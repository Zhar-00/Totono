default persistent.otorhin_was_here = False
define config.manage_gc = True


init:
    transform vienzoom:
        zoom 1.0/(1080.0/config.screen_height)

screen otorhin():

    add "#181818"

    add "otrh/logo.png":
        xalign 0.1
        yalign 0.5
        at vienzoom

    add "otrh/made.png":
        xalign 0.6
        yalign 0.5
        at vienzoom

    hbox:
        xalign 0.6
        yalign 0.9
        spacing 30
        yanchor 64+int(60/(1080.0/config.screen_height))

        imagebutton:
            idle "otrh/tg.png"
            action OpenURL("https://t.me/otorhin")
            at vienzoom
        imagebutton:
            idle "otrh/vk.png"
            action OpenURL("https://vk.com/otorhin")
            at vienzoom
        imagebutton:
            idle "otrh/web.png"
            action OpenURL("https://otorh.in")
            at vienzoom

label otorhinsplashscreen:
    scene black
    show screen otorhin with fade
    if persistent.otorhin_was_here:
        $ renpy.pause(2)
    else:
        $ persistent.otorhin_was_here = True
        $ renpy.pause(3, hard=True)
        $ renpy.pause(7)
    hide screen otorhin with fade
    return


label hiddenotorhin:
    "Спасибо VienDesu за их сплешскрин и костыль =)"

init python:
    def fix_android11(name):
        if renpy.is_init_phase():
            return
        
        cache = renpy.display.im.cache
        
        if fix_android11.statements_passed > 100:
            reason = "statements"
        
        elif cache.get_total_size() >= cache.cache_limit * 1.25:
            cache.clear()
            reason = "cache"
        
        else:
            fix_android11.statements_passed += 1
            return
        
        fix_android11.statements_passed = 0
        
        if renpy.game.interface is not None:
            renpy.game.interface.full_redraw = True
            renpy.game.interface.restart_interaction = False
            
            if renpy.display.draw is not None:
                renpy.display.draw.kill_textures()
            
            renpy.display.render.free_memory()
        
        renpy.write_log(
        "Textures cleanup, {}: {}".format(reason, renpy.get_filename_line()))
    fix_android11.statements_passed = 0
    config.statement_callbacks.append(fix_android11)

    config.gestures = {
        "e" : "toggle_skip",
        "w" : "rollback",
        "n" : "game_menu",
    }
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
