#################################################
## Somnoria Traducciones 2026                  ##
#################################################
init offset = -1

init:
    $ enable_splash_port = False
    $ enable_splash_trans = True
    $ enable_lang_screen = True
    $ lang_font = style.default.font
    $ link_variant = "en"

default persistent.lang_set = False

init:
    # Se mantiene este nombre técnico para no romper otras partes del juego
    transform vienzoom:
        zoom 1.0/(1080.0/config.screen_height)

    transform vienscale:
        zoom 1.25

    $ splash_spacing = config.screen_width/32

init python early:
    config.enable_language_autodetect = True

screen lang():
    modal True
    hbox:
        xalign 0.5
        yalign 0.5
        textbutton _("{font=[lang_font]}Español{/font}"):
            action [SetField(persistent, "lang_set", True), Language("english"), Hide('lang'), Return()]
        textbutton _("{font=[lang_font]}Русский (Ruso){/font}"):
            action [SetField(persistent, "lang_set", True), Language(None), Hide('lang'), Return()]

screen somnoria_port_logo():
    # Pantalla del port ruso (Apagada desde arriba)
    add "viendesu/port_logo.png":
        xalign 0.5
        yalign 0.5
        at vienzoom

screen somnoria_trans_logo():
    # Pantalla de Somnoria Traducciones (Encendida)
    # CORRECCIÓN 1: Ruta cambiada a "viendesu/logo_espanol.png"
    add "viendesu/logo_espanol.png":
        xalign 0.5
        yalign 0.5
        at vienzoom

    hbox:
        xalign 0.5
        ypos 0.9
        spacing splash_spacing

        imagebutton:
            idle "viendesu/tg.png"
            action OpenURL("https://t.me/Somnoria_VN")
            at vienzoom

init 999 python:
    config.label_overrides["splashscreen"] = "somnoria_splash"

label somnoria_splash:
    if enable_splash_port:
        scene black
        show screen somnoria_port_logo with fade
        pause 2.0
        hide screen somnoria_port_logo with fade

    if enable_splash_trans:
        scene black
        show screen somnoria_trans_logo with fade
        # CORRECCIÓN 2: Tiempo de visualización aumentado a 4.0 segundos
        pause 4.0
        hide screen somnoria_trans_logo with fade

    $ config.label_overrides.pop("splashscreen")
    if renpy.has_label("splashscreen"):
        call splashscreen from _call_splashscreen

    if not persistent.lang_set and enable_lang_screen:
        scene black
        call screen lang with dissolve
return
