"################################################# ## VienDesu! 2026 ## #################################################"
init offset = -1









init:
    $ enable_splash_port = False
    $ enable_splash_trans = False
    $ enable_lang_screen = True
    $ lang_font = style.default.font
    $ link_variant = "en"





default persistent.lang_set = False

init:

    transform vienzoom:
        zoom 1.0/(1080.0/config.screen_height)


    transform vienscale:
        zoom 1.25

    $ splash_spacing = config.screen_width/32





init python early:
    config.enable_language_autodetect = True

screen lang():
    modal True
    hbox:
        xalign 0.5
        yalign 0.5
        textbutton _("{font=[lang_font]}Español{/font}"):
            action [SetField(persistent, "lang_set", True), Language("english"), Hide('lang'), Return()]
        textbutton _("{font=[lang_font]}Русский (Ruso){/font}"):
            action [SetField(persistent, "lang_set", True), Language(None), Hide('lang'), Return()]





screen vienlogo():

    add "viendesu/port_logo.png":
        xalign 0.5
        yalign 0.5
        at vienzoom

    hbox:
        xalign 0.5
        ypos 0.9
        spacing splash_spacing

        imagebutton:
            idle "viendesu/yt.png"
            action OpenURL("https://www.youtube.com/@viendesu")
            at vienzoom
        imagebutton:
            idle "viendesu/tg.png"
            if link_variant == "ru":
                action OpenURL("https://t.me/visual_novels_for_android")
            if link_variant == "en":
                action OpenURL("https://t.me/visual_novels_android_eng")
            at vienzoom
        if link_variant == "ru":
            imagebutton:
                idle "viendesu/vk.png"
                action OpenURL("https://vk.com/viendesu")
                at vienzoom
        imagebutton:
            idle "viendesu/web.png"
            action OpenURL("https://viende.su")
            at vienzoom

screen vientranslogo():
    add "viendesu/trans_logo.png":
        xalign 0.5
        yalign 0.5
        at vienzoom

    hbox:
        xalign 0.5
        ypos 0.9
        spacing splash_spacing

        imagebutton:
            idle "viendesu/tg.png"
            action OpenURL("https://t.me/pufkein")
            at vienzoom


init 999 python:
    config.label_overrides["splashscreen"] = "viensplash"

label viensplash:
    if enable_splash_port:
        scene black
        show screen vienlogo with fade
        pause 2.0
        hide screen vienlogo with fade

    if enable_splash_trans:
        scene black
        show screen vientranslogo with fade
        pause 2.0
        hide screen vientranslogo with fade


    $ config.label_overrides.pop("splashscreen")
    if renpy.has_label("splashscreen"):
        call splashscreen from _call_splashscreen


    if not persistent.lang_set and enable_lang_screen:
        scene black
        call screen lang with dissolve
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
