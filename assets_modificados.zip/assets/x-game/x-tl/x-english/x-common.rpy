
translate english strings:


    old "Click to play the video."
    new "Click to play the video."


    old "Self-voicing disabled."
    new "Self-voicing disabled."


    old "Clipboard voicing enabled. "
    new "Clipboard voicing enabled. "


    old "Self-voicing enabled. "
    new "Self-voicing enabled. "


    old "bar"
    new "bar"


    old "selected"
    new "selected"


    old "viewport"
    new "viewport"


    old "horizontal scroll"
    new "horizontal scroll"


    old "vertical scroll"
    new "vertical scroll"


    old "activate"
    new "activate"


    old "deactivate"
    new "deactivate"


    old "increase"
    new "increase"


    old "decrease"
    new "decrease"


    old "Self-Voicing"
    new "Self-Voicing"


    old "Self-voicing support is limited when using a touch screen."
    new "Self-voicing support is limited when using a touch screen."


    old "Off"
    new "Off"


    old "Text-to-speech"
    new "Text-to-speech"


    old "Clipboard"
    new "Clipboard"


    old "Debug"
    new "Debug"


    old "Voice Volume"
    new "Voice Volume"


    old "Reset"
    new "Reset"


    old "Self-Voicing Volume Drop"
    new "Self-Voicing Volume Drop"


    old "Mono Audio"
    new "Mono Audio"


    old "Enable"
    new "Enable"


    old "Disable"
    new "Disable"


    old "Font Override"
    new "Font Override"


    old "Default"
    new "Default"


    old "DejaVu Sans"
    new "DejaVu Sans"


    old "Opendyslexic"
    new "Opendyslexic"


    old "High Contrast Text"
    new "High Contrast Text"


    old "Text Size Scaling"
    new "Text Size Scaling"


    old "Line Spacing Scaling"
    new "Line Spacing Scaling"


    old "Kerning"
    new "Kerning"


    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."


    old "Self-Voicing and Audio"
    new "Self-Voicing and Audio"


    old "Text"
    new "Text"


    old "Return"
    new "Return"


    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."


    old "{#weekday}Monday"
    new "{#weekday}Monday"


    old "{#weekday}Tuesday"
    new "{#weekday}Tuesday"


    old "{#weekday}Wednesday"
    new "{#weekday}Wednesday"


    old "{#weekday}Thursday"
    new "{#weekday}Thursday"


    old "{#weekday}Friday"
    new "{#weekday}Friday"


    old "{#weekday}Saturday"
    new "{#weekday}Saturday"


    old "{#weekday}Sunday"
    new "{#weekday}Sunday"


    old "{#weekday_short}Mon"
    new "{#weekday_short}Mon"


    old "{#weekday_short}Tue"
    new "{#weekday_short}Tue"


    old "{#weekday_short}Wed"
    new "{#weekday_short}Wed"


    old "{#weekday_short}Thu"
    new "{#weekday_short}Thu"


    old "{#weekday_short}Fri"
    new "{#weekday_short}Fri"


    old "{#weekday_short}Sat"
    new "{#weekday_short}Sat"


    old "{#weekday_short}Sun"
    new "{#weekday_short}Sun"


    old "{#month}January"
    new "{#month}January"


    old "{#month}February"
    new "{#month}February"


    old "{#month}March"
    new "{#month}March"


    old "{#month}April"
    new "{#month}April"


    old "{#month}May"
    new "{#month}May"


    old "{#month}June"
    new "{#month}June"


    old "{#month}July"
    new "{#month}July"


    old "{#month}August"
    new "{#month}August"


    old "{#month}September"
    new "{#month}September"


    old "{#month}October"
    new "{#month}October"


    old "{#month}November"
    new "{#month}November"


    old "{#month}December"
    new "{#month}December"


    old "{#month_short}Jan"
    new "{#month_short}Jan"


    old "{#month_short}Feb"
    new "{#month_short}Feb"


    old "{#month_short}Mar"
    new "{#month_short}Mar"


    old "{#month_short}Apr"
    new "{#month_short}Apr"


    old "{#month_short}May"
    new "{#month_short}May"


    old "{#month_short}Jun"
    new "{#month_short}Jun"


    old "{#month_short}Jul"
    new "{#month_short}Jul"


    old "{#month_short}Aug"
    new "{#month_short}Aug"


    old "{#month_short}Sep"
    new "{#month_short}Sep"


    old "{#month_short}Oct"
    new "{#month_short}Oct"


    old "{#month_short}Nov"
    new "{#month_short}Nov"


    old "{#month_short}Dec"
    new "{#month_short}Dec"


    old "%b %d, %H:%M"
    new "%b %d, %H:%M"


    old "Save slot %s: [text]"
    new "Save slot %s: [text]"


    old "Load slot %s: [text]"
    new "Load slot %s: [text]"


    old "Delete slot [text]"
    new "Delete slot [text]"


    old "File page auto"
    new "File page auto"


    old "File page quick"
    new "File page quick"


    old "File page [text]"
    new "File page [text]"


    old "Page {}"
    new "Page {}"


    old "Automatic saves"
    new "Automatic saves"


    old "Quick saves"
    new "Quick saves"


    old "Next file page."
    new "Next file page."


    old "Previous file page."
    new "Previous file page."


    old "Quick save complete."
    new "Quick save complete."


    old "Quick save."
    new "Quick save."


    old "Quick load."
    new "Quick load."


    old "Language [text]"
    new "Language [text]"


    old "Open [text] directory."
    new "Open [text] directory."


    old "The interactive director is not enabled here."
    new "The interactive director is not enabled here."


    old "⬆"
    new "⬆"


    old "⬇"
    new "⬇"


    old "Done"
    new "Done"


    old "(statement)"
    new "(statement)"


    old "(tag)"
    new "(tag)"


    old "(attributes)"
    new "(attributes)"


    old "(transform)"
    new "(transform)"


    old "(transition)"
    new "(transition)"


    old "(channel)"
    new "(channel)"


    old "(filename)"
    new "(filename)"


    old "Change"
    new "Change"


    old "Add"
    new "Add"


    old "Cancel"
    new "Cancel"


    old "Remove"
    new "Remove"


    old "Statement:"
    new "Statement:"


    old "Tag:"
    new "Tag:"


    old "Attributes:"
    new "Attributes:"


    old "Click to toggle attribute, right click to toggle negative attribute."
    new "Click to toggle attribute, right click to toggle negative attribute."


    old "Transforms:"
    new "Transforms:"


    old "Click to set transform, right click to add to transform list."
    new "Click to set transform, right click to add to transform list."


    old "Customize director.transforms to add more transforms."
    new "Customize director.transforms to add more transforms."


    old "Behind:"
    new "Behind:"


    old "Click to set, right click to add to behind list."
    new "Click to set, right click to add to behind list."


    old "Transition:"
    new "Transition:"


    old "Click to set."
    new "Click to set."


    old "Customize director.transitions to add more transitions."
    new "Customize director.transitions to add more transitions."


    old "Channel:"
    new "Channel:"


    old "Customize director.audio_channels to add more channels."
    new "Customize director.audio_channels to add more channels."


    old "Audio Filename:"
    new "Audio Filename:"


    old "Are you sure?"
    new "Are you sure?"


    old "Are you sure you want to delete this save?"
    new "Are you sure you want to delete this save?"


    old "Are you sure you want to overwrite your save?"
    new "Are you sure you want to overwrite your save?"


    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Loading will lose unsaved progress.\nAre you sure you want to do this?"


    old "Are you sure you want to quit?"
    new "Are you sure you want to quit?"


    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."


    old "Are you sure you want to continue where you left off?"
    new "Are you sure you want to continue where you left off?"


    old "Are you sure you want to end the replay?"
    new "Are you sure you want to end the replay?"


    old "Are you sure you want to begin skipping?"
    new "Are you sure you want to begin skipping?"


    old "Are you sure you want to skip to the next choice?"
    new "Are you sure you want to skip to the next choice?"


    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Are you sure you want to skip unseen dialogue to the next choice?"


    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"


    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."


    old "Failed to save screenshot as %s."
    new "Failed to save screenshot as %s."


    old "Saved screenshot as %s."
    new "Saved screenshot as %s."


    old "Skip Mode"
    new "Skip Mode"


    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."


    old "display"
    new "display"


    old "transitions"
    new "transitions"


    old "skip transitions"
    new "skip transitions"


    old "video sprites"
    new "video sprites"


    old "show empty window"
    new "show empty window"


    old "text speed"
    new "text speed"


    old "joystick"
    new "joystick"


    old "joystick..."
    new "joystick..."


    old "skip"
    new "skip"


    old "skip unseen [text]"
    new "skip unseen [text]"


    old "skip unseen text"
    new "skip unseen text"


    old "begin skipping"
    new "begin skipping"


    old "after choices"
    new "after choices"


    old "skip after choices"
    new "skip after choices"


    old "auto-forward time"
    new "auto-forward time"


    old "auto-forward"
    new "auto-forward"


    old "Auto forward"
    new "Auto forward"


    old "auto-forward after click"
    new "auto-forward after click"


    old "automatic move"
    new "automatic move"


    old "wait for voice"
    new "wait for voice"


    old "voice sustain"
    new "voice sustain"


    old "self voicing"
    new "self voicing"


    old "self voicing enable"
    new "self voicing enable"


    old "self voicing disable"
    new "self voicing disable"


    old "self voicing volume drop"
    new "self voicing volume drop"


    old "clipboard voicing"
    new "clipboard voicing"


    old "clipboard voicing enable"
    new "clipboard voicing enable"


    old "clipboard voicing disable"
    new "clipboard voicing disable"


    old "debug voicing"
    new "debug voicing"


    old "debug voicing enable"
    new "debug voicing enable"


    old "debug voicing disable"
    new "debug voicing disable"


    old "emphasize audio"
    new "emphasize audio"


    old "rollback side"
    new "rollback side"


    old "gl powersave"
    new "gl powersave"


    old "gl framerate"
    new "gl framerate"


    old "gl tearing"
    new "gl tearing"


    old "font transform"
    new "font transform"


    old "font size"
    new "font size"


    old "font line spacing"
    new "font line spacing"


    old "system cursor"
    new "system cursor"


    old "renderer menu"
    new "renderer menu"


    old "accessibility menu"
    new "accessibility menu"


    old "high contrast text"
    new "high contrast text"


    old "audio when minimized"
    new "audio when minimized"


    old "audio when unfocused"
    new "audio when unfocused"


    old "web cache preload"
    new "web cache preload"


    old "voice after game menu"
    new "voice after game menu"


    old "restore window position"
    new "restore window position"


    old "mono audio"
    new "mono audio"


    old "font kerning"
    new "font kerning"


    old "reset"
    new "reset"


    old "main volume"
    new "main volume"


    old "music volume"
    new "music volume"


    old "sound volume"
    new "sound volume"


    old "voice volume"
    new "voice volume"


    old "mute main"
    new "mute main"


    old "mute music"
    new "mute music"


    old "mute sound"
    new "mute sound"


    old "mute voice"
    new "mute voice"


    old "mute all"
    new "mute all"


    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Clipboard voicing enabled. Press 'shift+C' to disable."


    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."


    old "Self-voicing enabled. Press 'v' to disable."
    new "Self-voicing enabled. Press 'v' to disable."


    old "Speech Bubble Editor"
    new "Speech Bubble Editor"


    old "(hide)"
    new "(hide)"


    old "(clear retained bubbles)"
    new "(clear retained bubbles)"


    old "Sync downloaded."
    new "Sync downloaded."


    old "Could not connect to the Ren'Py Sync server."
    new "Could not connect to the Ren'Py Sync server."


    old "The Ren'Py Sync server timed out."
    new "The Ren'Py Sync server timed out."


    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "An unknown error occurred while connecting to the Ren'Py Sync server."


    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."


    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."


    old "The sync ID is not in the correct format."
    new "The sync ID is not in the correct format."


    old "The sync could not be decrypted."
    new "The sync could not be decrypted."


    old "The sync belongs to a different game."
    new "The sync belongs to a different game."


    old "The sync contains a file with an invalid name."
    new "The sync contains a file with an invalid name."


    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"


    old "Yes"
    new "Yes"


    old "No"
    new "No"


    old "Enter Sync ID"
    new "Enter Sync ID"


    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."


    old "Sync Success"
    new "Sync Success"


    old "The Sync ID is:"
    new "The Sync ID is:"


    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."


    old "Continue"
    new "Continue"


    old "Sync Error"
    new "Sync Error"


    old "Translation identifier: [identifier]"
    new "Translation identifier: [identifier]"


    old " translates [tl.filename]:[tl.linenumber]"
    new " translates [tl.filename]:[tl.linenumber]"


    old "\n{color=#fff}Copied to clipboard.{/color}"
    new "\n{color=#fff}Copied to clipboard.{/color}"


    old "Contacting App Store\nPlease Wait..."
    new "Contacting App Store\nPlease Wait..."


    old "No update methods found."
    new "No update methods found."


    old "Could not download file list: "
    new "Could not download file list: "


    old "File list digest does not match."
    new "File list digest does not match."


    old "An error is being simulated."
    new "An error is being simulated."


    old "Either this project does not support updating, or the update status file was deleted."
    new "Either this project does not support updating, or the update status file was deleted."


    old "This account does not have permission to perform an update."
    new "This account does not have permission to perform an update."


    old "This account does not have permission to write the update log."
    new "This account does not have permission to write the update log."


    old "Could not verify update signature."
    new "Could not verify update signature."


    old "The update file was not downloaded."
    new "The update file was not downloaded."


    old "The update file does not have the correct digest - it may have been corrupted."
    new "The update file does not have the correct digest - it may have been corrupted."


    old "While unpacking {}, unknown type {}."
    new "While unpacking {}, unknown type {}."


    old "Updater"
    new "Updater"


    old "An error has occurred:"
    new "An error has occurred:"


    old "Checking for updates."
    new "Checking for updates."


    old "This program is up to date."
    new "This program is up to date."


    old "[u.version] is available. Do you want to install it?"
    new "[u.version] is available. Do you want to install it?"


    old "Preparing to download the updates."
    new "Preparing to download the updates."


    old "Downloading the updates."
    new "Downloading the updates."


    old "Unpacking the updates."
    new "Unpacking the updates."


    old "Finishing up."
    new "Finishing up."


    old "The updates have been installed. The program will restart."
    new "The updates have been installed. The program will restart."


    old "The updates have been installed."
    new "The updates have been installed."


    old "The updates were cancelled."
    new "The updates were cancelled."


    old "Proceed"
    new "Proceed"


    old "Preparing to download the game data."
    new "Preparing to download the game data."


    old "Downloading the game data."
    new "Downloading the game data."


    old "The game data has been downloaded."
    new "The game data has been downloaded."


    old "An error occurred when trying to download game data:"
    new "An error occurred when trying to download game data:"


    old "This game cannot be run until the game data has been downloaded."
    new "This game cannot be run until the game data has been downloaded."


    old "Retry"
    new "Retry"


    old "Fullscreen"
    new "Fullscreen"


    old "Image [index] of [count] locked."
    new "Image [index] of [count] locked."


    old "prev"
    new "prev"


    old "next"
    new "next"


    old "slideshow"
    new "slideshow"


    old "return"
    new "return"


    old "Renderer"
    new "Renderer"


    old "Automatically Choose"
    new "Automatically Choose"


    old "Force GL2 Renderer"
    new "Force GL2 Renderer"


    old "Force ANGLE2 Renderer"
    new "Force ANGLE2 Renderer"


    old "Force GLES2 Renderer"
    new "Force GLES2 Renderer"


    old "Gamepad"
    new "Gamepad"


    old "Enable (No Blocklist)"
    new "Enable (No Blocklist)"


    old "Calibrate"
    new "Calibrate"


    old "Powersave"
    new "Powersave"


    old "Framerate"
    new "Framerate"


    old "Screen"
    new "Screen"


    old "60"
    new "60"


    old "30"
    new "30"


    old "Tearing"
    new "Tearing"


    old "Changes will take effect the next time this program is run."
    new "Changes will take effect the next time this program is run."


    old "Quit"
    new "Quit"


    old "Performance Warning"
    new "Performance Warning"


    old "This computer is using software rendering."
    new "This computer is using software rendering."


    old "This game requires use of GL2 that can't be initialised."
    new "This game requires use of GL2 that can't be initialised."


    old "This computer has a problem displaying graphics: [problem]."
    new "This computer has a problem displaying graphics: [problem]."


    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."


    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."


    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "More details on how to fix this can be found in the {a=[url]}documentation{/a}."


    old "Continue, Show this warning again"
    new "Continue, Show this warning again"


    old "Continue, Don't show warning again"
    new "Continue, Don't show warning again"


    old "Change render options"
    new "Change render options"


    old "Select Gamepad to Calibrate"
    new "Select Gamepad to Calibrate"


    old "No Gamepads Available"
    new "No Gamepads Available"


    old "Calibrating [name] ([i]/[total])"
    new "Calibrating [name] ([i]/[total])"


    old "Press or move the '[control!s]' [kind]."
    new "Press or move the '[control!s]' [kind]."


    old "Skip (A)"
    new "Skip (A)"


    old "Back (B)"
    new "Back (B)"


    old "Open"
    new "Open"


    old "Opens the traceback.txt file in a text editor."
    new "Opens the traceback.txt file in a text editor."


    old "Copy BBCode"
    new "Copy BBCode"


    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."


    old "Copy Markdown"
    new "Copy Markdown"


    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Copies the traceback.txt file to the clipboard as Markdown for Discord."


    old "An exception has occurred."
    new "An exception has occurred."


    old "Rollback"
    new "Rollback"


    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Attempts a roll back to a prior time, allowing you to save or choose a different choice."


    old "Ignore"
    new "Ignore"


    old "Ignores the exception, allowing you to continue."
    new "Ignores the exception, allowing you to continue."


    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignores the exception, allowing you to continue. This often leads to additional errors."


    old "Reload"
    new "Reload"


    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Reloads the game from disk, saving and restoring game state if possible."


    old "Console"
    new "Console"


    old "Opens a console to allow debugging the problem."
    new "Opens a console to allow debugging the problem."


    old "Quits the game."
    new "Quits the game."


    old "Parsing the script failed."
    new "Parsing the script failed."


    old "Developer Menu"
    new "Developer Menu"


    old "Interactive Director (D)"
    new "Interactive Director (D)"


    old "Reload Game (Shift+R)"
    new "Reload Game (Shift+R)"


    old "Console (Shift+O)"
    new "Console (Shift+O)"


    old "Variable Viewer"
    new "Variable Viewer"


    old "Persistent Viewer"
    new "Persistent Viewer"


    old "Image Location Picker"
    new "Image Location Picker"


    old "Filename List"
    new "Filename List"


    old "Show Image Load Log (F4)"
    new "Show Image Load Log (F4)"


    old "Hide Image Load Log (F4)"
    new "Hide Image Load Log (F4)"


    old "Image Attributes"
    new "Image Attributes"


    old "Show Translation Info"
    new "Show Translation Info"


    old "Hide Translation Info"
    new "Hide Translation Info"


    old "Speech Bubble Editor (Shift+B)"
    new "Speech Bubble Editor (Shift+B)"


    old "Show Filename and Line"
    new "Show Filename and Line"


    old "Hide Filename and Line"
    new "Hide Filename and Line"


    old "Layer [l]:"
    new "Layer [l]:"


    old "    (transforms: [', '.join(transform_list)])"
    new "    (transforms: [', '.join(transform_list)])"


    old "    [name!q] [attributes!q] (hidden)"
    new "    [name!q] [attributes!q] (hidden)"


    old "    [name!q] [attributes!q]"
    new "    [name!q] [attributes!q]"


    old "Nothing to inspect."
    new "Nothing to inspect."


    old "Hide deleted"
    new "Hide deleted"


    old "Show deleted"
    new "Show deleted"


    old "Rectangle copied to clipboard."
    new "Rectangle copied to clipboard."


    old "Position copied to clipboard."
    new "Position copied to clipboard."


    old "Rectangle: %r"
    new "Rectangle: %r"


    old "Mouse position: %r"
    new "Mouse position: %r"


    old "Right-click or escape to quit."
    new "Right-click or escape to quit."


    old "Type to filter: "
    new "Type to filter: "


    old "Textures: [tex_count] ([tex_size_mb:.1f] MB)"
    new "Textures: [tex_count] ([tex_size_mb:.1f] MB)"


    old "Image cache: [cache_pct:.1f]% ([cache_size_mb:.1f] MB)"
    new "Image cache: [cache_pct:.1f]% ([cache_size_mb:.1f] MB)"


    old "✔ "
    new "✔ "


    old "✘ "
    new "✘ "


    old "\n{color=#cfc}✔ predicted image (good){/color}\n{color=#fcc}✘ unpredicted image (bad){/color}\n{color=#fff}Drag to move.{/color}"
    new "\n{color=#cfc}✔ predicted image (good){/color}\n{color=#fcc}✘ unpredicted image (bad){/color}\n{color=#fff}Drag to move.{/color}"


    old "Click to open in editor."
    new "Click to open in editor."


    old "Displayable Inspector"
    new "Displayable Inspector"


    old "Size"
    new "Size"


    old "Style"
    new "Style"


    old "Location"
    new "Location"


    old "Inspecting Styles of [displayable_name!q]"
    new "Inspecting Styles of [displayable_name!q]"


    old "displayable:"
    new "displayable:"


    old "        (no properties affect the displayable)"
    new "        (no properties affect the displayable)"


    old "        (default properties omitted)"
    new "        (default properties omitted)"


    old "<repr() failed>"
    new "<repr() failed>"


    old "Press <esc> to exit console. Type help for help.\n"
    new "Press <esc> to exit console. Type help for help.\n"


    old "Ren'Py script enabled."
    new "Ren'Py script enabled."


    old "Ren'Py script disabled."
    new "Ren'Py script disabled."


    old "The console is using short representations. To disable this, type 'long', and to re-enable, type 'short'"
    new "The console is using short representations. To disable this, type 'long', and to re-enable, type 'short'"


    old "help: show this help\n help <expr>: show signature and documentation of <expr>"
    new "help: show this help\n help <expr>: show signature and documentation of <expr>"


    old "Help may display undocumented functions. Please check that the function or\nclass you want to use is documented.\n\n"
    new "Help may display undocumented functions. Please check that the function or\nclass you want to use is documented.\n\n"


    old "commands:\n"
    new "commands:\n"


    old " <renpy script statement>: run the statement\n"
    new " <renpy script statement>: run the statement\n"


    old " <python expression or statement>: run the expression or statement"
    new " <python expression or statement>: run the expression or statement"


    old "clear: clear the console history"
    new "clear: clear the console history"


    old "exit: exit the console"
    new "exit: exit the console"


    old "stack: print the return stack"
    new "stack: print the return stack"


    old "load <slot>: loads the game from slot"
    new "load <slot>: loads the game from slot"


    old "save <slot>: saves the game in slot"
    new "save <slot>: saves the game in slot"


    old "reload: reloads the game, refreshing the scripts"
    new "reload: reloads the game, refreshing the scripts"


    old "watch <expression>: watch a python expression\n watch short: makes the representation of traced expressions short (default)\n watch long: makes the representation of traced expressions as is"
    new "watch <expression>: watch a python expression\n watch short: makes the representation of traced expressions short (default)\n watch long: makes the representation of traced expressions as is"


    old "unwatch <expression>: stop watching an expression"
    new "unwatch <expression>: stop watching an expression"


    old "unwatchall: stop watching all expressions"
    new "unwatchall: stop watching all expressions"


    old "jump <label>: jumps to label"
    new "jump <label>: jumps to label"


    old "short: Shorten the representation of objects on the console (default)."
    new "short: Shorten the representation of objects on the console (default)."


    old "long: Print the full representation of objects on the console."
    new "long: Print the full representation of objects on the console."


    old "escape: Enables escaping of unicode symbols in unicode strings."
    new "escape: Enables escaping of unicode symbols in unicode strings."


    old "unescape: Disables escaping of unicode symbols in unicode strings and print it as is (default)."
    new "unescape: Disables escaping of unicode symbols in unicode strings and print it as is (default)."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
