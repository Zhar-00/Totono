

translate english a0114b_d60c1f62:


    "...Vale, respiremos hondo y calmémonos."


translate english a0114b_ff867865:


    "¿Qué quiere exactamente esta chica de mí?"


translate english a0114b_83000884:


    "¿Y quién ES ella, siquiera?"


translate english a0114b_e42a321a:


    "Espera... ¿No es esto exactamente lo que acaba de pasar en ese juego...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
