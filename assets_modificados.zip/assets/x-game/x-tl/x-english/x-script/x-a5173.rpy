

translate english a5173_b6e1710f:


    xy "\"Wait, Miyuki! I'll get it!\""


translate english a5173_827e207f:



    voice "voice/a51/7300010a01.opus"
    mx "\"What's wrong? You're looking rather pale.\""


translate english a5173_017aa89c:



    voice "voice/a51/7300020a01.opus"
    mx "\"Oh, I get it. Haha! Are you hiding something NAUGHTY under here?\""


translate english a5173_61aa6144:


    "La sonrisa de Miyuki no llega a sus ojos."


translate english a5173_33972c2e:


    "Le grito en silencio que se detenga, pero mis plegarias caen en oídos sordos."


translate english a5173_7fae7faf:


    "Mete la mano hasta el fondo debajo de la cama... y se queda inmóvil."


translate english a5173_b75c880b:



    voice "voice/a51/7300030a01.opus"
    mx "\"Gotcha.\""


translate english a5173_29e3bee3:



    voice "voice/a51/7300040a02.opus"
    aoi "\"Boop boop...\""


translate english a5173_bbd68546:


    "Miyuki saca a Aoi de debajo de la cama."


translate english a5173_c361c5cf:


    "Ay, Dios... ¡Todavía está medio desnuda...!"


translate english a5173_f6d95aa6:



    voice "voice/a51/7300050a01.opus"
    mx "\"......Oh.\""


translate english a5173_a13c81f6:


    xy "\"Listen, I can explain—\""


translate english a5173_a8e77363:



    voice "voice/a51/7300060a01.opus"
    mx "\"\"......!!!\"\""


translate english a5173_061c5e6f:


    xy "\"Stop!\""


translate english a5173_f4bb03da:


    "Miyuki aparta la mano, y la agarro del brazo."


translate english a5173_6c4d6fd4:



    voice "voice/a51/7300070a01.opus"
    mx "\"What do you want?! Let go of me!\""


translate english a5173_fa29f229:


    xy "\"Please, let's just stay calm—\""


translate english a5173_0e002162:



    voice "voice/a51/7300080a01.opus"
    mx "\"How can I possibly stay calm right now?!\""


translate english a5173_1a7022e1:


    "Forcejeando contra mi agarre, se gira hacia Aoi."


translate english a5173_e36f9455:



    voice "voice/a51/7300090a01.opus"
    mx "\"I thought you were trying to help me! I thought you wanted me and him to get together!\""


translate english a5173_44052665:



    voice "voice/a51/7300100a01.opus"
    mx "\"So why...? Why?! Why would you make a move on him?!\""


translate english a5173_df729b02:


    xy "\"I'm telling you, you've got the wrong idea!\""


translate english a5173_5c0c6f5b:



    voice "voice/a51/7300110a01.opus"
    mx "\"SHUT UP!\""


translate english a5173_59440fa7:



    voice "voice/a51/7300120a01.opus"
    mx "\"You care about Aoi more than me, don't you?\""


translate english a5173_bd775c5a:



    voice "voice/a51/7300130a01.opus"
    mx "\"I get it, okay? I know I hurt you! I never should have treated you like a guinea pig!\""



translate english a5173_c96be89b:



    voice "voice/a51/7300140a01.opus"
    mx "\"But this? This is too far!\""


translate english a5173_b801ff67:



    voice "voice/a51/7300150a01.opus"
    mx "\"How could you...?!\""


translate english a5173_adcc7c17:



    voice "voice/a51/7300160a02.opus"
    aoi "\"Got it.\""


translate english a5173_f3250316:


    "Ya vestida con su camisa aún húmeda, Aoi alza la mano para hablar por primera vez desde que empezó la pelea."


translate english a5173_ea48e621:


    "Su expresión es tan vacía que me da un escalofrío."


translate english a5173_d79bc662:



    voice "voice/a51/7300170a02.opus"
    aoi "\"Aoi's the one who tried to seduce Shinichi.\""


translate english a5173_7f7829bd:



    voice "voice/a51/7300180a02.opus"
    aoi "\"Aoi is a transceiver. A space case.\""


translate english a5173_c66466db:



    voice "voice/a51/7300190a02.opus"
    aoi "\"Every bit as slutty as the rumors say.\""


translate english a5173_fad8cade:



    voice "voice/a51/7300200a02.opus"
    aoi "\"And Aoi tried to have sex with Shinichi.\""


translate english a5173_377cad69:



    voice "voice/a51/7300210a01.opus"
    mx "\"\"......!!!\"\""


translate english a5173_1551c702:


    xy "\"Wait, Miyuki! I'll get it!\""


translate english a5173_d4962ed7:


    "Miyuki intenta una vez más alzar la mano contra Aoi, pero apenas logro contenerla."


translate english a5173_c32763e0:



    voice "voice/a51/7300220a01.opus"
    mx "\"Let GO of me!\""


translate english a5173_85c07747:


    xy "\"Just stop!\""


translate english a5173_087e5d0f:


    xy "\"And you, Aoi! Where did all that come from?!\""


translate english a5173_1f34fc71:



    voice "voice/a51/7300230a02.opus"
    aoi "\"Aoi got the phone back.\""


translate english a5173_666449f2:



    voice "voice/a51/7300240a02.opus"
    aoi "\"Now it's time to load my save file.\""


translate english a5173_7f2193d8:



    voice "voice/a51/7300250a02.opus"
    aoi "\"After that, Aoi will disappear.\""


translate english a5173_d58dac9c:



    voice "voice/a51/7300260a02.opus"
    aoi "\"You'll never see me again.\""


translate english a5173_8c2511ed:


    xy "\"Aoi? What are you—\""


translate english a5173_e0452b6a:



    voice "voice/a51/7300270a02.opus"
    aoi "\"Bye-bye.\""


translate english a5173_d6935052:


    "Aoi sale de la habitación y desaparece de la vista."


translate english a5173_0c0d8f5b:


    "Corro tras ella."


translate english a5173_17704335:


    xy "\"Aoi, wait!\""


translate english a5173_0d06777c:



    voice "voice/a51/7300280a01.opus"
    mx "\"You're not going anywhere!\""


translate english a5173_02aec098:


    xy "\"Let go of me! She's not well!\""


translate english a5173_cceebafe:



    voice "voice/a51/7300290a01.opus"
    mx "\"I don't care!\""


translate english a5173_d2984f49:


    xy "\"Too bad! Now let go, damn it!\""


translate english a5173_05fbe504:



    voice "voice/a51/7300300a01.opus"
    mx "\"I'm not letting go!\""


translate english a5173_4c2db6bd:


    "Me hace girar para que la enfrente."


translate english a5173_1842df04:



    voice "voice/a51/7300310a01.opus"
    mx "\"The guinea pig stuff... It was all just an excuse...\""


translate english a5173_9716d451:


    "No puedo escapar."


translate english a5173_a0500b4d:



    voice "voice/a51/7300320a01.opus"
    mx "\"But I'm finally ready to say it.\""


translate english a5173_0307197f:


    "No puedo resistirme."


translate english a5173_08c2f9d5:



    voice "voice/a51/7300330a01.opus"
    mx "\"I'm ready to tell you the truth.\""


translate english a5173_1266a389:


    "Tengo miedo—"


translate english a5173_31cba53b:



    voice "voice/a51/7300340a01.opus"
    mx "\"The truth about how I feel.\""


translate english a5173_1e0419df:


    "No—"


translate english a5173_18c84473:



    voice "voice/a51/7300350a01.opus"
    mx "\"Shinichi, listen to me.\""


translate english a5173_427f6903:


    "Detente—"


translate english a5173_eb782d62:



    voice "voice/a51/7300360a01.opus"
    mx "\"I'm...\""


translate english a5173_eaf97a4e:


    "No termines esa frase—"


translate english a5173_f547bda5:



    voice "voice/a51/7300370a01.opus"
    mx "\"...in love with you.\""


translate english a5173_0accd139:


    xy "\"\"\"\"......\"!!!\"!!!\"Oh.\""


translate english a5173_b4d8ae49:


    "Exhalo."


translate english a5173_34c6e940:


    "Mis rodillas están débiles."


translate english a5173_481504a3:


    "Mi mente está en blanco."


translate english a5173_7ea18a7f:


    "No quería oírlo."


translate english a5173_96b4b370:


    "No quería que lo dijera."


translate english a5173_76bd24a3:


    "Ambos sabemos que está prohibido."


translate english a5173_ddfc113c:


    "Un acuerdo tácito."


translate english a5173_6292f48b:


    "Lo que acaba de decir..."


translate english a5173_c81a411a:


    "...lo destruirá todo."


translate english a5173_5439064b:



    voice "voice/a51/7300380a01.opus"
    mx "\"I just wanted you to kiss me.\""


translate english a5173_e3bef804:



    voice "voice/a51/7300390a01.opus"
    mx "\"That's all I really wanted.\""


translate english a5173_ebcc6d6c:



    voice "voice/a51/7300400a01.opus"
    mx "\"I've been dying to tell you...\""


translate english a5173_d95cf88e:



    voice "voice/a51/7300410a01.opus"
    mx "\"But I couldn't.\""


translate english a5173_afe82bc5:



    voice "voice/a51/7300420a01.opus"
    mx "\"I'm in love with you.\""


translate english a5173_61573e34:



    voice "voice/a51/7300430a01.opus"
    mx "\"Completely and utterly in love with you.\""


translate english a5173_377fbe82:



    voice "voice/a51/7300440a01.opus"
    mx "\"Shinichi... Please...\""


translate english a5173_dbf5a6cc:


    "Lentamente, los labios de Miyuki se acercan."


translate english a5173_6aeecdf0:


    "Sus labios..."


translate english a5173_147b0a83:


    "He querido besarlos tanto que hasta los he visto en mis sueños."


translate english a5173_6ff0929c:


    "Ahora estamos a solo centímetros..."


translate english a5173_f5876d10:


    "Puedo sentir su respiración rápida y superficial contra mi piel."


translate english a5173_c9149df5:


    "Puedo oler el más leve rastro de su perfume."


translate english a5173_b41e6d69:


    "Así que—"


translate english a5173_609da94a:


    "Yo—"


translate english a5173_17bca8c4:


    xy "\"...My phone's ringing.\""


translate english a5173_8c5982b9:



    voice "voice/a51/7300450a01.opus"
    mx "\"Shinichi!\""


translate english a5173_437945b5:


    xy "\"It's Yuutarou.\""


translate english a5173_de030945:


    xy "\"He's probably calling about Aoi.\""


translate english a5173_182debe4:


    "Soy basura por usar a Aoi como excusa. Lo sé."


translate english a5173_5b7f2283:


    "Pero es la única opción que tengo."


translate english a5173_c5819b76:



    voice "voice/a51/7300460a01.opus"
    mx "\"You're choosing a phone call... over ME...?\""


translate english a5173_70783706:


    "Puedo oír un tono de súplica en su voz."


translate english a5173_f1c0844c:


    "Sus ojos están inundados de lágrimas..."


translate english a5173_95f0f796:


    "Pero aparto la mirada."


translate english a5173_7fbbdd4a:


    xy "\"Hello?\""


translate english a5173_2c1ad5f8:



    voice "voice/a51/7300470b01.opus"
    xtl "\"Shinichi, you scumbag! The hell were you thinking, throwing Mukou out on her ass in her condition?!\""


translate english a5173_a48ba9e3:



    voice "voice/a51/7300480b01.opus"
    xtl "\"She stumbled all the way here with a kitten in tow!\""


translate english a5173_f17b0e76:


    xy "\"...I'm sorry.\""


translate english a5173_32e94202:



    voice "voice/a51/7300490b01.opus"
    xtl "\"Say that to her, not me. Anyway, I'll watch over her for now, alright?\""


translate english a5173_06e8022c:


    xy "\"Would you?\""


translate english a5173_3be24ab1:



    voice "voice/a51/7300500b01.opus"
    xtl "\"Well, you've got your hands full, yeah?\""


translate english a5173_2a1af6c4:


    xy "\"...I really owe you one.\""


translate english a5173_14874014:



    voice "voice/a51/7300510b01.opus"
    xtl "\"No sweat. See ya.\""


translate english a5173_dd116f34:


    "Cuelgo y miro alrededor de la habitación."


translate english a5173_64762b9e:


    "Pero Miyuki ya se ha ido."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
