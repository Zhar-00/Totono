

translate english a5173_b6e1710f:


    xy "\"¡Espera, Miyuki! ¡Yo lo recojo!\""


translate english a5173_827e207f:



    voice "voice/a51/7300010a01.opus"
    mx "\"¿Qué pasa? Te ves bastante pálido.\""


translate english a5173_017aa89c:



    voice "voice/a51/7300020a01.opus"
    mx "\"Ah, ya entiendo. ¡Jaja! ¿Estás escondiendo algo PÍCARO aquí abajo?\""


translate english a5173_61aa6144:


    "La sonrisa de Miyuki no llega a sus ojos."


translate english a5173_33972c2e:


    "Le grito en silencio que se detenga, pero mis plegarias caen en oídos sordos."


translate english a5173_7fae7faf:


    "Mete la mano hasta el fondo debajo de la cama... y se queda inmóvil."


translate english a5173_b75c880b:



    voice "voice/a51/7300030a01.opus"
    mx "\"Te agarré.\""


translate english a5173_29e3bee3:



    voice "voice/a51/7300040a02.opus"
    aoi "\"Boop boop...\""


translate english a5173_bbd68546:


    "Miyuki saca a Aoi de debajo de la cama."


translate english a5173_c361c5cf:


    "Ay, Dios... ¡Todavía está medio desnuda...!"


translate english a5173_f6d95aa6:



    voice "voice/a51/7300050a01.opus"
    mx "\"......Oh.\""


translate english a5173_a13c81f6:


    xy "\"Escucha, puedo explicarlo...\""


translate english a5173_a8e77363:



    voice "voice/a51/7300060a01.opus"
    mx "\"\"......!!!\"\""


translate english a5173_061c5e6f:


    xy "\"¡Basta!\""


translate english a5173_f4bb03da:


    "Miyuki aparta la mano, y la agarro del brazo."


translate english a5173_6c4d6fd4:



    voice "voice/a51/7300070a01.opus"
    mx "\"¡¿Qué quieres?! ¡Suéltame!\""


translate english a5173_fa29f229:


    xy "\"Por favor, solo calmémonos...\""


translate english a5173_0e002162:



    voice "voice/a51/7300080a01.opus"
    mx "\"¡¿Cómo puedo calmarme ahora mismo?!\""


translate english a5173_1a7022e1:


    "Forcejeando contra mi agarre, se gira hacia Aoi."


translate english a5173_e36f9455:



    voice "voice/a51/7300090a01.opus"
    mx "\"¡Pensé que estabas tratando de ayudarme! ¡Pensé que querías que él y yo estuviéramos juntos!\""


translate english a5173_44052665:



    voice "voice/a51/7300100a01.opus"
    mx "\"¿¡Entonces por qué...? ¡¿Por qué?! ¡¿Por qué te le insinuaste?!\""


translate english a5173_df729b02:


    xy "\"¡Te digo que te haces una idea equivocada!\""


translate english a5173_5c0c6f5b:



    voice "voice/a51/7300110a01.opus"
    mx "\"¡CÁLLATE!\""


translate english a5173_59440fa7:



    voice "voice/a51/7300120a01.opus"
    mx "\"Te importa más Aoi que yo, ¿verdad?\""


translate english a5173_bd775c5a:



    voice "voice/a51/7300130a01.opus"
    mx "\"Lo entiendo, ¿sí? ¡Sé que te herí! ¡Nunca debí tratarte como un conejillo de indias!\""



translate english a5173_c96be89b:



    voice "voice/a51/7300140a01.opus"
    mx "\"¿Pero esto? ¡Esto es demasiado!\""


translate english a5173_b801ff67:



    voice "voice/a51/7300150a01.opus"
    mx "\"¡¿Cómo pudiste...?!\""


translate english a5173_adcc7c17:



    voice "voice/a51/7300160a02.opus"
    aoi "\"Entendido.\""


translate english a5173_f3250316:


    "Ya vestida con su camisa aún húmeda, Aoi alza la mano para hablar por primera vez desde que empezó la pelea."


translate english a5173_ea48e621:


    "Su expresión es tan vacía que me da un escalofrío."


translate english a5173_d79bc662:



    voice "voice/a51/7300170a02.opus"
    aoi "\"Aoi es la que trató de seducir a Shinichi.\""


translate english a5173_7f7829bd:



    voice "voice/a51/7300180a02.opus"
    aoi "\"Aoi es una transceptora. Una despistada.\""


translate english a5173_c66466db:



    voice "voice/a51/7300190a02.opus"
    aoi "\"Igual de zorra que dicen los rumores.\""


translate english a5173_fad8cade:



    voice "voice/a51/7300200a02.opus"
    aoi "\"Y Aoi intentó tener sexo con Shinichi.\""


translate english a5173_377cad69:



    voice "voice/a51/7300210a01.opus"
    mx "\"\"......!!!\"\""


translate english a5173_1551c702:


    xy "\"¡Espera, Miyuki! ¡Yo lo recojo!\""


translate english a5173_d4962ed7:


    "Miyuki intenta una vez más alzar la mano contra Aoi, pero apenas logro contenerla."


translate english a5173_c32763e0:



    voice "voice/a51/7300220a01.opus"
    mx "\"¡SUÉLTAME!\""


translate english a5173_85c07747:


    xy "\"¡Solo basta!\""


translate english a5173_087e5d0f:


    xy "\"¡Y tú, Aoi! ¿¡De dónde salió todo eso!?\""


translate english a5173_1f34fc71:



    voice "voice/a51/7300230a02.opus"
    aoi "\"Aoi recuperó el teléfono.\""


translate english a5173_666449f2:



    voice "voice/a51/7300240a02.opus"
    aoi "\"Ahora es hora de cargar mi archivo de guardado.\""


translate english a5173_7f2193d8:



    voice "voice/a51/7300250a02.opus"
    aoi "\"Después de eso, Aoi desaparecerá.\""


translate english a5173_d58dac9c:



    voice "voice/a51/7300260a02.opus"
    aoi "\"No me volverás a ver.\""


translate english a5173_8c2511ed:


    xy "\"¿Aoi? ¿Qué estás...?\""


translate english a5173_e0452b6a:



    voice "voice/a51/7300270a02.opus"
    aoi "\"Bye-bye.\""


translate english a5173_d6935052:


    "Aoi sale de la habitación y desaparece de la vista."


translate english a5173_0c0d8f5b:


    "Corro tras ella."


translate english a5173_17704335:


    xy "\"¡Aoi, espera!\""


translate english a5173_0d06777c:



    voice "voice/a51/7300280a01.opus"
    mx "\"¡No te vas a ir a ningún lado!\""


translate english a5173_02aec098:


    xy "\"¡Suéltame! ¡Ella no está bien!\""


translate english a5173_cceebafe:



    voice "voice/a51/7300290a01.opus"
    mx "\"¡No me importa!\""


translate english a5173_d2984f49:


    xy "\"¡Pues qué lástima! ¡Ahora suéltame, carajo!\""


translate english a5173_05fbe504:



    voice "voice/a51/7300300a01.opus"
    mx "\"¡No te suelto!\""


translate english a5173_4c2db6bd:


    "Me hace girar para que la enfrente."


translate english a5173_1842df04:



    voice "voice/a51/7300310a01.opus"
    mx "\"Eso del conejillo de indias... Todo era solo una excusa...\""


translate english a5173_9716d451:


    "No puedo escapar."


translate english a5173_a0500b4d:



    voice "voice/a51/7300320a01.opus"
    mx "\"Pero por fin estoy lista para decirlo.\""


translate english a5173_0307197f:


    "No puedo resistirme."


translate english a5173_08c2f9d5:



    voice "voice/a51/7300330a01.opus"
    mx "\"Estoy lista para decirte la verdad.\""


translate english a5173_1266a389:


    "Tengo miedo—"


translate english a5173_31cba53b:



    voice "voice/a51/7300340a01.opus"
    mx "\"La verdad sobre lo que siento.\""


translate english a5173_1e0419df:


    "No—"


translate english a5173_18c84473:



    voice "voice/a51/7300350a01.opus"
    mx "\"Shinichi, escúchame.\""


translate english a5173_427f6903:


    "Detente—"


translate english a5173_eb782d62:



    voice "voice/a51/7300360a01.opus"
    mx "\"Estoy...\""


translate english a5173_eaf97a4e:


    "No termines esa frase—"


translate english a5173_f547bda5:



    voice "voice/a51/7300370a01.opus"
    mx "\"...enamorada de ti.\""


translate english a5173_0accd139:


    xy "\"\"\"\"......\"!!!\"!!!\"Oh.\""


translate english a5173_b4d8ae49:


    "Exhalo."


translate english a5173_34c6e940:


    "Mis rodillas están débiles."


translate english a5173_481504a3:


    "Mi mente está en blanco."


translate english a5173_7ea18a7f:


    "No quería oírlo."


translate english a5173_96b4b370:


    "No quería que lo dijera."


translate english a5173_76bd24a3:


    "Ambos sabemos que está prohibido."


translate english a5173_ddfc113c:


    "Un acuerdo tácito."


translate english a5173_6292f48b:


    "Lo que acaba de decir..."


translate english a5173_c81a411a:


    "...lo destruirá todo."


translate english a5173_5439064b:



    voice "voice/a51/7300380a01.opus"
    mx "\"Solo quería que me besaras.\""


translate english a5173_e3bef804:



    voice "voice/a51/7300390a01.opus"
    mx "\"Eso es todo lo que de verdad quería.\""


translate english a5173_ebcc6d6c:



    voice "voice/a51/7300400a01.opus"
    mx "\"Me moría por decírtelo...\""


translate english a5173_d95cf88e:



    voice "voice/a51/7300410a01.opus"
    mx "\"Pero no podía.\""


translate english a5173_afe82bc5:



    voice "voice/a51/7300420a01.opus"
    mx "\"Estoy enamorada de ti.\""


translate english a5173_61573e34:



    voice "voice/a51/7300430a01.opus"
    mx "\"Completa y absolutamente enamorada de ti.\""


translate english a5173_377fbe82:



    voice "voice/a51/7300440a01.opus"
    mx "\"Shinichi... Por favor...\""


translate english a5173_dbf5a6cc:


    "Lentamente, los labios de Miyuki se acercan."


translate english a5173_6aeecdf0:


    "Sus labios..."


translate english a5173_147b0a83:


    "He querido besarlos tanto que hasta los he visto en mis sueños."


translate english a5173_6ff0929c:


    "Ahora estamos a solo centímetros..."


translate english a5173_f5876d10:


    "Puedo sentir su respiración rápida y superficial contra mi piel."


translate english a5173_c9149df5:


    "Puedo oler el más leve rastro de su perfume."


translate english a5173_b41e6d69:


    "Así que—"


translate english a5173_609da94a:


    "Yo—"


translate english a5173_17bca8c4:


    xy "\"...Mi teléfono está sonando.\""


translate english a5173_8c5982b9:



    voice "voice/a51/7300450a01.opus"
    mx "\"¡Shinichi!\""


translate english a5173_437945b5:


    xy "\"Es Yuutarou.\""


translate english a5173_de030945:


    xy "\"Probablemente llama por Aoi.\""


translate english a5173_182debe4:


    "Soy basura por usar a Aoi como excusa. Lo sé."


translate english a5173_5b7f2283:


    "Pero es la única opción que tengo."


translate english a5173_c5819b76:



    voice "voice/a51/7300460a01.opus"
    mx "\"¿Estás eligiendo una llamada... antes que a MÍ...?\""


translate english a5173_70783706:


    "Puedo oír un tono de súplica en su voz."


translate english a5173_f1c0844c:


    "Sus ojos están inundados de lágrimas..."


translate english a5173_95f0f796:


    "Pero aparto la mirada."


translate english a5173_7fbbdd4a:


    xy "\"¿Hola?\""


translate english a5173_2c1ad5f8:



    voice "voice/a51/7300470b01.opus"
    xtl "\"¡Shinichi, pedazo de basura! ¡¿En qué demonios pensabas, echando a Mukou a la calle en su estado?!\""


translate english a5173_a48ba9e3:



    voice "voice/a51/7300480b01.opus"
    xtl "\"¡Vino tambaleándose hasta aquí con un gatito en brazos!\""


translate english a5173_f17b0e76:


    xy "\"...Perdón.\""


translate english a5173_32e94202:



    voice "voice/a51/7300490b01.opus"
    xtl "\"Díselo a ella, no a mí. En fin, por ahora la voy a cuidar, ¿sí?\""


translate english a5173_06e8022c:


    xy "\"¿Lo harías?\""


translate english a5173_3be24ab1:



    voice "voice/a51/7300500b01.opus"
    xtl "\"Bueno, tienes las manos ocupadas, ¿no?\""


translate english a5173_2a1af6c4:


    xy "\"...De verdad te debo una.\""


translate english a5173_14874014:



    voice "voice/a51/7300510b01.opus"
    xtl "\"No hay problema. Nos vemos.\""


translate english a5173_dd116f34:


    "Cuelgo y miro alrededor de la habitación."


translate english a5173_64762b9e:


    "Pero Miyuki ya se ha ido."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
