

translate english a3124b_d08f6eda:


    "Intento moverme, pero estoy congelado en el sitio."


translate english a3124b_19d193f4:


    "¿Qué me pasa?"


translate english a3124b_9049c216:


    "¿Acaso..."


translate english a3124b_a4cfdaab:


    "¿De verdad creo en el Dios de Aoi...?"


translate english a3124b_e87b058f:


    "El timbre se corta..."


translate english a3124b_1c528244:


    "...y Dios contesta."


translate english a3124b_ad78853a:



    voice "voice/a31/24b00010a02.opus"
    aoi "\"Mi señal llegó.\""


translate english a3124b_eabfce2c:


    xy "\"¿Qu...?\""


translate english a3124b_ca5d5477:


    "Hay un desgarro en el tejido del espacio—"


translate english a3124b_eead4f24:


    "Se abre de la nada—"


translate english a3124b_f48c621c:


    "—y empieza a consumir—"


translate english a3124b_e055c39a:


    "Las sombras se desprenden—"


translate english a3124b_220c3145:


    "Los colores se desvanecen—"


translate english a3124b_b230478a:


    "Los bocetos se inclinan y se distorsionan—"


translate english a3124b_48027b4c:


    "Las líneas se desvanecen—"


translate english a3124b_4bf7fc07:


    "El mundo entero está—"


translate english a3124b_b129c319:


    "—empezando a fallar—!"


translate english a3124b_889bd7c6:



    voice "voice/a31/24b00020a02.opus"
    aoi "\"El juego fue recodificado para que tú y Miyuki puedan estar juntos.\""


translate english a3124b_949ff8fa:



    voice "voice/a31/24b00030a02.opus"
    aoi "\"Ahora nunca, jamás, te pondrán los cuernos.\""


translate english a3124b_e3cbc66c:



    voice "voice/a31/24b00040a02.opus"
    aoi "\"Ahora, el juego parcheado se sincronizará con el universo.\""


translate english a3124b_2753f6c6:



    voice "voice/a31/24b00050a02.opus"
    aoi "\"Entonces la actualización estará completa.\""


translate english a3124b_c902e46e:


    xy "\"Ya deja de decir tonterías...\""


translate english a3124b_66860f77:



    voice "voice/a31/24b00060a02.opus"
    aoi "\"Es la verdad.\""


translate english a3124b_21a0f576:



    voice "voice/a31/24b00070a02.opus"
    aoi "\"Este mundo es un videojuego.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
