

translate english a3124b_d08f6eda:


    "Intento moverme, pero estoy congelado en el sitio."


translate english a3124b_19d193f4:


    "¿Qué me pasa?"


translate english a3124b_9049c216:


    "¿Acaso..."


translate english a3124b_a4cfdaab:


    "¿De verdad creo en el Dios de Aoi...?"


translate english a3124b_e87b058f:


    "El timbre se corta..."


translate english a3124b_1c528244:


    "...y Dios contesta."


translate english a3124b_ad78853a:



    voice "voice/a31/24b00010a02.opus"
    aoi "\"My signal got through.\""


translate english a3124b_eabfce2c:


    xy "\"Wha—?!\""


translate english a3124b_ca5d5477:


    "Hay un desgarro en el tejido del espacio—"


translate english a3124b_eead4f24:


    "Se abre de la nada—"


translate english a3124b_f48c621c:


    "—y empieza a consumir—"


translate english a3124b_e055c39a:


    "Las sombras se desprenden—"


translate english a3124b_220c3145:


    "Los colores se desvanecen—"


translate english a3124b_b230478a:


    "Los bocetos se inclinan y se distorsionan—"


translate english a3124b_48027b4c:


    "Las líneas se desvanecen—"


translate english a3124b_4bf7fc07:


    "El mundo entero está—"


translate english a3124b_b129c319:


    "—empezando a fallar—!"


translate english a3124b_889bd7c6:



    voice "voice/a31/24b00020a02.opus"
    aoi "\"The game has been recoded so that you and Miyuki can be together.\""


translate english a3124b_949ff8fa:



    voice "voice/a31/24b00030a02.opus"
    aoi "\"Now you'll never, ever be cucked.\""


translate english a3124b_e3cbc66c:



    voice "voice/a31/24b00040a02.opus"
    aoi "\"Next, the patched game will be synced with the universe.\""


translate english a3124b_2753f6c6:



    voice "voice/a31/24b00050a02.opus"
    aoi "\"Then the update will be complete.\""


translate english a3124b_c902e46e:


    xy "\"Quit with that nonsense already...\""


translate english a3124b_66860f77:



    voice "voice/a31/24b00060a02.opus"
    aoi "\"It's the truth.\""


translate english a3124b_21a0f576:



    voice "voice/a31/24b00070a02.opus"
    aoi "\"This world is a video game.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
