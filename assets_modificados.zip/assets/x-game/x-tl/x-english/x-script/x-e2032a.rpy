

translate english e2032a_2fe370cb:


    xy "\"Yeah, I'll stay.\""


translate english e2032a_4170681c:


    "Asiento sin dudar."


translate english e2032a_15bdf97a:


    "Soy feliz viviendo aquí con Miyuki."


translate english e2032a_de826154:


    "Y espero que podamos seguir juntos así por mucho, mucho tiempo."


translate english e2032a_619755bd:


    "De hecho, no necesito nada más."


translate english e2032a_80b038a5:



    voice "voice/e20/32a00010a01.opus"
    mx "\"...Thanks.\""


translate english e2032a_cc61f676:


    xy "\"Miyuki...?!\""


translate english e2032a_0dc03a51:


    "Miro dos veces, incrédulo."


translate english e2032a_068f7674:


    "Los ojos de Miyuki están... llenos de lágrimas."


translate english e2032a_f7fa1227:


    xy "\"What's wrong?\""


translate english e2032a_2ef226e6:



    voice "voice/e20/32a00020a01.opus"
    mx "\"Nothing. I'm fine... I'm just...\""


translate english e2032a_765d6612:



    voice "voice/e20/32a00030a01.opus"
    mx "\"I'm the luckiest girl in the whole world.\""


translate english e2032a_b89bc07e:


    "Contrary to her words, she doesn't look \"fine\"en absoluto. Grandes lágrimas ruedan por sus mejillas."



translate english e2032a_6b8528bf:


    "...Nunca la había visto tan feliz en toda mi vida."


translate english e2032a_3d081812:


    xy "\"Miyuki.\""


translate english e2032a_ada5961c:



    voice "voice/e20/32a00040a01.opus"
    mx "\"Listen, um...\""


translate english e2032a_1bba9d19:



    voice "voice/e20/32a00050a01.opus"
    mx "\"I want to kiss YOU... Not just any kiss. An eternal kiss.\""


translate english e2032a_2b46ec5a:


    "Asiento en silencio..."


translate english e2032a_bbb0096a:


    "...y presiono mis labios contra los suyos."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
