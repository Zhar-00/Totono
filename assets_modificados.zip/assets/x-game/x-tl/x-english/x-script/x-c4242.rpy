

translate english c4242_48dcc6fb:


    "Una luz pálida brilla sobre nosotros desde los cielos, bendiciendo nuestra unión."


translate english c4242_e1955b76:


    "Nos acurrucamos y miramos al cielo."


translate english c4242_970777d7:


    "Puedo sentir su calor contra mi cuerpo."


translate english c4242_cbc3ba85:


    "Es tan pequeña y preciosa..."


translate english c4242_5eb1c05d:


    "Solo quiero abrazarla y protegerla siempre..."


translate english c4242_ade7156e:


    "Pero—"


translate english c4242_b46c963b:



    voice "voice/c42/4200010a02.opus"
    aoi "\"Boop boop...\""


translate english c4242_3b1af3b8:


    "Algo falta."


translate english c4242_97ef1526:


    "Puede que nos hayamos conectado físicamente, pero aún queda un largo camino por recorrer."


translate english c4242_4d40ef2b:


    "Su mirada es tan distante que casi me pregunto si está mirando algo al otro lado del universo."


translate english c4242_ab4803f0:


    xy "\"All that time I spent searching for you, I was thinking...\""


translate english c4242_c37e5a21:


    xy "\"I never knew the first thing about you.\""


translate english c4242_33a19f37:



    voice "voice/c42/4200020a02.opus"
    aoi "\"About me...?\""


translate english c4242_c9379f4f:


    xy "\"Your likes, your dislikes, things you think about, the video games you play...\""


translate english c4242_43c0d902:


    xy "\"And the God you believe in.\""


translate english c4242_b6a20d01:



    voice "voice/c42/4200030a02.opus"
    aoi "\"My God...\""


translate english c4242_ed936965:


    "Aoi vuelve a mirar el cielo."


translate english c4242_406b3383:


    "Su mirada vaga."


translate english c4242_00d68467:


    "Como si estuviera mirando un mundo que no puedo ver—un mundo más allá de las estrellas."


translate english c4242_fbf25595:


    xy "\"You'll tell me, won't you?\""


translate english c4242_803569da:



    voice "voice/c42/4200040a02.opus"
    aoi "\"Boop boop...\""


translate english c4242_6366e035:


    "Su voz es diminuta y débil... y no encuentra mi mirada."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
