

translate english a5162_d6cb0262:



    voice "voice/a51/6200020a02.opus"
    aoi "\"It's okay. Aoi can keep looking.\""


translate english a5162_85860b35:


    xy "\"But you're not feeling good, right? I think you should rest and—\""


translate english a5162_6367ad8a:



    voice "voice/a51/6200030a02.opus"
    aoi "\"It's okay. Aoi can keep looking.\""


translate english a5162_92afe47e:



    voice "voice/a51/6200040a02.opus"
    aoi "\"Aoi... has to keep looking...\""


translate english a5162_0accd139:


    xy "\"......\""


translate english a5162_cf270741:


    "Lo sabía. No se ha recuperado en absoluto."


translate english a5162_4dd0c9d7:


    "Pero también se niega a seguir mi consejo."


translate english a5162_594c3cdf:


    "Supongo que mi única opción es apurarme y encontrar su teléfono—"


translate english a5162_24e00c32:


    "Espera... ¿Teléfono...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
