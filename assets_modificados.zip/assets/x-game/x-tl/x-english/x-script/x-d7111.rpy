

translate english d7111_55879f65:


    "¿Qué demonios...?"


translate english d7111_c430d4fe:


    "¿Dónde estoy?"


translate english d7111_8da7d185:


    "¿Qué es este dolor que siento?"


translate english d7111_46141fed:


    "¿Desamor? ¿Angustia?"


translate english d7111_84453c40:


    "No..."


translate english d7111_c860c5ff:


    "Solo dolor normal. Dolor físico."


translate english d7111_c0964b30:


    "¿Dolor físico de dónde?"


translate english d7111_e638bf38:


    xy "\"¿¿Mi mano...??\""


translate english d7111_9ad6ffdd:


    "Mi mano está vendada."


translate english d7111_24ff061f:



    voice "voice/d71/1100010b01.opus"
    xtl "\"¿Cómo estás, Shinichi?\""


translate english d7111_ab85c70a:


    "Encuentro a Yuutarou sentado en una silla cerca."


translate english d7111_247d9fff:


    xy "\"¿¿Qué demo...?? ¿Qué hago aquí?\""


translate english d7111_a83fdd21:



    voice "voice/d71/1100020b01.opus"
    xtl "\"¿Hmm?\""


translate english d7111_dd5b8c80:


    xy "\"¿¿Y qué le pasó a mi mano??\""


translate english d7111_3fe8034c:


    xy "\"Lo último que recuerdo es que estaba en ese condominio elegante...\""


translate english d7111_0c3fc025:



    voice "voice/d71/1100030b01.opus"
    xtl "\"Oh. Debes haber perdido el conocimiento.\""


translate english d7111_293c71d7:


    xy "\"¿Qué? ¿¿Perdí el conocimiento??\""


translate english d7111_d93ea7f6:



    voice "voice/d71/1100040b01.opus"
    xtl "\"No es que te culpe, después de lo que pasó.\""


translate english d7111_7d4d9cd6:


    "Miro hacia abajo a mi mano."


translate english d7111_ffbf0019:


    "Mis nudillos están todos vendados."


translate english d7111_66529602:


    xy "\"...¿Qué hice?\""


translate english d7111_05757bd5:


    xy "\"¡Dios, ¿¿acaso—??\""


translate english d7111_3cf86fa4:



    voice "voice/d71/1100050b01.opus"
    xtl "\"No te preocupes.\""


translate english d7111_bf0d64a9:


    "Yuutarou niega ligeramente con la cabeza."


translate english d7111_0c58f8cf:



    voice "voice/d71/1100060b01.opus"
    xtl "\"Ryuujirou va a descansar del modelaje hasta que sanen sus lesiones. No es gran castigo, pero algo es algo.\""


translate english d7111_493ef3ee:


    "Entonces eso significa que yo..."


translate english d7111_db45e3b1:


    "Le di un puñetazo... y con suficiente fuerza para dañarme la mano también..."


translate english d7111_d5cabffe:


    "Eso debe ser lo que pasó."


translate english d7111_800ef7ec:


    "Miyuki tenía toda la razón sobre mí."


translate english d7111_b43f718d:


    "Soy mucho más un monstruo celoso de lo que jamás pensé posible."


translate english d7111_ba410692:


    xy "\"...¿Y Aoi?\""


translate english d7111_20a2d6dd:


    xy "\"¿Qué le hice?\""


translate english d7111_6dea6a5c:



    voice "voice/d71/1100070b01.opus"
    xtl "\"Nada.\""


translate english d7111_ca7fe3be:


    xy "\"¿Nada?\""


translate english d7111_091fad2b:



    voice "voice/d71/1100080b01.opus"
    xtl "\"Después de que atacaste a Ryuujirou, te agarré y te sujeté. Mientras tanto, ella solo estaba sentada en el rincón del cuarto.\""


translate english d7111_21121615:



    voice "voice/d71/1100090b01.opus"
    xtl "\"Tenía el teléfono en alto, murmurando para sí todo el tiempo.\""


translate english d7111_a33b0967:



    voice "voice/d71/1100100b01.opus"
    xtl "\"Algo sobre Dios, o archivos guardados, no sé.\""


translate english d7111_096b8934:



    voice "voice/d71/1100110b01.opus"
    xtl "\"Seguía repitiéndolo una y otra vez, como una plegaria.\""


translate english d7111_4fdb3d41:


    xy "\"...Ah.\""


translate english d7111_32257249:


    "Puedo imaginarla haciéndolo."


translate english d7111_49c8125b:


    "Sin embargo, dudo que su llamada haya entrado."


translate english d7111_ce0d2206:


    xy "\"¿Dónde está ahora?\""


translate english d7111_fe1d3a36:



    voice "voice/d71/1100120b01.opus"
    xtl "\"Pues...\""


translate english d7111_ae3f3d41:



    voice "voice/d71/1100130b01.opus"
    xtl "\"No sabemos.\""


translate english d7111_e820ee09:


    xy "\"¿No saben?\""


translate english d7111_5ebaedbb:



    voice "voice/d71/1100140b01.opus"
    xtl "\"Lo siguiente que supimos fue que simplemente... se había ido.\""


translate english d7111_0752d64d:



    voice "voice/d71/1100150b01.opus"
    xtl "\"Casi como si se hubiera desvanecido en el aire.\""


translate english d7111_fa39fbb7:


    "Los seres humanos no se desvanecen en el aire."


translate english d7111_01ac69fd:


    "Lo sé."


translate english d7111_0634f20e:


    "Pero parte de mí se pregunta si..."


translate english d7111_d1f07cfe:


    "...quizás Aoi es una excepción especial."


translate english d7111_de06b277:


    "Además..."


translate english d7111_38eb3038:



    voice "voice/d71/1100160b01.opus"
    xtl "\"¿Quieres ir a buscarla?\""


translate english d7111_eab47e37:


    xy "\"No, gracias.\""


translate english d7111_e70a43fa:


    "No quiero verla de nuevo. No después de eso."


translate english d7111_9ea963b6:



    voice "voice/d71/1100170b01.opus"
    xtl "\"Bien. Parece que has vuelto en ti, así que me voy.\""


translate english d7111_371e0631:


    xy "\"Perdón por todas las molestias.\""


translate english d7111_9e639889:



    voice "voice/d71/1100180b01.opus"
    xtl "\"Si alguien debería disculparse, soy yo, amigo...\""


translate english d7111_fb8d0977:


    xy "\"No, no es tu culpa.\""


translate english d7111_26e52133:


    xy "\"En serio, no te culpes por esto.\""


translate english d7111_77cd5a57:



    voice "voice/d71/1100190b01.opus"
    xtl "\"...Bien.\""


translate english d7111_09389294:



    voice "voice/d71/1100200b01.opus"
    xtl "\"Nos vemos.\""


translate english d7111_b5e845f7:


    xy "\"Al rato.\""


translate english d7111_92fab389:


    "Yuutarou me saluda con la mano y se marcha."


translate english d7111_b73ab6f6:


    "Me quedo solo en el cuarto."


translate english d7111_067d18c6:


    "Me derrumbo de vuelta en la cama y miro por la ventana."


translate english d7111_b1a1b3ae:


    "La luna cuelga sobre el oscuro lienzo del cielo nocturno."


translate english d7111_681746b3:


    "Al final, Aoi y yo estábamos viviendo en dos mundos diferentes."


translate english d7111_40acdc0f:


    "Quería ser su nuevo Dios, pero no pude."


translate english d7111_7a260f79:


    xy "\"...Ah, sí.\""


translate english d7111_767216f4:


    "¿Alguien se acordó de alimentar a Eru?"


translate english d7111_b7bdba7b:


    "Salgo de la cama y dejo el cuarto."


translate english d7111_95150941:


    xy "\"¿Hmm?\""



translate english d7111_be5c38a6:


    "Las luces están encendidas en la sala de estar."


translate english d7111_c57879e8:


    "Me siento atraído hacia dentro."


translate english d7111_a2d4a029:


    xy "\"¿Miyuki? No sabía que estabas aquí.\""


translate english d7111_296ab2a9:



    voice "voice/d71/1100210a01.opus"
    mx "\"¿Me dicen que ya estás más calmado?\""


translate english d7111_5fce5c59:


    xy "\"Sí. Perdón por todo el lío de allá.\""


translate english d7111_dd4a4f91:



    voice "voice/d71/1100220a01.opus"
    mx "\"Por favor. ¿Para qué están los viejos amigos? Con gusto te cuido de vez en cuando.\""


translate english d7111_20656a28:


    "Sus amables palabras son el lado positivo de mi nube de lluvia ahora mismo."


translate english d7111_eb2ca58c:


    xy "\"¿Dónde está Eru?\""


translate english d7111_b4ae931a:



    voice "voice/d71/1100230a01.opus"
    mx "\"Intenté darle leche, pero me arañó y salió corriendo.\""


translate english d7111_62c69fc9:


    xy "\"¡¿Te arañó?! ¿Estás bien?\""


translate english d7111_64d58c62:



    voice "voice/d71/1100240a01.opus"
    mx "\"Está bien. Probablemente no deje marca.\""


translate english d7111_9e013865:


    "Me muestra su palma. En efecto, puedo ver marcas profundas de garras."


translate english d7111_af3e8db9:


    xy "\"Qué raro... Normalmente es un gato tan bueno.\""


translate english d7111_25d3215a:



    voice "voice/d71/1100250a01.opus"
    mx "\"Quizá ya no le gusto.\""


translate english d7111_b80a8b6b:



    voice "voice/d71/1100260a01.opus"
    mx "\"...Lástima. De verdad quería a esa bolita de pelo.\""


translate english d7111_ce9f6f4c:


    "Sus palabras susurradas resuenan dentro de mi pecho."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
