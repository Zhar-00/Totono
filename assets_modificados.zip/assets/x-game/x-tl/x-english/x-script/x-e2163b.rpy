

translate english e2163b_5e0c4c97:


    "Está ahí, solo, todo solitario..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
