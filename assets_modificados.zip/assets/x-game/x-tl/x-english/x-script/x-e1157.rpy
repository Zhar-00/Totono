

translate english e1157_2a88a329:


    xy "\"......Wait, what the?\""


translate english e1157_c1d02193:


    "Mis zapatos no están."


translate english e1157_90722672:


    "Rebusco apresuradamente entre las cajas de zapatos del armario y al final los encuentro, hasta el fondo."


translate english e1157_380acacb:


    "No puedo creer que Miyuki se haya molestado en guardarlos hasta el fondo..."


translate english e1157_522b63f6:


    "Como siempre, es una maniática del orden..."


translate english e1157_1edf7367:


    "Bien, ya estoy afuera."


translate english e1157_7eb24463:


    "Pero, ¿adónde voy desde aquí?"


translate english e1157_46131a01:


    "No tengo un destino fijo en mente—"


translate english e1157_7fb7fc89:



    voice "voice/e11/5700010b01.opus"
    xtl "\"...Shinichi?\""


translate english e1157_f30a1252:



    voice "voice/e11/5700020b01.opus"
    xtl "\"H-Hey! Is that you?! It is!\""


translate english e1157_b4cbaf12:


    xy "\"Oh, hey, Yuutarou! Perfect timing!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
