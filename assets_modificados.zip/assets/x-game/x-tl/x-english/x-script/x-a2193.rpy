

translate english a2193_ef81abde:


    xy "\"Y ahora es momento del segundo regalo.\""


translate english a2193_11cf1bc1:


    "Saco un segundo paquete que contiene el otro pasador."


translate english a2193_36aa6535:



    voice "voice/a21/9300010a01.opus"
    mx "\"Ay, dios, no lo hiciste...\""


translate english a2193_bc1600fa:



    voice "voice/a21/9300020a02.opus"
    aoi "\"¿Le hiciste un glitch a tu set de movimientos?\""


translate english a2193_ebbcddc5:



    voice "voice/a21/9300030a01.opus"
    mx "\"¿Compraste LOS DOS?\""


translate english a2193_3617478b:


    "Qué suerte que tenían dos..."


translate english a2193_18631119:


    xy "\"Pasadores a juego para ti y tu mejor amiga.\""


translate english a2193_dea732d5:


    xy "\"Lo vas a aceptar, ¿verdad?\""


translate english a2193_f564ff49:



    voice "voice/a21/9300040a02.opus"
    aoi "\"Por favor, Miyuki...\""


translate english a2193_35c572e1:



    voice "voice/a21/9300050a01.opus"
    mx "\"...Haah...\""


translate english a2193_d3d7fa70:


    "Miyuki suspira derrotada."


translate english a2193_4053bea9:



    voice "voice/a21/9300060a01.opus"
    mx "\"Shinichi, acabas de gastarte todo tu presupuesto de comida, ¿verdad?\""


translate english a2193_9ca5ba43:


    xy "\"...¿Era tan obvio?\""


translate english a2193_0a2b43eb:



    voice "voice/a21/9300070a01.opus"
    mx "\"A partir de mañana, voy a preparar almuerzos para los dos. Eso debería alcanzarte por un tiempo.\""


translate english a2193_6b8eeb4c:


    xy "\"¿En serio? ¡Me salvas la vida!\""


translate english a2193_0c928dd3:



    voice "voice/a21/9300080a02.opus"
    aoi "\"Hechos con el amor de Miyuki.\""


translate english a2193_761dee77:



    voice "voice/a21/9300090a01.opus"
    mx "\"Ugh, ¡cállate! ¡Dios!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
