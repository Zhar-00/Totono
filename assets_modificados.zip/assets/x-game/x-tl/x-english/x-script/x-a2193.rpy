

translate english a2193_ef81abde:


    xy "\"And now it's time for the second gift.\""


translate english a2193_11cf1bc1:


    "Saco un segundo paquete que contiene el otro pasador."


translate english a2193_36aa6535:



    voice "voice/a21/9300010a01.opus"
    mx "\"Oh my god, you didn't...\""


translate english a2193_bc1600fa:



    voice "voice/a21/9300020a02.opus"
    aoi "\"Did you glitch your moveset?\""


translate english a2193_ebbcddc5:



    voice "voice/a21/9300030a01.opus"
    mx "\"You bought BOTH of them?\""


translate english a2193_3617478b:


    "Qué suerte que tenían dos..."


translate english a2193_18631119:


    xy "\"Matching hairpins for you and your bestie.\""


translate english a2193_dea732d5:


    xy "\"You'll take it, won't you?\""


translate english a2193_f564ff49:



    voice "voice/a21/9300040a02.opus"
    aoi "\"Please, Miyuki...\""


translate english a2193_35c572e1:



    voice "voice/a21/9300050a01.opus"
    mx "\"...Haah...\""


translate english a2193_d3d7fa70:


    "Miyuki suspira derrotada."


translate english a2193_4053bea9:



    voice "voice/a21/9300060a01.opus"
    mx "\"Shinichi, you just spent your entire food budget, didn't you?\""


translate english a2193_9ca5ba43:


    xy "\"...Was it that obvious?\""


translate english a2193_0a2b43eb:



    voice "voice/a21/9300070a01.opus"
    mx "\"Starting tomorrow, I'll make lunches for the both of us. That should tide you over for a while.\""


translate english a2193_6b8eeb4c:


    xy "\"For real?! You're a lifesaver!\""


translate english a2193_0c928dd3:



    voice "voice/a21/9300080a02.opus"
    aoi "\"Made with Miyuki's love.\""


translate english a2193_761dee77:



    voice "voice/a21/9300090a01.opus"
    mx "\"Ugh, shut up! God!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
