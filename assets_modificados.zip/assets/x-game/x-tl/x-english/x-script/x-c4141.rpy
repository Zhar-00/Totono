

translate english c4141_640e46ca:


    "El sol empezó a ponerse."


translate english c4141_f521ce1e:



    voice "voice/c41/4100010a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c4141_f3dddc5f:



    voice "voice/c41/4100020a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c4141_a944d017:


    xy "\"Uh, Aoi?\""


translate english c4141_764cb4f6:


    xy "\"Hey! Aoi!\""


translate english c4141_76dffb52:



    voice "voice/c41/4100030a02.opus"
    aoi "\"Boop boop?\""


translate english c4141_2678f7a5:


    xy "\"Are you still having trouble getting any signal?\""


translate english c4141_9648fea7:



    voice "voice/c41/4100040a02.opus"
    aoi "\"...Uh huh. It just won't go through no matter what.\""


translate english c4141_3cc043a7:


    "Aoi didn't show up to her afternoon classes. Instead, she stayed on the roof and has been calling \"God\"desde el almuerzo."


translate english c4141_45aca7e0:


    xy "\"I'm gonna head home now. What about you?\""


translate english c4141_4563f4fd:



    voice "voice/c41/4100050a02.opus"
    aoi "\"Gonna stay here and try for a little longer.\""


translate english c4141_444a0765:



    voice "voice/c41/4100060a02.opus"
    aoi "\"Aoi needs an update patch. A bugfix patch.\""


translate english c4141_636fee17:



    voice "voice/c41/4100070a02.opus"
    aoi "\"It's important.\""


translate english c4141_8bb5ae94:


    xy "\"Look, I think you should call it a day.\""


translate english c4141_3adea2e7:


    xy "\"See? Eru's hungry.\""


translate english c4141_50eedae9:



    voice "voice/c41/4100090a02.opus"
    aoi "\"Shinichi...\""



translate english c4141_69d18865:



    voice "voice/c41/4100100a02.opus"
    aoi "\"Can you take care of Eru for me?\""


translate english c4141_337b1fb9:


    xy "\"I mean, sure, I don't mind...\""


translate english c4141_147cbc56:


    "No hicimos planes para que se quedara a dormir esta noche."


translate english c4141_8bf8b2ed:


    "Lo que significa que voy a estar cuidando a Eru yo solo de todos modos."


translate english c4141_54667fa6:


    "Me agacho y recojo al gatito."


translate english c4141_abb87e6e:


    xy "\"...Just don't overwork yourself, alright?\""


translate english c4141_f036c324:



    voice "voice/c41/4100110a02.opus"
    aoi "\"Aoi will be fine.\""


translate english c4141_3ba0714f:



    voice "voice/c41/4100120a02.opus"
    aoi "\"Just gotta patch out my bugs.\""


translate english c4141_3696b643:



    voice "voice/c41/4100130a02.opus"
    aoi "\"After all, Aoi...\""


translate english c4141_8d3b191c:



    voice "voice/c41/4100140a02.opus"
    aoi "\"Aoi will never be anything more than a friend to you.\""


translate english c4141_3a1c551f:


    "Espera..."


translate english c4141_d2b8762b:


    "Eso es exactamente lo mismo que dije antes..."


translate english c4141_80263628:


    "¿Acaso me escuchó después de todo...?"


translate english c4141_53e70f1d:



    voice "voice/c41/4100150a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c4141_6426495e:


    "Before I can ask her about it, Aoi starts \"dialing\"otra vez."


translate english c4141_03db4b8e:


    "Con el teléfono en mano, mira hacia el pueblo..."


translate english c4141_664b4078:


    "Transmitiendo a un dios más allá de los confines de nuestro mundo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
