

translate english c4141_640e46ca:


    "El sol empezó a ponerse."


translate english c4141_f521ce1e:



    voice "voice/c41/4100010a02.opus"
    aoi "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english c4141_f3dddc5f:



    voice "voice/c41/4100020a02.opus"
    aoi "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english c4141_a944d017:


    xy "\"Eh, ¿Aoi?\""


translate english c4141_764cb4f6:


    xy "\"¡Oye! ¡Aoi!\""


translate english c4141_76dffb52:



    voice "voice/c41/4100030a02.opus"
    aoi "\"¿Bip bip?\""


translate english c4141_2678f7a5:


    xy "\"¿Todavía tienes problemas para recibir señal?\""


translate english c4141_9648fea7:



    voice "voice/c41/4100040a02.opus"
    aoi "\"...Ajá. Simplemente no entra por más que intento.\""


translate english c4141_3cc043a7:


    "Aoi didn't show up to her afternoon classes. Instead, she stayed on the roof and has been calling \"God\"desde el almuerzo."


translate english c4141_45aca7e0:


    xy "\"Me voy a ir a casa ahora. ¿Y tú?\""


translate english c4141_4563f4fd:



    voice "voice/c41/4100050a02.opus"
    aoi "\"Me quedaré aquí e intentaré un poco más.\""


translate english c4141_444a0765:



    voice "voice/c41/4100060a02.opus"
    aoi "\"Aoi necesita un parche de actualización. Un parche de corrección de errores.\""


translate english c4141_636fee17:



    voice "voice/c41/4100070a02.opus"
    aoi "\"Es importante.\""


translate english c4141_8bb5ae94:


    xy "\"Mira, creo que deberías darlo por terminado por hoy.\""


translate english c4141_3adea2e7:


    xy "\"¿Ves? Eru tiene hambre.\""


translate english c4141_50eedae9:



    voice "voice/c41/4100090a02.opus"
    aoi "\"Shinichi...\""



translate english c4141_69d18865:



    voice "voice/c41/4100100a02.opus"
    aoi "\"¿Puedes cuidar de Eru por mí?\""


translate english c4141_337b1fb9:


    xy "\"O sea, claro, no me importa...\""


translate english c4141_147cbc56:


    "No hicimos planes para que se quedara a dormir esta noche."


translate english c4141_8bf8b2ed:


    "Lo que significa que voy a estar cuidando a Eru yo solo de todos modos."


translate english c4141_54667fa6:


    "Me agacho y recojo al gatito."


translate english c4141_abb87e6e:


    xy "\"...Solo no te sobrecargues, ¿sí?\""


translate english c4141_f036c324:



    voice "voice/c41/4100110a02.opus"
    aoi "\"Aoi estará bien.\""


translate english c4141_3ba0714f:



    voice "voice/c41/4100120a02.opus"
    aoi "\"Solo tengo que parchar mis errores.\""


translate english c4141_3696b643:



    voice "voice/c41/4100130a02.opus"
    aoi "\"Después de todo, Aoi...\""


translate english c4141_8d3b191c:



    voice "voice/c41/4100140a02.opus"
    aoi "\"Aoi nunca será nada más que una amiga para ti.\""


translate english c4141_3a1c551f:


    "Espera..."


translate english c4141_d2b8762b:


    "Eso es exactamente lo mismo que dije antes..."


translate english c4141_80263628:


    "¿Acaso me escuchó después de todo...?"


translate english c4141_53e70f1d:



    voice "voice/c41/4100150a02.opus"
    aoi "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english c4141_6426495e:


    "Before I can ask her about it, Aoi starts \"dialing\"otra vez."


translate english c4141_03db4b8e:


    "Con el teléfono en mano, mira hacia el pueblo..."


translate english c4141_664b4078:


    "Transmitiendo a un dios más allá de los confines de nuestro mundo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
