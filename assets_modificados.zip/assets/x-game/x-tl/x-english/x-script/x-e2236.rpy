

translate english e2236_9b2c7eb9:



    voice "voice/e22/3600010a01.opus"
    mx "\"So. Let's do it.\""


translate english e2236_a1e6e4b5:


    "Sonríe con picardía, con el rostro sonrojado."


translate english e2236_60cbb1ca:


    xy "\"Do it, as in... right here, right now?\""


translate english e2236_20f47d86:



    voice "voice/e22/3600020a01.opus"
    mx "\"Right here, right now.\""


translate english e2236_9801497b:



    voice "voice/e22/3600030a01.opus"
    mx "\"Or... do you not want to?\""


translate english strings:


    old "Я хочу"
    new "Quiero"


    old "Я не хочу"
    new "No quiero"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
