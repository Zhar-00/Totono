

translate english e2236_9b2c7eb9:



    voice "voice/e22/3600010a01.opus"
    mx "\"Entonces. Hagámoslo.\""


translate english e2236_a1e6e4b5:


    "Sonríe con picardía, con el rostro sonrojado."


translate english e2236_60cbb1ca:


    xy "\"¿Hacerlo, o sea... aquí y ahora?\""


translate english e2236_20f47d86:



    voice "voice/e22/3600020a01.opus"
    mx "\"Aquí y ahora.\""


translate english e2236_9801497b:



    voice "voice/e22/3600030a01.opus"
    mx "\"¿O... no quieres?\""


translate english strings:


    old "Я хочу"
    new "Quiero"


    old "Я не хочу"
    new "No quiero"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
