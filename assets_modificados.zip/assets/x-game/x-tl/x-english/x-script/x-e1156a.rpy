

translate english e1156a_b8913613:


    "Después de todas esas locuras que dijo, estoy preocupado por Miyuki."


translate english e1156a_cacf4ab0:


    "Y así la sigo fuera de la casa—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
