

translate english c7143_676690eb:



    voice "voice/c71/4300010a01.opus"
    mx "\"TÚ... me traicionaste.\""


translate english c7143_7e6dce7f:



    voice "voice/c71/4300020a01.opus"
    mx "\"Y ahora... voy a tomar mi venganza.\""


translate english c7143_cc61f676:


    xy "\"¿Miyuki...?\""



translate english c7143_2818cda4:


    "Coloca suavemente la punta de su bate..."


translate english c7143_a17c9490:


    "...justo sobre mi escroto."


translate english c7143_3b01e9dc:


    "Siento que me estremezco."


translate english c7143_88056cd8:



    voice "voice/c71/4300030a01.opus"
    mx "\"Sé que eres solo un personaje autoproyectado.\""


translate english c7143_7948b66c:



    voice "voice/c71/4300040a01.opus"
    mx "\"Pero mi corazón no está de acuerdo.\""


translate english c7143_2526e8f6:



    voice "voice/c71/4300050a01.opus"
    mx "\"Así que... esto es un adiós.\""


translate english c7143_f54eea58:


    xy "\"¡E-Espera...! ¡Por favor, espera!\""


translate english c7143_a13ba97a:



    voice "voice/c71/4300060a01.opus"
    mx "\"Está bien. Puedes simplemente empezar de nuevo.\""


translate english c7143_47314cf7:


    "Miyuki me mira, casi aburrida."


translate english c7143_0f3b6256:



    voice "voice/c71/4300070a01.opus"
    mx "\"Hora de parchear esos bugs, ¿mm?\""


translate english c7143_9c59f675:


    xy "\"¡Miyuki! ¡Basta—\""


translate english c7143_3d2706e9:



    voice "voice/c71/4300080a01.opus"
    mx "¿Hola? ¿Dios?"



translate english c7143_4a397457:



    voice "voice/c71/4300090a01.opus"
    mx "Guarda mis recuerdos. Es la hora del espectáculo."



translate english c7143_ef8e4d9e:



    voice "voice/c71/4300100a01.opus"
    mx "Usa mi parche de mod..."



translate english c7143_2bb546a1:



    voice "voice/c71/4300110a01.opus"
    mx "...and push an update for [[YOU and ME and HER]."



translate english c7143_c3ea8475:



    voice "voice/c71/4300120a01.opus"
    mx "FeLIZ CuMPLeaÑoS"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
