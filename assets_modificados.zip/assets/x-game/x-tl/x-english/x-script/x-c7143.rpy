

translate english c7143_676690eb:



    voice "voice/c71/4300010a01.opus"
    mx "\"YOU... betrayed me.\""


translate english c7143_7e6dce7f:



    voice "voice/c71/4300020a01.opus"
    mx "\"And now... I'm going to have my revenge.\""


translate english c7143_cc61f676:


    xy "\"Miyuki...?\""



translate english c7143_2818cda4:


    "Coloca suavemente la punta de su bate..."


translate english c7143_a17c9490:


    "...justo sobre mi escroto."


translate english c7143_3b01e9dc:


    "Siento que me estremezco."


translate english c7143_88056cd8:



    voice "voice/c71/4300030a01.opus"
    mx "\"I know you're just a self-insert character.\""


translate english c7143_7948b66c:



    voice "voice/c71/4300040a01.opus"
    mx "\"But my heart disagrees.\""


translate english c7143_2526e8f6:



    voice "voice/c71/4300050a01.opus"
    mx "\"So... this is goodbye.\""


translate english c7143_f54eea58:


    xy "\"W-Wait... Please wait!\""


translate english c7143_a13ba97a:



    voice "voice/c71/4300060a01.opus"
    mx "\"It's okay. You can just start over.\""


translate english c7143_47314cf7:


    "Miyuki me mira, casi aburrida."


translate english c7143_0f3b6256:



    voice "voice/c71/4300070a01.opus"
    mx "\"Time to patch out those bugs, hmm?\""


translate english c7143_9c59f675:


    xy "\"Miyuki! Sto—\""


translate english c7143_3d2706e9:



    voice "voice/c71/4300080a01.opus"
    mx "¿Hola? ¿Dios?"



translate english c7143_4a397457:



    voice "voice/c71/4300090a01.opus"
    mx "Guarda mis recuerdos. Es la hora del espectáculo."



translate english c7143_ef8e4d9e:



    voice "voice/c71/4300100a01.opus"
    mx "Usa mi parche de mod..."



translate english c7143_2bb546a1:



    voice "voice/c71/4300110a01.opus"
    mx "...and push an update for [[YOU and ME and HER]."



translate english c7143_c3ea8475:



    voice "voice/c71/4300120a01.opus"
    mx "FeLIZ CuMPLeaÑoS"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
