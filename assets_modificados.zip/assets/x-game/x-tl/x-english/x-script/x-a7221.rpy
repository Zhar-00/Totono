

translate english a7221_7b3e7797:


    "Nos sentamos lado a lado en el sofá, apoyados el uno en el otro, comiendo nuestro pastel."


translate english a7221_5bb2d8bd:



    voice "voice/a72/2100010a01.opus"
    mx "\"Thank you.\""


translate english a7221_c5bedb85:


    xy "\"No, thank you.\""


translate english a7221_e32a6ee1:



    voice "voice/a72/2100020a01.opus"
    mx "\"I'll remember this day for the rest of my life.\""


translate english a7221_97aa6add:



    voice "voice/a72/2100030a01.opus"
    mx "\"And the rest of my next life, too, if there is one.\""


translate english a7221_c55c1cd5:



    voice "voice/a72/2100040a01.opus"
    mx "\"I swear, I'll never, EVER forget.\""


translate english a7221_5ea4d4da:


    xy "\"Okay, now you're just exaggerating.\""


translate english a7221_75a65bd6:



    voice "voice/a72/2100050a01.opus"
    mx "\"No I'm not!\""


translate english a7221_543aac94:


    "Miyuki hace un puchero."


translate english a7221_26dbd250:



    voice "voice/a72/2100060a01.opus"
    mx "\"I mean, you... you took my virginity...!\""


translate english a7221_e95815e0:



    voice "voice/a72/2100070a01.opus"
    mx "\"Obviously I could never forget my first!\""


translate english a7221_e73699b7:



    voice "voice/a72/2100080a01.opus"
    mx "\"So now, every year on your birthday, I'll always be reminded of our first time together.\""


translate english a7221_4a451431:


    xy "\"Hmm... I see.\""


translate english a7221_772cc8e5:



    voice "voice/a72/2100090a01.opus"
    mx "\"Is that a problem?\""


translate english a7221_5af2a1b7:


    xy "\"Not at all.\""


translate english a7221_429ccec0:



    voice "voice/a72/2100100a01.opus"
    mx "\"Good. Thanks.\""


translate english a7221_b7a6250b:



    voice "voice/a72/2100110a01.opus"
    mx "\"I'm not letting you go, mister.\""


translate english a7221_11c8f082:


    "Sus palabras me hacen sonreír a pesar de mí."


translate english a7221_9a0e70ad:


    "En este momento, soy el hombre más feliz del mundo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
