

translate english a7221_7b3e7797:


    "Nos sentamos lado a lado en el sofá, apoyados el uno en el otro, comiendo nuestro pastel."


translate english a7221_5bb2d8bd:



    voice "voice/a72/2100010a01.opus"
    mx "\"Gracias.\""


translate english a7221_c5bedb85:


    xy "\"No, gracias a ti.\""


translate english a7221_e32a6ee1:



    voice "voice/a72/2100020a01.opus"
    mx "\"Recordaré este día el resto de mi vida.\""


translate english a7221_97aa6add:



    voice "voice/a72/2100030a01.opus"
    mx "\"Y el resto de mi próxima vida también, si hay alguna.\""


translate english a7221_c55c1cd5:



    voice "voice/a72/2100040a01.opus"
    mx "\"Lo juro, jamás, JAMÁS lo olvidaré.\""


translate english a7221_5ea4d4da:


    xy "\"Okay, ahora sí estás exagerando.\""


translate english a7221_75a65bd6:



    voice "voice/a72/2100050a01.opus"
    mx "\"¡No es cierto!\""


translate english a7221_543aac94:


    "Miyuki hace un puchero."


translate english a7221_26dbd250:



    voice "voice/a72/2100060a01.opus"
    mx "\"O sea, ¡tú... me quitaste la virginidad...!\""


translate english a7221_e95815e0:



    voice "voice/a72/2100070a01.opus"
    mx "\"¡Obviamente nunca podría olvidar mi primera vez!\""


translate english a7221_e73699b7:



    voice "voice/a72/2100080a01.opus"
    mx "\"Así que ahora, cada año en tu cumpleaños, siempre me acordaré de nuestra primera vez juntos.\""


translate english a7221_4a451431:


    xy "\"Hmm... Ya veo.\""


translate english a7221_772cc8e5:



    voice "voice/a72/2100090a01.opus"
    mx "\"¿Eso es un problema?\""


translate english a7221_5af2a1b7:


    xy "\"Para nada.\""


translate english a7221_429ccec0:



    voice "voice/a72/2100100a01.opus"
    mx "\"Bien. Gracias.\""


translate english a7221_b7a6250b:



    voice "voice/a72/2100110a01.opus"
    mx "\"No te voy a soltar, señor.\""


translate english a7221_11c8f082:


    "Sus palabras me hacen sonreír a pesar de mí."


translate english a7221_9a0e70ad:


    "En este momento, soy el hombre más feliz del mundo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
