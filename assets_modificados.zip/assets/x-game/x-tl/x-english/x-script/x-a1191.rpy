

translate english a1191_75b02c15:



    voice "voice/a11/9100010a02.opus"
    aoi "\"Buenos días, Miyuki.\""


translate english a1191_088d87d1:



    voice "voice/a11/9100020a02.opus"
    aoi "\"Hoy es otro día ventoso.\""


translate english a1191_dc88bb66:



    voice "voice/a11/9100030a02.opus"
    aoi "\"Miyuki, ¿quieres ver mi almuerzo?\""


translate english a1191_3d8b80f7:



    voice "voice/a11/9100040a02.opus"
    aoi "\"Estos dulces te ponen la lengua de colores raros.\""


translate english a1191_16a48c1e:



    voice "voice/a11/9100050a02.opus"
    aoi "\"Miyuki, ¿quieres jugar este juego conmigo?\""


translate english a1191_7ca597e7:



    voice "voice/a11/9100060a02.opus"
    aoi "\"Miyuki, ¿quieres limpiar junt—?\""


translate english a1191_ca866e66:



    voice "voice/a11/9100070a02.opus"
    aoi "\"Miyuki, ¿quieres caminar a casa jun—?\""


translate english a1191_a1d05740:



    voice "voice/a11/9100080a02.opus"
    aoi "\"¡Miyuki, espera—!\""


translate english a1191_3cf9fde0:



    voice "voice/a11/9100090a02.opus"
    aoi "\"¡Miyuki—!\""


translate english a1191_6bbeb385:



    voice "voice/a11/9100100a02.opus"
    aoi "\"Miyuki...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
