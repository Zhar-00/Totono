

translate english e1167a_bff481f3:


    "Estaba seguro de haber marcado el número correcto..."


translate english e1167a_37df4649:


    "...pero la llamada no se conecta."


translate english e1167a_27e1bf5b:


    "Aoi no va a volver."


translate english e1167a_d55cff57:


    "Y sin embargo—"


translate english e1167a_2513c9e2:


    xy "\"Why...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
