

translate english b3223_4db5f423:



    voice "voice/b32/2300010a02.opus"
    aoi "\"Este mundo SÍ es un videojuego.\""


translate english b3223_f6366c95:



    voice "voice/b32/2300020a02.opus"
    aoi "\"Y Aoi puede pedirle a Dios que haga un parche de actualización.\""


translate english b3223_371236dc:



    voice "voice/b32/2300030a02.opus"
    aoi "\"Eso resolverá tus problemas.\""


translate english b3223_e575eed0:



    voice "voice/b32/2300040a02.opus"
    aoi "\"O al menos... se suponía que así sería...\""


translate english b3223_22e977c2:



    voice "voice/b32/2300050a02.opus"
    aoi "\"Pero mi teléfono no tiene señal... No conecta.\""


translate english b3223_58b8f054:



    voice "voice/b32/2300060a02.opus"
    aoi "\"...Perdón...\""


translate english b3223_08335dca:


    xy "\"Vamos, no te disculpes.\""


translate english b3223_1aa37c1e:


    xy "\"Resolveré algo, con o sin Dios.\""


translate english b3223_5c4441c6:



    voice "voice/b32/2300070a02.opus"
    aoi "\"No puedes simplemente \"resolver algo\".\""


translate english b3223_df30b33e:



    voice "voice/b32/2300080a02.opus"
    aoi "\"Vas a ser el príncipe de Miyuki.\""


translate english b3223_322d7af9:


    "No puedo creer lo que oigo."


translate english b3223_1168a36c:


    "Of all the words that could be used to describe me, \"prince\"no es una de ellas."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
