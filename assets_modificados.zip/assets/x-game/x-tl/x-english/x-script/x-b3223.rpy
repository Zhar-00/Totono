

translate english b3223_4db5f423:



    voice "voice/b32/2300010a02.opus"
    aoi "\"This world IS a video game.\""


translate english b3223_f6366c95:



    voice "voice/b32/2300020a02.opus"
    aoi "\"And Aoi can ask God to make an update patch.\""


translate english b3223_371236dc:



    voice "voice/b32/2300030a02.opus"
    aoi "\"That'll solve your problems.\""


translate english b3223_e575eed0:



    voice "voice/b32/2300040a02.opus"
    aoi "\"Or at least... that's how it was supposed to be...\""


translate english b3223_22e977c2:



    voice "voice/b32/2300050a02.opus"
    aoi "\"But my phone has no service... It won't connect.\""


translate english b3223_58b8f054:



    voice "voice/b32/2300060a02.opus"
    aoi "\"...Sorry...\""


translate english b3223_08335dca:


    xy "\"C'mon, don't apologize.\""


translate english b3223_1aa37c1e:


    xy "\"I'll figure something out, with or without God.\""


translate english b3223_5c4441c6:



    voice "voice/b32/2300070a02.opus"
    aoi "\"You can't just 'figure something out'.\""


translate english b3223_df30b33e:



    voice "voice/b32/2300080a02.opus"
    aoi "\"You're going to be Miyuki's prince.\""


translate english b3223_322d7af9:


    "No puedo creer lo que oigo."


translate english b3223_1168a36c:


    "Of all the words that could be used to describe me, \"prince\"no es una de ellas."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
