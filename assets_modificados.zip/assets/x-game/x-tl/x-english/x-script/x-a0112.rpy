

translate english a0112_787d4cf3:


    xy "\"¿Hmm?\""


translate english a0112_af76426d:


    "Miro hacia abajo."


translate english a0112_aa94e8c7:


    "Hay un celular tirado boca abajo en el suelo, junto a la puerta."


translate english a0112_bf09c9d9:


    "¿De quién será?"


translate english a0112_98a7710a:


    "Me agacho y lo recojo."


translate english a0112_0accd139:


    xy "\"......\""


translate english a0112_e09f3ed1:


    "Hay una llamada entrante de \"God.\""


translate english a0112_93351add:


    "...¿¿¿De Dios???"


translate english a0112_393bacc4:


    "Antes de que pueda contestar, el timbre se detiene."


translate english a0112_dd9c1890:


    "La verdad, me siento algo aliviado."


translate english a0112_322e8b39:


    "En serio, ¿de quién es este teléfono?"


translate english strings:


    old "Позвонить по телефону"
    new "Hacer una llamada"


    old "Проверить историю вызовов"
    new "Revisar el historial de llamadas"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
