

translate english a6151_d5a489d9:


    "Me meto bajo las cobijas y cierro los ojos."


translate english a6151_7e91b4c3:


    "En mis sueños, es la noche del estreno."


translate english a6151_d96b1d4e:


    "Miyuki besa a su amado entre aplausos estruendosos."


translate english a6151_eb40d2fc:


    "Besa a alguien que no soy yo."


translate english a6151_77bef945:


    "No estoy entre el público."


translate english a6151_3e474249:


    "No estoy en ningún lado."


translate english a6151_088dfb64:


    "...Desearía poder desaparecer."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
