

translate english e2314b_fcc64596:


    "Recojo la bolsa de papel pequeña."


translate english e2314b_1050d89f:


    "Sea lo que sea, algo dentro de mí me dice que debo usarlo."


translate english e2314b_b76055da:


    "Una especie de instinto interior..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
