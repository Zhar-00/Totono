

translate english c7121_29adcddf:


    xy "\"Okay... They're gone.\""


translate english c7121_3e4ef725:


    "Ahora solo estamos Aoi y yo, solos en la sala."


translate english c7121_6abc0c0d:



    voice "voice/c71/2100010a02.opus"
    aoi "\"Boop boop...\""


translate english c7121_bec8c84f:


    "Sus ojos son como platos."


translate english c7121_7bec076a:


    "Es como si todas sus esperanzas se hubieran destrozado con su celular."


translate english c7121_a0a3a1a3:


    "Respiro hondo para serenarme."


translate english c7121_c7c85043:


    "Luego me acerco a Aoi."


translate english c7121_581c0ffd:


    xy "\"Please, tell me...\""


translate english c7121_7b0f8611:


    xy "\"Why did you betray me...?\""


translate english c7121_9a5b692b:



    voice "voice/c71/2100020a02.opus"
    aoi "\"Aoi...\""


translate english c7121_c4e9222d:



    voice "voice/c71/2100030a02.opus"
    aoi "\"Aoi is a romance option.\""


translate english c7121_12e64a21:


    xy "\"......\""


translate english c7121_106b2357:



    voice "voice/c71/2100040a02.opus"
    aoi "\"God created me as a character in this game—\""


translate english c7121_183c8591:


    xy "\"SHUT THE FUCK UP!\""


translate english c7121_2bba49fd:


    "Antes de poder detenerme, le grito."


translate english c7121_4e03527e:


    xy "\"I'm SICK of your fucking game bullshit!\""


translate english c7121_3daece5b:



    voice "voice/c71/2100050a02.opus"
    aoi "\"It's the truth.\""


translate english c7121_0f4627b8:


    "Su mirada es firme."


translate english c7121_0757468c:



    voice "voice/c71/2100060a02.opus"
    aoi "\"God is real.\""


translate english c7121_77055946:



    voice "voice/c71/2100070a02.opus"
    aoi "\"God is a concept.\""


translate english c7121_b602bc3e:



    voice "voice/c71/2100080a02.opus"
    aoi "\"An amalgamation of every possible love interest in every possible world.\""


translate english c7121_dbdcf49a:



    voice "voice/c71/2100090a02.opus"
    aoi "\"An abstract.\""


translate english c7121_3130bfc9:



    voice "voice/c71/2100100a02.opus"
    aoi "\"Aoi is a manifestation of that God.\""


translate english c7121_536061a1:



    voice "voice/c71/2100110a02.opus"
    aoi "\"An avatar pulled from a massive database and optimized to perfectly suit this world.\""


translate english c7121_af8cb1a0:



    voice "voice/c71/2100120a02.opus"
    aoi "\"With only one objective.\""


translate english c7121_21cb3829:



    voice "voice/c71/2100130a02.opus"
    aoi "\"To pursue as many protagonists as possible.\""


translate english c7121_02c43e67:



    voice "voice/c71/2100140a02.opus"
    aoi "\"And collect all the event CGs.\""


translate english c7121_c3c8c5a3:



    voice "voice/c71/2100150a02.opus"
    aoi "\"This 'Aoi route' that YOU'RE on...\""



translate english c7121_b529b58f:



    voice "voice/c71/2100160a02.opus"
    aoi "\"...also serves as the 'Shinichi route' for God.\""



translate english c7121_ff91728d:



    voice "voice/c71/2100170a02.opus"
    aoi "\"Once God achieves sex with Shinichi...\""


translate english c7121_2ac3139b:



    voice "voice/c71/2100180a02.opus"
    aoi "\"The Shinichi route is complete.\""


translate english c7121_92af81e0:



    voice "voice/c71/2100190a02.opus"
    aoi "\"Without new CGs, Aoi's entire existence is pointless.\""


translate english c7121_e5f9ee4d:



    voice "voice/c71/2100200a02.opus"
    aoi "\"My battery will run dry and my signal won't reach, which means no saving the game... and so Aoi will disappear.\""


translate english c7121_0f9e81c2:



    voice "voice/c71/2100210a02.opus"
    aoi "\"So Aoi started playing Haru-chan's route.\""


translate english c7121_5c147da9:



    voice "voice/c71/2100220a02.opus"
    aoi "\"That's why Aoi cheated on you.\""


translate english c7121_35f0f934:


    "Su expresión no cambia ni un ápice."


translate english c7121_e948e0c6:


    "Lo recita todo como si fuera lo más normal del mundo."


translate english c7121_f40af430:


    "Como si estuviera leyendo de un guion."


translate english c7121_a3cdffcf:



    voice "voice/c71/2100230a02.opus"
    aoi "\"But this is where we say goodbye.\""


translate english c7121_d447e7ad:



    voice "voice/c71/2100240a02.opus"
    aoi "\"Bye-bye.\""


translate english c7121_3bfca076:


    "Se da la vuelta en silencio."


translate english c7121_3db72a3f:


    "Y luego se marcha."


translate english c7121_5c4d17a9:


    "Sus pasos inseguros se van apagando."


translate english strings:


    old "Аой врёт"
    new "Aoi miente"


    old "Я уже не знаю, чему верить"
    new "No sé qué creer"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
