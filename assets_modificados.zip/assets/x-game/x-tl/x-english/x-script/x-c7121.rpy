

translate english c7121_29adcddf:


    xy "\"Bien... Ya se fueron.\""


translate english c7121_3e4ef725:


    "Ahora solo estamos Aoi y yo, solos en la sala."


translate english c7121_6abc0c0d:



    voice "voice/c71/2100010a02.opus"
    aoi "\"Bup bup...\""


translate english c7121_bec8c84f:


    "Sus ojos son como platos."


translate english c7121_7bec076a:


    "Es como si todas sus esperanzas se hubieran destrozado con su celular."


translate english c7121_a0a3a1a3:


    "Respiro hondo para serenarme."


translate english c7121_c7c85043:


    "Luego me acerco a Aoi."


translate english c7121_581c0ffd:


    xy "\"Por favor, dime...\""


translate english c7121_7b0f8611:


    xy "\"¿Por qué me traicionaste...?\""


translate english c7121_9a5b692b:



    voice "voice/c71/2100020a02.opus"
    aoi "\"Aoi...\""


translate english c7121_c4e9222d:



    voice "voice/c71/2100030a02.opus"
    aoi "\"Aoi es una ruta romántica.\""


translate english c7121_12e64a21:


    xy "\"......\""


translate english c7121_106b2357:



    voice "voice/c71/2100040a02.opus"
    aoi "\"Dios me creó como personaje en este juego—\""


translate english c7121_183c8591:


    xy "\"¡CÁLLATE DE UNA PUTA VEZ!\""


translate english c7121_2bba49fd:


    "Antes de poder detenerme, le grito."


translate english c7121_4e03527e:


    xy "\"¡Estoy HARTO de tus pendejadas de jueguito!\""


translate english c7121_3daece5b:



    voice "voice/c71/2100050a02.opus"
    aoi "\"Es la verdad.\""


translate english c7121_0f4627b8:


    "Su mirada es firme."


translate english c7121_0757468c:



    voice "voice/c71/2100060a02.opus"
    aoi "\"Dios es real.\""


translate english c7121_77055946:



    voice "voice/c71/2100070a02.opus"
    aoi "\"Dios es un concepto.\""


translate english c7121_b602bc3e:



    voice "voice/c71/2100080a02.opus"
    aoi "\"Una amalgama de todos los intereses amorosos posibles en todos los mundos posibles.\""


translate english c7121_dbdcf49a:



    voice "voice/c71/2100090a02.opus"
    aoi "\"Un abstracto.\""


translate english c7121_3130bfc9:



    voice "voice/c71/2100100a02.opus"
    aoi "\"Aoi es una manifestación de ese Dios.\""


translate english c7121_536061a1:



    voice "voice/c71/2100110a02.opus"
    aoi "\"Un avatar sacado de una base de datos masiva y optimizado para encajar perfectamente con este mundo.\""


translate english c7121_af8cb1a0:



    voice "voice/c71/2100120a02.opus"
    aoi "\"Con un solo objetivo.\""


translate english c7121_21cb3829:



    voice "voice/c71/2100130a02.opus"
    aoi "\"Cortejar a tantos protagonistas como sea posible.\""


translate english c7121_02c43e67:



    voice "voice/c71/2100140a02.opus"
    aoi "\"Y coleccionar todas las CGs de eventos.\""


translate english c7121_c3c8c5a3:



    voice "voice/c71/2100150a02.opus"
    aoi "\"Esta \"ruta de Aoi\" por la que TÚ vas...\""



translate english c7121_b529b58f:



    voice "voice/c71/2100160a02.opus"
    aoi "\"...también sirve como la \"ruta de Shinichi\" para Dios.\""



translate english c7121_ff91728d:



    voice "voice/c71/2100170a02.opus"
    aoi "\"Una vez que Dios logre tener sexo con Shinichi...\""


translate english c7121_2ac3139b:



    voice "voice/c71/2100180a02.opus"
    aoi "\"La ruta de Shinichi queda completa.\""


translate english c7121_92af81e0:



    voice "voice/c71/2100190a02.opus"
    aoi "\"Sin nuevas CGs, toda la existencia de Aoi no tiene sentido.\""


translate english c7121_e5f9ee4d:



    voice "voice/c71/2100200a02.opus"
    aoi "\"Mi batería se agotará y mi señal no llegará, lo que significa que no podré guardar la partida... y entonces Aoi desaparecerá.\""


translate english c7121_0f9e81c2:



    voice "voice/c71/2100210a02.opus"
    aoi "\"Así que Aoi empezó a jugar la ruta de Haru-chan.\""


translate english c7121_5c147da9:



    voice "voice/c71/2100220a02.opus"
    aoi "\"Por eso Aoi te engañó.\""


translate english c7121_35f0f934:


    "Su expresión no cambia ni un ápice."


translate english c7121_e948e0c6:


    "Lo recita todo como si fuera lo más normal del mundo."


translate english c7121_f40af430:


    "Como si estuviera leyendo de un guion."


translate english c7121_a3cdffcf:



    voice "voice/c71/2100230a02.opus"
    aoi "\"Pero aquí nos despedimos.\""


translate english c7121_d447e7ad:



    voice "voice/c71/2100240a02.opus"
    aoi "\"Adiós.\""


translate english c7121_3bfca076:


    "Se da la vuelta en silencio."


translate english c7121_3db72a3f:


    "Y luego se marcha."


translate english c7121_5c4d17a9:


    "Sus pasos inseguros se van apagando."


translate english strings:


    old "Аой врёт"
    new "Aoi miente"


    old "Я уже не знаю, чему верить"
    new "No sé qué creer"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
