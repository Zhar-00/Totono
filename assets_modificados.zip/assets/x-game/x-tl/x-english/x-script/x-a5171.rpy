

translate english a5171_9fb97838:


    xy "\"...Whew...\""


translate english a5171_772f4685:


    "Mientras bajo las escaleras, suspiro aliviado."



translate english a5171_4770b949:


    "Intento calmarme, pero mi corazón sigue latiendo como loco."


translate english a5171_4f259ab6:


    "Salvado por la campana... literalmente."


translate english a5171_6feab424:


    "Gracias a Dios se me ocurrió llamarlo."


translate english a5171_773aa3b6:


    "Además, llegó mucho más rápido de lo que esperaba. La amistad es algo tan hermoso—"


translate english a5171_a7ded73a:


    xy "\"...Huh?\""


translate english a5171_c54286cd:



    voice "voice/a51/7100010a01.opus"
    mx "\"Why?\""


translate english a5171_d6b063ab:


    "Su bate de béisbol cae al suelo con estrépito."


translate english a5171_d128d86c:



    voice "voice/a51/7100020a01.opus"
    mx "\"Why are you here?\""


translate english a5171_9c0238fd:



    voice "voice/a51/7100030a01.opus"
    mx "\"What happened to 'something came up'?\""


translate english a5171_87754f2d:



    voice "voice/a51/7100040a01.opus"
    mx "\"Were you just trying to get out of meeting me?\""


translate english a5171_a9c19fbf:


    xy "\"No, that's not it—\""


translate english a5171_451f3740:



    voice "voice/a51/7100050a01.opus"
    mx "\"Those shoes.\""


translate english a5171_bb58c512:


    xy "\"...Huh?\""


translate english a5171_b0575cad:


    "Miro hacia abajo, a un par de zapatos de mujer tirados en la entrada."


translate english a5171_60a59cf5:



    voice "voice/a51/7100060a01.opus"
    mx "\"Those are Aoi's.\""


translate english a5171_13e208e9:



    voice "voice/a51/7100070a01.opus"
    mx "\"Aoi's here, isn't she.\""


translate english a5171_118a8b88:


    xy "\"N-No, uh—\""


translate english a5171_83593a92:



    voice "voice/a51/7100080a01.opus"
    mx "\"So you ignored my request...\""


translate english a5171_3417cc88:



    voice "voice/a51/7100090a01.opus"
    mx "\"...and chose to stay here, alone with Aoi.\""


translate english a5171_041ef918:


    xy "\"It's not what it looks li—\""


translate english a5171_f55b769d:



    voice "voice/a51/7100100a01.opus"
    mx "\"I want to see her.\""


translate english a5171_acbe322e:


    xy "\"Wait—\""


translate english a5171_2cde9ced:



    voice "voice/a51/7100110a01.opus"
    mx "\"I'm coming in.\""


translate english a5171_08e3f757:


    xy "\"Wait—HEY! I said wait!\""


translate english a5171_a84fd9bc:



    voice "voice/a51/7100120a01.opus"
    mx "\"Aoi! Where are you? Come on out!\""


translate english a5171_48fde860:



    voice "voice/a51/7100140a01.opus"
    mx "\"You get out of my way! Go on, get!\""


translate english a5171_11c41feb:


    "Eru intenta restregarse contra la pierna de Miyuki, pero ella no le presta atención. En cambio, sigue registrando mi sala."



translate english a5171_de14d057:


    "No voy a poder calmarla con palabras."


translate english a5171_e00e46fc:


    "Así que, en cambio, decido decirle la verdad."



translate english a5171_6ccba33b:


    xy "\"Miyuki, just hear me out! I can explain!\""


translate english a5171_feb194c4:


    xy "\"You know how important her phone is to her? Well, the thing is, it's gone missing.\""


translate english a5171_5ca9225f:


    xy "\"She was freaking out, saying she'll lose her memories without it, so I've been helping her look—\""


translate english a5171_877abc5f:



    voice "voice/a51/7100150a01.opus"
    mx "\"And you seriously believe that?\""


translate english a5171_ac3b49da:


    xy "\"I mean... not really, but...\""


translate english a5171_6798af40:



    voice "voice/a51/7100160a01.opus"
    mx "\"We had plans. But you chose Aoi.\""


translate english a5171_19bfbd9f:


    xy "\"Well, she isn't feeling well—\""


translate english a5171_2b84e2c9:



    voice "voice/a51/7100170a01.opus"
    mx "\"I don't want to hear it.\""


translate english a5171_32f8904d:


    "Tras registrar la sala sin éxito, se dirige de inmediato a las escaleras."


translate english a5171_72aabed9:


    xy "\"Don't—HEY!\""


translate english a5171_deeeb9ef:


    "Ay, mierda. Va hacia mi cuarto."


translate english a5171_a545da07:


    "¡Puede que Aoi todavía esté a medio vestir!"


translate english a5171_0a008605:


    xy "\"Miyuki! Will you please just slow down?!\""


translate english a5171_b69957b7:


    "Corro tras ella, hasta el segundo piso."


translate english a5171_f9caeadf:



    voice "voice/a51/7100180a01.opus"
    mx "\"\"\"......\"\"\""


translate english a5171_c2ca6e46:


    "La encuentro de pie, en silencio, en la entrada de mi cuarto... totalmente inmóvil."


translate english a5171_3e20b1b0:


    "¿Está conteniendo su furia, o—?"


translate english a5171_39a8f629:



    voice "voice/a51/7100190a01.opus"
    mx "\"\"\"......\"\"\""


translate english a5171_b5972e9a:


    "Con dudas, me asomo por detrás de ella hacia mi cuarto."


translate english a5171_0accd139:


    xy "\"\"\"......\"\"\""


translate english a5171_aa0973db:


    "Está vacío."


translate english a5171_2e0da2b6:


    "Aoi se ha ido."


translate english a5171_db2a8055:


    "¿Acaso... desapareció...?"


translate english a5171_97be5591:



    voice "voice/a51/7100200a01.opus"
    mx "\"Where is she?\""


translate english a5171_f1bdd3ee:


    xy "\"I... I don't know...!\""


translate english a5171_ec7974c7:



    voice "voice/a51/7100210a01.opus"
    mx "\"What do you mean, you don't know?!\""


translate english a5171_8b5184c0:


    xy "\"Maybe she left to go look for her phone.\""


translate english a5171_1d7cfb9d:



    voice "voice/a51/7100220a01.opus"
    mx "\"Without her shoes?\""


translate english a5171_25e476e1:


    xy "\"She was really out of it. She probably put mine on by mistake when she left.\""


translate english a5171_08f0af00:



    voice "voice/a51/7100230a01.opus"
    mx "\"Oh really...\""


translate english a5171_5fbd0cc1:


    "Miyuki no suena ni un poco convencida."


translate english a5171_933affc6:


    "Hasta yo sé que es una excusa de porquería."


translate english a5171_c5e57267:


    "Es solo que no quiero que las cosas empeoren—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
