

translate english a5171_9fb97838:


    xy "\"...Uf...\""


translate english a5171_772f4685:


    "Mientras bajo las escaleras, suspiro aliviado."



translate english a5171_4770b949:


    "Intento calmarme, pero mi corazón sigue latiendo como loco."


translate english a5171_4f259ab6:


    "Salvado por la campana... literalmente."


translate english a5171_6feab424:


    "Gracias a Dios se me ocurrió llamarlo."


translate english a5171_773aa3b6:


    "Además, llegó mucho más rápido de lo que esperaba. La amistad es algo tan hermoso—"


translate english a5171_a7ded73a:


    xy "\"...¿Eh?\""


translate english a5171_c54286cd:



    voice "voice/a51/7100010a01.opus"
    mx "\"¿Por qué?\""


translate english a5171_d6b063ab:


    "Su bate de béisbol cae al suelo con estrépito."


translate english a5171_d128d86c:



    voice "voice/a51/7100020a01.opus"
    mx "\"¿Por qué estás aquí?\""


translate english a5171_9c0238fd:



    voice "voice/a51/7100030a01.opus"
    mx "\"¿Qué pasó con 'me surgió algo'?\""


translate english a5171_87754f2d:



    voice "voice/a51/7100040a01.opus"
    mx "\"¿Solo estabas tratando de zafarte de verme?\""


translate english a5171_a9c19fbf:


    xy "\"No, no es eso...\""


translate english a5171_451f3740:



    voice "voice/a51/7100050a01.opus"
    mx "\"Esos zapatos.\""


translate english a5171_bb58c512:


    xy "\"...¿Eh?\""


translate english a5171_b0575cad:


    "Miro hacia abajo, a un par de zapatos de mujer tirados en la entrada."


translate english a5171_60a59cf5:



    voice "voice/a51/7100060a01.opus"
    mx "\"Esos son de Aoi.\""


translate english a5171_13e208e9:



    voice "voice/a51/7100070a01.opus"
    mx "\"Aoi está aquí, ¿verdad?\""


translate english a5171_118a8b88:


    xy "\"N-No, em...\""


translate english a5171_83593a92:



    voice "voice/a51/7100080a01.opus"
    mx "\"Así que ignoraste mi petición...\""


translate english a5171_3417cc88:



    voice "voice/a51/7100090a01.opus"
    mx "\"...y elegiste quedarte aquí, a solas con Aoi.\""


translate english a5171_041ef918:


    xy "\"No es lo que pare...\""


translate english a5171_f55b769d:



    voice "voice/a51/7100100a01.opus"
    mx "\"Quiero verla.\""


translate english a5171_acbe322e:


    xy "\"Espera...\""


translate english a5171_2cde9ced:



    voice "voice/a51/7100110a01.opus"
    mx "\"Voy a entrar.\""


translate english a5171_08e3f757:


    xy "\"¡Espera... OYE! ¡Dije que esperes!\""


translate english a5171_a84fd9bc:



    voice "voice/a51/7100120a01.opus"
    mx "\"¡Aoi! ¿Dónde estás? ¡Sal!\""


translate english a5171_48fde860:



    voice "voice/a51/7100140a01.opus"
    mx "\"¡Apártate de mi camino! ¡Vamos, quítate!\""


translate english a5171_11c41feb:


    "Eru intenta restregarse contra la pierna de Miyuki, pero ella no le presta atención. En cambio, sigue registrando mi sala."



translate english a5171_de14d057:


    "No voy a poder calmarla con palabras."


translate english a5171_e00e46fc:


    "Así que, en cambio, decido decirle la verdad."



translate english a5171_6ccba33b:


    xy "\"¡Miyuki, solo escúchame! ¡Puedo explicarlo!\""


translate english a5171_feb194c4:


    xy "\"¿Sabes lo importante que es su teléfono para ella? Bueno, la cosa es que se perdió.\""


translate english a5171_5ca9225f:


    xy "\"Se estaba volviendo loca, diciendo que perderá sus recuerdos sin él, así que la he estado ayudando a buscar...\""


translate english a5171_877abc5f:



    voice "voice/a51/7100150a01.opus"
    mx "\"¿Y de verdad te lo crees?\""


translate english a5171_ac3b49da:


    xy "\"O sea... no realmente, pero...\""


translate english a5171_6798af40:



    voice "voice/a51/7100160a01.opus"
    mx "\"Teníamos planes. Pero elegiste a Aoi.\""


translate english a5171_19bfbd9f:


    xy "\"Bueno, no se siente bien...\""


translate english a5171_2b84e2c9:



    voice "voice/a51/7100170a01.opus"
    mx "\"No quiero escucharlo.\""


translate english a5171_32f8904d:


    "Tras registrar la sala sin éxito, se dirige de inmediato a las escaleras."


translate english a5171_72aabed9:


    xy "\"¡No... OYE!\""


translate english a5171_deeeb9ef:


    "Ay, mierda. Va hacia mi cuarto."


translate english a5171_a545da07:


    "¡Puede que Aoi todavía esté a medio vestir!"


translate english a5171_0a008605:


    xy "\"¡Miyuki! ¿¡Puedes ir más despacio, por favor!?\""


translate english a5171_b69957b7:


    "Corro tras ella, hasta el segundo piso."


translate english a5171_f9caeadf:



    voice "voice/a51/7100180a01.opus"
    mx "\"\"\"......\"\"\""


translate english a5171_c2ca6e46:


    "La encuentro de pie, en silencio, en la entrada de mi cuarto... totalmente inmóvil."


translate english a5171_3e20b1b0:


    "¿Está conteniendo su furia, o—?"


translate english a5171_39a8f629:



    voice "voice/a51/7100190a01.opus"
    mx "\"\"\"......\"\"\""


translate english a5171_b5972e9a:


    "Con dudas, me asomo por detrás de ella hacia mi cuarto."


translate english a5171_0accd139:


    xy "\"\"\"......\"\"\""


translate english a5171_aa0973db:


    "Está vacío."


translate english a5171_2e0da2b6:


    "Aoi se ha ido."


translate english a5171_db2a8055:


    "¿Acaso... desapareció...?"


translate english a5171_97be5591:



    voice "voice/a51/7100200a01.opus"
    mx "\"¿Dónde está?\""


translate english a5171_f1bdd3ee:


    xy "\"¡Yo... no sé...!\""


translate english a5171_ec7974c7:



    voice "voice/a51/7100210a01.opus"
    mx "\"¡¿Cómo que no sabes?!\""


translate english a5171_8b5184c0:


    xy "\"Quizá se fue a buscar su teléfono.\""


translate english a5171_1d7cfb9d:



    voice "voice/a51/7100220a01.opus"
    mx "\"¿Sin sus zapatos?\""


translate english a5171_25e476e1:


    xy "\"Estaba muy ida. Probablemente se puso los míos por error cuando se fue.\""


translate english a5171_08f0af00:



    voice "voice/a51/7100230a01.opus"
    mx "\"Ah, ¿en serio...?\""


translate english a5171_5fbd0cc1:


    "Miyuki no suena ni un poco convencida."


translate english a5171_933affc6:


    "Hasta yo sé que es una excusa de porquería."


translate english a5171_c5e57267:


    "Es solo que no quiero que las cosas empeoren—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
