

translate english a7222_b7f75ea2:



    voice "voice/a72/2200010a01.opus"
    mx "\"Oh, that's right! I almost forgot your present!\""


translate english a7222_94a8ee7c:



    voice "voice/a72/2200020a01.opus"
    mx "\"...Not that we need it anymore.\""


translate english a7222_5df275c3:


    xy "\"What do you mean?\""


translate english a7222_2e84a28b:



    voice "voice/a72/2200030a01.opus"
    mx "\"Well, you know how, back in the classroom, you were talking about how maid uniforms are your dream or whatever?\""


translate english a7222_4f527e0d:



    voice "voice/a72/2200040a01.opus"
    mx "\"Well... I bought one just for today, and...\""


translate english a7222_942e5bbb:



    voice "voice/a72/2200050a01.opus"
    mx "\"I thought I'd give it to you as your birthday present.\""


translate english a7222_876bb4bf:



    voice "voice/a72/2200060a01.opus"
    mx "\"But then I got caught up in the heat of the moment... and now my gift will just go to waste—\""


translate english a7222_0147f4d4:


    xy "\"No it won't!\""


translate english a7222_f337a024:



    voice "voice/a72/2200070a01.opus"
    mx "\"Huh? But Shinichi, we already—\""


translate english a7222_98cb0286:



    voice "voice/a72/2200080a01.opus"
    mx "\"What the—AAAH! Shin...ichi...?\""


translate english a7222_599a23a5:


    xy "\"For you, I can get it up as many times as it takes!\""


translate english a7222_b7a8179f:



    voice "voice/a72/2200090a01.opus"
    mx "\"Gee, how thoughtful of you...\""


translate english a7222_65dc14f0:


    xy "\"Miyuki!\""


translate english a7222_d78c8b1a:


    xy "\"I'm madly in love with you! Nothing more, nothing less!\""


translate english a7222_76efdf23:



    voice "voice/a72/2200100a01.opus"
    mx "\"Oh, shush... You big dork!\""


translate english a7222_fbd42898:



    voice "voice/a72/2200110a01.opus"
    mx "\"Fine, okay? I get it!\""


translate english a7222_499509b3:



    voice "voice/a72/2200120a01.opus"
    mx "\"I'll... I'll go put it on... Y-You just wait right here.\""


translate english a7222_b7a6a406:



    voice "voice/a72/2200130a01.opus"
    mx "\"Got that, M-Master...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
