

translate english a7222_b7f75ea2:



    voice "voice/a72/2200010a01.opus"
    mx "\"¡Oh, es cierto! ¡Casi olvido tu regalo!\""


translate english a7222_94a8ee7c:



    voice "voice/a72/2200020a01.opus"
    mx "\"...No es que ya lo necesitemos.\""


translate english a7222_5df275c3:


    xy "\"¿A qué te refieres?\""


translate english a7222_2e84a28b:



    voice "voice/a72/2200030a01.opus"
    mx "\"Bueno, ya sabes cómo, allá en el salón de clases, estabas hablando de que los uniformes de empleada son tu sueño o lo que sea.\""


translate english a7222_4f527e0d:



    voice "voice/a72/2200040a01.opus"
    mx "\"Bueno... compré uno solo para hoy, y...\""


translate english a7222_942e5bbb:



    voice "voice/a72/2200050a01.opus"
    mx "\"Pensé en dártelo como regalo de cumpleaños.\""


translate english a7222_876bb4bf:



    voice "voice/a72/2200060a01.opus"
    mx "\"Pero luego me dejé llevar por el momento... y ahora mi regalo solo se va a desperdiciar—\""


translate english a7222_0147f4d4:


    xy "\"¡No se va a desperdiciar!\""


translate english a7222_f337a024:



    voice "voice/a72/2200070a01.opus"
    mx "\"¿Eh? Pero Shinichi, ya lo hic—\""


translate english a7222_98cb0286:



    voice "voice/a72/2200080a01.opus"
    mx "\"¿¡Qué demonios—!? ¡AAAH! ¿¡Shin...ichi...!?\""


translate english a7222_599a23a5:


    xy "\"¡Por ti, puedo ponérmela tiesa tantas veces como haga falta!\""


translate english a7222_b7a8179f:



    voice "voice/a72/2200090a01.opus"
    mx "\"Vaya, qué considerado de tu parte...\""


translate english a7222_65dc14f0:


    xy "\"¡Miyuki!\""


translate english a7222_d78c8b1a:


    xy "\"¡Estoy perdidamente enamorado de ti! ¡Ni más ni menos!\""


translate english a7222_76efdf23:



    voice "voice/a72/2200100a01.opus"
    mx "\"Oh, cállate... ¡Tonto!\""


translate english a7222_fbd42898:



    voice "voice/a72/2200110a01.opus"
    mx "\"Está bien, ¿sí? ¡Ya entendí!\""


translate english a7222_499509b3:



    voice "voice/a72/2200120a01.opus"
    mx "\"Me... me lo voy a poner... T-Tú solo espera aquí.\""


translate english a7222_b7a6a406:



    voice "voice/a72/2200130a01.opus"
    mx "\"Entendido, ¿a-amo...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
