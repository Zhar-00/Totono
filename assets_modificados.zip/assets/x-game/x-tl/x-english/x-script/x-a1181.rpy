

translate english a1181_75834da7:


    "Después de escapar de casa, Aoi ahora vive sola en un manga café."


translate english a1181_3910a89f:


    "Dios podría ser real, pero de ninguna forma eso es el cielo."


translate english a1181_e58cb38c:


    "Tiene que haber un final más feliz para ella en algún lado."


translate english a1181_84507025:


    "Surely \"God\"no es el fin de todo."


translate english a1181_0db80546:


    "¿Hay alguna forma de ayudarla?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
