



translate english e2203b_65035b89:


    "Hoy conocí a Mukou Aoi en el techo de la escuela."


translate english e2203b_298dc7ec:


    "Era mi primera vez hablando con ella, pero resulta que el rumor de que es una despistada es totalmente cierto."


translate english e2203b_9dfc4e89:


    "Confunde los videojuegos con la realidad y me trata como una opción romántica en una novela visual. ¡Es absolutamente inaceptable!"


translate english e2203b_e85ca865:


    "¡Mis sentimientos por Shinichi NO son algo con lo que jugar!"



translate english e2203b_b4b1b75f:


    "Hoy, en las jaulas de bateo, Shinichi me pidió que me hiciera amiga de Mukou-san."


translate english e2203b_b4eb2492:


    "Francamente, no veo que vaya a funcionar nunca, por mucho que me esfuerce."


translate english e2203b_42f57326:


    "Pero Shinichi parecía desesperado... y no estoy hecha de piedra..."


translate english e2203b_1c1be541:


    "Así que no tuve más remedio que aceptar ayudarlo."


translate english e2203b_76e7f35f:


    "A cambio, iba a pedirle que me ayudara con otra cosa, pero..."


translate english e2203b_47571874:


    "Tendré que arreglármelas yo misma."


translate english e2203b_6cc2a2ac:


    "Aun así, parece que Shinichi realmente se preocupa por mí."


translate english e2203b_b23ea32c:


    "Estoy un poco sorprendida."



translate english e2203b_0d4398fc:


    "¡Shinichi me dio un pasador!"


translate english e2203b_1835e262:


    "A decir verdad, no es realmente mi estilo."


translate english e2203b_6bff2f97:


    "Sé que no me queda bien."


translate english e2203b_e3c71e2d:


    "Pero voy a atesorarlo de todos modos."


translate english e2203b_46d7fe17:


    "Lo cuidaré bien por el resto de mi vida."


translate english e2203b_9167de6c:


    "¡Por siempre y para siempre!"


translate english e2203b_f40652df:


    "Aoi es tan afortunada... Desearía poder lucir el look como ella."



translate english e2203b_08a17fc0:


    "Aoi dejó el café de manga para rescatar a un gatito abandonado, así que Shinichi y yo fuimos a buscarla."


translate english e2203b_8d675130:


    "Registramos todo el pueblo hasta encontrarla en el recinto escolar fuera del horario escolar."


translate english e2203b_5f5ce744:


    "En ese momento, pensé para mí... Quizás está bien que sea honesta sobre cómo me siento realmente."


translate english e2203b_3355f636:


    "\"Maybe it's okay to tell Shinichi, I thought.\""


translate english e2203b_72639698:


    "Pero entonces Aoi me interrumpió antes de que pudiera."


translate english e2203b_c2221428:


    "Se desplomó, y Shinichi terminó acompañándola de vuelta al café de manga, dejándome ir a casa sola."


translate english e2203b_ebdf8c58:


    "Entonces oí un teléfono sonando a lo lejos."


translate english e2203b_5b8425ce:


    "Seguí el sonido, y ¿qué sabes? Encontré el celular de Aoi tirado ahí."


translate english e2203b_26640eb2:


    "Probablemente lo dejó caer cuando salió tambaleándose por la puerta principal."


translate english e2203b_b780f5db:


    "Así que lo recogí—e inmediatamente me quedé atónita."


translate english e2203b_412f7fab:


    "Era una llamada de \"God\"."



translate english e2203b_bd7a3eae:


    "Pensándolo bien, no estoy segura de por qué decidí contestar esa llamada, pero lo hice."


translate english e2203b_df0b767a:


    "Y en el instante en que lo hice..."


translate english e2203b_c02b75cc:


    "Algo echó raíces en mi corazón."


translate english e2203b_6b0c0772:


    "Empecé a pensar... quizás Dios realmente existe."


translate english e2203b_da800a90:


    "No podía creerlo."


translate english e2203b_f56a55d3:


    "¿Qué era esa novela visual?"


translate english e2203b_54bd92c3:


    "Era casi idéntica al mundo real."


translate english e2203b_fedf241b:


    "¿Pasarían esos mismos eventos en la vida real también?"


translate english e2203b_c2cc2726:


    "¿Incluso el final?"


translate english e2203b_32c6d40f:


    "Decidí que le preguntaría a Shinichi al respecto en la escuela al día siguiente."


translate english e2203b_38634a34:


    "Así que fui a casa y descargué el juego en mi teléfono."


translate english e2203b_36e5e1b3:


    "Luego lo jugué completo, solo para comprobar."


translate english e2203b_42265109:


    "Pero el juego no es un reflejo de la realidad."


translate english e2203b_dd1d5984:


    "La realidad es un reflejo del juego."


translate english e2203b_0d09e4a7:


    "De ahora en adelante, tendré que olvidar todo lo que creía saber."


translate english e2203b_c1d1c6ff:


    "Ese es el único camino hacia mi felicidad..."


translate english e2203b_f325d197:


    "...y la única forma en que terminaré con Shinichi en este mundo."


translate english e2203b_1f98cdb6:


    "Hoy tuve sexo con Shinichi por primera vez."


translate english e2203b_eadd9c1a:


    "Estaba muy nerviosa y avergonzada, y pensé que iba a morir."


translate english e2203b_c649c879:


    "Al principio dolió un poco."


translate english e2203b_265e1c91:


    "Pero Shinichi no le dio la espalda a la verdadera yo."


translate english e2203b_96370f61:


    "Sentí alegría llenar todo mi cuerpo."


translate english e2203b_e075374e:


    "Supe que ya no necesitaba nada más que esto."


translate english e2203b_3a19a21e:


    "Te amo..."


translate english e2203b_de794372:


    "Así que por favor..."


translate english e2203b_a6788dfe:


    "Prométeme que nunca me dejarás ir."


translate english e2203b_1ef53b86:


    "・Cómo preservar recuerdos → Llamar a Dios (= Guardar)"


translate english e2203b_6586a4a4:


    "・Aoi es un dispositivo de colección de eventos. Como avatar, requiere energía (lo que ella llama poder de batería) para mantener su existencia."


translate english e2203b_ebd4b736:


    "・Asimismo, guardar el juego también requiere energía, ya que implica llamar a Dios. (No se requiere energía para recibir una llamada.)"


translate english e2203b_686496d0:


    "・Aoi tiene razón: el techo tiene la mejor recepción."


translate english e2203b_ce74affc:


    "・Como humano, no necesito energía para existir."


translate english e2203b_02cff0c3:


    "・Todavía me cuesta guardar el juego, pero no es demasiado devastador."


translate english e2203b_5cde694b:


    "・La clave es la tarjeta SIM. La tarjeta SIM es más importante que el teléfono mismo."


translate english e2203b_7640d642:


    "・La tarjeta SIM permite que mis fotos se transfieran."


translate english e2203b_14d75da2:


    "・Mientras tome fotos de mi diario, sin importar en qué ruta termine, puedo mantener un registro de los eventos."


translate english e2203b_4b1813f0:


    "Ayer, TÚ me traicionaste."


translate english e2203b_5fc8f91e:


    "Te esperé tanto tiempo en las jaulas de bateo, pero me ignoraste."


translate english e2203b_a71c26e2:


    "Tú te fuiste y tuviste sexo con Aoi."


translate english e2203b_de1d1658:


    "Estabas tratando de meterte en su ruta."


translate english e2203b_8a50d86a:


    "¡Inaceptable!"


translate english e2203b_d2981a76:


    "¡Absolutamente IMPERDONABLE!"


translate english e2203b_866847d2:


    "¡Tú me confesaste tu amor a MÍ!"


translate english e2203b_423af9e5:


    "¡Tú me juraste amor eterno a MÍ!"


translate english e2203b_63d7e62c:


    "Hoy maté a Shinichi."


translate english e2203b_db5e25c0:


    "Probablemente me odias por eso."


translate english e2203b_e6ea0106:


    "Pero es tu culpa."


translate english e2203b_bbc09ba8:


    "Primero me juras tu amor, y luego te das la vuelta y me engañas con Aoi..."


translate english e2203b_0117d12f:


    "¡Todo esto es tu culpa por follarte a esa zorra...!"


translate english e2203b_16901cc3:


    "He estado viviendo con Shinichi durante una semana."


translate english e2203b_14ba1863:


    "He estado viviendo con Shinichi durante dos semanas."


translate english e2203b_bb519534:


    "He estado viviendo con Shinichi durante tres semanas."


translate english e2203b_88add880:


    "Lanzamos ese teléfono viejo y obsoleto desde el techo de la escuela, y ahora hemos comenzado nuestra nueva vida juntos."


translate english e2203b_13354b51:


    "Lanzamos ese teléfono de aspecto hortera desde el techo de la escuela, y ahora hemos comenzado nuestra nueva vida juntos."


translate english e2203b_90e0ae87:


    "Lanzamos ese teléfono, y todos los recuerdos horribles, desde el techo de la escuela, y ahora hemos comenzado nuestra nueva vida juntos."


translate english e2203b_75f7f54f:


    "Sé que lo que hago está mal y es una locura."


translate english e2203b_d3f22b69:


    "A decir verdad, no quiero tener que usar sedantes."


translate english e2203b_07f01573:


    "Realmente no quiero tocar las rutas."


translate english e2203b_5a0190a7:


    "Pero... si no lo hago, me dejarás."


translate english e2203b_49be85f1:


    "Me abandonarás en mi soledad y te irás corriendo a otro final."


translate english e2203b_4906257d:


    "Así que esta es mi única opción."


translate english e2203b_375ac04f:


    "Lo siento... lo siento muchísimo..."


translate english e2203b_b9ec17b5:


    "No quería tener que alterar el universo..."


translate english e2203b_3ebfd864:


    "Quería que siguiéramos juntos, los tres..."


translate english e2203b_f9303c81:


    "Pero no podemos."


translate english e2203b_eb6c62cf:


    "Ya me traicionaste una vez."


translate english e2203b_385d8ca5:


    "Y no quiero que vuelva a pasar."


translate english e2203b_66a883d6:


    "No me importa si este mundo está retorcido."


translate english e2203b_e8393d32:


    "Solo quiero ser feliz contigo por el resto de mi vida."


translate english e2203b_c614a333:


    "Por favor, perdóname..."


translate english e2203b_3044a0e8:


    "Parece que simplemente no puedes olvidar a Aoi..."


translate english e2203b_4f71e4f0:


    "Así que hoy te follé mientras me disfrazaba de ella."


translate english e2203b_e0322459:


    "A decir verdad, odié cada minuto... pero aguantaría cualquier cosa por ti."


translate english e2203b_984f386e:


    "Además... jejeje..."


translate english e2203b_bc1a4400:


    "Conseguí tu semen, justo como quería."



translate english e2203b_d3e14e52:


    "Me pregunto si de verdad lograrás dejarme embarazada..."


translate english e2203b_6b231407:


    "¿Ya te has enamorado de mí?"


translate english e2203b_868bc8ae:


    "El sexo que tuvimos hoy fue muy especial para mí."


translate english e2203b_da64c9a5:


    "¿Sabes por qué?"


translate english e2203b_1cdf88bc:


    "Porque el techo es donde me juraste amor eterno."


translate english e2203b_cecf3389:


    "Y es donde me traicionaste."


translate english e2203b_05d3e211:


    "Es donde tuviste sexo con Aoi."


translate english e2203b_d5967db7:


    "Te guardé rencor por eso durante mucho tiempo..."


translate english e2203b_905b4b7e:


    "Pero ahora todo está bien."


translate english e2203b_a91b5c80:


    "De verdad ensuciamos su pupitre, ¿no?"


translate english e2203b_18a0dd04:


    "¡Por fin, mi corazón está en paz!"


translate english e2203b_f6c88891:


    "Ahora podemos estar juntos para siempre..."


translate english e2203b_1e1f4744:


    "Hoy volviste a ver una de mis escenas de sexo favoritas."


translate english e2203b_09cab4fc:


    "¿Te puso caliente?"


translate english e2203b_deb81c36:


    "Me pusiste tan caliente..."


translate english e2203b_35d3ed20:


    "Incluso me toqué."


translate english e2203b_ff737724:


    "Aunque no es lo mismo..."


translate english e2203b_ec7738de:


    "Espero que podamos tener sexo de verdad algún día..."


translate english e2203b_c0b8cb5a:


    "No me dormiste porque me odies, no, lo hiciste porque quieres que cambie para mejor"


translate english e2203b_c33bad0a:


    "cómo lo sé, porque tuviste que saber todo sobre mí para poder responder esas preguntas y lo lograste, lo que significa"


translate english e2203b_8e7881d8:


    "claramente debes amarme, sé que lo que hago está mal y sé que te importo, por eso me dormiste"


translate english e2203b_f7ab7082:


    "tiene que ser eso, tiene que ser eso, tiene que ser eso"


translate english e2203b_79b0736c:


    "confío en ti, me dormiste por amor, creo en ti, por eso fingí que funcionó, esta es la prueba de nuestro amor"


translate english e2203b_bd9d065e:


    "confío confío confío confío en ti sí sí confío confío en ti sí sí sí confío confío confío"


translate english e2203b_ac7ebab8:


    "Hoy tuve sexo contigo."


translate english e2203b_7e1e33cb:


    "No con el protagonista."


translate english e2203b_bd4ebd79:


    "Tuve sexo contigo, literalmente."


translate english e2203b_5aeab501:


    "No tuvimos contacto físico."


translate english e2203b_14ea7046:


    "Así que no voy a quedar embarazada."


translate english e2203b_01ac69fd:


    "Lo sé."


translate english e2203b_4034a185:


    "Pero elijo creer..."


translate english e2203b_575c57c0:


    "...que de verdad tuvimos sexo."


translate english e2203b_37095c1c:


    "Te quiero muchísimo."


translate english e2203b_ddb78b68:


    "Estoy loca por ti."


translate english e2203b_fe188701:


    "Así que... creo que puedo confiar en ti."


translate english lastnumber_6cb47ee2:


    "...ya sabes la respuesta, ¿no?"


translate english lastnumber_4176f4e9:


    "Lo recuerdas, ¿no?"


translate english lastnumber_34e7e8d9:


    "Mi número favorito..."


translate english lastnumber_a46cbdf4:


    "Es..."


translate english lastnumber_8abc2692:


    "...el número de veces que me has dado tu amor."


translate english lastnumber_c2ec39d8:


    "En otras palabras, el número de veces que te has corrido dentro de mí."


translate english lastnumber_f609aa5a:


    "El número de corridas dentro que me has dado."


translate english lastnumber_fd675153:


    "El número de veces que me has llenado con tu leche."


translate english lastnumber_3b40d340:


    "Y ese número..."


translate english lastnumber_130dce36:


    "[persistent.ejaculation] times"



translate english lastnumber_4aca674c:


    "Mira..."


translate english lastnumber_e4b21c1f:


    "Es seguro confiar en ti, ¿verdad?"


translate english lastnumber_dd0f8973:


    "...Sinceramente, perdí la cuenta."


translate english lastnumber_d5067609:


    "Digamos que es 100."




translate english e2203b_fe506ec7:


    "[persistent.passed_a0131_month]/[persistent.passed_a0131_day]"


translate english e2203b_2814e1c1:


    "[persistent.passed_a1211_month]/[persistent.passed_a1211_day]"


translate english e2203b_d52f8358:


    "[persistent.passed_a2182_month]/[persistent.passed_a2182_day]"


translate english e2203b_5ebccc0f:


    "[persistent.passed_sim_stolen_month]/[persistent.passed_sim_stolen_day]"


translate english e2203b_5ebccc0f_1:


    "[persistent.passed_sim_stolen_month]/[persistent.passed_sim_stolen_day]"


translate english e2203b_81dccf89:


    "[persistent.passed_a5122_month]/[persistent.passed_a5122_day]"


translate english e2203b_02433b27:


    "[persistent.passed_non_virgin_month]/[persistent.passed_non_virgin_day]"


translate english e2203b_18fa5a53:


    "[persistent.passed_a_route_month]/[persistent.passed_a_route_day]"


translate english e2203b_c0acabb3:


    "[persistent.passed_c5122_month]/[persistent.passed_c5122_day]"


translate english e2203b_5f0369e5:


    "[persistent.passed_c_route_month]/[persistent.passed_c_route_day]"


translate english e2203b_89f0847f:


    "[persistent.passed_e_route_first_month]/[persistent.passed_e_route_first_day]"


translate english e2203b_572d2b87:


    "[persistent.passed_world_recreate_month]/[persistent.passed_world_recreate_day]"


translate english e2203b_82dff485:


    "[persistent.passed_aoi_sex3_month]/[persistent.passed_aoi_sex3_day]"


translate english e2203b_c408ee15:


    "[persistent.passed_miyuki_sex2_month]/[persistent.passed_miyuki_sex2_day]"


translate english e2203b_845a4673:


    "[persistent.passed_unlock_challenge_month]/[persistent.passed_unlock_challenge_day]"


translate english e2203b_e42d75ce:


    "[persistent.passed_meta_sex_month]/[persistent.passed_meta_sex_day]"


translate english lastnumber_c993b66c:


    "[month]/[day]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
