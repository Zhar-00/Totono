

translate english c6153_0accd139:


    xy "\"......\""


translate english c6153_640f71ed:


    "¿Esto es parte de la sorpresa de cumpleaños?"


translate english c6153_a1bc1c2f:


    "Confundido, llamo a mi casa vacía."


translate english c6153_64f1ddb8:


    "Sé que Aoi no está ahí ahora, así que nadie va a contestar."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
