

translate english e1154b_3e6b1a8a:


    "Decido revisar la agenda de contactos."


translate english e1154b_56c678d2:


    "Pero lo único que consigo es una pantalla de bloqueo."


translate english e1154b_73b43da4:


    "Y además es un bloqueo por huella dactilar."


translate english e1154b_f7888a5b:


    "Lo pruebo con mi dedo índice, pero, naturalmente, rechaza mi huella."


translate english e1154b_d8a02250:


    "I see there's an \"Unlock via security questions\"opción..."



translate english e1154b_b1eef3f1:


    "¿Debería improvisar?"


translate english e1154b_1a2aaed9:


    xy "\"Whoa!!!\""


translate english e1154b_1238235a:


    "¿Q-Qué demonios fue eso?"


translate english e1154b_1a393028:


    "¡La puerta del baño acaba de—!"


translate english e1154b_faa99759:


    xy "\"You're kidding me...\""


translate english e1154b_fa5ed399:



    voice "voice/e11/54b00010a01.opus"
    mx "\"I won't let you...!!!\""


translate english e1154b_e569952b:


    "La puerta del baño chirría con fuerza."


translate english e1154b_b557054a:


    "¡Miyuki está metiendo una palanca!"


translate english e1154b_077a28d9:


    "Ante mis ojos, empieza a forzar la puerta—"


translate english e1154b_f80ec4cd:



    voice "voice/e11/54b00020a01.opus"
    mx "\"You think you're gonna call God? OVER MY DEAD BODY!!!\""


translate english e1154b_c4214de9:



    voice "voice/e11/54b00030a01.opus"
    mx "\"Shinichi...\""


translate english e1154b_8f5a9185:


    xy "\"C-Calm down, Miyuki!\""


translate english e1154b_2c6fce3e:



    voice "voice/e11/54b00040a01.opus"
    mx "\"Haha... haha... hahahahahahahahahaha...!!!\""


translate english e1154b_01b89115:



    voice "voice/e11/54b00050a01.opus"
    mx "\"Calm down? And how would you suggest I calm down?\""


translate english e1154b_b08731ae:


    "¡Arrancó la puerta entera de sus bisagras...!"


translate english e1154b_c082ff8c:


    "Cambia la palanca por su bate y luego se coloca en el marco de la puerta."


translate english e1154b_0b03da07:


    "Estoy atrapado..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
