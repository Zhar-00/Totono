

translate english b3124_e8641e55:



    voice "voice/b31/2400010a02.opus"
    aoi "\"The game has been recoded so that you and Miyuki can be together.\""


translate english b3124_a90761cd:



    voice "voice/b31/2400020a02.opus"
    aoi "\"Now you'll never, ever be cucked.\""


translate english b3124_410ae3e4:



    voice "voice/b31/2400030a02.opus"
    aoi "\"So you don't have to worry about anything anymore.\""


translate english b3124_d04076dd:



    voice "voice/b31/2400040a02.opus"
    aoi "\"You can love Miyuki as much as you want.\""


translate english b3124_61cd6c01:


    xy "\"Oh... Right.\""


translate english b3124_bf9e5cd3:


    xy "\"Thanks.\""


translate english b3124_13523571:



    voice "voice/b31/2400050a02.opus"
    aoi "\"No prob.\""


translate english b3124_0638f48b:


    "No puedo ver al dios de Aoi."


translate english b3124_08efbca4:


    "Sé la diferencia entre realidad y ficción. No estoy lo bastante loco para creer que su dios de verdad me ayudará."


translate english b3124_664366c0:


    "Pero Aoi está rezando por mí..."


translate english b3124_d22e81f0:


    "Y la intención es lo que cuenta."


translate english b3124_df24edc4:


    xy "\"Anyway, let's go find Miyuki.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
