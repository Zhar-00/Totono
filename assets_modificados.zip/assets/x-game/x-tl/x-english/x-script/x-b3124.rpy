

translate english b3124_e8641e55:



    voice "voice/b31/2400010a02.opus"
    aoi "\"El juego fue recodificado para que tú y Miyuki puedan estar juntos.\""


translate english b3124_a90761cd:



    voice "voice/b31/2400020a02.opus"
    aoi "\"Ahora nunca, jamás te pondrán los cuernos.\""


translate english b3124_410ae3e4:



    voice "voice/b31/2400030a02.opus"
    aoi "\"Así que ya no tienes que preocuparte por nada.\""


translate english b3124_d04076dd:



    voice "voice/b31/2400040a02.opus"
    aoi "\"Puedes amar a Miyuki tanto como quieras.\""


translate english b3124_61cd6c01:


    xy "\"Oh... Cierto.\""


translate english b3124_bf9e5cd3:


    xy "\"Gracias.\""


translate english b3124_13523571:



    voice "voice/b31/2400050a02.opus"
    aoi "\"No hay problema.\""


translate english b3124_0638f48b:


    "No puedo ver al dios de Aoi."


translate english b3124_08efbca4:


    "Sé la diferencia entre realidad y ficción. No estoy lo bastante loco para creer que su dios de verdad me ayudará."


translate english b3124_664366c0:


    "Pero Aoi está rezando por mí..."


translate english b3124_d22e81f0:


    "Y la intención es lo que cuenta."


translate english b3124_df24edc4:


    xy "\"En fin, vamos a buscar a Miyuki.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
