

translate english a1202_14ea5d4a:


    xy "\"¿Eh...?\""


translate english a1202_f67c1031:


    "La puerta ya está abierta."


translate english a1202_98196bcb:


    "Está perfectamente silencioso aquí arriba, en la azotea."


translate english a1202_6b9d1dac:


    "Ni un alma a la vista."


translate english a1202_f774cf43:


    "Y probablemente está completamente sola."


translate english a1202_e000d63c:



    voice "voice/a12/0200010a02.opus"
    aoi "\"\"......\"\""


translate english a1202_f1b84f4c:


    xy "\"Justo como pensé.\""


translate english a1202_992e530e:


    "Me volteo y encuentro a Aoi de pie, en silencio, arriba en la azotea sobre las escaleras."


translate english a1202_681acf16:


    "Sus ojos están fijos en algo más allá de los confines más lejanos del cielo."


translate english a1202_cd44796f:


    "Algo sin forma e imperceptible."


translate english a1202_54a8ebd7:


    "O quizá no está mirando nada en absoluto."


translate english a1202_869a2a13:


    "Es un día brillante y soleado."


translate english a1202_8688038b:


    "Mientras contemplo el cielo otoñal azul despejado, me descubro preguntándome si Dios de verdad contestará el teléfono esta vez."


translate english a1202_04feb7a3:


    xy "\"Voy a subir, ¿ok?\""


translate english a1202_e2344fad:


    xy "\"Whoa...\""


translate english a1202_513626b5:


    xy "\"Ja... jaja...\""


translate english a1202_85cd0bca:


    xy "\"¡Santo cielo...!\""


translate english a1202_323b5a66:


    "Es una locura la diferencia que pueden marcar unos cuantos metros extra."


translate english a1202_7f267147:


    "Aquí arriba me recibe una vista perfectamente despejada de 360 grados de todo el pueblo."


translate english a1202_a06814fe:


    xy "\"¡Vaya vista tan impresionante!\""


translate english a1202_a5ed88a7:



    voice "voice/a12/0200020a02.opus"
    aoi "\"Por supuesto.\""


translate english a1202_21c65859:


    "Aoi no aparta los ojos del cielo ni un solo momento."


translate english a1202_765c07d1:



    voice "voice/a12/0200030a02.opus"
    aoi "\"Este es un lugar especial.\""


translate english a1202_cb7e5874:


    "Un lugar secreto en la cúspide de una tierra prohibida..."


translate english a1202_c3c55b88:


    "Sí, puedo ver por qué Aoi podría sentirse así."


translate english a1202_55f3ab2f:


    xy "\"¿Almorzaste?\""


translate english a1202_aa94bdf7:



    voice "voice/a12/0200040a02.opus"
    aoi "\"Sí.\""


translate english a1202_fc2d7517:


    "Junto a ella hay una bolsa de plástico para llevar llena de basura."


translate english a1202_5fb18f96:


    "Puedo oler tenues rastros de algo empalagosamente dulce, como pastel o mermelada."


translate english a1202_6c6ebc40:


    xy "\"Deberías tratar de comer mejor.\""


translate english a1202_5782a3d4:



    voice "voice/a12/0200050a02.opus"
    aoi "\"¿Mejor?\""


translate english a1202_045a24bc:


    xy "\"Ya sabes, algo con un balance de nutrientes—\""


translate english a1202_c246bb60:



    voice "voice/a12/0200060a02.opus"
    aoi "\"¿ESO está balanceado?\""


translate english a1202_407ffe93:


    "Aoi señala la bolsa que contiene mi almuerzo."


translate english a1202_f211c974:


    "Todo lo que hay dentro grita carbohidratos cargados de calorías, desde el sándwich de yakisoba hasta las croquetas y los panecillos de curry."


translate english a1202_66644a3a:


    xy "\"Lo que pasa con mi almuerzo es que tengo uno de ESTOS chicos malos.\""


translate english a1202_3dcb3d7b:



    voice "voice/a12/0200070a02.opus"
    aoi "\"¿Bip bip?\""


translate english a1202_1cd42960:


    "Coloco una pequeña lata de metal frente a ella."


translate english a1202_e800657a:


    xy "\"De Yabaley.\""


translate english a1202_d606480c:



    voice "voice/a12/0200080a02.opus"
    aoi "\"¿Naranja de Yabaley—no, jugo de Tomate?\""


translate english a1202_e3570f9e:


    xy "\"Así también tomo una ración de verduras. Problema resuelto.\""


translate english a1202_d42ffd11:



    voice "voice/a12/0200090a02.opus"
    aoi "\"Bip bip...\""


translate english a1202_4032d105:


    "Lo mira como si fuera una reliquia del Área 51."


translate english a1202_df6680d0:


    xy "\"Ggllpp... ggllpp... ggllpp...\""


translate english a1202_3de73a0c:


    xy "\"¡Uf!\""


translate english a1202_98722c60:



    voice "voice/a12/0200100a02.opus"
    aoi "\"¿Está rico?\""


translate english a1202_2d3f8315:


    xy "\"Sí.\""


translate english a1202_1e68fcbe:


    "...En realidad no es tan buena."


translate english a1202_457c75c2:


    "A decir verdad, no soy muy fanático del jugo de tomate."


translate english a1202_3f8046d4:


    "Es solo que... quizá pulsé el botón equivocado en la máquina expendedora por accidente."


translate english a1202_bd8ec965:


    xy "\"¿Quieres probarlo?\""


translate english a1202_474e0d77:



    voice "voice/a12/0200110a02.opus"
    aoi "\"¿Está bien?\""


translate english a1202_02488e53:


    xy "\"Claro.\""


translate english a1202_a95e6437:


    "Demonios, puede quedarse con el resto, no me importa."


translate english a1202_597635d6:



    voice "voice/a12/0200120a02.opus"
    aoi "\"Ggllpp... ggllpp... ggllpp...\""


translate english a1202_27050b11:


    "Empieza a beber—"


translate english a1202_aeb452cd:



    voice "voice/a12/0200130a02.opus"
    aoi "\"¿Ggllpp...? ¡Ggllpp...! Ggllpp... ggllpp... ggllpp... ggllpp... ggllpp...\""


translate english a1202_d41ccc33:


    "—y beber, y beber, y beber."



translate english a1202_d4f28108:



    voice "voice/a12/0200140a02.opus"
    aoi "\"¡Uf...!\""


translate english a1202_025783f3:


    xy "\"¿Te lo tomaste todo de un trago?\""


translate english a1202_9ff5ecda:



    voice "voice/a12/0200150a02.opus"
    aoi "\"...¿Eso es malo?\""


translate english a1202_bf0b4b0c:


    xy "\"No, no, no estoy enojado ni nada.\""


translate english a1202_6301f6b3:


    xy "\"¿Te gustó?\""


translate english a1202_18c87769:



    voice "voice/a12/0200160a02.opus"
    aoi "\"¡Sí!\""


translate english a1202_acee720d:



    voice "voice/a12/0200170a02.opus"
    aoi "\"¡Es como el curry, o el taiyaki, o los panecillos de melón! ¡Por ahí!\""


translate english a1202_eaaf6f97:


    "No entiendo mucho la comparación, pero está bien..."


translate english a1202_ee3f2ab0:


    xy "\"Me alegra que te gustara.\""


translate english a1202_4d325f37:



    voice "voice/a12/0200180a02.opus"
    aoi "\"Oh...\""


translate english a1202_f0f916ef:


    xy "\"¿Hmm?\""


translate english a1202_930d27a5:



    voice "voice/a12/0200190a02.opus"
    aoi "\"¿Fue un beso indirecto?\""


translate english a1202_91c49ca2:



    voice "voice/a12/0200200a02.opus"
    aoi "\"¿Estás tratando de activar la bandera de ruta de Aoi?\""


translate english a1202_c2b084b0:


    "Vale, ahora lo arruinaste."


translate english a1202_dc2fa4a7:


    xy "\"De verdad amas los videojuegos, ¿eh?\""


translate english a1202_f708d053:



    voice "voice/a12/0200210a02.opus"
    aoi "\"Todo este mundo es un juego.\""


translate english a1202_23c90f98:



    voice "voice/a12/0200220a02.opus"
    aoi "\"La opinión de Aoi no tiene nada que ver.\""


translate english a1202_8fedf4eb:


    xy "\"Cierto...\""


translate english a1202_954af5a7:


    "Miyuki odia la idea de que alguien trate la realidad como un juego."


translate english a1202_0a2b5bd6:


    "Pero Aoi cree que son una y la misma cosa."


translate english a1202_be7cc6da:


    "Es natural que nunca se lleven bien..."


translate english a1202_2658e101:


    "Y sin embargo aquí estoy, intentando que suceda de todos modos."


translate english a1202_cc581427:


    xy "\"Perdón, Aoi.\""


translate english a1202_3e0b981e:


    xy "\"Yo fui quien te dijo que hicieras amigos con ella, y ahora es mi culpa que salieras herida.\""


translate english a1202_3cfa4221:



    voice "voice/a12/0200230a02.opus"
    aoi "\"¿Aoi salió herida?\""


translate english a1202_f87a65bf:


    "Aoi ladea la cabeza."


translate english a1202_0bb8441c:



    voice "voice/a12/0200240a02.opus"
    aoi "\"¿Qué es... herida?\""


translate english a1202_13ef7b8b:


    xy "\"Bueno, no se siente bien que Miyuki te ignore todos los días, ¿verdad?\""


translate english a1202_0a2b1ffa:



    voice "voice/a12/0200250a02.opus"
    aoi "\"Bip bip...\""


translate english a1202_4dbecfb5:



    voice "voice/a12/0200260a02.opus"
    aoi "\"No sé...\""


translate english a1202_bfd7fa2b:



    voice "voice/a12/0200270a02.opus"
    aoi "\"Aoi tiene un archivo guardado.\""


translate english a1202_1f8c8e69:



    voice "voice/a12/0200280a02.opus"
    aoi "\"Cualquier error se puede reiniciar. Aoi puede recargar tantas veces como haga falta.\""


translate english a1202_49acb998:



    voice "voice/a12/0200290a02.opus"
    aoi "\"Eso es todo lo que hay.\""


translate english a1202_6065b4cc:



    voice "voice/a12/0200300a02.opus"
    aoi "\"¿Verdad?\""


translate english a1202_0accd139:


    xy "\"\"......\"\""


translate english a1202_57d63eb2:


    "No estoy seguro de qué decirle."


translate english a1202_63bcbbb8:


    "Resulta que no ha estado aguantando el dolor."


translate english a1202_40c42dc2:


    "No lo sintió en primer lugar."


translate english a1202_f13e5c2c:


    "Se dice a sí misma que puede arreglar sus errores empezando de nuevo, permitiéndose huir de la dura realidad de sus acciones. Dejándose olvidar."


translate english a1202_a0efaad9:


    "Supongo que ella tampoco lo ha pensado críticamente ni una vez."


translate english a1202_50419603:


    xy "\"...Falso.\""


translate english a1202_442caa7d:


    "Esa no es forma de vivir."


translate english a1202_402724af:


    "Necesita estabilidad en su vida."


translate english a1202_9ad69f2d:


    "Y necesita amigos."


translate english a1202_04011906:



    voice "voice/a12/0200310a02.opus"
    aoi "\"¿Shinichi?\""


translate english a1202_9eed91cd:


    xy "\"En fin, ¡hora de comer! Ñam ñam...\""


translate english a1202_6feb7e60:


    "Mientras le doy un mordisco a mi croqueta, tomo mi decisión."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
