

translate english a6182a_e625085e:


    "Me acerco y miro el bate tirado en el suelo."


translate english a6182a_d5e20e19:


    "Hay sangre en el mango, de donde Aoi lo sostenía."


translate english a6182a_b34f383d:


    "Lentamente, lo recojo—"


translate english a6182a_8c9d8d7a:



    voice "voice/a61/82a00010a02.opus"
    aoi "\"¿Shinichi?\""


translate english a6182a_09e7f168:


    "—y me paro en el área de bateo."


translate english a6182a_646c624a:


    "Adopto mi postura de bateo."


translate english a6182a_60394c23:


    "Luego concentro mi energía en todo lo que está directamente frente a mí."


translate english a6182a_97094fc0:


    "¿Qué me ha pasado?"


translate english a6182a_e62911f9:


    "Ni yo mismo estoy del todo seguro."


translate english a6182a_276b9e74:


    "Normalmente nunca llegaría tan lejos."


translate english a6182a_4bc54b5c:


    "En cambio, encontraría la forma de zafarme."


translate english a6182a_a5774138:


    "Y aun así, aquí estoy."


translate english a6182a_d016e37d:


    "Quizá tenga que agradecérselo a Aoi."


translate english a6182a_e71a73d2:


    "Puedo sentir mi corazón latiendo fuerte."


translate english a6182a_09910ac7:


    "No me había sentido así en años."


translate english a6182a_fb984d10:


    "La máquina lanzapelotas disparará la pelota, y con una forma perfecta a la altura de la de Miyuki, la enviaré de vuelta como un cohete—"


translate english a6182a_bae3e54a:


    "—directly into the \"Home Run\"objetivo."


translate english a6182a_6a5fbb38:


    "He tenido esta misma fantasía mil veces."


translate english a6182a_90e7507f:


    "La máquina lanzapelotas dispara la pelota."


translate english a6182a_f8729f46:


    "Hasta ahora, todo bien—"


translate english a6182a_e889e7b4:


    xy "\"¡Miyuki...!\""


translate english a6182a_549a914f:


    "Mi swing falla por completo."


translate english a6182a_50c912c5:


    "De inmediato me derrumbo al suelo."


translate english a6182a_0a60832b:


    xy "\"¡Jaja!\""


translate english a6182a_fdd06e35:


    xy "\"¡Jajaja! Jaja... ¡jajajajajaja!\""


translate english a6182a_91f458cf:



    voice "voice/a61/82a00020a02.opus"
    aoi "\"¡Shinichi!\""


translate english a6182a_9afea137:


    "Mierda."


translate english a6182a_f957b3fe:


    "No puedo dejar de reír."


translate english a6182a_4ba6124e:


    "No tengo excusa para esa vergonzosa demostración."


translate english a6182a_2448fca0:


    "Fallé en conectar un jonrón."


translate english a6182a_4d77cf05:


    "Fallé en hacer que ocurriera un milagro."


translate english a6182a_76dd2e33:


    "Y aun así..."


translate english a6182a_32322891:


    "De algún modo, siento que estoy en la gloria."


translate english a6182a_16f1fc97:



    voice "voice/a61/82a00030a02.opus"
    aoi "\"¿Shinichi?\""


translate english a6182a_2b30ab40:


    xy "\"Gracias, Aoi.\""


translate english a6182a_04c61cc1:


    xy "\"Con tu ayuda, por fin volví a batear.\""


translate english a6182a_1d4e11c4:


    xy "\"Ahora puedo empezar de nuevo.\""


translate english a6182a_ed2cc6af:


    xy "\"No es demasiado tarde, ¿verdad?\""


translate english a6182a_8005be4b:



    voice "voice/a61/82a00040a02.opus"
    aoi "\"Oh...\""


translate english a6182a_c1357a91:



    voice "voice/a61/82a00050a02.opus"
    aoi "\"¡Cierto!\""


translate english a6182a_eeb475e9:


    xy "\"Perdón, pero tengo que ir a un lugar.\""


translate english a6182a_4c2763d4:


    xy "\"¡Voy a ver a Miyuki!\""


translate english a6182a_f0485a43:


    xy "\"¡Y esta vez le voy a decir lo que siento!\""


translate english a6182a_a4a46bce:



    voice "voice/a61/82a00060a02.opus"
    aoi "\"¡Entendido!\""


translate english a6182a_9105c636:


    "Mientras me preparo para despegar, Aoi alza la mano."


translate english a6182a_f5fcb334:



    voice "voice/a61/82a00070a02.opus"
    aoi "\"¡Shinichi, eres tan genial!\""


translate english a6182a_c67889cc:


    xy "\"¡Qué va!\""


translate english a6182a_05917dc7:



    voice "voice/a61/82a00080a02.opus"
    aoi "\"¡No, en serio! ¡Eres el más genial!\""


translate english a6182a_c962b850:



    voice "voice/a61/82a00090a02.opus"
    aoi "\"Hasta que nos volvamos a ver...\""


translate english a6182a_e6bc73f2:



    voice "voice/a61/82a00100a02.opus"
    aoi "\"¡Una Aoi totalmente nueva te estará esperando en otra ruta!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
