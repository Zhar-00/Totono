

translate english e2225f_517197e4:



    voice "voice/e22/25f00010a01.opus"
    mx "No puedo creer que hicieras tanto desastre... y encima por todo mi cosplay..."



translate english e2225f_ad20832c:



    voice "voice/e22/25f00020a01.opus"
    mx "Debes ser todo un pequeño pervertido, ¿hm?"


translate english e2225f_fa232347:



    voice "voice/e22/25f00030a01.opus"
    mx "Pero... está bien..."


translate english e2225f_d65172af:



    voice "voice/e22/25f00040a01.opus"
    mx "Te amaré de todos modos..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
