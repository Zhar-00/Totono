

translate english c4111_773c6436:



    voice "voice/c41/1100010a02.opus"
    aoi "\"Ggllpp... ggllpp... ggllpp... Whew!\""


translate english c4111_fdc41589:



    voice "voice/c41/1100020a02.opus"
    aoi "\"Yummy.\""


translate english c4111_4cf0293e:



    voice "voice/c41/1100030a02.opus"
    aoi "\"Yabaley's is godlike.\""


translate english c4111_8139d42b:



    voice "voice/c41/1100040a02.opus"
    aoi "\"Don't you think, Shinichi?\""


translate english c4111_1fac9a74:



    voice "voice/c41/1100050a02.opus"
    aoi "\"Shinichi? What's wrong?\""


translate english c4111_61d063a0:


    xy "\"Oh, nothing! Nothing at all!\""


translate english c4111_345526f1:



    voice "voice/c41/1100060a02.opus"
    aoi "\"You're spacing out.\""


translate english c4111_69ada052:


    xy "\"I just... didn't get much sleep last night.\""


translate english c4111_ae791946:


    "Durante todo el desayuno..."


translate english c4111_93ca8d6d:


    "Por alguna razón, no puedo dejar de mirar sus labios."


translate english c4111_1bb488ce:


    "...Dios, soy un desastre."


translate english c4111_636f5735:


    "Después de todo lo que pasó ayer, ya no sé cómo interactuar con ella."


translate english c4111_374f19fc:


    "Para distraerme, miro hacia abajo, a Eru lamiendo su leche."


translate english c4111_6cb0e074:


    "No me entusiasma la idea de dejar a la cosita completamente solo mientras nos vamos a la escuela..."


translate english c4111_5af510bd:



    voice "voice/c41/1100070a02.opus"
    aoi "\"Aoi's going to skip school today.\""


translate english c4111_d27eeafa:


    xy "\"Huh?\""


translate english c4111_a4080390:



    voice "voice/c41/1100080a02.opus"
    aoi "\"Aoi will stay here and look after Eru.\""


translate english c4111_1c0fa221:



    voice "voice/c41/1100090a02.opus"
    aoi "\"That way you won't have to worry.\""


translate english c4111_b25fcb2b:


    xy "\"We can just let it run around on the roof while we're in class.\""


translate english c4111_e69a44fe:



    voice "voice/c41/1100100a02.opus"
    aoi "\"But if someone goes up there—\""


translate english c4111_bf5ec55f:


    xy "\"No one's gonna go up there, trust me.\""


translate english c4111_37630455:



    voice "voice/c41/1100110a02.opus"
    aoi "\"But—\""


translate english c4111_48de2217:


    xy "\"Besides, don't you want to patch things up with Miyuki?\""


translate english c4111_937c4b6b:



    voice "voice/c41/1100120a02.opus"
    aoi "\"Boop boop...\""


translate english c4111_2bcbc1d6:


    xy "\"Let me handle it. I stayed up all night coming up with a plan.\""


translate english c4111_af26abef:


    "Mi mirada se desvía en dirección al miau. Ahí encuentro a Eru ya acurrucado ordenadamente en su transportadora."


translate english c4111_b46eaab8:


    "Casi como si el gatito intentara reforzar mi argumento..."


translate english c4111_4665fcf6:



    voice "voice/c41/1100140a02.opus"
    aoi "\"...Okay.\""


translate english c4111_c09d7876:



    voice "voice/c41/1100150a02.opus"
    aoi "\"Aoi will go to school.\""


translate english c4111_36ab4625:



    voice "voice/c41/1100160a02.opus"
    aoi "\"And Aoi will patch things up with Miyuki, too.\""


translate english c4111_d5c85d47:


    xy "\"Good! I'm glad.\""


translate english c4111_6b8f59d1:


    "A mis pies, Eru maúlla feliz."


translate english c4111_f106e9bd:


    xy "\"You know, sometimes it feels like the little furball can understand what we're saying.\""


translate english c4111_3f8ca034:



    voice "voice/c41/1100180a02.opus"
    aoi "\"He's a transceiver cat.\""


translate english c4111_44face35:


    xy "\"What does THAT mean?\""


translate english c4111_fb616554:


    "O sea, seguro, el pequeño mechón de pelaje blanco en su frente SÍ se parece un poco a un rayo, pero..."


translate english c4111_926fce72:



    voice "voice/c41/1100190a02.opus"
    aoi "\"He can use his whiskers to pick up electromagnetic waves.\""


translate english c4111_ccc3d695:



    voice "voice/c41/1100200a02.opus"
    aoi "\"And he can use his cat vision to see an infinite number of possible worlds.\""


translate english c4111_d38fca29:


    xy "\"He can... see different worlds...?\""


translate english c4111_f68f701b:



    voice "voice/c41/1100210a02.opus"
    aoi "\"It's kinda weird. Like sci-fi.\""


translate english c4111_c233a5b0:


    xy "\"C'mon, there's no way—\""


translate english c4111_c415f8e5:


    "Eru interrumpe mi escepticismo con un miau."


translate english c4111_c0770673:


    "Qué criatura tan extraña..."




translate english c4111_12e64a21:


    xy "\"......\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
