

translate english c4111_773c6436:



    voice "voice/c41/1100010a02.opus"
    aoi "\"Ggllpp... ggllpp... ggllpp... ¡Uf!\""


translate english c4111_fdc41589:



    voice "voice/c41/1100020a02.opus"
    aoi "\"Delicioso.\""


translate english c4111_4cf0293e:



    voice "voice/c41/1100030a02.opus"
    aoi "\"Yabaley's es divino.\""


translate english c4111_8139d42b:



    voice "voice/c41/1100040a02.opus"
    aoi "\"¿No crees, Shinichi?\""


translate english c4111_1fac9a74:



    voice "voice/c41/1100050a02.opus"
    aoi "\"¿Shinichi? ¿Qué pasa?\""


translate english c4111_61d063a0:


    xy "\"¡Oh, nada! ¡Nada en absoluto!\""


translate english c4111_345526f1:



    voice "voice/c41/1100060a02.opus"
    aoi "\"Estás distraído.\""


translate english c4111_69ada052:


    xy "\"Es solo que... no dormí mucho anoche.\""


translate english c4111_ae791946:


    "Durante todo el desayuno..."


translate english c4111_93ca8d6d:


    "Por alguna razón, no puedo dejar de mirar sus labios."


translate english c4111_1bb488ce:


    "...Dios, soy un desastre."


translate english c4111_636f5735:


    "Después de todo lo que pasó ayer, ya no sé cómo interactuar con ella."


translate english c4111_374f19fc:


    "Para distraerme, miro hacia abajo, a Eru lamiendo su leche."


translate english c4111_6cb0e074:


    "No me entusiasma la idea de dejar a la cosita completamente solo mientras nos vamos a la escuela..."


translate english c4111_5af510bd:



    voice "voice/c41/1100070a02.opus"
    aoi "\"Aoi va a faltar a la escuela hoy.\""


translate english c4111_d27eeafa:


    xy "\"¿Eh?\""


translate english c4111_a4080390:



    voice "voice/c41/1100080a02.opus"
    aoi "\"Aoi se quedará aquí y cuidará de Eru.\""


translate english c4111_1c0fa221:



    voice "voice/c41/1100090a02.opus"
    aoi "\"Así no tendrás de qué preocuparte.\""


translate english c4111_b25fcb2b:


    xy "\"Podemos dejarlo corretear por la azotea mientras estamos en clase.\""


translate english c4111_e69a44fe:



    voice "voice/c41/1100100a02.opus"
    aoi "\"Pero si alguien sube ahí—\""


translate english c4111_bf5ec55f:


    xy "\"Nadie va a subir ahí, confía en mí.\""


translate english c4111_37630455:



    voice "voice/c41/1100110a02.opus"
    aoi "\"Pero—\""


translate english c4111_48de2217:


    xy "\"Además, ¿no quieres arreglar las cosas con Miyuki?\""


translate english c4111_937c4b6b:



    voice "voice/c41/1100120a02.opus"
    aoi "\"Bip bip...\""


translate english c4111_2bcbc1d6:


    xy "\"Déjame encargarme. Me quedé despierta toda la noche ideando un plan.\""


translate english c4111_af26abef:


    "Mi mirada se desvía en dirección al miau. Ahí encuentro a Eru ya acurrucado ordenadamente en su transportadora."


translate english c4111_b46eaab8:


    "Casi como si el gatito intentara reforzar mi argumento..."


translate english c4111_4665fcf6:



    voice "voice/c41/1100140a02.opus"
    aoi "\"...Okay.\""


translate english c4111_c09d7876:



    voice "voice/c41/1100150a02.opus"
    aoi "\"Aoi irá a la escuela.\""


translate english c4111_36ab4625:



    voice "voice/c41/1100160a02.opus"
    aoi "\"Y Aoi también arreglará las cosas con Miyuki.\""


translate english c4111_d5c85d47:


    xy "\"¡Bien! Me alegra.\""


translate english c4111_6b8f59d1:


    "A mis pies, Eru maúlla feliz."


translate english c4111_f106e9bd:


    xy "\"Sabes, a veces parece que la bolita de pelo puede entender lo que decimos.\""


translate english c4111_3f8ca034:



    voice "voice/c41/1100180a02.opus"
    aoi "\"Es un gato transceptor.\""


translate english c4111_44face35:


    xy "\"¿Y eso QUÉ significa?\""


translate english c4111_fb616554:


    "O sea, seguro, el pequeño mechón de pelaje blanco en su frente SÍ se parece un poco a un rayo, pero..."


translate english c4111_926fce72:



    voice "voice/c41/1100190a02.opus"
    aoi "\"Puede usar sus bigotes para captar ondas electromagnéticas.\""


translate english c4111_ccc3d695:



    voice "voice/c41/1100200a02.opus"
    aoi "\"Y puede usar su visión felina para ver un número infinito de mundos posibles.\""


translate english c4111_d38fca29:


    xy "\"¿Puede... ver mundos diferentes...?\""


translate english c4111_f68f701b:



    voice "voice/c41/1100210a02.opus"
    aoi "\"Es algo raro. Como ciencia ficción.\""


translate english c4111_c233a5b0:


    xy "\"Vamos, no hay forma—\""


translate english c4111_c415f8e5:


    "Eru interrumpe mi escepticismo con un miau."


translate english c4111_c0770673:


    "Qué criatura tan extraña..."




translate english c4111_12e64a21:


    xy "\"......\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
