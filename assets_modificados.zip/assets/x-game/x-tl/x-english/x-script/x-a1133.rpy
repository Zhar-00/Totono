

translate english a1133_f56428b4:



    voice "voice/a11/3300010a01.opus"
    mx "\"I refuse.\""


translate english a1133_600c6371:



    voice "voice/a11/3300020a01.opus"
    mx "\"I feel that you and I are fundamentally incompatible.\""


translate english a1133_ff10c502:


    "Parece que es un no rotundo."


translate english a1133_94e592b9:


    "Aun así, tiene razón. No me imagino a las dos llevándose muy bien."


translate english a1133_87c978d1:



    voice "voice/a11/3300030a02.opus"
    aoi "\"Got it! Plan B.\""


translate english a1133_1396e85c:


    "Mukou sostiene su celular en el aire."


translate english a1133_d225aa88:


    xy "\"What the...?\""


translate english a1133_2d2b7ec5:



    voice "voice/a11/3300040a01.opus"
    mx "\"What exactly did you just do?\""


translate english a1133_ecf030e7:



    voice "voice/a11/3300050a02.opus"
    aoi "\"Photo mission.\""


translate english a1133_e7969d2c:



    voice "voice/a11/3300060a02.opus"
    aoi "\"I'll send this to the whole class.\""


translate english a1133_a3cec0be:


    xy "\"...Are you blackmailing us?\""


translate english a1133_b8a75e9b:



    voice "voice/a11/3300070a02.opus"
    aoi "\"Boop boop?\""


translate english a1133_f074903c:



    voice "voice/a11/3300080a02.opus"
    aoi "\"Is that bad?\""


translate english a1133_ed1ac1fc:


    "La expresión de su rostro es perfectamente inocente."


translate english a1133_85508eff:


    xy "\"Come on, Miyuki, explain to her—\""


translate english a1133_5a77373f:



    voice "voice/a11/3300090a01.opus"
    mx "\"Knock yourself out, Mukou-san.\""


translate english a1133_e4835a32:


    xy "\"...Are you serious?\""


translate english a1133_a689a6a2:



    voice "voice/a11/3300100a01.opus"
    mx "\"I mean, it's true Shinichi and I were up here together.\""


translate english a1133_3b7de962:



    voice "voice/a11/3300110a01.opus"
    mx "\"Maybe it'll give some people the wrong idea, but I can clear it up for them, no problem.\""


translate english a1133_a0502223:



    voice "voice/a11/3300120a01.opus"
    mx "\"If anything, being friends with someone like YOU would be way more embarrassing.\""


translate english a1133_7f0bd58d:



    voice "voice/a11/3300130a01.opus"
    mx "\"You know what? Let me say two things.\""


translate english a1133_cd90a3ba:



    voice "voice/a11/3300140a01.opus"
    mx "\"One...\""


translate english a1133_550571c8:



    voice "voice/a11/3300150a01.opus"
    mx "\"You're free to try all you like, but unless you make some serious changes, you'll never stand a chance at making any friends.\""


translate english a1133_678ecdbe:



    voice "voice/a11/3300160a01.opus"
    mx "\"Two...\""


translate english a1133_e0a9f44c:



    voice "voice/a11/3300170a01.opus"
    mx "\"Don't call me Miyuki.\""


translate english a1133_349c724c:



    voice "voice/a11/3300180a01.opus"
    mx "\"That's final.\""


translate english a1133_31a51b33:


    "Con eso, Miyuki se dirige a la puerta y baja las escaleras."


translate english a1133_98f55c07:


    "Mientras tanto, siento que me relajo. Sé que no me estaba gritando a mí, pero aun así."


translate english a1133_c713006d:



    voice "voice/a11/3300190a02.opus"
    aoi "\"She's so cool.\""


translate english a1133_6946b9b6:


    xy "\"You, uh... really march to the beat of your own drum, huh?\""


translate english a1133_85003b0c:



    voice "voice/a11/3300200a02.opus"
    aoi "\"Boop boop?\""


translate english a1133_62e442a2:


    "Mukou ladea la cabeza."


translate english a1133_695357d4:


    "Parece confundida, algo habitual en ella."


translate english a1133_8001697a:



    voice "voice/a11/3300210a02.opus"
    aoi "\"Bye-bye.\""


translate english a1133_c3958eb3:


    xy "\"Where are you going?\""


translate english a1133_21164cbe:



    voice "voice/a11/3300220a02.opus"
    aoi "\"The classroom.\""


translate english a1133_279af32b:


    "¿De verdad tiene la intención de mostrarle esa foto a todos...?"


translate english a1133_bc443767:


    xy "\"Miyuki's gonna get mad, you know.\""


translate english a1133_79f897ed:



    voice "voice/a11/3300230a02.opus"
    aoi "\"Why?\""


translate english a1133_721111a6:



    voice "voice/a11/3300240a02.opus"
    aoi "\"She gave permission.\""


translate english a1133_220d51b5:


    xy "\"Haah...\""


translate english a1133_2422933f:


    "En serio no tiene ni idea, ¿verdad?"


translate english a1133_4fe7c5a0:


    xy "\"Why are you trying to get me and Miyuki together in the first place?\""


translate english a1133_a2d01750:



    voice "voice/a11/3300250a02.opus"
    aoi "\"The protagonist needs to end up with the main heroine.\""


translate english a1133_7dcd28b7:



    voice "voice/a11/3300260a02.opus"
    aoi "\"Wouldn't make sense otherwise.\""


translate english a1133_43608eb8:



    voice "voice/a11/3300270a02.opus"
    aoi "\"So Aoi will request an update patch.\""


translate english a1133_6df57f04:


    xy "\"There you go with your dating sim nonsense again...\""


translate english a1133_23328d21:



    voice "voice/a11/3300280a02.opus"
    aoi "\"I'm gonna go now—\""


translate english a1133_061c5e6f:


    xy "\"Hold it!\""


translate english a1133_6cebb640:



    voice "voice/a11/3300290a02.opus"
    aoi "\"Boop boop...?\""


translate english a1133_a3ad9b09:


    "La expresión de Mukou cambia levemente, casi de forma imperceptible."


translate english a1133_d462d868:


    "Mientras tanto, estoy un poco sorprendido de haberle gritado hace un momento."


translate english a1133_99d759d4:


    "Obviamente no quiero que le muestre esa foto a nadie."


translate english a1133_0aea109c:


    "No cuando por fin empiezo a disfrutar mi vida como el marginado de la clase."


translate english a1133_a1689688:


    "Si empiezan a correr rumores de que un don nadie patético como yo intentó confesarle su amor a la reina Miyuki..."


translate english a1133_c2b977d0:


    "Solo pensarlo ya me pone nervioso."


translate english a1133_6d157805:


    "Debe de ser por eso que le grité a Mukou: para evitar que eso pasara."


translate english a1133_b11d686e:


    "...¿Verdad?"


translate english a1133_d7c55948:


    xy "\"Look... Didn't you JUST ask her to be your friend?\""


translate english a1133_845fc4df:


    xy "\"Isn't that what you want?\""


translate english a1133_df6e1db2:



    voice "voice/a11/3300300a02.opus"
    aoi "\"Friend...?\""


translate english a1133_a4d828a6:


    "Ladea la cabeza otra vez, como para considerar los méritos de la palabra."


translate english a1133_51050ac8:



    voice "voice/a11/3300310a02.opus"
    aoi "\"Aoi doesn't really understand... friends.\""


translate english a1133_dc746a70:


    "Recuerdo su agenda con su única entrada."


translate english a1133_8c8ed255:


    xy "\"Alright, tell you what.\""


translate english a1133_aaa4b238:


    "Saco mi teléfono del bolsillo."


translate english a1133_56fac0a5:


    xy "\"Let's trade email addresses.\""


translate english a1133_4336ef55:


    xy "\"It's the first step to making friends. Cool?\""


translate english a1133_99389b15:



    voice "voice/a11/3300320a02.opus"
    aoi "\"Trade... email addresses...?\""


translate english a1133_894bbad0:


    xy "\"You ready?\""


translate english a1133_91382bc8:



    voice "voice/a11/3300330a02.opus"
    aoi "\"How do you do it?\""


translate english a1133_c24d59b0:


    xy "\"...Oh, right.\""


translate english a1133_b9f681ff:


    "Obviamente nunca ha hecho esto antes."


translate english a1133_6413bd4b:


    xy "\"First you open this menu...\""
    xy "\"Okay, now to send me an email.\""



translate english a1133_4917ad07:


    xy "\"...What the?\""


translate english a1133_33b27b06:


    "Intento enviarme un correo usando su teléfono, pero no se envía."


translate english a1133_34c17009:


    xy "\"Do you not have service up here? That's so weird. My phone's getting full bars...\""


translate english a1133_59166d3e:



    voice "voice/a11/3300340a02.opus"
    aoi "\"Does this mean... we can't trade?\""


translate english a1133_02c599c1:


    "Por alguna razón, percibo tristeza en su expresión vacía. Pensando rápido, le dedico una sonrisa tranquilizadora."


translate english a1133_3e7e6df2:


    xy "\"Don't worry. We can just do it manually. Here.\""


translate english a1133_48e3d230:


    "Ingreso su número de teléfono y su correo en mi lista de contactos."


translate english a1133_e867bb56:


    "Luego se lo muestro, por si acaso."


translate english a1133_858a6ad6:


    xy "\"Is this correct?\""


translate english a1133_fca2c085:



    voice "voice/a11/3300350a02.opus"
    aoi "\"Uh huh.\""


translate english a1133_6f21d6a8:


    "Pasa un momento de silencio mientras ella mira de un teléfono al otro."



translate english a1133_b3266c54:


    xy "\"...What's wrong?\""


translate english a1133_3205a042:



    voice "voice/a11/3300360a02.opus"
    aoi "\"Got it! Plan B.\""


translate english a1133_360d8691:


    "Alza la mano."


translate english a1133_3696a47c:



    voice "voice/a11/3300370a02.opus"
    aoi "\"Does this make us friends?\""


translate english a1133_093d499b:


    xy "\"Yeah, I'd say so.\""


translate english a1133_0d8a0688:


    xy "\"Once you're in each other's phones, you're pretty much friends.\""


translate english a1133_c65ffb71:



    voice "voice/a11/3300380a02.opus"
    aoi "\"Shinichi... and Aoi... are friends?\""


translate english a1133_8f55bbae:


    xy "\"Yep. You and I are officially friends now.\""


translate english a1133_81318b7c:



    voice "voice/a11/3300390a02.opus"
    aoi "\"Friends...\""


translate english a1133_1b9c95fa:


    "Mukou mira, desconcertada, la nueva adición a su agenda."


translate english a1133_447975b4:


    "Pasa un largo momento."


translate english a1133_b8a7afdc:


    "Empieza a sentirse como si el tiempo se hubiera detenido a nuestro alrededor."


translate english a1133_256551dc:


    xy "\"We should probably head to class...\""


translate english a1133_42dd7c12:


    xy "\"...Uhh, earth to Mukou? You listening?\""


translate english a1133_ff81ccb5:



    voice "voice/a11/3300400a02.opus"
    aoi "\"Got it! Plan B.\""


translate english a1133_050d9951:


    "Una vez más, su mano se dispara recta hacia el aire."


translate english a1133_1ce0b383:



    voice "voice/a11/3300410a02.opus"
    aoi "\"Now that we're friends, you should call me Aoi.\""


translate english a1133_647fb9a6:


    "Ey, ey... no estoy seguro de eso..."


translate english a1133_2a824895:


    "Se siente un poco demasiado personal, demasiado pronto..."


translate english a1133_258a84a0:



    voice "voice/a11/3300420a02.opus"
    aoi "\"Is that bad?\""


translate english a1133_68384741:


    "Ay... no puedo decirle que no a esa cara..."


translate english a1133_5757470d:


    xy "\"Alright.\""


translate english a1133_8a8cd389:


    "Sintiéndome un poco incómodo, me aclaro la garganta."


translate english a1133_f5d75230:


    xy "\"Let's go, Aoi.\""


translate english a1133_2f8dbeda:



    voice "voice/a11/3300430a02.opus"
    aoi "\"Sure thing, Shinichi.\""


translate english a1133_44d12300:


    "Al final, Aoi no le mostró la foto a nadie ese día."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
