

translate english e1134a_cc947ac4:


    xy "\"Sorry, Yuutarou! Gotta jet!\""


translate english e1134a_f1404dd6:


    "Agarro la mano de Miyuki y empiezo a correr."


translate english e1134a_f8870b68:



    voice "voice/e11/34a00010a01.opus"
    mx "\"See you later, Akebono-kun!\""


translate english e1134a_4f8984de:



    voice "voice/e11/34a00020b01.opus"
    xtl "\"Uhh... okay! See ya!\""


translate english e1134a_1c981729:


    "Y así dejamos atrás a Yuutarou como si huyéramos de la escena."


translate english e1134a_da8a626e:


    xy "\"Man, Yuutarou was acting kinda weird back there...\""


translate english e1134a_5f2ccbbc:


    "Nos vemos todos los días en la escuela, y sin embargo hablaba como si no hubiéramos hablado en meses o algo así..."


translate english e1134a_9e673fee:


    "¿Y qué era eso de un accidente automovilístico...?"


translate english e1134a_11de2f4c:



    voice "voice/e11/34a00030a01.opus"
    mx "\"He's been a little distracted lately.\""


translate english e1134a_eb6b38df:


    xy "\"How so?\""


translate english e1134a_ff2cfa74:



    voice "voice/e11/34a00040a01.opus"
    mx "\"I heard he and Haru-chan are dating now.\""


translate english e1134a_ac52d179:


    xy "\"...For real?!\""


translate english e1134a_59bd3ade:



    voice "voice/e11/34a00050a01.opus"
    mx "\"For real.\""


translate english e1134a_9afea137:


    "Mierda."


translate english e1134a_33116136:


    "Si eso es cierto, entonces... el legado del Club de Chicos y Sueños llegará a su fin."



translate english e1134a_3a3db899:


    "No estoy seguro de si debería estar feliz o triste..."


translate english e1134a_06ee27ae:


    "Espera."


translate english e1134a_51e57764:


    "¿No son hermanos...?"


translate english e1134a_8cfb1cd8:


    "Caminamos a la escuela juntos, de la mano."


translate english e1134a_f4cc5adc:


    "De vez en cuando pasamos junto a alguien con el mismo uniforme, pero no me avergüenzo."


translate english e1134a_78b50b35:


    "Estoy orgulloso de ser el novio de Miyuki."


translate english e1134a_58574118:


    xy "\"Hey, so, where are we going?\""


translate english e1134a_eecd939d:



    voice "voice/e11/34a00060a01.opus"
    mx "\"To the center of the universe.\""


translate english e1134a_7adfba19:



    voice "voice/e11/34a00070a01.opus"
    mx "\"I've decided... to tell you the truth.\""


translate english e1134a_2d9a3f97:


    xy "\"Mmm...\""


translate english e1134a_5c79b855:


    "Sonrío para mí mismo."


translate english e1134a_950c34d0:


    "El sol se hunde tras el horizonte."


translate english e1134a_fb352f1a:


    "Sus rayos son deslumbrantes."


translate english e1134a_d0b9dcb6:



    voice "voice/e11/34a00080a01.opus"
    mx "\"Wait right there.\""


translate english e1134a_47405ead:


    "Miyuki pone su mano en la escalera que sube al techo sobre las escaleras—la cima misma de la azotea."


translate english e1134a_307c2a8c:



    voice "voice/e11/34a00090a01.opus"
    mx "\"No looking up!\""


translate english e1134a_9290963d:


    xy "\"I know, I know...\""


translate english e1134a_3c7aecc0:


    "Qué cliché..."


translate english e1134a_86932e7d:


    "Mientras tanto, Miyuki sube rápidamente a la cima del techo."


translate english e1134a_3d1befac:


    "Puedo verla silueteada contra el atardecer."


translate english e1134a_5ef0945e:


    "Su belleza tiene una cualidad llamativa, casi de otro mundo."


translate english e1134a_0faf8ade:



    voice "voice/e11/34a00100a01.opus"
    mx "\"You know why I brought you here today, right?\""


translate english e1134a_cca0b2f6:


    xy "\"Uh, no...? I have no clue.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
