

translate english e2172e_da494787:


    "\"Cooking 101.\""



translate english e2172e_02912a5f:



    voice "voice/e21/72e00010a01.opus"
    mx "\"...Oh, for crying out loud...\""


translate english e2172e_6ab61c32:


    xy "\"Hmm?\""



translate english e2172e_6212c1f4:



    voice "voice/e21/72e00020a01.opus"
    mx "\"What are you even going to do with four copies of the same cookbook?\""


translate english e2172e_63dd2c42:



    voice "voice/e21/72e00030a01.opus"
    mx "\"Are you just messing with me?\""


translate english e2172e_2e80aff4:


    xy "\"No...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
