

translate english e2172e_da494787:


    "\"Cocina para principiantes.\""



translate english e2172e_02912a5f:



    voice "voice/e21/72e00010a01.opus"
    mx "\"...Ay, por Dios...\""


translate english e2172e_6ab61c32:


    xy "\"¿Hmm?\""



translate english e2172e_6212c1f4:



    voice "voice/e21/72e00020a01.opus"
    mx "\"¿Qué vas a hacer con cuatro copias del mismo libro de cocina?\""


translate english e2172e_63dd2c42:



    voice "voice/e21/72e00030a01.opus"
    mx "\"¿Solo me estás tomando el pelo?\""


translate english e2172e_2e80aff4:


    xy "\"¿No...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
