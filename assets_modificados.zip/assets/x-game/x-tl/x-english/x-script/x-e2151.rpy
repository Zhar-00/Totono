

translate english e2151_ba29630c:



    voice "voice/e21/5100010a01.opus"
    mx "\"Sorry I took so long!\""


translate english e2151_a296f51a:


    xy "\"Oh, hey... Got some ice cream?\""


translate english e2151_324e04f0:



    voice "voice/e21/5100020a01.opus"
    mx "\"Yep! Here's yours.\""


translate english e2151_d1ccfac4:


    xy "\"Awesome, thanks.\""


translate english e2151_e8dac6a2:


    "Me tiende un sándwich de helado de vainilla."


translate english e2151_2a7548f7:


    xy "\"Sweet! That's my favorite! ...What'd you get?\""


translate english e2151_f7f0c332:


    "Miyuki saca helado de mochi para ella."


translate english e2151_f2c0365c:


    "Miyuki saca una paleta de sandía para ella."


translate english e2151_23e7b619:


    "Miyuki saca una paleta de chocolate para ella."


translate english e2151_68ce41bd:



    voice "voice/e21/5100040a01.opus"
    mx "\"I like to get these usually.\""


translate english strings:


    old "А ты уверена, что не растолстеешь?"
    new "¿Seguro que no vas a engordar?"


    old "Давай поделимся?"
    new "¿Vamos a medias?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
