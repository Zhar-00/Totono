

translate english e2151_ba29630c:



    voice "voice/e21/5100010a01.opus"
    mx "\"¡Perdón por tardar!\""


translate english e2151_a296f51a:


    xy "\"Oh, oye... ¿Tienes helado?\""


translate english e2151_324e04f0:



    voice "voice/e21/5100020a01.opus"
    mx "\"¡Síp! Aquí está el tuyo.\""


translate english e2151_d1ccfac4:


    xy "\"Genial, gracias.\""


translate english e2151_e8dac6a2:


    "Me tiende un sándwich de helado de vainilla."


translate english e2151_2a7548f7:


    xy "\"¡Bien! ¡Ese es mi favorito! ...¿Qué compraste?\""


translate english e2151_f7f0c332:


    "Miyuki saca helado de mochi para ella."


translate english e2151_f2c0365c:


    "Miyuki saca una paleta de sandía para ella."


translate english e2151_23e7b619:


    "Miyuki saca una paleta de chocolate para ella."


translate english e2151_68ce41bd:



    voice "voice/e21/5100040a01.opus"
    mx "\"Normalmente me gusta comprar estos.\""


translate english strings:


    old "А ты уверена, что не растолстеешь?"
    new "¿Seguro que no vas a engordar?"


    old "Давай поделимся?"
    new "¿Vamos a medias?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
