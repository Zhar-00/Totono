

translate english e1164_e89afc1c:


    "Unos minutos después..."


translate english e1164_05a59f95:


    "Llegamos a la casa de Yuutarou."


translate english e1164_6f09e0b5:



    voice "voice/e11/6400010b01.opus"
    xtl "\"¡Apenas llegué a tiempo!\""


translate english e1164_ad6e23a4:



    voice "voice/e11/6400020b03.opus"
    c "\"Bienvenido—¡Oh! ¡Onii-chan!\""


translate english e1164_bf8b3821:



    voice "voice/e11/6400030b01.opus"
    xtl "\"¡Ya llegué! ¿Dónde está Mukou?\""


translate english e1164_3fe77848:



    voice "voice/e11/6400040b03.opus"
    c "\"Se está cambiando allá atrás.\""


translate english e1164_2811d5ee:



    voice "voice/e11/6400050b01.opus"
    xtl "\"Ah, entiendo.\""


translate english e1164_c336ea8c:


    xy "\"¿Cambiándose?\""


translate english e1164_640241ed:



    voice "voice/e11/6400060b01.opus"
    xtl "\"Trabaja aquí medio tiempo.\""


translate english e1164_cbe5cd28:



    voice "voice/e11/6400070b01.opus"
    xtl "\"Digo, después de todo es la novia de Ryuujirou.\""


translate english e1164_b7a8c858:


    xy "\"¿Ryuu...jirou...?\""


translate english e1164_8aa2f597:


    "Una vez más, me doy cuenta de que no entiendo lo que dice Yuutarou."


translate english e1164_10a01745:


    "Está señalando a Haru-chan."


translate english e1164_bee71a87:


    "¡No hay forma de que Haru-chan sea Ryuujirou...!"


translate english e1164_ab964c40:



    voice "voice/e11/6400080b03.opus"
    c "\"Emm... ¿Quién es ese?\""


translate english e1164_0c09570c:


    xy "¿Por qué actúas como si nunca nos hubiéramos conocido?\""


translate english e1164_a7d098f7:



    voice "voice/e11/6400090b03.opus"
    c "\"Estamos... en el mismo club...?\""


translate english e1164_bf5b1725:



    voice "voice/e11/6400100b01.opus"
    xtl "\"¡Shinichi!\""


translate english e1164_5c0aee18:



    voice "voice/e11/6400110b01.opus"
    xtl "\"¡Eres un miembro valioso del Club de Chicos y Sueños!\""



translate english e1164_e7c4f49a:



    voice "voice/e11/6400120b01.opus"
    xtl "\"¡No pienso dejar que el club de teatro te robe!\""


translate english e1164_6e889241:


    xy "\"¿Yo... no estoy en el club de teatro...?\""


translate english e1164_ae85b599:


    xy "\"Haru-chan, ¿es cierto?\""


translate english e1164_492853ba:



    voice "voice/e11/6400130b03.opus"
    c "\"S-Sí... Definitivamente...\""


translate english e1164_0accd139:


    xy "\"\"\"......\"¿Qué?\"\""


translate english e1164_28edec60:


    "Mis recuerdos no coinciden con lo que ellos dicen."


translate english e1164_e234763d:


    "¿Se están burlando de mí ahora mismo?"


translate english e1164_e59f80b7:


    "¿O...?"


translate english e1164_d3eb6189:


    "¿Mis recuerdos... están mal...?"


translate english e1164_e3653616:



    voice "voice/e11/6400140a02.opus"
    aoi "\"¡Entendido!\""



translate english e1164_25b02aa0:


    "Justo entonces, una chica asoma desde el cuarto del fondo, con la mano en alto."


translate english e1164_ea4675d7:



    voice "voice/e11/6400150a02.opus"
    aoi "\"¿Tienes amnesia?\""


translate english e1164_f6883751:


    "Es... Aoi."


translate english e1164_495851ef:


    xy "\"......¿Qué?\""


translate english e1164_e7bf3ae4:


    xy "\"¿Qué demonios hace Aoi aquí?\""


translate english e1164_b3333edf:



    voice "voice/e11/6400160b01.opus"
    xtl "\"Como te dije, trabaja aquí medio tiempo—\""


translate english e1164_4d460da7:


    xy "\"¡No es eso lo que quiero decir!\""


translate english e1164_97ebcbcb:


    xy "\"¿¡No es una heroína de una novela visual...!?\""


translate english e1164_307f6fa5:



    voice "voice/e11/6400170a02.opus"
    aoi "\"¿Bup bup...?\""


translate english e1164_91b17c60:



    voice "voice/e11/6400180b01.opus"
    xtl "\"Si es una broma, no tiene gracia.\""


translate english e1164_d28d7b3d:



    voice "voice/e11/6400190b01.opus"
    xtl "\"Mukou está en nuestra clase, amigo.\""


translate english e1164_d8ceae61:


    xy "\"¿Ella es...?\""


translate english e1164_150acd9c:



    voice "voice/e11/6400200a02.opus"
    aoi "\"¡Entendido!\""



translate english e1164_395bfe02:


    "Aoi levanta la mano muy alto."


translate english e1164_195a0df3:



    voice "voice/e11/6400210a02.opus"
    aoi "\"Ven conmigo.\""



translate english e1164_d27eeafa:


    xy "\"¿Eh?\""


translate english e1164_995fa531:



    voice "voice/e11/6400220a02.opus"
    aoi "\"Por ahí.\""


translate english e1164_ca0e3960:


    "Al parecer, Aoi quiere hablar conmigo en privado..."


translate english e1164_c11501db:


    "A petición suya, la sigo afuera."


translate english e1164_0accd139_1:


    xy "\"\"\"......\"¿Qué?\"\""


translate english e1164_524371cf:



    voice "voice/e11/6400230a02.opus"
    aoi "\"\"\"......\"¿Qué?\"\""


translate english e1164_9f6ba599:


    "Afuera, frente a la tienda, se gira para encararme."


translate english e1164_816786db:


    "Cuanto más la miro, más segura estoy de ello: es IDÉNTICA a su versión del videojuego."


translate english e1164_f19695b2:



    voice "voice/e11/6400240a02.opus"
    aoi "\"Explícame algo.\""


translate english e1164_6754fb4f:



    voice "voice/e11/6400250a02.opus"
    aoi "\"¿Cómo te enteraste?\""


translate english e1164_f5025546:


    xy "\"¿Enterarme de qué?\""


translate english e1164_e5c67be1:



    voice "voice/e11/6400260a02.opus"
    aoi "\"De mi verdadera identidad.\""


translate english e1164_fee1bc47:


    "Entonces, ¿SÍ es un personaje de videojuego?"


translate english e1164_d36d52ba:



    voice "voice/e11/6400270a02.opus"
    aoi "\"Dime. ¿Cómo te enteraste?\""


translate english e1164_b978356e:


    xy "\"¿Cómo que cómo? ¡Estabas ahí mismo en el juego!\""


translate english e1164_b399a5e2:



    voice "voice/e11/6400280a02.opus"
    aoi "\"¿Este juego?\""


translate english e1164_6850a38c:


    "Saca su teléfono."


translate english e1164_46c8bcab:


    "La misma novela visual está en pantalla."


translate english e1164_7e564820:


    "Y la Aoi del juego..."


translate english e1164_1e90dbc4:


    "...es idéntica a la Aoi que tengo justo delante..."


translate english e1164_5c603fba:


    xy "\"¿¡Qué...!?\""


translate english e1164_1e6db202:


    "Levanto la vista y encuentro nubes oscuras de tormenta arremolinándose en el cielo sobre nosotros, donde antes solo había un atardecer."


translate english e1164_8dd37578:


    "Casi como un pequeño tifón, localizado enteramente sobre la escuela—"


translate english e1164_03c908a7:



    voice "voice/e11/6400290a02.opus"
    aoi "\"¡Dios...!\""


translate english e1164_1fd5d80a:


    "Aoi echa a correr."


translate english e1164_97e288a0:


    xy "\"¡¿Qué demonios?! ¡¿Aoi?! ¿Dónde estás—?\""


translate english e1164_77f2dcf8:



    voice "voice/e11/6400300a02.opus"
    aoi "\"¡Al centro del universo!\""


translate english e1164_05e8c05f:



    voice "voice/e11/6400310a02.opus"
    aoi "\"¡El universo va a recibir un parche de actualización!\""


translate english e1164_528876fa:


    xy "\"¿Un parche de actualización?\""


translate english e1164_7c279468:



    voice "voice/e11/6400320a02.opus"
    aoi "\"El mundo cambiará.\""


translate english e1164_4d823ca4:



    voice "voice/e11/6400330a02.opus"
    aoi "\"Una vez que Dios capte la señal...\""


translate english e1164_8c462929:



    voice "voice/e11/6400340a02.opus"
    aoi "\"El juego se volverá realidad.\""


translate english e1164_b5811851:


    "Las palabras de Miyuki resuenan en mis oídos."


translate english e1164_c1a62c82:


    "\"Alteraré este mundo.\""



translate english e1164_fbe8b2ac:


    "No entiendo..."


translate english e1164_b0022cd6:


    "¿Cómo puedo distinguir la realidad de la ficción...?"


translate english e1164_26b94e0c:


    "Se supone que Aoi era una heroína de novela visual."


translate english e1164_6674fdda:


    "¡Pero entonces la vi con mis propios ojos!"


translate english e1164_d7edb145:


    "No hay forma de que esto sea un sueño."


translate english e1164_3cfd0616:


    "Esto es la vida real."


translate english e1164_a1618fec:


    "Si todo lo que pasó hasta ayer era solo parte de un videojuego..."


translate english e1164_19391a34:


    "And that video game \"will become reality\"..."



translate english e1164_8faafddf:


    "Entonces eso significa..."


translate english e1164_346555cb:


    "¿Miyuki borrará a Aoi de la realidad?"


translate english e1164_4cd39df4:


    "Salgo corriendo a la azotea y me doy la vuelta."


translate english e1164_88048d92:


    "De pie en el centro del universo está—"


translate english e1164_bbefafcb:


    xy "\"¡Miyuki!\""



translate english e1164_4f98e4ac:



    voice "voice/e11/6400350a01.opus"
    mx "\"Shinichi...\""


translate english e1164_69f2d51e:



    voice "voice/e11/6400360a01.opus"
    mx "\"Y veo que Aoi está contigo.\""


translate english e1164_c9cdeb09:



    voice "voice/e11/6400370a02.opus"
    aoi "\"Miyuki, devuélveme el teléfono.\""


translate english e1164_35ab75b1:



    voice "voice/e11/6400380a01.opus"
    mx "\"Es demasiado tarde.\""


translate english e1164_a2e67e4d:



    voice "voice/e11/6400390a02.opus"
    aoi "\"Oh...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
