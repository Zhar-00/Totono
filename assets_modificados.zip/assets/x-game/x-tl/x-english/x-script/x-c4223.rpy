

translate english c4223_3be605f4:


    xy "\"...De acuerdo.\""


translate english c4223_6dee0f5a:


    "Si eso es lo que quiere, no diré que no."


translate english c4223_0ababde1:


    "Tengo esta sensación de que... si no le doy lo que quiere, va a desvanecerse hacia algún mundo lejano."


translate english c4223_857fc692:



    voice "voice/c42/2300010a02.opus"
    aoi "\"Bip bip...\""


translate english c4223_10e01223:



    voice "voice/c42/2300020a02.opus"
    aoi "\"Aoi puede sentir... tu electricidad...\""


translate english c4223_9bfea759:



    voice "voice/c42/2300030a02.opus"
    aoi "\"Chispazos... chispazos...\""


translate english c4223_245f75bc:



    voice "voice/c42/2300040a02.opus"
    aoi "\"Aoi ha querido... recargarse... desde hace tanto...\""


translate english c4223_10e5fc2c:



    voice "voice/c42/2300050a02.opus"
    aoi "\"Chispazos... chispazos...\""


translate english c4223_0fed9418:


    xy "\"Sí, ya me imagino.\""


translate english c4223_b8d29b13:


    xy "\"Siéntete libre de recargarte todo lo que quieras.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
