

translate english c4223_3be605f4:


    xy "\"...Alright.\""


translate english c4223_6dee0f5a:


    "Si eso es lo que quiere, no diré que no."


translate english c4223_0ababde1:


    "Tengo esta sensación de que... si no le doy lo que quiere, va a desvanecerse hacia algún mundo lejano."


translate english c4223_857fc692:



    voice "voice/c42/2300010a02.opus"
    aoi "\"Boop boop...\""


translate english c4223_10e01223:



    voice "voice/c42/2300020a02.opus"
    aoi "\"Aoi can feel... your electricity...\""


translate english c4223_9bfea759:



    voice "voice/c42/2300030a02.opus"
    aoi "\"Zappy... zappy...\""


translate english c4223_245f75bc:



    voice "voice/c42/2300040a02.opus"
    aoi "\"Aoi has... wanted to recharge... for so long...\""


translate english c4223_10e5fc2c:



    voice "voice/c42/2300050a02.opus"
    aoi "\"Zappy... zappy...\""


translate english c4223_0fed9418:


    xy "\"Yeah, I bet.\""


translate english c4223_b8d29b13:


    xy "\"Feel free to recharge as much as you like.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
