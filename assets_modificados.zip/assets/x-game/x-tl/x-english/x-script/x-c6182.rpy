

translate english c6182_0accd139:


    xy "\"\"......Ugh.\"\""


translate english c6182_89efc76f:


    "El apartamento está vacío."


translate english c6182_d3efad94:


    "Con todos los muebles de lujo, difícilmente puedo imaginar a un estudiante de secundaria común viviendo aquí."


translate english c6182_ba051297:


    "Pero de cualquier manera, no hay nadie aquí."


translate english c6182_337906a8:



    voice "voice/c61/8200010a01.opus"
    mx "Y tampoco hay zapatos junto a la puerta.\""


translate english c6182_84b52d69:



    voice "voice/c61/8200020b01.opus"
    xtl "\"So they didn't come here...?\""


translate english c6182_84d829b2:



    voice "voice/c61/8200030a01.opus"
    mx "\"No, they definitely did.\""


translate english c6182_f797f398:



    voice "voice/c61/8200040a01.opus"
    mx "\"The tub is wet. And the water from the faucet is still warm.\""


translate english c6182_4b8bc94d:



    voice "voice/c61/8200050a01.opus"
    mx "\"Ryuujirou left the corner store with Aoi.\""


translate english c6182_4eb05fc3:



    voice "voice/c61/8200060a01.opus"
    mx "\"Then, at some point afterwards, someone took a shower here.\""


translate english c6182_d5891edc:


    xy "\"...That's just circumstantial evidence...\""


translate english c6182_65392059:



    voice "voice/c61/8200070a01.opus"
    mx "\"True. As of right now, we don't have any concrete proof.\""


translate english c6182_55d5d46c:


    xy "\"Yuutarou, is it cool if I poke around?\""


translate english c6182_96dbf7e6:



    voice "voice/c61/8200080b01.opus"
    xtl "\"Whatever you wanna do, buddy.\""


translate english c6182_bf08cf67:


    "Estaría mintiendo si dijera que no tengo miedo."


translate english c6182_6a0371bc:


    "Pero quizás hay una posibilidad de que pueda encontrar pruebas de su inocencia."


translate english c6182_12e64a21:


    xy "\"......\""


translate english c6182_801075e2:


    "Asiento en silencio."


translate english c6182_2b81ec41:


    "No quiero mirar."


translate english c6182_7a988d14:


    "No quiero encontrar nada."


translate english c6182_0426f713:


    "Pero ignoro la voz que grita en mi cabeza y hurgo de todos modos."


translate english c6182_11ba5a7a:


    "Casi como si estuviera obligado por alguna fuerza invisible."


translate english c6182_d4b8a026:



    voice "voice/c61/8200090a01.opus"
    mx "\"Aaah!\""


translate english c6182_65dc14f0:


    xy "\"Miyuki!\""


translate english c6182_87c0f897:


    "Miyuki salta hacia atrás, y la atrapo en mis brazos."


translate english c6182_8e2cb74c:


    xy "\"What's wrong?\""


translate english c6182_ea382423:



    voice "voice/c61/8200100a01.opus"
    mx "\"In there...\""


translate english c6182_39f9afa0:


    "Miyuki señala un bote de basura junto a la cama."


translate english c6182_4e681bf8:


    "Lo que sea que haya ahí, aparentemente es suficiente para hacer que sus piernas flaqueen."


translate english c6182_1c0daa3a:


    "Siento que mi visión se vuelve borrosa."


translate english c6182_cde73d21:


    "Si tan solo pudiera desmayarme en su lugar."


translate english c6182_7955cd2b:



    voice "voice/c61/8200110b01.opus"
    xtl "\"Shinichi?\""


translate english c6182_aefdc5ce:


    xy "\"Go ahead.\""


translate english c6182_7ea3e420:


    "Con Miyuki en mis brazos, mis manos están un poco ocupadas."


translate english c6182_71b1f36b:


    "En mi lugar, Yuutarou se acerca lentamente al bote de basura."


translate english c6182_ed78225a:



    voice "voice/c61/8200120b01.opus"
    xtl "\"......Ugh.\""


translate english c6182_bb5110d0:


    "Gruñe."


translate english c6182_8e2cb74c_1:


    xy "\"What's wrong?\""


translate english c6182_293e7238:


    xy "\"What's in there?\""


translate english c6182_1b2414a7:


    xy "\"Hey! Yuutarou! Tell me what's in there!!!\""


translate english c6182_1e4b1dfb:



    voice "voice/c61/8200130b01.opus"
    xtl "\"...Condoms.\""


translate english c6182_e49d6b60:


    "La palabra me golpea como un puñetazo en el estómago."


translate english c6182_9baa67eb:



    voice "voice/c61/8200140b01.opus"
    xtl "\"The package has been opened, but...\""


translate english c6182_80b9a7ff:



    voice "voice/c61/8200150b01.opus"
    xtl "\"It's unused.\""


translate english c6182_9a660300:


    "Este es el clavo en el ataúd, el golpe final que hace que mi vista se nuble."


translate english c6182_f084a74b:


    "El dolor en mi pie se siente distante, como si estuviera ocurriendo en algún otro mundo."


translate english c6182_5bb2e3a3:



    voice "voice/c61/8200160a01.opus"
    mx "\"Shinichi, hang in there.\""


translate english c6182_dd817848:


    "Con su compostura restaurada, esta vez Miyuki envuelve sus brazos a mi alrededor."


translate english c6182_2b25e6fe:



    voice "voice/c61/8200170a01.opus"
    mx "\"It's too early to give up yet.\""


translate english c6182_87af8a4b:



    voice "voice/c61/8200180a01.opus"
    mx "\"I mean, we don't have any proof that Aoi's the one he—\""


translate english c6182_60e062d6:


    xy "\"Aoi was definitely here.\""


translate english c6182_984ebd42:


    "Me agacho lentamente para agarrar la cosa que pisé."


translate english c6182_192537c2:


    "Mis dedos están entumecidos y temblorosos."


translate english c6182_4a452e05:


    "Apenas puedo levantarlo."


translate english c6182_b76db1be:


    xy "\"Aoi is cheating on me.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
