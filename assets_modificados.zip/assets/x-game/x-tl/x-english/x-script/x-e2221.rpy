

translate english e2221_824e2511:



    voice "voice/e22/2100010a01.opus"
    mx "\"Happy birthday dear Shinichiii...\""


translate english e2221_5894bdcc:



    voice "voice/e22/2100020a01.opus"
    mx "\"Happy birthday to youuu!\""


translate english e2221_71bbb8aa:


    xy "\"Pfffooooo!!!\""


translate english e2221_61f8ed19:



    voice "voice/e22/2100030a01.opus"
    mx "\"Happy birthday, sweetie.\""


translate english e2221_bf9e5cd3:


    xy "\"Thanks.\""


translate english e2221_b51c904f:


    "We sit across from each other at the table. Between us sits a birthday cake with [persistent.count_birthday] candles on top."



translate english e2221_39b4b1b9:


    "No es gran cosa una fiesta con solo dos personas, pero para mí es más que suficiente."


translate english e2221_18e25c02:


    xy "\"Man, how long's it been since the last time we celebrated my birthday together?\""


translate english e2221_78f21bfc:



    voice "voice/e22/2100040a01.opus"
    mx "\"Not as long as you think.\""


translate english e2221_fcd7b165:


    xy "\"Really...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
