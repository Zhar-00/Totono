

translate english e2221_824e2511:



    voice "voice/e22/2100010a01.opus"
    mx "\"Feliz cumpleaños, querido Shinichiii...\""


translate english e2221_5894bdcc:



    voice "voice/e22/2100020a01.opus"
    mx "\"¡Feliz cumpleaños para tiiii!\""


translate english e2221_71bbb8aa:


    xy "\"¡¡¡Pfffooooo!!!\""


translate english e2221_61f8ed19:



    voice "voice/e22/2100030a01.opus"
    mx "\"Feliz cumpleaños, cariño.\""


translate english e2221_bf9e5cd3:


    xy "\"Gracias.\""


translate english e2221_b51c904f:


    "We sit across from each other at the table. Between us sits a birthday cake with [persistent.count_birthday] candles on top."



translate english e2221_39b4b1b9:


    "No es gran cosa una fiesta con solo dos personas, pero para mí es más que suficiente."


translate english e2221_18e25c02:


    xy "\"Vaya, ¿cuánto tiempo ha pasado desde la última vez que celebramos mi cumpleaños juntos?\""


translate english e2221_78f21bfc:



    voice "voice/e22/2100040a01.opus"
    mx "\"No tanto como crees.\""


translate english e2221_fcd7b165:


    xy "\"¿De verdad...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
