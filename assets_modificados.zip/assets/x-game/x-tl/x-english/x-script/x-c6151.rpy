

translate english c6151_07caa015:


    "Entrego mi boleto y entro al oscuro gimnasio."


translate english c6151_72bca016:


    "La obra aún no ha empezado, pero la mayoría de los asientos están llenos."


translate english c6151_c5232f3b:


    "Todo lo que queda es esperar a que suba el telón."


translate english c6151_d2ae0b79:



    voice "voice/c61/5100010a01.opus"
    mx "\"¡Shinichi! ¡Llegas tarde!\""


translate english c6151_2320db4e:


    xy "\"Sí, lo sé. Surgió algo.\""


translate english c6151_daf96963:



    voice "voice/c61/5100020a01.opus"
    mx "\"Veo que Aoi no está contigo. ¿Pasa algo con ella?\""


translate english c6151_a0708d3c:


    "Si Miyuki está al tanto de la sorpresa, entonces probablemente no debería confesar lo que vi justo ahora..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
