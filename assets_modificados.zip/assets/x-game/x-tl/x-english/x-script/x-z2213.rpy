

translate english z2213_d35183d5:


    "Bip bip bip bip bip bip bip bip bip..."



translate english z2213_d35183d5_1:


    "Bip bip bip bip bip bip bip bip bip..."



translate english z2213_e9087362:


    "Bip bip... ¿Me oyes?"


translate english z2213_55e6945d:


    "¡Por fin... Aoi por fin logró comunicarse!"


translate english z2213_d8ffaecb:



    voice "voice/z22/1300050a01.opus"
    mx "No."


translate english z2213_a04e180e:



    voice "voice/z22/1300060a01.opus"
    mx "¿Estás enojado? Bueno, espero que me perdones."


translate english z2213_1a87d767:



    voice "voice/z22/1300070a01.opus"
    mx "¡Después de todo, es el Día de los Inocentes!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
