

translate english c5191_aedff609:



    voice "voice/c51/9100010a01.opus"
    mx "\"¿Por qué no van a una cita alguna vez?\""


translate english c5191_82b146f9:


    xy "\"¡¿Una cita?!\""


translate english c5191_5689b20d:


    "Al día siguiente, me toma por sorpresa una pregunta inesperada."


translate english c5191_1f4d3eae:


    xy "\"Con lo que solo puedo suponer que te refieres a... ir a algún lado... ¿románticamente...?\""


translate english c5191_9cead201:



    voice "voice/c51/9100020a01.opus"
    mx "\"¿Ustedes hacen ALGO de pareja?\""


translate english c5191_a77fd455:


    xy "\"Pues...\""


translate english c5191_f1d0ea38:


    "Esperando esquivar el tema, aparto la mirada."


translate english c5191_05ae7e21:



    voice "voice/c51/9100030a02.opus"
    aoi "\"¡Aoi es una leona feroz!\""


translate english c5191_83543b11:



    voice "voice/c51/9100040a02.opus"
    aoi "\"¡Grrrrr!\""


translate english c5191_0fdab202:



    voice "voice/c51/9100060a02.opus"
    aoi "\"Aterrizando... ¡Whooo!\""


translate english c5191_ebcd26b1:



    voice "voice/c51/9100070a02.opus"
    aoi "\"¡Ahora es el turno de Aoi!\""


translate english c5191_9c6facaa:


    "Aoi y Eru juegan juntos, como siempre."


translate english c5191_82464fde:


    "Y Eru lleva su collar nuevo."


translate english c5191_17cb34e1:


    "Afortunadamente, no parece molestarle el sonido del cascabel."


translate english c5191_9f7011e2:


    xy "\"Supongo que no hacemos muchas cosas de pareja... En cierto modo se siente como si solo fuéramos amigos...\""


translate english c5191_005c20e2:



    voice "voice/c51/9100080a01.opus"
    mx "\"Te das cuenta de que podían haber ido a Catnip sin mí, ¿verdad?\""


translate english c5191_50596c6d:


    xy "\"Oh...\""


translate english c5191_b8b5e7fe:


    "Pensándolo bien, en el momento en que sugerí invitar a Miyuki, Aoi pareció un poco decepcionada..."


translate english c5191_0298642e:



    voice "voice/c51/9100090a01.opus"
    mx "\"Lo sabía.\""


translate english c5191_5e6dd002:



    voice "voice/c51/9100100a01.opus"
    mx "\"...O sea, no es que no agradezca la invitación.\""


translate english c5191_84c0d42a:



    voice "voice/c51/9100110a01.opus"
    mx "\"Pero la próxima vez, más te vale llevarla a una cita de verdad, ¿me oyes?\""


translate english c5191_6448b762:



    voice "voice/c51/9100120a01.opus"
    mx "\"O si no se va a hartar de tus tonterías y te va a poner los cuernos.\""


translate english c5191_c0195779:


    xy "\"¡¿Ponerme los cuernos?! ¡Pssh! ¡Como si fuera posible!\""


translate english c5191_ce31b18d:



    voice "voice/c51/9100130a01.opus"
    mx "\"No estoy bromeando.\""


translate english c5191_495851ef:


    xy "\"......¿Qué?\""


translate english c5191_603f5a44:


    "¿Habla en serio...?"


translate english c5191_974c3008:


    xy "Recuerdo el rumor de que Aoi es una cualquiera."


translate english c5191_aa1e5cad:



    voice "voice/c51/9100140a01.opus"
    mx "\"Miyuki, ¿sabes algo?\""


translate english c5191_da9efd5a:



    voice "voice/c51/9100150a01.opus"
    mx "\"No tengo ninguna prueba concreta...\""


translate english c5191_42cd51f6:



    voice "voice/c51/9100160a01.opus"
    mx "\"Pero cuando hablé con la cajera de Catnip ayer...\""


translate english c5191_2fefb243:


    mx "\"Me dijo que Aoi suele pasar con un amigo.\""



translate english c5191_6c62f72d:


    xy "\"¿Un amigo...?\""


translate english c5191_dd620416:


    "Aoi y yo nunca hemos visitado Catnip solo los dos..."


translate english c5191_051d76c6:



    voice "voice/c51/9100170a01.opus"
    mx "\"Claro que la cajera podría haber confundido a alguien con ella.\""


translate english c5191_a8a81627:



    voice "voice/c51/9100180a01.opus"
    mx "\"Solo pensé en mencionarlo.\""


translate english c5191_b475db6f:


    xy "\"Quizá vino con alguna otra amiga—\""


translate english c5191_9ad8e52a:



    voice "voice/c51/9100190a01.opus"
    mx "\"Ya pregunté por ahí. Al menos no tiene amigos en nuestra clase.\""


translate english c5191_0accd139:


    xy "\"\"......\"What?\""


translate english c5191_ea34660d:


    xy "\"Tiene que haber algún malentendido. Me niego a creerlo.\""


translate english c5191_002c41a9:



    voice "voice/c51/9100200a01.opus"
    mx "\"Yo tampoco quiero creerlo. No puedo imaginar que Aoi haga algo así sin explicación.\""


translate english c5191_2cbfd34c:



    voice "voice/c51/9100210a01.opus"
    mx "\"Pero como tu amiga, sentí que debía decírtelo.\""


translate english c5191_9b2da0e2:


    xy "\"Cierto... Gracias.\""


translate english c5191_169d2894:


    "Pero podía oír mi voz vacilar."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
