

translate english c5191_aedff609:



    voice "voice/c51/9100010a01.opus"
    mx "\"Why don't you two go on a date sometime?\""


translate english c5191_82b146f9:


    xy "\"A date?!\""


translate english c5191_5689b20d:


    "Al día siguiente, me toma por sorpresa una pregunta inesperada."


translate english c5191_1f4d3eae:


    xy "\"By which I can only assume you mean... going somewhere... romantically...?\""


translate english c5191_9cead201:



    voice "voice/c51/9100020a01.opus"
    mx "\"Do you guys do ANY couple-y stuff?\""


translate english c5191_a77fd455:


    xy "\"Well...\""


translate english c5191_f1d0ea38:


    "Esperando esquivar el tema, aparto la mirada."


translate english c5191_05ae7e21:



    voice "voice/c51/9100030a02.opus"
    aoi "\"Aoi's a fierce lion!\""


translate english c5191_83543b11:



    voice "voice/c51/9100040a02.opus"
    aoi "\"Roarrrr!\""


translate english c5191_0fdab202:



    voice "voice/c51/9100060a02.opus"
    aoi "\"Coming in for a landing... Whoooo!\""


translate english c5191_ebcd26b1:



    voice "voice/c51/9100070a02.opus"
    aoi "\"Now it's Aoi's turn!\""


translate english c5191_9c6facaa:


    "Aoi y Eru juegan juntos, como siempre."


translate english c5191_82464fde:


    "Y Eru lleva su collar nuevo."


translate english c5191_17cb34e1:


    "Afortunadamente, no parece molestarle el sonido del cascabel."


translate english c5191_9f7011e2:


    xy "\"I guess we don't really do much couple stuff... It kinda feels like we're just friends, in a way...\""


translate english c5191_005c20e2:



    voice "voice/c51/9100080a01.opus"
    mx "\"You realize you guys could have gone to Catnip without me, right?\""


translate english c5191_50596c6d:


    xy "\"Oh...\""


translate english c5191_b8b5e7fe:


    "Pensándolo bien, en el momento en que sugerí invitar a Miyuki, Aoi pareció un poco decepcionada..."


translate english c5191_0298642e:



    voice "voice/c51/9100090a01.opus"
    mx "\"I knew it.\""


translate english c5191_5e6dd002:



    voice "voice/c51/9100100a01.opus"
    mx "\"...I mean, not that I don't appreciate the invite.\""


translate english c5191_84c0d42a:



    voice "voice/c51/9100110a01.opus"
    mx "\"But next time, you better take her on an actual date, you hear me?\""


translate english c5191_6448b762:



    voice "voice/c51/9100120a01.opus"
    mx "\"Otherwise she'll get sick of your nonsense and cheat on you.\""


translate english c5191_c0195779:


    xy "\"Cheat on me! Pssh! As if!\""


translate english c5191_ce31b18d:



    voice "voice/c51/9100130a01.opus"
    mx "\"I'm not joking.\""


translate english c5191_495851ef:


    xy "\"......What?\""


translate english c5191_603f5a44:


    "¿Habla en serio...?"


translate english c5191_974c3008:


    xy "Recuerdo el rumor de que Aoi es una cualquiera."


translate english c5191_aa1e5cad:



    voice "voice/c51/9100140a01.opus"
    mx "\"Miyuki, do you know something?\""


translate english c5191_da9efd5a:



    voice "voice/c51/9100150a01.opus"
    mx "\"I don't have any concrete proof...\""


translate english c5191_42cd51f6:



    voice "voice/c51/9100160a01.opus"
    mx "\"But when I was talking to the Catnip clerk yesterday...\""


translate english c5191_2fefb243:


    mx "\"They told me Aoi often stops by with a friend.\""



translate english c5191_6c62f72d:


    xy "\"A friend...?\""


translate english c5191_dd620416:


    "Aoi y yo nunca hemos visitado Catnip solo los dos..."


translate english c5191_051d76c6:



    voice "voice/c51/9100170a01.opus"
    mx "\"Granted, the clerk might have mistaken someone else for her.\""


translate english c5191_a8a81627:



    voice "voice/c51/9100180a01.opus"
    mx "\"Just thought I'd mention it.\""


translate english c5191_b475db6f:


    xy "\"Maybe she came with some other female friend—\""


translate english c5191_9ad8e52a:



    voice "voice/c51/9100190a01.opus"
    mx "\"I already asked around. She doesn't have any friends in our class, at least.\""


translate english c5191_0accd139:


    xy "\"\"......\"What?\""


translate english c5191_ea34660d:


    xy "\"There's got to be some kind of misunderstanding here. I refuse to believe this.\""


translate english c5191_002c41a9:



    voice "voice/c51/9100200a01.opus"
    mx "\"I don't want to believe it, either. I can't imagine Aoi would do that sort of thing with no explanation.\""


translate english c5191_2cbfd34c:



    voice "voice/c51/9100210a01.opus"
    mx "\"But as your friend, I felt I should tell you.\""


translate english c5191_9b2da0e2:


    xy "\"Right... Thanks.\""


translate english c5191_169d2894:


    "Pero podía oír mi voz vacilar."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
