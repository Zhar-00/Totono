

translate english e2152a_9b34fa61:


    xy "\"¿Segura que no vas a engordar?\""


translate english e2152a_fa244c64:



    voice "voice/e21/52a00010a01.opus"
    mx "\"Puedo comer todo lo que quiera. Tengo el metabolismo acelerado.\""


translate english e2152a_dedb920b:


    xy "\"...¿En serio? ¿Desde cuándo?\""


translate english e2152a_f13be9b1:



    voice "voice/e21/52a00020a01.opus"
    mx "\"Desde hace poco.\""


translate english e2152a_8e22b9db:


    xy "\"¿Cómo pasó eso?\""


translate english e2152a_148a2bba:



    voice "voice/e21/52a00030a01.opus"
    mx "\"Oh, descubrí cómo hacer trampa al sistema.\""


translate english e2152a_e152b62e:


    "¿Qué tipo de dieta rara está siguiendo ahora...?"


translate english e2152a_11be2420:


    xy "\"De todos modos, ¿cuánto pesas estos días?\""


translate english e2152a_cd5a5ad3:



    voice "voice/e21/52a00040a01.opus"
    mx "\"¡Como si fuera a decírtelo!\""


translate english e2152a_441d1e45:


    xy "\"Ya me imaginaba...\""


translate english e2152a_917e7629:


    "El peso de una dama es un secreto demasiado poderoso para que cualquier hombre lo conozca... Probablemente..."


translate english e2152a_50f55626:



    voice "voice/e21/52a00050a01.opus"
    mx "\"¿DE VERDAD quieres saberlo?\""


translate english e2152a_31e16c6f:


    xy "\"N-Nah, así estoy bien.\""


translate english e2152a_8ab25a16:


    "Cedo ante la intensidad de su mirada."


translate english e2152a_e4150eda:



    voice "voice/e21/52a00060a01.opus"
    mx "\"¡Buena pregunta! ¡Quizás debería quemar algunas CALORÍAS!\""


translate english e2152a_32649587:


    "Miyuki de repente empieza a practicar su swing de béisbol—¡¿en mi dirección?!"


translate english e2152a_720a9fc1:


    xy "\"¡D-Descartado! En serio, eres tan delgada, ¡que apenas veo la necesidad!\""


translate english e2152a_c57f046a:


    "Por un segundo pensé que iba a destrozarme la cara..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
