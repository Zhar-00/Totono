

translate english e2152a_9b34fa61:


    xy "\"You sure you won't get fat?\""


translate english e2152a_fa244c64:



    voice "voice/e21/52a00010a01.opus"
    mx "\"I can eat as much as I want. I have a high metabolism.\""


translate english e2152a_dedb920b:


    xy "\"...You do? Since when?\""


translate english e2152a_f13be9b1:



    voice "voice/e21/52a00020a01.opus"
    mx "\"Since recently.\""


translate english e2152a_8e22b9db:


    xy "\"How'd that happen?\""


translate english e2152a_148a2bba:



    voice "voice/e21/52a00030a01.opus"
    mx "\"Oh, I figured out how to cheat the system.\""


translate english e2152a_e152b62e:


    "¿Qué tipo de dieta rara está siguiendo ahora...?"


translate english e2152a_11be2420:


    xy "\"How much do you weigh these days, anyhow?\""


translate english e2152a_cd5a5ad3:



    voice "voice/e21/52a00040a01.opus"
    mx "\"As if I'm going to tell you!\""


translate english e2152a_441d1e45:


    xy "\"Figures...\""


translate english e2152a_917e7629:


    "El peso de una dama es un secreto demasiado poderoso para que cualquier hombre lo conozca... Probablemente..."


translate english e2152a_50f55626:



    voice "voice/e21/52a00050a01.opus"
    mx "\"You REALLY want to know?\""


translate english e2152a_31e16c6f:


    xy "\"N-Nah, I'm good.\""


translate english e2152a_8ab25a16:


    "Cedo ante la intensidad de su mirada."


translate english e2152a_e4150eda:



    voice "voice/e21/52a00060a01.opus"
    mx "\"Good question! Maybe I should burn some CALORIES!\""


translate english e2152a_32649587:


    "Miyuki de repente empieza a practicar su swing de béisbol—¡¿en mi dirección?!"


translate english e2152a_720a9fc1:


    xy "\"N-Nonsense! Honestly, you're so slim, I hardly see the need!\""


translate english e2152a_c57f046a:


    "Por un segundo pensé que iba a destrozarme la cara..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
