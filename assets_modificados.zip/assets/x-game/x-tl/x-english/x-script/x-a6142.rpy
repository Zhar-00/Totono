

translate english a6142_9570d187:


    "Todavía tengo la foto que Aoi nos tomó a los tres."


translate english a6142_2a3d89c2:


    "Una instantánea de una amistad que nunca podré recuperar."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
