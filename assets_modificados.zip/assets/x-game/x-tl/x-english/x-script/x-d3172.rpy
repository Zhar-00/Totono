

translate english d3172_04e30af2:



    voice "voice/d31/7200010a01.opus"
    mx "\"Now YOU'RE mixing up games with reality?\""


translate english d3172_12e64a21:


    xy "\"......\""


translate english d3172_c6eca240:


    "Miyuki tiene razón."


translate english d3172_c795129e:


    "Se supone que debo rehabilitarla de vuelta al mundo real."


translate english d3172_0c0a5437:


    "¡No puedo contagiarme su enfermedad de cerebro gamer!"


translate english d3172_36a8325d:


    "Debería obligarme a dormir."


translate english d3172_d04b1258:


    "Abrazando mi almohada, aprieto los ojos cerrados."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
