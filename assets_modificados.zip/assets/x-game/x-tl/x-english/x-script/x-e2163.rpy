

translate english e2163_1a7af927:



    voice "voice/e21/6300010a01.opus"
    mx "\"Ooh! This is so cute!\""


translate english e2163_5d6011c7:


    "Miyuki señala un pasador con forma de gato en exhibición cerca de la ventana."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
