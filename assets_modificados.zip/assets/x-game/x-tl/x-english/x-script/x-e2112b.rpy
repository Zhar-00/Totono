

translate english e2112b_02e0df6d:


    "Sé lo que busca."


translate english e2112b_3d65cdd6:


    "Pero me alejo en silencio."


translate english e2112b_570463d6:


    "Es demasiado temprano en la mañana para ponernos tan pegajosos."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
