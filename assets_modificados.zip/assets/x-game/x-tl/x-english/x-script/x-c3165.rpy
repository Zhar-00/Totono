

translate english c3165_60ae9167:


    xy "\"¡El juego para móvil!\""


translate english c3165_5021f382:



    voice "voice/c31/6500010a01.opus"
    mx "\"¿Qué? ¿Qué juego para móvil?\""


translate english c3165_5a5bd91f:


    xy "\"Hay este juego que le tomé prestado a Yuutarou. ¡Tiene un personaje que es EXACTAMENTE igual a Aoi!\""


translate english c3165_8e66f6d4:


    xy "\"Y no solo en apariencia. ¡También actúan idéntico! ¿Ese día que la encontramos en la azotea? Casi exactamente lo mismo pasó en una escena de—\""


translate english c3165_84a91697:



    voice "voice/c31/6500020a01.opus"
    mx "\"Jaah...\""


translate english c3165_56af6876:


    "Miyuki suspira, exasperada."


translate english c3165_876d67ae:



    voice "voice/c31/6500030a01.opus"
    mx "\"¿Ahora TÚ estás mezclando los juegos con la realidad?\""


translate english c3165_065f5d2b:


    xy "\"¡No, escúchame! ¡Aoi está actuando escenas del juego! Cuando encontró a ese gatito callejero, todo lo que dijo fue como una reproducción 1:1 de—\""


translate english c3165_32132689:



    voice "voice/c31/6500040a01.opus"
    mx "\"¿Y cómo consiguió el gato entonces? ¿Fue a propósito a un refugio a buscarlo?\""


translate english c3165_bb44ba80:


    xy "\"Oh... eh...\""


translate english c3165_2b9db307:


    "¿De verdad se tomaría tantas molestias solo para recrear una escena del juego...?"


translate english c3165_8bb6780a:


    "No veo razón alguna para que se esfuerce tanto..."


translate english c3165_05b46338:



    voice "voice/c31/6500050a01.opus"
    mx "\"Todo es solo una coincidencia.\""


translate english c3165_bc2b7e9a:



    voice "voice/c31/6500060a01.opus"
    mx "\"¿Qué otra cosa podría ser?\""


translate english c3165_5f3b44b3:


    xy "\"¿Eh? Bueno... eh... er...\""


translate english c3165_7989bd91:


    xy "\"¿Un milagro divino, tal vez?\""


translate english c3165_de5a0734:


    mx "\"¡Shinichi!\""


translate english c3165_3a3701d4:


    "Miyuki alza la voz."


translate english c3165_47386803:



    voice "voice/c31/6500080a01.opus"
    mx "\"Entiendo que estés alterado ahora, ¡pero usa la cabeza!\""


translate english c3165_66b78c03:



    voice "voice/c31/6500090a01.opus"
    mx "\"Dios no existe. Lo sabes, ¿no?\""


translate english c3165_cacc21df:


    xy "\"Oh... Cierto...\""


translate english c3165_c43afe0a:


    xy "\"Claro...\""


translate english c3165_4e661af5:


    "SÍ estaba intentando usar la cabeza..."


translate english c3165_b87dc91c:


    "Supongo que acabé balbuceando como un loco."


translate english c3165_73ccff67:



    voice "voice/c31/6500100a01.opus"
    mx "\"Estás agotado. Ahora vete a casa y descansa.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
