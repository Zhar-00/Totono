

translate english c3165_60ae9167:


    xy "\"The mobile game!\""


translate english c3165_5021f382:



    voice "voice/c31/6500010a01.opus"
    mx "\"What? What mobile game?\""


translate english c3165_5a5bd91f:


    xy "\"There's this game I borrowed from Yuutarou. It's got a character that's dead-on EXACTLY like Aoi!\""


translate english c3165_8e66f6d4:


    xy "\"Not just looks-wise, either. They act identical, too! That day we met her on the roof? Almost the same exact thing happened in this one scene—\""


translate english c3165_84a91697:



    voice "voice/c31/6500020a01.opus"
    mx "\"Haah...\""


translate english c3165_56af6876:


    "Miyuki suspira, exasperada."


translate english c3165_876d67ae:



    voice "voice/c31/6500030a01.opus"
    mx "\"Now YOU'RE mixing up games with reality?\""


translate english c3165_065f5d2b:


    xy "\"No, listen to me! Aoi's acting out scenes from the game! When she found that stray kitten, everything she said was like a 1:1 reproduction of—\""


translate english c3165_32132689:



    voice "voice/c31/6500040a01.opus"
    mx "\"How'd she get the cat, then? Did she go out of her way to get one from a shelter?\""


translate english c3165_bb44ba80:


    xy "\"Oh... uh...\""


translate english c3165_2b9db307:


    "¿De verdad se tomaría tantas molestias solo para recrear una escena del juego...?"


translate english c3165_8bb6780a:


    "No veo razón alguna para que se esfuerce tanto..."


translate english c3165_05b46338:



    voice "voice/c31/6500050a01.opus"
    mx "\"It's all just a coincidence.\""


translate english c3165_bc2b7e9a:



    voice "voice/c31/6500060a01.opus"
    mx "\"What else could it possibly be?\""


translate english c3165_5f3b44b3:


    xy "\"Huh? Well... uh... er...\""


translate english c3165_7989bd91:


    xy "\"A divine miracle, maybe?\""


translate english c3165_de5a0734:


    mx "\"Shinichi!\""


translate english c3165_3a3701d4:


    "Miyuki alza la voz."


translate english c3165_47386803:



    voice "voice/c31/6500080a01.opus"
    mx "\"I understand you're worked up right now, but use your head!\""


translate english c3165_66b78c03:



    voice "voice/c31/6500090a01.opus"
    mx "\"God isn't real. You do know that, don't you?\""


translate english c3165_cacc21df:


    xy "\"Oh... Right...\""


translate english c3165_c43afe0a:


    xy "\"Of course...\""


translate english c3165_4e661af5:


    "SÍ estaba intentando usar la cabeza..."


translate english c3165_b87dc91c:


    "Supongo que acabé balbuceando como un loco."


translate english c3165_73ccff67:



    voice "voice/c31/6500100a01.opus"
    mx "\"You're exhausted. Now go home and get some rest.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
