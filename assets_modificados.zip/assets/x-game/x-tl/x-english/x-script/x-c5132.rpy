

translate english c5132_c3ae5b10:



    voice "voice/c51/3200010a02.opus"
    aoi "\"Boop boop...\""


translate english c5132_fa3fb06a:


    "—Encuentro a Aoi mirándome."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
