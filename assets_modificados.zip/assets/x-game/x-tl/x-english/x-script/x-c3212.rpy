

translate english c3212_bc5d8549:



    voice "voice/c32/1200010a02.opus"
    aoi "\"Qué bueno que Haru-chan estaba ahí para ayudarnos.\""


translate english c3212_7bc305d2:


    "Después de desenterrarla, la ayudamos a poner los cigarrillos de vuelta en su lugar."


translate english c3212_36c1640e:


    "Como muestra de agradecimiento, la tímida y torpe Haru nos enseñó todo lo que sabe sobre cómo cuidar a un gatito."


translate english c3212_d1517db5:


    "Ahora estamos alimentando a Eru con leche pasteurizada que Haru eligió para nosotros."


translate english c3212_0accd139:


    xy "\"\"\"......\"\"\""


translate english c3212_6cb29492:



    voice "voice/c32/1200020a02.opus"
    aoi "\"\"\"......\"\"\""


translate english c3212_b74fd9c6:


    xy "\"¿Quieres tal vez...\""


translate english c3212_31701470:


    xy "\"...quedarte aquí esta noche?\""


translate english c3212_6819a886:



    voice "voice/c32/1200030a02.opus"
    aoi "\"¿Bip bip...?\""



translate english c3212_72b72465:


    xy "\"Es bastante tarde, y sé que no te sientes bien. Y dormir en un manga café no suena propicio para descansar bien.\""


translate english c3212_974a0f11:



    voice "voice/c32/1200040a02.opus"
    aoi "\"Pero... eso activaría una bandera de evento riesgosa...\""


translate english c3212_ce2dac17:



    voice "voice/c32/1200050a02.opus"
    aoi "\"\"\"......\"\"\""


translate english c3212_bb704d91:


    xy "\"¿Qué es una bandera de evento...?\""


translate english c3212_f927024f:



    voice "voice/c32/1200060a02.opus"
    aoi "\"...Bip bip.\""


translate english c3212_60a8b55c:


    "Aoi se queda callada y mira a Eru."


translate english c3212_98627e75:


    "El gatito lame la leche con su lengüita. Antes de darnos cuenta, ambos estamos sonriendo."


translate english c3212_9d42f3a0:


    xy "\"La bolita de pelo parece bastante feliz.\""


translate english c3212_786d4024:



    voice "voice/c32/1200070a02.opus"
    aoi "\"La leche parece semen.\""


translate english c3212_76d897ba:


    xy "\"—?!\""


translate english c3212_4cac74eb:


    xy "\"¡Uah! ¡Cielos! ¡No hables así!\""


translate english c3212_5e01ddd0:



    voice "voice/c32/1200080a02.opus"
    aoi "\"¿Por qué no?\""


translate english c3212_28fabc60:


    xy "\"¡Porque lo digo yo!\""


translate english c3212_6ddbd8b1:



    voice "voice/c32/1200090a02.opus"
    aoi "\"Bip bip... Okay.\""


translate english c3212_5e85cad6:



    voice "voice/c32/1200100a02.opus"
    aoi "\"Pero...\""


translate english c3212_10f93b69:


    "Aoi se queda callada y me mira fijamente."


translate english c3212_5295b9f3:


    "No, a mí no..."


translate english c3212_de67a6f6:


    "¡¿A mi entrepierna...?!"


translate english c3212_4ff875e5:



    voice "voice/c32/1200110a02.opus"
    aoi "\"A Aoi no le importaría beber la tuya.\""


translate english c3212_779b65c1:


    xy "\"¿¡Pfffff!?\""


translate english c3212_448d48a3:


    xy "\"¡Basta, Aoi! ¡Estás actuando raro—!\""


translate english c3212_4bdbf080:



    voice "voice/c32/1200120a02.opus"
    aoi "\"Sí, SÍ es raro.\""


translate english c3212_bdad430a:



    voice "voice/c32/1200130a02.opus"
    aoi "\"Cada vez que Aoi dice tu nombre...\""


translate english c3212_d826b615:



    voice "voice/c32/1200140a02.opus"
    aoi "\"...mi pecho se aprieta todo...\""


translate english c3212_4f5da8e3:



    voice "voice/c32/1200150a02.opus"
    aoi "\"...y mi cabeza se nubla.\""


translate english c3212_a541b1c6:



    voice "voice/c32/1200160a02.opus"
    aoi "\"¿Qué me pasa?\""


translate english c3212_c7774ca7:


    "Aoi se acerca más a mí."


translate english c3212_ec632e54:


    "Sus mejillas están ligeramente rosadas."


translate english c3212_86daa290:


    "Mis ojos están clavados en los suyos."


translate english c3212_ffe0b29f:


    xy "\"Suena a que probablemente t-tienes un resfriado o algo.\""


translate english c3212_24e51f96:



    voice "voice/c32/1200170a02.opus"
    aoi "\"No. De eso no hay CG.\""


translate english c3212_4db8f881:


    "Se lleva una mano al pecho."


translate english c3212_180318c0:



    voice "voice/c32/1200180a02.opus"
    aoi "\"Aoi siente tantos chispazos...\""


translate english c3212_a2779574:



    voice "voice/c32/1200190a02.opus"
    aoi "\"Justo por aquí.\""


translate english c3212_f97a4649:



    voice "voice/c32/1200200a02.opus"
    aoi "\"¿Puede Aoi besarte?\""


translate english c3212_552ddfd9:


    xy "\"¡Uah, espera—!\""


translate english c3212_41e55f9a:


    "Aparto su mano rápidamente."


translate english c3212_c72dfc60:



    voice "voice/c32/1200210a02.opus"
    aoi "\"¿Bip bip?\""


translate english c3212_42e58d2f:



    voice "voice/c32/1200220a02.opus"
    aoi "\"¿Por qué no?\""


translate english c3212_6275d27b:


    xy "\"Bueno... porque...\""


translate english c3212_7ab4f50b:


    xy "\"Porque lo digo yo.\""


translate english c3212_3656ec0e:



    voice "voice/c32/1200230a02.opus"
    aoi "\"¿Tú también te sientes raro?\""


translate english c3212_e7cb80fc:


    xy "\"¡Me... me voy a dormir!\""


translate english c3212_48a31b01:


    xy "\"Ya te dejé una cobija lista, así que deberías estar bien.\""


translate english c3212_c4da10f2:


    xy "\"¡Buenas noches!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
