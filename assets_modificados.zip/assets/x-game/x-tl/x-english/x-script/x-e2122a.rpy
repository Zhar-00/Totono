

translate english e2122a_41c7fc16:


    xy "\"I'm talking about Haru-chan, obviously.\""


translate english e2122a_282a6d79:



    voice "voice/e21/22a00010b01.opus"
    xtl "\"Huh...? What do you mean?\""


translate english e2122a_48598762:


    xy "\"I mean, she confessed her love to you, didn't she?\""


translate english e2122a_8882e345:



    voice "voice/e21/22a00020b01.opus"
    xtl "\"That was all just a misunderstanding on my part!\""


translate english e2122a_e1d1eabb:


    xy "\"You sure?\""


translate english e2122a_0d00c392:



    voice "voice/e21/22a00030b01.opus"
    xtl "\"I mean, we're brother and sister, dude! There's no way!\""


translate english e2122a_1c29c586:



    voice "voice/e21/22a00040b01.opus"
    xtl "\"The only reason she got close to me was...\""


translate english e2122a_81539e2b:


    xy "\"...Was...?\""


translate english e2122a_cda75b4a:



    voice "voice/e21/22a00050b01.opus"
    xtl "\"Well...\""


translate english e2122a_55df0f8e:



    voice "voice/e21/22a00060b01.opus"
    xtl "\"Aaargh! Forget it!\""


translate english e2122a_769b01a8:



    voice "voice/e21/22a00070b01.opus"
    xtl "\"Death to normies!\""


translate english e2122a_b62efd85:


    xy "\"Huh? What're you so pissy about?\""


translate english e2122a_da272e00:



    voice "voice/e21/22a00080b01.opus"
    xtl "\"Hmph!\""


translate english e2122a_7299bdbf:


    "Yuutarou se marcha furioso a su escritorio sin responder mi pregunta..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
