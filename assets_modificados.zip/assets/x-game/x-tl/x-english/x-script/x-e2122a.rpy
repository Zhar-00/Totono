

translate english e2122a_41c7fc16:


    xy "\"Estoy hablando de Haru-chan, obviamente.\""


translate english e2122a_282a6d79:



    voice "voice/e21/22a00010b01.opus"
    xtl "\"¿Eh...? ¿A qué te refieres?\""


translate english e2122a_48598762:


    xy "\"Digo, te confesó su amor, ¿no?\""


translate english e2122a_8882e345:



    voice "voice/e21/22a00020b01.opus"
    xtl "\"¡Todo eso fue solo un malentendido mío!\""


translate english e2122a_e1d1eabb:


    xy "\"¿Estás seguro?\""


translate english e2122a_0d00c392:



    voice "voice/e21/22a00030b01.opus"
    xtl "\"Digo, ¡somos hermanos, amigo! ¡No hay forma!\""


translate english e2122a_1c29c586:



    voice "voice/e21/22a00040b01.opus"
    xtl "\"La única razón por la que se me acercó fue...\""


translate english e2122a_81539e2b:


    xy "\"...¿Fue...?\""


translate english e2122a_cda75b4a:



    voice "voice/e21/22a00050b01.opus"
    xtl "\"Bueno...\""


translate english e2122a_55df0f8e:



    voice "voice/e21/22a00060b01.opus"
    xtl "\"¡Aaargh! ¡Olvídalo!\""


translate english e2122a_769b01a8:



    voice "voice/e21/22a00070b01.opus"
    xtl "\"¡Muerte a los normies!\""


translate english e2122a_b62efd85:


    xy "\"¿Eh? ¿Por qué estás tan gruñón?\""


translate english e2122a_da272e00:



    voice "voice/e21/22a00080b01.opus"
    xtl "\"¡Hmph!\""


translate english e2122a_7299bdbf:


    "Yuutarou se marcha furioso a su escritorio sin responder mi pregunta..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
