

translate english a0121_575163cd:



    voice "voice/a01/2100010a01.opus"
    mx "\"Wow. Is nothing sacred?\""


translate english a0121_29ae1267:



    voice "voice/a01/2100020a01.opus"
    mx "¿Qué haces exactamente aquí arriba, en la azotea de nuestra estimada academia?"



translate english a0121_544a05a6:


    xy "\"M-Miyuki?\""


translate english a0121_b5fa1868:


    xy "\"What am I doing? Well...\""


translate english a0121_f202de9a:



    voice "voice/a01/2100030a02.opus"
    bm "\"Recharging.\""


translate english a0121_a6a9e11a:



    voice "voice/a01/2100040a01.opus"
    mx "\"What?\""


translate english a0121_24aa6a74:



    voice "voice/a01/2100050a02.opus"
    bm "\"Having sex.\""


translate english a0121_6373566c:



    voice "voice/a01/2100060a01.opus"
    mx "\"What?!\""


translate english a0121_ca99ff95:


    xy "\"What?!\""


translate english a0121_c6afbc44:



    voice "voice/a01/2100070a02.opus"
    bm "\"Kissing triggers the event flag.\""


translate english a0121_40a4a9c8:



    voice "voice/a01/2100080a01.opus"
    mx "\"I've heard enough!\""


translate english a0121_e377f23f:


    "Miyuki agita su bate de béisbol."


translate english a0121_b707525f:



    voice "voice/a01/2100090a01.opus"
    mx "\"Don't treat Shinichi like your plaything!\""


translate english a0121_523a5ffe:


    xy "\"Y-Yeah! I'm not your plaything!\""


translate english a0121_fffa7560:



    voice "voice/a01/2100100a01.opus"
    mx "\"Sh-Shinichi... is... He's...!\""


translate english a0121_da880c04:



    voice "voice/a01/2100110a01.opus"
    mx "\"He's my boyfriend!\""


translate english a0121_9804f92e:


    xy "\"......What?\""


translate english a0121_4762ce46:


    "Soy amigo de Sone Miyuki desde que éramos niños."


translate english a0121_129bac21:


    "En la primaria solíamos jugar juntos todo el tiempo, pero nos fuimos distanciando al crecer. Le pasa a mucha gente."


translate english a0121_dbc0d98b:


    "Mientras yo he ido pasando por la vida sin ninguna afición, ella demostró rápidamente que puede dominar cualquier cosa que intenta."


translate english a0121_d508585a:


    "Con su belleza, inteligencia, habilidad atlética y un talento natural para actuar, se convirtió en la reina de la escuela prácticamente de la noche a la mañana."


translate english a0121_12205751:


    "Se rumora que recibió más de una docena de confesiones de amor en su primer mes en esta escuela."


translate english a0121_a023fcbf:


    "Me han dicho que dos fueron de chicas, y una incluso de un profesor."


translate english a0121_72058fb0:


    "Al parecer, los rechazó a todos."


translate english a0121_1da60b11:


    "Pero dicen que uno de los chicos se negó a aceptar un no por respuesta, y ella tuvo que defenderse con un bate de béisbol."


translate english a0121_de7ee726:


    "Es tan famosa que los estudiantes de aquí no pueden dejar de hablar de ella."


translate english a0121_544b1d27:


    "Y luego estoy yo, un don nadie absoluto."


translate english a0121_b27ae360:


    "Soy tan invisible que prácticamente soy aire."


translate english a0121_f9f757ab:


    "Insulso, inofensivo, apenas presente."


translate english a0121_941a7635:


    "Un personaje NPC totalmente olvidable en el RPG de la vida."


translate english a0121_b01a4334:


    "Apenas soy digno de respirar el mismo aire que ella."


translate english a0121_d608a90b:


    "Solo estar cerca de ella me pone algo tenso."


translate english a0121_32c72d43:


    "Así que sí, soy como lo más lejano a—"


translate english a0121_f0662b77:


    xy "\"Your... boyfriend...?\""


translate english a0121_94363481:



    voice "voice/a01/2100120a01.opus"
    mx "\"You be quiet!\""


translate english a0121_273f303a:



    voice "voice/a01/2100130a01.opus"
    mx "\"Sh-Shinichi and I are in a relationship. I'm afraid you don't have a chance with him.\""


translate english a0121_37e7378b:



    voice "voice/a01/2100140a01.opus"
    mx "\"So could you leave already?\""


translate english a0121_2105c48c:



    voice "voice/a01/2100150a02.opus"
    bm "\"That's not true.\""


translate english a0121_1ddf5e2b:



    voice "voice/a01/2100160a02.opus"
    bm "\"You're not dating.\""


translate english a0121_667b9261:



    voice "voice/a01/2100170a01.opus"
    mx "\"Excuse me? How would you kn—\""


translate english a0121_335c5ee1:



    voice "voice/a01/2100180a02.opus"
    bm "\"I'm a transceiver.\""


translate english a0121_f2efc7cc:



    voice "voice/a01/2100190a02.opus"
    bm "\"God sent me a radio transmission from beyond the universe.\""


translate english a0121_878e0134:


    "Eeeh..."


translate english a0121_971bda2b:


    "Parece que le faltan dos hot dogs de maíz para el picnic..."



translate english a0121_2bcbfdad:



    voice "voice/a01/2100200a01.opus"
    mx "\"Whatever. Talking to you is a waste of breath.\""


translate english a0121_48ff5006:



    voice "voice/a01/2100210a01.opus"
    mx "\"Listen here: Shinichi and I have known each other a long time. So, as his girlfriend—\""


translate english a0121_729a34d6:



    voice "voice/a01/2100220a02.opus"
    bm "\"Got it!\""


translate english a0121_123dd046:


    "Ella alza la mano, interrumpiendo a Miyuki."


translate english a0121_384efa44:



    voice "voice/a01/2100230a02.opus"
    bm "\"You're the childhood friend character.\""


translate english a0121_abc70f9f:



    voice "voice/a01/2100240a02.opus"
    bm "\"Your true feelings are a mystery.\""


translate english a0121_d0a27355:



    voice "voice/a01/2100250a02.opus"
    bm "\"A staple of visual novels.\""


translate english a0121_09491adc:



    voice "voice/a01/2100260a01.opus"
    mx "\"Visual novels...?\""


translate english a0121_ab251f76:


    xy "\"Oh, you mean like this one?\""


translate english a0121_77c3e46f:


    "Levanto el celular que encontré antes."


translate english a0121_9aea408a:


    xy "\"Whoa!\""


translate english a0121_da3e05c7:


    "¿¡Eso que sentí hace un momento fue una descarga estática!?"


translate english a0121_4e8846b6:



    voice "voice/a01/2100270a02.opus"
    bm "\"Thief.\""


translate english a0121_c221901e:


    "El teléfono se me cae de los dedos, ya entumecidos. Ella lo recupera con destreza y me lanza una mirada acusadora."


translate english a0121_1071c0a5:


    xy "\"I didn't steal it. It was lying on the ground over there.\""


translate english a0121_63e9db5c:



    voice "voice/a01/2100280a02.opus"
    bm "\"On the ground?\""


translate english a0121_a1b6783b:


    xy "\"Yeah.\""


translate english a0121_7f906e68:



    voice "voice/a01/2100290a02.opus"
    bm "\"\"\"\"\"\"\"\"......!!!\"Nnn...\"\"\"!!!\"What?\"\"What?\""


translate english a0121_ec88bea3:



    voice "voice/a01/2100300a02.opus"
    bm "\"So I owe you a favor?\""


translate english a0121_71d42437:


    xy "\"Well, I wouldn't go that far, but—\""


translate english a0121_826a15f7:



    voice "voice/a01/2100310a02.opus"
    bm "\"I'll make it up to you.\""


translate english a0121_dc8278ed:


    xy "\"Uhh...?\""


translate english a0121_1aa009b2:



    voice "voice/a01/2100320a02.opus"
    bm "\"Let's get zappy.\""


translate english a0121_d01eb237:



    voice "voice/a01/2100330a01.opus"
    mx "\"Hold it right there!\""


translate english a0121_1d224a3c:


    "Miyuki ahora tiembla visiblemente de rabia."


translate english a0121_bbe716ae:



    voice "voice/a01/2100340a01.opus"
    mx "\"What was it you called me? The childhood friend character?\""


translate english a0121_4428e026:



    voice "voice/a01/2100350a01.opus"
    mx "\"Are you seriously comparing me to a character in a video game?\""


translate english a0121_91c5e53b:



    voice "voice/a01/2100360a02.opus"
    bm "\"Yup.\""


translate english a0121_ba324bed:



    voice "voice/a01/2100370a01.opus"
    mx "\"Get real!\""


translate english a0121_8e69cff5:


    "Golpea con fuerza su bate contra el concreto."


translate english a0121_7a4d70d3:



    voice "voice/a01/2100380a01.opus"
    mx "\"Life is not a video game!\""


translate english a0121_aa427484:



    voice "voice/a01/2100390a01.opus"
    mx "\"You hear me? My feelings are the real deal. Some video game character can't possibly compare to—\""


translate english a0121_fd890258:



    voice "voice/a01/2100400a02.opus"
    bm "\"Got it!\""


translate english a0121_16a5167b:


    "El tono de Miyuki rezuma furia, pero la chica alza la mano como si ni se diera cuenta."


translate english a0121_2b87e368:



    voice "voice/a01/2100410a02.opus"
    bm "\"Can you kiss him?\""


translate english a0121_52f7fed0:



    voice "voice/a01/2100420a01.opus"
    mx "\"......What?\""


translate english a0121_d1690175:



    voice "voice/a01/2100430a02.opus"
    bm "\"If you're really dating, you can kiss him, right?\""


translate english a0121_8e0a662e:



    voice "voice/a01/2100440a01.opus"
    mx "\"Wh... That has nothing to do with—\""


translate english a0121_321db10c:



    voice "voice/a01/2100450a02.opus"
    aoi "\"Kiss him. Right now.\""


translate english a0121_7937e6a7:



    voice "voice/a01/2100460a02.opus"
    bm "\"Should be easy, right?\""


translate english a0121_1baf3fec:



    voice "voice/a01/2100470a01.opus"
    mx "\"\"......!!!\"\""


translate english a0121_bf264648:


    "La cara de Miyuki está tan roja que el atardecer ni se compara."


translate english a0121_606d000b:



    voice "voice/a01/2100480a01.opus"
    mx "\"F-Fine!\""


translate english a0121_4e5b6433:



    voice "voice/a01/2100490a01.opus"
    mx "\"What's a kiss between lovers?\""


translate english a0121_d2edf322:



    voice "voice/a01/2100500a01.opus"
    mx "\"P-Practically nothing...\""


translate english a0121_71671695:



    voice "voice/a01/2100510a01.opus"
    mx "\"\"\"\"\"\"\"\"......!!!\"Nnn...\"\"\"!!!\"What?\"\"What?\""


translate english a0121_db8ea37a:



    voice "voice/a01/2100520a01.opus"
    mx "\"I can do it... I can kiss him... But if we... Nnn...\""


translate english a0121_93bbea44:


    xy "\"Listen, if you're opposed to it, we really don't have t—\""


translate english a0121_1b5313bb:



    voice "voice/a01/2100530a01.opus"
    mx "\"I'm not opposed to it!\""


translate english a0121_f14b9846:



    voice "voice/a01/2100540a01.opus"
    mx "\"To tell the truth... I was always waiting for this.\""


translate english a0121_1ffd4e92:


    "De niños, éramos como dos gotas de agua."


translate english a0121_43544d1d:


    "¿Cuándo se vino todo abajo?"



translate english a0121_ec4f60fa:


    "¿Por qué empecé a distanciarme?"


translate english a0121_af9a07fb:



    voice "voice/a01/2100550a01.opus"
    mx "\"I'm really happy you asked to meet me up here.\""


translate english a0121_c758894e:


    xy "\"Miyuki...?\""


translate english a0121_7c997125:


    "Su voz apenas es un susurro."


translate english a0121_4d191e4f:



    voice "voice/a01/2100560a01.opus"
    mx "\"This will be my first kiss...\""


translate english a0121_a6c60e31:



    voice "voice/a01/2100570a01.opus"
    mx "\"But I'll give it...\""


translate english a0121_68cbef6f:



    voice "voice/a01/2100580a01.opus"
    mx "\"...to...\""


translate english a0121_2b41c724:



    voice "voice/a01/2100590a01.opus"
    mx "\"\"\"\"\"\"\"\"......!!!\"Nnn...\"\"\"!!!\"What?\"\"What?\""


translate english a0121_020ec4c3:



    voice "voice/a01/2100600a01.opus"
    mx "\"......Nnn...\""


translate english a0121_c7e88d6d:



    voice "voice/a01/2100610a01.opus"
    mx "\"Nnnnnggghhhh!\""


translate english a0121_9fed649c:



    voice "voice/a01/2100620a01.opus"
    mx "\"I can't! This is too awkward!\""


translate english a0121_a8c92930:



    voice "voice/a01/2100630a02.opus"
    aoi "\"Cute.\""


translate english a0121_79d11926:



    voice "voice/a01/2100640a01.opus"
    mx "\"I just prefer to keep private matters private, that's all! Public displays of affection are far too shameless!\""


translate english a0121_e8432636:



    voice "voice/a01/2100650a01.opus"
    mx "\"Tell her, Shinichi! The two of us are d-d-dating, aren't we?!\""


translate english a0121_690e2655:


    xy "\"What? I don't—\""


translate english a0121_71d0662b:



    voice "voice/a01/2100660a01.opus"
    mx "\"Make it clear to her! You're the one who called me up here, after all!\""


translate english a0121_b0eae70f:



    voice "voice/a01/2100670a01.opus"
    mx "\"Your actions pushed me to make up my mind, and...\""


translate english a0121_cb7178f3:


    "Espera, ¿qué?"


translate english a0121_bd9e8181:


    xy "¿Que hice qué ahora?"



translate english a0121_645be8b5:



    voice "voice/a01/2100680a01.opus"
    mx "\"Don't play dumb! I know you wrote this!\""


translate english a0121_502eda53:


    "Miyuki saca una carta de su bolsillo."


translate english a0121_81f411bc:


    "—Para: Srta. Sone Miyuki"


translate english a0121_d8ca7678:


    "—Te esperaré en la azotea después de clases."


translate english a0121_9914a255:


    "No hay firma."


translate english a0121_98658638:


    "Nunca he visto esta carta en mi vida."


translate english a0121_c4f47e93:



    voice "voice/a01/2100690a01.opus"
    mx "\"Wait... what? Wait...\""


translate english a0121_845495ac:



    voice "voice/a01/2100700a01.opus"
    mx "\"Now that I look at it, this... isn't your handwriting...\""


translate english a0121_36cf76be:



    voice "voice/a01/2100710b01.opus"
    xtl "\"Sorry I'm late!\""


translate english a0121_e5d5fd4c:



    voice "voice/a01/2100720b01.opus"
    xtl "\"Arriving just in the nick of time! Akebono Yuutarou, captain of the Boys and Dreams Club!\""


translate english a0121_2c65e5fa:


    "Claro."


translate english a0121_187b051b:


    "Fue este idiota."


translate english a0121_d07c8238:



    voice "voice/a01/2100730b01.opus"
    xtl "\"A rooftop confession! A legendary kiss! The two exchange eternal vows of love!\""


translate english a0121_f8d160c0:



    voice "voice/a01/2100740b01.opus"
    xtl "¡Sí, de esto están hechos los sueños! Yo, el gallardo príncipe, y tú, la hermosa doncella—¿qué?"



translate english a0121_d812d5b8:



    voice "voice/a01/2100750b01.opus"
    xtl "\"Sone-san...?\""


translate english a0121_2f74f730:



    voice "voice/a01/2100760a01.opus"
    mx "\"\"......!!!\"\""


translate english a0121_0887daff:


    "Visiblemente esforzándose por contenerse, Miyuki se dirige a la puerta—"


translate english a0121_6a38466f:


    "—y la cierra de golpe tras de sí."


translate english a0121_c6596c44:



    voice "voice/a01/2100770b01.opus"
    xtl "\"WHYYY?!\""


translate english a0121_c43457f2:


    xy "\"Nice going, genius.\""


translate english a0121_9e8ea640:



    voice "voice/a01/2100780b01.opus"
    xtl "\"What? Was it something I said?\""


translate english a0121_77c35c7a:



    voice "voice/a01/2100790b01.opus"
    xtl "\"Damn! I must have let all the dreams go to my head!\""


translate english a0121_6ac855bd:


    xy "\"Yeahhh, I don't think that's it...\""


translate english a0121_93355eaa:


    "Olvídalo. Mejor guardo la explicación para después, o nos quedaremos aquí parados toda la noche."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
