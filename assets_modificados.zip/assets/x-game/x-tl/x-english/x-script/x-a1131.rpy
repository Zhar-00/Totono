

translate english a1131_b8baed6c:


    "Incluso en otoño, el sol de la tarde sigue siendo tan implacable como siempre."


translate english a1131_22211458:


    "Mi visión se ve envuelta en una bruma blanca."


translate english a1131_800558b7:


    "Finalmente, tras parpadear unas cuantas veces, mi vista por fin registra una figura solitaria—"


translate english a1131_b905c0be:


    xy "\"Oh...\""


translate english a1131_5732996d:



    voice "voice/a11/3100010a01.opus"
    mx "\"¿Shinichi?\""


translate english a1131_9431c609:


    "Ahí de pie no está otra que la propia Sone Miyuki, con un bate de béisbol en la mano."


translate english a1131_8e11a8a5:


    xy "\"No puede ser...\""


translate english a1131_71b69b8a:


    xy "\"¿TÚ eres quien me invitó aquí arriba?\""


translate english a1131_49ab08d6:



    voice "voice/a11/3100020a01.opus"
    mx "\"No, genio. ¿Olvidaste cómo es mi letra?\""


translate english a1131_c0bc90ae:


    xy "\"Oh, cierto...\""


translate english a1131_68968f4c:


    "Encima de todo, también es una maestra de la caligrafía."


translate english a1131_49ef1ae0:


    "Por lo mismo, su letra es sumamente distintiva."


translate english a1131_3a1c551f:


    "Espera..."


translate english a1131_e2b79dea:


    xy "\"Entonces... ¿cómo sabías que era una invitación escrita?\""


translate english a1131_d98c617b:



    voice "voice/a11/3100030a01.opus"
    mx "\"Porque yo también recibí una.\""


translate english a1131_adbaa60c:


    "Levanta una hoja de papel."


translate english a1131_ebee3fc8:


    "Puedo notar que es exactamente el mismo papel que el mío."


translate english a1131_185b4abe:


    xy "\"Entonces eso significa...\""


translate english a1131_51c66de3:



    voice "voice/a11/3100040a01.opus"
    mx "\"No puedo imaginar qué espera lograr haciendo esto.\""


translate english a1131_0cee99a6:


    xy "\"¿Quién?\""


translate english a1131_bb7011cb:



    voice "voice/a11/3100050a01.opus"
    mx "\"Quién, en efecto... Solo esperemos y averigüemos.\""


translate english a1131_c5285979:


    xy "\"...Está bien.\""


translate english a1131_74780e0c:



    voice "voice/a11/3100060a01.opus"
    mx "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_0accd139:


    xy "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_527d68e6:


    "Nos quedamos ahí en silencio, lado a lado, contemplando el pueblo."


translate english a1131_34fb9aff:


    "El cielo otoñal despejado parece extenderse sin fin."


translate english a1131_78e898ca:



    voice "voice/a11/3100070a01.opus"
    mx "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_9b1eeac8:


    "Siento que necesitamos hablar de lo que pasó ayer."


translate english a1131_53a192cc:


    "Pero al mismo tiempo, se siente demasiado... personal, de alguna forma."


translate english a1131_85d1ffcf:


    "Antes nunca era así."


translate english a1131_46c88035:


    "En el pasado, teníamos una relación más juguetona."


translate english a1131_78a58e23:


    "No teníamos problema en bromear o tomarle el pelo al otro."


translate english a1131_e190fb81:


    "...Pero no podemos volver a como éramos."


translate english a1131_21383692:


    "A lo lejos, oigo el chasquido de un bate de béisbol."


translate english a1131_7a58018f:


    xy "\"Eso me recuerda... ¿Por qué trajiste el bate?\""


translate english a1131_c4e6d777:



    voice "voice/a11/3100080a01.opus"
    mx "\"Para practicar mi swing.\""


translate english a1131_f85b30b8:



    voice "voice/a11/3100090a01.opus"
    mx "\"Es para mi próxima actuación. La obra es sobre softbol.\""


translate english a1131_94288e28:


    xy "\"Interesante.\""


translate english a1131_fe0348ea:


    "Pensándolo bien, ayer también llevaba uno."


translate english a1131_dc285be1:


    xy "\"Estás muy dedicada, ¿eh?\""


translate english a1131_9c2bf62a:



    voice "voice/a11/3100100a01.opus"
    mx "\"Bueno, como estudiante de segundo año, algo así como que le robé el papel principal a los mayores, así que ahora tengo que ganármelo.\""


translate english a1131_156753d9:


    xy "\"Estoy impresionado.\""


translate english a1131_5cbb3956:


    "Cierro los ojos."


translate english a1131_4da06ccd:


    "En el pasado, solíamos ir a jugar al centro de bateo cubierto del pueblo."


translate english a1131_42c886b2:


    "Recuerdo su largo cabello ondeando con el movimiento..."


translate english a1131_63fd978f:


    "El movimiento de su swing perfecto y hermoso—"


translate english a1131_ade1c3ec:


    xy "\"Estás mintiendo, ¿verdad?\""


translate english a1131_75dc6729:



    voice "voice/a11/3100110a01.opus"
    mx "\"¿Sobre qué?\""


translate english a1131_19703396:


    xy "\"Sobre necesitar practicar. Ya eres una profesional.\""


translate english a1131_16e3875a:



    voice "voice/a11/3100120a01.opus"
    mx "\"Creo que me sobreestimas.\""


translate english a1131_6a486b76:


    xy "\"Lo dudo.\""


translate english a1131_900c98db:


    xy "\"Ayer también traías ese bate, ¿no?\""


translate english a1131_6e2eca92:


    "There's no way she'd bring a baseball bat to a romantic rendezvous \"just because.\"Tiene más tacto que eso."


translate english a1131_8ab4ec0b:


    "En realidad, ahora que lo pienso, recuerdo haber oído que usó un bate para defenderse de un admirador particularmente agresivo..."


translate english a1131_32619e95:


    "Al parecer, el tipo estuvo cerca de pasar el resto de su vida en una silla de ruedas."



translate english a1131_c58815b5:


    "En ese momento, pensé que era solo otro rumor exagerado, pero... donde hay humo, hay fuego, o eso dicen."


translate english a1131_fa0689bd:


    xy "\"¿Es para defensa personal?\""


translate english a1131_978b3d3a:



    voice "voice/a11/3100130a01.opus"
    mx "\"Digo, en parte, sí...\""


translate english a1131_e20a1553:


    xy "\"Está bien, bueno, trata de no matar a nadie con esa cosa.\""


translate english a1131_e77f21dd:



    voice "voice/a11/3100140a01.opus"
    mx "\"...¡Cállate!\""



translate english a1131_ce2ad8ff:


    "Miyuki hace un mohín."


translate english a1131_9f3b8969:


    "Nunca dejaría que este lado suyo se mostrara frente a nuestros compañeros, pero esta es la verdadera ella."


translate english a1131_c4eea653:



    voice "voice/a11/3100150a01.opus"
    mx "\"Solo soy humana. A veces me asusto.\""


translate english a1131_1f8be570:


    "No la culpo por mantenerse en guardia con tipos al azar."


translate english a1131_becaf064:


    "La puerta de la azotea es la única salida."


translate english a1131_71284986:


    "Si se cerrara con llave, quedaría atrapada, y así, su reputación perfecta se destruiría de la noche a la mañana."


translate english a1131_b7e768a9:


    "Mirando su rostro, todavía puedo ver rasgos de la chica que solía conocer."


translate english a1131_f17b0e76:


    xy "\"...Perdón.\""


translate english a1131_e95ea0b1:



    voice "voice/a11/3100160a01.opus"
    mx "\"No has cambiado nada. No puedo decir si eres muy lista o muy, muy densa.\""


translate english a1131_87147c18:


    xy "\"Mi culpa.\""


translate english a1131_81992fe0:



    voice "voice/a11/3100170a01.opus"
    mx "\"Está bien. Ya te di por perdido hace años.\""


translate english a1131_eb583b02:


    "Es cierto."


translate english a1131_237aa65e:


    "Nos rendimos el uno con el otro hace mucho, mucho tiempo."


translate english a1131_5749234b:



    voice "voice/a11/3100180a01.opus"
    mx "\"Qué gracioso... Nuestra misteriosa escritora de cartas se está tomando su dulce tiempo para subir.\""


translate english a1131_749b9dc0:


    xy "\"Vaya, no puedo imaginar por qué.\""


translate english a1131_3a2c0ab5:


    "Intercambiamos comentarios sarcásticos."


translate english a1131_5bf679bf:


    "Me siento un poco más cómodo ahora que sé que la vieja ella no se ha ido del todo."


translate english a1131_78a0973f:


    "Eso hace más fácil reunir el valor para hablarle."


translate english a1131_b2fd7d52:


    xy "\"Escucha... Sobre ayer...\""


translate english a1131_7ecf3d2d:



    voice "voice/a11/3100190a01.opus"
    mx "\"¿Ayer?\""


translate english a1131_3621fba2:



    voice "voice/a11/3100200a01.opus"
    mx "\"¡Oh, cierto! ¡Eso! Emm...\""


translate english a1131_088f7456:


    xy "\"Todo fue una actuación, ¿verdad? ¿Para ayudarme a salir de ese aprieto?\""


translate english a1131_1f5989d7:



    voice "voice/a11/3100210a01.opus"
    mx "\"¡Claro! Parecías estar realmente asustado.\""


translate english a1131_d189e430:


    xy "\"Sí, me tomó totalmente por sorpresa. Digo, apenas la conozco.\""


translate english a1131_6701305f:


    xy "\"Gracias por aparecer cuando lo hiciste. En serio.\""


translate english a1131_799a1889:



    voice "voice/a11/3100220a01.opus"
    mx "\"No hay necesidad de agradecer. Apenas hice nada.\""


translate english a1131_cbe08ef4:


    "Mira al suelo, bajando la guardia de una forma que sería impensable frente a cualquier otro."


translate english a1131_b3536013:


    "Hago una pausa por un momento."


translate english a1131_bcf6b061:


    "Luego, cuando se calma, le pregunto de nuevo."


translate english a1131_343a08e1:


    xy "\"Esa confesión de amor... Todo fue solo una actuación.\""


translate english a1131_653b1c45:


    xy "\"...¿Verdad?\""


translate english a1131_8c192ebe:



    voice "voice/a11/3100230a01.opus"
    mx "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_56854832:



    voice "voice/a11/3100240a01.opus"
    mx "\"Verdad.\""


translate english a1131_8033be30:



    voice "voice/a11/3100250a01.opus"
    mx "\"No fue real. Solo olvídalo.\""


translate english a1131_3717bfe8:


    xy "\"Está bien, lo haré.\""


translate english a1131_60d3a723:


    "Hay un acuerdo tácito entre nosotros."


translate english a1131_bc933bf9:


    "Nosotros dos somos viejos amigos y nada más."


translate english a1131_c83f2369:


    "Tengo que mantener mi distancia de ella."


translate english a1131_053ab321:


    "Eso es crucial."


translate english a1131_f42056fa:



    voice "voice/a11/3100260a01.opus"
    mx "\"En fin... Esa Mukou-san sí que es algo.\""


translate english a1131_2a1de97b:


    "Noto que está llevando la conversación de vuelta a terreno seguro."


translate english a1131_928bfb10:



    voice "voice/a11/3100270a01.opus"
    mx "\"Supongo que los rumores son ciertos. Está más loca que una cabra.\""


translate english a1131_27db9671:


    xy "\"Y con un grave caso de cerebro de gamer.\""


translate english a1131_f8ce9183:



    voice "voice/a11/3100280a01.opus"
    mx "\"¿Qué demonios es cerebro de gamer?\""


translate english a1131_686e6704:


    xy "\"Es cuando empiezas a confundir los videojuegos con la realidad.\""


translate english a1131_73176a59:



    voice "voice/a11/3100290a01.opus"
    mx "\"...Odio eso.\""


translate english a1131_1ab33c04:


    "Su tono se agudiza de repente."


translate english a1131_ad3c8c5d:



    voice "voice/a11/3100300a01.opus"
    mx "\"¿Es por eso que siempre se comporta como se comporta?\""


translate english a1131_6c747b63:



    voice "voice/a11/3100310a01.opus"
    mx "\"No parece que le importe nada. O al menos, nunca parece prestar mucha atención.\""


translate english a1131_a0c18d1b:



    voice "voice/a11/3100320a01.opus"
    mx "\"Honestamente, me enfurece.\""


translate english a1131_917f009f:


    "Miyuki's the type to always put 100%% into everything she does."


translate english a1131_646f7bed:


    "Así que tiene sentido que no se lleve bien con alguien tan distraída como Mukou."


translate english a1131_2d0631e0:


    xy "\"Vamos, no seas tan dura con ella.\""


translate english a1131_49a076ac:


    xy "\"Tener un mal agarre de la realidad tampoco debe ser fácil para ella, ¿sab—?\""


translate english a1131_830108fa:



    voice "voice/a11/3100330a02.opus"
    aoi "\"Eso no es cierto.\""


translate english a1131_84646e71:



    voice "voice/a11/3100340a01.opus"
    mx "\"¿Quién está ahí?\""


translate english a1131_c003fec7:


    xy "\"¿Mukou?\""


translate english a1131_19b795b9:


    "Igual que ayer, está de pie en la azotea sobre las escaleras."


translate english a1131_8ae8b4f5:


    xy "\"¿Estuviste aquí todo el tiempo?\""


translate english a1131_7d2d240c:



    voice "voice/a11/3100350a02.opus"
    aoi "\"Aoi puede distinguir entre la realidad y la ficción.\""


translate english a1131_ee5d13f5:



    voice "voice/a11/3100360a02.opus"
    aoi "\"Este mundo es un juego.\""


translate english a1131_799e2e67:



    voice "voice/a11/3100370a02.opus"
    aoi "\"Aoi es una opción romántica.\""



translate english a1131_8d97eab3:



    voice "voice/a11/3100380a01.opus"
    mx "\"No otra vez con estas tonterías...\""


translate english a1131_14759c64:



    voice "voice/a11/3100390a01.opus"
    mx "\"Veamos tus pruebas, entonces.\""


translate english a1131_1433247d:



    voice "voice/a11/3100400a02.opus"
    aoi "\"¿Pruebas?\""


translate english a1131_b09614bd:



    voice "voice/a11/3100410a02.opus"
    aoi "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_1f5ec427:


    "Mukou ladea la cabeza, desconcertada."


translate english a1131_74d70a62:



    voice "voice/a11/3100420a02.opus"
    aoi "\"Bip bip...\""


translate english a1131_7739e700:


    "Luego mete las manos bajo la falda y empieza a bajarse los calzones."


translate english a1131_b6623422:



    voice "voice/a11/3100430a01.opus"
    mx "\"¡Alto ahí! ¿¡Qué demonios crees que estás haciendo!?\""


translate english a1131_d133f45c:



    voice "voice/a11/3100440a02.opus"
    aoi "\"Aoi se desnudará y aparecerá la marca de agua internacional.\""


translate english a1131_11752b95:


    "Sí, eh, lo dudo sinceramente..."


translate english a1131_355d1247:



    voice "voice/a11/3100450a01.opus"
    mx "\"¡No te atrevas! ¿¡No tienes vergüenza!?\""


translate english a1131_ac8864c9:



    voice "voice/a11/3100460a02.opus"
    aoi "\"¿Qué tiene de vergonzoso?\""


translate english a1131_9193b5dc:


    xy "\"¿En serio no lo sabes?\""


translate english a1131_a9222bc0:


    "Seguramente tiene al menos ALGO de sentido común, ¿no?"


translate english a1131_d3673ea1:



    voice "voice/a11/3100470a01.opus"
    mx "\"¡Como sea! ¡Solo mantén la ropa puesta, por el amor de Dios!\""


translate english a1131_c926ea64:



    voice "voice/a11/3100480a02.opus"
    aoi "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_deb2edd3:


    "Mukou se queda callada, como perdida en sus pensamientos."


translate english a1131_7e4ac428:



    voice "voice/a11/3100490a02.opus"
    aoi "\"Está bien.\""


translate english a1131_4897ccf9:



    voice "voice/a11/3100500a02.opus"
    aoi "\"Otra prueba, entonces.\""


translate english a1131_369d8e9a:


    "Saca su celular del bolsillo."


translate english a1131_145d3b80:



    voice "voice/a11/3100510a02.opus"
    aoi "\"Dios.\""


translate english a1131_f75eba52:



    voice "voice/a11/3100520a01.opus"
    mx "\"...¿Dios?\""


translate english a1131_4b18b3ca:



    voice "voice/a11/3100530a02.opus"
    aoi "\"Sí. El dios de las novelas visuales.\""


translate english a1131_307db502:



    voice "voice/a11/3100540a02.opus"
    aoi "\"Este mundo es un videojuego... un programa.\""


translate english a1131_3495b089:



    voice "voice/a11/3100550a02.opus"
    aoi "\"Y los programas se pueden parchear.\""


translate english a1131_77a1101a:


    xy "\"¿Y eso qué significa?\""


translate english a1131_c17cb5f8:



    voice "voice/a11/3100560a02.opus"
    aoi "\"El mundo cambiará.\""


translate english a1131_58cf6e77:



    voice "voice/a11/3100570a01.opus"
    mx "\"Ah, ¿sí? Entonces muéstranos un milagro, ¿quieres?\""


translate english a1131_594d17c3:



    voice "voice/a11/3100580a02.opus"
    aoi "\"Entendido.\""


translate english a1131_b3631cf9:


    "Mukou asiente distraídamente y alza el teléfono hacia el aire."


translate english a1131_aa04a73e:


    "Tengo la sensación de saber a quién está llamando."


translate english a1131_749a6fd4:



    voice "voice/a11/3100590a02.opus"
    aoi "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english a1131_bd72bb08:



    voice "voice/a11/3100600a02.opus"
    aoi "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english a1131_87e8fa5a:



    voice "voice/a11/3100610a01.opus"
    mx "\"¿Mukou-san? ¿Qué estás haciendo?\""


translate english a1131_ffef0610:


    xy "\"Creo que está llamando a Dios.\""


translate english a1131_d611e041:



    voice "voice/a11/3100620a01.opus"
    mx "\"¿Desde cuándo Dios tiene número de teléfono?\""


translate english a1131_085ccb88:


    xy "\"Desde nunca, que yo sepa.\""


translate english a1131_3238fd2e:



    voice "voice/a11/3100630a01.opus"
    mx "\"Sí, no lo creía.\""


translate english a1131_728f2bd5:



    voice "voice/a11/3100640a02.opus"
    aoi "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english a1131_3f96fe2a:



    voice "voice/a11/3100650a02.opus"
    aoi "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english a1131_0c8b994f:


    "As usual, \"God\"no muestra señales de contestar."


translate english a1131_1b8da857:


    "No obstante, Mukou sigue llamando."


translate english a1131_b4786c1b:



    voice "voice/a11/3100660a01.opus"
    mx "\"A estas alturas ya duele verlo...\""


translate english a1131_5d93a4f5:



    voice "voice/a11/3100670a01.opus"
    mx "\"¿Ya terminaste?\""


translate english a1131_5ce30338:


    xy "\"Probablemente no hasta que Él responda.\""


translate english a1131_28f27f16:


    "Conociendo a Mukou, parece la conclusión obvia."


translate english a1131_d8793634:


    "Eso explicaría por qué se desmayó de repente ayer..."


translate english a1131_cf41cf2e:



    voice "voice/a11/3100680a01.opus"
    mx "\"...Oí que tiene una situación familiar complicada.\""


translate english a1131_478a02fb:


    xy "\"¿La tiene?\""


translate english a1131_af869a72:



    voice "voice/a11/3100690a01.opus"
    mx "\"Supuestamente nunca va a casa. Duerme en una cama distinta cada noche.\""


translate english a1131_2a2a54ff:



    voice "voice/a11/3100700a01.opus"
    mx "\"Aunque en las camas de quién, no estoy seguro.\""


translate english a1131_0accd139_1:


    xy "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_5374c625:


    "En el fondo de mi mente, recuerdo lo que Yuutarou me dijo antes... Los rumores de que anda durmiendo por ahí."


translate english a1131_e568dd37:



    voice "voice/a11/3100710a02.opus"
    aoi "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english a1131_fd9c49ce:



    voice "voice/a11/3100720a02.opus"
    aoi "\"Bip bip bip bip bip bip bip—\""


translate english a1131_fb040b51:


    xy "\"Hey, ¿Mukou?\""


translate english a1131_3800cc01:



    voice "voice/a11/3100730a02.opus"
    aoi "\"¿Bip bip?\""


translate english a1131_d7cecd45:


    xy "\"¿Quizás tu teléfono no tiene señal aquí arriba?\""


translate english a1131_e6112c5a:


    xy "\"O, no sé... quizás Dios está un poco ocupado ahora.\""


translate english a1131_d455cddc:



    voice "voice/a11/3100740a02.opus"
    aoi "\"...¿Bip bip? ¿Eso crees?\""


translate english a1131_866f27fe:



    voice "voice/a11/3100750a02.opus"
    aoi "\"Quizás Aoi no tiene suficiente batería—\""


translate english a1131_da279daa:



    voice "voice/a11/3100760a01.opus"
    mx "\"¡Solo bájate de ahí, ¿quieres?\""


translate english a1131_1872a547:



    voice "voice/a11/3100770a01.opus"
    mx "\"Querías hablar con nosotros, ¿verdad?\""


translate english a1131_516f87d2:



    voice "voice/a11/3100780a02.opus"
    aoi "\"Tres, dos, uno...\""


translate english a1131_035cb118:


    xy "\"¡Hey! ¡NO saltes desde ahí!\""


translate english a1131_36f8539c:



    voice "voice/a11/3100790a02.opus"
    aoi "\"...¿Bip bip? ¿Eso crees?\""


translate english a1131_b3243e76:



    voice "voice/a11/3100800a02.opus"
    aoi "\"¿Por qué no?\""


translate english a1131_da147fab:


    xy "\"Dios mío... Haah...\""


translate english a1131_284f9b71:


    "Porque no es SEGURO, genio."


translate english a1131_aa18404f:


    "¿Cómo ha sobrevivido tanto tiempo sin saber estas cosas?"


translate english a1131_1f2bb50a:



    voice "voice/a11/3100810a01.opus"
    mx "\"Solo usa la escalera, por favor.\""


translate english a1131_49ab0513:



    voice "voice/a11/3100820a02.opus"
    aoi "\"Entendido.\""


translate english a1131_b8b8514c:


    "Procede a bajar un poco más imprudentemente de lo que me habría gustado."


translate english a1131_f7b84014:


    "Finalmente, los tres estamos de pie en terreno parejo."


translate english a1131_ed39c8b1:



    voice "voice/a11/3100830a01.opus"
    mx "\"Entonces, ¿por qué pediste vernos aquí?\""


translate english a1131_ea84a899:


    "¿Qué?"


translate english a1131_4f0441f8:


    xy "\"Espera... Entonces eso significa...\""


translate english a1131_5fec36c6:



    voice "voice/a11/3100840a01.opus"
    mx "\"Tú escribiste esas cartas, ¿verdad?\""


translate english a1131_a38374d0:



    voice "voice/a11/3100850a02.opus"
    aoi "\"Ajá.\""


translate english a1131_1f6fa5c0:



    voice "voice/a11/3100860a01.opus"
    mx "\"Bueno entonces. Primero lo primero, déjame dejar esto claro. Como quizás ya hayas oído o no...\""


translate english a1131_5646bdec:



    voice "voice/a11/3100870a01.opus"
    mx "\"Todo lo que pasó ayer fue un total malentendido.\""


translate english a1131_040984d6:



    voice "voice/a11/3100880a01.opus"
    mx "\"Shinichi y yo somos viejos amigos, eso es todo.\""


translate english a1131_34e450a8:



    voice "voice/a11/3100890a01.opus"
    mx "\"Nada más, nada menos.\""


translate english a1131_8eed6115:



    voice "voice/a11/3100900a01.opus"
    mx "\"No hay nada romántico entre nosotros.\""


translate english a1131_3a9e5316:


    "Sí..."


translate english a1131_2a0cb5e3:


    "Es lo mejor."


translate english a1131_b0e0b390:



    voice "voice/a11/3100910a02.opus"
    aoi "\"¡Entendido!\""


translate english a1131_ac6458a7:



    voice "voice/a11/3100920a01.opus"
    mx "\"...¿Qué pasa?\""


translate english a1131_ce4876fd:



    voice "voice/a11/3100930a02.opus"
    aoi "\"Plan A.\""


translate english a1131_367964a2:



    voice "voice/a11/3100940a02.opus"
    aoi "\"Misión de amistad.\""


translate english a1131_6dbb1528:



    voice "voice/a11/3100950a01.opus"
    mx "¿Qué?"


translate english a1131_8ddf45e3:



    voice "voice/a11/3100960a02.opus"
    aoi "\"Aoi y Miyuki y Shinichi...\""


translate english a1131_7e1d2995:



    voice "voice/a11/3100970a02.opus"
    aoi "\"Todos seremos amigos.\""


translate english a1131_8ab2a18f:



    voice "voice/a11/3100980a02.opus"
    aoi "\"¿Ok?\""


translate english strings:


    old "Дружить"
    new "Ser amigos"


    old "Не дружить"
    new "No ser amigos"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
