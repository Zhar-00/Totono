

translate english a1131_b8baed6c:


    "Incluso en otoño, el sol de la tarde sigue siendo tan implacable como siempre."


translate english a1131_22211458:


    "Mi visión se ve envuelta en una bruma blanca."


translate english a1131_800558b7:


    "Finalmente, tras parpadear unas cuantas veces, mi vista por fin registra una figura solitaria—"


translate english a1131_b905c0be:


    xy "\"Oh...\""


translate english a1131_5732996d:



    voice "voice/a11/3100010a01.opus"
    mx "\"Shinichi?\""


translate english a1131_9431c609:


    "Ahí de pie no está otra que la propia Sone Miyuki, con un bate de béisbol en la mano."


translate english a1131_8e11a8a5:


    xy "\"No way...\""


translate english a1131_71b69b8a:


    xy "\"YOU'RE the one who invited me up here?\""


translate english a1131_49ab08d6:



    voice "voice/a11/3100020a01.opus"
    mx "\"No, genius. Did you forget what my handwriting looks like?\""


translate english a1131_c0bc90ae:


    xy "\"Oh, right...\""


translate english a1131_68968f4c:


    "Encima de todo, también es una maestra de la caligrafía."


translate english a1131_49ef1ae0:


    "Por lo mismo, su letra es sumamente distintiva."


translate english a1131_3a1c551f:


    "Espera..."


translate english a1131_e2b79dea:


    xy "\"Then... how'd you know it was a written invitation?\""


translate english a1131_d98c617b:



    voice "voice/a11/3100030a01.opus"
    mx "\"Because I got one, too.\""


translate english a1131_adbaa60c:


    "Levanta una hoja de papel."


translate english a1131_ebee3fc8:


    "Puedo notar que es exactamente el mismo papel que el mío."


translate english a1131_185b4abe:


    xy "\"Then that means...\""


translate english a1131_51c66de3:



    voice "voice/a11/3100040a01.opus"
    mx "\"Can't imagine what she hopes to achieve by doing this.\""


translate english a1131_0cee99a6:


    xy "\"Who?\""


translate english a1131_bb7011cb:



    voice "voice/a11/3100050a01.opus"
    mx "\"Who, indeed... Let's just wait and find out.\""


translate english a1131_c5285979:


    xy "\"...Okay then.\""


translate english a1131_74780e0c:



    voice "voice/a11/3100060a01.opus"
    mx "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_0accd139:


    xy "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_527d68e6:


    "Nos quedamos ahí en silencio, lado a lado, contemplando el pueblo."


translate english a1131_34fb9aff:


    "El cielo otoñal despejado parece extenderse sin fin."


translate english a1131_78e898ca:



    voice "voice/a11/3100070a01.opus"
    mx "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_9b1eeac8:


    "Siento que necesitamos hablar de lo que pasó ayer."


translate english a1131_53a192cc:


    "Pero al mismo tiempo, se siente demasiado... personal, de alguna forma."


translate english a1131_85d1ffcf:


    "Antes nunca era así."


translate english a1131_46c88035:


    "En el pasado, teníamos una relación más juguetona."


translate english a1131_78a58e23:


    "No teníamos problema en bromear o tomarle el pelo al otro."


translate english a1131_e190fb81:


    "...Pero no podemos volver a como éramos."


translate english a1131_21383692:


    "A lo lejos, oigo el chasquido de un bate de béisbol."


translate english a1131_7a58018f:


    xy "\"That reminds me... Why'd you bring the bat?\""


translate english a1131_c4e6d777:



    voice "voice/a11/3100080a01.opus"
    mx "\"To practice my swing.\""


translate english a1131_f85b30b8:



    voice "voice/a11/3100090a01.opus"
    mx "\"It's for my next performance. The play is about softball.\""


translate english a1131_94288e28:


    xy "\"Interesting.\""


translate english a1131_fe0348ea:


    "Pensándolo bien, ayer también llevaba uno."


translate english a1131_dc285be1:


    xy "\"You're really dedicated, huh?\""


translate english a1131_9c2bf62a:



    voice "voice/a11/3100100a01.opus"
    mx "\"Well, as a second-year, I did kind of steal the lead role from the older students, so now I need to earn it.\""


translate english a1131_156753d9:


    xy "\"I'm impressed.\""


translate english a1131_5cbb3956:


    "Cierro los ojos."


translate english a1131_4da06ccd:


    "En el pasado, solíamos ir a jugar al centro de bateo cubierto del pueblo."


translate english a1131_42c886b2:


    "Recuerdo su largo cabello ondeando con el movimiento..."


translate english a1131_63fd978f:


    "El movimiento de su swing perfecto y hermoso—"


translate english a1131_ade1c3ec:


    xy "\"You're lying, aren't you?\""


translate english a1131_75dc6729:



    voice "voice/a11/3100110a01.opus"
    mx "\"About what?\""


translate english a1131_19703396:


    xy "\"Needing to practice. You're already a pro.\""


translate english a1131_16e3875a:



    voice "voice/a11/3100120a01.opus"
    mx "\"I think you overestimate me.\""


translate english a1131_6a486b76:


    xy "\"Doubt it.\""


translate english a1131_900c98db:


    xy "\"You had that bat with you yesterday too, didn't you?\""


translate english a1131_6e2eca92:


    "There's no way she'd bring a baseball bat to a romantic rendezvous \"just because.\"Tiene más tacto que eso."


translate english a1131_8ab4ec0b:


    "En realidad, ahora que lo pienso, recuerdo haber oído que usó un bate para defenderse de un admirador particularmente agresivo..."


translate english a1131_32619e95:


    "Al parecer, el tipo estuvo cerca de pasar el resto de su vida en una silla de ruedas."



translate english a1131_c58815b5:


    "En ese momento, pensé que era solo otro rumor exagerado, pero... donde hay humo, hay fuego, o eso dicen."


translate english a1131_fa0689bd:


    xy "\"Is it for self-defense?\""


translate english a1131_978b3d3a:



    voice "voice/a11/3100130a01.opus"
    mx "\"I mean, partially, yeah...\""


translate english a1131_e20a1553:


    xy "\"Alright, well, try not to kill anyone with that thing.\""


translate english a1131_e77f21dd:



    voice "voice/a11/3100140a01.opus"
    mx "\"...Shut up!\""



translate english a1131_ce2ad8ff:


    "Miyuki hace un mohín."


translate english a1131_9f3b8969:


    "Nunca dejaría que este lado suyo se mostrara frente a nuestros compañeros, pero esta es la verdadera ella."


translate english a1131_c4eea653:



    voice "voice/a11/3100150a01.opus"
    mx "\"I'm only human. I get scared sometimes.\""


translate english a1131_1f8be570:


    "No la culpo por mantenerse en guardia con tipos al azar."


translate english a1131_becaf064:


    "La puerta de la azotea es la única salida."


translate english a1131_71284986:


    "Si se cerrara con llave, quedaría atrapada, y así, su reputación perfecta se destruiría de la noche a la mañana."


translate english a1131_b7e768a9:


    "Mirando su rostro, todavía puedo ver rasgos de la chica que solía conocer."


translate english a1131_f17b0e76:


    xy "\"...Sorry.\""


translate english a1131_e95ea0b1:



    voice "voice/a11/3100160a01.opus"
    mx "\"You haven't changed a bit. I can't tell if you're really smart or really, really dense.\""


translate english a1131_87147c18:


    xy "\"My bad.\""


translate english a1131_81992fe0:



    voice "voice/a11/3100170a01.opus"
    mx "\"It's fine. I gave up on you years ago.\""


translate english a1131_eb583b02:


    "Es cierto."


translate english a1131_237aa65e:


    "Nos rendimos el uno con el otro hace mucho, mucho tiempo."


translate english a1131_5749234b:



    voice "voice/a11/3100180a01.opus"
    mx "\"Funny... Our mystery letter writer sure is taking her sweet time to get up here.\""


translate english a1131_749b9dc0:


    xy "\"Gee, can't imagine why.\""


translate english a1131_3a2c0ab5:


    "Intercambiamos comentarios sarcásticos."


translate english a1131_5bf679bf:


    "Me siento un poco más cómodo ahora que sé que la vieja ella no se ha ido del todo."


translate english a1131_78a0973f:


    "Eso hace más fácil reunir el valor para hablarle."


translate english a1131_b2fd7d52:


    xy "\"Listen... About yesterday...\""


translate english a1131_7ecf3d2d:



    voice "voice/a11/3100190a01.opus"
    mx "\"Yesterday?\""


translate english a1131_3621fba2:



    voice "voice/a11/3100200a01.opus"
    mx "\"Oh, right! That! Umm...\""


translate english a1131_088f7456:


    xy "\"That was all an act, right? To help get me out of that jam?\""


translate english a1131_1f5989d7:



    voice "voice/a11/3100210a01.opus"
    mx "\"Of course! You looked like you were really freaked out.\""


translate english a1131_d189e430:


    xy "\"Yeah, it totally threw me for a loop. I mean, I barely even know her.\""


translate english a1131_6701305f:


    xy "\"Thank you for showing up when you did. Seriously.\""


translate english a1131_799a1889:



    voice "voice/a11/3100220a01.opus"
    mx "\"No need to thank me. I hardly did a thing.\""


translate english a1131_cbe08ef4:


    "Mira al suelo, bajando la guardia de una forma que sería impensable frente a cualquier otro."


translate english a1131_b3536013:


    "Hago una pausa por un momento."


translate english a1131_bcf6b061:


    "Luego, cuando se calma, le pregunto de nuevo."


translate english a1131_343a08e1:


    xy "\"That love confession... It was all just an act.\""


translate english a1131_653b1c45:


    xy "\"...Right?\""


translate english a1131_8c192ebe:



    voice "voice/a11/3100230a01.opus"
    mx "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_56854832:



    voice "voice/a11/3100240a01.opus"
    mx "\"Right.\""


translate english a1131_8033be30:



    voice "voice/a11/3100250a01.opus"
    mx "\"It wasn't real. Just forget it.\""


translate english a1131_3717bfe8:


    xy "\"Alright, I will.\""


translate english a1131_60d3a723:


    "Hay un acuerdo tácito entre nosotros."


translate english a1131_bc933bf9:


    "Nosotros dos somos viejos amigos y nada más."


translate english a1131_c83f2369:


    "Tengo que mantener mi distancia de ella."


translate english a1131_053ab321:


    "Eso es crucial."


translate english a1131_f42056fa:



    voice "voice/a11/3100260a01.opus"
    mx "\"Anyway... That Mukou-san sure is something else.\""


translate english a1131_2a1de97b:


    "Noto que está llevando la conversación de vuelta a terreno seguro."


translate english a1131_928bfb10:



    voice "voice/a11/3100270a01.opus"
    mx "\"I guess the rumors are true. She's nuttier than a fruitcake.\""


translate english a1131_27db9671:


    xy "\"And with a bad case of gamer brain.\""


translate english a1131_f8ce9183:



    voice "voice/a11/3100280a01.opus"
    mx "\"The heck is gamer brain?\""


translate english a1131_686e6704:


    xy "\"It's when you start to confuse video games with reality.\""


translate english a1131_73176a59:



    voice "voice/a11/3100290a01.opus"
    mx "\"...I hate that.\""


translate english a1131_1ab33c04:


    "Su tono se agudiza de repente."


translate english a1131_ad3c8c5d:



    voice "voice/a11/3100300a01.opus"
    mx "\"Is that why she always behaves the way she does?\""


translate english a1131_6c747b63:



    voice "voice/a11/3100310a01.opus"
    mx "\"She doesn't seem to care about anything. Or at least, she never seems to pay much attention.\""


translate english a1131_a0c18d1b:



    voice "voice/a11/3100320a01.opus"
    mx "\"Honestly, it infuriates me.\""


translate english a1131_917f009f:


    "Miyuki's the type to always put 100%% into everything she does."


translate english a1131_646f7bed:


    "Así que tiene sentido que no se lleve bien con alguien tan distraída como Mukou."


translate english a1131_2d0631e0:


    xy "\"C'mon, don't be so hard on her.\""


translate english a1131_49a076ac:


    xy "\"Having a poor grip on reality can't exactly be easy for her either, y'know—\""


translate english a1131_830108fa:



    voice "voice/a11/3100330a02.opus"
    aoi "\"That's not true.\""


translate english a1131_84646e71:



    voice "voice/a11/3100340a01.opus"
    mx "\"Who's there?\""


translate english a1131_c003fec7:


    xy "\"Mukou?\""


translate english a1131_19b795b9:


    "Igual que ayer, está de pie en la azotea sobre las escaleras."


translate english a1131_8ae8b4f5:


    xy "\"Have you been here the whole time?\""


translate english a1131_7d2d240c:



    voice "voice/a11/3100350a02.opus"
    aoi "\"Aoi can tell the difference between reality and fiction.\""


translate english a1131_ee5d13f5:



    voice "voice/a11/3100360a02.opus"
    aoi "\"This world is a game.\""


translate english a1131_799e2e67:



    voice "voice/a11/3100370a02.opus"
    aoi "\"Aoi is a romance option.\""



translate english a1131_8d97eab3:



    voice "voice/a11/3100380a01.opus"
    mx "\"Not this nonsense again...\""


translate english a1131_14759c64:



    voice "voice/a11/3100390a01.opus"
    mx "\"Let's see your proof, then.\""


translate english a1131_1433247d:



    voice "voice/a11/3100400a02.opus"
    aoi "\"Proof?\""


translate english a1131_b09614bd:



    voice "voice/a11/3100410a02.opus"
    aoi "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_1f5ec427:


    "Mukou ladea la cabeza, desconcertada."


translate english a1131_74d70a62:



    voice "voice/a11/3100420a02.opus"
    aoi "\"Boop boop...\""


translate english a1131_7739e700:


    "Luego mete las manos bajo la falda y empieza a bajarse los calzones."


translate english a1131_b6623422:



    voice "voice/a11/3100430a01.opus"
    mx "\"Stop right there! What on earth do you think you're doing?!\""


translate english a1131_d133f45c:



    voice "voice/a11/3100440a02.opus"
    aoi "\"Aoi will get naked and the international watermark will appear.\""


translate english a1131_11752b95:


    "Sí, eh, lo dudo sinceramente..."


translate english a1131_355d1247:



    voice "voice/a11/3100450a01.opus"
    mx "\"Don't you DARE! Have you no shame?!\""


translate english a1131_ac8864c9:



    voice "voice/a11/3100460a02.opus"
    aoi "\"What's shameful about it?\""


translate english a1131_9193b5dc:


    xy "\"You seriously don't know?\""


translate english a1131_a9222bc0:


    "Seguramente tiene al menos ALGO de sentido común, ¿no?"


translate english a1131_d3673ea1:



    voice "voice/a11/3100470a01.opus"
    mx "\"Whatever! Just keep your clothes on, for god's sake!\""


translate english a1131_c926ea64:



    voice "voice/a11/3100480a02.opus"
    aoi "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_deb2edd3:


    "Mukou se queda callada, como perdida en sus pensamientos."


translate english a1131_7e4ac428:



    voice "voice/a11/3100490a02.opus"
    aoi "\"Okay.\""


translate english a1131_4897ccf9:



    voice "voice/a11/3100500a02.opus"
    aoi "\"Different proof, then.\""


translate english a1131_369d8e9a:


    "Saca su celular del bolsillo."


translate english a1131_145d3b80:



    voice "voice/a11/3100510a02.opus"
    aoi "\"God.\""


translate english a1131_f75eba52:



    voice "voice/a11/3100520a01.opus"
    mx "\"...God?\""


translate english a1131_4b18b3ca:



    voice "voice/a11/3100530a02.opus"
    aoi "\"Yes. The god of visual novels.\""


translate english a1131_307db502:



    voice "voice/a11/3100540a02.opus"
    aoi "\"This world is a video game... a program.\""


translate english a1131_3495b089:



    voice "voice/a11/3100550a02.opus"
    aoi "\"And programs can be patched.\""


translate english a1131_77a1101a:


    xy "\"What's that supposed to mean?\""


translate english a1131_c17cb5f8:



    voice "voice/a11/3100560a02.opus"
    aoi "\"The world will change.\""


translate english a1131_58cf6e77:



    voice "voice/a11/3100570a01.opus"
    mx "\"Oh yeah? Show us a miracle then, would you?\""


translate english a1131_594d17c3:



    voice "voice/a11/3100580a02.opus"
    aoi "\"Got it.\""


translate english a1131_b3631cf9:


    "Mukou asiente distraídamente y alza el teléfono hacia el aire."


translate english a1131_aa04a73e:


    "Tengo la sensación de saber a quién está llamando."


translate english a1131_749a6fd4:



    voice "voice/a11/3100590a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english a1131_bd72bb08:



    voice "voice/a11/3100600a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english a1131_87e8fa5a:



    voice "voice/a11/3100610a01.opus"
    mx "\"Mukou-san? What are you doing?\""


translate english a1131_ffef0610:


    xy "\"I think she's calling God.\""


translate english a1131_d611e041:



    voice "voice/a11/3100620a01.opus"
    mx "\"Since when does God have a phone number?\""


translate english a1131_085ccb88:


    xy "\"Since never, as far as I know.\""


translate english a1131_3238fd2e:



    voice "voice/a11/3100630a01.opus"
    mx "\"Yeah, didn't think so.\""


translate english a1131_728f2bd5:



    voice "voice/a11/3100640a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english a1131_3f96fe2a:



    voice "voice/a11/3100650a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english a1131_0c8b994f:


    "As usual, \"God\"no muestra señales de contestar."


translate english a1131_1b8da857:


    "No obstante, Mukou sigue llamando."


translate english a1131_b4786c1b:



    voice "voice/a11/3100660a01.opus"
    mx "\"At this point it just hurts to watch...\""


translate english a1131_5d93a4f5:



    voice "voice/a11/3100670a01.opus"
    mx "\"Are you done yet?\""


translate english a1131_5ce30338:


    xy "\"Not until He answers, probably.\""


translate english a1131_28f27f16:


    "Conociendo a Mukou, parece la conclusión obvia."


translate english a1131_d8793634:


    "Eso explicaría por qué se desmayó de repente ayer..."


translate english a1131_cf41cf2e:



    voice "voice/a11/3100680a01.opus"
    mx "\"...I heard she has a complicated family situation.\""


translate english a1131_478a02fb:


    xy "\"She does?\""


translate english a1131_af869a72:



    voice "voice/a11/3100690a01.opus"
    mx "\"Supposedly she never goes home. Sleeps in a different bed every night.\""


translate english a1131_2a2a54ff:



    voice "voice/a11/3100700a01.opus"
    mx "\"Whose beds, though, I'm not sure.\""


translate english a1131_0accd139_1:


    xy "\"\"\"\"\"\"......\"\"\"\"\"\""


translate english a1131_5374c625:


    "En el fondo de mi mente, recuerdo lo que Yuutarou me dijo antes... Los rumores de que anda durmiendo por ahí."


translate english a1131_e568dd37:



    voice "voice/a11/3100710a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english a1131_fd9c49ce:



    voice "voice/a11/3100720a02.opus"
    aoi "\"Boop boop boop boop boop—\""


translate english a1131_fb040b51:


    xy "\"Hey, Mukou?\""


translate english a1131_3800cc01:



    voice "voice/a11/3100730a02.opus"
    aoi "\"Boop boop?\""


translate english a1131_d7cecd45:


    xy "\"Maybe your phone doesn't get service up here?\""


translate english a1131_e6112c5a:


    xy "\"Or, I dunno... maybe God's a little busy right now.\""


translate english a1131_d455cddc:



    voice "voice/a11/3100740a02.opus"
    aoi "\"...Boop boop? You think so?\""


translate english a1131_866f27fe:



    voice "voice/a11/3100750a02.opus"
    aoi "\"Maybe Aoi doesn't have enough battery pow—\""


translate english a1131_da279daa:



    voice "voice/a11/3100760a01.opus"
    mx "\"Just get down from there, would you?\""


translate english a1131_1872a547:



    voice "voice/a11/3100770a01.opus"
    mx "\"You wanted to talk to us, right?\""


translate english a1131_516f87d2:



    voice "voice/a11/3100780a02.opus"
    aoi "\"Three, two, one...\""


translate english a1131_035cb118:


    xy "\"Hey! Do NOT jump from there!\""


translate english a1131_36f8539c:



    voice "voice/a11/3100790a02.opus"
    aoi "\"...Boop boop? You think so?\""


translate english a1131_b3243e76:



    voice "voice/a11/3100800a02.opus"
    aoi "\"Why not?\""


translate english a1131_da147fab:


    xy "\"Oh my god... Haah...\""


translate english a1131_284f9b71:


    "Porque no es SEGURO, genio."


translate english a1131_aa18404f:


    "¿Cómo ha sobrevivido tanto tiempo sin saber estas cosas?"


translate english a1131_1f2bb50a:



    voice "voice/a11/3100810a01.opus"
    mx "\"Just use the ladder, please.\""


translate english a1131_49ab0513:



    voice "voice/a11/3100820a02.opus"
    aoi "\"Got it.\""


translate english a1131_b8b8514c:


    "Procede a bajar un poco más imprudentemente de lo que me habría gustado."


translate english a1131_f7b84014:


    "Finalmente, los tres estamos de pie en terreno parejo."


translate english a1131_ed39c8b1:



    voice "voice/a11/3100830a01.opus"
    mx "\"So, why did you ask to meet us up here?\""


translate english a1131_ea84a899:


    "¿Qué?"


translate english a1131_4f0441f8:


    xy "\"Wait... Then that means...\""


translate english a1131_5fec36c6:



    voice "voice/a11/3100840a01.opus"
    mx "\"You wrote those letters, didn't you?\""


translate english a1131_a38374d0:



    voice "voice/a11/3100850a02.opus"
    aoi "\"Uh huh.\""


translate english a1131_1f6fa5c0:



    voice "voice/a11/3100860a01.opus"
    mx "\"Well then. First things first, let me make this clear. As you may or may not have already heard...\""


translate english a1131_5646bdec:



    voice "voice/a11/3100870a01.opus"
    mx "\"Everything that happened yesterday was a total misunderstanding.\""


translate english a1131_040984d6:



    voice "voice/a11/3100880a01.opus"
    mx "\"Shinichi and I are old friends, that's all.\""


translate english a1131_34e450a8:



    voice "voice/a11/3100890a01.opus"
    mx "\"Nothing more, nothing less.\""


translate english a1131_8eed6115:



    voice "voice/a11/3100900a01.opus"
    mx "\"There's nothing romantic between us.\""


translate english a1131_3a9e5316:


    "Sí..."


translate english a1131_2a0cb5e3:


    "Es lo mejor."


translate english a1131_b0e0b390:



    voice "voice/a11/3100910a02.opus"
    aoi "\"Got it!\""


translate english a1131_ac6458a7:



    voice "voice/a11/3100920a01.opus"
    mx "\"...What is it?\""


translate english a1131_ce4876fd:



    voice "voice/a11/3100930a02.opus"
    aoi "\"Plan A.\""


translate english a1131_367964a2:



    voice "voice/a11/3100940a02.opus"
    aoi "\"Friendship mission.\""


translate english a1131_6dbb1528:



    voice "voice/a11/3100950a01.opus"
    mx "¿Qué?"


translate english a1131_8ddf45e3:



    voice "voice/a11/3100960a02.opus"
    aoi "\"Aoi and Miyuki and Shinichi...\""


translate english a1131_7e1d2995:



    voice "voice/a11/3100970a02.opus"
    aoi "\"We'll all be friends.\""


translate english a1131_8ab2a18f:



    voice "voice/a11/3100980a02.opus"
    aoi "\"Okay?\""


translate english strings:


    old "Дружить"
    new "Ser amigos"


    old "Не дружить"
    new "No ser amigos"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
