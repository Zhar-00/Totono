

translate english a6221_f6d1b6af:


    "Es la primera vez que estoy en la azotea de noche."


translate english a6221_48766a83:


    "Sobre mí, incontables estrellas brillan en el cielo."


translate english a6221_92d8bc3f:


    "Mientras tanto, la ciudad de abajo titila con el mismo brillo."


translate english a6221_61964378:


    "Es una vista de la que seguro nunca me cansaría."


translate english a6221_a2bbecb0:



    voice "voice/a62/2100010a01.opus"
    mx "\"...There you are.\""


translate english a6221_b79304a6:


    xy "\"How'd you know where to find me?\""


translate english a6221_2f817756:



    voice "voice/a62/2100020a01.opus"
    mx "\"Please. I know how you think.\""


translate english a6221_353fa36c:


    xy "\"No cast party?\""


translate english a6221_c540a0ca:



    voice "voice/a62/2100030a01.opus"
    mx "\"They're, uh, a little busy right now.\""


translate english a6221_c38be098:


    xy "\"That was one hell of an ending, that's for sure.\""


translate english a6221_9b6b8658:


    "Tras el apagón, la función se cortó."


translate english a6221_dbdcddb6:


    "Imagino que había un poco más de historia después de la escena del beso."


translate english a6221_a3168d02:


    "Así que, aunque la trama principal se resolvió, la obra en sí terminó con una nota algo insatisfactoria."


translate english a6221_1e108fa5:



    voice "voice/a62/2100040a01.opus"
    mx "\"They said some kind of short circuit tripped the breaker.\""


translate english a6221_94288e28:


    xy "\"Interesting.\""


translate english a6221_a2a8603a:


    xy "\"Especially since the rest of the school seems to be unaffected.\""


translate english a6221_5d9d0bab:



    voice "voice/a62/2100050a01.opus"
    mx "\"\"......!\"\""


translate english a6221_d9315e90:


    xy "\"What?\""


translate english a6221_2640cbe2:


    "Miyuki me lanza una mirada fulminante. Por reflejo, doy un paso atrás."


translate english a6221_11cc631f:


    xy "\"I... I didn't do anything!\""


translate english a6221_8dbebb11:



    voice "voice/a62/2100060a01.opus"
    mx "\"I didn't say you did... You wouldn't happen to know anything about how it happened, would you?\""


translate english a6221_33c1b295:


    xy "\"Of course not!\""


translate english a6221_817506be:



    voice "voice/a62/2100070a01.opus"
    mx "\"You got out of your chair right before it happened, yes?\""


translate english a6221_7ad24323:


    xy "\"You saw?\""


translate english a6221_ee3e4a43:



    voice "voice/a62/2100080a01.opus"
    mx "\"I was watching you from the moment all the blood drained from your face.\""


translate english a6221_d891e30a:


    xy "\"You should pay more attention to your performance!\""


translate english a6221_52173c64:



    voice "voice/a62/2100090a01.opus"
    mx "\"Please. I was doing just fine.\""


translate english a6221_b657726e:


    xy "\"Until the moment of the kiss, anyway.\""


translate english a6221_ef8de229:



    voice "voice/a62/2100100a01.opus"
    mx "\"......!\""


translate english a6221_67cb54fb:



    voice "voice/a62/2100110a01.opus"
    mx "\"A-Anyway!\""


translate english a6221_a249ba68:



    voice "voice/a62/2100120a01.opus"
    mx "\"You SWEAR you didn't do it?\""


translate english a6221_fd3a603e:


    "Miyuki me mira con recelo."


translate english a6221_ef9f3daf:


    "Bueno, admito que, si no se hubiera ido la luz, es totalmente posible que yo mismo hubiera arruinado la función, pero..."


translate english a6221_360b0eed:


    xy "\"All I did was stand up.\""


translate english a6221_f5963bf4:



    voice "voice/a62/2100130a01.opus"
    mx "\"You weren't... giving the signal?\""


translate english a6221_581378f5:


    xy "\"What signal?\""


translate english a6221_52a0c293:



    voice "voice/a62/2100140a01.opus"
    mx "\"They found this at the scene.\""


translate english a6221_1885a20c:


    "Saca algo de su bolsillo y me lo entrega."


translate english a6221_45a17334:


    xy "\"A hairpin...?\""


translate english a6221_623363a9:


    "Es la misma horquilla de gatito que le di a Aoi."


translate english a6221_245d3699:



    voice "voice/a62/2100150a01.opus"
    mx "\"There's a witness who claims she saw a girl in a kitty onesie during the performance.\""


translate english a6221_b906701c:



    voice "voice/a62/2100160a01.opus"
    mx "\"But she figured it was just part of the show, so she didn't say anything.\""


translate english a6221_c7d6c06d:


    xy "\"...I see...\""


translate english a6221_8461fb8f:


    "Ninguna persona normal usaría un atuendo tan llamativo para colarse en algún lugar..."


translate english a6221_6d16bf4c:


    "Énfasis en normal..."



translate english a6221_7ae2982b:


    xy "\"Are you going to hunt her down?\""


translate english a6221_8da8e65f:



    voice "voice/a62/2100170a01.opus"
    mx "\"The club president certainly wants to. He's furious.\""


translate english a6221_6fb88c75:



    voice "voice/a62/2100180a01.opus"
    mx "\"But God only knows where she might be now.\""


translate english a6221_5b985630:


    xy "\"I actually ran into her before I came here.\""


translate english a6221_70bebce6:



    voice "voice/a62/2100190a01.opus"
    mx "\"What?\""


translate english a6221_2aea066a:


    xy "\"She showed up at the batting cages with Eru in tow.\""


translate english a6221_18aab78c:


    xy "\"She was the one who encouraged me to come see you.\""


translate english a6221_5d8d09a1:



    voice "voice/a62/2100200a01.opus"
    mx "\"I... see.\""


translate english a6221_585830d7:


    "Su mirada tiene un pequeño dejo de tristeza."


translate english a6221_442d9fac:



    voice "voice/a62/2100210a01.opus"
    mx "\"How is she these days?\""


translate english a6221_952ecdd0:


    xy "\"She seemed to be doing pretty okay.\""


translate english a6221_63adc336:



    voice "voice/a62/2100220a01.opus"
    mx "\"...I'm glad.\""


translate english a6221_dca9b01b:



    voice "voice/a62/2100230a01.opus"
    mx "\"We left things on such an awful note.\""


translate english a6221_d81ede04:


    xy "\"Yeah...\""


translate english a6221_4641f811:



    voice "voice/a62/2100240a01.opus"
    mx "\"Our friendship may be over, but...\""


translate english a6221_3f079872:



    voice "voice/a62/2100250a01.opus"
    mx "\"I guess it's her way of showing she still supports our relationship.\""


translate english a6221_e08da79c:


    "Los dedos de Miyuki se cierran alrededor de la horquilla derretida, un regalo que alguna vez fue símbolo de su vínculo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
