

translate english a6221_f6d1b6af:


    "Es la primera vez que estoy en la azotea de noche."


translate english a6221_48766a83:


    "Sobre mí, incontables estrellas brillan en el cielo."


translate english a6221_92d8bc3f:


    "Mientras tanto, la ciudad de abajo titila con el mismo brillo."


translate english a6221_61964378:


    "Es una vista de la que seguro nunca me cansaría."


translate english a6221_a2bbecb0:



    voice "voice/a62/2100010a01.opus"
    mx "\"...Ahí estás.\""


translate english a6221_b79304a6:


    xy "\"¿Cómo sabías dónde encontrarme?\""


translate english a6221_2f817756:



    voice "voice/a62/2100020a01.opus"
    mx "\"Por favor. Sé cómo piensas.\""


translate english a6221_353fa36c:


    xy "\"¿No hay fiesta del elenco?\""


translate english a6221_c540a0ca:



    voice "voice/a62/2100030a01.opus"
    mx "\"Están, eh, un poco ocupados ahora mismo.\""


translate english a6221_c38be098:


    xy "\"Ese fue un final de mil demonios, eso sí.\""


translate english a6221_9b6b8658:


    "Tras el apagón, la función se cortó."


translate english a6221_dbdcddb6:


    "Imagino que había un poco más de historia después de la escena del beso."


translate english a6221_a3168d02:


    "Así que, aunque la trama principal se resolvió, la obra en sí terminó con una nota algo insatisfactoria."


translate english a6221_1e108fa5:



    voice "voice/a62/2100040a01.opus"
    mx "\"Dijeron que algún tipo de cortocircuito tiró el interruptor.\""


translate english a6221_94288e28:


    xy "\"Interesante.\""


translate english a6221_a2a8603a:


    xy "\"Sobre todo porque el resto de la escuela parece no haberse visto afectado.\""


translate english a6221_5d9d0bab:



    voice "voice/a62/2100050a01.opus"
    mx "\"\"......!\"\""


translate english a6221_d9315e90:


    xy "\"¿Qué?\""


translate english a6221_2640cbe2:


    "Miyuki me lanza una mirada fulminante. Por reflejo, doy un paso atrás."


translate english a6221_11cc631f:


    xy "\"¡Yo... no hice nada!\""


translate english a6221_8dbebb11:



    voice "voice/a62/2100060a01.opus"
    mx "\"No dije que lo hicieras... No sabrás nada de cómo pasó, ¿o sí?\""


translate english a6221_33c1b295:


    xy "\"¡Claro que no!\""


translate english a6221_817506be:



    voice "voice/a62/2100070a01.opus"
    mx "\"Te levantaste de tu silla justo antes de que pasara, ¿verdad?\""


translate english a6221_7ad24323:


    xy "\"¿Lo viste?\""


translate english a6221_ee3e4a43:



    voice "voice/a62/2100080a01.opus"
    mx "\"Te estuve mirando desde el momento en que toda la sangre se te fue de la cara.\""


translate english a6221_d891e30a:


    xy "\"¡Deberías prestarle más atención a tu actuación!\""


translate english a6221_52173c64:



    voice "voice/a62/2100090a01.opus"
    mx "\"Por favor. Estaba haciéndolo bien.\""


translate english a6221_b657726e:


    xy "\"Hasta el momento del beso, en todo caso.\""


translate english a6221_ef8de229:



    voice "voice/a62/2100100a01.opus"
    mx "\"......!\""


translate english a6221_67cb54fb:



    voice "voice/a62/2100110a01.opus"
    mx "\"¡E-En fin!\""


translate english a6221_a249ba68:



    voice "voice/a62/2100120a01.opus"
    mx "\"¿JURAS que no lo hiciste?\""


translate english a6221_fd3a603e:


    "Miyuki me mira con recelo."


translate english a6221_ef9f3daf:


    "Bueno, admito que, si no se hubiera ido la luz, es totalmente posible que yo mismo hubiera arruinado la función, pero..."


translate english a6221_360b0eed:


    xy "\"Lo único que hice fue ponerme de pie.\""


translate english a6221_f5963bf4:



    voice "voice/a62/2100130a01.opus"
    mx "\"¿No estabas... dando la señal?\""


translate english a6221_581378f5:


    xy "\"¿Qué señal?\""


translate english a6221_52a0c293:



    voice "voice/a62/2100140a01.opus"
    mx "\"Encontraron esto en la escena.\""


translate english a6221_1885a20c:


    "Saca algo de su bolsillo y me lo entrega."


translate english a6221_45a17334:


    xy "\"¿Una horquilla...?\""


translate english a6221_623363a9:


    "Es la misma horquilla de gatito que le di a Aoi."


translate english a6221_245d3699:



    voice "voice/a62/2100150a01.opus"
    mx "\"Hay una testigo que afirma haber visto a una chica con un enterizo de gatito durante la función.\""


translate english a6221_b906701c:



    voice "voice/a62/2100160a01.opus"
    mx "\"Pero pensó que era parte del show, así que no dijo nada.\""


translate english a6221_c7d6c06d:


    xy "\"...Ya veo...\""


translate english a6221_8461fb8f:


    "Ninguna persona normal usaría un atuendo tan llamativo para colarse en algún lugar..."


translate english a6221_6d16bf4c:


    "Énfasis en normal..."



translate english a6221_7ae2982b:


    xy "\"¿Vas a ir a cazarla?\""


translate english a6221_8da8e65f:



    voice "voice/a62/2100170a01.opus"
    mx "\"El presidente del club sin duda quiere. Está furioso.\""


translate english a6221_6fb88c75:



    voice "voice/a62/2100180a01.opus"
    mx "\"Pero solo Dios sabe dónde pueda estar ahora.\""


translate english a6221_5b985630:


    xy "\"De hecho me la encontré antes de venir aquí.\""


translate english a6221_70bebce6:



    voice "voice/a62/2100190a01.opus"
    mx "\"¿Qué?\""


translate english a6221_2aea066a:


    xy "\"Apareció en las jaulas de bateo con Eru a cuestas.\""


translate english a6221_18aab78c:


    xy "\"Fue ella quien me animó a venir a verte.\""


translate english a6221_5d8d09a1:



    voice "voice/a62/2100200a01.opus"
    mx "\"Ya... veo.\""


translate english a6221_585830d7:


    "Su mirada tiene un pequeño dejo de tristeza."


translate english a6221_442d9fac:



    voice "voice/a62/2100210a01.opus"
    mx "\"¿Cómo está estos días?\""


translate english a6221_952ecdd0:


    xy "\"Parecía estar bastante bien.\""


translate english a6221_63adc336:



    voice "voice/a62/2100220a01.opus"
    mx "\"...Me alegra.\""


translate english a6221_dca9b01b:



    voice "voice/a62/2100230a01.opus"
    mx "\"Dejamos las cosas en tan malos términos.\""


translate english a6221_d81ede04:


    xy "\"Sí...\""


translate english a6221_4641f811:



    voice "voice/a62/2100240a01.opus"
    mx "\"Nuestra amistad puede haberse acabado, pero...\""


translate english a6221_3f079872:



    voice "voice/a62/2100250a01.opus"
    mx "\"Supongo que es su forma de mostrar que aún apoya nuestra relación.\""


translate english a6221_e08da79c:


    "Los dedos de Miyuki se cierran alrededor de la horquilla derretida, un regalo que alguna vez fue símbolo de su vínculo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
