

translate english a7221b_7170542d:



    voice "voice/a72/21b00010a01.opus"
    mx "\"It's our fate, after all.\""


translate english a7221b_7523aee4:


    xy "\"Fate...?\""


translate english a7221b_c95b01db:


    "Supongo que sí..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
