

translate english a9201_77b01d02:


    "Tres años después—"


translate english a9201_3e2f729a:


    "Estoy en mi cocina, friendo algo de cerdo en oferta."


translate english a9201_c16eccaa:


    "Pico unas cebollas y las añado al sartén."


translate english a9201_0db3e79c:


    "Bought myself a side salad for 30%% off, too. Now I just need to stir a little dashi broth into my miso soup mix and I'm set!"



translate english a9201_f4a159ec:


    "Esta es una cena bastante elegante para un soltero que gana el salario mínimo, si se me permite decirlo."


translate english a9201_8969398b:


    xy "\"Mmm... Oh, cielos, ¡ya empezó el programa!\""


translate english a9201_467f2cc5:


    "Apago el quemador a la carrera."


translate english a9201_97db8b3b:


    "Seguro que ya lo cociné el tiempo suficiente... probablemente... Eh, ¡estará bien!"


translate english a9201_778abc32:


    "Me sirvo un tazón de arroz humeante, luego vacío el cerdo salteado sobre mi ensalada y enciendo la televisión rápidamente."


translate english a9201_1b8e1df4:



    voice "voice/a92/0100010a01.opus"
    mx "\"¿¡Por qué!? ¡Respóndeme!\""


translate english a9201_d240d734:



    voice "voice/a92/0100020a01.opus"
    mx "\"¿¡Por qué... por qué me traicionarías así!?\""


translate english a9201_4c79508f:


    "Sone Miyuki abandonó la preparatoria para debutar en la industria del entretenimiento."


translate english a9201_3228b68e:


    "Hoy en día, su popularidad se dispara; apenas pasa un día sin que la vea en pantalla en algún lugar."


translate english a9201_22e43c83:


    "Es tan famosa que prácticamente la adoran."


translate english a9201_3b02e643:


    "Siempre supe que tenía talento, pero nunca imaginé esto..."


translate english a9201_1947e86a:



    voice "voice/a92/0100030a01.opus"
    mx "\"Si vas a traicionarme...\""


translate english a9201_a5449560:



    voice "voice/a92/0100040a01.opus"
    mx "\"Entonces tendré que desquitarme.\""


translate english a9201_567b7d91:



    voice "voice/a92/0100050a01.opus"
    mx "\"Puedes correr, pero no esconderte. Te perseguiré hasta los confines de la tierra...\""


translate english a9201_a38f4c39:


    xy "\"¡Uy! ¡Qué miedo!\""


translate english a9201_678c082b:


    "Así es Miyuki."


translate english a9201_acf6ae74:


    "Sus habilidades actorales están realmente fuera de este mundo."


translate english a9201_f004f3e7:


    "En cuanto a mí, soy un gran fan. Veo cualquier y toda serie en la que salga."


translate english a9201_83a3a4c1:


    "Dicho esto, no soy el tipo de persona que normalmente se deja llevar por el hype, y no me veo asistiendo a ninguna de sus sesiones de autógrafos."


translate english a9201_e09e07f0:



    voice "voice/a92/0100060a01.opus"
    mx "\"Dicho eso...\""


translate english a9201_e8af8ae6:



    voice "voice/a92/0100070a01.opus"
    mx "\"Si prometes amarme siempre...\""


translate english a9201_44905a2c:



    voice "voice/a92/0100080a01.opus"
    mx "\"Entonces te amaré el resto de nuestras vidas.\""


translate english a9201_17c5a11a:



    voice "voice/a92/0100090a01.opus"
    mx "\"Te haré el hombre más feliz del mundo.\""


translate english a9201_9115d046:


    "Miyuki mira a su coprotagonista con fervor en los ojos."


translate english a9201_7674ea3e:


    "Tampoco es sorpresa."


translate english a9201_21251285:


    "Su relación acaba de filtrarse a la prensa hace unos días."


translate english a9201_adc20e5d:


    "Ninguno de los dos lo negó en las entrevistas posteriores, y ahora los blogs de celebridades están enloquecidos con la noticia."


translate english a9201_7d4eb3e2:


    "Pero nada de eso es asunto mío ahora."


translate english a9201_32856b11:


    "Los dos estamos en mundos distintos, y ella está en un lugar al que nunca podré llegar."


translate english a9201_63d456fb:


    "Pero no me molesta."


translate english a9201_00d0f528:


    "Tampoco logro sentir celos."


translate english a9201_54176a8f:


    "Lo único que siento es el vapor que sube de mi arroz."


translate english a9201_fa39bd5f:


    "Y el cerdo sobre sazonado que me escuece en el fondo de la garganta."


translate english a9201_0ea5d3b3:


    "Y las cebollas picadas que tardíamente me escuecen los ojos."


translate english a9201_77b4c6f7:


    "...Vale, quizá estoy llorando."


translate english a9201_1c557b4c:


    "Pero vi esa entrevista, y lo sé."


translate english a9201_f78a911d:


    "Sé que es la más feliz que ha sido nunca."


translate english a9201_7f8d09ca:


    "Así que claramente estas son solo lágrimas de felicidad."


translate english a9201_e37c55a9:


    xy "\"Ahora bien...\""


translate english a9201_2d4403b4:


    xy "\"¡Hora de lavarse!\""


translate english a9201_72e55bcb:


    "Recojo mis platos sucios y me dirijo al fregadero."


translate english a9201_2b3550b0:


    "Los días pasan..."


translate english a9201_ab3d8079:


    "...mientras sigo el camino que estaba destinado a tomar."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
