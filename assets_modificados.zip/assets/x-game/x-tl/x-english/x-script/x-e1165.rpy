

translate english e1165_5f77942e:


    xy "\"Aoi...?\""


translate english e1165_4f6d15e6:


    xy "\"Aoi! AOIIIII—!!!\""


translate english e1165_8630b208:


    "Mi grito resuena en vano."


translate english e1165_9180845b:


    "Simplemente... desapareció."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
