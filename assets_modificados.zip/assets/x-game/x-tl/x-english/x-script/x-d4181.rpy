

translate english d4181_4ba8ceca:


    xy "\"What Mukou's taught me...\""


translate english d4181_5640e199:


    "¿De verdad me enseñó algo?"


translate english d4181_00028d15:



    voice "voice/d41/8100010b03.opus"
    c "\"Welcome—AAH!\""


translate english d4181_badd42c9:



    voice "voice/d41/8100020b03.opus"
    c "\"S-Susuki-senpai!\""


translate english d4181_a1a93212:


    xy "\"Oh, hey, Haru-chan.\""


translate english d4181_c37132db:



    voice "voice/d41/8100040b03.opus"
    c "\"Uh... um... I need to talk to you!\""


translate english d4181_7d57a6bc:


    xy "\"You do?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
