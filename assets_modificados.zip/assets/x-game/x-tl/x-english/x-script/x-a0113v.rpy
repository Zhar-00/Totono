

translate english a0113v_6ec43f8f:



    voice "voice/a01/13v00010b02.opus"
    bm "\"CÓDIGO DE TRAMPA CONFIRMADO.\""


translate english a0113v_d5aa2ebd:


    "Justo entonces, oigo una voz al otro lado de la línea."


translate english a0113v_bb106d9c:



    voice "voice/a01/13v00020b02.opus"
    bm "\"PREPARANDO ACTUALIZACIÓN FORZADA DEL UNIVERSO.\""


translate english a0113v_33f11a70:


    xy "\"¿Actualizar... el universo...?\""


translate english a0113v_ae904453:



    voice "voice/a01/13v00030b02.opus"
    bm "\"ESTA ACTUALIZACIÓN ES IRREVERSIBLE. UNA VEZ COMPLETADA, SE DESACTIVARÁ EL JUEGO NORMAL.\""


translate english a0113v_b7e9e06f:



    voice "voice/a01/13v00040b02.opus"
    bm "\"ADVERTENCIA. SI EL SUJETO DESEA EXPERIMENTAR EL MUNDO COMO FUE PREVISTO, CIERRE EL JUEGO AHORA.\""


translate english a0113v_eb53491f:


    xy "\"Perdón, ¿qué? ¿De qué estás hablando?\""


translate english a0113v_b25c4b26:



    voice "voice/a01/13v00050b02.opus"
    bm "\"REPITO, SE RECOMIENDA ENCARECIDAMENTE CERRAR EL JUEGO DE INMEDIATO.\""


translate english a0113v_5c266c58:



    voice "voice/a01/13v00060b02.opus"
    bm "\"INICIANDO CUENTA REGRESIVA.\""


translate english a0113v_52384693:



    voice "voice/a01/13v00070b02.opus"
    bm "TEN.{w=1}{nw}"



translate english a0113v_57fd0c77:



    voice "voice/a01/13v00080b02.opus"
    bm "NINE.{w=1}{nw}"



translate english a0113v_84eb265a:



    voice "voice/a01/13v00090b02.opus"
    bm "EIGHT.{w=1}{nw}"



translate english a0113v_33d26103:



    voice "voice/a01/13v00100b02.opus"
    bm "SEVEN.{w=1}{nw}"



translate english a0113v_96ebaef1:



    voice "voice/a01/13v00110b02.opus"
    bm "SIX.{w=1}{nw}"



translate english a0113v_d56a42df:



    voice "voice/a01/13v00120b02.opus"
    bm "FIVE.{w=1}{nw}"



translate english a0113v_bc3c8c70:



    voice "voice/a01/13v00130b02.opus"
    bm "FOUR.{w=1}{nw}"



translate english a0113v_306153a7:



    voice "voice/a01/13v00140b02.opus"
    bm "THREE.{w=1}{nw}"



translate english a0113v_d1fc4e99:



    voice "voice/a01/13v00150b02.opus"
    bm "TWO.{w=1}{nw}"



translate english a0113v_1d4439ad:



    voice "voice/a01/13v00160b02.opus"
    bm "ONE.{w=1}{nw}"



translate english a0113v_3e980479:



    voice "voice/a01/13v00170b02.opus"
    bm "ZERO.{w=1}{nw}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
