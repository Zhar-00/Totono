

translate english e3412a_847a95a9:


    "Recojo el teléfono de Miyuki del suelo."


translate english e3412a_fbf3134c:


    "Parece estar desbloqueado."


translate english e3412a_8fc37850:


    "...¿Hmm?"


translate english e3412a_acea63a1:


    "¿Es un gato lo que oigo maullar justo afuera?"


translate english e3412a_9ceeac47:


    "¿Es eso lo que me despertó...?"


translate english strings:


    old "Пойти искать кота"
    new "Ir a buscar al gato"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
