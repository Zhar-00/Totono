

translate english a7132_6c6489dc:


    xy "\"¿Esto es una carta de renuncia al club...?\""


translate english a7132_0a892a4e:


    xy "\"...Al parecer no...\""


translate english a7132_9412b064:


    "The words \"Club Resignation Form\"están tachadas."


translate english a7132_e25bb48d:


    "Instead, the words \"LETTER OF EXPULSION\"han sido impresas encima con una florida letra caligráfica."


translate english a7132_13342beb:


    "Y, en efecto, la carta está firmada \"Akebono Yuutarou.\""


translate english a7132_b7c6a703:


    "¿Por qué se molestó en hacerla tan elegante...?"


translate english a7132_deec32da:


    "Entonces veo el contenido de la carta."


translate english a7132_48ede9b0:


    "—¡MUERE!!!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
