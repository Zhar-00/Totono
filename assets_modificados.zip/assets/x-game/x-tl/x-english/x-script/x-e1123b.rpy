

translate english e1123b_ef2a3ba8:



    voice "voice/e11/23b00010a01.opus"
    mx "\"...¿Por qué dirías eso?\""


translate english e1123b_da321974:



    voice "voice/e11/23b00020a01.opus"
    mx "\"¡Dijiste que podías hace rato!\""


translate english e1123b_3b27afec:


    xy "\"No puede ser...\""


translate english e1123b_64a818d6:


    "Nunca podría aceptar su amor."


translate english e1123b_55f1ef04:


    "Sin duda alguna."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
