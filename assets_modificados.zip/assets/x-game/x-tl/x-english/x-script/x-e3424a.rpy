

translate english e3424a_dba04539:


    "Mis dedos deambulan por la pantalla."


translate english e3424a_24f6fe1c:


    "Un número que nunca he encontrado en mi vida flota misteriosamente al frente de mi mente..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
