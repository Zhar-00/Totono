

translate english e2203f_e561312c:


    "Por curiosidad, abro su agenda."


translate english e2203f_183520e6:


    xy "\"...Lo sabía. Un teléfono desechable para Dios.\""


translate english e2203f_eaee99af:


    "Bueno, admito que tengo curiosidad..."


translate english e2203f_41997b57:


    "¿Debería llamar al número y ver qué pasa...?"


translate english e2203f_c9f3877e:


    "Pero antes de que pueda decidirme—"


translate english e2203f_76f2b3e7:



    voice "voice/e22/03f00010a01.opus"
    mx "\"Oye, ¿Shinichi—? ¿Qué quieres de postre—?\""


translate english e2203f_ce1c86eb:


    xy "\"Oh, uhhh... ¿Qué tenemos?\""


translate english e2203f_a93a44d7:



    voice "voice/e22/03f00020a01.opus"
    mx "\"Pues... Tenemos helado, pudín... ¡Oh, y pastel también—!\""


translate english e2203f_7d2eaabc:


    xy "\"Vale, ehh... Entonces tomaré un poco de pastel.\""


translate english e2203f_18941bf3:



    voice "voice/e22/03f00030a01.opus"
    mx "\"¡Ahora mismo!\""


translate english e2203f_35337f37:


    "Parece que Miyuki volverá en cualquier momento."


translate english e2203f_2a16060f:


    "Necesito más tiempo si voy a hacer una llamada."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
