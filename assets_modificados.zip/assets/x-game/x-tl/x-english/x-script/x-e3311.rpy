

translate english e3311_e4e86175:



    voice "voice/e33/1100010a02.opus"
    aoi "\"Got it! Shinichi!\""


translate english e3311_3964b057:


    xy "\"Whuh...? Nnrgh...\""


translate english e3311_7746189a:



    voice "voice/e33/1100020a02.opus"
    aoi "\"Wake up!\""


translate english e3311_8f591efa:


    "Convocada por la voz familiar, mi conciencia emerge a la superficie..."


translate english e3311_6bc4be56:


    xy "\"Huh...? A-Aoi...? Is that you?\""


translate english e3311_1004673c:


    xy "\"Am I dreaming?\""


translate english e3311_27800142:



    voice "voice/e33/1100030a02.opus"
    aoi "\"Nope.\""


translate english e3311_74644d39:



    voice "voice/e33/1100040a02.opus"
    aoi "\"This is real life.\""


translate english e3311_76e4ff5d:



    voice "voice/e33/1100050a02.opus"
    aoi "\"After all...\""


translate english e3311_2abf6135:



    voice "voice/e33/1100060a01.opus"
    mx "\"I'm just cosplaying.\""


translate english e3311_7fe1cf16:


    xy "\"Huh...?\""


translate english e3311_d1a56754:


    "Estoy tan confundido."


translate english e3311_16bea5e3:


    "¿Esa es... la voz de Miyuki?"


translate english e3311_630ca23d:



    voice "voice/e33/1100070a01.opus"
    mx "\"I'm doing this in the hopes that you might fall in love with a real-life human being instead of a video game character.\""


translate english e3311_b0c7ca00:


    "¿Cosplay...?"


translate english e3311_bdc799ca:


    "Pero, ¿cómo se hizo más baja... y menos curvilínea...?"


translate english e3311_5063aad5:



    voice "voice/e33/1100080a02.opus"
    aoi "\"Boop boop... nnn...!\""


translate english e3311_715ff9d1:


    xy "\"Wh—\""


translate english e3311_bec99c19:


    "Se sienta a horcajadas sobre mí y desliza una mano entre sus piernas."


translate english e3311_79e19415:


    "Sus bragas expuestas están empapadas."


translate english e3311_91d6527e:


    "Al instante, mi polla se pone dura."


translate english e3311_29a62e00:


    xy "\"Aoi, wait—\""


translate english e3311_68c85d32:



    voice "voice/e33/1100090a02.opus"
    aoi "\"Not Aoi. Miyuki.\""


translate english e3311_02eeb28a:



    voice "voice/e33/1100100a02.opus"
    aoi "\"Call me Miyuki. Got it?\""


translate english e3311_6dfa6548:


    xy "\"Oh... O-Okay...\""


translate english e3311_d909a761:


    "Puede que ahora parezca Aoi, pero por dentro sigue siendo Miyuki."


translate english e3311_6f1d26ea:


    "Así que tiene sentido llamarla por su nombre real."


translate english e3311_d26c95cb:


    xy "\"Miyuki, what are you doing?\""


translate english e3311_16a12d33:



    voice "voice/e33/1100110a02.opus"
    aoi "\"We're gonna have sex.\""


translate english e3311_46bc0fb0:


    xy "\"What?\""


translate english e3311_9ea4638a:



    voice "voice/e33/1100120a02.opus"
    aoi "\"Miyuki will tell you the truth.\""


translate english e3311_8cf499a2:



    voice "voice/e33/1100130a02.opus"
    aoi "\"Miyuki was born to be loved by you.\""


translate english e3311_9ed987a7:



    voice "voice/e33/1100140a02.opus"
    aoi "\"And if we don't have sex, Miyuki will disappear.\""


translate english e3311_daabdf6c:



    voice "voice/e33/1100150a02.opus"
    aoi "\"That's the curse of my existence.\""


translate english e3311_397271b5:


    xy "\"Ao—\""


translate english e3311_71e5106b:



    voice "voice/e33/1100160a02.opus"
    aoi "\"Miyuki!\""



translate english e3311_42848ae0:


    xy "\"M-Miyuki...\""


translate english e3311_66792cf0:


    "If I remember correctly, there's a similar scene in that one visual novel, [[YOU and ME and HER]."


translate english e3311_92e9ac39:


    "Aoi era una pizarra en blanco creada por \"God.\""



translate english e3311_8920230b:


    "Como opción romántica, nació puramente para el consumo masculino. Una historia triste, la verdad."


translate english e3311_ffbe8392:


    "Viajaba de mundo en mundo, cambiando de forma cada vez, teniendo sexo con docenas de protagonistas..."


translate english e3311_7983ebdb:


    "Porque si no lo hacía, dejaría de existir."


translate english e3311_0d320de7:


    "But this \"Aoi\"es solo Miyuki disfrazada. No va a desaparecer de verdad si no me la follo."



translate english e3311_395a6fc9:


    "...Aunque, evidentemente, eso no la detiene."


translate english e3311_111b85ea:



    voice "voice/e33/1100170a02.opus"
    aoi "\"Time to put it in.\""


translate english e3311_dff5523a:


    "Miyuki agarra mi polla y se aparta las bragas a un lado, dejando al descubierto su coño."


translate english e3311_a4779694:


    "Presiona su humedad contra mi punta—"


translate english e3311_6ac5bd9d:



    voice "voice/e33/1100180a02.opus"
    aoi "\"Nnn... Boop... boop boop... Nn... nnng... nnnnn—!\""


translate english e3311_7ed24098:


    "Entonces una suave sensación envuelve mi miembro."


translate english e3311_d3e46f53:



    voice "voice/e33/1100190a02.opus"
    aoi "\"Hnn... aah... nn... nnng!!! Your cock... It's in me...!\""


translate english e3311_dfd6c5d3:



    voice "voice/e33/1100200a02.opus"
    aoi "\"Does my pussy feel good?\""


translate english e3311_8b8ee3dc:


    "No puedo hablar. Apenas si puedo asentir."


translate english e3311_abed744d:


    "Nunca había sentido un placer así..."


translate english e3311_3fd7da57:


    "Casi se siente como si... como si ella y yo estuviéramos fusionados por las caderas..."


translate english e3311_171c3e0d:


    "Apenas acaba de metérsela, y ya un cosquilleo se extiende por todo mi cuerpo..."


translate english e3311_ff55d1d6:



    voice "voice/e33/1100210a02.opus"
    aoi "\"How's it feel? Better than normal?\""


translate english e3311_1cd84814:



    voice "voice/e33/1100220a02.opus"
    aoi "\"See, Miyuki hacked the game.\""


translate english e3311_ca71c4ac:



    voice "voice/e33/1100230a02.opus"
    aoi "\"This body is Aoi's, but...\""


translate english e3311_cf327cc5:



    voice "voice/e33/1100240a02.opus"
    aoi "\"This pussy is mine.\""


translate english e3311_84de879c:



    voice "voice/e33/1100250a02.opus"
    aoi "\"And Miyuki's pussy is exclusively yours.\""


translate english e3311_9f9b6663:



    voice "voice/e33/1100260a02.opus"
    aoi "\"Which is why it feels so much better than Aoi's.\""


translate english e3311_050aa177:



    voice "voice/e33/1100270a02.opus"
    aoi "\"Right?\""


translate english e3311_5f047a64:


    xy "\"Yeah... It feels good...\""


translate english e3311_b9c0528d:



    voice "voice/e33/1100280a02.opus"
    aoi "\"Repeat after me.\""


translate english e3311_9970143a:



    voice "voice/e33/1100290a02.opus"
    aoi "\" 'Miyuki's pussy feels good.' \""



translate english e3311_928a4e9d:



    voice "voice/e33/1100300a02.opus"
    aoi "\" 'Way, way better than Aoi's.' \""



translate english e3311_3295e43a:



    voice "voice/e33/1100310a02.opus"
    aoi "\"If you say it, Miyuki will bounce on your cock.\""


translate english e3311_accdfa80:



    voice "voice/e33/1100320a02.opus"
    aoi "\"That'll make it feel even better.\""


translate english e3311_745cb1da:


    xy "\"Better than this? Is that even possible?\""


translate english e3311_343fff92:



    voice "voice/e33/1100330a02.opus"
    aoi "\"Yup! So good, you might just pass out. Now say it.\""


translate english e3311_7d774408:


    "Con eso, mi sentido de la razón se va por la ventana."


translate english e3311_ecbd0988:


    xy "\"It... feels good...\""


translate english e3311_05216c39:



    voice "voice/e33/1100340a02.opus"
    aoi "\"What does?\""


translate english e3311_7489398c:


    xy "\"Miyuki's... pussy...\""


translate english e3311_abcf13eb:



    voice "voice/e33/1100350a02.opus"
    aoi "\"Feels better than...?\""


translate english e3311_f5dcc510:


    xy "\"Better than... Aoi's...\""


translate english e3311_fc8dcf41:



    voice "voice/e33/1100360a02.opus"
    aoi "\"Good job.\""


translate english e3311_c3982a19:



    voice "voice/e33/1100370a02.opus"
    aoi "\"Now for your reward.\""


translate english e3311_0df8c437:


    xy "\"—!!!\""



translate english e3311_a47ba427:


    "Chap, chap, chap, chap—"


translate english e3311_762b02df:


    "Miyuki empieza a menear las caderas lentamente."


translate english e3311_79a5f224:



    voice "voice/e33/1100380a02.opus"
    aoi "\"Nnhaah... nnn... nnng... nnn... nnngg! Haah... aah... aaahh... aaaahhh!\""


translate english e3311_1ce39913:



    voice "voice/e33/1100390a02.opus"
    aoi "\"Aah... Miyuki can feel you—every inch of your cock—sliding in and out—!\""


translate english e3311_ae27721e:



    voice "voice/e33/1100400a02.opus"
    aoi "\"Nnng... Does it—feel good—for you, too? Back and forth... barely pushing in... Nnngg!\""


translate english e3311_a5e31881:



    voice "voice/e33/1100410a02.opus"
    aoi "\"Rocking back and forth— Squishy, squishy, squishy... Hnnng!\""


translate english e3311_608889c6:



    voice "voice/e33/1100420a02.opus"
    aoi "\"Or deeper—like this—! Slamming inside me—!\""


translate english e3311_96af0654:



    voice "voice/e33/1100430a02.opus"
    aoi "\"Which one—nnng—feels better—for you?\""


translate english e3311_68931218:


    "No puedo distinguir dónde termina mi polla y dónde empieza su coño..."


translate english e3311_0d39454b:


    "Much as I'd love to tell her what feels \"better\", apenas si puedo pensar con claridad."



translate english e3311_77ab10d7:



    voice "voice/e33/1100440a02.opus"
    aoi "\"Are they both—just as good—?\""


translate english e3311_9cf1c7c5:



    voice "voice/e33/1100450a02.opus"
    aoi "\"But—nnhaah! Nnn... nnng— Guess what, Shinichi?\""


translate english e3311_bb23e337:



    voice "voice/e33/1100460a02.opus"
    aoi "\"Today is a special day.\""


translate english e3311_a36091b3:



    voice "voice/e33/1100470a02.opus"
    aoi "\"If you cum inside Miyuki... it'll feel super-duper incredible.\""


translate english e3311_1e44e2ac:



    voice "voice/e33/1100480a02.opus"
    aoi "\"And Miyuki will get pregnant.\""


translate english e3311_e1c003ae:



    voice "voice/e33/1100490a02.opus"
    aoi "\"And we'll have a baby.\""


translate english e3311_0abcb881:



    voice "voice/e33/1100500a02.opus"
    aoi "\"The fruit of our union—of our love.\""


translate english e3311_1c107566:



    voice "voice/e33/1100510a02.opus"
    aoi "\"It'll feel amazing.\""


translate english e3311_2ca4a827:


    "Susurra mientras rebota sobre mi polla—"


translate english e3311_cc37497c:


    "—y me encuentro acumulando hacia el orgasmo de forma patéticamente rápida."


translate english e3311_102d19a3:



    voice "voice/e33/1100520a02.opus"
    aoi "\"Nnng... Your cock is rock hard... It's ready to burst. Miyuki can feel it.\""


translate english e3311_653b1283:



    voice "voice/e33/1100530a02.opus"
    aoi "\"Nnnh... Wanna cum? Nnn... nnng... Wanna cum inside me, Shinichi?\""


translate english e3311_87b5261f:


    xy "\"Yeah—I wanna cum—\""


translate english e3311_577239fd:



    voice "voice/e33/1100540a02.opus"
    aoi "\"Wanna put a baby in Miyuki?\""


translate english e3311_daeb28ff:


    xy "\"Well—I—\""


translate english e3311_39c55fdf:



    voice "voice/e33/1100550a02.opus"
    aoi "\"Do you?\""


translate english e3311_0accd139:


    xy "\"......\""


translate english e3311_b338c9d6:


    "Mientras el placer amenaza con hundirme por completo, el último rastro persistente de mi racionalidad agita una bandera roja."


translate english e3311_4bcc25bb:


    "Miyuki sí me importa, pero este no es momento para formar una familia."


translate english e3311_94869075:



    voice "voice/e33/1100560a02.opus"
    aoi "\"Well then.\""


translate english e3311_2255a098:



    voice "voice/e33/1100570a02.opus"
    aoi "\"You need more zappy.\""


translate english e3311_46bc0fb0_1:


    xy "\"What?\""


translate english e3311_ab0c750c:



    voice "voice/e33/1100580a02.opus"
    aoi "\"Nnnh... aahh... nnng! Nnn! Nnn... nnng! Nnnngghhh... nnn!\""


translate english e3311_6bd89dd2:


    "Miyuki empieza a moverse cada vez más rápido."


translate english e3311_8b7ddd95:


    "El placer recorre mi cuerpo como electricidad."


translate english e3311_08cfaaac:


    "Mientras tanto, siento que me disparo hacia el clímax—"


translate english e3311_e2b55f00:



    voice "voice/e33/1100590a02.opus"
    aoi "\"Nnng... Boop boop... boop...!\""


translate english e3311_84361737:


    "Pero justo cuando llego al borde, Miyuki se detiene en seco."


translate english e3311_fc6c4346:


    "El placer empieza a desvanecerse rápidamente."


translate english e3311_cc61f676:


    xy "\"Miyuki...?\""



translate english e3311_82e3eb9d:



    voice "voice/e33/1100600a02.opus"
    aoi "\"—Not yet.\""


translate english e3311_20e716fd:



    voice "voice/e33/1100610a02.opus"
    aoi "\"It's not enough.\""


translate english e3311_8861c836:



    voice "voice/e33/1100620a02.opus"
    aoi "\"You need to get more zappy.\""


translate english e3311_ae39febd:



    voice "voice/e33/1100630a02.opus"
    aoi "\"Hnnn! Nnngghh! Nnnnnn... nnnnn... nnngghh... nnngggghhhhh—!!!\""


translate english e3311_b9bb2f14:


    "Empieza a acelerar una vez más, llevándome a la fuerza hacia el clímax de nuevo—"


translate english e3311_3b1e14b8:



    voice "voice/e33/1100640a02.opus"
    aoi "\"Nnnh... Boop boop...\""


translate english e3311_22f63a8d:


    "Y luego se detiene otra vez."


translate english e3311_c7b3b3ec:


    "Es como si me estuviera llevando al borde a propósito..."


translate english e3311_22640b8b:


    xy "\"Why are you doing this...?\""


translate english e3311_617e9f53:



    voice "voice/e33/1100650a02.opus"
    aoi "\"Miyuki's gonna make your head—all full of zappy, zappy, zappy!!!\""


translate english e3311_bb1ad4e7:



    voice "voice/e33/1100660a02.opus"
    aoi "\"...And then you'll glitch out.\""


translate english e3311_d7ed35aa:


    xy "\"What do you mean, glitch out?! Aaah!\""


translate english e3311_198d6f08:



    voice "voice/e33/1100670a02.opus"
    aoi "\"Nnng... Well... Hnnn... nnn! Nnn...gghh...! Nnn...nnhaahh! Aah! Aah, aah, aah—AAAH!\""


translate english e3311_ffd7b7e0:



    voice "voice/e33/1100680a02.opus"
    aoi "\"Boop boop—boop—nnn—This is payback—for Aoi's route!\""


translate english e3311_0df8c437_1:


    xy "\"—!!!\""



translate english e3311_9aae85f3:


    xy "\"What about Aoi's route...?\""


translate english e3311_c5e9c559:



    voice "voice/e33/1100690a02.opus"
    aoi "\"Nnn... You did this to her... Nnnh! Nnhaah! Nn... nnn... nnng... nn... nnnnnggg—\""


translate english e3311_c5f97c23:



    voice "voice/e33/1100700a02.opus"
    aoi "\"Nnhaah! Nnn... You got Aoi all hot and bothered and forced her to kiss you!\""


translate english e3311_b45ea898:


    xy "\"What...? I don't remember that... Nnngghh!!!\""


translate english e3311_aafab7a9:



    voice "voice/e33/1100710a02.opus"
    aoi "Claro—no lo harías—pero—!\""


translate english e3311_02912642:



    voice "voice/e33/1100720a02.opus"
    aoi "\"Miyuki can—reload the memories—so Miyuki knows all about it—!\""


translate english e3311_de17f957:



    voice "voice/e33/1100730a02.opus"
    aoi "\"Got it—Shinichi!\""


translate english e3311_9698442c:



    voice "voice/e33/1100740a02.opus"
    aoi "\"You're drooling...\""


translate english e3311_e92ec63c:



    voice "voice/e33/1100750a02.opus"
    aoi "\"Did you get zappy?\""


translate english e3311_921dee1f:


    "Podrías decirlo así."


translate english e3311_0015b742:


    "Una enorme sacudida de placer se extiende desde mi polla por todo mi cuerpo, abrumándome por completo."


translate english e3311_4e528801:


    "Mi cerebro es papilla."


translate english e3311_917720a4:


    "Estoy tan desesperado por liberarme que voy a perder la cabeza."


translate english e3311_c0e24f15:


    "A estas alturas, haré cualquier cosa—"


translate english e3311_7234dca8:



    voice "voice/e33/1100760a02.opus"
    aoi "\"Shinichi?\""


translate english e3311_6c7142e8:



    voice "voice/e33/1100770a02.opus"
    aoi "\"Wanna cum inside Miyuki?\""


translate english e3311_7d19b7b3:


    xy "\"Yeah!\""


translate english e3311_9d5eb19b:


    "La palabra sale de mis labios antes de que pueda pensarlo."


translate english e3311_58b26dc1:



    voice "voice/e33/1100780a02.opus"
    aoi "\"You sure?\""


translate english e3311_a37d717b:


    xy "\"I'm sure!\""


translate english e3311_ae56264c:



    voice "voice/e33/1100790a02.opus"
    aoi "\"You wanna make a baby?\""


translate english e3311_1cec1364:


    xy "\"Just... please... let me cum!\""


translate english e3311_0106d306:



    voice "voice/e33/1100800a02.opus"
    aoi "\"Okay then!\""


translate english e3311_3c5e9390:



    voice "voice/e33/1100810a02.opus"
    aoi "\"Nnnngghhh!!! Nnhaah! Nnhaahh!!! Aah, aah, aah, aah—!!!\""


translate english e3311_20550ef9:


    "Las caderas de Miyuki aceleran por lo que parece la enésima vez."


translate english e3311_ade7156e:


    "\"But—nnhaah! Nnn... nnng— Guess what, Shinichi?\""


translate english e3311_290a3797:



    voice "voice/e33/1100820a02.opus"
    aoi "\"This time—Miyuki won't stop—until you cum— Won't stop—even after you cum—!\""


translate english e3311_76e7f865:


    "Se mueve a velocidad de rayo, y no puedo resistirlo."


translate english e3311_5af0cd85:



    voice "voice/e33/1100830a02.opus"
    aoi "\"Nnhaah! Nnngghhh! Nnn... nnnnnnn... nnngghhh... Hey, Shinichi? Aah! Does my pussy feel good?\""


translate english e3311_90d0ade5:



    voice "voice/e33/1100840a02.opus"
    aoi "\"It does—right? My body—is all zappy—\""


translate english e3311_485cc50b:



    voice "voice/e33/1100850a02.opus"
    aoi "\"Miyuki's—gonna cum—gonna cum—gonna cum from the zappy—!!!\""


translate english e3311_29a6778d:



    voice "voice/e33/1100860a02.opus"
    aoi "\"Aaahh! Aah! Shinichi! Let it out! Fill me! Flood my pussy!\""


translate english e3311_d0c1740a:



    voice "voice/e33/1100870a02.opus"
    aoi "\"Fill me—with your sperm—and give me—a baby—!!!\""


translate english e3311_fe0826d8:



    voice "voice/e33/1100880a02.opus"
    aoi "\"AAAAAHH!!! Aah! Aah, aah, aah, aah—! Gonna cum! Cumming, cumming, cumming—\""


translate english e3311_a15fe01a:



    voice "voice/e33/1100890a02.opus"
    aoi "\"CUUUUUMMMMMIIIIINNNNNNGGGGGG—!!!\""


translate english e3311_8a26cd2c:



    voice "voice/e33/1100900a01.opus"
    mx "\"Nnn—nnnggghh! Nnnn—nnnng—nnhaah—aaahh—nnn—nnngghhh—!\""


translate english e3311_13c8261b:



    voice "voice/e33/1100910a01.opus"
    mx "\"Nnng! There it is—your thick sperm—filling me up—Nnnnngh—!\""


translate english e3311_dcd3000a:



    voice "voice/e33/1100920a01.opus"
    mx "\"Nnn! Today's one of my fertile days, so I'm probably gonna get pregnant! Hehehe!\""


translate english e3311_a210f154:


    xy "\"Huh? Miyuki, you're back to normal?\""


translate english e3311_7f918565:



    voice "voice/e33/1100930a01.opus"
    mx "\"Mmhmm! That's how the scene goes!\""


translate english e3311_0df8c437_2:


    xy "\"—!!!\""



translate english e3311_969babb2:


    xy "\"W-Wait! I'm too sensitive! Nnnngghh!!!\""


translate english e3311_136c7097:



    voice "voice/e33/1100940a01.opus"
    mx "\"Hehe! Weren't you listening?\""


translate english e3311_96429d77:



    voice "voice/e33/1100950a01.opus"
    mx "\"I told you I wasn't gonna stop after you came!\""


translate english e3311_d835dc0b:



    voice "voice/e33/1100960a01.opus"
    mx "\"And look at that... Not a minute later and you're already getting hard again!\""


translate english e3311_d26b400a:



    voice "voice/e33/1100970a01.opus"
    mx "Sí que lo hace, ¿verdad?\""


translate english e3311_df6b813d:



    voice "voice/e33/1100980a01.opus"
    mx "Te estás follando a la verdadera yo.\""


translate english e3311_1d0505b7:



    voice "voice/e33/1100990a01.opus"
    mx "¿Ves? ¿Ves? ¿Ves, ves, ves—?\""


translate english e3311_d69c2f1f:


    "Rebota de arriba abajo con cada palabra."


translate english e3311_922f95b5:


    "La estimulación interminable me mantiene duro a la fuerza."


translate english e3311_1d3f38e9:



    voice "voice/e33/1101000a01.opus"
    mx "\"Well, Shinichi? Do you understand?\""


translate english e3311_3fdc8610:



    voice "voice/e33/1101010a01.opus"
    mx "No es real. Es un personaje en 2D.\""


translate english e3311_a363329c:



    voice "voice/e33/1101020a01.opus"
    mx "¿Por qué la elegirías a ella...?\""


translate english e3311_bd362729:


    "Las lágrimas asoman a sus ojos mientras me cabalga."


translate english e3311_7204b216:


    "Llegó al punto de disfrazarse de un personaje de videojuego que ni siquiera le gusta, solo por mí. Solo para mi placer."


translate english e3311_35aaa2c4:


    "Así que debería hacer algo por ella en retorno."


translate english e3311_4f040a2f:


    xy "\"Miyuki, I'm sorry... I was wrong...\""


translate english e3311_e9f411ad:



    voice "voice/e33/1101030a01.opus"
    mx "Pero si de verdad te arrepientes de lo que hiciste...\""


translate english e3311_5bbdd323:



    voice "voice/e33/1101040a01.opus"
    mx "\"Make me cum, okay?\""


translate english e3311_01035716:


    "Suplica dulcemente, y sin dudarlo empiezo a embestir mis caderas hacia las suyas."


translate english e3311_891dbe26:



    voice "voice/e33/1101050a01.opus"
    mx "\"NnhaaaAAAHH!!!\""


translate english e3311_2b8b95dc:



    voice "voice/e33/1101060a01.opus"
    mx "\"Aaahh! Aah! Oh god—your cock—your fat cock—railing me from below!!!\""


translate english e3311_f9f4af69:



    voice "voice/e33/1101070a01.opus"
    mx "Me encanta cómo se siente tu polla—dentro de mí—!\""


translate english e3311_bd729209:



    voice "voice/e33/1101080a01.opus"
    mx "¡Oh, joder! ¡Sí! ¡Justo ahí!\""


translate english e3311_e3a1c661:



    voice "voice/e33/1101090a01.opus"
    mx "¡Mi cuerpo! ¡No deja de temblar!\""


translate english e3311_8c0c7f23:


    "Y en efecto, se retuerce y se convulsiona una y otra vez."


translate english e3311_79925ee5:


    "Nuestros fluidos se mezclan, finos hilos nos unen."


translate english e3311_d9d39f9b:


    "Un sonido sexy y pegajoso llena el aire."


translate english e3311_1ed30860:



    voice "voice/e33/1101100a01.opus"
    mx "\"Nnng! Tell me, Shinichi... does it... feel good...?\""


translate english e3311_11bbe21f:


    xy "\"Yeah—it feels great—\""


translate english e3311_c0df96d6:



    voice "voice/e33/1101110a01.opus"
    mx "\"How good is 'great'?\""



translate english e3311_4ddddc18:



    voice "voice/e33/1101120a01.opus"
    mx "\"Better than Aoi?\""


translate english e3311_36fd0bae:


    xy "\"Yeah—way better—\""


translate english e3311_cc9c075e:



    voice "voice/e33/1101130a01.opus"
    mx "\"Really? You... mean it...?!\""


translate english e3311_06631fd7:



    voice "voice/e33/1101140a01.opus"
    mx "¡Dime que soy mejor que Aoi!\""


translate english e3311_7dd2ff49:



    voice "voice/e33/1101150a01.opus"
    mx "\"Tell me a fictional character can't possibly compare to a real person who will love you for the rest of your life!\""


translate english e3311_4606c4db:


    xy "\"It's true... Miyuki... I love you...\""


translate english e3311_4ae787d2:


    xy "\"There's no contest between you and some 2D character who sleeps around with tons of guys!\""


translate english e3311_13a780d0:


    xy "\"You're way better—way, way better—!\""


translate english e3311_8b58c239:



    voice "voice/e33/1101160a01.opus"
    mx "\"Haah! Aaahh!!! Oh fuck! That! Makes me! So! Aah! Aahaahhh!!!\""


translate english e3311_a2895801:



    voice "voice/e33/1101170a01.opus"
    mx "Shinichi... te amo... ¡te amo muchísimo!!!\""


translate english e3311_8990ed75:


    "Su pecho no es lo único que se aprieta—su coño se cierra con más fuerza que nunca."


translate english e3311_f8f9dc65:


    "Mientras tanto, mis caderas prácticamente se mueven solas, golpeándola a velocidad incontrolable."


translate english e3311_dd4877b7:



    voice "voice/e33/1101180a01.opus"
    mx "¡Me estoy corriendo...! ¡Shinichi... Shinichi...!\""


translate english e3311_df1a1ef2:



    voice "voice/e33/1101190a01.opus"
    mx "\"Listen—please—Just forget everything else—and flood me with your hot cum—!!!\""


translate english e3311_2b5fe7d9:



    voice "voice/e33/1101200a01.opus"
    mx "¡Con... tu... esperma...!\""


translate english e3311_ea7c2881:



    voice "voice/e33/1101210a01.opus"
    mx "¡Tu bebé! ¡Aaahh! ¡Aah! ¡AAAAAHHHH!!!\""


translate english e3311_9e5b0b4a:



    voice "voice/e33/1101220a01.opus"
    mx "¡ME ESTOY COOOOORRRIIIIEEEENDOOOO—!!!\""


translate english e3311_4cd00cbe:



    voice "voice/e33/1101230a01.opus"
    mx "\"Aah! Nnn—hnngh!!!r\nNnn... nnnggghh... aaaahh...!!!\""



translate english e3311_520f6d5f:



    voice "voice/e33/1101240a01.opus"
    mx "\"Nnngh... nnn... Shinichi... you came... so much... you filled me up inside...\""



translate english e3311_e6bf6439:



    voice "voice/e33/1101250a01.opus"
    mx "\"I'm so happy... Nnnggh!r\nShinichi... Shinichi... I love you—!\""



translate english e3311_25bfe3c9:



    voice "voice/e33/1101260a01.opus"
    mx "\"I won't—let anyone else have you—Nnng!!!r\nNever—Never ever—!\""



translate english e3311_100e4f21:



    voice "voice/e33/1101270a01.opus"
    mx "\"Never leave me—!\""



translate english e3311_3c5b2152:



    voice "voice/e33/1101280a01.opus"
    mx "\"That's a promise—okay—?\""



translate english e3311_d60fad3c:


    "Mientras su susurro me hace cosquillas en la oreja..."



translate english e3311_60110717:


    "Mi conciencia se desvanece lentamente..."



translate english e3311_666d3ee4:


    "Y desciendo hacia una oscuridad apacible..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
