

translate english a3151_8f5bb191:


    xy "\"Vamos, no te enojes.\""


translate english a3151_02e42614:



    voice "voice/a31/5100010a01.opus"
    mx "\"No estoy enojada.\""


translate english a3151_f1b8f8ab:


    xy "\"¿Esta es tu idea de no estar enojada?\""


translate english a3151_0dea5d9b:



    voice "voice/a31/5100020a01.opus"
    mx "\"Mira, lo entiendo, ¿sí? Sé que Aoi no se siente bien.\""


translate english a3151_1fad3da2:



    voice "voice/a31/5100030a02.opus"
    aoi "\"Boop boop boop... boop...\""


translate english a3151_91f3303e:


    "Aquí, bajo el cielo estrellado de la noche, el andar de Aoi es aún más inestable que de costumbre."


translate english a3151_b688c838:



    voice "voice/a31/5100040a01.opus"
    mx "\"Bien, lo que sea.\""


translate english a3151_840cf9c7:



    voice "voice/a31/5100050a01.opus"
    mx "\"Dejaré de estar enojada... SI...\""


translate english a3151_841b501b:



    voice "voice/a31/5100060a01.opus"
    mx "\"...me das algún consejo.\""


translate english a3151_6cf43dbb:


    "Tengo un presentimiento muy malo sobre esto."


translate english a3151_73185148:


    xy "\"¿Es sobre... eso de antes?\""


translate english a3151_88ae71c1:



    voice "voice/a31/5100070a01.opus"
    mx "\"En algún punto de ese estadio, supongo.\""


translate english a3151_bdb2a744:



    voice "voice/a31/5100080a02.opus"
    aoi "\"¿Problemas de chicos?\""


translate english a3151_f2fe286d:


    "Aoi interrumpe."


translate english a3151_b76d7227:


    "Miyuki se estremece alarmada."


translate english a3151_ec4c0720:



    voice "voice/a31/5100090a01.opus"
    mx "\"¡N-No! ¡Es sobre la OBRA!\""


translate english a3151_8318cd6d:



    voice "voice/a31/5100100a02.opus"
    aoi "\"¿Sobre el beso?\""


translate english a3151_5709ebf7:



    voice "voice/a31/5100110a01.opus"
    mx "\"Espera, ¿¡qué!?\""


translate english a3151_6e6e5ae2:



    voice "voice/a31/5100120a01.opus"
    mx "\"Shinichi, ¿SE lo DIJISTE?\""


translate english a3151_1e41ff84:


    xy "\"Oh, ehhh...\""


translate english a3151_ce9e3867:



    voice "voice/a31/5100130a01.opus"
    mx "\"¿No prometiste que no se lo dirías a nadie?\""


translate english a3151_a474cfd6:



    voice "voice/a31/5100140a01.opus"
    mx "\"¿Cómo pudiste? ¡Confiaba en ti!\""


translate english a3151_b7c88a8b:


    xy "\"Perdón... Solo... pensé que estaría bien porque todos somos amigos.\""


translate english a3151_b2f5a032:



    voice "voice/a31/5100150a01.opus"
    mx "\"......!\""


translate english a3151_afa65961:


    "Miyuki parece lista para explotar."


translate english a3151_2eafcb6c:


    "Desesperado, busco ayuda en Aoi."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
