

translate english d6111_14e242db:



    voice "voice/d61/1100010a01.opus"
    mx "\"La función está por empezar, ¿eh?\""


translate english d6111_80b7ccbc:


    xy "\"Sí...\""


translate english d6111_7be29900:


    "Miramos el viejo gimnasio desde nuestro punto de vista en el techo."


translate english d6111_3efe7eff:


    "Después de esa noche, me uní al club de teatro."


translate english d6111_f925c814:


    "Tenía una meta: hacer que revisaran la escena del beso de Miyuki."


translate english d6111_3afe0648:


    "Sabía que era egoísta, pero simplemente no podía tolerar la idea de que otro chico besara a mi novia."


translate english d6111_544198f3:


    "Naturalmente, el director y el dramaturgo estaban completamente en contra."


translate english d6111_a626d7aa:


    "La obra ya estaba tomando forma muy bien, y una vez que clavaran la escena del beso, sería perfecta."


translate english d6111_0405088c:


    "Si la cambiaban ahora, no podrían pulirla a tiempo, decían."


translate english d6111_d044dcbe:


    "Probablemente no apreciaban que un don nadie apareciera de la nada y exigiera una revisión tan masiva."


translate english d6111_69564070:


    "No los culpaba, por supuesto."


translate english d6111_6929544e:


    "Pero me negué a echarme atrás."


translate english d6111_f8239e3c:


    "Fui a verlos una y otra y otra vez."


translate english d6111_be0f3920:


    "Lo sé—soy un pequeño bastardo celoso."


translate english d6111_0027418e:


    "Mientras miro el atardecer, puedo oír los vítores de la multitud."


translate english d6111_0657d16a:


    xy "\"Lo siento.\""


translate english d6111_cb589dd5:


    xy "\"Sé que estaba siendo egoísta.\""


translate english d6111_d3509705:



    voice "voice/d61/1100020a01.opus"
    mx "\"Sin disculpas, ¿sí?\""


translate english d6111_b1d0684a:



    voice "voice/d61/1100030a01.opus"
    mx "\"Amo todo de ti, incluso tu supuesto lado 'egoísta'.\""



translate english d6111_53141fa4:


    "Miyuki me sonríe sin un dejo de resentimiento."


translate english d6111_e309b1b5:


    "Ella fue quien finalmente decidió el destino de la obra."


translate english d6111_b2d13c4c:


    "Me dicen que fue a verlos y amenazó con renunciar a su papel si dejaban la escena del beso intacta."


translate english d6111_b71c883c:


    "Y ahora aquí está, de pie a mi lado."


translate english d6111_e5201699:


    "Puso tanto trabajo duro en sus ensayos..."


translate english d6111_d9ac4256:


    "Era su oportunidad de llegar a las grandes ligas."


translate english d6111_0e9d7ea6:


    "Y ahora lo ha tirado todo por la borda."


translate english d6111_02ae35c3:


    "El viejo yo se habría sentido culpable como el demonio."



translate english d6111_6cf2e2ce:


    "Pero soy diferente ahora."


translate english d6111_50cf01ef:


    "Veo el sacrificio que ha hecho y la amo aún más por ello."


translate english d6111_98f54c9c:


    "Y ahora voy a hacerla feliz por el resto de su vida."


translate english d6111_24910b4f:


    "Esa es la promesa que me he hecho a mí mismo."


translate english d6111_24bb5775:



    voice "voice/d61/1100040a01.opus"
    mx "\"Oye, ¿Shinichi?\""


translate english d6111_28f19ada:


    xy "\"¿Sí?\""


translate english d6111_044ba241:


    "De la mano, miramos el cielo del oeste."


translate english d6111_950c34d0:


    "El sol se hunde más allá del horizonte."


translate english d6111_9cb3752f:


    "Nos quedamos ahí, sin palabras."


translate english d6111_3bc7aadd:


    "Nuestros corazones laten como uno, palpitando con el fluir del tiempo."


translate english d6111_835bb2fe:


    "El sol arde carmesí mientras desciende lentamente."


translate english d6111_9f9522d0:


    "Entonces, finalmente, cae la noche."


translate english d6111_1ce75744:


    "Una a una, las luces del pueblo parpadean hasta cobrar vida."


translate english d6111_fd38b81c:


    "Como si respondieran, las estrellas salen sobre nosotros."


translate english d6111_dcbc5274:


    "Esta es mi primera vez en el techo de noche."


translate english d6111_8500df43:


    "Juntos, nos perdemos en la vista impresionante."


translate english d6111_f580c6e8:


    "...¿Cuánto tiempo ha pasado ya?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
