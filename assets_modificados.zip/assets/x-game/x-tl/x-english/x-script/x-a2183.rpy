

translate english a2183_d95983b8:



    voice "voice/a21/8300010a01.opus"
    mx "\"Es tan lindo...\""


translate english a2183_0accd139:


    xy "\"......\""


translate english a2183_b59c727d:


    "Miyuki lo contempla, totalmente encantada."


translate english a2183_96e79457:


    "También puedo ver por qué. Definitivamente tiene ese aire clásico de hecho a mano, y el artista clavó su expresión."


translate english a2183_2c91fe77:


    "En cuanto al precio, es posible si echo mano de mi presupuesto mensual de comida..."


translate english a2183_bf09f3d8:


    xy "\"¿Por qué no te lo compro yo?\""


translate english a2183_9104b52b:



    voice "voice/a21/8300020a01.opus"
    mx "\"...¿Qué?\""


translate english a2183_862763d5:


    xy "\"Tómalo como un gesto de agradecimiento. Ya sabes, por ayudarme con Aoi y eso.\""


translate english a2183_5bbe437e:



    voice "voice/a21/8300030a01.opus"
    mx "\"¿Qu...? Pero... ¡No, no, no puedo! ¡No puedo aceptarlo! O sea...\""


translate english a2183_dc822d67:


    xy "\"Ibas a hacer que te compensara en el béisbol antes de cambiar de opinión, ¿recuerdas? Así que técnicamente te debo una.\""


translate english a2183_4aa94140:



    voice "voice/a21/8300040a01.opus"
    mx "\"P-Pero... O sea, agradezco el detalle, pero ni siquiera me quedaría tan bien.\""


translate english a2183_41ba1dab:


    xy "\"¿Estás seguro de eso?\""


translate english a2183_be50f337:


    "En la escuela, Miyuki es la viva imagen de la sofisticación. Este lindo pasador de gato casi con seguridad chocaría con eso."


translate english a2183_2e7c7edd:


    "Aun así, sus acciones dicen mucho."


translate english a2183_e526d571:


    xy "\"Si te gusta, ¿qué tiene de malo?\""


translate english a2183_71a17809:



    voice "voice/a21/8300050a01.opus"
    mx "\"Este tipo de cosas se verían mejor en Aoi, así que...\""


translate english a2183_76162d0f:



    voice "voice/a21/8300060a02.opus"
    aoi "\"¿Estás siendo tsundere?\""


translate english a2183_a64ae75d:


    "Aoi vuelve de la caja justo a tiempo para respaldarme."


translate english a2183_e0aef3dc:



    voice "voice/a21/8300070a01.opus"
    mx "\"...En ese caso, ¿qué tal esto?\""


translate english a2183_16f5dab8:



    voice "voice/a21/8300080a01.opus"
    mx "\"Haré que Shinichi lo compre, y luego te lo doy a ti...\""


translate english a2183_29fb2135:



    voice "voice/a21/8300090a02.opus"
    aoi "\"Para nada. Eso no tiene sentido.\""


translate english a2183_684982ae:



    voice "voice/a21/8300100a01.opus"
    mx "\"¿Y? Es lo que quiero hacer.\""


translate english a2183_346e9913:


    xy "\"¡Está bien, está bien!\""


translate english a2183_d457dfea:


    "Dudo que al dependiente le guste que estemos aquí parados discutiendo."


translate english a2183_8c422420:


    "Ya hemos causado suficientes problemas al tirar ese estante."


translate english a2183_1ec026b9:


    xy "\"Ustedes dos espérenme afuera, ¿sí?\""


translate english a2183_65b2d1d9:


    "Paso por el estante y luego voy directo a la caja."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
