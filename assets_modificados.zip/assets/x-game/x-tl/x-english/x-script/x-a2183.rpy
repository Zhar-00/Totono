

translate english a2183_d95983b8:



    voice "voice/a21/8300010a01.opus"
    mx "\"It's so cute...\""


translate english a2183_0accd139:


    xy "\"......\""


translate english a2183_b59c727d:


    "Miyuki lo contempla, totalmente encantada."


translate english a2183_96e79457:


    "También puedo ver por qué. Definitivamente tiene ese aire clásico de hecho a mano, y el artista clavó su expresión."


translate english a2183_2c91fe77:


    "En cuanto al precio, es posible si echo mano de mi presupuesto mensual de comida..."


translate english a2183_bf09f3d8:


    xy "\"Why don't I buy it for you?\""


translate english a2183_9104b52b:



    voice "voice/a21/8300020a01.opus"
    mx "\"...What?\""


translate english a2183_862763d5:


    xy "\"Consider it a token of my thanks. You know, for helping me with Aoi and stuff.\""


translate english a2183_5bbe437e:



    voice "voice/a21/8300030a01.opus"
    mx "\"Wh... But... No, no, I can't! I can't accept that! I mean—\""


translate english a2183_dc822d67:


    xy "\"You were going to have me make it up to you back at the batting cages before you changed your mind, remember? So technically I owe you.\""


translate english a2183_4aa94140:



    voice "voice/a21/8300040a01.opus"
    mx "\"B-But... I mean, I appreciate the thought, but it wouldn't even look that good on me.\""


translate english a2183_41ba1dab:


    xy "\"You sure about that?\""


translate english a2183_be50f337:


    "En la escuela, Miyuki es la viva imagen de la sofisticación. Este lindo pasador de gato casi con seguridad chocaría con eso."


translate english a2183_2e7c7edd:


    "Aun así, sus acciones dicen mucho."


translate english a2183_e526d571:


    xy "\"If you like it, then what's the harm?\""


translate english a2183_71a17809:



    voice "voice/a21/8300050a01.opus"
    mx "\"This sort of thing would look better on Aoi, so—\""


translate english a2183_76162d0f:



    voice "voice/a21/8300060a02.opus"
    aoi "\"Are you being tsundere?\""


translate english a2183_a64ae75d:


    "Aoi vuelve de la caja justo a tiempo para respaldarme."


translate english a2183_e0aef3dc:



    voice "voice/a21/8300070a01.opus"
    mx "\"...In that case, how about this?\""


translate english a2183_16f5dab8:



    voice "voice/a21/8300080a01.opus"
    mx "\"I'll have Shinichi buy it, and then I'll give it to y—\""


translate english a2183_29fb2135:



    voice "voice/a21/8300090a02.opus"
    aoi "\"No way. That makes no sense.\""


translate english a2183_684982ae:



    voice "voice/a21/8300100a01.opus"
    mx "\"So? It's what I want to do.\""


translate english a2183_346e9913:


    xy "\"Fine, fine!\""


translate english a2183_d457dfea:


    "Dudo que al dependiente le guste que estemos aquí parados discutiendo."


translate english a2183_8c422420:


    "Ya hemos causado suficientes problemas al tirar ese estante."


translate english a2183_1ec026b9:


    xy "\"You two wait outside for me, alright?\""


translate english a2183_65b2d1d9:


    "Paso por el estante y luego voy directo a la caja."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
