

translate english a2133_f4e30075:



    voice "voice/a21/3300010a01.opus"
    mx "\"Whew, I'm full.\""


translate english a2133_f3c3673c:


    xy "\"Me too.\""


translate english a2133_bfa7acd1:



    voice "voice/a21/3300020a01.opus"
    mx "\"Now then, let's get started on our math homew—\""


translate english a2133_d8fc262f:



    voice "voice/a21/3300030a02.opus"
    aoi "\"Boop boop... Battery too low...\""


translate english a2133_8bfb4cdb:


    xy "\"Let me guess. You need to recharge?\""


translate english a2133_f898258f:



    voice "voice/a21/3300040a01.opus"
    mx "\"Heh. I had a feeling this would happen.\""


translate english a2133_4010c8cd:


    "Mientras habla, Miyuki saca algo de su bolsa de almuerzo."


translate english a2133_c7f61682:



    voice "voice/a21/3300050a02.opus"
    aoi "\"Boop boop... Battery too low...\""


translate english a2133_b444ce10:



    voice "voice/a21/3300060a02.opus"
    aoi "\"That sound... That smell...\""


translate english a2133_a8187d88:



    voice "voice/a21/3300070a02.opus"
    aoi "\"It's Yabaley's!\""


translate english a2133_6d5dbb8b:



    voice "voice/a21/3300080a01.opus"
    mx "\"Want it?\""


translate english a2133_bfd052b9:



    voice "voice/a21/3300090a02.opus"
    aoi "\"Aoi can have it?\""


translate english a2133_4957e5d4:



    voice "voice/a21/3300100a01.opus"
    mx "\"Only if you promise to do your homework after you drink it.\""


translate english a2133_31afe2a5:



    voice "voice/a21/3300110a02.opus"
    aoi "\"Boop... boop... boop boop!\""


translate english a2133_768fcfab:



    voice "voice/a21/3300120a02.opus"
    aoi "\"Deal! One can of Yabaley's will charge me right up!\""


translate english a2133_15c68bec:



    voice "voice/a21/3300130a01.opus"
    mx "\"Perfect.\""


translate english a2133_b20b0500:


    "Miyuki le entrega la lata."


translate english a2133_48c8bd7b:



    voice "voice/a21/3300140a02.opus"
    aoi "\"Ggllpp... ggllpp... ggllpp... ggllpp...\""


translate english a2133_e4ae5119:



    voice "voice/a21/3300150a02.opus"
    aoi "\"Whew...!\""


translate english a2133_286f56ff:


    "Aoi se la toma toda de un trago, igual que la última vez."


translate english a2133_b2c447df:



    voice "voice/a21/3300160a02.opus"
    aoi "\"Recharge complete.\""


translate english a2133_6e836023:



    voice "voice/a21/3300170a01.opus"
    mx "\"You really love your tomato juice, hmm?\""


translate english a2133_a553c4ef:



    voice "voice/a21/3300180a02.opus"
    aoi "\"It's godlike.\""


translate english a2133_1acae5fd:



    voice "voice/a21/3300190a02.opus"
    aoi "\"Want some?\""


translate english a2133_c0b0c474:



    voice "voice/a21/3300200a01.opus"
    mx "\"What? No, I—\""


translate english a2133_ad95aac8:



    voice "voice/a21/3300210a02.opus"
    aoi "\"Don't be shy. Have some.\""


translate english a2133_39e8163b:



    voice "voice/a21/3300220a01.opus"
    mx "\"Uhh... Well... About that...\""


translate english a2133_2469c1b4:



    voice "voice/a21/3300230a02.opus"
    aoi "\"Miyuki, do you not like tomatoes?\""


translate english a2133_c13e79d7:



    voice "voice/a21/3300240a01.opus"
    mx "\"I just don't feel the need to drink it, that's all.\""


translate english a2133_4294d904:


    "Para ser justos, ella YA tiene tomates en su almuerzo."


translate english a2133_d02bb960:


    xy "\"C'mon, don't knock it 'til you try it.\""


translate english a2133_b2f10a88:



    voice "voice/a21/3300250a01.opus"
    mx "\"I wasn't 'knocking' it!\""


translate english a2133_75d247d2:



    voice "voice/a21/3300260a01.opus"
    mx "\"Whatever. Let's start on our homework.\""


translate english a2133_59a4d152:


    xy "\"Have fun.\""


translate english a2133_771e1e13:



    voice "voice/a21/3300270a01.opus"
    mx "\"You're doing this too, mister!\""


translate english a2133_5f1934d0:


    xy "\"...Yes, ma'am...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
