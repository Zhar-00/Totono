

translate english a2133_f4e30075:



    voice "voice/a21/3300010a01.opus"
    mx "\"Uf, estoy lleno.\""


translate english a2133_f3c3673c:


    xy "\"Yo también.\""


translate english a2133_bfa7acd1:



    voice "voice/a21/3300020a01.opus"
    mx "\"Ahora entonces, empecemos con nuestra tarea de ma—\""


translate english a2133_d8fc262f:



    voice "voice/a21/3300030a02.opus"
    aoi "\"Bip bip... Batería muy baja...\""


translate english a2133_8bfb4cdb:


    xy "\"Déjame adivinar. ¿Necesitas recargarte?\""


translate english a2133_f898258f:



    voice "voice/a21/3300040a01.opus"
    mx "\"Jeh. Me lo imaginaba.\""


translate english a2133_4010c8cd:


    "Mientras habla, Miyuki saca algo de su bolsa de almuerzo."


translate english a2133_c7f61682:



    voice "voice/a21/3300050a02.opus"
    aoi "\"Bip bip... Batería muy baja...\""


translate english a2133_b444ce10:



    voice "voice/a21/3300060a02.opus"
    aoi "\"Ese sonido... Ese olor...\""


translate english a2133_a8187d88:



    voice "voice/a21/3300070a02.opus"
    aoi "\"¡Es Yabaley!\""


translate english a2133_6d5dbb8b:



    voice "voice/a21/3300080a01.opus"
    mx "\"¿Lo quieres?\""


translate english a2133_bfd052b9:



    voice "voice/a21/3300090a02.opus"
    aoi "\"¿Aoi puede tomarlo?\""


translate english a2133_4957e5d4:



    voice "voice/a21/3300100a01.opus"
    mx "\"Solo si prometes hacer tu tarea después de beberlo.\""


translate english a2133_31afe2a5:



    voice "voice/a21/3300110a02.opus"
    aoi "\"Bip... bip... ¡bip bip!\""


translate english a2133_768fcfab:



    voice "voice/a21/3300120a02.opus"
    aoi "\"¡Trato hecho! ¡Una lata de Yabaley me cargará al instante!\""


translate english a2133_15c68bec:



    voice "voice/a21/3300130a01.opus"
    mx "\"Perfecto.\""


translate english a2133_b20b0500:


    "Miyuki le entrega la lata."


translate english a2133_48c8bd7b:



    voice "voice/a21/3300140a02.opus"
    aoi "\"Ggllpp... ggllpp... ggllpp... ggllpp...\""


translate english a2133_e4ae5119:



    voice "voice/a21/3300150a02.opus"
    aoi "\"¡Uf...!\""


translate english a2133_286f56ff:


    "Aoi se la toma toda de un trago, igual que la última vez."


translate english a2133_b2c447df:



    voice "voice/a21/3300160a02.opus"
    aoi "\"Recarga completa.\""


translate english a2133_6e836023:



    voice "voice/a21/3300170a01.opus"
    mx "\"De verdad amas tu jugo de tomate, ¿eh?\""


translate english a2133_a553c4ef:



    voice "voice/a21/3300180a02.opus"
    aoi "\"Es divino.\""


translate english a2133_1acae5fd:



    voice "voice/a21/3300190a02.opus"
    aoi "\"¿Quieres un poco?\""


translate english a2133_c0b0c474:



    voice "voice/a21/3300200a01.opus"
    mx "\"¿Qué? No, yo—\""


translate english a2133_ad95aac8:



    voice "voice/a21/3300210a02.opus"
    aoi "\"No seas tímido. Toma un poco.\""


translate english a2133_39e8163b:



    voice "voice/a21/3300220a01.opus"
    mx "\"Ehh... Bueno... Sobre eso...\""


translate english a2133_2469c1b4:



    voice "voice/a21/3300230a02.opus"
    aoi "\"Miyuki, ¿no te gustan los tomates?\""


translate english a2133_c13e79d7:



    voice "voice/a21/3300240a01.opus"
    mx "\"Es solo que no siento la necesidad de beberlo, eso es todo.\""


translate english a2133_4294d904:


    "Para ser justos, ella YA tiene tomates en su almuerzo."


translate english a2133_d02bb960:


    xy "\"Vamos, no lo critiques hasta probarlo.\""


translate english a2133_b2f10a88:



    voice "voice/a21/3300250a01.opus"
    mx "\"¡No lo estaba \"criticando\"!\""


translate english a2133_75d247d2:



    voice "voice/a21/3300260a01.opus"
    mx "\"Como sea. Empecemos con la tarea.\""


translate english a2133_59a4d152:


    xy "\"Diviértanse.\""


translate english a2133_771e1e13:



    voice "voice/a21/3300270a01.opus"
    mx "\"¡Tú también vas a hacerlo, caballero!\""


translate english a2133_5f1934d0:


    xy "\"...Sí, señora...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
