

translate english e1168_9e0e0e5d:



    voice "voice/e11/6800010a01.opus"
    mx "\"You wanna know why?\""


translate english e1168_3d779cc4:



    voice "voice/e11/6800020a01.opus"
    mx "\"Then why don't you check the backlog?\""


translate english e1168_d75efb7c:



    voice "voice/e11/6800030a01.opus"
    mx "\"That's how I knew your location, too.\""


translate english e1168_a2d719e5:



    voice "voice/e11/6800040a01.opus"
    mx "\"I tracked you by monitoring the backlog.\""


translate english e1168_2565ac5e:


    xy "\"The heck is a 'backlog'...?\""



translate english e1168_9fcc92a5:


    "¿De qué demonios está hablando siquiera?"


translate english e1168_d2d97803:


    "¿Realmente no hay forma de traer a Aoi de vuelta...?"


translate english e1168_24899837:


    "¿No hay forma de salvar a Miyuki...?"


translate english e1168_3d8d79a9:



    voice "voice/e11/6800050a01.opus"
    mx "\"Just give up already.\""


translate english e1168_abd270f2:



    voice "voice/e11/6800060a01.opus"
    mx "\"You're staying here in this world with me.\""


translate english e1168_8f0a9f66:



    voice "voice/e11/6800070a01.opus"
    mx "\"Forever... and ever... and ever...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
