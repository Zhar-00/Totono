

translate english e3424e_88f9c507:



    voice "voice/e34/24e00010b02.opus"
    kmsm "\"HAVE [[YOU] CONFIRMED IT?\""


translate english e3424e_2f5a15fd:



    voice "voice/e34/24e00020b02.opus"
    kmsm "\"HAVE [[YOU] DETERMINED AOI'S CODE NUMBER?\""


translate english e3424e_27981ee7:



    voice "voice/e34/24e00030b02.opus"
    kmsm "\"SOLICITANDO ENTRADA.\""


translate english strings:


    old "Перечитать инструкции"
    new "Revisar las instrucciones"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
