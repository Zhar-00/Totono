

translate english e2319c_0accd139:


    xy "\"......\""


translate english e2319c_76fd4bcf:


    "No entiendo mucho de lo que ha escrito aquí."


translate english e2319c_71ae6ede:


    "Pero sí tengo la clara sensación de que no debería haberlo mirado."


translate english e2319c_356b5b52:


    "Así que decido olvidarlo e irme a la cama."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
