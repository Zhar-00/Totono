

translate english e2162b_9cb45d2e:


    xy "\"How about this photo frame?\""


translate english e2162b_11dc8720:



    voice "voice/e21/62b00010a01.opus"
    mx "\"Hmm... Sure, why not? I like photos.\""


translate english e2162b_a8e86f2c:



    voice "voice/e21/62b00020a01.opus"
    mx "\"Photos are eternal, after all.\""


translate english e2162b_0311e35f:



    voice "voice/e21/62b00030a01.opus"
    mx "\"They're an easy way to see how much you've changed.\""


translate english e2162b_5be80d88:



    voice "voice/e21/62b00040a01.opus"
    mx "\"They help you remember the good times.\""


translate english e2162b_7c4d3428:


    "Vaya... Nunca lo había pensado así."


translate english e2162b_fccd7d6f:



    voice "voice/e21/62b00050a01.opus"
    mx "\"Not a bad suggestion. For you, at least.\""


translate english e2162b_13895abc:



    voice "voice/e21/62b00060a01.opus"
    mx "\"But...\""


translate english e2162b_97488279:



    voice "voice/e21/62b00070a01.opus"
    mx "\"If I have it printed, it'll disappear. The only thing that carries over is my data.\""


translate english e2162b_3965b8f3:


    xy "\"Hm? Did you say something?\""


translate english e2162b_1432b976:



    voice "voice/e21/62b00080a01.opus"
    mx "\"Nope! Nothing at all!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
