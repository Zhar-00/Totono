

translate english e2162b_9cb45d2e:


    xy "\"¿Qué tal este marco de fotos?\""


translate english e2162b_11dc8720:



    voice "voice/e21/62b00010a01.opus"
    mx "\"Mmm... Claro, ¿por qué no? Me gustan las fotos.\""


translate english e2162b_a8e86f2c:



    voice "voice/e21/62b00020a01.opus"
    mx "\"Después de todo, las fotos son eternas.\""


translate english e2162b_0311e35f:



    voice "voice/e21/62b00030a01.opus"
    mx "\"Son una forma fácil de ver cuánto has cambiado.\""


translate english e2162b_5be80d88:



    voice "voice/e21/62b00040a01.opus"
    mx "\"Te ayudan a recordar los buenos tiempos.\""


translate english e2162b_7c4d3428:


    "Vaya... Nunca lo había pensado así."


translate english e2162b_fccd7d6f:



    voice "voice/e21/62b00050a01.opus"
    mx "\"No es mala sugerencia. Para ti, al menos.\""


translate english e2162b_13895abc:



    voice "voice/e21/62b00060a01.opus"
    mx "\"Pero...\""


translate english e2162b_97488279:



    voice "voice/e21/62b00070a01.opus"
    mx "\"Si la imprimo, desaparecerá. Lo único que perdura son mis datos.\""


translate english e2162b_3965b8f3:


    xy "\"¿Hm? ¿Dijiste algo?\""


translate english e2162b_1432b976:



    voice "voice/e21/62b00080a01.opus"
    mx "\"¡Nop! ¡Nada de nada!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
