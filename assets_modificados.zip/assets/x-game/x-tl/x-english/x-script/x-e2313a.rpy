

translate english e2313a_2af7ac5e:



    voice "voice/e23/13a00010a01.opus"
    mx "\"...Sí, vale.\""


translate english e2313a_4efdf143:



    voice "voice/e23/13a00020a01.opus"
    mx "\"Bien. Confiaré en ti.\""


translate english e2313a_9e959452:


    xy "\"Genial. Gracias.\""


translate english e2313a_838c13f8:



    voice "voice/e23/13a00030a01.opus"
    mx "\"Y bien, ¿qué hay en el menú?\""


translate english e2313a_10c87281:


    xy "\"Okonomiyaki.\""


translate english e2313a_42c79c8c:


    xy "\"Gyoza.\""


translate english e2313a_fedd6c50:


    xy "\"Bistec hamburguesa.\""


translate english e2313a_567fd39d:



    voice "voice/e23/13a00040a01.opus"
    mx "\"Recuerdo que me lo hiciste una vez, cuando éramos niños.\""


translate english e2313a_978cafc5:



    voice "voice/e23/13a00050a01.opus"
    mx "\"Al menos, INTENTASTE hacerlo, de todos modos...\""


translate english e2313a_e0ac3cb8:


    xy "\"¡Cállate! ¡Te lo demostraré! ¡Ya no soy un niño!\""


translate english e2313a_65d3f157:



    voice "voice/e23/13a00060a01.opus"
    mx "\"Claro, cariño. Lo espero con ansias.\""


translate english e2313a_748499da:



    voice "voice/e23/13a00070a01.opus"
    mx "\"¡Mm-mmm! ¡Delicioso!\""


translate english e2313a_5ab62fa4:



    voice "voice/e23/13a00080a01.opus"
    mx "\"¡Shinichi, esto es sinceramente increíble! ¿Cuál es tu ingrediente secreto?\""


translate english e2313a_5fe1bafb:


    xy "\"¿Eh? No hay ninguno.\""


translate english e2313a_d2bf7683:



    voice "voice/e23/13a00090a01.opus"
    mx "\"Mentiroso. No puedes ocultármelo.\""


translate english e2313a_d3f527a0:



    voice "voice/e23/13a00100a01.opus"
    mx "\"Con un bocado lo noto... Está hecho con tu amor.\""


translate english e2313a_0accd139:


    xy "\"......!\""


translate english e2313a_fc09cbce:


    "No sé cómo puede decir eso con cara seria..."


translate english e2313a_f82a8cbd:



    voice "voice/e23/13a00110a01.opus"
    mx "\"¡Uuh, te estás sonrojando! ¿Te avergoncé?\""


translate english e2313a_864d0100:


    xy "\"¡N-No!\""


translate english e2313a_fb603508:


    xy "\"¡Vuelvo enseguida!\""


translate english e2313a_02e144a3:


    "Miyuki me lanza una sonrisa burlona mientras entro a la cocina."


translate english e2313a_dd84e09e:


    "Abro el refrigerador y saco una caja de fresas."


translate english e2313a_96d5618b:


    "¡Como venganza, voy a prepararle su postre favorito!"


translate english e2313a_8a168fa7:


    "Trituro las fresas..."


translate english e2313a_cb28e29c:


    "Luego vierto un poco de crema sobre ellas..."


translate english e2313a_300ded43:


    "Y por último, añado algo de azúcar—"


translate english e2313a_7fe1cf16:


    xy "\"¿Eh...?\""


translate english e2313a_dba87359:


    "Parece que el azucarero está vacío."


translate english e2313a_956f1786:


    "¿Dónde guarda el azúcar, que ya no recuerdo...?"


translate english e2313a_06f021b3:


    xy "\"¿Aquí abajo...?\""


translate english e2313a_165f8ee4:


    "Abro un armario a mis pies."


translate english e2313a_35b72a29:


    "Inside is a large paper bag marked \"SUGAR\"con letras rojas... además de una bolsa de papel más pequeña, sin etiqueta."



translate english e2313a_dbccc1f7:


    "Extiendo la mano y agarro—"


translate english strings:


    old "Большой пакет"
    new "La bolsa grande"


    old "Маленький пакет"
    new "La bolsa pequeña"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
