

translate english e1167c_136cc5b4:



    voice "voice/e11/67c00010b02.opus"
    kmsm "\"CHEAT CODE CONFIRMED.\""


translate english e1167c_cb6d8cd3:



    voice "voice/e11/67c00020b02.opus"
    kmsm "\"PREPARING TO FORCE-UPDATE THE UNIVERSE.\""


translate english e1167c_c2e1e1ad:


    xy "\"Update... the universe...?\""


translate english e1167c_592e6aad:



    voice "voice/e11/67c00030a01.opus"
    mx "\"Wha—?!\""


translate english e1167c_36d06f4a:



    voice "voice/e11/67c00040a01.opus"
    mx "\"What have you DONE?!\""


translate english e1167c_dbdb8948:



    voice "voice/e11/67c00050b02.opus"
    kmsm "\"THIS UPDATE IS IRREVERSIBLE. ONCE COMPLETE, REGULAR PLAY WILL BE DISABLED.\""


translate english e1167c_86c52575:



    voice "voice/e11/67c00060a01.opus"
    mx "\"It can't be—\""


translate english e1167c_af495987:



    voice "voice/e11/67c00070b02.opus"
    kmsm "\"WARNING. SHOULD THE SUBJECT WISH TO EXPERIENCE THE WORLD AS INTENDED, PLEASE CLOSE THE GAME NOW.\""


translate english e1167c_5d28a577:



    voice "voice/e11/67c00080a01.opus"
    mx "\"You put in the cheat code?\""


translate english e1167c_7c3c0a0b:



    voice "voice/e11/67c00090b02.opus"
    kmsm "\"AGAIN, IT IS STRONGLY ENCOURAGED TO CLOSE THE GAME IMMEDIATELY.\""


translate english e1167c_cc46791c:



    voice "voice/e11/67c00100a01.opus"
    mx "\"Give me a fucking break...!\""


translate english e1167c_3db88e2c:


    "Algo me golpea el cráneo..."


translate english e1167c_b18cbbce:



    voice "voice/a01/13v00060b02.opus"
    kmsm "INICIANDO CUENTA REGRESIVA."



translate english e1167c_f1e159be:



    voice "voice/e11/67c00120a01.opus"
    mx "¡Ahí está! ¡El protagonista está muerto!"


translate english e1167c_383ed45f:



    voice "voice/e11/67c00160a01.opus"
    mx "¡Ahora sal del juego! ¡Rápido!"


translate english e1167c_0b3e290b:



    voice "voice/e11/67c00180a01.opus"
    mx "¡Hazlo! ¡Ahora!"


translate english e1167c_6a3a4dfe:



    voice "voice/e11/67c00200a01.opus"
    mx "¡Por favor! ¿Por qué haces TÚ esto?"


translate english e1167c_636c8c8e:



    voice "voice/e11/67c00220a01.opus"
    mx "Si hubiera sabido que TÚ me traicionarías así—"


translate english e1167c_cf5a67c1:



    voice "voice/e11/67c00240a01.opus"
    mx "Si hubiera sabido que TÚ te rendirías a mitad de la historia—"


translate english e1167c_6181e58c:



    voice "voice/e11/67c00260a01.opus"
    mx "Si hubiera sabido que perdería mis recuerdos—"


translate english e1167c_356cdabc:



    voice "voice/e11/67c00280a01.opus"
    mx "¡Entonces preferiría que TÚ simplemente—"


translate english e1167c_e5be4278:



    voice "voice/e11/67c00300a01.opus"
    mx "—¡¡¡ME ODIARAS CON TODAS TUS FUERZAS!!!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
