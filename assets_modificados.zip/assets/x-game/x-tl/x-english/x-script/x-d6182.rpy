

translate english d6182_69286145:



    voice "voice/d61/8200010b03.opus"
    c "\"Huh...?\""


translate english d6182_a042c5b3:


    "Ahí, encuentro a Ryuujirou con un uniforme de chica, con su polla asomando por debajo de la falda..."


translate english d6182_3f2c2f1d:



    voice "voice/d61/8200020a02.opus"
    aoi "\"Boop...\""


translate english d6182_eeb6facd:


    "Y ahí está Aoi, haciéndole una mamada."


translate english d6182_d7c1a69a:



    voice "voice/d61/8200030a02.opus"
    aoi "\"No way...\""


translate english d6182_8c475dd6:



    voice "voice/d61/8200040b03.opus"
    c "\"Aaah...\""


translate english d6182_569da03c:



    voice "voice/d61/8200050b03.opus"
    c "\"AAAAAAAAAAAAAAAAAAAAHHHHH!!!\""


translate english d6182_86ca0b20:


    "Lo siguiente que sé, todo se vuelve negro."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
