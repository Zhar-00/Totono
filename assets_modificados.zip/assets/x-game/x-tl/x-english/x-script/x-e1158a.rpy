

translate english e1158a_920c65b6:


    xy "\"Have you seen Miyuki anywhere?!\""


translate english e1158a_6b16a6ba:



    voice "voice/e11/58a00010b01.opus"
    xtl "\"Sone-san? I just saw her out in front of the school—\""


translate english e1158a_f106a0f2:


    xy "\"The school! Got it! Thanks, buddy!\""


translate english e1158a_f9889fcf:



    voice "voice/e11/58a00020b01.opus"
    xtl "\"Wh... HEY! Shinichi! What about your injuries?!\""


translate english e1158a_ec7ac67e:


    xy "\"What injuries? I'm fit as a fiddle!\""


translate english e1158a_e08e1281:



    voice "voice/e11/58a00030b01.opus"
    xtl "\"But what about the car accident—?!\""


translate english e1158a_5542c955:


    xy "\"Sorry! We'll catch up later!\""


translate english e1158a_ed9deffa:



    voice "voice/e11/58a00040b01.opus"
    xtl "\"H-Hey—!\""


translate english e1158a_49e77ec6:


    "¡No hay tiempo para hablar ahora!"


translate english e1158a_315ed62d:


    "Paso junto a algunos estudiantes en el camino, ganándome más de unas cuantas miradas extrañas mientras lo hago."


translate english e1158a_49ada547:


    "Debo decir que probablemente no debería estar tan sin aliento ya..."


translate english e1158a_43739ef9:


    "Necesito empezar una rutina de ejercicio o algo..."


translate english e1158a_0a366d8f:


    "Mientras el sol se pone afuera, corro por el pasillo hacia el salón—"


translate english e1158a_7fc240e8:


    "—pero ella no está ahí."


translate english e1158a_e1d1418b:


    "Lo cual significa—"


translate english e1158a_bbefafcb:


    xy "\"Miyuki!\""



translate english e1158a_ef7d2c54:


    "Abro la puerta del techo."


translate english e1158a_62d9a3a0:


    xy "\"There you are...\""


translate english e1158a_1368c30f:



    voice "voice/e11/58a00050a01.opus"
    mx "\"You came after me?\""


translate english e1158a_26ce6f17:



    voice "voice/e11/58a00060a01.opus"
    mx "\"Or...\""


translate english e1158a_0b268059:



    voice "voice/e11/58a00070a01.opus"
    mx "\"Are you just here for THIS...?\""


translate english e1158a_5337736c:


    "Miyuki levanta su teléfono."


translate english e1158a_49876c76:


    xy "\"Miyuki... what's gotten into you?\""


translate english e1158a_cf41aa3b:


    xy "\"You're acting kinda weird—\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
