

translate english e1158a_920c65b6:


    xy "\"¿Has visto a Miyuki por algún lado?\""


translate english e1158a_6b16a6ba:



    voice "voice/e11/58a00010b01.opus"
    xtl "\"¿Sone-san? La acabo de ver afuera, frente a la escuela—\""


translate english e1158a_f106a0f2:


    xy "\"¡La escuela! ¡Entendido! ¡Gracias, amigo!\""


translate english e1158a_f9889fcf:



    voice "voice/e11/58a00020b01.opus"
    xtl "\"¿Q...? ¡OYE! ¡Shinichi! ¿Y tus heridas?\""


translate english e1158a_ec7ac67e:


    xy "\"¿Qué heridas? ¡Estoy como nuevo!\""


translate english e1158a_e08e1281:



    voice "voice/e11/58a00030b01.opus"
    xtl "\"¡¿Pero y el accidente de auto—?!\""


translate english e1158a_5542c955:


    xy "\"¡Perdón! ¡Hablamos luego!\""


translate english e1158a_ed9deffa:



    voice "voice/e11/58a00040b01.opus"
    xtl "\"¡O-Oye—!\""


translate english e1158a_49e77ec6:


    "¡No hay tiempo para hablar ahora!"


translate english e1158a_315ed62d:


    "Paso junto a algunos estudiantes en el camino, ganándome más de unas cuantas miradas extrañas mientras lo hago."


translate english e1158a_49ada547:


    "Debo decir que probablemente no debería estar tan sin aliento ya..."


translate english e1158a_43739ef9:


    "Necesito empezar una rutina de ejercicio o algo..."


translate english e1158a_0a366d8f:


    "Mientras el sol se pone afuera, corro por el pasillo hacia el salón—"


translate english e1158a_7fc240e8:


    "—pero ella no está ahí."


translate english e1158a_e1d1418b:


    "Lo cual significa—"


translate english e1158a_bbefafcb:


    xy "\"¡Miyuki!\""



translate english e1158a_ef7d2c54:


    "Abro la puerta del techo."


translate english e1158a_62d9a3a0:


    xy "\"Ahí estás...\""


translate english e1158a_1368c30f:



    voice "voice/e11/58a00050a01.opus"
    mx "\"¿Viniste tras de mí?\""


translate english e1158a_26ce6f17:



    voice "voice/e11/58a00060a01.opus"
    mx "\"¿O...?\""


translate english e1158a_0b268059:



    voice "voice/e11/58a00070a01.opus"
    mx "\"¿Solo viniste por ESTO...?\""


translate english e1158a_5337736c:


    "Miyuki levanta su teléfono."


translate english e1158a_49876c76:


    xy "\"Miyuki... ¿qué te pasa?\""


translate english e1158a_cf41aa3b:


    xy "\"Estás actuando algo raro—\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
