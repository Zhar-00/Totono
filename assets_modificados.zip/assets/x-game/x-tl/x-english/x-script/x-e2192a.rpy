

translate english e2192a_e8797142:


    xy "\"Alright. Let's go.\""


translate english e2192a_059ecff0:



    voice "voice/e21/92a00010a01.opus"
    mx "\"Good.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
