

translate english e2192a_e8797142:


    xy "\"Muy bien. Vamos.\""


translate english e2192a_059ecff0:



    voice "voice/e21/92a00010a01.opus"
    mx "\"Bien.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
