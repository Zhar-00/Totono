

translate english c5211_97b6a69c:


    xy "\"I'm home!\""


translate english c5211_a4ada528:


    "La llamo, pero no obtengo respuesta."


translate english c5211_ce7edbd2:


    "Todo ha estado totalmente bien hasta ahora..."


translate english c5211_51608602:


    "Entonces, ¿por qué me siento tan inquieto de repente?"


translate english c5211_117af311:


    xy "\"Hey! You here?\""


translate english c5211_d22b0ce5:


    xy "\"Aoi?\""


translate english c5211_eff407a2:


    xy "\"Hey there, Eru.\""


translate english c5211_1da79a1e:


    xy "\"Where'd she go...?\""


translate english c5211_c86a8fd0:


    "Murmuro para mí mismo mientras juego con Eru."


translate english c5211_f8439f93:


    "En general, no me siento cómodo siendo demasiado público sobre mis relaciones."


translate english c5211_414459da:


    "Así que ha habido muchos días en que Aoi y yo salimos de la escuela por separado."


translate english c5211_a3114972:


    "Pero pensándolo bien, algo al respecto me molesta."


translate english c5211_a40546bd:


    "Aoi no forma parte de ningún club ni nada."


translate english c5211_345f281d:


    "Y de alguna manera dudo que tenga amigos cercanos fuera de Miyuki."


translate english c5211_0d7f678c:


    "Entonces, ¿qué podría estar haciendo ahora?"


translate english c5211_1117cd9c:



    voice "voice/c52/1100030a02.opus"
    aoi "\"Aoi's home!\""


translate english c5211_079cb7e1:


    "La puerta principal se abre, y Aoi llama."


translate english c5211_44781c27:


    "Eru salta del sofá para recibirla."


translate english c5211_cdc44e0d:



    voice "voice/c52/1100040a02.opus"
    aoi "\"Did you miss me, Eru?\""


translate english c5211_9cfe6cc0:



    voice "voice/c52/1100050a02.opus"
    aoi "\"Time for your dinner—\""


translate english c5211_622e760a:


    xy "\"Welcome home.\""



translate english c5211_e774610f:


    xy "\"Where were you?\""


translate english c5211_5dcbe559:



    voice "voice/c52/1100060a02.opus"
    aoi "\"Went to buy milk.\""


translate english c5211_060974d8:


    "Aoi saca un cartón de leche de una bolsa para llevar de la tienda de la esquina."


translate english c5211_2b3d7bda:


    "Pero la tienda de la esquina más cercana desde aquí—la tienda familiar de Yuutarou—está a unos diez minutos a pie como máximo."


translate english c5211_c0a0589e:


    "No debería haberle tomado tanto tiempo..."


translate english c5211_22e3c026:



    voice "voice/c52/1100070a02.opus"
    aoi "\"What's wrong?\""


translate english c5211_46e5bc27:


    xy "\"Oh, it's nothing.\""


translate english c5211_bda27329:



    voice "voice/c52/1100080a02.opus"
    aoi "\"Shinichi?\""


translate english c5211_6800d26b:


    xy "\"I said it's nothing.\""


translate english c5211_d76a069d:



    voice "voice/c52/1100090a02.opus"
    aoi "\"Wait!\""


translate english c5211_1dd45143:


    "Desesperada, Aoi me detiene en seco."


translate english c5211_3b7326c4:



    voice "voice/c52/1100100a02.opus"
    aoi "\"Umm, Aoi needs to talk to y—\""


translate english c5211_6f981c4a:


    xy "\"Sorry. It'll have to wait.\""


translate english c5211_cbbb6887:



    voice "voice/c52/1100110a02.opus"
    aoi "\"Shinichi...\""


translate english c5211_866f0054:


    "Me la quito de encima y subo las escaleras."


translate english c5211_5e8b78c0:


    "No intenta perseguirme."


translate english c5211_1ce504aa:


    "Miro por la ventana."


translate english c5211_12e64a21:


    xy "\"......\""


translate english c5211_1ae1973c:


    "La pálida luna cuelga sobre el oscuro lienzo del cielo nocturno."


translate english c5211_7cdd5cb7:


    "Me recuerda a la noche en que consumamos nuestro amor en la azotea."


translate english c5211_d69cd3ed:


    "Fui tan feliz entonces."


translate english c5211_b2c874e6:


    "Sinceramente, no podría haber pedido más."


translate english c5211_e5b9d093:


    "Y creía que ella sentía lo mismo."


translate english c5211_49119816:


    "...Pero eso fue entonces."


translate english c5211_e7bc9249:


    "Ahora, con cada momento que pasa, nos vamos desmoronando."


translate english c5211_391c147c:


    "¿Seguimos siquiera en el mismo planeta?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
