

translate english c6113_76c0a0c3:


    xy "\"Maybe...\""


translate english c6113_4f054a84:


    "Eru es un gato transceptor."


translate english c6113_4a2f1b3c:


    "Aoi me contó todo sobre sus supuestos poderes de precognición."


translate english c6113_2805bb24:


    "Sé que probablemente debería tomarlo todo con pinzas, pero al mismo tiempo... Eru es quien me ayudó a encontrarla en el techo de la escuela esa noche."


translate english c6113_026301e4:


    "Reviso la hora en mi teléfono."


translate english c6113_f3295661:


    "Treinta minutos hasta que empiece la función."


translate english c6113_043c4873:


    "Me siento mal por sospechar de ella, pero admito que algo en su comportamiento me ha estado molestando últimamente."


translate english c6113_3be605f4:


    xy "\"...Fine.\""


translate english c6113_d525caae:


    "Mi instinto me obliga a actuar."


translate english c6113_aeef2588:


    "Y así decido esconderme en los arbustos y esperar."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
