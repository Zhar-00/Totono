

translate english d4223_f819370f:


    xy "\"No digas tonterías. ¿Olvidas que cuando te encontré hace un momento, no respirabas?\""


translate english d4223_c0563bd5:


    "Agarro mi teléfono rápidamente."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
