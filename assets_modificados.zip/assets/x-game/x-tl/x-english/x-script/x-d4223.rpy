

translate english d4223_f819370f:


    xy "\"Don't be ridiculous. Are you forgetting that when I found you just now, you weren't breathing?\""


translate english d4223_c0563bd5:


    "Agarro mi teléfono rápidamente."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
