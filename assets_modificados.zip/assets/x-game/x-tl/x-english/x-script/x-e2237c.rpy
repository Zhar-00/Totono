

translate english e2237c_7d734f07:


    xy "\"¡Miyuki—!\""


translate english e2237c_7a1de061:



    voice "voice/e22/37c00010a01.opus"
    mx "\"¡Adelante... Está bien...!\""


translate english e2237c_7b6a9fed:



    voice "voice/e22/37c00020a01.opus"
    mx "\"¡Solo... cúbreme...! ¡¡¡Nnhaaahh!!! ¡Nnngg! ¡Rocíame con eso...!\""


translate english e2237c_51e3b26e:



    voice "voice/e22/37c00030a01.opus"
    mx "\"¡¡¡Dispara tu... semen caliente... por todo... mi culo...!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
