

translate english e2237c_7d734f07:


    xy "\"Miyuki—!\""


translate english e2237c_7a1de061:



    voice "voice/e22/37c00010a01.opus"
    mx "\"Go ahead... It's okay...!\""


translate english e2237c_7b6a9fed:



    voice "voice/e22/37c00020a01.opus"
    mx "\"Just... cover me... Nnhaaahh!!! Nnngg! Drizzle me with it...!\""


translate english e2237c_51e3b26e:



    voice "voice/e22/37c00030a01.opus"
    mx "\"Shoot your... hot cum... all over... my ass...!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
