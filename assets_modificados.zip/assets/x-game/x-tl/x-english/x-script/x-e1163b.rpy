

translate english e1163b_273ebeb8:



    voice "voice/e11/63b00010b01.opus"
    xtl "\"Dude, look at your hair! And your beard!\""


translate english e1163b_a461401f:



    voice "voice/e11/63b00020b01.opus"
    xtl "\"I never would've recognized ya!\""


translate english e1163b_e791d7d8:


    xy "\"My what...?\""


translate english e1163b_4607a4b2:


    "Ahora que lo menciona... Mi cabello sí se siente bastante largo..."


translate english e1163b_e515a3d7:


    xy "\"That's weird...\""


translate english e1163b_bea159c1:



    voice "voice/e11/63b00030b01.opus"
    xtl "\"Did you hit your head in the car accident or something?\""


translate english e1163b_f26066a5:


    xy "\"No, no!\""


translate english e1163b_0ab4f146:


    xy "\"At least... I don't think so...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
