

translate english e1163b_273ebeb8:



    voice "voice/e11/63b00010b01.opus"
    xtl "\"¡Amigo, mira tu pelo! ¡Y tu barba!\""


translate english e1163b_a461401f:



    voice "voice/e11/63b00020b01.opus"
    xtl "\"¡Nunca te habría reconocido!\""


translate english e1163b_e791d7d8:


    xy "\"¿Mi qué...?\""


translate english e1163b_4607a4b2:


    "Ahora que lo menciona... Mi cabello sí se siente bastante largo..."


translate english e1163b_e515a3d7:


    xy "\"Qué raro...\""


translate english e1163b_bea159c1:



    voice "voice/e11/63b00030b01.opus"
    xtl "\"¿Te golpeaste la cabeza en el accidente de auto o algo?\""


translate english e1163b_f26066a5:


    xy "\"¡No, no!\""


translate english e1163b_0ab4f146:


    xy "\"Al menos... creo que no...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
