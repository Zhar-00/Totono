

translate english c7131_2ee63878:



    voice "voice/c71/3100010b03.opus"
    c "\"Hi...\""


translate english c7131_148b7693:



    voice "voice/c71/3100020a02.opus"
    aoi "\"Haru-chan!\""


translate english c7131_69e1b53d:



    voice "voice/c71/3100030b03.opus"
    c "\"Aoi-senpai...\""


translate english c7131_4c476de9:



    voice "voice/c71/3100040b03.opus"
    c "\"I just got a call from Susuki-senpai...\""


translate english c7131_cff499f2:



    voice "voice/c71/3100050a02.opus"
    aoi "\"Aoi needs a favor.\""


translate english c7131_c64cf142:



    voice "voice/c71/3100060a02.opus"
    aoi "\"Have sex with me.\""


translate english c7131_4d5167d1:



    voice "voice/c71/3100070b03.opus"
    c "\"......What?\""


translate english c7131_fc98c4dd:



    voice "voice/c71/3100080a02.opus"
    aoi "\"Have sex with me, Haru-chan.\""


translate english c7131_16622931:



    voice "voice/c71/3100090b03.opus"
    c "\"Wh... What? What happened? What about Susuki-senpai?\""


translate english c7131_bdbb3880:



    voice "voice/c71/3100100a02.opus"
    aoi "\"Aoi needs to have sex with you.\""


translate english c7131_dfc37676:



    voice "voice/c71/3100110b03.opus"
    c "\"Aoi-senpai...\""


translate english c7131_8a483d8b:


    "La voz de Aoi es tan firme que él no puede discutir."


translate english c7131_814b53d2:



    voice "voice/c71/3100120b03.opus"
    c "\"...Okay.\""


translate english c7131_f36029c5:



    voice "voice/c71/3100130b03.opus"
    c "\"I don't know what's going on...\""


translate english c7131_ae0f6048:



    voice "voice/c71/3100140b03.opus"
    c "\"So my only option is to do as you ask...\""


translate english c7131_a206ccf3:



    voice "voice/c71/3100150b03.opus"
    c "\"But first... I want to tell you how I feel.\""


translate english c7131_60587d3b:



    voice "voice/c71/3100160b03.opus"
    c "\"I'm in love with you, Aoi-senpai.\""


translate english c7131_4f86af2a:



    voice "voice/c71/3100170b03.opus"
    c "\"I really like you. I'm crazy about you.\""


translate english c7131_946140d6:



    voice "voice/c71/3100180b03.opus"
    c "\"And I know you love Susuki-senpai.\""


translate english c7131_085b1d20:



    voice "voice/c71/3100190b03.opus"
    c "\"Whenever you were with me, I knew you were thinking about him.\""


translate english c7131_0c73d684:



    voice "voice/c71/3100200b03.opus"
    c "\"But... none of that matters.\""


translate english c7131_493699a0:



    voice "voice/c71/3100210b03.opus"
    c "\"I'll do anything for you, Aoi-senpai. Anything to satisfy you.\""


translate english c7131_618e9aec:



    voice "voice/c71/3100220b03.opus"
    c "\"...So please...\""


translate english c7131_ccb881e7:



    voice "voice/c71/3100230b03.opus"
    c "\"Please take my virginity! For real this time!\""


translate english c7131_a5f4c058:



    voice "voice/c71/3100240a02.opus"
    aoi "\"Haru-chan...\""



translate english c7131_5833e51e:


    "El suelo cruje."


translate english c7131_88cc0a90:


    "Aoi avanza lentamente, sin peso, como si se estuviera desvaneciendo."


translate english c7131_c20f2501:



    voice "voice/c71/3100250a02.opus"
    aoi "\"Don't cry.\""


translate english c7131_60dd56ec:



    voice "voice/c71/3100260a02.opus"
    aoi "\"Aoi will make it all feel better.\""


translate english c7131_62592d8b:



    voice "voice/c71/3100270b03.opus"
    c "\"Please do...\""


translate english c7131_f8202f4c:


    "La puerta se cierra."


translate english c7131_dcdade71:


    "Cae el silencio."


translate english c7131_7afbf393:


    "Tumbado ahí en la oscura sala de estar, abro los ojos."


translate english c7131_f1698624:


    "No puedo dormir—"


translate english c7131_55236cd9:


    xy "\"...Eru?\""


translate english c7131_eb3933ff:


    xy "\"When did you get here?\""


translate english c7131_8adaf0be:


    "Creo recordar haberlo encerrado arriba en mi habitación para que Miyuki no tuviera un ataque de alergia durante mi fiesta de cumpleaños..."


translate english c7131_babf25dd:


    "¿Se escapó cuando Aoi abrió la puerta?"


translate english c7131_5bdb9cac:


    "Casi se siente como si se hubiera teletransportado aquí..."


translate english c7131_c99586b1:


    "Me maúlla dulcemente."


translate english c7131_dc6222b7:


    "Lo recojo y cierro los ojos, acunando su calor en mis brazos."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
