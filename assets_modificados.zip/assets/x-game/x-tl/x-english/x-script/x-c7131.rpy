

translate english c7131_2ee63878:



    voice "voice/c71/3100010b03.opus"
    c "\"Hola...\""


translate english c7131_148b7693:



    voice "voice/c71/3100020a02.opus"
    aoi "\"¡Haru-chan!\""


translate english c7131_69e1b53d:



    voice "voice/c71/3100030b03.opus"
    c "\"Aoi-senpai...\""


translate english c7131_4c476de9:



    voice "voice/c71/3100040b03.opus"
    c "\"Acabo de recibir una llamada de Susuki-senpai...\""


translate english c7131_cff499f2:



    voice "voice/c71/3100050a02.opus"
    aoi "\"Aoi necesita un favor.\""


translate english c7131_c64cf142:



    voice "voice/c71/3100060a02.opus"
    aoi "\"Ten sexo conmigo.\""


translate english c7131_4d5167d1:



    voice "voice/c71/3100070b03.opus"
    c "\"......¿Qué?\""


translate english c7131_fc98c4dd:



    voice "voice/c71/3100080a02.opus"
    aoi "\"Ten sexo conmigo, Haru-chan.\""


translate english c7131_16622931:



    voice "voice/c71/3100090b03.opus"
    c "\"¿Q... Qué? ¿Qué pasó? ¿¿Y Susuki-senpai??\""


translate english c7131_bdbb3880:



    voice "voice/c71/3100100a02.opus"
    aoi "\"Aoi necesita tener sexo contigo.\""


translate english c7131_dfc37676:



    voice "voice/c71/3100110b03.opus"
    c "\"Aoi-senpai...\""


translate english c7131_8a483d8b:


    "La voz de Aoi es tan firme que él no puede discutir."


translate english c7131_814b53d2:



    voice "voice/c71/3100120b03.opus"
    c "\"...Bien.\""


translate english c7131_f36029c5:



    voice "voice/c71/3100130b03.opus"
    c "\"No sé qué está pasando...\""


translate english c7131_ae0f6048:



    voice "voice/c71/3100140b03.opus"
    c "\"Así que mi única opción es hacer lo que pides...\""


translate english c7131_a206ccf3:



    voice "voice/c71/3100150b03.opus"
    c "\"Pero primero... quiero decirte cómo me siento.\""


translate english c7131_60587d3b:



    voice "voice/c71/3100160b03.opus"
    c "\"Estoy enamorado de ti, Aoi-senpai.\""


translate english c7131_4f86af2a:



    voice "voice/c71/3100170b03.opus"
    c "\"Me gustas mucho. Estoy loco por ti.\""


translate english c7131_946140d6:



    voice "voice/c71/3100180b03.opus"
    c "\"Y sé que amas a Susuki-senpai.\""


translate english c7131_085b1d20:



    voice "voice/c71/3100190b03.opus"
    c "\"Cada vez que estabas conmigo, sabía que estabas pensando en él.\""


translate english c7131_0c73d684:



    voice "voice/c71/3100200b03.opus"
    c "\"Pero... nada de eso importa.\""


translate english c7131_493699a0:



    voice "voice/c71/3100210b03.opus"
    c "\"Haré lo que sea por ti, Aoi-senpai. Lo que sea para satisfacerte.\""


translate english c7131_618e9aec:



    voice "voice/c71/3100220b03.opus"
    c "\"...Así que, por favor...\""


translate english c7131_ccb881e7:



    voice "voice/c71/3100230b03.opus"
    c "\"¡Por favor, toma mi virginidad! ¡De verdad esta vez!\""


translate english c7131_a5f4c058:



    voice "voice/c71/3100240a02.opus"
    aoi "\"Haru-chan...\""



translate english c7131_5833e51e:


    "El suelo cruje."


translate english c7131_88cc0a90:


    "Aoi avanza lentamente, sin peso, como si se estuviera desvaneciendo."


translate english c7131_c20f2501:



    voice "voice/c71/3100250a02.opus"
    aoi "\"No llores.\""


translate english c7131_60dd56ec:



    voice "voice/c71/3100260a02.opus"
    aoi "\"Aoi hará que todo se sienta mejor.\""


translate english c7131_62592d8b:



    voice "voice/c71/3100270b03.opus"
    c "\"Por favor...\""


translate english c7131_f8202f4c:


    "La puerta se cierra."


translate english c7131_dcdade71:


    "Cae el silencio."


translate english c7131_7afbf393:


    "Tumbado ahí en la oscura sala de estar, abro los ojos."


translate english c7131_f1698624:


    "No puedo dormir—"


translate english c7131_55236cd9:


    xy "\"...¿Eru?\""


translate english c7131_eb3933ff:


    xy "\"¿Cuándo llegaste?\""


translate english c7131_8adaf0be:


    "Creo recordar haberlo encerrado arriba en mi habitación para que Miyuki no tuviera un ataque de alergia durante mi fiesta de cumpleaños..."


translate english c7131_babf25dd:


    "¿Se escapó cuando Aoi abrió la puerta?"


translate english c7131_5bdb9cac:


    "Casi se siente como si se hubiera teletransportado aquí..."


translate english c7131_c99586b1:


    "Me maúlla dulcemente."


translate english c7131_dc6222b7:


    "Lo recojo y cierro los ojos, acunando su calor en mis brazos."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
