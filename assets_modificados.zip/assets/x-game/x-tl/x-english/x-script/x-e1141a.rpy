

translate english e1141a_ea607621:



    voice "voice/e11/41a00010a01.opus"
    mx "\"You don't have any more choices to make.\""


translate english e1141a_a09f61a8:



    voice "voice/e11/41a00020a01.opus"
    mx "\"The world has been modified, and now...\""


translate english e1141a_6e35cbb2:



    voice "voice/e11/41a00030a01.opus"
    mx "\"...you don't need to worry about a thing.\""


translate english e1141a_d9125880:



    voice "voice/e11/41a00040a01.opus"
    mx "\"You'll be happy with me.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
