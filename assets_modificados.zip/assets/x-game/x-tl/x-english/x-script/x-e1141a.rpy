

translate english e1141a_ea607621:



    voice "voice/e11/41a00010a01.opus"
    mx "\"Ya no tienes más decisiones que tomar.\""


translate english e1141a_a09f61a8:



    voice "voice/e11/41a00020a01.opus"
    mx "\"El mundo ha sido modificado, y ahora...\""


translate english e1141a_6e35cbb2:



    voice "voice/e11/41a00030a01.opus"
    mx "\"...no tienes de qué preocuparte.\""


translate english e1141a_d9125880:



    voice "voice/e11/41a00040a01.opus"
    mx "\"Serás feliz conmigo.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
