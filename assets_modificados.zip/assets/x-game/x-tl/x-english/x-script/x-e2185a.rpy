

translate english e2185a_58233ab7:



    voice "voice/e21/85a00010a01.opus"
    mx "\"If you insist you hate real girls that much...\""


translate english e2185a_49212af9:



    voice "voice/e21/85a00020a01.opus"
    mx "\"...then I'll just have to rehabilitate you.\""


translate english e2185a_fce8cc3e:


    xy "\"Rehabilitate me how...?\""


translate english e2185a_b54deddd:



    voice "voice/e21/85a00030a01.opus"
    mx "\"I'll make your wildest dreams come true!\""


translate english e2185a_69ef5dbb:


    xy "\"R-Really...?\""


translate english e2185a_d5fb060b:



    voice "voice/e21/85a00040a01.opus"
    mx "\"Of course.\""


translate english e2185a_2e6b3da2:



    voice "voice/e21/85a00050a01.opus"
    mx "\"I'll give you everything you could ever want and more.\""


translate english e2185a_4d923ec8:



    voice "voice/e21/85a00060a01.opus"
    mx "\"Just you wait and see...\""


translate english e2185a_45c566d6:


    "¿Es solo mi imaginación jugándome una mala pasada, o... siento algo malvado escondido detrás de su sonrisa...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
