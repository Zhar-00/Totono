

translate english e2185a_58233ab7:



    voice "voice/e21/85a00010a01.opus"
    mx "\"Si insistes en que odias tanto a las chicas reales...\""


translate english e2185a_49212af9:



    voice "voice/e21/85a00020a01.opus"
    mx "\"...entonces tendré que rehabilitarte.\""


translate english e2185a_fce8cc3e:


    xy "\"¿Rehabilitarme cómo...?\""


translate english e2185a_b54deddd:



    voice "voice/e21/85a00030a01.opus"
    mx "\"¡Haré realidad tus sueños más salvajes!\""


translate english e2185a_69ef5dbb:


    xy "\"¿D-De verdad...?\""


translate english e2185a_d5fb060b:



    voice "voice/e21/85a00040a01.opus"
    mx "\"Claro.\""


translate english e2185a_2e6b3da2:



    voice "voice/e21/85a00050a01.opus"
    mx "\"Te daré todo lo que puedas desear y más.\""


translate english e2185a_4d923ec8:



    voice "voice/e21/85a00060a01.opus"
    mx "\"Ya verás...\""


translate english e2185a_45c566d6:


    "¿Es solo mi imaginación jugándome una mala pasada, o... siento algo malvado escondido detrás de su sonrisa...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
