

translate english a3212_7803c940:


    xy "\"Ah, sí, ¿y Yuutarou estaba en la caja?\""


translate english a3212_f5d9450d:



    voice "voice/a32/1200010a02.opus"
    aoi "\"Nop.\""


translate english a3212_03931ba2:



    voice "voice/a32/1200020a02.opus"
    aoi "\"Pero esa torpe sí.\""


translate english a3212_37bfde72:


    xy "\"¿Qué torpe?\""


translate english a3212_6fe58d69:



    voice "voice/a32/1200030a02.opus"
    aoi "\"La del club de teatro.\""


translate english a3212_c9832836:


    "Ah, cierto... La chica que grita y sale corriendo cada vez que me ve..."


translate english a3212_65626964:


    xy "\"Esa chica le tiene miedo hasta a su propia sombra. ¿Cómo puede mantener un trabajo de atención al cliente?\""


translate english a3212_407ba591:



    voice "voice/a32/1200040a02.opus"
    aoi "\"Aoi la saludó.\""


translate english a3212_0fa2c162:



    voice "voice/a32/1200050a02.opus"
    aoi "\"Se asustó.\""


translate english a3212_40da8044:



    voice "voice/a32/1200060a02.opus"
    aoi "\"Y saltó hacia atrás.\""


translate english a3212_71b12dd4:



    voice "voice/a32/1200070a02.opus"
    aoi "\"Y chocó con el estante.\""


translate english a3212_733ba9d2:



    voice "voice/a32/1200080a02.opus"
    aoi "\"Y todo lo que había voló por los aires.\""


translate english a3212_60b777c8:


    "Suena lógico."


translate english a3212_efee620e:


    xy "\"Qué bueno que no entré. Se habría escapado otra vez.\""


translate english a3212_14a55eb1:



    voice "voice/a32/1200090a02.opus"
    aoi "\"Quizá así se activa la bandera de su ruta.\""


translate english a3212_b68e5508:



    voice "voice/a32/1200100a02.opus"
    aoi "\"¿Aoi es una 'rompebanderas'?\""


translate english a3212_6dbf9ffb:


    xy "\"¿Cómo voy a saberlo? ¡Si ni siquiera sé qué es una 'bandera'!\""


translate english a3212_787d4cf3:


    xy "\"¿Hmm?\""


translate english a3212_93026bf9:


    "Justo entonces, oigo un ruido detrás de mí y me volteo a mirar."


translate english a3212_9aea408a:


    xy "\"¡Uah!\""


translate english a3212_22bbf3d2:



    voice "voice/a32/1200110a02.opus"
    aoi "\"¿¡Miyuki se está derritiendo!?\""


translate english a3212_5fb5ad25:


    xy "\"Ehh... Probablemente esté bien... Probablemente...\""


translate english a3212_12e49da1:


    xy "\"Creo que solo pegó la cara contra la puerta de vidrio, eso es todo.\""


translate english a3212_063c8d61:



    voice "voice/a32/1200120a02.opus"
    aoi "\"¿Estás seguro?\""


translate english a3212_eb633109:


    xy "\"Casi...\""


translate english a3212_36ad454d:


    "En serio, parece que perteneciera al set de una película de terror de serie B. No es bonito."


translate english a3212_4ee36edc:


    "Pero más importante, hay una mirada en sus ojos que dice—"


translate english a3212_a1652a15:


    "\"¡¡¡VEN AQUÍ!!!\""


translate english a3212_c09d483c:


    "—así que mejor no la dejo esperando."


translate english a3212_a05770da:


    xy "\"En fin... em...\""


translate english a3212_5e348498:


    "\"Ya... vuelvo.\""


translate english a3212_1b0cd4e8:



    voice "voice/a32/1200140a02.opus"
    aoi "\"¡Ten cuidado!\""


translate english a3212_d95c2025:


    "Es decir, no es EN REALIDAD un monstruo de una película de terror de serie B..."


translate english a3212_85386724:


    "...¿verdad?"


translate english a3212_46681b78:


    xy "\"¿Cuál es tu problema?\""


translate english a3212_3ef11dd9:



    voice "voice/a32/1200150a01.opus"
    mx "\"¡No es justo!\""


translate english a3212_2d5b9991:



    voice "voice/a32/1200160a01.opus"
    mx "\"No puedo creer que ustedes dos se lo queden todo para sí.\""


translate english a3212_0500fa7f:


    xy "\"¿Qué se supone que hagamos? ¿Dejarte morir de alergia?\""


translate english a3212_c48e39c8:



    voice "voice/a32/1200170a01.opus"
    mx "\"Se están divirtiendo sin mí.\""


translate english a3212_a62bacfc:


    xy "\"Mira, no estamos restregándotelo ni nada...\""


translate english a3212_0e92dec6:


    "De la nada, su mano de pronto toca la mía—?!?!"


translate english a3212_45dedb96:


    "Empiezo a entrar en pánico."


translate english a3212_4295d6e1:


    "Luego Miyuki se aparta, y me doy cuenta de que su celular ahora está sobre mi palma."


translate english a3212_1a82bf0c:



    voice "voice/a32/1200180a01.opus"
    mx "\"Toma fotos.\""


translate english a3212_ae7d6e33:



    voice "voice/a32/1200190a01.opus"
    mx "\"De cerca.\""


translate english a3212_9a901eae:



    voice "voice/a32/1200200a01.opus"
    mx "\"¡Trata de buscar ángulos lindos, si puedes!\""


translate english a3212_6a1d41a4:



    voice "voice/a32/1200210a02.opus"
    aoi "\"¿Qué quería Miyuki?\""


translate english a3212_2ee47a83:


    xy "\"...Me han encomendado una misión sagrada.\""


translate english a3212_7b88147a:



    voice "voice/a32/1200220a02.opus"
    aoi "\"¿Boop boop...?\""


translate english a3212_eb0efe29:


    xy "\"Me pidió que le tomara fotos a Eru con su teléfono.\""


translate english a3212_1a6f1a44:



    voice "voice/a32/1200230a02.opus"
    aoi "\"A Miyuki sí que le encantan los gatitos.\""


translate english a3212_2d3f8315:


    xy "\"Sí.\""


translate english a3212_ab5f571b:


    "Apunto el teléfono de Miyuki hacia el gatito."


translate english a3212_3fa1ed02:


    "Ahora mismo parece estar bastante concentrado en esa leche sabrosa... Espero que no le dé miedo yo o la cámara..."


translate english a3212_98a5ee97:


    "Mientras suena el efecto de obturador, me preparo—"


translate english a3212_62ff27ab:


    "—pero no asusta a Eru en absoluto. De hecho, la cámara parece haber llamado su atención, y se inclina con curiosidad."


translate english a3212_e78adce2:


    "Resulta que me preocupé por nada."


translate english a3212_36106eb7:


    xy "\"¡Parece que aquí tenemos a la próxima supermodelo de Feline Weekly!\""


translate english a3212_78dcec50:



    voice "voice/a32/1200240a02.opus"
    aoi "\"De hecho, Eru es un gato transceptor.\""


translate english a3212_747aa077:


    xy "\"¿Ah, sí? ¿Y cómo funciona eso?\""


translate english a3212_ecf11c62:


    "Es decir, claro, el pequeño mechón de pelaje blanco en su frente SÍ se parece un poco a un rayo, pero..."


translate english a3212_2d115c91:



    voice "voice/a32/1200250a02.opus"
    aoi "\"Nuestras emociones se transmiten en ondas invisibles que Eru puede captar.\""


translate english a3212_ddec56e7:


    xy "\"Ay, por favor...\""


translate english a3212_29d14d33:


    xy "\"Espera, ¿qué demonios? ¿Dónde está Eru?\""


translate english a3212_8eb23f2c:


    xy "\"¿¡Qu...!?\""


translate english a3212_ed33c0a6:



    voice "voice/a32/1200280a02.opus"
    aoi "\"¡Boop boop!\""


translate english a3212_504d74f1:


    "Después de terminar su cena, Eru se aleja tambaleándose, sin que nadie lo incite, en dirección a la puerta de vidrio a la que Miyuki está pegada ahora mismo."


translate english a3212_8e11a8a5:


    xy "\"No puede ser...\""


translate english a3212_0142008a:


    "Ahí, Eru y Miyuki se enfrentan, con solo un cristal entre ellos."


translate english a3212_9071605b:


    "El rostro de Miyuki sigue contorsionado más allá de los rasgos reconocibles de la humanidad."


translate english a3212_c6e84120:


    "El gatito la mira hacia arriba, ladea la cabeza—"


translate english a3212_09f5f7d9:


    "—y le lame la mejilla a través del vidrio."


translate english a3212_5b4b3473:


    xy "\"¡¡¡Ay, dios!!!\""


translate english a3212_c40b7b02:


    "This \"transceiver cat\"es la bomba!"


translate english a3212_e463222d:


    "¡Vaya, es increíblemente listo!"


translate english a3212_7ba28481:



    voice "voice/a32/1200300a02.opus"
    aoi "\"¿Ya le están dando alergias a Miyuki a través del vidrio?\""


translate english a3212_3f890dbc:


    xy "\"Jaja, buena esa. No, creo que esas son solo lágrimas de felicidad...\""


translate english a3212_2b08b962:



    voice "voice/a32/1200310a02.opus"
    aoi "\"¡Lágrimas de felicidad! ¡Aoi sabe todo sobre eso!\""


translate english a3212_bd470f9d:


    "Me alegro por ti, Miyuki..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
