

translate english a3212_7803c940:


    xy "\"Oh yeah, so was Yuutarou working the register?\""


translate english a3212_f5d9450d:



    voice "voice/a32/1200010a02.opus"
    aoi "\"Nope.\""


translate english a3212_03931ba2:



    voice "voice/a32/1200020a02.opus"
    aoi "\"But that klutz was.\""


translate english a3212_37bfde72:


    xy "\"What klutz?\""


translate english a3212_6fe58d69:



    voice "voice/a32/1200030a02.opus"
    aoi "\"The one from the theatre club.\""


translate english a3212_c9832836:


    "Ah, cierto... La chica que grita y sale corriendo cada vez que me ve..."


translate english a3212_65626964:


    xy "\"That chick's practically afraid of her own shadow. How can she hold down a customer service job?\""


translate english a3212_407ba591:



    voice "voice/a32/1200040a02.opus"
    aoi "\"Aoi said hi.\""


translate english a3212_0fa2c162:



    voice "voice/a32/1200050a02.opus"
    aoi "\"She got scared.\""


translate english a3212_40da8044:



    voice "voice/a32/1200060a02.opus"
    aoi "\"And jumped backwards.\""


translate english a3212_71b12dd4:



    voice "voice/a32/1200070a02.opus"
    aoi "\"And hit the shelf.\""


translate english a3212_733ba9d2:



    voice "voice/a32/1200080a02.opus"
    aoi "\"And all the stuff on it went flying.\""


translate english a3212_60b777c8:


    "Suena lógico."


translate english a3212_efee620e:


    xy "\"Good thing I didn't go in there. She would have run off again.\""


translate english a3212_14a55eb1:



    voice "voice/a32/1200090a02.opus"
    aoi "\"Maybe that's how you trigger her route flag.\""


translate english a3212_b68e5508:



    voice "voice/a32/1200100a02.opus"
    aoi "\"Is Aoi a 'flag crusher'?\""


translate english a3212_6dbf9ffb:


    xy "\"How should I know? I don't even know what a 'flag' is!\""


translate english a3212_787d4cf3:


    xy "\"Hmm?\""


translate english a3212_93026bf9:


    "Justo entonces, oigo un ruido detrás de mí y me volteo a mirar."


translate english a3212_9aea408a:


    xy "\"Whoa!\""


translate english a3212_22bbf3d2:



    voice "voice/a32/1200110a02.opus"
    aoi "\"Is Miyuki melting?!\""


translate english a3212_5fb5ad25:


    xy "\"Uhh... She's probably fine... Probably...\""


translate english a3212_12e49da1:


    xy "\"I think she's just pressed her face right up against the glass door, that's all.\""


translate english a3212_063c8d61:



    voice "voice/a32/1200120a02.opus"
    aoi "\"You sure?\""


translate english a3212_eb633109:


    xy "\"Mostly...\""


translate english a3212_36ad454d:


    "En serio, parece que perteneciera al set de una película de terror de serie B. No es bonito."


translate english a3212_4ee36edc:


    "Pero más importante, hay una mirada en sus ojos que dice—"


translate english a3212_a1652a15:


    "\"GET OVER HERE!!!\""


translate english a3212_c09d483c:


    "—así que mejor no la dejo esperando."


translate english a3212_a05770da:


    xy "\"Anyway... uh...\""


translate english a3212_5e348498:


    "\"I'll... be right back.\""


translate english a3212_1b0cd4e8:



    voice "voice/a32/1200140a02.opus"
    aoi "\"Be careful!\""


translate english a3212_d95c2025:


    "Es decir, no es EN REALIDAD un monstruo de una película de terror de serie B..."


translate english a3212_85386724:


    "...¿verdad?"


translate english a3212_46681b78:


    xy "\"What's your problem?\""


translate english a3212_3ef11dd9:



    voice "voice/a32/1200150a01.opus"
    mx "\"It's not fair!\""


translate english a3212_2d5b9991:



    voice "voice/a32/1200160a01.opus"
    mx "\"I can't believe you two get to hog him all to yourself.\""


translate english a3212_0500fa7f:


    xy "\"What else are we supposed to do? Let you die of allergies?\""


translate english a3212_c48e39c8:



    voice "voice/a32/1200170a01.opus"
    mx "\"You're all having fun without me.\""


translate english a3212_a62bacfc:


    xy "\"Look, we're not trying to rub it in or anyth—\""


translate english a3212_0e92dec6:


    "De la nada, su mano de pronto toca la mía—?!?!"


translate english a3212_45dedb96:


    "Empiezo a entrar en pánico."


translate english a3212_4295d6e1:


    "Luego Miyuki se aparta, y me doy cuenta de que su celular ahora está sobre mi palma."


translate english a3212_1a82bf0c:



    voice "voice/a32/1200180a01.opus"
    mx "\"Take pics.\""


translate english a3212_ae7d6e33:



    voice "voice/a32/1200190a01.opus"
    mx "\"Close-up shots.\""


translate english a3212_9a901eae:



    voice "voice/a32/1200200a01.opus"
    mx "\"Try to get some cute angles, if possible!\""


translate english a3212_6a1d41a4:



    voice "voice/a32/1200210a02.opus"
    aoi "\"What did Miyuki want?\""


translate english a3212_2ee47a83:


    xy "\"...I have been tasked with a holy mission.\""


translate english a3212_7b88147a:



    voice "voice/a32/1200220a02.opus"
    aoi "\"Boop boop...?\""


translate english a3212_eb0efe29:


    xy "\"She asked me to take pics of Eru on her phone.\""


translate english a3212_1a6f1a44:



    voice "voice/a32/1200230a02.opus"
    aoi "\"Miyuki sure loves kitty cats.\""


translate english a3212_2d3f8315:


    xy "\"Yep.\""


translate english a3212_ab5f571b:


    "Apunto el teléfono de Miyuki hacia el gatito."


translate english a3212_3fa1ed02:


    "Ahora mismo parece estar bastante concentrado en esa leche sabrosa... Espero que no le dé miedo yo o la cámara..."


translate english a3212_98a5ee97:


    "Mientras suena el efecto de obturador, me preparo—"


translate english a3212_62ff27ab:


    "—pero no asusta a Eru en absoluto. De hecho, la cámara parece haber llamado su atención, y se inclina con curiosidad."


translate english a3212_e78adce2:


    "Resulta que me preocupé por nada."


translate english a3212_36106eb7:


    xy "\"Looks like we got ourselves the next top model for Feline Weekly over here!\""


translate english a3212_78dcec50:



    voice "voice/a32/1200240a02.opus"
    aoi "\"Actually, Eru is a transceiver cat.\""


translate english a3212_747aa077:


    xy "\"Oh yeah? And how does that work?\""


translate english a3212_ecf11c62:


    "Es decir, claro, el pequeño mechón de pelaje blanco en su frente SÍ se parece un poco a un rayo, pero..."


translate english a3212_2d115c91:



    voice "voice/a32/1200250a02.opus"
    aoi "\"Our emotions transmit on invisible airwaves that Eru can pick up.\""


translate english a3212_ddec56e7:


    xy "\"Give me a break...\""


translate english a3212_29d14d33:


    xy "\"Wait, what the? Where's Eru?\""


translate english a3212_8eb23f2c:


    xy "\"Wha...?!\""


translate english a3212_ed33c0a6:



    voice "voice/a32/1200280a02.opus"
    aoi "\"Boop boop!\""


translate english a3212_504d74f1:


    "Después de terminar su cena, Eru se aleja tambaleándose, sin que nadie lo incite, en dirección a la puerta de vidrio a la que Miyuki está pegada ahora mismo."


translate english a3212_8e11a8a5:


    xy "\"No way...\""


translate english a3212_0142008a:


    "Ahí, Eru y Miyuki se enfrentan, con solo un cristal entre ellos."


translate english a3212_9071605b:


    "El rostro de Miyuki sigue contorsionado más allá de los rasgos reconocibles de la humanidad."


translate english a3212_c6e84120:


    "El gatito la mira hacia arriba, ladea la cabeza—"


translate english a3212_09f5f7d9:


    "—y le lame la mejilla a través del vidrio."


translate english a3212_5b4b3473:


    xy "\"Oh my god!!!\""


translate english a3212_c40b7b02:


    "This \"transceiver cat\"es la bomba!"


translate english a3212_e463222d:


    "¡Vaya, es increíblemente listo!"


translate english a3212_7ba28481:



    voice "voice/a32/1200300a02.opus"
    aoi "\"Are Miyuki's allergies acting up through the glass now?\""


translate english a3212_3f890dbc:


    xy "\"Haha, good one. Nah, those are just happy tears, methinks...\""


translate english a3212_2b08b962:



    voice "voice/a32/1200310a02.opus"
    aoi "\"Happy tears! Aoi knows all about that!\""


translate english a3212_bd470f9d:


    "Me alegro por ti, Miyuki..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
