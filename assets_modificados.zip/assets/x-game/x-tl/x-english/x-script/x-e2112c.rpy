

translate english e2112c_7c306c1b:



    voice "voice/e21/12c00010a01.opus"
    mx "\"Don't be shy, now.\""


translate english e2112c_bee4501d:



    voice "voice/e21/12c00020a01.opus"
    mx "\"Not like you have a choice anyway.\""


translate english e2112c_386e633b:


    "Intento retirar mi mano, pero ella la agarra—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
