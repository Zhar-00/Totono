

translate english e2112c_7c306c1b:



    voice "voice/e21/12c00010a01.opus"
    mx "\"No te pongas tímida.\""


translate english e2112c_bee4501d:



    voice "voice/e21/12c00020a01.opus"
    mx "\"De todos modos, no tienes opción.\""


translate english e2112c_386e633b:


    "Intento retirar mi mano, pero ella la agarra—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
