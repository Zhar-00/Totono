

translate english d3165_5d7d9980:


    xy "\"¡La puerta peatonal frente a la escuela!\""


translate english d3165_ba4ea872:



    voice "voice/d31/6500010a01.opus"
    mx "\"¿La qué...?\""


translate english d3165_891f445f:



    voice "voice/d31/6500020a01.opus"
    mx "\"Espera... ¡¿Shinichi?!\""


translate english d3165_38877f88:


    "Antes de darme cuenta, estoy corriendo a toda velocidad."


translate english d3165_e8ef0552:


    "Pasé junto a las rejas de la escuela antes, de camino a revisar la caja de cartón."


translate english d3165_1f104589:


    "Normalmente sería un detalle diminuto y olvidable—"


translate english d3165_fc4d33d0:


    "Pero ahora mismo, estoy extrañamente seguro."


translate english d3165_e4205071:


    "Recuerdo que estaba abierta—"


translate english d3165_fdd3d6c8:


    xy "\"¡¿Está cerrada?!\""


translate english d3165_37395b4d:


    "¿Estoy recordando mal?"


translate english d3165_3417516e:


    "No, no puedo estar..."


translate english d3165_65593848:



    voice "voice/d31/6500030a01.opus"
    mx "\"Mira, Shinichi...\""


translate english d3165_5572d52b:


    "Miyuki me alcanza, completamente sin aliento."


translate english d3165_377d400d:



    voice "voice/d31/6500040a01.opus"
    mx "Estaban cerradas.\""


translate english d3165_c988f0a2:


    xy "\"¡Pero—!\""


translate english d3165_20ee1ac1:



    voice "voice/d31/6500050a01.opus"
    mx "\"No digo que te acuerdes mal.\""


translate english d3165_549e6334:



    voice "voice/d31/6500060a01.opus"
    mx "\"Quizá... Oh, ya sé. Quizá estaban abiertas la última vez que las viste, pero para cuando yo llegué, ya estaban cerradas.\""


translate english d3165_8d5f9fe4:



    voice "voice/d31/6500070a01.opus"
    mx "\"Quien haya estado en el recinto escolar antes, debe haberse ido ya.\""


translate english d3165_3ead5c20:



    voice "voice/d31/6500080a01.opus"
    mx "\"Eso tendría sentido, ¿no?\""


translate english d3165_0accd139:


    xy "\"......\""


translate english d3165_669b963c:


    "No puedo fingir que no veo la lógica ahí."


translate english d3165_39e7c143:


    "Pero..."


translate english d3165_18f26559:



    voice "voice/d31/6500090a01.opus"
    mx "\"¿Qué? ¿Todavía no te convences?\""


translate english d3165_5c81c925:



    voice "voice/d31/6500100a01.opus"
    mx "\"¿Quieres colarte, entonces?\""


translate english d3165_df926bb3:


    "Miro hacia arriba, a la alta reja que se alza sobre nosotros."


translate english d3165_f475accc:


    "¿Colarme en el recinto escolar de noche?"


translate english d3165_90f38906:


    "Ni yo tengo suficiente confianza para ESO."


translate english d3165_0e22675c:


    xy "\"Perdón por reaccionar tan exageradamente.\""


translate english d3165_5217ccce:



    voice "voice/d31/6500110a01.opus"
    mx "\"No, está bien.\""


translate english d3165_1adb4488:



    voice "voice/d31/6500120a01.opus"
    mx "\"Ahora, vámonos a casa.\""


translate english d3165_a37d76a3:


    "Nos alejamos en silencio de las rejas."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
