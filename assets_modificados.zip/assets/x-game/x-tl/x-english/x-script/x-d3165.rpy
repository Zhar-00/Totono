

translate english d3165_5d7d9980:


    xy "\"The pedestrian gate in front of the school!\""


translate english d3165_ba4ea872:



    voice "voice/d31/6500010a01.opus"
    mx "\"The what...?\""


translate english d3165_891f445f:



    voice "voice/d31/6500020a01.opus"
    mx "\"Wait... Shinichi?!\""


translate english d3165_38877f88:


    "Antes de darme cuenta, estoy corriendo a toda velocidad."


translate english d3165_e8ef0552:


    "Pasé junto a las rejas de la escuela antes, de camino a revisar la caja de cartón."


translate english d3165_1f104589:


    "Normalmente sería un detalle diminuto y olvidable—"


translate english d3165_fc4d33d0:


    "Pero ahora mismo, estoy extrañamente seguro."


translate english d3165_e4205071:


    "Recuerdo que estaba abierta—"


translate english d3165_fdd3d6c8:


    xy "\"It's closed?!\""


translate english d3165_37395b4d:


    "¿Estoy recordando mal?"


translate english d3165_3417516e:


    "No, no puedo estar..."


translate english d3165_65593848:



    voice "voice/d31/6500030a01.opus"
    mx "\"Look, Shinichi...\""


translate english d3165_5572d52b:


    "Miyuki me alcanza, completamente sin aliento."


translate english d3165_377d400d:



    voice "voice/d31/6500040a01.opus"
    mx "Estaban cerradas.\""


translate english d3165_c988f0a2:


    xy "\"But—!\""


translate english d3165_20ee1ac1:



    voice "voice/d31/6500050a01.opus"
    mx "\"I'm not saying you remembered wrong.\""


translate english d3165_549e6334:



    voice "voice/d31/6500060a01.opus"
    mx "\"Maybe... Oh, I know. Maybe they were open when you last saw them, but by the time I got there, they were closed.\""


translate english d3165_8d5f9fe4:



    voice "voice/d31/6500070a01.opus"
    mx "\"Whoever was on school grounds earlier, they must have left.\""


translate english d3165_3ead5c20:



    voice "voice/d31/6500080a01.opus"
    mx "\"That would make sense, wouldn't it?\""


translate english d3165_0accd139:


    xy "\"......\""


translate english d3165_669b963c:


    "No puedo fingir que no veo la lógica ahí."


translate english d3165_39e7c143:


    "Pero..."


translate english d3165_18f26559:



    voice "voice/d31/6500090a01.opus"
    mx "\"What? You're still not convinced?\""


translate english d3165_5c81c925:



    voice "voice/d31/6500100a01.opus"
    mx "\"You wanna trespass, then?\""


translate english d3165_df926bb3:


    "Miro hacia arriba, a la alta reja que se alza sobre nosotros."


translate english d3165_f475accc:


    "¿Colarme en el recinto escolar de noche?"


translate english d3165_90f38906:


    "Ni yo tengo suficiente confianza para ESO."


translate english d3165_0e22675c:


    xy "\"Sorry for overreacting.\""


translate english d3165_5217ccce:



    voice "voice/d31/6500110a01.opus"
    mx "\"No, it's fine.\""


translate english d3165_1adb4488:



    voice "voice/d31/6500120a01.opus"
    mx "\"Now, let's go home.\""


translate english d3165_a37d76a3:


    "Nos alejamos en silencio de las rejas."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
