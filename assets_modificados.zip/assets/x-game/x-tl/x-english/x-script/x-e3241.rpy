

translate english e3241_249d18bb:



    voice "voice/e32/4100010a01.opus"
    mx "Oye, TÚ."


translate english e3241_c0e0c716:



    voice "voice/e32/4100020a01.opus"
    mx "¿Estás triste?"


translate english e3241_2e74a565:



    voice "voice/e32/4100030a01.opus"
    mx "¿Enojado?"


translate english e3241_be3f3058:



    voice "voice/e32/4100040a01.opus"
    mx "¿O incluso... a punto de dejar el juego hecho una furia?"


translate english e3241_8a2a505d:



    voice "voice/e32/4100050a01.opus"
    mx "Esa escena de sexo de hace un momento era un fragmento de una parte de la ruta de Aoi que nunca viste."


translate english e3241_f30dcc85:



    voice "voice/e32/4100060a01.opus"
    mx "Es la verdad de lo que ocurrió en ese departamento."


translate english e3241_02935c1b:



    voice "voice/e32/4100070a01.opus"
    mx "No creías de verdad que Aoi decía la verdad cuando dijo que se detuvieron después de abrir el condón, ¿verdad?"


translate english strings:


    old "Аой трахалась с Рюджиро"
    new "Aoi se folló a Ryuujirou"


    old "Она никогда не трахалась с ним"
    new "Nunca se lo folló"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
