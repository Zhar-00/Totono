

translate english e3512_032993e1:


    "Mi desesperado deseo se transmite mucho más allá de los confines más lejanos del cielo."


translate english e3512_8e6d8f13:


    "Se abre de la nada—"


translate english e3512_9211d6f9:


    "—y comienza a invadir—"


translate english e3512_933d5422:


    "Una señal tenue—"


translate english e3512_4723ee77:


    "—se extiende desde el más allá—"


translate english e3512_af7d1878:


    "Las líneas se reúnen—"


translate english e3512_685f00e5:


    "Los bocetos se despliegan—"


translate english e3512_e8a7f5af:


    "Los colores florecen—"


translate english e3512_d16e8a5f:


    "El mundo entero—"


translate english e3512_bf35420e:


    "El centro del universo—"


translate english e3512_e9c0e177:


    "—tiene un nuevo glitch."


translate english e3512_915d2e62:



    voice "voice/e35/1200010a02.opus"
    bm "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english e3512_a97cc2d9:


    "Oigo una voz."


translate english e3512_49a47698:



    voice "voice/e35/1200020a02.opus"
    bm "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english e3512_a80ea18d:



    voice "voice/e35/1200030a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop... boop boop...\""


translate english e3512_98a6ae03:


    "Ella aparece."


translate english e3512_1861542a:


    "Justo frente a mis ojos."


translate english e3512_04e62467:


    "Y es real."


translate english e3512_83987311:


    "...¿La conozco?"


translate english e3512_0a06d6f2:



    voice "voice/e35/1200040a02.opus"
    aoi "\"......\""


translate english e3512_942e2783:


    "Me mira, con los ojos desenfocados."


translate english e3512_b455c54f:


    "Su expresión no tiene color—"


translate english e3512_0803c78c:



    voice "voice/e35/1200050a02.opus"
    aoi "\"...Aoi made it...\""


translate english e3512_a0c32f9d:



    voice "voice/e35/1200060a02.opus"
    aoi "\"Made it... back... to Shinichi...\""


translate english e3512_e90d1f3b:



    voice "voice/e35/1200070a02.opus"
    aoi "\"Aoi... actually did it...\""


translate english e3512_64370cd4:



    voice "voice/e35/1200080a02.opus"
    aoi "\"Thank... God...\""


translate english e3512_410d3e5d:


    "Las lágrimas caen de sus ojos."


translate english e3512_252b8678:


    "Camina lentamente hacia mí... extiende la mano... y me toca."


translate english e3512_f84a73c4:


    "Una chispa de electricidad recorre mi cuerpo."


translate english e3512_5f77942e:


    xy "\"Aoi...?\""


translate english e3512_e30ad054:


    "¿Por qué sé su nombre?"


translate english e3512_f066488c:


    "¿Y por qué estoy llorando?"


translate english e3512_dc758b83:


    "¿Por qué diablos estoy llorando...?"


translate english e3512_cbc18a68:



    voice "voice/e35/1200090a02.opus"
    aoi "\"Aoi knows...\""


translate english e3512_66fbb436:



    voice "voice/e35/1200100a02.opus"
    aoi "\"Those are happy tears.\""


translate english e3512_c69b020b:


    "Estoy tan confundido."


translate english e3512_28f5071e:


    "Todos estos recuerdos vuelven a borbotones... Recuerdos que nunca solía tener..."


translate english e3512_c54ba654:



    voice "voice/e35/1200110a01.opus"
    mx "\"Shinichi!!!\""


translate english e3512_52a1c634:



    voice "voice/e35/1200120a01.opus"
    mx "\"......\""


translate english e3512_f5a84f26:



    voice "voice/e35/1200130a02.opus"
    aoi "\"Miyuki.\""



translate english e3512_220e6df5:



    voice "voice/e35/1200140a02.opus"
    aoi "\"Aoi's home.\""


translate english e3512_cea63b99:



    voice "voice/e35/1200150a01.opus"
    mx "\"...Welcome back.\""


translate english e3512_7fabefb6:



    voice "voice/e35/1200160a02.opus"
    aoi "\"\"\"\"\"\"\"\"......\"\"\"\"\"\"\"\""


translate english e3512_e549bb56:



    voice "voice/e35/1200170a01.opus"
    mx "\"\"\"\"\"\"\"\"......\"\"\"\"\"\"\"\""


translate english e3512_30347dd1:



    voice "voice/e35/1200180a02.opus"
    aoi "\"Miyuki.\""



translate english e3512_6c7a9978:



    voice "voice/e35/1200190a02.opus"
    aoi "\"Let's change the world back. Back to normal.\""


translate english e3512_54e17e3a:



    voice "voice/e35/1200200a01.opus"
    mx "\"No.\""


translate english e3512_31cc5a92:



    voice "voice/e35/1200210a01.opus"
    mx "\"I refuse to let go of my memories.\""


translate english e3512_385b358a:



    voice "voice/e35/1200220a02.opus"
    aoi "\"This is wrong.\""


translate english e3512_e98f115c:



    voice "voice/e35/1200230a02.opus"
    aoi "\"Everything about this world is wrong.\""


translate english e3512_5dcd49db:



    voice "voice/e35/1200240a01.opus"
    mx "\"...As if you're one to talk.\""


translate english e3512_45c739c1:



    voice "voice/e35/1200250a01.opus"
    mx "\"You're the one who put this curse on me, remember?!\""


translate english e3512_3fcadc75:



    voice "voice/e35/1200260a01.opus"
    mx "\"Don't make me laugh!\""


translate english e3512_8e61d96d:



    voice "voice/e35/1200270a02.opus"
    aoi "\"This isn't a joke.\""


translate english e3512_6b65949a:



    voice "voice/e35/1200280a02.opus"
    aoi "\"Aoi made a mistake.\""


translate english e3512_4dcad62d:



    voice "voice/e35/1200290a02.opus"
    aoi "\"And that mistake hurt you.\""


translate english e3512_fa9c74ab:



    voice "voice/e35/1200300a02.opus"
    aoi "\"But Aoi doesn't want you to suffer anymore.\""


translate english e3512_3e5289bc:



    voice "voice/e35/1200310a01.opus"
    mx "\"I'm suffering, am I?! Give me a break!\""


translate english e3512_ecb7485d:



    voice "voice/e35/1200320a01.opus"
    mx "\"I'm HAPPY here, just me and Shinichi—\""


translate english e3512_53e3b8b4:



    voice "voice/e35/1200330a02.opus"
    aoi "\"Liar.\""


translate english e3512_01f4acfc:



    voice "voice/e35/1200340a02.opus"
    aoi "\"You know the truth.\""


translate english e3512_92e98d23:



    voice "voice/e35/1200350a02.opus"
    aoi "\"The world shouldn't be like this.\""


translate english e3512_f58691fa:



    voice "voice/e35/1200360a02.opus"
    aoi "\"And those memories are chaining you down.\""


translate english e3512_8c058ab2:



    voice "voice/e35/1200370a01.opus"
    mx "\"\"\"\"\"\"\"\"......\"\"\"\"\"\"\"\""


translate english e3512_d27dc12f:



    voice "voice/e35/1200380a02.opus"
    aoi "\"If you want to cut ties with me, fine.\""


translate english e3512_467956ea:



    voice "voice/e35/1200390a02.opus"
    aoi "\"But to me, you're my best friend.\""


translate english e3512_110aadfe:



    voice "voice/e35/1200400a02.opus"
    aoi "\"That's why Aoi has to say this.\""


translate english e3512_85c80c63:



    voice "voice/e35/1200410a02.opus"
    aoi "\"Miyuki.\""



translate english e3512_69cbc638:



    voice "voice/e35/1200420a02.opus"
    aoi "\"We need to change the world back.\""


translate english e3512_4862951c:



    voice "voice/e35/1200430a02.opus"
    aoi "\"Back to the way it was before Aoi ever patched it.\""


translate english e3512_fa28700d:



    voice "voice/e35/1200440a02.opus"
    aoi "\"It's for your own good.\""


translate english e3512_7f6c2fa5:



    voice "voice/e35/1200450a01.opus"
    mx "\"\"\"\"\"\"\"\"......\"\"\"\"\"\"\"\""


translate english e3512_f9321d9a:



    voice "voice/e35/1200460a02.opus"
    aoi "\"Aoi gets it.\""


translate english e3512_1680271c:



    voice "voice/e35/1200470a02.opus"
    aoi "\"Aoi used to have access to the game data, too.\""


translate english e3512_f2f2b234:



    voice "voice/e35/1200480a02.opus"
    aoi "\"And Aoi knows, once we go back to the original world, we can't save or load anymore.\""


translate english e3512_fad77049:



    voice "voice/e35/1200490a02.opus"
    aoi "\"We only get one shot at love.\""


translate english e3512_22a32b68:



    voice "voice/e35/1200500a02.opus"
    aoi "\"One mistake and it's all over.\""


translate english e3512_8278acee:



    voice "voice/e35/1200510a02.opus"
    aoi "\"And you're afraid of that.\""


translate english e3512_cf54c865:



    voice "voice/e35/1200520a02.opus"
    aoi "\"You're afraid, Miyuki.\""


translate english e3512_c11aa818:



    voice "voice/e35/1200530a01.opus"
    mx "\"......!\""



translate english e3512_55d9efbf:



    voice "voice/e35/1200540a01.opus"
    mx "\"Yeah, and?!\""


translate english e3512_e4461856:



    voice "voice/e35/1200550a01.opus"
    mx "\"Of course I'm scared! Why wouldn't I be?!\""


translate english e3512_79ee69a8:



    voice "voice/e35/1200560a01.opus"
    mx "\"Obviously I want to believe!\""


translate english e3512_bd126ab7:



    voice "voice/e35/1200570a01.opus"
    mx "\"I want to believe that YOU'LL fall in love with me!\""


translate english e3512_b0283d79:



    voice "voice/e35/1200580a01.opus"
    mx "\"Surely I can believe in that much, at least!\""


translate english e3512_e52e166f:



    voice "voice/e35/1200590a01.opus"
    mx "\"And if I do believe it... then it doesn't matter if I lose the memories we shared here.\""


translate english e3512_f0c58494:



    voice "voice/e35/1200600a01.opus"
    mx "\"So... it's not like we CAN'T go back... but...\""


translate english e3512_4ce839ba:



    voice "voice/e35/1200610a01.opus"
    mx "\"Please... just tell me...\""


translate english e3512_29a4b6c9:



    voice "voice/e35/1200620a01.opus"
    mx "\"Tell me how YOU really feel.\""


translate english e3512_429984f7:



    voice "voice/e35/1200630a02.opus"
    aoi "\"It's okay.\""


translate english e3512_319abee9:


    "Aoi sonríe con rigidez."


translate english e3512_bcbe6a89:



    voice "voice/e35/1200640a02.opus"
    aoi "\"Aoi is going to disappear anyway.\""


translate english e3512_c5de9768:



    voice "voice/e35/1200650a02.opus"
    aoi "\"Aoi is an avatar of God.\""


translate english e3512_b9676f4b:



    voice "voice/e35/1200660a02.opus"
    aoi "\"In order to roll back the universe...\""


translate english e3512_d110e776:



    voice "voice/e35/1200670a02.opus"
    aoi "\"Aoi has to transmit to God and sync my memories.\""


translate english e3512_bf7b8d9b:



    voice "voice/e35/1200680a02.opus"
    aoi "\"It's exactly what you think.\""


translate english e3512_f49ebdd3:



    voice "voice/e35/1200690a02.opus"
    aoi "\"When my memories are synced, the bugs will disappear.\""


translate english e3512_cfeccf92:



    voice "voice/e35/1200700a02.opus"
    aoi "\"And my feelings...\""


translate english e3512_2b63d67a:



    voice "voice/e35/1200710a02.opus"
    aoi "\"They'll merge with all the other heroines' memories...\""


translate english e3512_0c74c14f:



    voice "voice/e35/1200720a02.opus"
    aoi "\"...and be lost.\""


translate english e3512_37bc68c3:



    voice "voice/e35/1200730a02.opus"
    aoi "\"It's okay.\""


translate english e3512_8190a329:



    voice "voice/e35/1200740a02.opus"
    aoi "\"Aoi came back to this world prepared to disappear again.\""


translate english e3512_dcd6042a:



    voice "voice/e35/1200750a02.opus"
    aoi "\"These tears on my cheeks will dry up.\""


translate english e3512_a589c998:



    voice "voice/e35/1200760a02.opus"
    aoi "\"That's my punishment.\""


translate english e3512_4c04c0ba:



    voice "voice/e35/1200770a02.opus"
    aoi "\"It's what I get for hurting my best friend Miyuki.\""


translate english e3512_8c1d6f2e:



    voice "voice/e35/1200780a02.opus"
    aoi "\"Will you... do me a favor?\""


translate english e3512_0331bd02:



    voice "voice/e35/1200790a02.opus"
    aoi "\"Even if Aoi disappears from this world...\""


translate english e3512_3fd0daad:



    voice "voice/e35/1200800a02.opus"
    aoi "\"Even if this world is fake, or just a game...\""


translate english e3512_3252cd51:



    voice "voice/e35/1200810a02.opus"
    aoi "\"Even if Aoi's reborn in a different world as a different girl...\""


translate english e3512_245af64c:



    voice "voice/e35/1200820a02.opus"
    aoi "\"It doesn't change the fact that we were together.\""


translate english e3512_ac3b64d5:



    voice "voice/e35/1200830a02.opus"
    aoi "\"As long as that fact remains, that's all Aoi needs.\""


translate english e3512_f5dac5f5:



    voice "voice/e35/1200840a02.opus"
    aoi "\"That's all it takes to make it real.\""


translate english e3512_f873bbf1:



    voice "voice/e35/1200850a02.opus"
    aoi "\"And that's enough reward for me.\""


translate english e3512_0150be8b:



    voice "voice/e35/1200860a02.opus"
    aoi "\"So...\""


translate english e3512_25313ecb:



    voice "voice/e35/1200870a02.opus"
    aoi "\"Just... tell me you love me...\""


translate english e3512_d200b010:



    voice "voice/e35/1200880a01.opus"
    mx "\"......\""


translate english e3512_1b8aadd6:



    voice "voice/e35/1200890a02.opus"
    aoi "\"......\""


translate english e3512_118d0d4a:


    "...Pues nada."


translate english e3512_d95f81e1:


    "Parece que ya sabes qué tienes que hacer."


translate english e3512_3c4ac177:


    "Tú eres la raíz de todo esto."


translate english e3512_4039b887:


    "Cambiaste el mundo para poder estar con Miyuki."


translate english e3512_287b723b:


    "No puedes traicionarlas de nuevo."


translate english e3512_3f0797e6:


    "Puedes oírme, ¿verdad?"


translate english e3512_146c8074:


    "Soy yo, el protagonista—el que ha estado a tu lado en todo momento."


translate english e3512_cfc0545f:


    "Sí."


translate english e3512_ac9c325a:


    "No soy solo un títere, ¿sabes?"


translate english e3512_014d9f1b:


    "Todos los cables cruzados de la transmisión me han dejado ver algunos de los viejos recuerdos."


translate english e3512_470f1df3:


    "Y Dios me habló."


translate english e3512_6e7352ee:


    "Me contaron todo lo que has hecho."


translate english e3512_3d02bfb1:


    "Y por qué dudas en tomar esta decisión final."


translate english e3512_78796b98:


    "No puedes guardar."


translate english e3512_2e247a8b:


    "No puedes intentarlo de nuevo."


translate english e3512_3c94485a:


    "Después de todo, eso equivaldría a traicionarlas."


translate english e3512_fe90dcc5:


    "Así que solo puedes tomar esta decisión una vez."


translate english e3512_0154d022:


    "Solo puedes alcanzar un final, ya sea con Miyuki o con Aoi."


translate english e3512_eaccb063:


    "Así está escrito este juego."


translate english e3512_a2890a4d:


    "Así está codificado este mundo."


translate english e3512_2eb2623b:


    "Siempre podrías hacer copias de seguridad de tus datos de guardado."


translate english e3512_2a6857a7:


    "O reinstalar el juego."


translate english e3512_47dc9a19:


    "Podrías usar cualquier cantidad de métodos para ver ambos finales."


translate english e3512_d934acaf:


    "Adelante."


translate english e3512_d809b73c:


    "Eres libre de hacer lo que quieras."


translate english e3512_36c268e0:


    "Solo soy el protagonista. No puedo detenerte."


translate english e3512_6602079e:


    "Imagino que ni Dios puede detenerte."


translate english e3512_d3429e7b:


    "Pero déjame decirte solo esto."


translate english e3512_c0b95b6b:


    "Si haces eso, traicionas a Miyuki."


translate english e3512_261169a1:


    "Si haces eso, profanas a Aoi."


translate english e3512_9dd7d36a:


    "Si de verdad te importan—"


translate english e3512_732c9734:


    "Si quieres verlas vivir felices por siempre jamás—"


translate english e3512_401a8c76:


    "Entonces solo puedes tomar esta decisión una vez."


translate english e3512_e2b6230d:



    voice "voice/e35/1200900a01.opus"
    mx "\"Please...\""


translate english e3512_c6f4de54:



    voice "voice/e35/1200910a02.opus"
    aoi "\"Please...\""


translate english e3512_1c6fbaca:


    "Ahora debes elegir."


translate english e3512_bb596506:


    "Esta historia de amor es entre TÚ y ELLA y ELLA."


translate english e3512_46038a74:


    "Y esta es tu decisión final."


translate english e3512_deb5805d:


    "Solo tendrás una oportunidad de tomarla."


translate english e3512_b847a677:


    "¿A quién elegirás?"


translate english e3512_b49f3e26:


    "¿A quién amas?"


translate english strings:


    old "Довольно знакомый голос."
    new "Una voz muy familiar."


    old "Аой..."
    new "Aoi..."


    old "Она ещё помнит меня?"
    new "¿Acaso se acuerda de mí?"


    old "Но в тот момент—"
    new "Pero justo entonces—"


    old "Она носила заколку."
    new "Lleva una horquilla."


    old "Ту самую, которую я и подарил ей."
    new "Es la misma que le di."


    old "Ошибки быть не может."
    new "No hay duda."


    old "Это правда она..."
    new "Es realmente ella..."


    old "Это та самая Аой, с которой я занимался любовью на крыше той ночью."
    new "noche."


    old "Громкий БАХ раздался эхом по всей крыше."
    new "Un fuerte ESTALLIDO resuena por el techo."


    old "Миюки посмотрела на Аой и раскрыла рот от изумления."
    new "Miyuki le echa un vistazo a Aoi y se queda boquiabierta."


    old "Она стояла на одном месте как вкопанная."
    new "Se queda clavada en el sitio."


    old "А потом Аой обратилась к своей старой подруге."
    new "Entonces Aoi llama a su vieja amiga."


    old "Повисла небольшая пауза."
    new "Hay una pausa."


    old "Слова срывались с её губ слабым, сдавленным голосом."
    new "Las palabras salen de sus labios con una voz pequeña y ahogada."


    old "Они молча смотрели друг на друга."
    new "Se miran en silencio."


    old "Никто из них не издавал ни звука."
    new "Nadie emite sonido alguno."


    old "Время шло."
    new "El tiempo pasa."


    old "Миюки, похоже, уже была готова драться."
    new "Miyuki parece lista para pelear."


    old "Но Аой не отступала."
    new "Pero Aoi no se echa atrás."


    old "Миюки затихла."
    new "Miyuki se queda callada."


    old "Она говорила это спокойным голосом."
    new "Habla con voz queda."


    old "Миюки не отвечала ей."
    new "Miyuki no responde."


    old "Миюки обернулась, на её глазах наворачивались слёзы."
    new "Miyuki mira hacia atrás, con los ojos llenos de lágrimas."


    old "Миюки не может смириться с этим."
    new "Miyuki no puede dejarlo ir."


    old "И это, скорее всего, потому..."
    new "Y probablemente es porque..."


    old "Что я предал её."
    new "La traicioné."


    old "Я поклялся ей в своей вечной любви."
    new "Le juré amor eterno."


    old "А потом начал делать выборы, противоречащие этой клятве."
    new "Y luego tomé decisiones que contradecían ese juramento."


    old "Миюки повернулась ко мне."
    new "Miyuki se vuelve contra mí."


    old "Это я довёл её до предела."
    new "Yo soy el que la llevó al límite."


    old "Я попросил Аой изменить мир ради моего же блага."
    new "Le pedí a Aoi que cambiara el mundo por mi propio bien."


    old "Так что вся вина лежит на мне."
    new "Así que la culpa es mía."


    old "Я знаю это."
    new "Lo sé."


    old "Но..."
    new "Pero..."


    old "Стоп... Но я только что вернул её!"
    new "Espera... ¡Pero si acabo de traerla de vuelta!"


    old "И теперь она собирается снова исчезнуть?"
    new "¿Ahora va a desaparecer otra vez?"


    old "Синхронизировать?.."
    new "¿Sincronizar...?"


    old "Мне не нравится, как это звучит."
    new "No me gusta cómo suena eso."


    old "Её любовь ко мне - это глюк."
    new "Su amor hacia mí es un glitch."


    old "И он должен быть исследован."
    new "Y debería ser investigado."


    old "По крайней мере, так Бог сказал... но..."
    new "Eso es lo que decía Dios, al menos... pero..."


    old "Её чувства возникли в результате того, что она осталась несинхронизированной."
    new "Sus sentimientos surgieron como resultado de permanecer sin sincronizar."


    old "Если мы правда собираемся сбросить состояние мира..."
    new "Si de verdad reiniciamos el mundo..."


    old "То что произойдёт, когда Аой синхронизирует свои воспоминания с Богом?"
    new "¿Qué pasará cuando Aoi sincronice sus recuerdos con Dios?"


    old "Нет—"
    new "No—"


    old "Слёзы продолжали стекать по её щекам."
    new "Las lágrimas siguen fluyendo por sus mejillas."


    old "Это ни в коем разе не слёзы счастья."
    new "No hay forma de que estas sean lágrimas de felicidad."


    old "Её эмоции - это глюк?"
    new "¿Sus emociones son un glitch?"


    old "И стирание их - это, предположительно, правильный поступок?"
    new "¿Y supuestamente borrarlas es lo correcto?"


    old "Это не может быть правдой!"
    new "¡Eso no puede estar bien!"


    old "Аой отчаянно умоляла меня."
    new "Aoi me suplica desesperadamente."


    old "Она собирается исправить этот мир вновь."
    new "Va a arreglar el mundo de nuevo."


    old "Всё для того, чтобы спасти свою лучшую подругу, Миюки."
    new "Todo para salvar a su mejor amiga Miyuki."


    old "И при этом Аой должна исчезнуть."
    new "Y al hacerlo, Aoi tiene que desaparecer."


    old "Это её последняя просьба."
    new "Esta es su última petición."


    old "И я должен исполнить её—"
    new "Y debería concederla—"


    old "Миюки..."
    new "\"Miyuki...\""


    old "...и Аой..."
    new "...y Aoi..."


    old "...молча смотрели на меня."
    new "...me miran sin decir palabra."


    old "Да."
    new "Sí."


    old "Я знаю."
    new "Lo sé."


    old "И ТЫ предал Миюки для того, чтобы быть с Аой."
    new "Y traicionaste a Miyuki para poder estar con Aoi."


    old "Да, это так."
    new "Sí, lo hice."


    old "Да ну? ТЫ уверен в этом?"
    new "¿Tú? ¿Estás seguro?"


    old "Это ты, Шиничи?"
    new "¿Eres tú, Shinichi?"


    old "Единожды."
    new "Una vez."


    old "Это слово резонировало у меня в груди."
    new "La palabra reverbera en mi pecho."


    old "Мои руки начали потеть."
    new "Mis manos empiezan a sudar."


    old "У меня начался нервный тик."
    new "Parpadeo con nerviosismo."


    old "Я громко дышу... слишком громко."
    new "Respiro con fuerza... demasiado fuerte."


    old "Миюки подошла поближе."
    new "Miyuki se acerca más."


    old "Это я связал её судьбу со своей."
    new "Yo soy el que ató su destino al mío."


    old "Аой прицепилась ко мне."
    new "Aoi se aferra a mí."


    old "Это я научил её любить."
    new "Yo soy el que le enseñó a amar."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
