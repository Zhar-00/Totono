

translate english e3522b_8cec0df7:



    voice "voice/e35/22b00010a02.opus"
    aoi "\"Where did you go...?\""


translate english e3522b_cd8b28e7:



    voice "voice/e35/22b00020a02.opus"
    aoi "\"Do you...\""


translate english e3522b_4b6e8807:



    voice "voice/e35/22b00030a02.opus"
    aoi "\"Do you regret choosing me?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
