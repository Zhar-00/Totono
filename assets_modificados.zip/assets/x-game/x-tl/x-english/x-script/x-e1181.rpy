

translate english e1181_75e5f406:



    voice "voice/e11/8100010a01.opus"
    mx "\"No tenemos nada que temer...\""


translate english e1181_8fec3119:



    voice "voice/e11/8100020a01.opus"
    mx "\"Tú y yo pasaremos la eternidad aquí juntos...\""


translate english e1181_abf7db07:



    voice "voice/e11/8100030a01.opus"
    mx "\"Por siempre y siempre...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
