

translate english e1181_75e5f406:



    voice "voice/e11/8100010a01.opus"
    mx "\"We have nothing to fear...\""


translate english e1181_8fec3119:



    voice "voice/e11/8100020a01.opus"
    mx "\"You and I will spend eternity here together...\""


translate english e1181_abf7db07:



    voice "voice/e11/8100030a01.opus"
    mx "\"Forever and ever...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
