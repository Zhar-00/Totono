

translate english a3125_10d2c510:



    voice "voice/a31/2500010a02.opus"
    aoi "\"Okay.\""


translate english a3125_6cc647cd:


    "Justo cuando Aoi sonríe—"


translate english a3125_f8e1cd04:



    voice "voice/a31/2500020a02.opus"
    aoi "\"Boop boop...?\""


translate english a3125_9aea408a:


    xy "\"Whoa!\""


translate english a3125_3f6f41a0:


    "Su cuerpo cae de lado."


translate english a3125_3c442c06:


    xy "\"You okay?\""


translate english a3125_4c4852e1:



    voice "voice/a31/2500030a02.opus"
    aoi "\"Huh...?\""


translate english a3125_ca835e75:



    voice "voice/a31/2500040a02.opus"
    aoi "\"Is my battery dying?\""


translate english a3125_b6193ef5:


    xy "\"I could tell you weren't feeling so hot. Let's call off our plans and--\""


translate english a3125_0fc02288:



    voice "voice/a31/2500050a02.opus"
    aoi "\"Aoi's fine.\""


translate english a3125_da5589ff:



    voice "voice/a31/2500060a02.opus"
    aoi "\"Let's go to the batting cages.\""


translate english a3125_0accd139:


    xy "\"......\""


translate english a3125_5c8cff4a:


    "No hay vacilación en sus ojos."


translate english a3125_dffe39fb:


    "SÍ mencionó que estaba muy emocionada por ir... Tan emocionada que no durmió mucho..."


translate english a3125_ad0a1e3e:


    xy "\"Alright... But you better tell me if you start feeling sick, got it?\""


translate english a3125_30e38459:



    voice "voice/a31/2500070a02.opus"
    aoi "\"Got it.\""


translate english a3125_f5a4edb2:


    "Asiente y se tambalea hacia la escalera."


translate english a3125_17a7f3ad:



    voice "voice/a31/2500080a02.opus"
    aoi "\"Let's hurry and find Miyuki.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
