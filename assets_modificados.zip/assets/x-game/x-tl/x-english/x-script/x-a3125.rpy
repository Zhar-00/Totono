

translate english a3125_10d2c510:



    voice "voice/a31/2500010a02.opus"
    aoi "\"Está bien.\""


translate english a3125_6cc647cd:


    "Justo cuando Aoi sonríe—"


translate english a3125_f8e1cd04:



    voice "voice/a31/2500020a02.opus"
    aoi "\"Boop boop...?\""


translate english a3125_9aea408a:


    xy "\"¡Uah!\""


translate english a3125_3f6f41a0:


    "Su cuerpo cae de lado."


translate english a3125_3c442c06:


    xy "\"¿Estás bien?\""


translate english a3125_4c4852e1:



    voice "voice/a31/2500030a02.opus"
    aoi "\"¿Eh...?\""


translate english a3125_ca835e75:



    voice "voice/a31/2500040a02.opus"
    aoi "\"¿Se está muriendo mi batería?\""


translate english a3125_b6193ef5:


    xy "\"Me di cuenta de que no te sentías muy bien. Cancelemos nuestros planes y...\""


translate english a3125_0fc02288:



    voice "voice/a31/2500050a02.opus"
    aoi "\"Aoi está bien.\""


translate english a3125_da5589ff:



    voice "voice/a31/2500060a02.opus"
    aoi "\"Vamos al béisbol.\""


translate english a3125_0accd139:


    xy "\"......\""


translate english a3125_5c8cff4a:


    "No hay vacilación en sus ojos."


translate english a3125_dffe39fb:


    "SÍ mencionó que estaba muy emocionada por ir... Tan emocionada que no durmió mucho..."


translate english a3125_ad0a1e3e:


    xy "\"Está bien... Pero más te vale avisarme si empiezas a sentirte mal, ¿entendido?\""


translate english a3125_30e38459:



    voice "voice/a31/2500070a02.opus"
    aoi "\"Entendido.\""


translate english a3125_f5a4edb2:


    "Asiente y se tambalea hacia la escalera."


translate english a3125_17a7f3ad:



    voice "voice/a31/2500080a02.opus"
    aoi "\"Apurémonos a buscar a Miyuki.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
