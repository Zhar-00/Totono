

translate english e1165a_587f85e6:


    xy "\"¡¡¡Por favor, funciona!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
