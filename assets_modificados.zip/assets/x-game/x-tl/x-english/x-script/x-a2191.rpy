

translate english a2191_808b47a5:


    "Después de que el dependiente envuelve mi compra, salgo de la tienda."


translate english a2191_d72dda25:


    "Dos largas sombras se deslizan por el pavimento mientras Miyuki y Aoi se acercan a mí."


translate english a2191_3f3883fe:



    voice "voice/a21/9100010a01.opus"
    mx "\"Shinichi, you know what to do, yes?\""


translate english a2191_585abbd8:



    voice "voice/a21/9100020a02.opus"
    aoi "\"Shinichi, please...\""


translate english a2191_308c51b0:


    "Sus ojos me taladran."


translate english a2191_1471ead7:


    "Sonriendo, saco un paquete bien envuelto de mi bolsillo."


translate english strings:


    old "Отдать его Миюки"
    new "Dárselo a Miyuki"


    old "Отдать его Аой"
    new "Dárselo a Aoi"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
