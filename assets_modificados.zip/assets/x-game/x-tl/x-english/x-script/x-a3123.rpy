

translate english a3123_76e8febd:


    xy "\"Don't wear yourself out, now.\""


translate english a3123_2741117b:


    "Igual que esta mañana, todavía parece algo indispuesta."


translate english a3123_5607729f:


    xy "\"What'll you do if he answers?\""



translate english a3123_08498ce0:



    voice "voice/a31/2300010a02.opus"
    aoi "\"Save the game.\""


translate english a3123_e8989509:


    xy "\"Oh, right. You finally made friends with Miyuki, after all.\""


translate english a3123_c0c88805:



    voice "voice/a31/2300020a02.opus"
    aoi "\"Uh huh.\""


translate english a3123_6615eaa5:


    "No me vuelve loco su locura de cerebro gamer, pero me alegra que le importe Miyuki."


translate english a3123_922a9966:


    xy "\"Well, I hope He picks up, then.\""


translate english a3123_b4b5eb80:



    voice "voice/a31/2300030a02.opus"
    aoi "\"God will answer. Aoi can feel it.\""


translate english a3123_e1dd4a79:


    "Su mirada atraviesa más allá del cielo carmesí, más allá de los confines más lejanos del mundo, y por un momento, me descubro envidiándola."


translate english a3123_cb31f315:



    voice "voice/a31/2300040a02.opus"
    aoi "\"Shinichi, what's wrong with you today?\""


translate english a3123_c043fb3d:


    xy "\"What are you talking about?\""


translate english a3123_77c46eff:



    voice "voice/a31/2300050a02.opus"
    aoi "\"You were avoiding Miyuki.\""


translate english a3123_e2079a18:



    voice "voice/a31/2300060a02.opus"
    aoi "\"Did she shoot you down last night?\""


translate english a3123_8f987e98:


    xy "\"I didn't even confess!\""


translate english a3123_84a2fb88:


    xy "\"Miyuki and I are just friends, and--\""


translate english a3123_9119ac1b:



    voice "voice/a31/2300070a02.opus"
    aoi "\"You're lying. Aoi knows the truth.\""


translate english a3123_902b3d93:



    voice "voice/a31/2300080a02.opus"
    aoi "\"Miyuki likes Shinichi.\""


translate english a3123_fcf889c2:



    voice "voice/a31/2300090a02.opus"
    aoi "\"And Shinichi likes Miyuki.\""


translate english a3123_4e5b9821:



    voice "voice/a31/2300100a02.opus"
    aoi "\"So you two will get together. It would be dumb not to.\""


translate english a3123_0accd139:


    xy "\"......\""


translate english a3123_0389634d:


    "Cuando estoy con Aoi, por alguna razón, es más fácil abrirme."


translate english a3123_295a1fff:


    "¿Será porque estamos parados en el \"center of the universe\"?"


translate english a3123_b73c9def:


    "De alguna forma siento que, como amiga de Miyuki, Aoi es una persona segura a quien contárselo."


translate english a3123_c89c1965:


    xy "\"She said there's going to be a kiss.\""


translate english a3123_17cba4d1:



    voice "voice/a31/2300110a02.opus"
    aoi "\"Huh?\""


translate english a3123_50a3aee8:


    xy "\"In the play.\""


translate english a3123_23fcb540:


    xy "\"If I was her boyfriend, I'd be furious. But we're just friends, so it doesn't matter.\""


translate english a3123_711d4107:



    voice "voice/a31/2300120a02.opus"
    aoi "\"Are you sure?\""


translate english a3123_91b2c3f0:


    xy "\"I mean, she's out of my league, anyway.\""


translate english a3123_a892033e:


    xy "\"Once she's famous, she'll find someone who deserves her. Someone way better than me.\""


translate english a3123_fa0ab5f2:


    xy "\"Why sit around waiting to get dumped when I could just... not fall for her in the first place?\""


translate english a3123_43a6d9d4:


    xy "\"I made up my mind about this forever ago.\""


translate english a3123_20bb4b82:


    "Sé que estoy siendo un poco fatalista al respecto."


translate english a3123_7f3aa38d:


    "Pero no puedo evitar cómo me siento."


translate english a3123_3ea2b086:


    "Esta es la razón por la que me he mantenido a distancia de ella todo este tiempo."


translate english a3123_37c0b432:


    "Estar con ella solo haría que ambos saliéramos heridos más adelante."


translate english a3123_bacd0d58:



    voice "voice/a31/2300130a02.opus"
    aoi "\"Boop boop...?\""


translate english a3123_bf7b4c01:



    voice "voice/a31/2300140a02.opus"
    aoi "\"Shinichi, are you scared of getting cucked?\""


translate english a3123_62d467ed:


    xy "\"Excuse me?\""


translate english a3123_214dbdd2:



    voice "voice/a31/2300150a02.opus"
    aoi "\"Got it!\""


translate english a3123_b9a60e14:


    "Aoi alza la mano muy alto en el aire."


translate english a3123_09eb3a89:


    "Los rayos rojos del atardecer se reflejan en la pantalla de su teléfono."


translate english a3123_158050eb:



    voice "voice/a31/2300160a02.opus"
    aoi "\"Don't worry.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
