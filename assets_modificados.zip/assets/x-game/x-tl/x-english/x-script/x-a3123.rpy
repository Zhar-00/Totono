

translate english a3123_76e8febd:


    xy "\"No te agotes, ¿eh?\""


translate english a3123_2741117b:


    "Igual que esta mañana, todavía parece algo indispuesta."


translate english a3123_5607729f:


    xy "\"¿Qué harás si contesta?\""



translate english a3123_08498ce0:



    voice "voice/a31/2300010a02.opus"
    aoi "\"Guardar la partida.\""


translate english a3123_e8989509:


    xy "\"Ah, cierto. Después de todo, por fin hiciste amistad con Miyuki.\""


translate english a3123_c0c88805:



    voice "voice/a31/2300020a02.opus"
    aoi "\"Ajá.\""


translate english a3123_6615eaa5:


    "No me vuelve loco su locura de cerebro gamer, pero me alegra que le importe Miyuki."


translate english a3123_922a9966:


    xy "\"Bueno, entonces espero que conteste.\""


translate english a3123_b4b5eb80:



    voice "voice/a31/2300030a02.opus"
    aoi "\"Dios va a contestar. Aoi lo presiente.\""


translate english a3123_e1dd4a79:


    "Su mirada atraviesa más allá del cielo carmesí, más allá de los confines más lejanos del mundo, y por un momento, me descubro envidiándola."


translate english a3123_cb31f315:



    voice "voice/a31/2300040a02.opus"
    aoi "\"Shinichi, ¿qué te pasa hoy?\""


translate english a3123_c043fb3d:


    xy "\"¿De qué hablas?\""


translate english a3123_77c46eff:



    voice "voice/a31/2300050a02.opus"
    aoi "\"Estabas evitando a Miyuki.\""


translate english a3123_e2079a18:



    voice "voice/a31/2300060a02.opus"
    aoi "\"¿Te rechazó anoche?\""


translate english a3123_8f987e98:


    xy "\"¡Si ni siquiera confesé!\""


translate english a3123_84a2fb88:


    xy "\"Miyuki y yo solo somos amigos, y...\""


translate english a3123_9119ac1b:



    voice "voice/a31/2300070a02.opus"
    aoi "\"Mientes. Aoi sabe la verdad.\""


translate english a3123_902b3d93:



    voice "voice/a31/2300080a02.opus"
    aoi "\"A Miyuki le gusta Shinichi.\""


translate english a3123_fcf889c2:



    voice "voice/a31/2300090a02.opus"
    aoi "\"Y a Shinichi le gusta Miyuki.\""


translate english a3123_4e5b9821:



    voice "voice/a31/2300100a02.opus"
    aoi "\"Así que ustedes dos van a estar juntos. Sería tonto no hacerlo.\""


translate english a3123_0accd139:


    xy "\"......\""


translate english a3123_0389634d:


    "Cuando estoy con Aoi, por alguna razón, es más fácil abrirme."


translate english a3123_295a1fff:


    "¿Será porque estamos parados en el \"center of the universe\"?"


translate english a3123_b73c9def:


    "De alguna forma siento que, como amiga de Miyuki, Aoi es una persona segura a quien contárselo."


translate english a3123_c89c1965:


    xy "\"Dijo que va a haber un beso.\""


translate english a3123_17cba4d1:



    voice "voice/a31/2300110a02.opus"
    aoi "\"¿Eh?\""


translate english a3123_50a3aee8:


    xy "\"En la obra.\""


translate english a3123_23fcb540:


    xy "\"Si yo fuera su novio, estaría furioso. Pero solo somos amigos, así que no importa.\""


translate english a3123_711d4107:



    voice "voice/a31/2300120a02.opus"
    aoi "\"¿Estás seguro?\""


translate english a3123_91b2c3f0:


    xy "\"O sea, de todos modos, ella está fuera de mi liga.\""


translate english a3123_a892033e:


    xy "\"Cuando sea famosa, encontrará a alguien que la merezca. Alguien mucho mejor que yo.\""


translate english a3123_fa0ab5f2:


    xy "\"¿Para qué sentarme a esperar a que me deje cuando simplemente puedo... no enamorarme de ella desde el principio?\""


translate english a3123_43a6d9d4:


    xy "\"Me decidí sobre esto hace muchísimo tiempo.\""


translate english a3123_20bb4b82:


    "Sé que estoy siendo un poco fatalista al respecto."


translate english a3123_7f3aa38d:


    "Pero no puedo evitar cómo me siento."


translate english a3123_3ea2b086:


    "Esta es la razón por la que me he mantenido a distancia de ella todo este tiempo."


translate english a3123_37c0b432:


    "Estar con ella solo haría que ambos saliéramos heridos más adelante."


translate english a3123_bacd0d58:



    voice "voice/a31/2300130a02.opus"
    aoi "\"Boop boop...?\""


translate english a3123_bf7b4c01:



    voice "voice/a31/2300140a02.opus"
    aoi "\"Shinichi, ¿te da miedo que te pongan los cuernos?\""


translate english a3123_62d467ed:


    xy "\"¿Perdón?\""


translate english a3123_214dbdd2:



    voice "voice/a31/2300150a02.opus"
    aoi "\"¡Entendido!\""


translate english a3123_b9a60e14:


    "Aoi alza la mano muy alto en el aire."


translate english a3123_09eb3a89:


    "Los rayos rojos del atardecer se reflejan en la pantalla de su teléfono."


translate english a3123_158050eb:



    voice "voice/a31/2300160a02.opus"
    aoi "\"No te preocupes.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
