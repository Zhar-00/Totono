

translate english a2121_3cd77925:


    "A la hora del almuerzo..."


translate english a2121_f43eb050:



    voice "voice/a21/2100010a02.opus"
    aoi "\"Nice and warm outside.\""


translate english a2121_ad8f4930:



    voice "voice/a21/2100020a01.opus"
    mx "\"...I agreed to help you with your homework, nothing more. I certainly don't remember agreeing to eat lunch together.\""


translate english a2121_854ded88:


    xy "\"C'mon, don't be like that.\""


translate english a2121_5221c2a1:


    "Aquí estamos, en la azotea con nuestra comida."


translate english a2121_a8231a8f:



    voice "voice/a21/2100030a01.opus"
    mx "\"How are we going to get any studying done up here?\""


translate english a2121_e5654edc:


    xy "\"Would you rather do this in the classroom? With me and her? In front of everyone?\""


translate english a2121_e75da7af:



    voice "voice/a21/2100040a01.opus"
    mx "\"\"\"\"\"......\"\"\"?!?! ¡T-Tienes que olvidar que eso pasó!\"\""


translate english a2121_0441d4c6:


    "Miyuki atrae bastante atención solo con interactuar con Aoi."


translate english a2121_8b878b7b:


    "En el segundo en que me añadan a la mezcla, habrá rumores volando para mañana por la mañana."



translate english a2121_d96f9b04:



    voice "voice/a21/2100050a01.opus"
    mx "\"I don't like it up here.\""


translate english a2121_5683057a:


    xy "\"Reminds you of when you professed your fake love to me, huh?\""


translate english a2121_261b9ea1:



    voice "voice/a21/2100060a01.opus"
    mx "\"......?!?! Y-You need to forget that ever happened!\""


translate english a2121_09c71f47:



    voice "voice/a21/2100070a01.opus"
    mx "\"I only did it because Mukou-san was acting so—\""


translate english a2121_4fa4451e:



    voice "voice/a21/2100080a01.opus"
    mx "\"...Wait, what the? Where is she?\""


translate english a2121_ce9dac1e:


    xy "\"Over there.\""


translate english a2121_3b755078:



    voice "voice/a21/2100090a02.opus"
    aoi "\"Boop boop...\""


translate english a2121_179626c8:


    "Aoi está de pie en la azotea sobre las escaleras, contemplando el horizonte."


translate english a2121_d6f56d39:



    voice "voice/a21/2100100a01.opus"
    mx "\"What is she doing?\""


translate english a2121_966dc3ee:


    xy "\"Maybe you should go up there and find out.\""


translate english a2121_511cc8de:



    voice "voice/a21/2100110a01.opus"
    mx "\"Smoke will rise and fools will climb, as they say.\""


translate english a2121_4dfb0a71:


    xy "\"Enough with the proverbs. C'mon.\""


translate english a2121_f5162b52:


    "Miyuki pone a regañadientes la mano en el primer peldaño de la escalera."


translate english a2121_1b670e9c:



    voice "voice/a21/2100120a01.opus"
    mx "\"Don't you dare look up.\""


translate english a2121_f841fe20:


    xy "\"I won't!\""


translate english a2121_017beac2:


    "Mantengo los ojos apartados mientras la sigo subiendo."


translate english a2121_805caf0c:



    voice "voice/a21/2100130a01.opus"
    mx "\"\"\"\"\"......\"\"\"?!?! ¡T-Tienes que olvidar que eso pasó!\"\""


translate english a2121_d407e239:


    "Cuando llega arriba, Miyuki queda de inmediato cautivada por la vista."


translate english a2121_eedba865:


    "No es que la culpe."


translate english a2121_f95c9e1d:


    "Ni siquiera es la primera vez que la veo, y aun así me deja sin aliento."


translate english a2121_b3527f11:


    xy "\"Pretty cool, huh?\""


translate english a2121_7502ee62:



    voice "voice/a21/2100140a01.opus"
    mx "\"It's unlike anything I've ever seen...!\""


translate english a2121_5a452ccf:



    voice "voice/a21/2100150a02.opus"
    aoi "\"This is a special place.\""


translate english a2121_93d99734:



    voice "voice/a21/2100160a01.opus"
    mx "\"...I'm sorry. I need to apologize for making fun of you.\""


translate english a2121_4b25071e:



    voice "voice/a21/2100170a02.opus"
    aoi "\"Boop boop?\""


translate english a2121_7b562598:



    voice "voice/a21/2100180a02.opus"
    aoi "\"When was that?\""


translate english a2121_92199635:


    "Típico de Aoi."


translate english a2121_e6a8d5ca:



    voice "voice/a21/2100190a02.opus"
    aoi "\"Aoi's hungry. Time to eat.\""


translate english a2121_b9483742:



    voice "voice/a21/2100200a01.opus"
    mx "\"Hmm... Good call.\""


translate english a2121_65e1775c:


    "Claramente este no es momento para perderte en tus pensamientos."


translate english a2121_e603f93f:


    "Cada uno empieza a sacar su comida."


translate english a2121_63fefd9c:



    voice "voice/a21/2100210a02.opus"
    aoi "\"Chow time!\""


translate english a2121_330d887c:



    voice "voice/a21/2100220a01.opus"
    mx "\"Hold it!\""


translate english a2121_dabdbfe0:



    voice "voice/a21/2100230a01.opus"
    mx "\"What, pray tell, is THAT?\""


translate english a2121_621699d9:



    voice "voice/a21/2100240a02.opus"
    aoi "\"Koala Munch.\""


translate english a2121_a5d3fb54:



    voice "voice/a21/2100250a01.opus"
    mx "\"And THAT?\""


translate english a2121_7953b5d1:



    voice "voice/a21/2100260a02.opus"
    aoi "\"Bunny-ear tarts.\""


translate english a2121_ef562ed8:



    voice "voice/a21/2100270a01.opus"
    mx "\"And THAT?\""


translate english a2121_75ffbca4:



    voice "voice/a21/2100280a02.opus"
    aoi "\"Mushroom Monsters.\""


translate english a2121_6e448115:


    xy "\"On a bit of a chocolate kick, are you?\""


translate english a2121_f3d6ac69:



    voice "voice/a21/2100290a02.opus"
    aoi "\"What about you?\""


translate english a2121_6d99e09c:


    xy "\"Who, me? Let's see here... I've got a potato salad sandwich, a jumbo croquette, some candied yams...\""


translate english a2121_1acf380f:



    voice "voice/a21/2100300a02.opus"
    aoi "\"That's too much potato.\""


translate english a2121_65515a35:


    xy "\"You're not wrong! I can't help it, though. Potatoes are the best.\""


translate english a2121_9447b1b9:



    voice "voice/a21/2100310a02.opus"
    aoi "\"Aoi really likes chocolate.\""


translate english a2121_48dd19d6:



    voice "voice/a21/2100320a01.opus"
    mx "\"You ought to eat it in moderation, though!\""


translate english a2121_2fdbb7f4:



    voice "voice/a21/2100330a02.opus"
    aoi "\"Don't worry.\""


translate english a2121_bed2bc39:



    voice "voice/a21/2100340a02.opus"
    aoi "\"Aoi's got Yabaley's!\""


translate english a2121_c6a330ab:



    voice "voice/a21/2100350a01.opus"
    mx "\"Tomato juice...?\""


translate english a2121_8b418850:



    voice "voice/a21/2100360a02.opus"
    aoi "\"Problem solved.\""


translate english a2121_dee95c1d:



    voice "voice/a21/2100370a01.opus"
    mx "\"The sight of those things together is making my stomach turn.\""


translate english a2121_2508aef4:



    voice "voice/a21/2100380a02.opus"
    aoi "\"Miyuki, do you want some?\""


translate english a2121_c896efc3:



    voice "voice/a21/2100390a01.opus"
    mx "\"No thank you.\""


translate english a2121_574df45f:



    voice "voice/a21/2100400a02.opus"
    aoi "\"But it's yummy though.\""


translate english a2121_6a969c2a:



    voice "voice/a21/2100410a02.opus"
    aoi "\"It'll make you zappy and recharge your batteries.\""


translate english a2121_966e9432:



    voice "voice/a21/2100420a01.opus"
    mx "\"I said no thank you! Besides, I have my own perfectly good lunch right here! See?\""



translate english a2121_e8b869b4:


    "Miyuki abre la tapa de su lonchera para revelar—"


translate english a2121_e2344fad:


    xy "\"Whoa...\""


translate english a2121_32cdaaf4:



    voice "voice/a21/2100430a02.opus"
    aoi "\"Octopus hot dogs!\""


translate english a2121_6798e27c:



    voice "voice/a21/2100440a02.opus"
    aoi "\"Apple rabbits!\""


translate english a2121_fe694ec7:



    voice "voice/a21/2100450a02.opus"
    aoi "\"She's the ultimate childhood friend...\""


translate english a2121_1f727c83:



    voice "voice/a21/2100460a01.opus"
    mx "\"Please. This is what a NORMAL lunch looks like. You two need to shape up.\""



translate english a2121_e2e7f741:


    xy "\"You made the whole thing yourself, didn't you?\""


translate english a2121_e47d7a9f:



    voice "voice/a21/2100470a01.opus"
    mx "\"Of course.\""


translate english a2121_ff056c40:



    voice "voice/a21/2100480a02.opus"
    aoi "\"Boop boop... Miyuki's food is all so cute...\""


translate english a2121_bac25df3:



    voice "voice/a21/2100490a01.opus"
    mx "\"S-So?! What's wrong with putting cute stuff in my lunch?!\""


translate english a2121_9f88009a:


    "Las mejillas de Miyuki se tiñen de rosa."


translate english a2121_0accd139:


    xy "\"\"\"\"\"......\"\"\"?!?! ¡T-Tienes que olvidar que eso pasó!\"\""


translate english a2121_3e11c992:



    voice "voice/a21/2100500a02.opus"
    aoi "\"\"\"\"\"......\"\"\"?!?! ¡T-Tienes que olvidar que eso pasó!\"\""


translate english a2121_82a466af:



    voice "voice/a21/2100510a01.opus"
    mx "\"Wh-What's with you two?\""


translate english a2121_e5c817c4:


    xy "\"Correct me if I'm wrong, but... You're not used to being called cute, are you?\""


translate english a2121_9f254d8b:



    voice "voice/a21/2100520a01.opus"
    mx "\"M-Maybe! But it's your fault for—\""


translate english a2121_ce8747fe:



    voice "voice/a21/2100530a02.opus"
    aoi "\"Miyuki's cute when she's embarrassed.\""


translate english a2121_dc63ea30:



    voice "voice/a21/2100540a01.opus"
    mx "\"S-Stop making fun of me!\""


translate english a2121_b0f5e7eb:


    xy "\"And when she's ang—\""


translate english a2121_13c31d13:



    voice "voice/a21/2100550a01.opus"
    mx "\"Okay, now you're pushing it.\""


translate english a2121_abffe471:


    xy "\"M-My bad.\""


translate english a2121_1c22d5a6:



    voice "voice/a21/2100560a02ex.opus"
    bm "\"Let's dig in, everyone.\" \"Sounds good.\" \"Yay, food!\""


translate english a2121_063cc4fb:



    voice "voice/a21/2100580a02.opus"
    aoi "\"Nom nom... nom nom nom...\""


translate english a2121_3fc3eade:



    voice "voice/a21/2100590a02.opus"
    aoi "\"Boop boop...?\""


translate english a2121_817219c3:


    xy "\"What's wrong, Aoi?\""


translate english a2121_26f2d9f1:



    voice "voice/a21/2100600a02.opus"
    aoi "\"...That's weird.\""


translate english a2121_73b3374a:



    voice "voice/a21/2100610a02.opus"
    aoi "\"It tastes different.\""


translate english a2121_d96d1c40:



    voice "voice/a21/2100620a01.opus"
    mx "\"Is it past the expiration date or something?\""


translate english a2121_f33b7af2:



    voice "voice/a21/2100630a02.opus"
    aoi "\"No...\""


translate english a2121_e6335982:



    voice "voice/a21/2100640a02.opus"
    aoi "\"It tastes better this time.\""


translate english a2121_006afe50:



    voice "voice/a21/2100650a01.opus"
    mx "\"What? That doesn't make any—\""


translate english a2121_021ac249:



    voice "voice/a21/2100660a02.opus"
    aoi "\"It does! It just does!\""


translate english a2121_8a928c72:


    "El tono de Aoi es sorprendentemente firme."


translate english a2121_3df59c29:


    xy "\"Probably because you're eating it with your friends.\""


translate english a2121_3ab2f66a:



    voice "voice/a21/2100670a01.opus"
    mx "\"Plural? I'll have you know, I never agreed to that.\""


translate english a2121_f336bd49:



    voice "voice/a21/2100680a02.opus"
    aoi "\"...Yeah...\""


translate english a2121_2d150a58:


    "Aoi mira hacia abajo con tristeza."


translate english a2121_b342500f:


    "Vaya... Justo cuando pensaba que las cosas por fin iban bien..."


translate english a2121_99275d13:


    xy "\"C'mon, Miyuki—\""


translate english a2121_26d2eb57:



    voice "voice/a21/2100690a01.opus"
    mx "\"F-Fine! Whatever!\""


translate english a2121_125359ef:


    "Miyuki se mueve incómoda."


translate english a2121_d691c5a4:



    voice "voice/a21/2100700a01.opus"
    mx "\"...I guess...\""


translate english a2121_a2d0602d:



    voice "voice/a21/2100710a01.opus"
    mx "\"I mean, the view up here really is something special. Maybe it adds a little something to the food, you know?\""


translate english a2121_c595730d:



    voice "voice/a21/2100720a02.opus"
    aoi "\"Really?\""


translate english a2121_33f8b045:



    voice "voice/a21/2100730a01.opus"
    mx "\"Just a little.\""


translate english a2121_af5ceb20:



    voice "voice/a21/2100740a02.opus"
    aoi "\"What about you, Shinichi?\""


translate english a2121_9b1dc8fb:


    xy "\"Grade-A delicious.\""


translate english a2121_c595b49c:


    "La verdad, las cosas todavía están algo incómodas."


translate english a2121_e619a4b9:


    "Quizá es demasiado pronto para llamar a esto \"friendship.\""


translate english a2121_3ab27ba1:


    "Pero esto es solo el primer paso, y para Aoi es uno grande."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
