

translate english a2121_3cd77925:


    "A la hora del almuerzo..."


translate english a2121_f43eb050:



    voice "voice/a21/2100010a02.opus"
    aoi "\"Está agradable y caliente afuera.\""


translate english a2121_ad8f4930:



    voice "voice/a21/2100020a01.opus"
    mx "\"...Acepté ayudarte con tu tarea, nada más. Ciertamente no recuerdo haber aceptado almorzar juntas.\""


translate english a2121_854ded88:


    xy "\"Vamos, no seas así.\""


translate english a2121_5221c2a1:


    "Aquí estamos, en la azotea con nuestra comida."


translate english a2121_a8231a8f:



    voice "voice/a21/2100030a01.opus"
    mx "\"¿Cómo vamos a estudiar algo aquí arriba?\""


translate english a2121_e5654edc:


    xy "\"¿Preferirías hacerlo en el salón? ¿Conmigo y con ella? ¿Frente a todos?\""


translate english a2121_e75da7af:



    voice "voice/a21/2100040a01.opus"
    mx "\"\"\"\"\"......\"\"\"?!?! ¡T-Tienes que olvidar que eso pasó!\"\""


translate english a2121_0441d4c6:


    "Miyuki atrae bastante atención solo con interactuar con Aoi."


translate english a2121_8b878b7b:


    "En el segundo en que me añadan a la mezcla, habrá rumores volando para mañana por la mañana."



translate english a2121_d96f9b04:



    voice "voice/a21/2100050a01.opus"
    mx "\"No me gusta aquí arriba.\""


translate english a2121_5683057a:


    xy "\"Te recuerda a cuando me profesaste tu amor falso, ¿eh?\""


translate english a2121_261b9ea1:



    voice "voice/a21/2100060a01.opus"
    mx "\"......¿?!? ¡¿T-Tienes que olvidar que eso pasó!\""


translate english a2121_09c71f47:



    voice "voice/a21/2100070a01.opus"
    mx "\"Solo lo hice porque Mukou-san estaba actuando tan—\""


translate english a2121_4fa4451e:



    voice "voice/a21/2100080a01.opus"
    mx "\"...Espera, ¿qué demonios? ¿Dónde está?\""


translate english a2121_ce9dac1e:


    xy "\"Allá.\""


translate english a2121_3b755078:



    voice "voice/a21/2100090a02.opus"
    aoi "\"Bip bip...\""


translate english a2121_179626c8:


    "Aoi está de pie en la azotea sobre las escaleras, contemplando el horizonte."


translate english a2121_d6f56d39:



    voice "voice/a21/2100100a01.opus"
    mx "\"¿Qué está haciendo?\""


translate english a2121_966dc3ee:


    xy "\"Quizás deberías subir y averiguarlo.\""


translate english a2121_511cc8de:



    voice "voice/a21/2100110a01.opus"
    mx "\"Se levantará humo y los tontos subirán, como dicen.\""


translate english a2121_4dfb0a71:


    xy "\"Basta de proverbios. Vamos.\""


translate english a2121_f5162b52:


    "Miyuki pone a regañadientes la mano en el primer peldaño de la escalera."


translate english a2121_1b670e9c:



    voice "voice/a21/2100120a01.opus"
    mx "\"No te atrevas a mirar hacia arriba.\""


translate english a2121_f841fe20:


    xy "\"¡No lo haré!\""


translate english a2121_017beac2:


    "Mantengo los ojos apartados mientras la sigo subiendo."


translate english a2121_805caf0c:



    voice "voice/a21/2100130a01.opus"
    mx "\"\"\"\"\"......\"\"\"?!?! ¡T-Tienes que olvidar que eso pasó!\"\""


translate english a2121_d407e239:


    "Cuando llega arriba, Miyuki queda de inmediato cautivada por la vista."


translate english a2121_eedba865:


    "No es que la culpe."


translate english a2121_f95c9e1d:


    "Ni siquiera es la primera vez que la veo, y aun así me deja sin aliento."


translate english a2121_b3527f11:


    xy "\"Bastante genial, ¿eh?\""


translate english a2121_7502ee62:



    voice "voice/a21/2100140a01.opus"
    mx "\"¡Es como nada que haya visto antes...!\""


translate english a2121_5a452ccf:



    voice "voice/a21/2100150a02.opus"
    aoi "\"Este es un lugar especial.\""


translate english a2121_93d99734:



    voice "voice/a21/2100160a01.opus"
    mx "\"...Perdón. Necesito disculparme por haberme burlado de ti.\""


translate english a2121_4b25071e:



    voice "voice/a21/2100170a02.opus"
    aoi "\"¿Bip bip?\""


translate english a2121_7b562598:



    voice "voice/a21/2100180a02.opus"
    aoi "\"¿Cuándo fue eso?\""


translate english a2121_92199635:


    "Típico de Aoi."


translate english a2121_e6a8d5ca:



    voice "voice/a21/2100190a02.opus"
    aoi "\"Aoi tiene hambre. Hora de comer.\""


translate english a2121_b9483742:



    voice "voice/a21/2100200a01.opus"
    mx "\"Hmm... Buena decisión.\""


translate english a2121_65e1775c:


    "Claramente este no es momento para perderte en tus pensamientos."


translate english a2121_e603f93f:


    "Cada uno empieza a sacar su comida."


translate english a2121_63fefd9c:



    voice "voice/a21/2100210a02.opus"
    aoi "\"¡Hora de comer!\""


translate english a2121_330d887c:



    voice "voice/a21/2100220a01.opus"
    mx "\"¡Alto!\""


translate english a2121_dabdbfe0:



    voice "voice/a21/2100230a01.opus"
    mx "\"¿Qué, te parece, es ESO?\""


translate english a2121_621699d9:



    voice "voice/a21/2100240a02.opus"
    aoi "\"Koala Munch.\""


translate english a2121_a5d3fb54:



    voice "voice/a21/2100250a01.opus"
    mx "\"¿¡Y ESO!?\""


translate english a2121_7953b5d1:



    voice "voice/a21/2100260a02.opus"
    aoi "\"Tartas de orejas de conejo.\""


translate english a2121_ef562ed8:



    voice "voice/a21/2100270a01.opus"
    mx "\"¿¡Y ESO!?\""


translate english a2121_75ffbca4:



    voice "voice/a21/2100280a02.opus"
    aoi "\"Monstruos de champiñón.\""


translate english a2121_6e448115:


    xy "\"¿Estás en una racha de chocolate, eh?\""


translate english a2121_f3d6ac69:



    voice "voice/a21/2100290a02.opus"
    aoi "\"¿Y tú?\""


translate english a2121_6d99e09c:


    xy "\"¿Yo? Veamos... Tengo un sándwich de ensalada de papa, una croqueta gigante, camotes caramelizados...\""


translate english a2121_1acf380f:



    voice "voice/a21/2100300a02.opus"
    aoi "\"Eso es demasiada papa.\""


translate english a2121_65515a35:


    xy "\"¡No estás equivocado! Pero no puedo evitarlo. Las papas son lo mejor.\""


translate english a2121_9447b1b9:



    voice "voice/a21/2100310a02.opus"
    aoi "\"A Aoi le gusta mucho el chocolate.\""


translate english a2121_48dd19d6:



    voice "voice/a21/2100320a01.opus"
    mx "\"¡Pero deberías comerlo con moderación!\""


translate english a2121_2fdbb7f4:



    voice "voice/a21/2100330a02.opus"
    aoi "\"No te preocupes.\""


translate english a2121_bed2bc39:



    voice "voice/a21/2100340a02.opus"
    aoi "\"¡Aoi tiene Yabaley!\""


translate english a2121_c6a330ab:



    voice "voice/a21/2100350a01.opus"
    mx "\"¿Jugo de tomate...?\""


translate english a2121_8b418850:



    voice "voice/a21/2100360a02.opus"
    aoi "\"Problema resuelto.\""


translate english a2121_dee95c1d:



    voice "voice/a21/2100370a01.opus"
    mx "\"Ver esas cosas juntas me revuelve el estómago.\""


translate english a2121_2508aef4:



    voice "voice/a21/2100380a02.opus"
    aoi "\"Miyuki, ¿quieres un poco?\""


translate english a2121_c896efc3:



    voice "voice/a21/2100390a01.opus"
    mx "\"No, gracias.\""


translate english a2121_574df45f:



    voice "voice/a21/2100400a02.opus"
    aoi "\"Pero está rico.\""


translate english a2121_6a969c2a:



    voice "voice/a21/2100410a02.opus"
    aoi "\"Te va a dar chispa y recargar tus baterías.\""


translate english a2121_966e9432:



    voice "voice/a21/2100420a01.opus"
    mx "\"¡Dije que no, gracias! ¡Además, tengo mi propio y perfectamente bueno almuerzo aquí! ¿Ves?\""



translate english a2121_e8b869b4:


    "Miyuki abre la tapa de su lonchera para revelar—"


translate english a2121_e2344fad:


    xy "\"Whoa...\""


translate english a2121_32cdaaf4:



    voice "voice/a21/2100430a02.opus"
    aoi "\"¡Hot dogs de pulpo!\""


translate english a2121_6798e27c:



    voice "voice/a21/2100440a02.opus"
    aoi "\"¡Conejos de manzana!\""


translate english a2121_fe694ec7:



    voice "voice/a21/2100450a02.opus"
    aoi "\"Es la amiga de la infancia definitiva...\""


translate english a2121_1f727c83:



    voice "voice/a21/2100460a01.opus"
    mx "\"Por favor. Así es como se ve un almuerzo NORMAL. Ustedes dos tienen que ponerse las pilas.\""



translate english a2121_e2e7f741:


    xy "\"Tú hiciste todo eso, ¿verdad?\""


translate english a2121_e47d7a9f:



    voice "voice/a21/2100470a01.opus"
    mx "\"Por supuesto.\""


translate english a2121_ff056c40:



    voice "voice/a21/2100480a02.opus"
    aoi "\"Bip bip... La comida de Miyuki es tan linda...\""


translate english a2121_bac25df3:



    voice "voice/a21/2100490a01.opus"
    mx "\"¡¿Y-Y qué?! ¡¿Qué tiene de malo poner cosas lindas en mi almuerzo?!\""


translate english a2121_9f88009a:


    "Las mejillas de Miyuki se tiñen de rosa."


translate english a2121_0accd139:


    xy "\"\"\"\"\"......\"\"\"?!?! ¡T-Tienes que olvidar que eso pasó!\"\""


translate english a2121_3e11c992:



    voice "voice/a21/2100500a02.opus"
    aoi "\"\"\"\"\"......\"\"\"?!?! ¡T-Tienes que olvidar que eso pasó!\"\""


translate english a2121_82a466af:



    voice "voice/a21/2100510a01.opus"
    mx "\"¿Q-Qué les pasa a ustedes dos?\""


translate english a2121_e5c817c4:


    xy "\"Corrígeme si me equivoco, pero... No estás acostumbrada a que te digan linda, ¿verdad?\""


translate english a2121_9f254d8b:



    voice "voice/a21/2100520a01.opus"
    mx "\"¡P-Puede ser! ¡Pero es tu culpa por—\""


translate english a2121_ce8747fe:



    voice "voice/a21/2100530a02.opus"
    aoi "\"Miyuki es linda cuando está avergonzada.\""


translate english a2121_dc63ea30:



    voice "voice/a21/2100540a01.opus"
    mx "\"¡D-Deja de burlarte de mí!\""


translate english a2121_b0f5e7eb:


    xy "\"Y cuando está enoj—\""


translate english a2121_13c31d13:



    voice "voice/a21/2100550a01.opus"
    mx "\"Ok, ahora sí te estás pasando.\""


translate english a2121_abffe471:


    xy "\"M-Mi culpa.\""


translate english a2121_1c22d5a6:



    voice "voice/a21/2100560a02ex.opus"
    bm "\"Vamos a comer, todos.\" \"Suena bien.\" \"¡Sí, comida!\"\""


translate english a2121_063cc4fb:



    voice "voice/a21/2100580a02.opus"
    aoi "\"Ñam ñam... ñam ñam ñam...\""


translate english a2121_3fc3eade:



    voice "voice/a21/2100590a02.opus"
    aoi "\"¿Bip bip...?\""


translate english a2121_817219c3:


    xy "\"¿Qué pasa, Aoi?\""


translate english a2121_26f2d9f1:



    voice "voice/a21/2100600a02.opus"
    aoi "\"...Qué raro.\""


translate english a2121_73b3374a:



    voice "voice/a21/2100610a02.opus"
    aoi "\"Sabe diferente.\""


translate english a2121_d96d1c40:



    voice "voice/a21/2100620a01.opus"
    mx "\"¿Está pasada de fecha o algo así?\""


translate english a2121_f33b7af2:



    voice "voice/a21/2100630a02.opus"
    aoi "\"No...\""


translate english a2121_e6335982:



    voice "voice/a21/2100640a02.opus"
    aoi "\"Sabe mejor esta vez.\""


translate english a2121_006afe50:



    voice "voice/a21/2100650a01.opus"
    mx "\"¿Qué? Eso no tiene ningún—\""


translate english a2121_021ac249:



    voice "voice/a21/2100660a02.opus"
    aoi "\"¡Sí lo tiene! ¡Solo lo tiene!\""


translate english a2121_8a928c72:


    "El tono de Aoi es sorprendentemente firme."


translate english a2121_3df59c29:


    xy "\"Probablemente porque la estás comiendo con tus amigos.\""


translate english a2121_3ab2f66a:



    voice "voice/a21/2100670a01.opus"
    mx "\"¿Plural? Que sepas que nunca acepté eso.\""


translate english a2121_f336bd49:



    voice "voice/a21/2100680a02.opus"
    aoi "\"...Sí...\""


translate english a2121_2d150a58:


    "Aoi mira hacia abajo con tristeza."


translate english a2121_b342500f:


    "Vaya... Justo cuando pensaba que las cosas por fin iban bien..."


translate english a2121_99275d13:


    xy "\"Vamos, Miyuki—\""


translate english a2121_26d2eb57:



    voice "voice/a21/2100690a01.opus"
    mx "\"¡E-Está bien! ¡Como sea!\""


translate english a2121_125359ef:


    "Miyuki se mueve incómoda."


translate english a2121_d691c5a4:



    voice "voice/a21/2100700a01.opus"
    mx "\"...Supongo...\""


translate english a2121_a2d0602d:



    voice "voice/a21/2100710a01.opus"
    mx "\"Digo, la vista aquí arriba sí que es algo especial. Quizás le añade algo a la comida, ¿sabes?\""


translate english a2121_c595730d:



    voice "voice/a21/2100720a02.opus"
    aoi "\"¿En serio?\""


translate english a2121_33f8b045:



    voice "voice/a21/2100730a01.opus"
    mx "\"Solo un poco.\""


translate english a2121_af5ceb20:



    voice "voice/a21/2100740a02.opus"
    aoi "\"¿Y tú, Shinichi?\""


translate english a2121_9b1dc8fb:


    xy "\"Delicioso de primera.\""


translate english a2121_c595b49c:


    "La verdad, las cosas todavía están algo incómodas."


translate english a2121_e619a4b9:


    "Quizá es demasiado pronto para llamar a esto \"friendship.\""


translate english a2121_3ab27ba1:


    "Pero esto es solo el primer paso, y para Aoi es uno grande."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
