

translate english a5161_631a1657:


    "—Surgió algo."


translate english a5161_9c136151:


    "—Lo siento, pero llegaré un poco tarde."


translate english a5161_4d186fb7:


    "Sé que le debo una explicación adecuada, pero simplemente no tengo tiempo."


translate english a5161_2cb1af4c:


    "Ahora que el correo va en camino, es momento de preguntarle a Aoi más detalles."


translate english a5161_d0def184:


    xy "\"Where did you lose it?\""


translate english a5161_86267756:



    voice "voice/a51/6100010a02.opus"
    aoi "\"No clue...\""


translate english a5161_885db130:



    voice "voice/a51/6100020a02.opus"
    aoi "\"Normally, whenever Aoi drops the phone, God's supposed to notice and start calling.\""


translate english a5161_f042498a:



    voice "voice/a51/6100030a02.opus"
    aoi "\"That way Aoi will hear the ringtone.\""


translate english a5161_ba52e6dc:


    xy "\"God actually calls you?\""


translate english a5161_cab3fbc5:



    voice "voice/a51/6100040a02.opus"
    aoi "\"But it didn't happen this time.\""


translate english a5161_0bf63076:


    xy "\"Okay then, when was the last time you remember having it?\""


translate english a5161_1c00196f:



    voice "voice/a51/6100050a02.opus"
    aoi "\"Before we went to the batting cages, Aoi checked the time.\""


translate english a5161_46f77b63:



    voice "voice/a51/6100060a02.opus"
    aoi "\"It went missing sometime after that.\""


translate english a5161_74aeb336:


    xy "\"When did you notice it was gone?\""


translate english a5161_daa275fa:



    voice "voice/a51/6100070a02.opus"
    aoi "\"This morning.\""


translate english a5161_7e1cea33:



    voice "voice/a51/6100080a02.opus"
    aoi "\"Aoi's been searching and searching... The manga cafe, the batting cages, and all the roads in between.\""


translate english a5161_c7ab1dc9:


    "Eso explica por qué no estuvo en la escuela hoy."


translate english a5161_55699552:



    voice "voice/a51/6100090a02.opus"
    aoi "\"Now all that's left is your house.\""


translate english a5161_381aafab:


    "Eso tiene sentido, considerando que vino anoche."


translate english a5161_ea3087e0:


    "Pasó la mayor parte del tiempo jugando con Eru, así que es muy posible que lo haya dejado caer por aquí."


translate english a5161_e44eb8ef:


    xy "\"Okay, let's retrace our steps. Last night... First we warmed up the milk...\""


translate english a5161_90a8d2c1:


    "Cierto recuerdo flota en el fondo de mi mente: el momento en que Miyuki me dijo que la besara."


translate english a5161_639938b2:


    "Y ahora mismo, ella me está esperando—"


translate english a5161_e64d27c9:



    voice "voice/a51/6100100a02.opus"
    aoi "\"Boop boop...\""


translate english a5161_85a173ca:


    "...Me preocuparé por eso después."


translate english a5161_ce18879c:


    "Suprimiendo mis emociones, concentro mi energía en la búsqueda del teléfono de Aoi."


translate english a5161_37e459e1:


    "...No aparece por ningún lado."


translate english a5161_b53148df:


    "¿A dónde demonios se fue?"


translate english a5161_9c5d089d:


    "¿Está siquiera aquí, o está tirado en alguna zanja?"


translate english a5161_3f96aceb:


    "¿Ya lo habrá encontrado alguien más?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
