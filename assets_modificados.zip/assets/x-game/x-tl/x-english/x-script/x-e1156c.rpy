

translate english e1156c_a9cdb990:


    xy "\"¡Aaargh! ¡Maldita sea!\""


translate english e1156c_a2813437:


    "¿¡Por qué me siento así!?"


translate english e1156c_99cd7f8a:


    "Sé que solo estoy perdiendo el tiempo."


translate english e1156c_1c8ca54b:


    "Y sin embargo... ¡siento este extraño y compulsivo impulso de buscar a Aoi...!"


translate english e1156c_1d50ccae:


    "¡No tiene absolutamente ningún sentido... pero me siento obligado a hacerlo de todos modos!"


translate english e1156c_ca2b83ce:


    "¡Bien, como sea! ¡Supongo que vamos a comprar una figura!"


translate english e1156c_0fbbc3c1:


    "¡Mi única opción es encontrar a Aoi lo más rápido posible!"


translate english e1156c_92fbfa51:


    "Tomo una respiración profunda, luego me dirijo a la puerta—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
