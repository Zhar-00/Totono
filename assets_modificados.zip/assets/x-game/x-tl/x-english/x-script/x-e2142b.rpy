

translate english e2142b_a0b3cb06:


    xy "\"Didn't we agree to save it for the debut performance?\""


translate english e2142b_7bba341d:



    voice "voice/e21/42b00010a01.opus"
    mx "\"But...\""


translate english e2142b_ea05796e:



    voice "voice/e21/42b00020a01.opus"
    mx "\"Do you promise you'll kiss me then?\""


translate english e2142b_78d0a98b:


    xy "\"When the time comes, sure.\""


translate english e2142b_fe7f4241:


    "Ella levanta la vista hacia mí, y asiento."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
