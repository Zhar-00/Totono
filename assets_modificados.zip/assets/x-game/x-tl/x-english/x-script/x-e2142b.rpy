

translate english e2142b_a0b3cb06:


    xy "\"¿No habíamos acordado guardarlo para la presentación de debut?\""


translate english e2142b_7bba341d:



    voice "voice/e21/42b00010a01.opus"
    mx "\"Pero...\""


translate english e2142b_ea05796e:



    voice "voice/e21/42b00020a01.opus"
    mx "\"¿Prometes que me besarás entonces?\""


translate english e2142b_78d0a98b:


    xy "\"Cuando llegue el momento, claro.\""


translate english e2142b_fe7f4241:


    "Ella levanta la vista hacia mí, y asiento."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
