

translate english a7131_935bbc12:



    voice "voice/a71/3100010a01.opus"
    mx "\"¡Buenos días!\""


translate english a7131_caee0168:



    voice "voice/a71/3100020a01.opus"
    mx "\"Buenos días— ¡Oye! ¡Ven aquí!\""


translate english a7131_d1f456c9:


    xy "\"N-No tenemos que hacer esto, sabes...\""


translate english a7131_1e37013a:



    voice "voice/a71/3100030a01.opus"
    mx "\"¡Pero eres mi novio!\""


translate english a7131_8beb5778:



    voice "voice/a71/3100040a01.opus"
    mx "\"¿Por qué no íbamos a caminar juntos a la escuela?\""


translate english a7131_574a48b6:


    "Me arrastra de la mano."


translate english a7131_0accd139:


    xy "\"......\""


translate english a7131_10c6402b:


    "No puedo discutir más el punto."


translate english a7131_25aa6511:


    "Mientras avanzamos entre la multitud de gente camino a la escuela, puedo sentir vibras raras de todos los que encontramos."


translate english a7131_bbf3c6f4:


    "Miyuki podrá estar enamorada de mí, pero eso no cambia el hecho de que está objetivamente fuera de mi liga."


translate english a7131_50b63dee:


    xy "\"Veo que estás sorprendentemente tranquilo.\""


translate english a7131_a3e0b75c:



    voice "voice/a71/3100050a01.opus"
    mx "\"Es solo una actuación. Por dentro, mi corazón late como loco.\""


translate english a7131_0e7ee104:


    "Dicho como toda una actriz de teatro."


translate english a7131_64f2c954:


    "Solo una actriz de su calibre podría ocultar su agitación tan bien."


translate english a7131_ea280433:


    xy "\"Aunque no soy buen actor.\""


translate english a7131_b5b06dc8:



    voice "voice/a71/3100060a01.opus"
    mx "\"Oh, aguántate ya.\""


translate english a7131_3f44b0f6:


    "Lado a lado, nos acercamos a la puerta."


translate english a7131_4e09c3e0:


    "A estas alturas, ya lo he superado."


translate english a7131_74111e7f:


    "Que los envidiosos se queden enojados, no me importa."


translate english a7131_733ab50f:


    "Nada puede desconcertarme ahora—"


translate english a7131_a7621669:


    xy "\"¡No puedo. No puedo hacerlo!\""


translate english a7131_c2044a58:


    "—vale, quizá mentí."


translate english a7131_7dbdc30f:



    voice "voice/a71/3100070a01.opus"
    mx "\"Pero tenemos que hacer esto para que todos nos acepten, ¿recuerdas?\""


translate english a7131_ab765de3:


    xy "\"Yo... lo sé, pero no estoy emocionalmente preparado—?\""


translate english a7131_9e3dfc5c:



    voice "voice/a71/3100080a01.opus"
    mx "\"No seas tan bebé. ¡Vamos!\""


translate english a7131_9aea408a:


    xy "\"¡Uah!\""


translate english a7131_ee1d539f:


    xy "\"¡No tan rápido...!\""


translate english a7131_d7567fc5:


    "Entro tropezando al salón de clases."


translate english a7131_39147a35:


    "Luego ella entra tras de mí."


translate english a7131_31f2f380:



    voice "voice/a71/3100090a01.opus"
    mx "\"¡Buenos días!\""



translate english a7131_faa7038d:


    "Saluda al salón con desenfado, igual que siempre."


translate english a7131_169c9ffe:


    "Uno a uno, nuestros compañeros le responden de la misma manera."


translate english a7131_547f6fcc:


    "Puedo oír confusión en sus voces... pero aun así, se agolpan alrededor de su reina, como de costumbre."


translate english a7131_58ea3693:


    "Evidentemente toda la clase ya escuchó la noticia de que vinimos juntos a la escuela; puedo sentir algunas miradas curiosas dirigidas a mí."


translate english a7131_10265237:


    "Y puedo ver a mis compañeros varones sonriéndome... algunos de los cuales normalmente ni se habrían dado cuenta de que existo."


translate english a7131_c34ca60e:


    "Algunos de ellos vinieron a darme palmadas en la espalda—"


translate english a7131_49f0c291:


    xy "\"¡Ay! ¡Eso duele! ¡Basta, chicos!\""


translate english a7131_688ac9a1:


    "Noto que algunos aprovecharon la ocasión para desahogar sus celos..."


translate english a7131_f009b443:


    xy "\"¡Aaah! Jajaja... ¡V-Vamos, chicos, denme un respiro!\""


translate english a7131_e179ca31:


    "Pero sé que en su mayoría es broma. Además, imaginé que me molestarían de alguna forma."


translate english a7131_c964c06f:


    "Aunque, admito que estoy un poquito decepcionado de lo fácil que se calmaron."


translate english a7131_2eacbe7a:


    "Si tan solo todos los días pudieran ser así—"


translate english a7131_0accd139_1:


    xy "\"......\""


translate english a7131_f53fcfbf:


    "Justo entonces, recibo un feo despertar."


translate english a7131_963614b0:


    "Un solo trozo de papel me espera sobre mi escritorio."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
