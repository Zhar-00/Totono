

translate english c3163_1981a401:


    xy "\"This is Aoi we're talking about. There's no chance in hell she went home to her parents' house.\""


translate english c3163_33696c29:



    voice "voice/c31/6300010a01.opus"
    mx "\"Well, do you have an idea of where to look? We can wander aimlessly around town all we want, but it'll only be a waste of time.\""


translate english c3163_2932d704:



    voice "voice/c31/6300020a01.opus"
    mx "\"We should just call it quits.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
