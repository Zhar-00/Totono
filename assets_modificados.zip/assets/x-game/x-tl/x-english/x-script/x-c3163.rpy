

translate english c3163_1981a401:


    xy "\"Estamos hablando de Aoi. No hay ni una posibilidad en el infierno de que se haya ido a casa de sus padres.\""


translate english c3163_33696c29:



    voice "voice/c31/6300010a01.opus"
    mx "\"Bueno, ¿tienes idea de dónde buscar? Podemos vagar sin rumbo por la ciudad todo lo que queramos, pero solo será una pérdida de tiempo.\""


translate english c3163_2932d704:



    voice "voice/c31/6300020a01.opus"
    mx "\"Deberíamos darnos por vencidos.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
