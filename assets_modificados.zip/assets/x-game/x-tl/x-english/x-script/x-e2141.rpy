

translate english e2141_4bee6f90:


    xy "\"Miyuki... La verdad es... ¡que siempre te he amado!\""


translate english e2141_a9e3733f:



    voice "voice/e21/4100010a01.opus"
    mx "\"Lo sé... Y yo también te amo...\""


translate english e2141_3fa3a0f0:


    "En el escenario, Miyuki y yo estamos cara a cara. Aquí estamos en la escena final culminante."


translate english e2141_40a1dbca:


    "Ambos estamos poniendo todo en estos ensayos."


translate english e2141_2853d932:


    "Este es un guion original escrito por la propia Miyuki."


translate english e2141_3ed2e586:


    "Se titula \"Pandemonium!\""



translate english e2141_105d87b3:


    "Se titula \"Pandemonium!!\""



translate english e2141_24615130:


    "Se titula \"Pandemonium!!!\""



translate english e2141_35c3bc69:


    "Es una historia de triángulo amoroso bastante sencilla."


translate english e2141_c2f165c1:


    "La vida de un estudiante y su amiga de la infancia distanciada se pone patas arriba cuando aparece la Estudiante Transferida A."


translate english e2141_2e748b23:


    "Su comportamiento excéntrico y su falsa personalidad ganan la simpatía—y el afecto—del protagonista, Shinichirou."


translate english e2141_87a6c546:


    "Su comportamiento excéntrico y su falsa personalidad ganan la simpatía—y el afecto—del protagonista, Shinji."


translate english e2141_886ac498:


    "Su comportamiento excéntrico y su falsa personalidad ganan la simpatía—y el afecto—del protagonista, Shinnosuke."


translate english e2141_1bcb98f2:


    "A medida que avanza la historia, sin embargo, las mentiras de la Estudiante Transferida A quedan expuestas, y se revela que es una villana que engaña a los hombres."


translate english e2141_83ca7f96:


    "La historia concluye con el protagonista enamorándose de su comprensiva amiga de la infancia."


translate english e2141_47eda8d6:


    "En el escenario, Miyuki y yo nos miramos a los ojos, a centímetros de distancia."


translate english e2141_95a8941b:



    voice "voice/e21/4100020a01.opus"
    mx "\"Bésame.\""


translate english e2141_576c886c:


    xy "\"¿Qué? Eso no está en el guion—\""


translate english e2141_6672f28a:



    voice "voice/e21/4100030a01.opus"
    mx "\"Tienes razón. No lo está.\""


translate english e2141_2ee4c9ca:



    voice "voice/e21/4100040a01.opus"
    mx "\"Te lo estoy pidiendo yo.\""


translate english e2141_cdd8af6b:


    "Miyuki susurra para que solo yo pueda oír."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
