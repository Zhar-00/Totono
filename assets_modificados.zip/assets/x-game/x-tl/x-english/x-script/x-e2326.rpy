

translate english e2326_579038e7:


    xy "\"Nnn... nnrgh... nn...\""


translate english e2326_25fc1c66:


    "Despierto en mitad de la noche."


translate english e2326_f16a057f:


    "Creí oír algo..."


translate english e2326_7d523c80:


    xy "\"What the? Where am I...? Aagh!\""


translate english e2326_13a102f3:


    "Mientras me levanto del suelo, me agarro la cabeza."


translate english e2326_ac1ae8ca:


    "Siento como si tuviera un bulto hinchándose ahí atrás."


translate english e2326_c7842e70:


    "Casi como si la hubiera golpeado contra algo."


translate english e2326_ca95647c:


    "A lo lejos, oigo la regadera corriendo."


translate english e2326_6e2a1d6d:


    "Parece que Miyuki está en el baño."


translate english e2326_4d0a1ab0:


    "¿Estaba sonando su teléfono, o...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
