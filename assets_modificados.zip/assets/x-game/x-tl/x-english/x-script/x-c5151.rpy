

translate english c5151_5b0fc9cb:


    xy "\"Okay, guys!\""


translate english c5151_7964714c:



    voice "voice/c51/5100020a02.opus"
    xy "\"Let's have ourselves a feast!\" \"Eat up.\" \"Yay, food!\""


translate english c5151_714a355e:


    "Los tres nos sentamos en la cima del techo con nuestro pequeño banquete."


translate english c5151_0dcdb96c:


    "Ha pasado un tiempo desde la última vez que tuvimos la oportunidad de hacer esto. Y hombre, extrañaba este sabor..."


translate english c5151_941bd988:



    voice "voice/c51/5100030a02.opus"
    aoi "\"Om, nom, nom...\""


translate english c5151_1176b5d1:



    voice "voice/c51/5100040a01.opus"
    mx "\"How is it? Is it good?\""


translate english c5151_732bc3f8:



    voice "voice/c51/5100050a02.opus"
    aoi "\"Super mega good! The best in the whole world!\""


translate english c5151_e6a52747:



    voice "voice/c51/5100060a01.opus"
    mx "\"Haha! Please! You're exaggerating.\""


translate english c5151_318a581f:



    voice "voice/c51/5100070a01.opus"
    mx "\"What about you, Shinichi?\""


translate english c5151_b99aa565:


    xy "\"Absolutely exquisite.\""


translate english c5151_4f6bb0ec:



    voice "voice/c51/5100080a01.opus"
    mx "\"Thanks.\""


translate english c5151_acd37929:



    voice "voice/c51/5100090a01.opus"
    mx "\"Oh, and be sure to savor that rolled omelette, got it?\""


translate english c5151_99660099:


    xy "\"Mm... This here?\""


translate english c5151_eeb46fd4:


    xy "\"Nom, nom, nom... Mmm. It's really good... Wait... It tastes a little different from usual...\""


translate english c5151_e4ecfb19:



    voice "voice/c51/5100100a01.opus"
    mx "\"That must be the secret ingredient I added.\""


translate english c5151_bc111da8:


    xy "\"I guess so...\""


translate english c5151_5b25d281:


    xy "\"Man, this really hits the spot. I haven't eaten a decent home-cooked meal in ages.\""


translate english c5151_41e216ac:



    voice "voice/c51/5100110a01.opus"
    mx "\"What did you have for breakfast this morning?\""


translate english c5151_dd7306d0:


    xy "\"Pizza-style toast, with ketchup, cheese, corn, and ham.\""


translate english c5151_fc13c392:



    voice "voice/c51/5100120a01.opus"
    mx "\"...Haah.\""



translate english c5151_fa4aae7e:



    voice "voice/c51/5100130a01.opus"
    mx "\"What about you, Aoi?\""


translate english c5151_8d99e664:



    voice "voice/c51/5100140a02.opus"
    aoi "\"Toast with ketchup, cheese, corn, and ham.\""


translate english c5151_3cba5c3a:



    voice "voice/c51/5100150a02.opus"
    aoi "\"Pizza-style.\""


translate english c5151_19afa4c7:



    voice "voice/c51/5100160a01.opus"
    mx "\"...I somehow doubt that's a coincidence.\""


translate english c5151_5422bb5e:


    xy "\"Well, y'know... I couldn't let Aoi stay in that manga cafe forever, so...\""


translate english c5151_2aa85df7:



    voice "voice/c51/5100170a01.opus"
    mx "\"You don't have to explain yourself.\""


translate english c5151_70fc9ff2:



    voice "voice/c51/5100180a02.opus"
    aoi "\"Boop boop? Wanna spend the night with us, Miyuki?\""


translate english c5151_4cd6af74:



    voice "voice/c51/5100190a01.opus"
    mx "\"...What?\""


translate english c5151_241d696a:



    voice "voice/c51/5100200a02.opus"
    aoi "\"We can make it a slumber party.\""


translate english c5151_1f1c5de3:



    voice "voice/c51/5100210a02.opus"
    aoi "\"It'll be fun.\""


translate english c5151_ee1294d2:



    voice "voice/c51/5100220a01.opus"
    mx "\"Wh-What are you saying?!\""


translate english c5151_14158bd4:



    voice "voice/c51/5100230a01.opus"
    mx "\"I can't possibly spend the night at a boy's house! Ridiculous! Unthinkable!\""


translate english c5151_9e9a6dd3:



    voice "voice/c51/5100240a02.opus"
    aoi "\"You and me could cuddle together?\""


translate english c5151_47155171:



    voice "voice/c51/5100250a01.opus"
    mx "\"No thank you!\""


translate english c5151_2124b0d2:



    voice "voice/c51/5100260a02.opus"
    aoi "\"We could have a threesome?\""


translate english c5151_f0bcd8c3:



    voice "voice/c51/5100270a01.opus"
    mx "\"Wh—?! I... I have no idea what that word even means!\""


translate english c5151_4f9e7003:


    "La dama protesta demasiado."


translate english c5151_698126a2:



    voice "voice/c51/5100280a02.opus"
    aoi "\"But Eru wants to cuddle, too.\""


translate english c5151_470e1464:



    voice "voice/c51/5100290a01.opus"
    mx "\"What?! Cuddling with Eru?!\""


translate english c5151_29e84dab:


    "Aoi mira de reojo al gatito que juega con su pelota de goma."


translate english c5151_7cf15acf:



    voice "voice/c51/5100300a01.opus"
    mx "\"W-Well... I... maybe...\""


translate english c5151_2c8dd2cb:



    voice "voice/c51/5100310a02.opus"
    aoi "\"Very fuzzy.\""


translate english c5151_53c1436c:



    voice "voice/c51/5100340a01.opus"
    mx "\"Nngh!\""


translate english c5151_393dd659:



    voice "voice/c51/5100330a02.opus"
    aoi "\"And warm.\""


translate english c5151_a0478b74:



    voice "voice/c51/5100350a02.opus"
    aoi "\"Toe beans.\""


translate english c5151_ea008f36:



    voice "voice/c51/5100360a01.opus"
    mx "\"Nggghh...!\""


translate english c5151_1884dab4:



    voice "voice/c51/5100370a01.opus"
    mx "\"Sh-Shinichi...! Please... Please let me...!!!\""


translate english c5151_db3ee90f:


    xy "\"Sorry. For your own good, I have to put my foot down. You and I both know you wouldn't be able to sleep a wink.\""


translate english c5151_9f546719:



    voice "voice/c51/5100380a01.opus"
    mx "\"Nnnn...!\""


translate english c5151_ce2ad8ff:


    "Miyuki empieza a hacer pucheros."


translate english c5151_e4c93264:


    "De alguna manera, siento que los tres finalmente volvemos a la normalidad."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
