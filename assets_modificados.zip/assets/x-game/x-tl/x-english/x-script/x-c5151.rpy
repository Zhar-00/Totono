

translate english c5151_5b0fc9cb:


    xy "\"¡Bien, chicos!\""


translate english c5151_7964714c:



    voice "voice/c51/5100020a02.opus"
    xy "\"¡Vamos a darnos un festín!\" \"¡A comer!\" \"¡Yay, comida!\""


translate english c5151_714a355e:


    "Los tres nos sentamos en la cima del techo con nuestro pequeño banquete."


translate english c5151_0dcdb96c:


    "Ha pasado un tiempo desde la última vez que tuvimos la oportunidad de hacer esto. Y hombre, extrañaba este sabor..."


translate english c5151_941bd988:



    voice "voice/c51/5100030a02.opus"
    aoi "\"Ñam, ñam, ñam...\""


translate english c5151_1176b5d1:



    voice "voice/c51/5100040a01.opus"
    mx "\"¿Qué tal? ¿Está bueno?\""


translate english c5151_732bc3f8:



    voice "voice/c51/5100050a02.opus"
    aoi "\"¡Súper mega bueno! ¡El mejor del mundo entero!\""


translate english c5151_e6a52747:



    voice "voice/c51/5100060a01.opus"
    mx "\"¡Jaja! ¡Por favor! Estás exagerando.\""


translate english c5151_318a581f:



    voice "voice/c51/5100070a01.opus"
    mx "\"¿Y tú, Shinichi?\""


translate english c5151_b99aa565:


    xy "\"Absolutamente exquisito.\""


translate english c5151_4f6bb0ec:



    voice "voice/c51/5100080a01.opus"
    mx "\"Gracias.\""


translate english c5151_acd37929:



    voice "voice/c51/5100090a01.opus"
    mx "\"Ah, y asegúrate de saborear esa tortilla enrollada, ¿sí?\""


translate english c5151_99660099:


    xy "\"Mm... ¿Esto?\""


translate english c5151_eeb46fd4:


    xy "\"Ñam, ñam, ñam... Mmm. Está muy bueno... Espera... Sabe un poco diferente a lo de siempre...\""


translate english c5151_e4ecfb19:



    voice "voice/c51/5100100a01.opus"
    mx "\"Debe ser el ingrediente secreto que le agregué.\""


translate english c5151_bc111da8:


    xy "\"Supongo...\""


translate english c5151_5b25d281:


    xy "\"Vaya, esto sí que llena. Hacía siglos que no comía una comida casera decente.\""


translate english c5151_41e216ac:



    voice "voice/c51/5100110a01.opus"
    mx "\"¿Qué desayunaste esta mañana?\""


translate english c5151_dd7306d0:


    xy "\"Pan tostado estilo pizza, con cátsup, queso, elote y jamón.\""


translate english c5151_fc13c392:



    voice "voice/c51/5100120a01.opus"
    mx "\"...Haah.\""



translate english c5151_fa4aae7e:



    voice "voice/c51/5100130a01.opus"
    mx "\"¿Y tú, Aoi?\""


translate english c5151_8d99e664:



    voice "voice/c51/5100140a02.opus"
    aoi "\"Pan tostado con cátsup, queso, elote y jamón.\""


translate english c5151_3cba5c3a:



    voice "voice/c51/5100150a02.opus"
    aoi "\"Estilo pizza.\""


translate english c5151_19afa4c7:



    voice "voice/c51/5100160a01.opus"
    mx "\"...De algún modo dudo que sea coincidencia.\""


translate english c5151_5422bb5e:


    xy "\"Bueno, ya sabes... No podía dejar que Aoi se quedara en ese café de manga para siempre, así que...\""


translate english c5151_2aa85df7:



    voice "voice/c51/5100170a01.opus"
    mx "\"No tienes que explicarte.\""


translate english c5151_70fc9ff2:



    voice "voice/c51/5100180a02.opus"
    aoi "\"¿Boop boop? ¿Quieres pasar la noche con nosotros, Miyuki?\""


translate english c5151_4cd6af74:



    voice "voice/c51/5100190a01.opus"
    mx "\"...¿Qué?\""


translate english c5151_241d696a:



    voice "voice/c51/5100200a02.opus"
    aoi "\"Podemos hacer una pijamada.\""


translate english c5151_1f1c5de3:



    voice "voice/c51/5100210a02.opus"
    aoi "\"Será divertido.\""


translate english c5151_ee1294d2:



    voice "voice/c51/5100220a01.opus"
    mx "\"¡¿Q-Qué estás diciendo?!\""


translate english c5151_14158bd4:



    voice "voice/c51/5100230a01.opus"
    mx "\"¡No puedo pasar la noche en casa de un chico! ¡Ridículo! ¡Impensable!\""


translate english c5151_9e9a6dd3:



    voice "voice/c51/5100240a02.opus"
    aoi "\"¿Tú y yo podríamos acurrucarnos?\""


translate english c5151_47155171:



    voice "voice/c51/5100250a01.opus"
    mx "\"¡No, gracias!\""


translate english c5151_2124b0d2:



    voice "voice/c51/5100260a02.opus"
    aoi "\"¿Podríamos hacer un trío?\""


translate english c5151_f0bcd8c3:



    voice "voice/c51/5100270a01.opus"
    mx "\"¡¿Wh—?! ¡Yo... yo no tengo ni idea de lo que significa esa palabra!\""


translate english c5151_4f9e7003:


    "La dama protesta demasiado."


translate english c5151_698126a2:



    voice "voice/c51/5100280a02.opus"
    aoi "\"Pero Eru también quiere acurrucarse.\""


translate english c5151_470e1464:



    voice "voice/c51/5100290a01.opus"
    mx "\"¡¿Qué?! ¿¿Acurrucarme con Eru??\""


translate english c5151_29e84dab:


    "Aoi mira de reojo al gatito que juega con su pelota de goma."


translate english c5151_7cf15acf:



    voice "voice/c51/5100300a01.opus"
    mx "\"B-Bueno... yo... quizá...\""


translate english c5151_2c8dd2cb:



    voice "voice/c51/5100310a02.opus"
    aoi "\"Muy peludo.\""


translate english c5151_53c1436c:



    voice "voice/c51/5100340a01.opus"
    mx "\"¡Nngh!\""


translate english c5151_393dd659:



    voice "voice/c51/5100330a02.opus"
    aoi "\"Y calentito.\""


translate english c5151_a0478b74:



    voice "voice/c51/5100350a02.opus"
    aoi "\"Almohadillas.\""


translate english c5151_ea008f36:



    voice "voice/c51/5100360a01.opus"
    mx "\"¡Nggghh...!\""


translate english c5151_1884dab4:



    voice "voice/c51/5100370a01.opus"
    mx "\"¡Sh-Shinichi...! ¡Por favor... por favor déjame...!\""


translate english c5151_db3ee90f:


    xy "\"Lo siento. Por tu propio bien, tengo que ser firme. Tú y yo sabemos que no podrías dormir ni un parpadeo.\""


translate english c5151_9f546719:



    voice "voice/c51/5100380a01.opus"
    mx "\"¡Nnnn...!\""


translate english c5151_ce2ad8ff:


    "Miyuki empieza a hacer pucheros."


translate english c5151_e4c93264:


    "De alguna manera, siento que los tres finalmente volvemos a la normalidad."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
