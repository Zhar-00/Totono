

translate english a2194_f3c7f137:



    voice "voice/a21/9400010a02.opus"
    aoi "\"Shinichi!\""


translate english a2194_787d4cf3:


    xy "\"Hm?\""


translate english a2194_b4eaa056:



    voice "voice/a21/9400020a02.opus"
    aoi "\"What do you think...?\""


translate english a2194_0accd139:


    xy "\"\"\"\"......\"?!?!\" \"\"......\"?!?!\"\"\""


translate english a2194_b0fd23f5:



    voice "voice/a21/9400030a02.opus"
    aoi "\"Boop boop...?\""


translate english a2194_0accd139_1:


    xy "\"\"\"\"......\"?!?!\" \"\"......\"?!?!\"\"\""


translate english a2194_9f100932:



    voice "voice/a21/9400040a02.opus"
    aoi "\"Shinichi?\""


translate english a2194_492189a5:


    xy "\"O-Oh, uh, yeah, looks great! Totally!\""


translate english a2194_7294ba06:



    voice "voice/a21/9400050a02.opus"
    aoi "\"You're so nice... Thank you.\""


translate english a2194_43805a71:


    "La sonrisa tímida de Aoi es increíblemente adorable..."


translate english a2194_083e8d7a:


    "Aparto la mirada rápidamente y busco refuerzos."


translate english a2194_183617a2:


    xy "\"Right, Miyuki?\""


translate english a2194_b371d545:



    voice "voice/a21/9400060a01.opus"
    mx "\"\"\"\"......\"?!?!\" \"\"......\"?!?!\"\"\""


translate english a2194_1551c702:


    xy "\"Miyuki!\""


translate english a2194_9d3a08ac:



    voice "voice/a21/9400070a01.opus"
    mx "\"R-Right... What was the question?\""


translate english a2194_58dccbd3:


    "Aoi también te ha cautivado, supongo."


translate english a2194_893a1a12:


    xy "\"Anyway, it's getting pretty dark out.\""


translate english a2194_501a5d5c:



    voice "voice/a21/9400080a01.opus"
    mx "\"Yeah... We'd better head home.\""


translate english a2194_743792d0:



    voice "voice/a21/9400090a02.opus"
    aoi "\"This is goodbye, then.\""


translate english a2194_085462c5:



    voice "voice/a21/9400100a01.opus"
    mx "\"Oh, right.\""


translate english a2194_bbe5ec80:


    "Pensándolo bien, el manga café está justo ahí."


translate english a2194_8fd05edc:


    xy "\"Wait, why'd you take off your hairpin?\""


translate english a2194_b3d38c8e:



    voice "voice/a21/9400110a02.opus"
    aoi "\"Saving it for special moments.\""


translate english a2194_c2ce4c17:


    xy "\"Special in what way?\""


translate english a2194_8fed13a3:



    voice "voice/a21/9400120a02.opus"
    aoi "\"Moments that mean a lot to me.\""


translate english a2194_10a8386f:



    voice "voice/a21/9400130a02.opus"
    aoi "\"Until then, it'll stay in my pocket for safekeeping.\""


translate english a2194_63b7147c:


    "La verdad me halaga que quiera cuidar tan bien mi regalo."


translate english a2194_e6737ff0:



    voice "voice/a21/9400140a02.opus"
    aoi "\"Bye-bye.\""


translate english a2194_b1a245ad:



    voice "voice/a21/9400150a01.opus"
    mx "\"Thanks for today.\""


translate english a2194_ecb79cf0:


    xy "\"See you tomorrow!\""


translate english a2194_ab0ee601:



    voice "voice/a21/9400160a02.opus"
    aoi "\"Got it!\""


translate english a2194_34a96bef:


    xy "\"What's up?\""


translate english a2194_305809fb:



    voice "voice/a21/9400170a02.opus"
    aoi "\"This is your big chance to confess your love.\""


translate english a2194_4f355834:



    voice "voice/a21/9400180a01.opus"
    mx "\"......?!?!\" \"......?!?!\""


translate english a2194_35bb3f28:


    "De golpe, nos toma a los dos totalmente por sorpresa."


translate english a2194_302802e0:


    xy "¡Aoi! Deja de hacer tonterías—{nw=1}"


translate english a2194_51c349d3:


    xy "\"—Wait, what the? Where'd she go?\""


translate english a2194_85c7696f:


    "Miro a mi alrededor, pero es como si se hubiera desvanecido en el aire."


translate english a2194_b0e12391:


    xy "\"Haah... What an oddball...\""


translate english a2194_71c24a29:



    voice "voice/a21/9400190a01.opus"
    mx "\"\"\"\"......\"?!?!\" \"\"......\"?!?!\"\"\""


translate english a2194_00b0ecf9:


    xy "\"Right, Miyuki?\""


translate english a2194_b7f43a76:



    voice "voice/a21/9400200a01.opus"
    mx "\"Huh? O-Oh, right. Sorry, what?\""


translate english a2194_24f93e17:


    "Al parecer Miyuki no estaba escuchando."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
