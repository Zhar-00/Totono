

translate english e2122d_0cefc9a7:



    voice "voice/e21/22d00010a01.opus"
    mx "\"Did you piss him off?\""



translate english e2122d_84658cee:


    xy "\"Apparently.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
