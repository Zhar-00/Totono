

translate english e2122d_0cefc9a7:



    voice "voice/e21/22d00010a01.opus"
    mx "\"¿Lo hiciste enojar?\""



translate english e2122d_84658cee:


    xy "\"Aparentemente.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
