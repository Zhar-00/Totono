

translate english e2165a_49923519:


    "Lo agarro y me apresuro a la caja."


translate english e2165a_cf197681:


    xy "\"Here's a token of my gratitude... for everything you do for me each day.\""


translate english e2165a_73e499dc:



    voice "voice/e21/6500030a01.opus"
    mx "\"Hehehe...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
