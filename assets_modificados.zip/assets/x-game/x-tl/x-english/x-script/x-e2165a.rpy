

translate english e2165a_49923519:


    "Lo agarro y me apresuro a la caja."


translate english e2165a_cf197681:


    xy "\"Aquí tienes una muestra de mi gratitud... por todo lo que haces por mí cada día.\""


translate english e2165a_73e499dc:



    voice "voice/e21/6500030a01.opus"
    mx "\"Jejeje...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
