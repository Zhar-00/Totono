

translate english a7141_f285dbf2:



    voice "voice/a71/4100010a01.opus"
    mx "\"Come on, hurry up!\""


translate english a7141_132f43c5:


    xy "\"What's the rush?\""


translate english a7141_68d95c33:


    "Sigo a Miyuki hasta la azotea, donde la luz del sol brilla sobre el concreto."


translate english a7141_09e40de9:


    xy "\"Why bother coming up here? We don't have to hide it from anyone, you know.\""


translate english a7141_53e473b5:



    voice "voice/a71/4100020a01.opus"
    mx "\"\"\"\"\"\"..................\"\"\"Yeah.\"\"\""


translate english a7141_06e3d5b7:


    xy "\"Seriously, what's got you so pissy?\""


translate english a7141_3099b68b:



    voice "voice/a71/4100030a01.opus"
    mx "\"I'm NOT pissy.\""


translate english a7141_54dc886f:


    xy "\"Yes, you are. It's extremely obvious.\""


translate english a7141_c0895854:



    voice "voice/a71/4100040a01.opus"
    mx "\"If it's so 'obvious,' then hurry up and figure out why I brought you up here!\""


translate english a7141_91a866f5:


    xy "\"Uhh...\""


translate english a7141_25aaacaa:


    "Rascándome la cabeza, miro alrededor."


translate english a7141_6549a6d2:


    xy "\"Because the weather's nice today?\""


translate english a7141_bdd10f14:



    voice "voice/a71/4100050a01.opus"
    mx "\"No.\""


translate english a7141_1a7168ca:


    xy "\"Because the view from up here is so pretty?\""


translate english a7141_3a074107:



    voice "voice/a71/4100060a01.opus"
    mx "\"No!\""


translate english a7141_f8a19c80:


    xy "\"Okay then, uhh...\""


translate english a7141_5e7260fd:


    xy "\"Because you want to kiss me?\""


translate english a7141_845f8dbe:



    voice "voice/a71/4100070a01.opus"
    mx "\"Wha—?!\""


translate english a7141_b8e96fac:



    voice "voice/a71/4100080a01.opus"
    mx "\"Wh-What kind of stupid guess is that?!\""


translate english a7141_371d87a2:



    voice "voice/a71/4100090a01.opus"
    mx "\"Quit messing around and THINK!\""


translate english a7141_643ea744:


    "Supongo que fui un poco demasiado lejos con la última..."


translate english a7141_fd111f03:


    "Mmm... ¿Qué otra razón podría haber?"


translate english a7141_3e191d07:


    xy "\"Can I get a hint?\""


translate english a7141_4071ee33:



    voice "voice/a71/4100100a01.opus"
    mx "\"...Fine, I guess I'll throw you a bone.\""


translate english a7141_b9b612aa:



    voice "voice/a71/4100110a01.opus"
    mx "\"This place is obviously special to me, but... technically anywhere would be special today.\""


translate english a7141_2a7c0d83:


    xy "\"So the location doesn't matter?\""


translate english a7141_f584997a:



    voice "voice/a71/4100120a01.opus"
    mx "\"The important part is that we're together, I guess.\""


translate english a7141_7b8d1f65:



    voice "voice/a71/4100130a01.opus"
    mx "\"Or rather, the problem is with everyone else. You know what I mean...\""


translate english a7141_55938556:


    xy "\"Oh, so you just wanted to be alone together?\""


translate english a7141_5ecca303:



    voice "voice/a71/4100140a01.opus"
    mx "\"\"\"\"\"\"..................\"\"\"Yeah.\"\"\""


translate english a7141_796e8e67:



    voice "voice/a71/4100150a01.opus"
    mx "\"......Yeah.\""


translate english a7141_68855614:


    "Murmura, haciendo un pequeño puchero."


translate english a7141_485d4de7:



    voice "voice/a71/4100160a01.opus"
    mx "\"I mean, we're together now, after all...\""


translate english a7141_055dc9da:



    voice "voice/a71/4100170a01.opus"
    mx "\"Obviously I want you all to myself during lunch.\""


translate english a7141_2e315849:



    voice "voice/a71/4100180a01.opus"
    mx "\"...Ugh! God!\""


translate english a7141_b67872f4:



    voice "voice/a71/4100190a01.opus"
    mx "\"You're so dense when it comes to the stuff that matters!\""


translate english a7141_e29f0cb8:


    xy "\"I'm sorry...\""


translate english a7141_ab87fe76:


    "Lo único que puedo hacer es disculparme."


translate english a7141_e4121b50:


    "Juntos, tendemos una manta y nos sentamos sobre la azotea."


translate english a7141_f67f3696:


    "Como de costumbre, su almuerzo es casero y ridículamente enorme: un suntuoso festín. Hoy, el plato principal es anguila kabayaki."


translate english a7141_b08143a0:


    "Naturalmente, está perfectamente sazonado, y el sabor es tan exquisito que ni podría empezar a describirlo."


translate english a7141_9fe27f75:


    "Mientras tanto, Miyuki se sienta a mi lado, mirándome comer con una expresión que dice que se muere por saber qué opino."


translate english a7141_71e3c608:


    "Así que rebusco en mi limitado vocabulario—"


translate english a7141_644a9a3f:


    xy "\"This is, like, crazy good!\""


translate english a7141_ee421d80:


    "A pesar de mi absoluto y total fracaso en sonar remotamente elocuente, Miyuki no se queja."


translate english a7141_c04158d6:



    voice "voice/a71/4100200a01.opus"
    mx "\"...Thank you.\""


translate english a7141_3f1368c8:


    "Sus mejillas se tiñen de rosa."


translate english a7141_128aef95:


    "Parece que al final estamos en la misma sintonía."


translate english a7141_7ac69e89:


    "A veces siento que no encuentro las palabras correctas, pero al final resulta que no necesitaba esforzarme."


translate english a7141_b1f4c27a:


    xy "\"I like it when you're like this.\""


translate english a7141_d4ce6d42:



    voice "voice/a71/4100210a01.opus"
    mx "\"Huh...?\""


translate english a7141_a0066ecf:


    xy "\"You know, when you don't have to put on airs. It's like you're back to your normal self.\""


translate english a7141_5888fa3f:



    voice "voice/a71/4100220a01.opus"
    mx "\"Oh... I guess so.\""


translate english a7141_e8ebbf74:


    xy "\"...Why the long face?\""


translate english a7141_d58d58b4:



    voice "voice/a71/4100230a01.opus"
    mx "\"Well... You know how, back at the batting cages, you told me I put too much effort into my act?\""


translate english a7141_3211cf9d:



    voice "voice/a71/4100240a01.opus"
    mx "\"I actually kind of agree with you.\""


translate english a7141_570e3578:



    voice "voice/a71/4100250a01.opus"
    mx "\"If possible, I'd like to have the freedom to be myself around the others, even just a little bit.\""


translate english a7141_34e47f49:



    voice "voice/a71/4100260a01.opus"
    mx "\"But I'm scared of opening myself up like that.\""


translate english a7141_4cdab94f:


    xy "\"Wow... I had no idea you even cared about that kinda stuff.\""


translate english a7141_c912a92b:



    voice "voice/a71/4100270a01.opus"
    mx "\"I... I'm human too, you know!\""


translate english a7141_f5ba930f:


    xy "\"I mean, you seem to be getting along just fine in class.\""


translate english a7141_1d7c01a7:



    voice "voice/a71/4100280a01.opus"
    mx "\"...Key word, 'seem'.\""


translate english a7141_88de2f6c:


    xy "\"The way I see it, you can just fake it 'til you make it. Besides, it's normal to change how you act based on where you are and who you're with.\""


translate english a7141_c2c2cd17:


    xy "\"You don't need to force yourself to open up all the way.\""


translate english a7141_fe9cc4d7:



    voice "voice/a71/4100290a01.opus"
    mx "\"...You really think so?\""


translate english a7141_971996e3:


    xy "\"If it ever gets to be too suffocating, just come find me. You can open up to me as much as you want.\""


translate english a7141_3add59a8:


    xy "\"I mean, personally, I'd rather have the 'real you' all to myself, if we're being honest.\""


translate english a7141_275ca038:



    voice "voice/a71/4100300a01.opus"
    mx "\"Oh... O-Okay.\""


translate english a7141_626f9bce:



    voice "voice/a71/4100310a01.opus"
    mx "\"Same here... I want you all to myself, too...\""


translate english a7141_0accd139:


    xy "\"\"\"\"\"\"..................\"\"\"Yeah.\"\"\""


translate english a7141_2d5c3902:



    voice "voice/a71/4100320a01.opus"
    mx "\"\"\"\"\"\"..................\"\"\"Yeah.\"\"\""


translate english a7141_9d75f063:



    voice "voice/a71/4100330a01.opus"
    mx "\"W-Well?! Say something!\""


translate english a7141_ed5ccbb2:


    xy "\"Huh? Oh, uh...\""


translate english a7141_278ecdb2:


    xy "\"...Thanks...?\""


translate english a7141_6e752366:


    "Vaya, qué respuesta de imbécil. Bien hecho, yo."


translate english a7141_caec7323:



    voice "voice/a71/4100340a01.opus"
    mx "\"L-Let's hurry up and eat! Lunch will be over before we know it!\""


translate english a7141_1984ee9e:


    xy "\"R-Right!\""


translate english a7141_d555d4cf:


    "Así sin más, nuestro receso de almuerzo ya va por la mitad."


translate english a7141_8773d312:


    "Pero estoy tan concentrado en Miyuki que apenas puedo comer."


translate english a7141_3338fbc7:


    "Para calmarme, tomo un sorbo de mi Yabaley—"


translate english a7141_0accd139_1:


    xy "\"\"\"\"\"\"..................\"\"\"Yeah.\"\"\""


translate english a7141_a96ef298:



    voice "voice/a71/4100350a01.opus"
    mx "\"What's wrong?\""


translate english a7141_3de8e555:


    xy "\"Oh, nothing. This stuff is gross, that's all.\""


translate english a7141_93d39a9d:



    voice "voice/a71/4100360a01.opus"
    mx "\"Well, why'd you buy it, then? Are you on a health kick or something?\""


translate english a7141_639e4f6f:


    xy "\"No, no, it's nothing like that.\""


translate english a7141_85ef0504:


    "He estado comprando este asqueroso jugo de tomate desde que tengo memoria."


translate english a7141_518b1aea:


    "¿Por qué sigo comprándolo si ni siquiera me gusta?"


translate english a7141_dc3e5f80:



    voice "voice/a71/4100370a01.opus"
    mx "\"S-Say, um...!\""


translate english a7141_81d1893b:


    xy "\"Hm? What's up, Miyuki?\""


translate english a7141_1b949b11:



    voice "voice/a71/4100380a01.opus"
    mx "\"I have a... question.\""


translate english a7141_5ef9e145:



    voice "voice/a71/4100390a01.opus"
    mx "\"Shinichi... are you, um...\""


translate english a7141_575c861c:



    voice "voice/a71/4100400a01.opus"
    mx "\"...Are you into maid outfits and stuff?\""


translate english a7141_06a659bb:


    xy "\"Come again?\""


translate english a7141_dc29c02a:



    voice "voice/a71/4100410a01.opus"
    mx "\"Uhh, actually, never mind! I take it back!\""


translate english a7141_e726dc47:


    xy "\"Whoa, whoa! No take-backsies! I'm gonna need you to repeat that!\""


translate english a7141_c31783ee:



    voice "voice/a71/4100420a01.opus"
    mx "\"Shinichi, you're scaring me!\""


translate english a7141_d3751f36:


    xy "\"There's nothing to be afraid of!\""


translate english a7141_0e3e13d1:



    voice "voice/a71/4100430a01.opus"
    mx "\"You're acting like Akebono-kun!\""


translate english a7141_94c5f216:


    xy "\"My bad. I'll calm down.\""


translate english a7141_6b88afb5:



    voice "voice/a71/4100440a01.opus"
    mx "\"...Thank you.\""


translate english a7141_9355eef7:



    voice "voice/a71/4100450a01.opus"
    mx "\"Sorry for the random dumb question. I shouldn't have asked.\""


translate english a7141_f4304552:


    "Ambos hacemos una pausa para respirar."


translate english a7141_2624ef7b:


    xy "\"So, where did THAT come from?\""


translate english a7141_5835de3f:



    voice "voice/a71/4100460a01.opus"
    mx "\"Well, you were talking about it this morning...\""


translate english a7141_dcd3814a:



    voice "voice/a71/4100470a01.opus"
    mx "\"Something about dreams or whatever...\""


translate english a7141_6586fdbc:


    "...Ah, cierto."


translate english a7141_b9006813:


    "Ay, Dios, esto es tan vergonzoso."


translate english a7141_5cd77695:


    "Siento que acabo de soltar todos mis fetiches raros frente a toda la clase."


translate english a7141_6c152e53:


    "........"



translate english a7141_420b1ee5:


    "Espera, ¡no!"


translate english a7141_48b5daba:


    "¡No soy raro!"


translate english a7141_4d131873:


    "¡Soy un don nadie!"


translate english a7141_8e490959:


    "¡Así que eso significa que mis fetiches son, como máximo, completamente promedio!"



translate english a7141_e8d4aec4:


    "...¡Probablemente!"


translate english a7141_4db8acd2:


    "El punto es que necesito que ella piense que soy normal."


translate english a7141_a65557da:



    voice "voice/a71/4100480a01.opus"
    mx "\"S-Say, um... If I wore a maid outfit—\""


translate english a7141_58396b8f:


    xy "\"I'd love it!\""


translate english a7141_107b5c5c:



    voice "voice/a71/4100490a01.opus"
    mx "\"Huh?!\""


translate english a7141_900b0896:


    xy "\"...I mean, I'm sure it would look very nice.\""


translate english a7141_c19008eb:


    "¡Actúa con calma, amigo!"


translate english a7141_7515dd29:


    "¡La estás asustando!"


translate english a7141_255db989:


    "¡Tenemos que ser caballerosos con esto!"


translate english a7141_dcc40ba0:


    xy "\"It's just a fun idea I had. Ultimately, the clothes aren't what matters most.\""


translate english a7141_321dae1a:



    voice "voice/a71/4100500a01.opus"
    mx "\"Th-They aren't...?\""


translate english a7141_f353a9ac:


    xy "\"Of course not... What kind of skeeze do you think I am? Haha...\""


translate english a7141_f333fa0c:


    xy "\"What matters most is who you are on the inside...!\""


translate english a7141_3e82e2e5:


    xy "\"A girl could wear designer clothes for all I care... But if her personality's bad, that's a deal-breaker!\""


translate english a7141_44721b46:


    xy "\"When it comes to someone I'm in love with, they automatically look great in anything!\""


translate english a7141_ae509174:



    voice "voice/a71/4100510a01.opus"
    mx "\"Oh, I get it! Right!\""


translate english a7141_cd4de1cb:



    voice "voice/a71/4100520a01.opus"
    mx "\"That's good to hear.\""


translate english a7141_f2083798:



    voice "voice/a71/4100530a01.opus"
    mx "\"I mean, maid uniforms are kinda degrading, you know?\""


translate english a7141_cf69aaa2:


    "¡Nnngh!"


translate english a7141_275dcaa7:


    "¿Q... Qué fue eso...?"


translate english a7141_e2db45d9:


    "¿Por qué me siento tan destrozado...?"


translate english a7141_0b12d40a:



    voice "voice/a71/4100540a01.opus"
    mx "\"Shinichi? You look a little—\""


translate english a7141_ddaf1be0:


    xy "\"It's nothing! Anyway, I'm surprised you feel that way! I mean, you wear all kinds of costumes for your plays, right?\""


translate english a7141_a80c0883:


    xy "\"Surely a maid outfit isn't that much d—\""


translate english a7141_6f0bda9e:



    voice "voice/a71/4100550a01.opus"
    mx "\"But it wouldn't be for a play, so... it'd just be embarrassing.\""


translate english a7141_cd00f1fa:


    "Lo imaginé..."


translate english a7141_609ba1f8:


    "Por alguna razón, no puedo sacudirme esta sensación de haber perdido la oportunidad de mi vida..."




translate english a7141_daa77d7a:


    xy "\"..................\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
