

translate english a7141_f285dbf2:



    voice "voice/a71/4100010a01.opus"
    mx "\"¡Vamos, apúrense!\""


translate english a7141_132f43c5:


    xy "\"¿Cuál es la prisa?\""


translate english a7141_68d95c33:


    "Sigo a Miyuki hasta la azotea, donde la luz del sol brilla sobre el concreto."


translate english a7141_09e40de9:


    xy "\"¿Por qué molestarse en subir aquí? No tenemos que esconderlo de nadie, sabes.\""


translate english a7141_53e473b5:



    voice "voice/a71/4100020a01.opus"
    mx "\"\"\"\"\"\"..................\"\"\"Yeah.\"\"\""


translate english a7141_06e3d5b7:


    xy "\"En serio, ¿qué te tiene tan de malas?\""


translate english a7141_3099b68b:



    voice "voice/a71/4100030a01.opus"
    mx "\"No estoy de malas.\""


translate english a7141_54dc886f:


    xy "\"Sí lo estás. Es extremadamente obvio.\""


translate english a7141_c0895854:



    voice "voice/a71/4100040a01.opus"
    mx "\"Si es tan \"obvio\", ¡pues apúrate y descubre por qué te traje aquí!\""


translate english a7141_91a866f5:


    xy "\"Ehh...\""


translate english a7141_25aaacaa:


    "Rascándome la cabeza, miro alrededor."


translate english a7141_6549a6d2:


    xy "\"¿Porque hace buen clima hoy?\""


translate english a7141_bdd10f14:



    voice "voice/a71/4100050a01.opus"
    mx "\"No.\""


translate english a7141_1a7168ca:


    xy "\"¿Porque la vista desde aquí es muy bonita?\""


translate english a7141_3a074107:



    voice "voice/a71/4100060a01.opus"
    mx "\"¡No!\""


translate english a7141_f8a19c80:


    xy "\"Bueno entonces, ehh...\""


translate english a7141_5e7260fd:


    xy "\"¿Porque quieres besarme?\""


translate english a7141_845f8dbe:



    voice "voice/a71/4100070a01.opus"
    mx "\"¿¡Qué—!?\""


translate english a7141_b8e96fac:



    voice "voice/a71/4100080a01.opus"
    mx "\"¿¡Q-Qué clase de conjetura tonta es esa!?\""


translate english a7141_371d87a2:



    voice "voice/a71/4100090a01.opus"
    mx "\"¡Deja de hacer el tonto y PIENSA!\""


translate english a7141_643ea744:


    "Supongo que fui un poco demasiado lejos con la última..."


translate english a7141_fd111f03:


    "Mmm... ¿Qué otra razón podría haber?"


translate english a7141_3e191d07:


    xy "\"¿Me das una pista?\""


translate english a7141_4071ee33:



    voice "voice/a71/4100100a01.opus"
    mx "\"...Bien, supongo que te lanzaré un hueso.\""


translate english a7141_b9b612aa:



    voice "voice/a71/4100110a01.opus"
    mx "\"Obviamente este lugar es especial para mí, pero... técnicamente cualquier lugar sería especial hoy.\""


translate english a7141_2a7c0d83:


    xy "\"¿Así que el lugar no importa?\""


translate english a7141_f584997a:



    voice "voice/a71/4100120a01.opus"
    mx "\"Lo importante es que estamos juntos, supongo.\""


translate english a7141_7b8d1f65:



    voice "voice/a71/4100130a01.opus"
    mx "\"O más bien, el problema es con todos los demás. Sabes a qué me refiero...\""


translate english a7141_55938556:


    xy "\"Oh, ¿así que solo querías estar solos juntos?\""


translate english a7141_5ecca303:



    voice "voice/a71/4100140a01.opus"
    mx "\"\"\"\"\"\"..................\"\"\"Yeah.\"\"\""


translate english a7141_796e8e67:



    voice "voice/a71/4100150a01.opus"
    mx "\"......Sí.\""


translate english a7141_68855614:


    "Murmura, haciendo un pequeño puchero."


translate english a7141_485d4de7:



    voice "voice/a71/4100160a01.opus"
    mx "\"O sea, ahora estamos juntos, después de todo...\""


translate english a7141_055dc9da:



    voice "voice/a71/4100170a01.opus"
    mx "\"Obviamente te quiero solo para mí durante el almuerzo.\""


translate english a7141_2e315849:



    voice "voice/a71/4100180a01.opus"
    mx "\"...¡Ugh! ¡Dios!\""


translate english a7141_b67872f4:



    voice "voice/a71/4100190a01.opus"
    mx "\"¡Eres tan denso cuando se trata de lo que importa!\""


translate english a7141_e29f0cb8:


    xy "\"Lo siento...\""


translate english a7141_ab87fe76:


    "Lo único que puedo hacer es disculparme."


translate english a7141_e4121b50:


    "Juntos, tendemos una manta y nos sentamos sobre la azotea."


translate english a7141_f67f3696:


    "Como de costumbre, su almuerzo es casero y ridículamente enorme: un suntuoso festín. Hoy, el plato principal es anguila kabayaki."


translate english a7141_b08143a0:


    "Naturalmente, está perfectamente sazonado, y el sabor es tan exquisito que ni podría empezar a describirlo."


translate english a7141_9fe27f75:


    "Mientras tanto, Miyuki se sienta a mi lado, mirándome comer con una expresión que dice que se muere por saber qué opino."


translate english a7141_71e3c608:


    "Así que rebusco en mi limitado vocabulario—"


translate english a7141_644a9a3f:


    xy "\"¡Esto está, o sea, increíblemente bueno!\""


translate english a7141_ee421d80:


    "A pesar de mi absoluto y total fracaso en sonar remotamente elocuente, Miyuki no se queja."


translate english a7141_c04158d6:



    voice "voice/a71/4100200a01.opus"
    mx "\"...Gracias.\""


translate english a7141_3f1368c8:


    "Sus mejillas se tiñen de rosa."


translate english a7141_128aef95:


    "Parece que al final estamos en la misma sintonía."


translate english a7141_7ac69e89:


    "A veces siento que no encuentro las palabras correctas, pero al final resulta que no necesitaba esforzarme."


translate english a7141_b1f4c27a:


    xy "\"Me gusta cuando eres así.\""


translate english a7141_d4ce6d42:



    voice "voice/a71/4100210a01.opus"
    mx "\"¿Eh...?\""


translate english a7141_a0066ecf:


    xy "\"Ya sabes, cuando no tienes que aparentar. Es como si volvieras a ser tú mismo.\""


translate english a7141_5888fa3f:



    voice "voice/a71/4100220a01.opus"
    mx "\"Oh... Supongo que sí.\""


translate english a7141_e8ebbf74:


    xy "\"...¿Por qué la cara larga?\""


translate english a7141_d58d58b4:



    voice "voice/a71/4100230a01.opus"
    mx "\"Bueno... Ya sabes cómo, allá en las jaulas de bateo, me dijiste que me esforzaba demasiado en mi actuación.\""


translate english a7141_3211cf9d:



    voice "voice/a71/4100240a01.opus"
    mx "\"De hecho, más o menos estoy de acuerdo contigo.\""


translate english a7141_570e3578:



    voice "voice/a71/4100250a01.opus"
    mx "\"Si es posible, me gustaría tener la libertad de ser yo misma con los demás, aunque sea un poquito.\""


translate english a7141_34e47f49:



    voice "voice/a71/4100260a01.opus"
    mx "\"Pero me da miedo abrirme así.\""


translate english a7141_4cdab94f:


    xy "\"Guau... No tenía idea de que te importaran esas cosas.\""


translate english a7141_c912a92b:



    voice "voice/a71/4100270a01.opus"
    mx "\"¡Yo... también soy humana, sabes!\""


translate english a7141_f5ba930f:


    xy "\"O sea, parece que te llevas bien en clase.\""


translate english a7141_1d7c01a7:



    voice "voice/a71/4100280a01.opus"
    mx "\"...Palabra clave, \"parece\".\""


translate english a7141_88de2f6c:


    xy "\"Como yo lo veo, puedes fingirlo hasta que lo logres. Además, es normal cambiar la forma en que actúas según dónde estés y con quién.\""


translate english a7141_c2c2cd17:


    xy "\"No necesitas forzarte a abrirte del todo.\""


translate english a7141_fe9cc4d7:



    voice "voice/a71/4100290a01.opus"
    mx "\"...¿De verdad lo crees?\""


translate english a7141_971996e3:


    xy "\"Si alguna vez se vuelve demasiado sofocante, ven a buscarme. Puedes abrirte conmigo todo lo que quieras.\""


translate english a7141_3add59a8:


    xy "\"O sea, en lo personal, preferiría tener al \"verdadero tú\" solo para mí, siendo honestos.\""


translate english a7141_275ca038:



    voice "voice/a71/4100300a01.opus"
    mx "\"Oh... O-Okay.\""


translate english a7141_626f9bce:



    voice "voice/a71/4100310a01.opus"
    mx "\"Yo también... yo también te quiero solo para mí...\""


translate english a7141_0accd139:


    xy "\"\"\"\"\"\"..................\"\"\"Yeah.\"\"\""


translate english a7141_2d5c3902:



    voice "voice/a71/4100320a01.opus"
    mx "\"\"\"\"\"\"..................\"\"\"Yeah.\"\"\""


translate english a7141_9d75f063:



    voice "voice/a71/4100330a01.opus"
    mx "\"¡¿Y b-bueno?! ¡Di algo!\""


translate english a7141_ed5ccbb2:


    xy "\"¿Eh? Oh, eh...\""


translate english a7141_278ecdb2:


    xy "\"...¿Gracias...?\""


translate english a7141_6e752366:


    "Vaya, qué respuesta de imbécil. Bien hecho, yo."


translate english a7141_caec7323:



    voice "voice/a71/4100340a01.opus"
    mx "\"¡A-Apúrate y comamos! ¡El almuerzo se acabará antes de que nos demos cuenta!\""


translate english a7141_1984ee9e:


    xy "\"¡C-Cierto!\""


translate english a7141_d555d4cf:


    "Así sin más, nuestro receso de almuerzo ya va por la mitad."


translate english a7141_8773d312:


    "Pero estoy tan concentrado en Miyuki que apenas puedo comer."


translate english a7141_3338fbc7:


    "Para calmarme, tomo un sorbo de mi Yabaley—"


translate english a7141_0accd139_1:


    xy "\"\"\"\"\"\"..................\"\"\"Yeah.\"\"\""


translate english a7141_a96ef298:



    voice "voice/a71/4100350a01.opus"
    mx "\"¿Qué pasa?\""


translate english a7141_3de8e555:


    xy "\"Oh, nada. Esta cosa es asquerosa, eso es todo.\""


translate english a7141_93d39a9d:



    voice "voice/a71/4100360a01.opus"
    mx "\"Bueno, ¿y por qué la compraste entonces? ¿Estás en plan saludable o algo?\""


translate english a7141_639e4f6f:


    xy "\"No, no, no es nada de eso.\""


translate english a7141_85ef0504:


    "He estado comprando este asqueroso jugo de tomate desde que tengo memoria."


translate english a7141_518b1aea:


    "¿Por qué sigo comprándolo si ni siquiera me gusta?"


translate english a7141_dc3e5f80:



    voice "voice/a71/4100370a01.opus"
    mx "\"¡D-Dime, em...!\""


translate english a7141_81d1893b:


    xy "\"¿Hm? ¿Qué pasa, Miyuki?\""


translate english a7141_1b949b11:



    voice "voice/a71/4100380a01.opus"
    mx "\"Tengo una... pregunta.\""


translate english a7141_5ef9e145:



    voice "voice/a71/4100390a01.opus"
    mx "\"Shinichi... ¿tú, em...\""


translate english a7141_575c861c:



    voice "voice/a71/4100400a01.opus"
    mx "\"...¿Te gustan los atuendos de empleada y esas cosas?\""


translate english a7141_06a659bb:


    xy "\"¿Cómo dices?\""


translate english a7141_dc29c02a:



    voice "voice/a71/4100410a01.opus"
    mx "\"Ehh, ¡en realidad, olvídalo! ¡Retiro la pregunta!\""


translate english a7141_e726dc47:


    xy "\"¡Espera, espera! ¡No hay devoluciones! ¡Voy a necesitar que repitas eso!\""


translate english a7141_c31783ee:



    voice "voice/a71/4100420a01.opus"
    mx "\"¡Shinichi, me estás asustando!\""


translate english a7141_d3751f36:


    xy "\"¡No hay nada que temer!\""


translate english a7141_0e3e13d1:



    voice "voice/a71/4100430a01.opus"
    mx "\"¡Estás actuando como Akebono-kun!\""


translate english a7141_94c5f216:


    xy "\"Mi culpa. Me calmaré.\""


translate english a7141_6b88afb5:



    voice "voice/a71/4100440a01.opus"
    mx "\"...Gracias.\""


translate english a7141_9355eef7:



    voice "voice/a71/4100450a01.opus"
    mx "\"Perdón por la pregunta tonta al azar. No debí preguntar.\""


translate english a7141_f4304552:


    "Ambos hacemos una pausa para respirar."


translate english a7141_2624ef7b:


    xy "\"Entonces, ¿de dónde salió ESO?\""


translate english a7141_5835de3f:



    voice "voice/a71/4100460a01.opus"
    mx "\"Bueno, estabas hablando de eso esta mañana...\""


translate english a7141_dcd3814a:



    voice "voice/a71/4100470a01.opus"
    mx "\"Algo sobre sueños o lo que sea...\""


translate english a7141_6586fdbc:


    "...Ah, cierto."


translate english a7141_b9006813:


    "Ay, Dios, esto es tan vergonzoso."


translate english a7141_5cd77695:


    "Siento que acabo de soltar todos mis fetiches raros frente a toda la clase."


translate english a7141_6c152e53:


    "........"



translate english a7141_420b1ee5:


    "Espera, ¡no!"


translate english a7141_48b5daba:


    "¡No soy raro!"


translate english a7141_4d131873:


    "¡Soy un don nadie!"


translate english a7141_8e490959:


    "¡Así que eso significa que mis fetiches son, como máximo, completamente promedio!"



translate english a7141_e8d4aec4:


    "...¡Probablemente!"


translate english a7141_4db8acd2:


    "El punto es que necesito que ella piense que soy normal."


translate english a7141_a65557da:



    voice "voice/a71/4100480a01.opus"
    mx "\"D-Dime, em... Si usara un atuendo de empleada—\""


translate english a7141_58396b8f:


    xy "\"¡Me encantaría!\""


translate english a7141_107b5c5c:



    voice "voice/a71/4100490a01.opus"
    mx "\"¿¡Eh!?\""


translate english a7141_900b0896:


    xy "\"...O sea, estoy seguro de que se vería muy bien.\""


translate english a7141_c19008eb:


    "¡Actúa con calma, amigo!"


translate english a7141_7515dd29:


    "¡La estás asustando!"


translate english a7141_255db989:


    "¡Tenemos que ser caballerosos con esto!"


translate english a7141_dcc40ba0:


    xy "\"Es solo una idea divertida que tuve. Al final, la ropa no es lo que más importa.\""


translate english a7141_321dae1a:



    voice "voice/a71/4100500a01.opus"
    mx "\"¿N-No lo es...?\""


translate english a7141_f353a9ac:


    xy "\"Claro que no... ¿Qué clase de pervertido crees que soy? Jaja...\""


translate english a7141_f333fa0c:


    xy "\"¡Lo que más importa es quién eres por dentro...!\""


translate english a7141_3e82e2e5:


    xy "\"Una chica podría usar ropa de diseñador y no me importaría... ¡Pero si su personalidad es mala, eso es un factor decisivo!\""


translate english a7141_44721b46:


    xy "\"¡Cuando se trata de alguien de quien estoy enamorado, automáticamente se ve genial con lo que sea!\""


translate english a7141_ae509174:



    voice "voice/a71/4100510a01.opus"
    mx "\"¡Oh, ya entiendo! ¡Sí!\""


translate english a7141_cd4de1cb:



    voice "voice/a71/4100520a01.opus"
    mx "\"Qué bueno oír eso.\""


translate english a7141_f2083798:



    voice "voice/a71/4100530a01.opus"
    mx "\"O sea, los uniformes de empleada son algo degradantes, sabes.\""


translate english a7141_cf69aaa2:


    "¡Nnngh!"


translate english a7141_275dcaa7:


    "¿Q... Qué fue eso...?"


translate english a7141_e2db45d9:


    "¿Por qué me siento tan destrozado...?"


translate english a7141_0b12d40a:



    voice "voice/a71/4100540a01.opus"
    mx "\"¿Shinichi? Te ves un poco—\""


translate english a7141_ddaf1be0:


    xy "\"¡No es nada! En fin, ¡me sorprende que te sientas así! O sea, usas todo tipo de disfraces para tus obras, ¿no?\""


translate english a7141_a80c0883:


    xy "\"Seguramente un atuendo de empleada no es tan diferen—\""


translate english a7141_6f0bda9e:



    voice "voice/a71/4100550a01.opus"
    mx "\"Pero no sería para una obra, así que... sería solo vergonzoso.\""


translate english a7141_cd00f1fa:


    "Lo imaginé..."


translate english a7141_609ba1f8:


    "Por alguna razón, no puedo sacudirme esta sensación de haber perdido la oportunidad de mi vida..."




translate english a7141_daa77d7a:


    xy "\"..................\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
