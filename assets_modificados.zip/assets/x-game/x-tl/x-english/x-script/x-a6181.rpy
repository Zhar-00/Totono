

translate english a6181_48ee13cd:


    "Una hora después..."


translate english a6181_257620c9:



    voice "voice/a61/8100010a02.opus"
    aoi "\"Boop boop... Nnn... nnn...\""


translate english a6181_98ce8341:



    voice "voice/a61/8100020a02.opus"
    aoi "\"\"\"—!\"\"\""


translate english a6181_3a8c5088:



    voice "voice/a61/8100030a02.opus"
    aoi "\"Haah... haah... haah... haah...\""


translate english a6181_5279d452:


    "Su swing está completamente desviado."


translate english a6181_bfd8d5f6:


    "Ya lleva un buen rato sin siquiera rozar la pelota."


translate english a6181_76dd2e33:


    "Y aun así—"


translate english a6181_68f13bec:



    voice "voice/a61/8100040a02.opus"
    aoi "\"\"\"—!\"\"\""


translate english a6181_d308ae5a:



    voice "voice/a61/8100050a02.opus"
    aoi "\"Haah... haah... haah... haah...\""


translate english a6181_6c862feb:


    "—sigue bateando de todos modos."


translate english a6181_f3bfffda:


    "Sabe que no puede conectar un jonrón, pero sigue intentándolo de todos modos."


translate english a6181_5e5b5260:


    "Pensarías que ya se habría rendido, pero no lo ha hecho."


translate english a6181_094d5ab7:



    voice "voice/a61/8100060a02.opus"
    aoi "\"\"\"—!\"\"\""


translate english a6181_200bbdae:



    voice "voice/a61/8100070a02.opus"
    aoi "\"Nnnn... nnn... nnn...\""


translate english a6181_50838a47:


    "El impulso la hace caer al suelo."


translate english a6181_bdaeab59:


    "Tras agotar toda su energía, está demasiado exhausta para levantarse."


translate english a6181_3b53dc7d:


    xy "\"Vamos, Aoi. Ya ríndete.\""


translate english a6181_5af58d78:



    voice "voice/a61/8100080a02.opus"
    aoi "\"¡No!\""


translate english a6181_86276349:



    voice "voice/a61/8100090a02.opus"
    aoi "\"¡Aoi nunca se rendirá!\""


translate english a6181_a99f1900:



    voice "voice/a61/8100100a02.opus"
    aoi "\"¡Hasta que tú... le digas a Miyuki que la amas!\""


translate english a6181_fd33c1b1:


    xy "\"Ya te dije que no puedo.\""


translate english a6181_b5038a02:



    voice "voice/a61/8100110a02.opus"
    aoi "\"¡Sí puedes!\""


translate english a6181_3f84f24f:


    "Aoi se pone de pie con esfuerzo, apoyándose en su bate."


translate english a6181_2bffe038:



    voice "voice/a61/8100120a02.opus"
    aoi "\"Cuando Aoi batee un jonrón, tienes que tener fe.\""


translate english a6181_921be7e4:


    xy "\"Ya te digo, Dios no es real.\""


translate english a6181_e84f7740:



    voice "voice/a61/8100130a02.opus"
    aoi "\"¡SÍ ES!\""


translate english a6181_bb58c512:


    xy "\"¿Eh?\""


translate english a6181_a5c21e52:



    voice "voice/a61/8100140a02.opus"
    aoi "\"¡Sí es, sí es, SÍ ES!\""


translate english a6181_628c1e2c:



    voice "voice/a61/8100150a02.opus"
    aoi "\"—¡Nngh!\""


translate english a6181_57754152:



    voice "voice/a61/8100160a02.opus"
    aoi "\"¡Aoi conoció a Dios!\""


translate english a6181_e8776149:



    voice "voice/a61/8100170a02.opus"
    aoi "\"—¡Nngh!\""


translate english a6181_29349202:



    voice "voice/a61/8100180a02.opus"
    aoi "\"¡Y Dios puede actualizar el universo!\""


translate english a6181_7e827506:



    voice "voice/a61/8100190a02.opus"
    aoi "\"—¡Hnngh!\""


translate english a6181_bfca2916:



    voice "voice/a61/8100200a02.opus"
    aoi "\"¡Lo cual significa... que los milagros también son reales...!\""


translate english a6181_e33804cf:



    voice "voice/a61/8100210a02.opus"
    aoi "\"—¡Hggh!\""


translate english a6181_f64b04b8:



    voice "voice/a61/8100220a02.opus"
    aoi "\"¡Tu deseo... puede hacerse realidad...!\""


translate english a6181_91a575b9:



    voice "voice/a61/8100230a02.opus"
    aoi "\"—¡Nngah!\""


translate english a6181_3025f974:



    voice "voice/a61/8100240a02.opus"
    aoi "\"¡Y Aoi puede batear un jonrón!\""


translate english a6181_78435186:



    voice "voice/a61/8100250a02.opus"
    aoi "\"Aoi... sabe... que Aoi puede... hacerlo...\""


translate english a6181_871bb559:


    xy "\"¡Aoi!\""


translate english a6181_cb42fca8:



    voice "voice/a61/8100260a02.opus"
    aoi "\"¿Por qué...?\""


translate english a6181_92d38512:


    "Se agacha y agarra una pelota de béisbol que está en el suelo."


translate english a6181_22b50960:


    "Luego la lanza hacia la red..."


translate english a6181_17923e1d:


    "Naturalmente, se queda muy lejos del objetivo."



translate english a6181_4e46c026:



    voice "voice/a61/8100270a02.opus"
    aoi "\"¿¡Por qué, por qué, POR QUÉ!?\""


translate english a6181_526f25b3:



    voice "voice/a61/8100280a02.opus"
    aoi "\"¿Por qué Aoi no puede hacerlo...?\""


translate english a6181_b2caf680:


    xy "\"Aoi... sabe... que Aoi puede... hacerlo...\""


translate english a6181_f72bdb7b:


    "Se encoge."


translate english a6181_c26e6159:


    "Su sombra tiembla por el suelo."


translate english a6181_4ad5b035:


    "Susurra débilmente."


translate english a6181_efeb6ec5:



    voice "voice/a61/8100290a02.opus"
    aoi "\"Escucha, Shinichi...\""


translate english a6181_312d64d0:



    voice "voice/a61/8100300a02.opus"
    aoi "\"Los últimos días...\""


translate english a6181_49601fbe:



    voice "voice/a61/8100310a02.opus"
    aoi "\"Mis llamadas... No pasan.\""


translate english a6181_c4f893aa:



    voice "voice/a61/8100320a02.opus"
    aoi "\"Así que Aoi no puede pedirle a Dios que guarde la partida.\""


translate english a6181_e68ba82f:



    voice "voice/a61/8100330a02.opus"
    aoi "\"Y Aoi tampoco puede hacer un parche de actualización.\""


translate english a6181_69537a9c:



    voice "voice/a61/8100340a02.opus"
    aoi "\"¿Crees... que Dios me abandonó...?\""


translate english a6181_0e6c78b0:



    voice "voice/a61/8100350a02.opus"
    aoi "\"¿Aoi nunca fue una opción romántica desde el principio?\""


translate english a6181_0accd139:


    xy "\"......\""


translate english a6181_f576679f:


    "Aoi ha estado ausente todo este tiempo..."


translate english a6181_ed557dd4:


    "I can picture her with her arm up in the air, \"transmitting\"a Dios con un teléfono que no tiene señal."


translate english a6181_f8244752:


    "She's so far removed from reality, her \"god\"es el único apoyo emocional que tiene."


translate english a6181_9ee539d9:


    "Sin él, ella—"


translate english a6181_4b1dc452:



    voice "voice/a61/8100360a02.opus"
    aoi "\"Pero me enseñaste tantas cosas.\""


translate english a6181_a997e948:



    voice "voice/a61/8100370a02.opus"
    aoi "\"Me diste...\""


translate english a6181_37417c26:



    voice "voice/a61/8100380a02.opus"
    aoi "\"—alegría—\""


translate english a6181_c70f9d86:



    voice "voice/a61/8100390a02.opus"
    aoi "\"—y emoción—\""


translate english a6181_62e5da58:



    voice "voice/a61/8100400a02.opus"
    aoi "\"—y tristeza—\""


translate english a6181_32380b9d:



    voice "voice/a61/8100410a02.opus"
    aoi "\"—y dolor—\""


translate english a6181_ddc38714:



    voice "voice/a61/8100420a02.opus"
    aoi "\"—y todos los demás sentimientos de este universo.\""


translate english a6181_e65af951:



    voice "voice/a61/8100430a02.opus"
    aoi "\"Es gracias a ti que Aoi es quien es hoy.\""


translate english a6181_d211bb08:



    voice "voice/a61/8100440a02.opus"
    aoi "\"Y ahora, Shinichi...\""


translate english a6181_68e39c3e:



    voice "voice/a61/8100450a02.opus"
    aoi "\"...tú eres mi nuevo Dios.\""


translate english a6181_2d7929f5:


    "¿Soy su Dios?"


translate english a6181_8cc29f14:



    voice "voice/a61/8100460a02.opus"
    aoi "\"Por favor, ayúdame...\""


translate english a6181_058c2d5c:



    voice "voice/a61/8100470a02.opus"
    aoi "\"Aoi necesita algo en qué creer...\""


translate english a6181_ebe9e2f8:



    voice "voice/a61/8100480a02.opus"
    aoi "\"Por favor, dime que mis sentimientos son válidos...\""


translate english a6181_fbdc24a9:



    voice "voice/a61/8100490a02.opus"
    aoi "\"¡Ayúdame a creer en el amor...!\""


translate english strings:


    old "Помочь ей поверить"
    new "Ayúdala a creer"


    old "Подвести её"
    new "Fállale"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
