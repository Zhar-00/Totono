

translate english e1132a_dfd6ae9a:


    xy "\"Ah loph phoo...\""


translate english e1132a_f837ac3f:



    voice "voice/e11/32a00010a01.opus"
    mx "\"Gracias.\""


translate english e1132a_633e066c:


    "El metal frío se aparta de mi cuello."


translate english e1132a_9425bb3e:


    "Luego la toalla se levanta de mi cara, y mi vista regresa."


translate english e1132a_4b8361c7:


    "Lo siguiente que veo es la sonrisa de Miyuki."


translate english e1132a_1a89f1ff:


    "Me alegra haberle dicho cómo me siento. Su felicidad hace que todo valga la pena."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
