

translate english e2161_2d9a3f97:


    xy "\"Mmm...\""


translate english e2161_4d51ad3e:


    xy "\"Whoever owns this place must REALLY love cats.\""


translate english e2161_be82e11d:



    voice "voice/e21/6100010a01.opus"
    mx "\"...Heheh...\""


translate english e2161_8429ffa4:


    xy "\"Uh, Miyuki? Your face?\""


translate english e2161_9eb0de2d:



    voice "voice/e21/6100020a01.opus"
    mx "\"Huh? Oh!\""


translate english e2161_12c9a2ba:


    xy "\"You know, every time we set foot in here, it's like you transform into this totally different person...\""


translate english e2161_593bb204:



    voice "voice/e21/6100030a01.opus"
    mx "\"...So?\""


translate english e2161_3884373f:


    xy "\"Didn't you buy something in here just the other day, too?\""


translate english e2161_19faad3b:



    voice "voice/e21/6100040a01.opus"
    mx "\"Oh, just a cat video compilation DVD...\""


translate english e2161_1bddb6de:



    voice "voice/e21/6100050a01.opus"
    mx "\"Oh, just a cat ASMR CD...\""


translate english e2161_2834ef86:



    voice "voice/e21/6100060a01.opus"
    mx "\"Oh, just a cat-to-human translator toy...\""


translate english e2161_4cc234f7:


    xy "\"Right...\""


translate english e2161_44fac4b4:


    xy "\"Have you always been this much of a cat fanatic?\""


translate english e2161_92037530:


    xy "\"What's so great about cats, anyway?\""


translate english e2161_cec137f2:



    voice "voice/e21/6100070a01.opus"
    mx "\"Their little toe beans! They're cute!\""


translate english e2161_549faede:


    xy "\"Gotta admit, I haven't touched a cat's paw before.\""


translate english e2161_a9e26b0a:



    voice "voice/e21/6100080a01.opus"
    mx "\"Me either.\""


translate english e2161_88f13701:


    "¡¿Entonces por qué lo menciona?!?"


translate english e2161_b7ceb9b8:



    voice "voice/e21/6100090a01.opus"
    mx "\"I don't know how to explain it... They're just... elegant, you know?\""


translate english e2161_2186e0bd:


    xy "\"...Yeah, I can see that.\""


translate english e2161_b816246c:


    "Los gatos tienen esta vibra distante e independiente que le queda como anillo al dedo a Miyuki."


translate english e2161_96170baf:



    voice "voice/e21/6100100a01.opus"
    mx "\"Their little meows! I melt like butter whenever I hear it!\""


translate english e2161_4f420e86:


    xy "\"I see...\""


translate english e2161_10a49736:


    "Interesante..."


translate english e2161_4c96edc3:


    "Bueno, estamos aquí para conseguirle un regalo a Miyuki."


translate english e2161_70acf60b:


    "Estoy seguro de que estará extasiada sin importar qué elija."


translate english e2161_3381b8bb:


    "Pero... ¿qué elijo...?"


translate english strings:


    old "Кошачью пижаму"
    new "Un mameluco de gatito"


    old "Фоторамку"
    new "Un marco de fotos"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
