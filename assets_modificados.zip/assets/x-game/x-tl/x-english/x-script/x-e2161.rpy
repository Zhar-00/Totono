

translate english e2161_2d9a3f97:


    xy "\"Mmm...\""


translate english e2161_4d51ad3e:


    xy "\"Quien sea dueño de este lugar debe AMAR de verdad a los gatos.\""


translate english e2161_be82e11d:



    voice "voice/e21/6100010a01.opus"
    mx "\"...Jejeh...\""


translate english e2161_8429ffa4:


    xy "\"Eh, ¿Miyuki? ¿Tu cara?\""


translate english e2161_9eb0de2d:



    voice "voice/e21/6100020a01.opus"
    mx "\"¿Eh? ¡Ah!\""


translate english e2161_12c9a2ba:


    xy "\"Sabes, cada vez que entramos aquí, es como si te transformaras en una persona totalmente distinta...\""


translate english e2161_593bb204:



    voice "voice/e21/6100030a01.opus"
    mx "\"¿...Y?\""


translate english e2161_3884373f:


    xy "\"¿No compraste algo aquí también el otro día?\""


translate english e2161_19faad3b:



    voice "voice/e21/6100040a01.opus"
    mx "\"Oh, solo un DVD de recopilación de videos de gatos...\""


translate english e2161_1bddb6de:



    voice "voice/e21/6100050a01.opus"
    mx "\"Oh, solo un CD de ASMR de gatos...\""


translate english e2161_2834ef86:



    voice "voice/e21/6100060a01.opus"
    mx "\"Oh, solo un juguete traductor de gato a humano...\""


translate english e2161_4cc234f7:


    xy "\"Ya...\""


translate english e2161_44fac4b4:


    xy "\"¿Siempre has sido tan fanática de los gatos?\""


translate english e2161_92037530:


    xy "\"Además, ¿qué tienen de bueno los gatos?\""


translate english e2161_cec137f2:



    voice "voice/e21/6100070a01.opus"
    mx "\"¡Sus frijolitos de los dedos! ¡Son lindos!\""


translate english e2161_549faede:


    xy "\"Debo admitir que nunca he tocado la pata de un gato.\""


translate english e2161_a9e26b0a:



    voice "voice/e21/6100080a01.opus"
    mx "\"Yo tampoco.\""


translate english e2161_88f13701:


    "¡¿Entonces por qué lo menciona?!?"


translate english e2161_b7ceb9b8:



    voice "voice/e21/6100090a01.opus"
    mx "\"No sé cómo explicarlo... Son simplemente... elegantes, ¿sabes?\""


translate english e2161_2186e0bd:


    xy "\"...Sí, puedo verlo.\""


translate english e2161_b816246c:


    "Los gatos tienen esta vibra distante e independiente que le queda como anillo al dedo a Miyuki."


translate english e2161_96170baf:



    voice "voice/e21/6100100a01.opus"
    mx "\"¡Sus maulliditos! ¡Me derrito como mantequilla cada vez que los oigo!\""


translate english e2161_4f420e86:


    xy "\"Ya veo...\""


translate english e2161_10a49736:


    "Interesante..."


translate english e2161_4c96edc3:


    "Bueno, estamos aquí para conseguirle un regalo a Miyuki."


translate english e2161_70acf60b:


    "Estoy seguro de que estará extasiada sin importar qué elija."


translate english e2161_3381b8bb:


    "Pero... ¿qué elijo...?"


translate english strings:


    old "Кошачью пижаму"
    new "Un mameluco de gatito"


    old "Фоторамку"
    new "Un marco de fotos"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
