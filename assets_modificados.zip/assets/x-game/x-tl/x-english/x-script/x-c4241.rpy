

translate english c4241_3ab897a8:



    voice "voice/c42/4100010a02.opus"
    aoi "\"¡Hya!\""


translate english c4241_e8190bbf:


    xy "\"¡Nng...! Ay...\""


translate english c4241_c6f9e8f2:


    "Aoi me empuja hacia abajo."


translate english c4241_5f77942e:


    xy "\"¿Aoi...?\""


translate english c4241_709f79b4:


    xy "\"¿¡Q-Qué estás haciendo!?\""


translate english c4241_29f4fae7:



    voice "voice/c42/4100020a02.opus"
    aoi "\"Oh, ¿prefieres sexo con ropa?\""


translate english c4241_1fce7afe:


    "Aoi se detiene a mitad de quitarse la camisa."


translate english c4241_cff38484:


    xy "\"¡A eso no me refería y lo sabes!\""


translate english c4241_434cbc3e:



    voice "voice/c42/4100030a02.opus"
    aoi "\"Por favor...\""


translate english c4241_0fb6a42f:



    voice "voice/c42/4100040a02.opus"
    aoi "\"La batería de Aoi está a punto de morir.\""


translate english c4241_d0b610c5:



    voice "voice/c42/4100050a02.opus"
    aoi "\"Y para mañana, probablemente habrás olvidado todo.\""


translate english c4241_6f9e38e3:



    voice "voice/c42/4100060a02.opus"
    aoi "\"Solo finge que esto es un sueño, ¿sí?\""


translate english c4241_e4f82a95:



    voice "voice/c42/4100070a02.opus"
    aoi "\"Aoi quiere...\""


translate english c4241_52aa83c5:



    voice "voice/c42/4100080a02.opus"
    aoi "\"...tener chispazos contigo.\""


translate english c4241_0accd139:


    xy "\"\"\"......!!!\"!\"\""


translate english c4241_451d3bde:



    voice "voice/c42/4100090a02.opus"
    aoi "\"¿Tú no quieres?\""


translate english c4241_6823f477:


    xy "\"No estoy interesado en—\""


translate english c4241_6beab5e3:



    voice "voice/c42/4100100a02.opus"
    aoi "\"Mentiroso.\""


translate english c4241_007df635:


    "Puedo ver el contorno de sus senos asomándose por encima de su blusa parcialmente quitada."


translate english c4241_ea419d52:


    "Sus pequeñas palmas se deslizan suavemente sobre mi cuerpo."


translate english c4241_050d2ebe:


    "El peso de sus caderas empieza a hundirse."


translate english c4241_5f2f615c:


    "Y mi polla definitivamente lo ha notado."


translate english c4241_7d02385c:



    voice "voice/c42/4100110a02.opus"
    aoi "\"¿Estás tratando de levantarme con tu erección?\""


translate english c4241_b406c818:


    xy "\"Espera, ¿pero no te sentías mal? No deberíamos—\""


translate english c4241_bca9ef39:



    voice "voice/c42/4100120a02.opus"
    aoi "\"Aoi estará bien.\""


translate english c4241_6a1fcecf:



    voice "voice/c42/4100130a02.opus"
    aoi "\"Los CG de eventos me curarán.\""


translate english c4241_1a77c956:


    xy "\"Pero—\""


translate english c4241_a453d57b:



    voice "voice/c42/4100140a02.opus"
    aoi "\"El sexo me hará sentir mejor.\""


translate english c4241_fd1026f4:


    "Aoi se sube la falda y empuja sus caderas."


translate english c4241_84040fb0:


    "Puedo sentir sus bragas presionando contra mi ingle."


translate english c4241_b62a2332:


    "Pero de alguna manera, no puedo decir si duele o se siente bien..."


translate english c4241_81a42d1c:


    "Poco a poco, voy perdiendo las ganas de resistirme."


translate english c4241_5a5beacd:



    voice "voice/c42/4100150a02.opus"
    aoi "\"¿Estás duro aquí también?\""


translate english c4241_b5ee8eb2:


    "Me desabrocha la camisa."


translate english c4241_028aec12:



    voice "voice/c42/4100160a02.opus"
    aoi "\"Toqueteo, toqueteo...\""


translate english c4241_66854568:


    "Arrastra ligeramente sus uñas contra mi piel, dibuja círculos con sus dedos alrededor de mi pezón y se acerca lentamente hasta que—"


translate english c4241_a6189ce2:


    "—de repente, retira la mano."


translate english c4241_53e9e6ca:


    xy "\"¡Ah...!\""


translate english c4241_7ff0ac5c:



    voice "voice/c42/4100170a02.opus"
    aoi "\"¿Quieres? ¿Quieres que juegue con ellos?\""


translate english c4241_60296208:


    xy "\"N-No, claro que n—\""


translate english c4241_77c03da0:


    "Antes de que pueda terminar mi frase, Aoi presiona un dedo contra mi pezón."


translate english c4241_b3e7107d:



    voice "voice/c42/4100180a02.opus"
    aoi "\"¿Se siente bien? ¿Son chispazos?\""


translate english c4241_67be5d69:


    "Me provoca, y estoy completamente a su merced."


translate english c4241_7e1b018a:


    "Cada vez que sus dedos apenas rozan mis pezones, el placer me atraviesa como electricidad al rojo vivo."


translate english c4241_6d87aecf:



    voice "voice/c42/4100190a02.opus"
    aoi "\"¿Este es tu punto débil?\""


translate english c4241_a14efee3:


    xy "\"......!\""


translate english c4241_620d68d6:


    "De alguna manera, Aoi sabe exactamente qué botones presionar."


translate english c4241_87b928ee:


    "Casi como si lo hubiera descubierto de antemano o algo así..."


translate english c4241_95a7ba79:



    voice "voice/c42/4100200a02.opus"
    aoi "\"¡Bip bip!\""


translate english c4241_fd3a83fc:


    "Aoi no se detiene ni un momento."


translate english c4241_acf0934c:


    "Desabrocha con destreza mi cinturón y baja el cierre de mi bragueta."


translate english c4241_d5c8fc42:


    "Luego baja mis boxers unos centímetros, y mi polla dura asoma."


translate english c4241_3d59acab:


    "Mientras tanto, sus ojos están fijos en los míos."


translate english c4241_2462222c:


    "Ni siquiera mira mi erección. En cambio, ladea la cabeza hacia mí."


translate english c4241_d61aac1c:



    voice "voice/c42/4100210a02.opus"
    aoi "\"¿Estás caliente?\""


translate english c4241_44d811ac:


    "Su mirada es inquisitiva."


translate english c4241_a17a154d:


    "Admito que estoy un poco avergonzado, pero no puedo evitar apartar la vista."


translate english c4241_9c4f2437:


    "Sus mejillas están ligeramente sonrojadas, igual que aquella noche fatídica."


translate english c4241_3654a0df:



    voice "voice/c42/4100220a02.opus"
    aoi "\"Aoi también quiere tener chispazos.\""


translate english c4241_f114b3f1:


    "Un escalofrío recorre mi espalda."


translate english c4241_b77d0ad7:


    "Entonces, de repente, el peso se levanta de mi ingle."


translate english c4241_9c005946:


    "Escucho el sonido de ropa arrugándose."


translate english c4241_67ab4976:


    "Antes de que mi mirada pueda desviarse entre sus piernas—"


translate english c4241_c10d9ff0:



    voice "voice/c42/4100230a02.opus"
    aoi "\"No.\""


translate english c4241_99e31f2f:


    "—me detiene, y una vez más mis ojos quedan fijos en los suyos, casi como si me hubiera hipnotizado."


translate english c4241_7ef32ee0:



    voice "voice/c42/4100240a02.opus"
    aoi "\"Aah...\""


translate english c4241_b62edc6a:


    "Lo siguiente que siento es una repentina explosión de placer."


translate english c4241_85f8181b:



    voice "voice/c42/4100250a02.opus"
    aoi "\"Lo está tocando...\""


translate english c4241_9ae99110:



    voice "voice/c42/4100260a02.opus"
    aoi "\"Aoi está tocando tu verga ardiendo...\""


translate english c4241_5e3c55fd:


    "Puedo sentir una calidez húmeda presionada justo contra mi centro de placer."


translate english c4241_43146954:



    voice "voice/c42/4100270a02.opus"
    aoi "\"A Aoi le encanta tener sexo.\""


translate english c4241_ab072018:



    voice "voice/c42/4100280a02.opus"
    aoi "\"Y a Aoi le encanta la cara que pones cuando estás excitado.\""


translate english c4241_94d95eb9:



    voice "voice/c42/4100290a02.opus"
    aoi "\"Y los sonidos que haces, también.\""


translate english c4241_1a59cd4c:



    voice "voice/c42/4100300a02.opus"
    aoi "\"Me da curiosidad ver más.\""


translate english c4241_9e9036f3:


    "Puedo sentir su piel... su calor... su pulso... justo contra mi cuerpo."


translate english c4241_9510ac7f:


    "Mi instinto masculino lucha por suprimir mi sentido de la razón."


translate english c4241_5b5e94f3:


    "Joder, quiero metérsela en este mismo instante—"


translate english c4241_1fb4318a:



    voice "voice/c42/4100310a02.opus"
    aoi "\"No te apures.\""


translate english c4241_4fe2e2c3:


    "Sus dedos rozan mi pezón una vez más."


translate english c4241_5d273892:



    voice "voice/c42/4100320a02.opus"
    aoi "\"¿Te gusta esto?\""


translate english c4241_0ac1ef5a:


    "Esta vez, en lugar de punzar y hurgar, se aferra con firmeza."


translate english c4241_5484d520:


    "Luego lo retuerce y lo tira."


translate english c4241_c2891c4e:



    voice "voice/c42/4100330a02.opus"
    aoi "\"Aoi te va a hacer esperar.\""


translate english c4241_1de248d6:



    voice "voice/c42/4100340a02.opus"
    aoi "\"Aoi te va a provocar y provocar y provocar...\""


translate english c4241_d44d9295:



    voice "voice/c42/4100350a02.opus"
    aoi "\"...hasta que te corras.\""


translate english c4241_2f0536c0:



    voice "voice/c42/4100360a02.opus"
    aoi "\"Aoi va a drenar tus bolas.\""


translate english c4241_584b12f6:



    voice "voice/c42/4100370a02.opus"
    aoi "\"Tu mente se quedará en blanco por el placer.\""


translate english c4241_375957dd:


    "Su susurro convierte mi cerebro en papilla."


translate english c4241_25600193:


    "En lugar de concentrarse por completo en mis partes bajas, el placer parece extenderse por todo mi cuerpo."


translate english c4241_75350816:



    voice "voice/c42/4100380a02.opus"
    aoi "\"Ahora estás duro por arriba Y por abajo.\""


translate english c4241_6304ff12:



    voice "voice/c42/4100390a02.opus"
    aoi "\"¿Eres un pequeño desviado?\""


translate english c4241_d1d54220:


    "Mientras susurra, sus labios se contraen inocentemente."


translate english c4241_ee19711b:


    "Quiero más... ¡Quiero sentirla con cada centímetro de mi ser...!"


translate english c4241_b4c79d56:


    "Y tampoco quiero que esto siga siendo unilateral—¡quiero mostrarle cómo me siento por ella!"


translate english c4241_b3a69917:


    "Quiero besarla..."


translate english c4241_e8eb18f4:


    "¡Un beso de verdad esta vez, no solo RCP!"


translate english c4241_ba7c46c6:


    xy "\"Aoi, bésame...\""


translate english c4241_cb5577a8:



    voice "voice/c42/4100400a02.opus"
    aoi "\"Eso no está permitido.\""


translate english c4241_82b442a3:



    voice "voice/c42/4100410a02.opus"
    aoi "\"Ese es trabajo de Miyuki.\""


translate english c4241_d824fef1:


    xy "\"Te dije que no quiero—\""


translate english c4241_1f11075b:



    voice "voice/c42/4100420a02.opus"
    aoi "\"Esto es solo una aventura de una noche.\""


translate english c4241_7e0ed4e8:



    voice "voice/c42/4100430a02.opus"
    aoi "\"Solo un error... y cuando despiertes mañana, lo habrás olvidado todo.\""


translate english c4241_e152bdd4:


    xy "\"¡No, no lo olvidaré—!\""


translate english c4241_4c98aa59:



    voice "voice/c42/4100440a02.opus"
    aoi "\"Bip bip...\""


translate english c4241_c84601fd:


    xy "\"¿¡Eh—!?\""


translate english c4241_bf7791e9:



    voice "voice/c42/4100450a02.opus"
    aoi "\"En cambio...\""


translate english c4241_c6a4ae93:



    voice "voice/c42/4100460a02.opus"
    aoi "\"Puedes besarme aquí.\""


translate english c4241_0accd139_1:


    xy "\"\"\"......!!!\"!\"\""


translate english c4241_34f0d648:


    "Aoi está de pie frente a mí."


translate english c4241_7e9758e8:


    "La brisa nocturna trae su calor... y su aroma."


translate english c4241_16a8b893:


    "Su falda se agita con el viento, y debajo de ella—"


translate english c4241_7bef43ae:



    voice "voice/c42/4100470a02.opus"
    aoi "\"¿Quieres ver?\""


translate english c4241_f63a81e7:


    "Aoi pregunta, con el dedo en la boca."


translate english c4241_68c8f85c:


    "Incapaz de contenerme, deslizo una mano por su muslo."


translate english c4241_806618d7:



    voice "voice/c42/4100480a02.opus"
    aoi "\"¡Aah...!\""


translate english c4241_616d7d03:


    "Su cuerpo se estremece con mi toque."


translate english c4241_86d9a443:


    "Su piel es suave, tersa y flexible."


translate english c4241_5f7960ad:



    voice "voice/c42/4100490a02.opus"
    aoi "\"Aoi también está caliente.\""


translate english c4241_e3ef5d65:



    voice "voice/c42/4100500a02.opus"
    aoi "\"Nunca me había sentido así...\""


translate english c4241_7c4f1c51:


    "Sonríe tímidamente."


translate english c4241_49c2db4a:


    "Me siento impulsado, no por el instinto ni la razón, sino por el amor."


translate english c4241_9dabef61:


    xy "\"Aoi...\""


translate english c4241_1a10c917:



    voice "voice/c42/4100510a02.opus"
    aoi "\"¿Sí?\""


translate english c4241_e3d10c8e:


    "Aoi se levanta la falda."


translate english c4241_4b3fa310:


    "La tenue luz de la luna ilumina su perfecto coño."


translate english c4241_f66e67d4:


    "Sus labios suaves y sin vello están ligeramente entreabiertos por el deseo, y los fluidos han empezado a escurrir desde su interior."


translate english c4241_cba76a5c:



    voice "voice/c42/4100520a02.opus"
    aoi "\"...Quiere un beso.\""


translate english c4241_521c13d6:


    "Mi cuerpo se mueve solo, como una marioneta con hilos invisibles."


translate english c4241_8a3434f6:


    "Presiono una mano contra su piel suave..."


translate english c4241_cc5aa387:


    "...y deslizo mi pulgar entre sus labios, separándolos."


translate english c4241_91f9af2b:



    voice "voice/c42/4100530a02.opus"
    aoi "\"¿Puedes verlo todo?\""


translate english c4241_f7879a54:


    "A diferencia del resto de su piel, su coño está sonrojado, lo suficiente para notarlo incluso en la oscuridad de la noche."


translate english c4241_34c13007:


    "Ahora estamos a solo unos centímetros—a la distancia de una lengua."


translate english c4241_3164e0b2:



    voice "voice/c42/4100540a02.opus"
    aoi "\"Es raro... Aunque no me estés tocando...\""


translate english c4241_1aa6dbdd:



    voice "voice/c42/4100550a02.opus"
    aoi "\"Aoi siente tantos... chispazos...\""


translate english c4241_fd979e70:


    "Sus fluidos fluyen ante mis ojos."


translate english c4241_e9362c18:


    "Me pregunto qué pasaría si lo lamo..."


translate english c4241_be218c28:



    voice "voice/c42/4100560a02.opus"
    aoi "\"¡Nnnngg...!!!\""


translate english c4241_7efc9e46:


    "Su cuerpo se convulsiona."


translate english c4241_cbeea6c9:


    "Puedo ver sus manos temblar mientras se aferra a su falda."


translate english c4241_f4ed91c9:


    "Deslizo mi lengua entre sus labios una segunda vez, y luego una tercera."


translate english c4241_71ef43eb:



    voice "voice/c42/4100570a02.opus"
    aoi "\"Oh... jaa... aah... nnn... ¡nnngghh... nnngg!!!\""


translate english c4241_4cf50486:



    voice "voice/c42/4100580a02.opus"
    aoi "\"Espera... Uah... Esto es increíble... Shinichi, se siente tan bien... ¡Nnn... nnjaaahh!\""


translate english c4241_28733c29:


    "Sus fluidos se mezclan con mi saliva, y los sorbo."


translate english c4241_7dc0486b:


    "Luego empiezo a usar mis labios además de mi lengua."


translate english c4241_516938ae:



    voice "voice/c42/4100590a02.opus"
    aoi "\"¡Aah... aah... aaahh! ¿Lo estás chupando...? ¿Me estás chupando... toda...?\""


translate english c4241_77afabc8:



    voice "voice/c42/4100600a02.opus"
    aoi "\"¡Hnnnn! Estás... siendo tan ruidosa... Es... realmente sexy...\""


translate english c4241_e1893a7c:



    voice "voice/c42/4100610a02.opus"
    aoi "\"¿Tú... también te estás poniendo más duro?\""


translate english c4241_6559cbea:


    "Claro que sí."


translate english c4241_bf8a0f30:


    "A pesar de haber sido casi totalmente ignorada hasta ahora, mi erección sigue creciendo."


translate english c4241_b74c1068:



    voice "voice/c42/4100620a02.opus"
    aoi "\"Te estás poniendo caliente... por lamer mi coño... Shinichi... eres un desviado...\""


translate english c4241_2a9629b5:



    voice "voice/c42/4100630a02.opus"
    aoi "\"Ahora... es mi turno... Aoi te va a hacer sentir tan— ¡Aaahh!!!\""


translate english c4241_148b54a5:


    "Deslizo mi lengua hasta el fondo."


translate english c4241_ea775c9f:


    "Está tan apretado que no estoy seguro de que mi polla quepa."


translate english c4241_2934f990:



    voice "voice/c42/4100640a02.opus"
    aoi "\"¡AAH! Aah... Guau... Se siente... tan bien...\""


translate english c4241_b8abcbcf:



    voice "voice/c42/4100650a02.opus"
    aoi "\"Okay... Ahora es... turno de... Aoi...\""


translate english c4241_fb8c59d5:



    voice "voice/c42/4100660a02.opus"
    aoi "\"...¿Shinichi?\""


translate english c4241_75fb3796:


    "Lo siento, pero no tengo intención de detenerme aquí."


translate english c4241_e3231f5f:


    "La ignoro y separo sus labios con los dedos, luego presiono mis labios contra su clítoris expuesto y chupo."


translate english c4241_e5b68361:



    voice "voice/c42/4100670a02.opus"
    aoi "\"—?!\""


translate english c4241_7945b4d3:



    voice "voice/c42/4100680a02.opus"
    aoi "\"¡AAAH! ¡N-No! ¡No puedes chupar ahí! ¡Es demasiado intenso!\""


translate english c4241_1ce7e3d2:


    "Se retuerce e intenta apartarse."


translate english c4241_9674498a:


    "Pero sigo chupando."


translate english c4241_4d5dda4f:



    voice "voice/c42/4100690a02.opus"
    aoi "\"¡Jaah! ¡Aaah! ¡Aah! ¡Es demasiado—demasiados chispazos!\""


translate english c4241_21788fb5:



    voice "voice/c42/4100700a02.opus"
    aoi "\"Mi coño se siente tan bien... Los chispazos no paran... Nunca... se había sentido así de bien...\""


translate english c4241_0aa83bf8:



    voice "voice/c42/4100710a02.opus"
    aoi "\"¡Es demasiado! ¡Demasiado rápido! Oh no... ¡Aoi no puede contenerse!\""


translate english c4241_97e09650:



    voice "voice/c42/4100720a02.opus"
    aoi "\"¡Jaaah! ¡Aah! ¡Oh no! ¡Demasiados chispazos! ¡Aah... aah... aah, aah, aah, aah!\""


translate english c4241_7cc5405f:



    voice "voice/c42/4100730a02.opus"
    aoi "\"Aaah... aah... ¿uh...?\""


translate english c4241_4f6ab122:


    "Justo antes de que Aoi llegue al clímax, aparto los labios."


translate english c4241_44f3763e:



    voice "voice/c42/4100740a02.opus"
    aoi "\"¿Shinichi? ¿Por qué te detuviste—Nnnnnnggg!!!\""


translate english c4241_ff4518b9:



    voice "voice/c42/4100750a02.opus"
    aoi "\"¡Jaah! ¡AAH! ¡Otra vez no— Estás lamiendo tan fuerte...!\""


translate english c4241_75557bf2:



    voice "voice/c42/4100760a02.opus"
    aoi "\"¡Hnnn... nnnnggg! ¡Aah! ¡Voy a venirme! ¡Aoi va a venirse—a venirse por los chispazos—!\""


translate english c4241_eed2d26c:



    voice "voice/c42/4100770a02.opus"
    aoi "\"Nnn...\""


translate english c4241_938acadd:


    "De nuevo, me aparto antes de que pueda llegar al orgasmo."


translate english c4241_8db54554:



    voice "voice/c42/4100780a02.opus"
    aoi "\"¿Por qué me provocas? Eres tan— ¡AAAAAHHH! ¿Por qué... estás siendo tan malo...? ¡Hnnnn!!!\""


translate english c4241_b52e4dc3:



    voice "voice/c42/4100790a02.opus"
    aoi "\"¡Deja... de hacer eso... una y otra vez...! ¡Aoi está... tan cerca... tan cerca—Nnnnn!!!\""


translate english c4241_a53851ad:



    voice "voice/c42/4100800a02.opus"
    aoi "\"¡AAH! ¡Oh no! ¡Jaaaahhh!!! Aoi puede sentir las chispas—¡voy a venirme, voy a venirme!!!\""


translate english c4241_acad8924:



    voice "voice/c42/4100810a02.opus"
    aoi "\"Nnnnn... Shinichi, si sigues así, Aoi va a volverse lo—¡aaaAAHH!!!\""


translate english c4241_9be11942:



    voice "voice/c42/4100820a02.opus"
    aoi "\"¡Ay, Dios! ¡Es demasiado! ¡No lo pellizques—! ¡Hnnn! ¡Aah! ¡Aah! ¡Aah, aah, aah—!\""


translate english c4241_324faac2:



    voice "voice/c42/4100830a02.opus"
    aoi "\"Hnnn... nnn... nnnnn... ¡¡¡AAAH!!!\""


translate english c4241_69db83c2:



    voice "voice/c42/4100840a02.opus"
    aoi "\"¡Aah! ¡Ay no! ¡Dios, Dios, Dios—!\""


translate english c4241_585a0d17:



    voice "voice/c42/4100850a02.opus"
    aoi "\"¡Hnng... nn... nnnnnn!!! ¡¿Por qué?! ¡¿Por qué no me dejas corr—AAAAHHH!\""


translate english c4241_551a5dcb:



    voice "voice/c42/4100860a02.opus"
    aoi "\"¡Haaahh! ¡GAH! Aoi está tan cerca... Pero... ¡Aoi... no llega del todo!\""


translate english c4241_37a01add:



    voice "voice/c42/4100870a02.opus"
    aoi "\"Shinichi... por favor...\""


translate english c4241_5ab432e8:



    voice "voice/c42/4100880a02.opus"
    aoi "\"Deja... de provocarme...\""


translate english c4241_dc00e1b7:



    voice "voice/c42/4100890a02.opus"
    aoi "\"Por favor... deja que Aoi... se corra...\""


translate english c4241_6d022b25:


    "Sus hombros tiemblan mientras me implora, con los ojos húmedos de lágrimas."


translate english c4241_cfdf1b5e:


    "Me aparto de su clítoris otra vez."


translate english c4241_558c209c:


    xy "\"¿Me vas a besar ahora?\""


translate english c4241_b7335b3b:



    voice "voice/c42/4100900a02.opus"
    aoi "\"¿Besarte...?\""


translate english c4241_21acc704:



    voice "voice/c42/4100910a02.opus"
    aoi "\"Eso no está permitido—¡AAAAAAAHHH!\""


translate english c4241_73e48324:


    "En el momento en que empieza a negar con la cabeza, lamo su clítoris ruidosamente de nuevo."


translate english c4241_c0b49feb:



    voice "voice/c42/4100920a02.opus"
    aoi "\"¡HAAH! ¡AAH! ¡AAAHH! ¡AAH! ¡Dios! ¡No es justo! ¡No es justo! ¡Nnngg!\""


translate english c4241_a9ec6e2f:



    voice "voice/c42/4100930a02.opus"
    aoi "\"¡Otra vez no...! ¡Aoi está a nada de correrse... otra vez...! ¡Pero... haah... haah... haah...!\""


translate english c4241_4b9b1289:



    voice "voice/c42/4100940a02.opus"
    aoi "\"Nnnnn...\""


translate english c4241_a9334187:


    xy "\"¿Segura que no puedes besarme?\""


translate english c4241_fd1ffc51:



    voice "voice/c42/4100950a02.opus"
    aoi "\"Aoi de verdad... no puede... besarte... ¡AaaaAAAAAAHHH! ¡Para! ¡No podemos—Nnnggghhhh!\""


translate english c4241_d2445e68:


    xy "\"¿Segura que no quieres?\""


translate english c4241_7d85160d:



    voice "voice/c42/4100960a02.opus"
    aoi "\"Aoi... quiere... pero... Boop boop... Se supone... que Aoi... no... debe...\""


translate english c4241_1fd443fa:


    xy "\"¿Por qué?\""


translate english c4241_c0e4da18:



    voice "voice/c42/4100970a02.opus"
    aoi "\"Pues—¡AAHH! ¡Aoi... no puede...! ¡Hnnn—nnnngg! Nn... ¡Se supone que Aoi no debe, pero...!\""


translate english c4241_a6146902:



    voice "voice/c42/4100980a02.opus"
    aoi "\"Mi... cabeza... está... toda... confusa... ¡Se está...! ¡Todo...! ¡Desordenando...!\""


translate english c4241_e77ccc6a:



    voice "voice/c42/4100990a02.opus"
    aoi "\"¡Shinichi! Escucha... ¿Estás seguro...? ¿De verdad... DE VERDAD estás seguro...?\""


translate english c4241_efbb290c:



    voice "voice/c42/4101000a02.opus"
    aoi "\"¡Tienes a Miyuki, y—!\""


translate english c4241_65711612:


    xy "\"Aoi.\""


translate english c4241_5b4e7076:



    voice "voice/c42/4101010a02.opus"
    aoi "\"¿Huh...?\""


translate english c4241_496e6f8e:


    "Me levanto y la enfrento."


translate english c4241_3fa3ad74:


    xy "\"Estoy enamorado de ti.\""


translate english c4241_11c326d1:


    xy "\"Nadie más me importa.\""


translate english c4241_72ae9eac:


    xy "\"Te elijo a ti, Aoi.\""


translate english c4241_261feac2:


    "De golpe, su rostro se desmorona—y sus emociones se desbordan."


translate english c4241_3bdd553c:



    voice "voice/c42/4101020a02.opus"
    aoi "\"Boop boop... boop boop... ¿boop boop boop boop?\""


translate english c4241_251f2677:



    voice "voice/c42/4101030a02.opus"
    aoi "\"La señal está... mal... Shinichi está... mal...\""


translate english c4241_858a4be5:



    voice "voice/c42/4101040a02.opus"
    aoi "\"Aoi... Aoi...\""


translate english c4241_7fd393ca:



    voice "voice/c42/4101050a02.opus"
    aoi "\"Aoi se puso demasiado electrizada... y se rompió.\""


translate english c4241_f2106892:



    voice "voice/c42/4101060a02.opus"
    aoi "\"Glitch.\""


translate english c4241_80d9c51e:



    voice "voice/c42/4101070a02.opus"
    aoi "\"Y los errores no se pueden arreglar.\""


translate english c4241_84a9df2d:



    voice "voice/c42/4101080a02.opus"
    aoi "\"...¿Estás seguro?\""


translate english c4241_9ce5db7c:



    voice "voice/c42/4101090a02.opus"
    aoi "\"¿Seguro que estás bien con... los glitches de Aoi?\""


translate english c4241_9aa3dc6a:



    voice "voice/c42/4101100a02.opus"
    aoi "\"Risa, lágrimas, tristeza, alegría...\""


translate english c4241_ab786da3:



    voice "voice/c42/4101110a02.opus"
    aoi "\"¿Se le permite a Aoi sentir estas cosas? ¿Se le permite a Aoi... amarte?\""


translate english c4241_b3fbb876:



    voice "voice/c42/4101120a02.opus"
    aoi "\"Aoi es demasiado rara para ser una chica normal... así que probablemente la pases mal estando conmigo...\""


translate english c4241_5b12a82b:



    voice "voice/c42/4101130a02.opus"
    aoi "\"¿Seguro que esto es lo que quieres?\""


translate english c4241_55774ab1:



    voice "voice/c42/4101140a02.opus"
    aoi "\"¿Me amarás... incluso con todos mis glitches?\""


translate english c4241_b90c3f7f:


    xy "\"Lo haré. Ya lo hago.\""


translate english c4241_442b1da7:



    voice "voice/c42/4101150a02.opus"
    aoi "\"Mmm... mmmmm... mmnnn... mmph... mmmmppphhh...!!!\""


translate english c4241_c8523672:


    "Una chispa de electricidad nos atraviesa."


translate english c4241_a005c105:


    "Nuestros labios se tocan, nuestras lenguas se entrelazan, y el cuerpo de Aoi se convulsiona."


translate english c4241_0e240a76:


    "Pero eso no nos detiene."


translate english c4241_4c8a9576:


    "Presiono mis labios con fuerza contra los suyos, devorándola."


translate english c4241_1126281f:



    voice "voice/c42/4101160a02.opus"
    aoi "\"Haah, haah, haah—mmph... mmmph... ¡mm! ¡Mm! ¡Mmmnn! ¡Mmmppphh!\""


translate english c4241_fbbd4716:



    voice "voice/c42/4101170a02.opus"
    aoi "\"Haah... mmm—Se siente... tan bien... Este es... el mejor beso que Aoi ha tenido...\""


translate english c4241_7d708444:



    voice "voice/c42/4101180a02.opus"
    aoi "\"Aoi te ha deseado tanto tiempo... ¡Tanto, tanto tiempo...!\""


translate english c4241_b890813a:



    voice "voice/c42/4101190a02.opus"
    aoi "\"Aoi ama tener glitches...\""


translate english c4241_7d993890:



    voice "voice/c42/4101200a02.opus"
    aoi "\"Y Aoi seguirá teniendo glitches...\""


translate english c4241_0acd79be:



    voice "voice/c42/4101210a02.opus"
    aoi "\"Más y más y más... Con glitches como loca...\""


translate english c4241_9d0d8d01:



    voice "voice/c42/4101220a02.opus"
    aoi "\"Con glitches por amor a ti.\""


translate english c4241_40814ede:


    "Susurra, luego se inclina una vez más."


translate english c4241_2fb39e8a:



    voice "voice/c42/4101230a02.opus"
    aoi "\"Mmph... mmm... mmph, mmmph... mmm... mmm... mmmm... Boop boop...\""


translate english c4241_4029b69a:



    voice "voice/c42/4101240a02.opus"
    aoi "\"Tus labios... saben a mi pussy... Sabe tan bien... Aoi nunca lo supo...\""


translate english c4241_7287aeae:



    voice "voice/c42/4101250a02.opus"
    aoi "\"La lamiste tanto... Aoi pensó que su pussy se iba a derretir...\""


translate english c4241_e5155b1e:



    voice "voice/c42/4101260a02.opus"
    aoi "\"Así que ahora... mmph... es tu turno... ¡Mmmph... mmm... mmm... mmmmpphh!\""


translate english c4241_cdf17376:



    voice "voice/c42/4101270a02.opus"
    aoi "\"¡Mmm... mmmph... mm... mmmm... mmph...! Tu verga está... durísima...\""


translate english c4241_b7e34eca:


    "Cada palabra que susurra entre besos envía una nueva oleada de electricidad recorriendo mi cuerpo."


translate english c4241_f0a1b120:



    voice "voice/c42/4101280a02.opus"
    aoi "\"¿Shinichi?\""


translate english c4241_498b8d17:



    voice "voice/c42/4101290a02.opus"
    aoi "\"¿Prometes hacerme acabar?\""


translate english c4241_f7610bbc:



    voice "voice/c42/4101300a02.opus"
    aoi "\"Tu verga está tan dura que lleva un rato goteando...\""


translate english c4241_7a5713b5:



    voice "voice/c42/4101310a02.opus"
    aoi "\"Y mi pussy ya no puede esperar más... Está chorreando de lujuria... ¿Prometes cogerme duro?\""


translate english c4241_2203377c:



    voice "voice/c42/4101320a02.opus"
    aoi "\"Aoi está lista para correrse como loca. Se acabó la espera.\""


translate english c4241_7152165a:



    voice "voice/c42/4101330a02.opus"
    aoi "\"¿Me dejas?\""


translate english c4241_10f7b1d4:


    "Ahora no puedo negárselo."


translate english c4241_0e0eeae7:


    "Mi polla se alza hacia el cielo."


translate english c4241_2065b4a2:


    "Aoi la toca, y rebota como un resorte."


translate english c4241_409acf6b:



    voice "voice/c42/4101340a02.opus"
    aoi "\"A Aoi le encanta.\""


translate english c4241_b04f0917:



    voice "voice/c42/4101350a02.opus"
    aoi "\"A Aoi le encanta tu verga, Shinichi.\""


translate english c4241_52784f97:



    voice "voice/c42/4101360a02.opus"
    aoi "\"El más mínimo toque me electriza.\""


translate english c4241_f9d4eaec:



    voice "voice/c42/4101370a02.opus"
    aoi "\"Hora de meterla en Aoi.\""


translate english c4241_7fd217ee:



    voice "voice/c42/4101380a02.opus"
    aoi "\"Boop boop... Nnng...\""


translate english c4241_14a6e5e2:


    "Aoi presiona mi punta contra su entrada, ajusta su posición, luego baja lentamente sus caderas."


translate english c4241_f381a346:



    voice "voice/c42/4101390a02.opus"
    aoi "\"Hnng... nn... ¡¡¡nnnnngggg!!! ¡Nnhaah... nnng... nnnnnggggghhhh!!!\""


translate english c4241_357e7a0c:


    xy "\"¿A-Aoi?\""


translate english c4241_d829a873:



    voice "voice/c42/4101400a02.opus"
    aoi "\"¡Hnn... nnn... nngg... nnnng! ¡Hormiguea...!\""


translate english c4241_26449369:


    xy "\"Espera... ¿Estás...?\""


translate english c4241_ae21a51b:


    "Las lágrimas brotan en sus ojos."


translate english c4241_98c62031:


    "Y no son lágrimas de felicidad."


translate english c4241_33152163:


    "Su coño está dolorosamente apretado... Miro hacia abajo y, en efecto, sus fluidos tienen un tenue tinte rojo."


translate english c4241_58139318:


    xy "\"¿Es... tu primera vez...?\""


translate english c4241_0326aef3:



    voice "voice/c42/4101410a02.opus"
    aoi "\"Boop boop... Las chicas de las novelas visuales siempre son vírgenes.\""


translate english c4241_6310f965:


    xy "\"¿¡En serio estás hablando de videojuegos ahora!?\""


translate english c4241_a289ea98:



    voice "voice/c42/4101420a02.opus"
    aoi "\"Con glitch o sin glitch, así es Aoi.\""


translate english c4241_66736a9b:



    voice "voice/c42/4101430a02.opus"
    aoi "\"Aah... ¡Mmm!\""


translate english c4241_d6777e1a:


    "No puedo borrarle el dolor..."


translate english c4241_5886b1ad:


    "...pero al menos puedo besarla e intentar distraerla de él."


translate english c4241_00fe9c3b:



    voice "voice/c42/4101440a02.opus"
    aoi "\"Mmm... mm... mmmm... mmmph... mm... haah... mmm... mmph... mm... mmmm!!!\""


translate english c4241_b8038586:



    voice "voice/c42/4101450a02.opus"
    aoi "\"Haah... haah... mm... Jejeje... Gracias, Shinichi...\""


translate english c4241_fbd9257f:



    voice "voice/c42/4101460a02.opus"
    aoi "\"Eres... más grande de lo que pensaba...\""


translate english c4241_ca33bd47:



    voice "voice/c42/4101470a02.opus"
    aoi "\"Si me coges... quizá me rompa...\""


translate english c4241_5ffa35fc:


    xy "\"¿Tienes miedo?\""


translate english c4241_01f4e55e:



    voice "voice/c42/4101480a02.opus"
    aoi "\"...Nop. Emoción.\""


translate english c4241_eb700e94:


    "Aoi sonríe."


translate english c4241_ac722d1e:



    voice "voice/c42/4101490a02.opus"
    aoi "\"Bésame... una vez más...\""


translate english c4241_09eae20e:


    "A su petición, accedo encantado—"


translate english c4241_3fcf2af5:



    voice "voice/c42/4101500a02.opus"
    aoi "\"Mmm... mm... mmmph... mmmmm!!!\""


translate english c4241_c6046a02:


    aoi "\"Hnn... mmm... mmmph... mmm! ¡Mmhmmn! ¡Mmmn... mmmph! ¡Mmm... mmmm!!!\""


translate english c4241_1f92c449:


    "Mientras nos besamos, Aoi empieza a mover sus caderas arriba y abajo."


translate english c4241_27e78e25:


    "Su coño está tan apretado que prácticamente me aplasta la polla... y sin embargo se siente tan bien que me mareo."


translate english c4241_a1ef2c4c:



    voice "voice/c42/4101520a02.opus"
    aoi "\"¡Nnhaah! ¡Aah! ¡Aah! No— ¡Aah, aah, aah! ¡Dios!\""


translate english c4241_4e44f7dd:



    voice "voice/c42/4101530a02.opus"
    aoi "\"¡Aoi ha estado...! ¡Reprimida...! ¡Todo este tiempo...! ¡Así que ahora...! ¡Aoi ya está...! ¡Al borde...! ¡Del chispazo...!\""


translate english c4241_f28c1fd5:



    voice "voice/c42/4101540a02.opus"
    aoi "\"¡Aaah! ¡Dios! ¡Ahí! ¡Justo ahí! ¡Provoca mi entrada—con tu verga—!\""


translate english c4241_2a48ca90:



    voice "voice/c42/4101550a02.opus"
    aoi "\"¡Es tan electrizante! ¡Aaaahhh! ¡Mi cuerpo—se siente tan bien—no para—!\""


translate english c4241_cb0cb244:



    voice "voice/c42/4101560a02.opus"
    aoi "\"Shinichi... ¿Puede Aoi... electrizarse? Porque va... a pasar... ¡Mmm... mmmph... mmmm!\""


translate english c4241_f05ec7ec:



    voice "voice/c42/4101580a02.opus"
    aoi "\"¡Aoi va a correrse—Mmmph! ¡Mmmn! ¡Mmmm! ¡Mmmm! ¡Mmm! ¡Mmm! ¡Mmmnnnnmmmmm!\""


translate english c4241_26f0d827:



    voice "voice/c42/4101590a02.opus"
    aoi "\"¡¡¡Nnnngggghhhhh!!!\""


translate english c4241_ffb80ae2:



    voice "voice/c42/4101600a02.opus"
    aoi "\"¡Hnn... nnn... nnng... nnn...! ¡Nnnn... nngh... nn... nnng...!\""


translate english c4241_2e1fdc94:


    "Su cuerpo se convulsiona en el clímax."


translate english c4241_7a50dbb7:


    "Me besa distraídamente, con la mirada desenfocada."


translate english c4241_7667d26d:



    voice "voice/c42/4101610a02.opus"
    aoi "\"Mmn... mmmph... mm... mmmm... mm... Jeje... Mmm... mmm... mm...\""


translate english c4241_388af747:


    xy "\"¿Te dolió?\""


translate english c4241_3d6c8dba:



    voice "voice/c42/4101620a02.opus"
    aoi "\"Fue... tan intenso... Todo mi cuerpo... estaba eléctrico... y mi mente... se quedó en blanco...\""


translate english c4241_b35fd02b:



    voice "voice/c42/4101630a02.opus"
    aoi "\"¿Eso fue... otro glitch?\""


translate english c4241_0620bf22:


    "Susurra tímidamente."


translate english c4241_1e7e8ea2:


    "Limpio suavemente las lágrimas de sus mejillas."


translate english c4241_65663057:



    voice "voice/c42/4101640a02.opus"
    aoi "\"Jejejeje... Aoi sabe qué son estas lágrimas.\""


translate english c4241_23b89fe0:



    voice "voice/c42/4101650a02.opus"
    aoi "\"No son por el dolor.\""


translate english c4241_e6297870:



    voice "voice/c42/4101660a02.opus"
    aoi "\"Son lágrimas de felicidad.\""


translate english c4241_c7bfa62e:


    "Aoi sonríe como si se hubiera quitado toda carga de encima. La abrazo fuerte y nos besamos."


translate english c4241_9a186a9d:



    voice "voice/c42/4101670a02.opus"
    aoi "\"Mmph... mm... mmm... mm... Boop boop... Todavía no te has corrido.\""


translate english c4241_22e47abb:


    xy "\"Cierto...\""


translate english c4241_ddff8081:



    voice "voice/c42/4101680a02.opus"
    aoi "\"¿Por qué no lo arreglamos?\""


translate english c4241_1d958466:


    "Aoi empieza a rebotar sobre mi polla una vez más."


translate english c4241_6c5d234f:



    voice "voice/c42/4101690a02.opus"
    aoi "\"Hnn... mmph... mmm... mmmn... mmmph... mm... mmm... aaah... aaaaah!\""


translate english c4241_a3299ac1:



    voice "voice/c42/4101700a02.opus"
    aoi "\"Oh, wow... Está tan... profundo... dentro de Aoi... Haaah... nnn... ¿Aoi... se va a romper...?\""


translate english c4241_0f827bf1:


    "Actúa como si estuviera preocupada—pero su coño claramente está listo para ello."


translate english c4241_00c0bf31:


    "Sigo presionando, cada vez más fuerte."


translate english c4241_7a66713c:



    voice "voice/c42/4101710a02.opus"
    aoi "\"¡¡¡Mmmnnnnn!!!\""


translate english c4241_42c932d0:


    "Poco a poco, entierro mi longitud dentro de ella."


translate english c4241_f887a433:



    voice "voice/c42/4101720a02.opus"
    aoi "\"Mmmph... mmm... ¿Shinichi...?\""


translate english c4241_88955da7:



    voice "voice/c42/4101730a02.opus"
    aoi "\"¿Lo sientes...? ¿Te sientes dentro de Aoi...?\""


translate english c4241_0bde3497:


    xy "\"Sí... Estoy hasta el fondo.\""


translate english c4241_a6453192:



    voice "voice/c42/4101740a02.opus"
    aoi "\"Aoi nunca te va a soltar... ¡Mmph... mmn... mm... mmm...!\""


translate english c4241_749eabf1:


    "Con sus brazos envueltos a mi alrededor, desliza su lengua en mi boca, más profundo que nunca."


translate english c4241_0b649fa8:


    "En respuesta—"


translate english c4241_ccfdb921:



    voice "voice/c42/4101750a02.opus"
    aoi "\"¡Mmmn... mmmph... mmm... mm...! ¡Aah...! ¡Hnn... aah... aahhaaah!\""


translate english c4241_7a09c922:


    "Empiezo a embestirla lenta y suavemente."


translate english c4241_34c6aa92:


    "Con cada movimiento, su coño se aprieta a mi alrededor, enviando chispas de placer recorriendo mi cuerpo."


translate english c4241_d412dc86:



    voice "voice/c42/4101760a02.opus"
    aoi "\"Ay... Nnn... nn... Es tan... grande...\""


translate english c4241_f69254b6:



    voice "voice/c42/4101780a02.opus"
    aoi "\"Esto es raro... Shinichi... ¿Crees que... Aoi es rara...?\""


translate english c4241_0b374d8c:


    "La expresión de su cara es jodidamente adorable."


translate english c4241_639d9ed0:



    voice "voice/c42/4101790a02.opus"
    aoi "\"¡Haahh! ¡Nnn! ¡Nnnn! ¡Ay, Dios! ¡Dios! ¡Aoi se va a caer!\""


translate english c4241_2f2924f0:



    voice "voice/c42/4101800a02.opus"
    aoi "\"¡Nnhaah! ¡Mmmph! ¡Mmmm! ¡Mmm! ¡Mmmn! ¡Aaah! ¡Aah! ¡Aaah, aah!\""


translate english c4241_8814e625:


    "Al principio sus movimientos son lentos y torpes, pero luego, de la nada, empieza a moverse más rápido."


translate english c4241_4cbead85:


    "Se desplaza sobre mí, empujando contra mis embestidas anguladas."


translate english c4241_ae6b3e10:



    voice "voice/c42/4101810a02.opus"
    aoi "\"¡Mmmph! ¡Mm... mm... mmmn! ¡Mmmpphh! ¡Nnhaah! ¡Aah! ¡Aah! ¡Aah!\""


translate english c4241_4eec1adb:



    voice "voice/c42/4101820a02.opus"
    aoi "\"Perdón—Se suponía—que era tu turno— ¡Pero el chispazo—no para—!\""


translate english c4241_68b71434:



    voice "voice/c42/4101830a02.opus"
    aoi "\"¡Se siente tan bien—y electrizante—y hormiguea! ¡Aoi no—no puede aguantar—!\""


translate english c4241_0a21054f:


    xy "\"¡Me estoy corriendo!\""


translate english c4241_2d8cfa6b:



    voice "voice/c42/4101840a02.opus"
    aoi "\"¡¿Haahh?! ¡Aaahh! ¡Dios! ¡Tu verga! ¡Se está... haciendo aún más grande... y más dura... dentro de Aoi!\""


translate english c4241_d7054ba3:



    voice "voice/c42/4101850a02.opus"
    aoi "\"¡Nnhaah! ¡Nnng! ¡¡¡Nnnnngggghhhh! ¿Te estás corriendo? ¿Te estás electrizando? ¡Nnnnggg!\""


translate english c4241_addd1823:



    voice "voice/c42/4101860a02.opus"
    aoi "\"¡Dámelo! ¡Dame—tu leche— ¡Dame toda tu leche—! ¡Mmph!\""


translate english c4241_8dab2b29:


    "Mientras nos besamos—"


translate english c4241_2cec460c:


    "—me embisto hasta el clímax."


translate english c4241_83a6b4cb:



    voice "voice/c42/4101870a02.opus"
    aoi "\"¡Mmph! ¡Nnhaah! ¡Aah! ¡AAAH! ¡Dios! Gran chispazo... ¡Me voy a correr—!\""


translate english c4241_21f208fb:



    voice "voice/c42/4101880a02.opus"
    aoi "\"¡Haah! ¡AAAH! ¡Aah! ¡NNNG! Me voy a correr... ¡Me voy a cooorrreeeeer!\""


translate english c4241_7c14e699:



    voice "voice/c42/4101890a02.opus"
    aoi "\"¡Aoi se está... corriendoooo!\""


translate english c4241_9bff7d98:



    voice "voice/c42/4101900a02.opus"
    aoi "\"Aahaaah! Nngh... ¡mmm! Mmmm... mm... haah... mm... mmmm... mmm... mmmm...\""


translate english c4241_c5095ef1:



    voice "voice/c42/4101910a02.opus"
    aoi "\"Mmm... mm... Shinichi... ¡Mmph... mmm! Mmm... mmmnn... mmmm...\""


translate english c4241_f3ba2eaa:


    "Con cada chorro de semen, el cuerpo de Aoki se convulsiona en mis brazos."


translate english c4241_e262c4c4:


    "Puedo sentir cada pequeña sacudida contra mi piel."


translate english c4241_7efab5e5:


    "Acunando su pequeña figura, la beso de nuevo."


translate english c4241_12f87f76:



    voice "voice/c42/4101920a02.opus"
    aoi "\"Mmmph... mm... mmm... Shinichi... Tu chispazo... me recargó... tanto... ¡Nnn!\""


translate english c4241_532f4048:



    voice "voice/c42/4101930a02.opus"
    aoi "\"Nnggh... nn... aah... Todavía... te estás corriendo... ¡Nnn... nn... nnnn...!\""


translate english c4241_d087a8f7:



    voice "voice/c42/4101940a02.opus"
    aoi "\"Boop boop... Aoi está tan llena ahora...\""


translate english c4241_054e2bc1:


    "Pero ella no muestra señales de bajarse de mi polla."


translate english c4241_c8e6ad94:


    "En cambio, me mira soñadoramente. Luego su coño se aprieta alrededor de mi miembro más fuerte que nunca."


translate english c4241_c5f7388a:


    "Parece que mi erección no va a ir a ninguna parte todavía."


translate english c4241_76128129:



    voice "voice/c42/4101950a02.opus"
    aoi "\"Mmmph... mm... mmm... Boop boop... ¿Shinichi? Algo es raro...\""


translate english c4241_d7a54c2f:



    voice "voice/c42/4101960a02.opus"
    aoi "\"Te corriste muchísimo... pero... sigues... súper dura...\""


translate english c4241_5fb178b5:



    voice "voice/c42/4101970a02.opus"
    aoi "\"¿Tu verga tiene un glitch?\""


translate english c4241_a188f037:



    voice "voice/c42/4101980a02.opus"
    aoi "\"¿Te hicieron OP por ser el protagonista?\""


translate english c4241_572adb34:


    xy "\"¿Qué tonterías estás diciendo ahora?\""


translate english c4241_c07905f2:



    voice "voice/c42/4101990a02.opus"
    aoi "\"¡Entendido! En ese caso—\""


translate english c4241_c40b5baf:


    "Aoi empuja su culo hacia mí."


translate english c4241_97e3aee4:


    "Sangre, semen y otros fluidos escurren de su coño."


translate english c4241_3d09f8b2:


    "Separa sus nalgas y expone su ojete aún palpitante."



translate english c4241_a6317cb3:



    voice "voice/c42/4102000a02.opus"
    aoi "\"Aoi también lo quiere aquí.\""


translate english c4241_ac9f683e:


    xy "\"¿Aquí, o sea, en tu—?! ¡Pero eso—!\""


translate english c4241_8eae54bf:


    "Me seduce, con sus palabras todavía arrastradas por el placer."


translate english c4241_b23ca2e8:



    voice "voice/c42/4102010a02.opus"
    aoi "\"Mi boca... mi pussy... mi culo... Todos fueron creados... solo para ti...\""


translate english c4241_bb395385:



    voice "voice/c42/4102020a02.opus"
    aoi "\"¿No puedes recargarme?\""


translate english c4241_2b05fd2b:


    "Su ruego es todo el empujón que necesito."


translate english c4241_ce9c93d6:


    xy "\"...¿Estás seguro de esto?\""


translate english c4241_06cb93c9:



    voice "voice/c42/4102030a02.opus"
    aoi "\"Boop boop...\""


translate english c4241_c12df455:


    "Coloco suavemente mi punta contra su entrada."


translate english c4241_21a46f41:


    "Al principio parece demasiado estrecho incluso para un dedo, pero lentamente empieza a abrirse—"


translate english c4241_a30a85c2:



    voice "voice/c42/4102040a02.opus"
    aoi "\"¡Hnn... nnhaah... aaah... aaaaahh...! ¡Nngh... nnn... hnnnnnn!\""


translate english c4241_6486df0f:


    "—y mi longitud se hunde dentro."


translate english c4241_22f0ccff:


    "Está mucho más apretado y profundo que su coño."


translate english c4241_3a03b390:



    voice "voice/c42/4102050a02.opus"
    aoi "\"Hnnn... Está dentro... Aah... nngh... nn... Está dentro, ¿no...?\""


translate english c4241_3d35cc7d:



    voice "voice/c42/4102060a02.opus"
    aoi "\"Hnnn... nngghh... nn... aaghh... nn... Nngghh... aah... nn... nnng... nnn...\""


translate english c4241_48fde165:


    "Se siente tan completamente diferente que no puedo contenerme."


translate english c4241_2f4289fe:


    "Mientras embisto lentamente, puedo sentir el túnel de carne de Aoi succionándome, apretado como una segunda piel."


translate english c4241_50285a64:



    voice "voice/c42/4102070a02.opus"
    aoi "\"¡Hnnn... nn... nnng... aah... aaahh! ¿Se siente... bien... mi culo...?\""


translate english c4241_fec63493:


    xy "\"Sí... Muy bien, de hecho...\""


translate english c4241_27599f2f:



    voice "voice/c42/4102080a02.opus"
    aoi "\"Boop boop... Gra... cias... Tu verga... también se siente... hnn... bien...!\""


translate english c4241_a24efc6b:


    aoi "\"¡Aaah! ¡Hnnng! Dios... Nnn... Las dos a la vez... Es tan intenso... ¡Hnnn!\""


translate english c4241_44f9566d:


    "Me inclino y deslizo mi mano izquierda hacia su pecho."


translate english c4241_8c7cf1ac:


    "Sus senos son pequeños, pero firmes."


translate english c4241_e36304a4:


    "Pellizco su pezón duro con los dedos."


translate english c4241_5e8ad2d0:



    voice "voice/c42/4102100a02.opus"
    aoi "\"Haaahh... Dios... Se siente tan bien... cuando... juegas con mis tetas... ¡HaaaAAAHH!\""


translate english c4241_30da0a18:


    "Mientras tanto, mi mano derecha se desliza hacia su pegajosa y desordenada feminidad."


translate english c4241_c481b749:


    "Separo sus labios y presiono un dedo contra su clítoris hinchado."


translate english c4241_e54b6716:


    aoi "\"¡AAAH! ¡Aah... aaahaaahaaa...! ¡Nnnnggg! Para... ¡Nnng! Es demasiao electrizante... ¡Hnnn!\""


translate english c4241_bcd195f1:


    "Con mis brazos alrededor de ella, queda atrapada en su lugar."


translate english c4241_361cb29c:


    "Superada por el placer, su cuerpo amenaza con derrumbarse bajo mí, pero la sostengo erguida y sigo estimulando sus puntos más débiles por turnos."


translate english c4241_b8b89d67:



    voice "voice/c42/4102130a02.opus"
    aoi "\"¡HAAAHH! Pellizca mis pezones... ¡Hnnn! ¡Así! Jálalos... ¡Aaaaahh!\""


translate english c4241_879daffd:



    voice "voice/c42/4102140a02.opus"
    aoi "\"Juega con... mi clítoris... Hormiguea tanto... ¡Haaahh!\""


translate english c4241_feb17c8c:



    voice "voice/c42/4102150a02.opus"
    aoi "\"¡Aaah! ¡Las dos... las dos a la vez...! ¡Aahh! ¡Se siente... tan increíble...!\""


translate english c4241_18f2ac15:


    aoi "\"¡Aaah! ¡Hnn! Dios, mi clítoris... Si sigues... ¡Aoi va a chorrear!\""


translate english c4241_9ca2f781:



    voice "voice/c42/4102170a02.opus"
    aoi "\"¡Haaah! ¡Aah! ¡Hnnn! ¡Aah! ¡Aah...! ¡Aah! ¡Aah! ¡Aah, aah, aaaaAAAHHH...!\""


translate english c4241_ea6df85e:



    voice "voice/c42/4102180a02.opus"
    aoi "\"¡¡¡Nnnnnggggghhhhhh!!!\""


translate english c4241_4f134021:



    voice "voice/c42/4102190a02.opus"
    aoi "\"¡Hnn... nnn... nnnggh... nnn... hnn... haaah... nnn... nnnngg!\""


translate english c4241_5aeea949:



    voice "voice/c42/4102200a02.opus"
    aoi "\"Pero... Aoi no puede... parar... ¡Haahh...! Se siente tan bien... ¡Aoi no puede... parar...!\""


translate english c4241_1b917a39:



    voice "voice/c42/4102210a02.opus"
    aoi "\"Aoi está... fallando... ¡Me estás dejando la cabeza toda glitcheadaaa...!\""


translate english c4241_eaed8669:


    "La orina escurre al ritmo de sus convulsiones."


translate english c4241_876a2fb5:


    "Pero sigo embistiendo."


translate english c4241_ae5c979a:


    "Su culo está dolorosamente apretado, pero no me detengo."


translate english c4241_5221e096:



    voice "voice/c42/4102220a02.opus"
    aoi "\"Haaahh... nnn... Shinichi... Aoi se está... volviendo... loca...\""


translate english c4241_66cb24a7:



    voice "voice/c42/4102230a02.opus"
    aoi "\"Tu verga... es tan... electrizante... A Aoi... le... encanta...\""


translate english c4241_74e086eb:



    voice "voice/c42/4102240a02.opus"
    aoi "\"¿Puedes... seguir amando... a un desastre con glitches y loca como Aoi...?\""


translate english c4241_fcae8898:


    xy "\"Claro que puedo.\""


translate english c4241_788e9cac:



    voice "voice/c42/4102250a02.opus"
    aoi "\"—!!!\""


translate english c4241_f14bb1f4:


    "Mi susurro la hace convulsionar."


translate english c4241_d68aa4d7:


    "Una poderosa sacudida eléctrica recorre todo su cuerpo."


translate english c4241_0af76569:



    voice "voice/c42/4102260a02.opus"
    aoi "\"Por favor... toma mi cerebro vacío y espaciado... ¡y llénalo de ti...!\""


translate english c4241_c938fc3c:


    "Mientras ella suplica, puedo sentir mi segundo clímax de la noche acercándose rápidamente."


translate english c4241_be030a90:


    "Hora de cruzar la meta."


translate english c4241_ab224b2b:



    voice "voice/c42/4102270a02.opus"
    aoi "\"Shinichi... ¿estás cerca...? ¿Vas a correrte...? ¿Te estás... electrizando...?\""


translate english c4241_8621edfe:



    voice "voice/c42/4102280a02.opus"
    aoi "\"Boop boop... Aoi quiere que... dispares... un cargamento gordo de leche... dentro de Aoi...\""


translate english c4241_07d8bc39:


    aoi "\"¡Haaah... hnnn! ¡Nnng! ¡Nnhaah! ¡Aoi te ama... tanto! ¡AAAAHHH!\""


translate english c4241_030364c4:


    aoi "\"¡Aagh! ¡Hnnn! ¡Aaah! ¡Aah! ¡Aah, aah, aaah, aah, aah, aah, aaaaaahhhh!\""


translate english c4241_425bfb96:



    voice "voice/c42/4102310a02.opus"
    aoi "\"¡AAAAAAAAAAHHHH!\""


translate english c4241_1623d304:



    voice "voice/c42/4102330a02.opus"
    aoi "\"¡Aah... aah... hnn... aaahh! ¡Aah... nngh... nnn... nnnnn... nnnnnnggg!\""


translate english c4241_0a99c580:


    "Cada vez que mi polla palpita, su cuerpo se estremece junto conmigo."


translate english c4241_c8ee8f73:


    "Disparo hasta la última gota de mi carga directamente dentro de su culo."


translate english c4241_979f4534:



    voice "voice/c42/4102340a02.opus"
    aoi "\"Haah... nnn... nnnn... nn...\""


translate english c4241_4d8216a1:



    voice "voice/c42/4102350a02.opus"
    aoi "\"Shinichi... Shinichi... Aaah... Tan llena de hormigueo... A Aoi le encanta... tanto...\""


translate english c4241_6bf9fe50:



    voice "voice/c42/4102360a02.opus"
    aoi "\"Tan llena de tu leche... aah... nngghh... por delante... y por detrás...\""


translate english c4241_43cfc8d6:



    voice "voice/c42/4102370a02.opus"
    aoi "\"Boop boop... Recarga... completa...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
