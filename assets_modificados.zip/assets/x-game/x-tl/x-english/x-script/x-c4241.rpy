

translate english c4241_3ab897a8:



    voice "voice/c42/4100010a02.opus"
    aoi "\"Hyah!\""


translate english c4241_e8190bbf:


    xy "\"Nng...! Ouch...\""


translate english c4241_c6f9e8f2:


    "Aoi me empuja hacia abajo."


translate english c4241_5f77942e:


    xy "\"Aoi...?\""


translate english c4241_709f79b4:


    xy "\"Wh-What are you doing?!\""


translate english c4241_29f4fae7:



    voice "voice/c42/4100020a02.opus"
    aoi "\"Oh, do you prefer clothed sex?\""


translate english c4241_1fce7afe:


    "Aoi se detiene a mitad de quitarse la camisa."


translate english c4241_cff38484:


    xy "\"That's not what I meant and you know it!\""


translate english c4241_434cbc3e:



    voice "voice/c42/4100030a02.opus"
    aoi "\"Please...\""


translate english c4241_0fb6a42f:



    voice "voice/c42/4100040a02.opus"
    aoi "\"Aoi's battery is about to die.\""


translate english c4241_d0b610c5:



    voice "voice/c42/4100050a02.opus"
    aoi "\"And by tomorrow, you'll probably forget everything.\""


translate english c4241_6f9e38e3:



    voice "voice/c42/4100060a02.opus"
    aoi "\"Just pretend this is a dream, okay?\""


translate english c4241_e4f82a95:



    voice "voice/c42/4100070a02.opus"
    aoi "\"Aoi wants to...\""


translate english c4241_52aa83c5:



    voice "voice/c42/4100080a02.opus"
    aoi "\"...get zappy with you.\""


translate english c4241_0accd139:


    xy "\"\"\"......!!!\"!\"\""


translate english c4241_451d3bde:



    voice "voice/c42/4100090a02.opus"
    aoi "\"Don't you want to?\""


translate english c4241_6823f477:


    xy "\"I'm not interested in—\""


translate english c4241_6beab5e3:



    voice "voice/c42/4100100a02.opus"
    aoi "\"Liar.\""


translate english c4241_007df635:


    "Puedo ver el contorno de sus senos asomándose por encima de su blusa parcialmente quitada."


translate english c4241_ea419d52:


    "Sus pequeñas palmas se deslizan suavemente sobre mi cuerpo."


translate english c4241_050d2ebe:


    "El peso de sus caderas empieza a hundirse."


translate english c4241_5f2f615c:


    "Y mi polla definitivamente lo ha notado."


translate english c4241_7d02385c:



    voice "voice/c42/4100110a02.opus"
    aoi "\"Are you trying to lift me with your boner?\""


translate english c4241_b406c818:


    xy "\"Wait, but aren't you feeling sick? We shouldn't—\""


translate english c4241_bca9ef39:



    voice "voice/c42/4100120a02.opus"
    aoi "\"Aoi will be fine.\""


translate english c4241_6a1fcecf:



    voice "voice/c42/4100130a02.opus"
    aoi "\"The event CGs will heal me up.\""


translate english c4241_1a77c956:


    xy "\"But—\""


translate english c4241_a453d57b:



    voice "voice/c42/4100140a02.opus"
    aoi "\"The sex will make me feel better.\""


translate english c4241_fd1026f4:


    "Aoi se sube la falda y empuja sus caderas."


translate english c4241_84040fb0:


    "Puedo sentir sus bragas presionando contra mi ingle."


translate english c4241_b62a2332:


    "Pero de alguna manera, no puedo decir si duele o se siente bien..."


translate english c4241_81a42d1c:


    "Poco a poco, voy perdiendo las ganas de resistirme."


translate english c4241_5a5beacd:



    voice "voice/c42/4100150a02.opus"
    aoi "\"Are you hard up here, too?\""


translate english c4241_b5ee8eb2:


    "Me desabrocha la camisa."


translate english c4241_028aec12:



    voice "voice/c42/4100160a02.opus"
    aoi "\"Touchy touchy...\""


translate english c4241_66854568:


    "Arrastra ligeramente sus uñas contra mi piel, dibuja círculos con sus dedos alrededor de mi pezón y se acerca lentamente hasta que—"


translate english c4241_a6189ce2:


    "—de repente, retira la mano."


translate english c4241_53e9e6ca:


    xy "\"Ah...!\""


translate english c4241_7ff0ac5c:



    voice "voice/c42/4100170a02.opus"
    aoi "\"You want it? Want me to play with them?\""


translate english c4241_60296208:


    xy "\"N-No, of course n—\""


translate english c4241_77c03da0:


    "Antes de que pueda terminar mi frase, Aoi presiona un dedo contra mi pezón."


translate english c4241_b3e7107d:



    voice "voice/c42/4100180a02.opus"
    aoi "\"Does that feel good? Is it zappy?\""


translate english c4241_67be5d69:


    "Me provoca, y estoy completamente a su merced."


translate english c4241_7e1b018a:


    "Cada vez que sus dedos apenas rozan mis pezones, el placer me atraviesa como electricidad al rojo vivo."


translate english c4241_6d87aecf:



    voice "voice/c42/4100190a02.opus"
    aoi "\"Is this your weak spot?\""


translate english c4241_a14efee3:


    xy "\"......!\""


translate english c4241_620d68d6:


    "De alguna manera, Aoi sabe exactamente qué botones presionar."


translate english c4241_87b928ee:


    "Casi como si lo hubiera descubierto de antemano o algo así..."


translate english c4241_95a7ba79:



    voice "voice/c42/4100200a02.opus"
    aoi "\"Boop boop!\""


translate english c4241_fd3a83fc:


    "Aoi no se detiene ni un momento."


translate english c4241_acf0934c:


    "Desabrocha con destreza mi cinturón y baja el cierre de mi bragueta."


translate english c4241_d5c8fc42:


    "Luego baja mis boxers unos centímetros, y mi polla dura asoma."


translate english c4241_3d59acab:


    "Mientras tanto, sus ojos están fijos en los míos."


translate english c4241_2462222c:


    "Ni siquiera mira mi erección. En cambio, ladea la cabeza hacia mí."


translate english c4241_d61aac1c:



    voice "voice/c42/4100210a02.opus"
    aoi "\"Are you horny?\""


translate english c4241_44d811ac:


    "Su mirada es inquisitiva."


translate english c4241_a17a154d:


    "Admito que estoy un poco avergonzado, pero no puedo evitar apartar la vista."


translate english c4241_9c4f2437:


    "Sus mejillas están ligeramente sonrojadas, igual que aquella noche fatídica."


translate english c4241_3654a0df:



    voice "voice/c42/4100220a02.opus"
    aoi "\"Aoi wants to get zappy, too.\""


translate english c4241_f114b3f1:


    "Un escalofrío recorre mi espalda."


translate english c4241_b77d0ad7:


    "Entonces, de repente, el peso se levanta de mi ingle."


translate english c4241_9c005946:


    "Escucho el sonido de ropa arrugándose."


translate english c4241_67ab4976:


    "Antes de que mi mirada pueda desviarse entre sus piernas—"


translate english c4241_c10d9ff0:



    voice "voice/c42/4100230a02.opus"
    aoi "\"Don't.\""


translate english c4241_99e31f2f:


    "—me detiene, y una vez más mis ojos quedan fijos en los suyos, casi como si me hubiera hipnotizado."


translate english c4241_7ef32ee0:



    voice "voice/c42/4100240a02.opus"
    aoi "\"Aah...\""


translate english c4241_b62edc6a:


    "Lo siguiente que siento es una repentina explosión de placer."


translate english c4241_85f8181b:



    voice "voice/c42/4100250a02.opus"
    aoi "\"It's touching...\""


translate english c4241_9ae99110:



    voice "voice/c42/4100260a02.opus"
    aoi "\"Aoi's touching your burning hot cock...\""


translate english c4241_5e3c55fd:


    "Puedo sentir una calidez húmeda presionada justo contra mi centro de placer."


translate english c4241_43146954:



    voice "voice/c42/4100270a02.opus"
    aoi "\"Aoi loves having sex.\""


translate english c4241_ab072018:



    voice "voice/c42/4100280a02.opus"
    aoi "\"And Aoi loves the face you make when you're turned on.\""


translate english c4241_94d95eb9:



    voice "voice/c42/4100290a02.opus"
    aoi "\"And the sounds you make, too.\""


translate english c4241_1a59cd4c:



    voice "voice/c42/4100300a02.opus"
    aoi "\"Makes me curious to see more.\""


translate english c4241_9e9036f3:


    "Puedo sentir su piel... su calor... su pulso... justo contra mi cuerpo."


translate english c4241_9510ac7f:


    "Mi instinto masculino lucha por suprimir mi sentido de la razón."


translate english c4241_5b5e94f3:


    "Joder, quiero metérsela en este mismo instante—"


translate english c4241_1fb4318a:



    voice "voice/c42/4100310a02.opus"
    aoi "\"Don't rush.\""


translate english c4241_4fe2e2c3:


    "Sus dedos rozan mi pezón una vez más."


translate english c4241_5d273892:



    voice "voice/c42/4100320a02.opus"
    aoi "\"You like this?\""


translate english c4241_0ac1ef5a:


    "Esta vez, en lugar de punzar y hurgar, se aferra con firmeza."


translate english c4241_5484d520:


    "Luego lo retuerce y lo tira."


translate english c4241_c2891c4e:



    voice "voice/c42/4100330a02.opus"
    aoi "\"Aoi's gonna make you wait for it.\""


translate english c4241_1de248d6:



    voice "voice/c42/4100340a02.opus"
    aoi "\"Aoi's gonna tease you and tease you and tease you...\""


translate english c4241_d44d9295:



    voice "voice/c42/4100350a02.opus"
    aoi "\"...until you shoot your load.\""


translate english c4241_2f0536c0:



    voice "voice/c42/4100360a02.opus"
    aoi "\"Aoi's gonna drain your balls.\""


translate english c4241_584b12f6:



    voice "voice/c42/4100370a02.opus"
    aoi "\"Your mind will go blank from the pleasure.\""


translate english c4241_375957dd:


    "Su susurro convierte mi cerebro en papilla."


translate english c4241_25600193:


    "En lugar de concentrarse por completo en mis partes bajas, el placer parece extenderse por todo mi cuerpo."


translate english c4241_75350816:



    voice "voice/c42/4100380a02.opus"
    aoi "\"Now you're hard up top AND down south.\""


translate english c4241_6304ff12:



    voice "voice/c42/4100390a02.opus"
    aoi "\"Are you a little deviant?\""


translate english c4241_d1d54220:


    "Mientras susurra, sus labios se contraen inocentemente."


translate english c4241_ee19711b:


    "Quiero más... ¡Quiero sentirla con cada centímetro de mi ser...!"


translate english c4241_b4c79d56:


    "Y tampoco quiero que esto siga siendo unilateral—¡quiero mostrarle cómo me siento por ella!"


translate english c4241_b3a69917:


    "Quiero besarla..."


translate english c4241_e8eb18f4:


    "¡Un beso de verdad esta vez, no solo RCP!"


translate english c4241_ba7c46c6:


    xy "\"Aoi, kiss me...\""


translate english c4241_cb5577a8:



    voice "voice/c42/4100400a02.opus"
    aoi "\"That's not allowed.\""


translate english c4241_82b442a3:



    voice "voice/c42/4100410a02.opus"
    aoi "\"That's Miyuki's job.\""


translate english c4241_d824fef1:


    xy "\"I told you, I don't want—\""


translate english c4241_1f11075b:



    voice "voice/c42/4100420a02.opus"
    aoi "\"This is just a one-night stand.\""


translate english c4241_7e0ed4e8:



    voice "voice/c42/4100430a02.opus"
    aoi "\"Just a glitch... and when you wake up tomorrow, you'll have forgotten it all.\""


translate english c4241_e152bdd4:


    xy "\"No I won't—!\""


translate english c4241_4c98aa59:



    voice "voice/c42/4100440a02.opus"
    aoi "\"Boop boop...\""


translate english c4241_c84601fd:


    xy "\"Huh—?!\""


translate english c4241_bf7791e9:



    voice "voice/c42/4100450a02.opus"
    aoi "\"Instead...\""


translate english c4241_c6a4ae93:



    voice "voice/c42/4100460a02.opus"
    aoi "\"You can kiss me here.\""


translate english c4241_0accd139_1:


    xy "\"\"\"......!!!\"!\"\""


translate english c4241_34f0d648:


    "Aoi está de pie frente a mí."


translate english c4241_7e9758e8:


    "La brisa nocturna trae su calor... y su aroma."


translate english c4241_16a8b893:


    "Su falda se agita con el viento, y debajo de ella—"


translate english c4241_7bef43ae:



    voice "voice/c42/4100470a02.opus"
    aoi "\"Wanna see?\""


translate english c4241_f63a81e7:


    "Aoi pregunta, con el dedo en la boca."


translate english c4241_68c8f85c:


    "Incapaz de contenerme, deslizo una mano por su muslo."


translate english c4241_806618d7:



    voice "voice/c42/4100480a02.opus"
    aoi "\"Aah...!\""


translate english c4241_616d7d03:


    "Su cuerpo se estremece con mi toque."


translate english c4241_86d9a443:


    "Su piel es suave, tersa y flexible."


translate english c4241_5f7960ad:



    voice "voice/c42/4100490a02.opus"
    aoi "\"Aoi's horny, too.\""


translate english c4241_e3ef5d65:



    voice "voice/c42/4100500a02.opus"
    aoi "\"Never felt like this before...\""


translate english c4241_7c4f1c51:


    "Sonríe tímidamente."


translate english c4241_49c2db4a:


    "Me siento impulsado, no por el instinto ni la razón, sino por el amor."


translate english c4241_9dabef61:


    xy "\"Aoi...\""


translate english c4241_1a10c917:



    voice "voice/c42/4100510a02.opus"
    aoi "\"Yeah?\""


translate english c4241_e3d10c8e:


    "Aoi se levanta la falda."


translate english c4241_4b3fa310:


    "La tenue luz de la luna ilumina su perfecto coño."


translate english c4241_f66e67d4:


    "Sus labios suaves y sin vello están ligeramente entreabiertos por el deseo, y los fluidos han empezado a escurrir desde su interior."


translate english c4241_cba76a5c:



    voice "voice/c42/4100520a02.opus"
    aoi "\"...It wants a kiss.\""


translate english c4241_521c13d6:


    "Mi cuerpo se mueve solo, como una marioneta con hilos invisibles."


translate english c4241_8a3434f6:


    "Presiono una mano contra su piel suave..."


translate english c4241_cc5aa387:


    "...y deslizo mi pulgar entre sus labios, separándolos."


translate english c4241_91f9af2b:



    voice "voice/c42/4100530a02.opus"
    aoi "\"Can you see it all?\""


translate english c4241_f7879a54:


    "A diferencia del resto de su piel, su coño está sonrojado, lo suficiente para notarlo incluso en la oscuridad de la noche."


translate english c4241_34c13007:


    "Ahora estamos a solo unos centímetros—a la distancia de una lengua."


translate english c4241_3164e0b2:



    voice "voice/c42/4100540a02.opus"
    aoi "\"It's weird... Even though you're not touching me...\""


translate english c4241_1aa6dbdd:



    voice "voice/c42/4100550a02.opus"
    aoi "\"Aoi feels so... zappy...\""


translate english c4241_fd979e70:


    "Sus fluidos fluyen ante mis ojos."


translate english c4241_e9362c18:


    "Me pregunto qué pasaría si lo lamo..."


translate english c4241_be218c28:



    voice "voice/c42/4100560a02.opus"
    aoi "\"Nnnngg...!!!\""


translate english c4241_7efc9e46:


    "Su cuerpo se convulsiona."


translate english c4241_cbeea6c9:


    "Puedo ver sus manos temblar mientras se aferra a su falda."


translate english c4241_f4ed91c9:


    "Deslizo mi lengua entre sus labios una segunda vez, y luego una tercera."


translate english c4241_71ef43eb:



    voice "voice/c42/4100570a02.opus"
    aoi "\"Ooh... haa... aah... nnn... nnngghh... nnngg!!!\""


translate english c4241_4cf50486:



    voice "voice/c42/4100580a02.opus"
    aoi "\"Wait... Whoa... This is amazing... Shinichi, that feels so good... Nnn... nnhaaaahh!\""


translate english c4241_28733c29:


    "Sus fluidos se mezclan con mi saliva, y los sorbo."


translate english c4241_7dc0486b:


    "Luego empiezo a usar mis labios además de mi lengua."


translate english c4241_516938ae:



    voice "voice/c42/4100590a02.opus"
    aoi "\"Aah... aah... aaahh! Are you sucking it...? Are you sucking... all of me...?\""


translate english c4241_77afabc8:



    voice "voice/c42/4100600a02.opus"
    aoi "\"Hnnnn! You're... being so loud... It's... really sexy...\""


translate english c4241_e1893a7c:



    voice "voice/c42/4100610a02.opus"
    aoi "\"Are you... getting harder, too?\""


translate english c4241_6559cbea:


    "Claro que sí."


translate english c4241_bf8a0f30:


    "A pesar de haber sido casi totalmente ignorada hasta ahora, mi erección sigue creciendo."


translate english c4241_b74c1068:



    voice "voice/c42/4100620a02.opus"
    aoi "\"You're getting horny... from licking my pussy... Shinichi... you're such a deviant...\""


translate english c4241_2a9629b5:



    voice "voice/c42/4100630a02.opus"
    aoi "\"Next... it's my turn... Aoi's gonna make you feel so—Aaahh!!!\""


translate english c4241_148b54a5:


    "Deslizo mi lengua hasta el fondo."


translate english c4241_ea775c9f:


    "Está tan apretado que no estoy seguro de que mi polla quepa."


translate english c4241_2934f990:



    voice "voice/c42/4100640a02.opus"
    aoi "\"AAAH! Aah... Wow... It feels... so good...\""


translate english c4241_b8abcbcf:



    voice "voice/c42/4100650a02.opus"
    aoi "\"Okay... Now it's... Aoi's turn...\""


translate english c4241_fb8c59d5:



    voice "voice/c42/4100660a02.opus"
    aoi "\"...Shinichi?\""


translate english c4241_75fb3796:


    "Lo siento, pero no tengo intención de detenerme aquí."


translate english c4241_e3231f5f:


    "La ignoro y separo sus labios con los dedos, luego presiono mis labios contra su clítoris expuesto y chupo."


translate english c4241_e5b68361:



    voice "voice/c42/4100670a02.opus"
    aoi "\"—?!\""


translate english c4241_7945b4d3:



    voice "voice/c42/4100680a02.opus"
    aoi "\"AAAHH! N-No!!! You can't suck there! It's too intense!\""


translate english c4241_1ce7e3d2:


    "Se retuerce e intenta apartarse."


translate english c4241_9674498a:


    "Pero sigo chupando."


translate english c4241_4d5dda4f:



    voice "voice/c42/4100690a02.opus"
    aoi "\"Haah! Aaah! Aah! It's too much—too much zappy!\""


translate english c4241_21788fb5:



    voice "voice/c42/4100700a02.opus"
    aoi "\"My pussy feels so good... The zappy won't stop... It's never... felt this good before...\""


translate english c4241_0aa83bf8:



    voice "voice/c42/4100710a02.opus"
    aoi "\"It's too much! Too fast! Oh no... Aoi can't hold back!\""


translate english c4241_97e09650:



    voice "voice/c42/4100720a02.opus"
    aoi "\"Haahh! Aah! Oh no! Too zappy! Aah... aah... aah, aah, aah, aah!\""


translate english c4241_7cc5405f:



    voice "voice/c42/4100730a02.opus"
    aoi "\"Aaah... aah... uh...?\""


translate english c4241_4f6ab122:


    "Justo antes de que Aoi llegue al clímax, aparto los labios."


translate english c4241_44f3763e:



    voice "voice/c42/4100740a02.opus"
    aoi "\"Shinichi? Why'd you sto—Nnnnnnggg!!!\""


translate english c4241_ff4518b9:



    voice "voice/c42/4100750a02.opus"
    aoi "\"Haah! AAAH! Not again— You're licking so hard...!\""


translate english c4241_75557bf2:



    voice "voice/c42/4100760a02.opus"
    aoi "\"Hnnn... nnnnggg! Aah! Gonna cum! Aoi's gonna cum—gonna cum from the zappy—!\""


translate english c4241_eed2d26c:



    voice "voice/c42/4100770a02.opus"
    aoi "\"Nnn...\""


translate english c4241_938acadd:


    "De nuevo, me aparto antes de que pueda llegar al orgasmo."


translate english c4241_8db54554:



    voice "voice/c42/4100780a02.opus"
    aoi "\"Why are you teasing me? You're so—AAAAAHHH! Why are you... b-being so mean...? Hnnnn!!!\""


translate english c4241_b52e4dc3:



    voice "voice/c42/4100790a02.opus"
    aoi "\"Quit... doing that... over and over...! Aoi's... so close... so close—Nnnnn!!!\""


translate english c4241_a53851ad:



    voice "voice/c42/4100800a02.opus"
    aoi "\"AAAH! Oh no! Haaaahhh!!! Aoi can feel the sparks—gonna cum, gonna cum!!!\""


translate english c4241_acad8924:



    voice "voice/c42/4100810a02.opus"
    aoi "\"Nnnnn... Shinichi, if you keep this up, Aoi's gonna be ma—aaaAAHH!!!\""


translate english c4241_9be11942:



    voice "voice/c42/4100820a02.opus"
    aoi "\"Oh gosh! That's too much! Don't pinch it—! Hnnn! Aah! Aah! Aah, aah, aah—!\""


translate english c4241_324faac2:



    voice "voice/c42/4100830a02.opus"
    aoi "\"Hnnn... nnn... nnnnn... AAAH!!!\""


translate english c4241_69db83c2:



    voice "voice/c42/4100840a02.opus"
    aoi "\"Aah! Oh no! Oh god, oh god, oh god—!\""


translate english c4241_585a0d17:



    voice "voice/c42/4100850a02.opus"
    aoi "\"Hnng... nn... nnnnnn!!! Why?! Why won't you let me c—AAAAHHH!!!\""


translate english c4241_551a5dcb:



    voice "voice/c42/4100860a02.opus"
    aoi "\"Haaahh! GAH! Aoi's so close... But... Aoi... can't quite get there!\""


translate english c4241_37a01add:



    voice "voice/c42/4100870a02.opus"
    aoi "\"Shinichi... please...\""


translate english c4241_5ab432e8:



    voice "voice/c42/4100880a02.opus"
    aoi "\"Stop... teasing me...\""


translate english c4241_dc00e1b7:



    voice "voice/c42/4100890a02.opus"
    aoi "\"Please... let Aoi... cum...\""


translate english c4241_6d022b25:


    "Sus hombros tiemblan mientras me implora, con los ojos húmedos de lágrimas."


translate english c4241_cfdf1b5e:


    "Me aparto de su clítoris otra vez."


translate english c4241_558c209c:


    xy "\"Will you kiss me now?\""


translate english c4241_b7335b3b:



    voice "voice/c42/4100900a02.opus"
    aoi "\"Kiss you...?\""


translate english c4241_21acc704:



    voice "voice/c42/4100910a02.opus"
    aoi "\"That's not allowed—AAAAAAAHHH!!!\""


translate english c4241_73e48324:


    "En el momento en que empieza a negar con la cabeza, lamo su clítoris ruidosamente de nuevo."


translate english c4241_c0b49feb:



    voice "voice/c42/4100920a02.opus"
    aoi "\"HAAH! AAH! AAAHH! AAH! God! You're no fair! No fair! Nnngg!\""


translate english c4241_a9ec6e2f:



    voice "voice/c42/4100930a02.opus"
    aoi "\"Not again...! Aoi's so close to cumming... again...! But... haah... haah... haah...!\""


translate english c4241_4b9b1289:



    voice "voice/c42/4100940a02.opus"
    aoi "\"Nnnnn...\""


translate english c4241_a9334187:


    xy "\"You sure you can't kiss me?\""


translate english c4241_fd1ffc51:



    voice "voice/c42/4100950a02.opus"
    aoi "\"Aoi really... can't... kiss you... AaaaAAAAAAHHH!!! Stop! We can't—Nnnggghhhh!!!\""


translate english c4241_d2445e68:


    xy "\"You sure you don't want to?\""


translate english c4241_7d85160d:



    voice "voice/c42/4100960a02.opus"
    aoi "\"Aoi... wants... to... but... Boop boop... Aoi... isn't... supposed... to...\""


translate english c4241_1fd443fa:


    xy "\"Why's that?\""


translate english c4241_c0e4da18:



    voice "voice/c42/4100970a02.opus"
    aoi "\"Well—AAHH! Aoi just... can't...!!! Hnnn—nnnngg! Nn... Aoi's... not supposed to, but...!\""


translate english c4241_a6146902:



    voice "voice/c42/4100980a02.opus"
    aoi "\"My... head's... all... fuzzy... Getting...! All...! Messed up...!\""


translate english c4241_e77ccc6a:



    voice "voice/c42/4100990a02.opus"
    aoi "\"Shinichi! Listen... Are you sure...? Are you really... REALLY sure...?\""


translate english c4241_efbb290c:



    voice "voice/c42/4101000a02.opus"
    aoi "\"You have Miyuki, and—!\""


translate english c4241_65711612:


    xy "\"Aoi.\""


translate english c4241_5b4e7076:



    voice "voice/c42/4101010a02.opus"
    aoi "\"Huh...?\""


translate english c4241_496e6f8e:


    "Me levanto y la enfrento."


translate english c4241_3fa3ad74:


    xy "\"I'm in love with you.\""


translate english c4241_11c326d1:


    xy "\"Nobody else matters to me.\""


translate english c4241_72ae9eac:


    xy "\"I choose you, Aoi.\""


translate english c4241_261feac2:


    "De golpe, su rostro se desmorona—y sus emociones se desbordan."


translate english c4241_3bdd553c:



    voice "voice/c42/4101020a02.opus"
    aoi "\"Boop boop... boop boop... boop boop boop boop?\""


translate english c4241_251f2677:



    voice "voice/c42/4101030a02.opus"
    aoi "\"The signal's... messed up... Shinichi's... messed up...\""


translate english c4241_858a4be5:



    voice "voice/c42/4101040a02.opus"
    aoi "\"Aoi... Aoi...\""


translate english c4241_7fd393ca:



    voice "voice/c42/4101050a02.opus"
    aoi "\"Aoi got too zappy... and broke.\""


translate english c4241_f2106892:



    voice "voice/c42/4101060a02.opus"
    aoi "\"Glitched.\""


translate english c4241_80d9c51e:



    voice "voice/c42/4101070a02.opus"
    aoi "\"And the bugs can't be fixed.\""


translate english c4241_84a9df2d:



    voice "voice/c42/4101080a02.opus"
    aoi "\"...Are you sure?\""


translate english c4241_9ce5db7c:



    voice "voice/c42/4101090a02.opus"
    aoi "\"Are you sure you're okay with... Aoi's glitches?\""


translate english c4241_9aa3dc6a:



    voice "voice/c42/4101100a02.opus"
    aoi "\"Laughter, tears, sadness, joy...\""


translate english c4241_ab786da3:



    voice "voice/c42/4101110a02.opus"
    aoi "\"Is Aoi allowed to feel these things? Is Aoi... allowed to love you?\""


translate english c4241_b3fbb876:



    voice "voice/c42/4101120a02.opus"
    aoi "\"Aoi's too weird to be a normal girl... so you'll probably have a hard time being with me...\""


translate english c4241_5b12a82b:



    voice "voice/c42/4101130a02.opus"
    aoi "\"Are you sure this is what you want?\""


translate english c4241_55774ab1:



    voice "voice/c42/4101140a02.opus"
    aoi "\"Will you love me... even with all my glitches?\""


translate english c4241_b90c3f7f:


    xy "\"I will. I do.\""


translate english c4241_442b1da7:



    voice "voice/c42/4101150a02.opus"
    aoi "\"Mmm... mmmmm... mmnnn... mmph... mmmmppphhh...!!!\""


translate english c4241_c8523672:


    "Una chispa de electricidad nos atraviesa."


translate english c4241_a005c105:


    "Nuestros labios se tocan, nuestras lenguas se entrelazan, y el cuerpo de Aoi se convulsiona."


translate english c4241_0e240a76:


    "Pero eso no nos detiene."


translate english c4241_4c8a9576:


    "Presiono mis labios con fuerza contra los suyos, devorándola."


translate english c4241_1126281f:



    voice "voice/c42/4101160a02.opus"
    aoi "\"Haah, haah, haah—mmph... mmmph... mm! Mm! Mmmnn! Mmmppphh!\""


translate english c4241_fbbd4716:



    voice "voice/c42/4101170a02.opus"
    aoi "\"Haah... mmm—It feels... so good... This is... the best kiss Aoi's ever had...\""


translate english c4241_7d708444:



    voice "voice/c42/4101180a02.opus"
    aoi "\"Aoi's wanted you for so long... So, so long...!\""


translate english c4241_b890813a:



    voice "voice/c42/4101190a02.opus"
    aoi "\"Aoi loves being glitchy...\""


translate english c4241_7d993890:



    voice "voice/c42/4101200a02.opus"
    aoi "\"And Aoi will keep on glitching...\""


translate english c4241_0acd79be:



    voice "voice/c42/4101210a02.opus"
    aoi "\"More and more and more... Glitching like crazy...\""


translate english c4241_9d0d8d01:



    voice "voice/c42/4101220a02.opus"
    aoi "\"Glitching out of love for you.\""


translate english c4241_40814ede:


    "Susurra, luego se inclina una vez más."


translate english c4241_2fb39e8a:



    voice "voice/c42/4101230a02.opus"
    aoi "\"Mmph... mmm... mmph, mmmph... mmm... mmm... mmmm... Boop boop...\""


translate english c4241_4029b69a:



    voice "voice/c42/4101240a02.opus"
    aoi "\"Your lips... taste like my pussy... It tastes so good... Aoi never knew...\""


translate english c4241_7287aeae:



    voice "voice/c42/4101250a02.opus"
    aoi "\"You licked it so much... Aoi thought her pussy was gonna melt...\""


translate english c4241_e5155b1e:



    voice "voice/c42/4101260a02.opus"
    aoi "\"So now... mmph... it's your turn... Mmmph... mmm... mmm... mmmmpphh!!!\""


translate english c4241_cdf17376:



    voice "voice/c42/4101270a02.opus"
    aoi "\"Mmm... mmmph... mm... mmmm... mmph...! Your cock is... rock hard...\""


translate english c4241_b7e34eca:


    "Cada palabra que susurra entre besos envía una nueva oleada de electricidad recorriendo mi cuerpo."


translate english c4241_f0a1b120:



    voice "voice/c42/4101280a02.opus"
    aoi "\"Shinichi?\""


translate english c4241_498b8d17:



    voice "voice/c42/4101290a02.opus"
    aoi "\"Will you promise to get me off?\""


translate english c4241_f7610bbc:



    voice "voice/c42/4101300a02.opus"
    aoi "\"Your cock is so hard, it's been leaking for a while now...\""


translate english c4241_7a5713b5:



    voice "voice/c42/4101310a02.opus"
    aoi "\"And my pussy can't wait any longer... It's drooling with lust... Will you promise to fuck me hard?\""


translate english c4241_2203377c:



    voice "voice/c42/4101320a02.opus"
    aoi "\"Aoi's ready to cum like crazy. No more waiting.\""


translate english c4241_7152165a:



    voice "voice/c42/4101330a02.opus"
    aoi "\"Will you let me?\""


translate english c4241_10f7b1d4:


    "Ahora no puedo negárselo."


translate english c4241_0e0eeae7:


    "Mi polla se alza hacia el cielo."


translate english c4241_2065b4a2:


    "Aoi la toca, y rebota como un resorte."


translate english c4241_409acf6b:



    voice "voice/c42/4101340a02.opus"
    aoi "\"Aoi loves it.\""


translate english c4241_b04f0917:



    voice "voice/c42/4101350a02.opus"
    aoi "\"Aoi loves your cock, Shinichi.\""


translate english c4241_52784f97:



    voice "voice/c42/4101360a02.opus"
    aoi "\"The slightest touch makes me zappy.\""


translate english c4241_f9d4eaec:



    voice "voice/c42/4101370a02.opus"
    aoi "\"Time to put it in me.\""


translate english c4241_7fd217ee:



    voice "voice/c42/4101380a02.opus"
    aoi "\"Boop boop... Nnng...\""


translate english c4241_14a6e5e2:


    "Aoi presiona mi punta contra su entrada, ajusta su posición, luego baja lentamente sus caderas."


translate english c4241_f381a346:



    voice "voice/c42/4101390a02.opus"
    aoi "\"Hnng... nn... nnnnngggg!!! Nnhaah... nnng... nnnnnggggghhhh!!!\""


translate english c4241_357e7a0c:


    xy "\"A-Aoi?\""


translate english c4241_d829a873:



    voice "voice/c42/4101400a02.opus"
    aoi "\"Hnn... nnn... nngg... nnnng! It... tingles...!\""


translate english c4241_26449369:


    xy "\"Wait... Are you...?\""


translate english c4241_ae21a51b:


    "Las lágrimas brotan en sus ojos."


translate english c4241_98c62031:


    "Y no son lágrimas de felicidad."


translate english c4241_33152163:


    "Su coño está dolorosamente apretado... Miro hacia abajo y, en efecto, sus fluidos tienen un tenue tinte rojo."


translate english c4241_58139318:


    xy "\"Is this... your first time...?\""


translate english c4241_0326aef3:



    voice "voice/c42/4101410a02.opus"
    aoi "\"Boop boop... Girls in visual novels are always virgins.\""


translate english c4241_6310f965:


    xy "\"Are you seriously talking about video games right now?!\""


translate english c4241_a289ea98:



    voice "voice/c42/4101420a02.opus"
    aoi "\"Glitch or no glitch, that's just who Aoi is.\""


translate english c4241_66736a9b:



    voice "voice/c42/4101430a02.opus"
    aoi "\"Aah... Mmm!\""


translate english c4241_d6777e1a:


    "No puedo borrarle el dolor..."


translate english c4241_5886b1ad:


    "...pero al menos puedo besarla e intentar distraerla de él."


translate english c4241_00fe9c3b:



    voice "voice/c42/4101440a02.opus"
    aoi "\"Mmm... mm... mmmm... mmmph... mm... haah... mmm... mmph... mm... mmmm!!!\""


translate english c4241_b8038586:



    voice "voice/c42/4101450a02.opus"
    aoi "\"Haah... haah... mm... Hehehe... Thank you, Shinichi...\""


translate english c4241_fbd9257f:



    voice "voice/c42/4101460a02.opus"
    aoi "\"You're... bigger than I thought...\""


translate english c4241_ca33bd47:



    voice "voice/c42/4101470a02.opus"
    aoi "\"If you fuck me... maybe I'll break...\""


translate english c4241_5ffa35fc:


    xy "\"Are you scared?\""


translate english c4241_01f4e55e:



    voice "voice/c42/4101480a02.opus"
    aoi "\"...Nope. Excited.\""


translate english c4241_eb700e94:


    "Aoi sonríe."


translate english c4241_ac722d1e:



    voice "voice/c42/4101490a02.opus"
    aoi "\"Kiss me... one more time...\""


translate english c4241_09eae20e:


    "A su petición, accedo encantado—"


translate english c4241_3fcf2af5:



    voice "voice/c42/4101500a02.opus"
    aoi "\"Mmm... mm... mmmph... mmmmm!!!\""


translate english c4241_c6046a02:


    aoi "\"Hnn... mmm... mmmph... mmm! Mmhmmn! Mmmn... mmmph! Mmm... mmmm!!!\""


translate english c4241_1f92c449:


    "Mientras nos besamos, Aoi empieza a mover sus caderas arriba y abajo."


translate english c4241_27e78e25:


    "Su coño está tan apretado que prácticamente me aplasta la polla... y sin embargo se siente tan bien que me mareo."


translate english c4241_a1ef2c4c:



    voice "voice/c42/4101520a02.opus"
    aoi "\"Nnhaah! Aah! Aah! No— Aah, aah, aah! Oh god!\""


translate english c4241_4e44f7dd:



    voice "voice/c42/4101530a02.opus"
    aoi "\"Aoi's been...! Pent up...! All this time...! So now...! Aoi's already...! On the verge...! Of zappy...!\""


translate english c4241_f28c1fd5:



    voice "voice/c42/4101540a02.opus"
    aoi "\"Aaah! Oh god! Right there! Right there! Tease my entrance—with your cock—!\""


translate english c4241_2a48ca90:



    voice "voice/c42/4101550a02.opus"
    aoi "\"It's so zappy! Aaaahhh! My body—feels so good—it won't stop—!\""


translate english c4241_cb0cb244:



    voice "voice/c42/4101560a02.opus"
    aoi "\"Shinichi... Can Aoi... get zappy? Cuz it's... gonna happen... Mmm... mmmph... mmmm!!!\""


translate english c4241_f05ec7ec:



    voice "voice/c42/4101580a02.opus"
    aoi "\"Aoi's gonna cum—Mmmph! Mmmn! Mmmm! Mmmm! Mmm! Mmm! Mmmnnnnmmmmm!!!\""


translate english c4241_26f0d827:



    voice "voice/c42/4101590a02.opus"
    aoi "\"Nnnngggghhhhh!!!\""


translate english c4241_ffb80ae2:



    voice "voice/c42/4101600a02.opus"
    aoi "\"Hnn... nnn... nnng... nnn...! Nnnn... nngh... nn... nnng...!\""


translate english c4241_2e1fdc94:


    "Su cuerpo se convulsiona en el clímax."


translate english c4241_7a50dbb7:


    "Me besa distraídamente, con la mirada desenfocada."


translate english c4241_7667d26d:



    voice "voice/c42/4101610a02.opus"
    aoi "\"Mmn... mmmph... mm... mmmm... mm... Hehe... Mmm... mmm... mm...\""


translate english c4241_388af747:


    xy "\"Did it hurt?\""


translate english c4241_3d6c8dba:



    voice "voice/c42/4101620a02.opus"
    aoi "\"It was... so zappy... My whole body... was electric... and my mind... went all blank...\""


translate english c4241_b35fd02b:



    voice "voice/c42/4101630a02.opus"
    aoi "\"Was that... another glitch?\""


translate english c4241_0620bf22:


    "Susurra tímidamente."


translate english c4241_1e7e8ea2:


    "Limpio suavemente las lágrimas de sus mejillas."


translate english c4241_65663057:



    voice "voice/c42/4101640a02.opus"
    aoi "\"Hehehehe... Aoi knows what these tears are.\""


translate english c4241_23b89fe0:



    voice "voice/c42/4101650a02.opus"
    aoi "\"They're not from the pain.\""


translate english c4241_e6297870:



    voice "voice/c42/4101660a02.opus"
    aoi "\"They're happy tears.\""


translate english c4241_c7bfa62e:


    "Aoi sonríe como si se hubiera quitado toda carga de encima. La abrazo fuerte y nos besamos."


translate english c4241_9a186a9d:



    voice "voice/c42/4101670a02.opus"
    aoi "\"Mmph... mm... mmm... mm... Boop boop... You haven't cum yet.\""


translate english c4241_22e47abb:


    xy "\"True...\""


translate english c4241_ddff8081:



    voice "voice/c42/4101680a02.opus"
    aoi "\"Why don't we fix that?\""


translate english c4241_1d958466:


    "Aoi empieza a rebotar sobre mi polla una vez más."


translate english c4241_6c5d234f:



    voice "voice/c42/4101690a02.opus"
    aoi "\"Hnn... mmph... mmm... mmmn... mmmph... mm... mmm... aaah... aaaaah!\""


translate english c4241_a3299ac1:



    voice "voice/c42/4101700a02.opus"
    aoi "\"Oh wow... It's so... deep... inside me... Haaah... nnn... Is Aoi... gonna break...?\""


translate english c4241_0f827bf1:


    "Actúa como si estuviera preocupada—pero su coño claramente está listo para ello."


translate english c4241_00c0bf31:


    "Sigo presionando, cada vez más fuerte."


translate english c4241_7a66713c:



    voice "voice/c42/4101710a02.opus"
    aoi "\"Mmmnnnnn!!!\""


translate english c4241_42c932d0:


    "Poco a poco, entierro mi longitud dentro de ella."


translate english c4241_f887a433:



    voice "voice/c42/4101720a02.opus"
    aoi "\"Mmmph... mmm... Shinichi...?\""


translate english c4241_88955da7:



    voice "voice/c42/4101730a02.opus"
    aoi "\"Can you feel it...? Can you feel yourself inside me...?\""


translate english c4241_0bde3497:


    xy "\"Yeah... I'm all the way in.\""


translate english c4241_a6453192:



    voice "voice/c42/4101740a02.opus"
    aoi "\"Aoi won't ever let you go... Mmmph... mmn... mm... mmm...!\""


translate english c4241_749eabf1:


    "Con sus brazos envueltos a mi alrededor, desliza su lengua en mi boca, más profundo que nunca."


translate english c4241_0b649fa8:


    "En respuesta—"


translate english c4241_ccfdb921:



    voice "voice/c42/4101750a02.opus"
    aoi "\"Mmmn... mmmph... mmm... mm...!!! Aah...! Hnn... aah... aahhaaah!!!\""


translate english c4241_7a09c922:


    "Empiezo a embestirla lenta y suavemente."


translate english c4241_34c6aa92:


    "Con cada movimiento, su coño se aprieta a mi alrededor, enviando chispas de placer recorriendo mi cuerpo."


translate english c4241_d412dc86:



    voice "voice/c42/4101760a02.opus"
    aoi "\"Ow... Nnn... nn... It's so... big...\""


translate english c4241_f69254b6:



    voice "voice/c42/4101780a02.opus"
    aoi "\"This is weird... Shinichi... Do you think... Aoi's weird...?\""


translate english c4241_0b374d8c:


    "La expresión de su cara es jodidamente adorable."


translate english c4241_639d9ed0:



    voice "voice/c42/4101790a02.opus"
    aoi "\"Haahh! Nnn! Nnnn! Oh gosh! Oh god! Aoi's gonna fall!\""


translate english c4241_2f2924f0:



    voice "voice/c42/4101800a02.opus"
    aoi "\"Nnhaah! Mmmph! Mmmm! Mmm! Mmmn! Aaah! Aah! Aaah, aah!!!\""


translate english c4241_8814e625:


    "Al principio sus movimientos son lentos y torpes, pero luego, de la nada, empieza a moverse más rápido."


translate english c4241_4cbead85:


    "Se desplaza sobre mí, empujando contra mis embestidas anguladas."


translate english c4241_ae6b3e10:



    voice "voice/c42/4101810a02.opus"
    aoi "\"Mmmph! Mm... mm... mmmn! Mmmpphh! Nnhaah! Aah! Aah! Aah!\""


translate english c4241_4eec1adb:



    voice "voice/c42/4101820a02.opus"
    aoi "\"Sorry—This was supposed—to be your turn— But the zappy—won't stop—!\""


translate english c4241_68b71434:



    voice "voice/c42/4101830a02.opus"
    aoi "\"It feels so good—and zappy—and tingly! Aoi can't—can't hold b-back—!\""


translate english c4241_0a21054f:


    xy "\"I'm cumming!\""


translate english c4241_2d8cfa6b:



    voice "voice/c42/4101840a02.opus"
    aoi "\"Haahh?! Aaahh! Oh god!!! Your cock! It's getting... even bigger... and harder... inside me!!!\""


translate english c4241_d7054ba3:



    voice "voice/c42/4101850a02.opus"
    aoi "\"Nnhaah! Nnng! Nnnnngggghhhh!!! Are you cumming? Are you getting zappy? Nnnnggg!!!\""


translate english c4241_addd1823:



    voice "voice/c42/4101860a02.opus"
    aoi "\"Give it to me! Give me—your cum— Give me all your cum—!!! Mmmph!\""


translate english c4241_8dab2b29:


    "Mientras nos besamos—"


translate english c4241_2cec460c:


    "—me embisto hasta el clímax."


translate english c4241_83a6b4cb:



    voice "voice/c42/4101870a02.opus"
    aoi "\"Mmmph! Nnhaah! Aah! AAAH! Oh god! Big zappy... Gonna cum—!\""


translate english c4241_21f208fb:



    voice "voice/c42/4101880a02.opus"
    aoi "\"Haah! AAAH! Aah! NNNG!!! Gonna cum... Gonna cuuuummmm!!!\""


translate english c4241_7c14e699:



    voice "voice/c42/4101890a02.opus"
    aoi "\"Aoi's... cumminggggg!!!\""


translate english c4241_9bff7d98:



    voice "voice/c42/4101900a02.opus"
    aoi "\"Aahaaah! Nngh... mmm! Mmmm... mm... haah... mm... mmmm... mmm... mmmm...\""


translate english c4241_c5095ef1:



    voice "voice/c42/4101910a02.opus"
    aoi "\"Mmm... mm... Shinichi... Mmph... mmm! Mmm... mmmnn... mmmm...\""


translate english c4241_f3ba2eaa:


    "Con cada chorro de semen, el cuerpo de Aoki se convulsiona en mis brazos."


translate english c4241_e262c4c4:


    "Puedo sentir cada pequeña sacudida contra mi piel."


translate english c4241_7efab5e5:


    "Acunando su pequeña figura, la beso de nuevo."


translate english c4241_12f87f76:



    voice "voice/c42/4101920a02.opus"
    aoi "\"Mmmph... mm... mmm... Shinichi... Your zappy... recharged me... so much... Nnn!\""


translate english c4241_532f4048:



    voice "voice/c42/4101930a02.opus"
    aoi "\"Nnggh... nn... aah... You're... still cumming... Nnn... nn... nnnn...!!!\""


translate english c4241_d087a8f7:



    voice "voice/c42/4101940a02.opus"
    aoi "\"Boop boop... Aoi's so full now...\""


translate english c4241_054e2bc1:


    "Pero ella no muestra señales de bajarse de mi polla."


translate english c4241_c8e6ad94:


    "En cambio, me mira soñadoramente. Luego su coño se aprieta alrededor de mi miembro más fuerte que nunca."


translate english c4241_c5f7388a:


    "Parece que mi erección no va a ir a ninguna parte todavía."


translate english c4241_76128129:



    voice "voice/c42/4101950a02.opus"
    aoi "\"Mmmph... mm... mmm... Boop boop... Shinichi? Something's weird...\""


translate english c4241_d7a54c2f:



    voice "voice/c42/4101960a02.opus"
    aoi "\"You came lots and lots... but... you're still... super hard...\""


translate english c4241_5fb178b5:



    voice "voice/c42/4101970a02.opus"
    aoi "\"Is your cock glitched?\""


translate english c4241_a188f037:



    voice "voice/c42/4101980a02.opus"
    aoi "\"Did they make you OP because you're the main character?\""


translate english c4241_572adb34:


    xy "\"What nonsense are you babbling on about now?\""


translate english c4241_c07905f2:



    voice "voice/c42/4101990a02.opus"
    aoi "\"Got it! In that case—\""


translate english c4241_c40b5baf:


    "Aoi empuja su culo hacia mí."


translate english c4241_97e3aee4:


    "Sangre, semen y otros fluidos escurren de su coño."


translate english c4241_3d09f8b2:


    "Separa sus nalgas y expone su ojete aún palpitante."



translate english c4241_a6317cb3:



    voice "voice/c42/4102000a02.opus"
    aoi "\"Aoi wants it here, too.\""


translate english c4241_ac9f683e:


    xy "\"Here, as in your—?! But that's—!\""


translate english c4241_8eae54bf:


    "Me seduce, con sus palabras todavía arrastradas por el placer."


translate english c4241_b23ca2e8:



    voice "voice/c42/4102010a02.opus"
    aoi "\"My mouth... my pussy... my ass... They were all created... just for you...\""


translate english c4241_bb395385:



    voice "voice/c42/4102020a02.opus"
    aoi "\"Can't you recharge me?\""


translate english c4241_2b05fd2b:


    "Su ruego es todo el empujón que necesito."


translate english c4241_ce9c93d6:


    xy "\"...You're sure about this?\""


translate english c4241_06cb93c9:



    voice "voice/c42/4102030a02.opus"
    aoi "\"Boop boop...\""


translate english c4241_c12df455:


    "Coloco suavemente mi punta contra su entrada."


translate english c4241_21a46f41:


    "Al principio parece demasiado estrecho incluso para un dedo, pero lentamente empieza a abrirse—"


translate english c4241_a30a85c2:



    voice "voice/c42/4102040a02.opus"
    aoi "\"Hnn... nnhaah... aaah... aaaaahh...! Nngh... nnn... hnnnnnn!!!\""


translate english c4241_6486df0f:


    "—y mi longitud se hunde dentro."


translate english c4241_22f0ccff:


    "Está mucho más apretado y profundo que su coño."


translate english c4241_3a03b390:



    voice "voice/c42/4102050a02.opus"
    aoi "\"Hnnn... It's in... Aah... nngh... nn... It's in, right...?\""


translate english c4241_3d35cc7d:



    voice "voice/c42/4102060a02.opus"
    aoi "\"Hnnn... nngghh... nn... aaghh... nn... Nngghh... aah... nn... nnng... nnn...\""


translate english c4241_48fde165:


    "Se siente tan completamente diferente que no puedo contenerme."


translate english c4241_2f4289fe:


    "Mientras embisto lentamente, puedo sentir el túnel de carne de Aoi succionándome, apretado como una segunda piel."


translate english c4241_50285a64:



    voice "voice/c42/4102070a02.opus"
    aoi "\"Hnnn... nn... nnng... aah... aaahh! Does... my ass... feel good...?\""


translate english c4241_fec63493:


    xy "\"Yeah... Really good, actually...\""


translate english c4241_27599f2f:



    voice "voice/c42/4102080a02.opus"
    aoi "\"Boop boop... Thank... you... Your cock... feels good... hnn... too...!\""


translate english c4241_a24efc6b:


    aoi "\"Aaah! Hnnng! Oh god... Nnn... Both at once... It's so intense... Hnnn!!!\""


translate english c4241_44f9566d:


    "Me inclino y deslizo mi mano izquierda hacia su pecho."


translate english c4241_8c7cf1ac:


    "Sus senos son pequeños, pero firmes."


translate english c4241_e36304a4:


    "Pellizco su pezón duro con los dedos."


translate english c4241_5e8ad2d0:



    voice "voice/c42/4102100a02.opus"
    aoi "\"Haaahh... Oh god... It feels so good... when you... play with my titties... HaaaAAAHH!!!\""


translate english c4241_30da0a18:


    "Mientras tanto, mi mano derecha se desliza hacia su pegajosa y desordenada feminidad."


translate english c4241_c481b749:


    "Separo sus labios y presiono un dedo contra su clítoris hinchado."


translate english c4241_e54b6716:


    aoi "\"AAAH! Aah... aaahaaahaaa...! Nnnnggg!!! Shtop... Nnng! Ish too zappy... Hnnn!!!\""


translate english c4241_bcd195f1:


    "Con mis brazos alrededor de ella, queda atrapada en su lugar."


translate english c4241_361cb29c:


    "Superada por el placer, su cuerpo amenaza con derrumbarse bajo mí, pero la sostengo erguida y sigo estimulando sus puntos más débiles por turnos."


translate english c4241_b8b89d67:



    voice "voice/c42/4102130a02.opus"
    aoi "\"HAAAHH! Pinch my nipples... Hnnn! Just like that! Pull on them... Aaaaahh!!!\""


translate english c4241_879daffd:



    voice "voice/c42/4102140a02.opus"
    aoi "\"Play with... my clit... It's so tingly... Haaahh!!!\""


translate english c4241_feb17c8c:



    voice "voice/c42/4102150a02.opus"
    aoi "\"Aaah! Both... both at once...!!! Aahh! It feels... so amazing...!!!\""


translate english c4241_18f2ac15:


    aoi "\"Aaah! Hnn! Oh god, my clit... If you keep going... Aoi's gonna squirt!\""


translate english c4241_9ca2f781:



    voice "voice/c42/4102170a02.opus"
    aoi "\"Haaah! Aah! Hnnn! Aah! Aah...! Aah! Aah! Aah, aah, aaaaAAAHHH...!!!\""


translate english c4241_ea6df85e:



    voice "voice/c42/4102180a02.opus"
    aoi "\"Nnnnnggggghhhhhh!!!\""


translate english c4241_4f134021:



    voice "voice/c42/4102190a02.opus"
    aoi "\"Hnn... nnn... nnnggh... nnn... hnn... haaah... nnn... nnnngg!!!\""


translate english c4241_5aeea949:



    voice "voice/c42/4102200a02.opus"
    aoi "\"But... Aoi can't... stop... Haahh...! It feels so good... Aoi can't... stop...!\""


translate english c4241_1b917a39:



    voice "voice/c42/4102210a02.opus"
    aoi "\"Aoi's... glitching... You're making my head all glitchyyy...!\""


translate english c4241_eaed8669:


    "La orina escurre al ritmo de sus convulsiones."


translate english c4241_876a2fb5:


    "Pero sigo embistiendo."


translate english c4241_ae5c979a:


    "Su culo está dolorosamente apretado, pero no me detengo."


translate english c4241_5221e096:



    voice "voice/c42/4102220a02.opus"
    aoi "\"Haaahh... nnn... Shinichi... Aoi's... going... crazy...\""


translate english c4241_66cb24a7:



    voice "voice/c42/4102230a02.opus"
    aoi "\"Your cock... is so... zappy... Aoi... loves... it...\""


translate english c4241_74e086eb:



    voice "voice/c42/4102240a02.opus"
    aoi "\"Can you... still love... a glitchy, crazy mess like me...?\""


translate english c4241_fcae8898:


    xy "\"Of course I can.\""


translate english c4241_788e9cac:



    voice "voice/c42/4102250a02.opus"
    aoi "\"—!!!\""


translate english c4241_f14bb1f4:


    "Mi susurro la hace convulsionar."


translate english c4241_d68aa4d7:


    "Una poderosa sacudida eléctrica recorre todo su cuerpo."


translate english c4241_0af76569:



    voice "voice/c42/4102260a02.opus"
    aoi "\"Please... take my spacey, empty brain... and fill it up with you...!!!\""


translate english c4241_c938fc3c:


    "Mientras ella suplica, puedo sentir mi segundo clímax de la noche acercándose rápidamente."


translate english c4241_be030a90:


    "Hora de cruzar la meta."


translate english c4241_ab224b2b:



    voice "voice/c42/4102270a02.opus"
    aoi "\"Shinichi... are you close...? Are you gonna cum...? Are you... getting zappy...?\""


translate english c4241_8621edfe:



    voice "voice/c42/4102280a02.opus"
    aoi "\"Boop boop... Aoi wants you to... shoot... a fat load of cum... inside me...\""


translate english c4241_07d8bc39:


    aoi "\"Haaah... hnnn! Nnng! Nnhaah! Aoi loves you... so much! AAAAHHH!\""


translate english c4241_030364c4:


    aoi "\"Aagh! Hnnn! Aaah! Aah! Aah, aah, aaah, aah, aah, aah, aaaaaahhhh!!!\""


translate english c4241_425bfb96:



    voice "voice/c42/4102310a02.opus"
    aoi "\"AAAAAAAAAAHHHH!!!\""


translate english c4241_1623d304:



    voice "voice/c42/4102330a02.opus"
    aoi "\"Aah... aah... hnn... aaahh! Aah... nngh... nnn... nnnnn... nnnnnnggg!!!\""


translate english c4241_0a99c580:


    "Cada vez que mi polla palpita, su cuerpo se estremece junto conmigo."


translate english c4241_c8ee8f73:


    "Disparo hasta la última gota de mi carga directamente dentro de su culo."


translate english c4241_979f4534:



    voice "voice/c42/4102340a02.opus"
    aoi "\"Haah... nnn... nnnn... nn...\""


translate english c4241_4d8216a1:



    voice "voice/c42/4102350a02.opus"
    aoi "\"Shinichi... Shinichi... Aaah... So full of tingly... Aoi loves it... so much...\""


translate english c4241_6bf9fe50:



    voice "voice/c42/4102360a02.opus"
    aoi "\"So full of your cum... aah... nngghh... in both front... and back...\""


translate english c4241_43cfc8d6:



    voice "voice/c42/4102370a02.opus"
    aoi "\"Boop boop... Recharge... complete...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
