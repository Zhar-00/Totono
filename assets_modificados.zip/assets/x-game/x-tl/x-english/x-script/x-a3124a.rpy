

translate english a3124a_52364f33:


    "Supongamos que de verdad hay un Dios allá afuera."


translate english a3124a_c21432b7:


    "Si Él pudiera cambiar mi destino... y hacer posible lo imposible..."


translate english a3124a_933b8e1a:


    "¿Qué pediría a cambio?"


translate english a3124a_30f807e2:


    "¿A qué me vería forzado a sacrificar?"


translate english a3124a_c7076e5b:


    xy "\"¡Basta! ¡Por favor!\""


translate english a3124a_0c51b735:


    "Presa del pánico, suelto las palabras."


translate english a3124a_aacb170d:


    "Algo dentro de mi cabeza me dice que debo detenerla antes de que haga algo que nunca se pueda deshacer."


translate english a3124a_92bda2be:



    voice "voice/a31/24a00010a02.opus"
    aoi "\"¿Shinichi...?\""


translate english a3124a_178860ee:


    xy "\"En serio, por favor no hagas esto.\""


translate english a3124a_fb2c2080:



    voice "voice/a31/24a00020a02.opus"
    aoi "\"Boop boop...\""


translate english a3124a_ef293794:



    voice "voice/a31/24a00030a02.opus"
    aoi "\"¿Estás seguro?\""


translate english a3124a_97fb438f:



    voice "voice/a31/24a00040a02.opus"
    aoi "\"Ahora mismo vas directo a un final malo.\""


translate english a3124a_99fbab15:



    voice "voice/a31/24a00050a02.opus"
    aoi "\"¿De verdad es eso lo que quieres?\""


translate english a3124a_18f6e2a5:


    "Nada de mi vida podría llamarse un \"bad ending.\""


translate english a3124a_d3c0b84e:


    "Claro, no es nada especial, pero aun así es divertida."


translate english a3124a_da44114c:


    "Tampoco NECESITO salir con Miyuki. Nuestra amistad actual ya es más de lo que jamás podría pedir."


translate english a3124a_44edc9cd:


    "Esa es la verdad, simple y llanamente."


translate english a3124a_7cbf6134:


    "Ni siquiera necesito pensarlo dos veces."


translate english a3124a_dc742007:


    xy "\"Esto es lo que quiero.\""


translate english a3124a_2c6572cc:


    xy "\"Soy feliz solo siendo amigos.\""


translate english a3124a_33f1e0b1:



    voice "voice/a31/24a00060a02.opus"
    aoi "\"Amigos...\""


translate english a3124a_adbfcb75:


    "Justo cuando la palabra sale de sus labios..."


translate english a3124a_fe70279c:


    "...las nubes se disipan, justo ante mis ojos."


translate english a3124a_dc547175:


    "¿Fue un acto de Dios? Sinceramente, no lo sé."


translate english a3124a_9b373c05:


    "Quizá de verdad tenga el poder de cambiar las cosas."


translate english a3124a_8d1584fa:


    "Pero no necesito ningún milagro divino."


translate english a3124a_707bace2:


    "Solo quiero que las cosas sigan como siempre."


translate english a3124a_38c16093:


    "...Me diré a mí mismo que todo esto fue solo un sueño."


translate english a3124a_86761ec5:


    "Una ilusión. Una alucinación."


translate english a3124a_e1545e75:


    "Es decir, ¿qué más podría haber sido?"


translate english a3124a_7862f5a8:


    xy "\"Vamos a buscar a Miyuki.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
