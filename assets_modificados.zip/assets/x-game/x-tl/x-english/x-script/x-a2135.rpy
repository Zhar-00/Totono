

translate english a2135_0b4e67a3:



    voice "voice/a21/3500010a02.opus"
    aoi "\"Down the hatch!\""


translate english a2135_d84dd8cb:



    voice "voice/a21/3500020a02.opus"
    aoi "\"Ggllpp... ggllpp... ggllpp...\""


translate english a2135_62a276c5:



    voice "voice/a21/3500030a02.opus"
    aoi "\"Whew...!\""


translate english a2135_e3b55c4c:



    voice "voice/a21/3500040a02.opus"
    aoi "\"That hit the spot.\""


translate english a2135_58a62b96:


    xy "\"Don't get me wrong, I'm glad you enjoyed it, but...\""


translate english a2135_8d1f021c:


    xy "\"Is that really all you're having for lunch?\""


translate english a2135_2a2b6f1d:



    voice "voice/a21/3500050a02.opus"
    aoi "\"Yup.\""


translate english a2135_28a613c3:


    "Todo lo que Aoi trajo para el almuerzo hoy es una sola lata de Yabaley's."


translate english a2135_4b866610:



    voice "voice/a21/3500060a01.opus"
    mx "\"Your parents won't make you anything to take to school?\""


translate english a2135_aa02f0e7:



    voice "voice/a21/3500070a02.opus"
    aoi "\"Nope.\""


translate english a2135_a912435b:


    xy "\"She lives in a manga cafe these days.\""


translate english a2135_35d013cd:



    voice "voice/a21/3500080a01.opus"
    mx "\"A manga cafe?!\""


translate english a2135_f4dec77e:



    voice "voice/a21/3500090a02.opus"
    aoi "\"Yup.\""


translate english a2135_5b43b044:



    voice "voice/a21/3500100a01.opus"
    mx "\"I had no idea...\""


translate english a2135_b607c94c:


    "Miyuki se queda callada y mira al suelo."


translate english a2135_4a5b71f0:


    "Parece estar contemplando algo."


translate english a2135_292801fb:


    "No es que la culpe. La situación familiar de Aoi es bastante pesada."


translate english a2135_5546660b:



    voice "voice/a21/3500110a02.opus"
    aoi "\"Boop boop...?\""


translate english a2135_f715e3bc:



    voice "voice/a21/3500120a02.opus"
    aoi "\"Shinichi, is Miyuki mad at me?\""


translate english a2135_5e66737e:


    xy "\"Mmm, I don't think so, but—\""


translate english a2135_5ba0056c:



    voice "voice/a21/3500130a01.opus"
    mx "\"Mukou-san! If you ever have any problems, I want you to come talk to me.\""


translate english a2135_1335a3b4:



    voice "voice/a21/3500140a01.opus"
    mx "\"I'm not sure I'll have a solution, but... I'm happy to hear you out, at least.\""


translate english a2135_6bcc3370:



    voice "voice/a21/3500150a02.opus"
    aoi "\"Hear me out?\""


translate english a2135_f69a4991:



    voice "voice/a21/3500160a01.opus"
    mx "\"I'll even give you some advice.\""


translate english a2135_4f7aabda:



    voice "voice/a21/3500170a02.opus"
    aoi "\"Boop boop... boop boop... boop boop boop...\""


translate english a2135_438940e3:


    xy "\"You don't have to talk about it if you don't want to, though.\""


translate english a2135_3b2d3b02:



    voice "voice/a21/3500180a02.opus"
    aoi "\"Got it! Just thought of one.\""


translate english a2135_d15066c5:



    voice "voice/a21/3500190a02.opus"
    aoi "\"One time, Aoi almost got kicked out of the cafe.\""


translate english a2135_1afc7e2c:



    voice "voice/a21/3500200a01.opus"
    mx "\"Wow, those jerks! What happened?\""


translate english a2135_42cff1f6:



    voice "voice/a21/3500210a02.opus"
    aoi "\"Power outage.\""


translate english a2135_d19693bb:



    voice "voice/a21/3500220a01.opus"
    mx "\"The power went out?\""


translate english a2135_10b640c5:



    voice "voice/a21/3500230a02.opus"
    aoi "\"Cuz Aoi put a hairpin in the wall socket.\""


translate english a2135_8696dcff:



    voice "voice/a21/3500240a02.opus"
    aoi "\"ZAP!\""


translate english a2135_54216ba2:



    voice "voice/a21/3500250a01.opus"
    mx "\"...Sounds like you deserved it.\""


translate english a2135_47374f0e:



    voice "voice/a21/3500260a02.opus"
    aoi "\"Boop boop...?\""


translate english a2135_e94752db:


    "Dios, ¿hizo eso en el CAFÉ...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
