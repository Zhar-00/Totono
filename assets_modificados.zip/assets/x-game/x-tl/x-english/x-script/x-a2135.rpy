

translate english a2135_0b4e67a3:



    voice "voice/a21/3500010a02.opus"
    aoi "\"¡Hasta el fondo!\""


translate english a2135_d84dd8cb:



    voice "voice/a21/3500020a02.opus"
    aoi "\"Ggllpp... ggllpp... ggllpp...\""


translate english a2135_62a276c5:



    voice "voice/a21/3500030a02.opus"
    aoi "\"¡Uf...!\""


translate english a2135_e3b55c4c:



    voice "voice/a21/3500040a02.opus"
    aoi "\"Eso cayó bien.\""


translate english a2135_58a62b96:


    xy "\"No me malinterpretes, me alegra que lo disfrutaras, pero...\""


translate english a2135_8d1f021c:


    xy "\"¿Eso es de verdad todo lo que vas a almorzar?\""


translate english a2135_2a2b6f1d:



    voice "voice/a21/3500050a02.opus"
    aoi "\"Sí.\""


translate english a2135_28a613c3:


    "Todo lo que Aoi trajo para el almuerzo hoy es una sola lata de Yabaley's."


translate english a2135_4b866610:



    voice "voice/a21/3500060a01.opus"
    mx "\"¿Tus padres no te preparan algo para llevar a la escuela?\""


translate english a2135_aa02f0e7:



    voice "voice/a21/3500070a02.opus"
    aoi "\"Nop.\""


translate english a2135_a912435b:


    xy "\"Vive en un café de manga estos días.\""


translate english a2135_35d013cd:



    voice "voice/a21/3500080a01.opus"
    mx "\"¡¿Un café de manga?!\""


translate english a2135_f4dec77e:



    voice "voice/a21/3500090a02.opus"
    aoi "\"Sí.\""


translate english a2135_5b43b044:



    voice "voice/a21/3500100a01.opus"
    mx "\"No tenía idea...\""


translate english a2135_b607c94c:


    "Miyuki se queda callada y mira al suelo."


translate english a2135_4a5b71f0:


    "Parece estar contemplando algo."


translate english a2135_292801fb:


    "No es que la culpe. La situación familiar de Aoi es bastante pesada."


translate english a2135_5546660b:



    voice "voice/a21/3500110a02.opus"
    aoi "\"¿Bip bip...?\""


translate english a2135_f715e3bc:



    voice "voice/a21/3500120a02.opus"
    aoi "\"Shinichi, ¿Miyuki está enojada conmigo?\""


translate english a2135_5e66737e:


    xy "\"Mmm, no creo, pero—\""


translate english a2135_5ba0056c:



    voice "voice/a21/3500130a01.opus"
    mx "\"¡Mukou-san! Si alguna vez tienes algún problema, quiero que vengas a hablarme.\""


translate english a2135_1335a3b4:



    voice "voice/a21/3500140a01.opus"
    mx "\"No estoy segura de tener una solución, pero... al menos con gusto te escucho.\""


translate english a2135_6bcc3370:



    voice "voice/a21/3500150a02.opus"
    aoi "\"¿Escucharme?\""


translate english a2135_f69a4991:



    voice "voice/a21/3500160a01.opus"
    mx "\"Incluso te daré algún consejo.\""


translate english a2135_4f7aabda:



    voice "voice/a21/3500170a02.opus"
    aoi "\"Bip bip... bip bip... bip bip bip...\""


translate english a2135_438940e3:


    xy "\"Aunque no tienes que hablar de eso si no quieres.\""


translate english a2135_3b2d3b02:



    voice "voice/a21/3500180a02.opus"
    aoi "\"¡Entendido! Acabo de pensar en uno.\""


translate english a2135_d15066c5:



    voice "voice/a21/3500190a02.opus"
    aoi "\"Una vez, casi echan a Aoi del café.\""


translate english a2135_1afc7e2c:



    voice "voice/a21/3500200a01.opus"
    mx "\"¡Wow, qué groseros! ¿Qué pasó?\""


translate english a2135_42cff1f6:



    voice "voice/a21/3500210a02.opus"
    aoi "\"Corte de energía.\""


translate english a2135_d19693bb:



    voice "voice/a21/3500220a01.opus"
    mx "\"¿Se fue la luz?\""


translate english a2135_10b640c5:



    voice "voice/a21/3500230a02.opus"
    aoi "\"Porque Aoi puso una horquilla en el enchufe.\""


translate english a2135_8696dcff:



    voice "voice/a21/3500240a02.opus"
    aoi "\"¡ZAS!\""


translate english a2135_54216ba2:



    voice "voice/a21/3500250a01.opus"
    mx "\"...Suena a que te lo merecías.\""


translate english a2135_47374f0e:



    voice "voice/a21/3500260a02.opus"
    aoi "\"¿Bip bip...?\""


translate english a2135_e94752db:


    "Dios, ¿hizo eso en el CAFÉ...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
