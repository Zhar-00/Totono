

translate english a2132_b91a0a4c:



    voice "voice/a21/3200010a02.opus"
    aoi "\"Bleh... It's hot...\""



translate english a2132_f4ae83b4:



    voice "voice/a21/3200020a01.opus"
    mx "\"It seems summer's rolled around once again.\""


translate english a2132_5d062450:


    xy "\"Wanna hit up Kurakami?\""


translate english a2132_3f6c5fed:



    voice "voice/a21/3200030a02.opus"
    aoi "\"What's Kurakami?\""


translate english a2132_dc85e0ed:


    xy "\"Kurakami Electronics. It's right down the street from the school.\""


translate english a2132_5b70f52e:


    xy "\"They sell ice cream there.\""


translate english a2132_a172b340:


    xy "\"Every now and then I go there after school with my friends.\""


translate english a2132_b7fc7e68:



    voice "voice/a21/3200040a02.opus"
    aoi "\"With your friends...?\""



translate english a2132_a3b8a989:


    "Aoi mira hacia Miyuki."


translate english a2132_b2ffabb3:



    voice "voice/a21/3200050a02.opus"
    aoi "\"Miyuki, wanna go get ice cream t—\""


translate english a2132_e921165a:



    voice "voice/a21/3200060a01.opus"
    mx "\"Excuse me?\""


translate english a2132_5c2432bd:



    voice "voice/a21/3200070a02.opus"
    aoi "\"Boop boop...?\""


translate english a2132_1d079149:


    xy "\"Chill! It's nothing! Just forget it, Miyuki!\""


translate english a2132_ce7cbb60:


    "La mirada de Miyuki es tan feroz que no puedo evitar intervenir para calmar la situación."


translate english a2132_95dbba49:



    voice "voice/a21/3200080a02.opus"
    aoi "\"Um, Shinichi?\""


translate english a2132_0b2e779f:



    voice "voice/a21/3200090a02.opus"
    aoi "\"Miyuki's shooting sparks from her eyes!\""


translate english a2132_e3628c5a:


    xy "\"I think you pissed her off...\""


translate english a2132_4f82619e:



    voice "voice/a21/3200100a02.opus"
    aoi "\"How?\""


translate english a2132_517d5cbd:


    xy "\"Maybe the part where you called her 'Miyuki' despite the fact that she asked you a million times to stop?\""


translate english a2132_bc9ac114:



    voice "voice/a21/3200110a02.opus"
    aoi "\"Boop boop...?\""


translate english a2132_b12949fa:


    "Dicho esto, tengo la sensación de que hay algo más que eso..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
