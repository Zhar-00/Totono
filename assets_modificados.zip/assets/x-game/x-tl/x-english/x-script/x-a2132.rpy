

translate english a2132_b91a0a4c:



    voice "voice/a21/3200010a02.opus"
    aoi "\"Bleh... Está caliente...\""



translate english a2132_f4ae83b4:



    voice "voice/a21/3200020a01.opus"
    mx "\"Parece que el verano llegó otra vez.\""


translate english a2132_5d062450:


    xy "\"¿Quieres ir a Kurakami?\""


translate english a2132_3f6c5fed:



    voice "voice/a21/3200030a02.opus"
    aoi "\"¿Qué es Kurakami?\""


translate english a2132_dc85e0ed:


    xy "\"Kurakami Electronics. Está justo bajando la calle de la escuela.\""


translate english a2132_5b70f52e:


    xy "\"Venden helado ahí.\""


translate english a2132_a172b340:


    xy "\"De vez en cuando voy allí después de clases con mis amigos.\""


translate english a2132_b7fc7e68:



    voice "voice/a21/3200040a02.opus"
    aoi "\"¿Con tus amigos...?\""



translate english a2132_a3b8a989:


    "Aoi mira hacia Miyuki."


translate english a2132_b2ffabb3:



    voice "voice/a21/3200050a02.opus"
    aoi "\"Miyuki, ¿quieres ir por helado—\""


translate english a2132_e921165a:



    voice "voice/a21/3200060a01.opus"
    mx "\"¿Perdón?\""


translate english a2132_5c2432bd:



    voice "voice/a21/3200070a02.opus"
    aoi "\"¿Bip bip...?\""


translate english a2132_1d079149:


    xy "\"¡Calma! ¡No es nada! ¡Solo olvídalo, Miyuki!\""


translate english a2132_ce7cbb60:


    "La mirada de Miyuki es tan feroz que no puedo evitar intervenir para calmar la situación."


translate english a2132_95dbba49:



    voice "voice/a21/3200080a02.opus"
    aoi "\"Emm, ¿Shinichi?\""


translate english a2132_0b2e779f:



    voice "voice/a21/3200090a02.opus"
    aoi "\"¡Miyuki está echando chispas por los ojos!\""


translate english a2132_e3628c5a:


    xy "\"Creo que la enfadaste...\""


translate english a2132_4f82619e:



    voice "voice/a21/3200100a02.opus"
    aoi "\"¿Cómo?\""


translate english a2132_517d5cbd:


    xy "\"¿Quizás la parte donde la llamaste \"Miyuki\" a pesar de que te pidió un millón de veces que pararas?\""


translate english a2132_bc9ac114:



    voice "voice/a21/3200110a02.opus"
    aoi "\"¿Bip bip...?\""


translate english a2132_b12949fa:


    "Dicho esto, tengo la sensación de que hay algo más que eso..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
