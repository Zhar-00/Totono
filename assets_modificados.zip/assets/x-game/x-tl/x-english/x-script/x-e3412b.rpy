

translate english e3412b_f6e8ee6e:


    "No quiero arriesgarme a resfriarme, así que me meto en la cama y me duermo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
