

translate english e2011_fd5b4ac9:



    voice "voice/e20/1100010a01.opus"
    mx "\"Oh, that's right...\""


translate english e2011_a184f3cc:



    voice "voice/e20/1100020a01.opus"
    mx "\"Today's a special day for me and YOU...\""


translate english e2011_09982758:



    voice "voice/e20/1100030a01.opus"
    mx "\"Do YOU know what I'm referring to?\""


translate english e2011_b94ae4d3:


    xy "\"Huh? Er...\""


translate english e2011_25d5fe84:


    "Reviso la fecha en el calendario, pero todavía no tengo ni idea..."


translate english e2011_8b0a1b31:



    voice "voice/e20/1100040a01.opus"
    mx "\"Yeah, I wouldn't expect you to know, Shinichi.\""


translate english e2011_ac1753f6:



    voice "voice/e20/1100050a01.opus"
    mx "\"Today marks one week since YOU first arrived here.\""


translate english e2011_156972f7:



    voice "voice/e20/1100060a01.opus"
    mx "\"How do YOU like it? Have YOU acclimated to everything?\""


translate english e2011_df9b0a4a:


    xy "\"Y-Yeah, I guess...\""


translate english e2011_d0148fbf:


    "Cuando empezamos a vivir en el mismo apartamento, se volvió bastante incómodo a veces..."


translate english e2011_5b4435f2:


    "Pero a estas alturas diría que estoy empezando a acostumbrarme."


translate english e2011_9e487730:



    voice "voice/e20/1100070a01.opus"
    mx "\"Hmm... Gotcha.\""


translate english e2011_24a3bb75:



    voice "voice/e20/1100080a01.opus"
    mx "\"Well then, I think I'll give you a little present.\""


translate english e2011_05f3c5db:


    xy "\"Present?\""


translate english e2011_ab79d838:



    voice "voice/e20/1100090a01.opus"
    mx "\"As a gift for spending a full week with me here...\""


translate english e2011_c6ce2c98:



    voice "voice/e20/1100100a01.opus"
    mx "\"...I'll let you raise my affection meter a whole bunch.\""


translate english e2011_b6b6f8b9:



    voice "voice/e20/1100110a01.opus"
    mx "\"Don't want to? Too bad.\""


translate english e2011_5afa96be:



    voice "voice/e20/1100120a01.opus"
    mx "\"After all, Shinichi... You have no reason to decline a kiss from your girlfriend.\""


translate english e2011_93c32c9f:



    voice "voice/e20/1100130a01.opus"
    mx "\"Isn't that right, Shinichi?\""


translate english e2011_bf162564:


    "Me mira apasionadamente y se acerca."


translate english e2011_2c602193:


    "Sé lo suaves que son esos labios..."


translate english e2011_662374a7:


    "Y no puedo negarme."


translate english e2011_7f2b7bc0:



    voice "voice/e20/1100140a01.opus"
    mx "\"I really love you, you know.\""


translate english e2011_c71d82bc:



    voice "voice/e20/1100150a01.opus"
    mx "\"Mmmph... mm... mmm... mmmph!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
