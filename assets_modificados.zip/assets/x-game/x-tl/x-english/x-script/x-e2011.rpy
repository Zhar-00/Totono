

translate english e2011_fd5b4ac9:



    voice "voice/e20/1100010a01.opus"
    mx "\"Ah, es cierto...\""


translate english e2011_a184f3cc:



    voice "voice/e20/1100020a01.opus"
    mx "\"Hoy es un día especial para mí y para TI...\""


translate english e2011_09982758:



    voice "voice/e20/1100030a01.opus"
    mx "\"¿TÚ sabes a qué me refiero?\""


translate english e2011_b94ae4d3:


    xy "\"¿Eh? Emm...\""


translate english e2011_25d5fe84:


    "Reviso la fecha en el calendario, pero todavía no tengo ni idea..."


translate english e2011_8b0a1b31:



    voice "voice/e20/1100040a01.opus"
    mx "\"Sí, no esperaba que lo supieras, Shinichi.\""


translate english e2011_ac1753f6:



    voice "voice/e20/1100050a01.opus"
    mx "\"Hoy se cumple una semana desde que TÚ llegaste aquí.\""


translate english e2011_156972f7:



    voice "voice/e20/1100060a01.opus"
    mx "\"¿Qué te parece? ¿Ya te adaptaste a todo?\""


translate english e2011_df9b0a4a:


    xy "\"S-Sí, supongo...\""


translate english e2011_d0148fbf:


    "Cuando empezamos a vivir en el mismo apartamento, se volvió bastante incómodo a veces..."


translate english e2011_5b4435f2:


    "Pero a estas alturas diría que estoy empezando a acostumbrarme."


translate english e2011_9e487730:



    voice "voice/e20/1100070a01.opus"
    mx "\"Hmm... Entiendo.\""


translate english e2011_24a3bb75:



    voice "voice/e20/1100080a01.opus"
    mx "\"Bueno, entonces, creo que te daré un pequeño regalo.\""


translate english e2011_05f3c5db:


    xy "\"¿Regalo?\""


translate english e2011_ab79d838:



    voice "voice/e20/1100090a01.opus"
    mx "\"Como obsequio por pasar una semana entera conmigo aquí...\""


translate english e2011_c6ce2c98:



    voice "voice/e20/1100100a01.opus"
    mx "\"...te dejaré subir un montón mi medidor de afecto.\""


translate english e2011_b6b6f8b9:



    voice "voice/e20/1100110a01.opus"
    mx "\"¿No quieres? Qué pena.\""


translate english e2011_5afa96be:



    voice "voice/e20/1100120a01.opus"
    mx "\"Después de todo, Shinichi... No tienes razón para rechazar un beso de tu novia.\""


translate english e2011_93c32c9f:



    voice "voice/e20/1100130a01.opus"
    mx "\"¿No es así, Shinichi?\""


translate english e2011_bf162564:


    "Me mira apasionadamente y se acerca."


translate english e2011_2c602193:


    "Sé lo suaves que son esos labios..."


translate english e2011_662374a7:


    "Y no puedo negarme."


translate english e2011_7f2b7bc0:



    voice "voice/e20/1100140a01.opus"
    mx "\"De verdad te amo, sabes.\""


translate english e2011_c71d82bc:



    voice "voice/e20/1100150a01.opus"
    mx "\"Mmmph... mm... mmm... mmmph!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
