

translate english e1171_31038d58:



    voice "voice/e11/7100010a01.opus"
    mx "\"Good morning.\""


translate english e1171_368391ff:



    voice "voice/e11/7100020a01.opus"
    mx "\"...Yeah.\""


translate english e1171_3cf62cd2:



    voice "voice/e11/7100030a01.opus"
    mx "\"I'm happy here.\""


translate english e1171_eca6cce2:



    voice "voice/e11/7100040a01.opus"
    mx "\"I'll always believe in YOU, okay?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
