

translate english e1171_31038d58:



    voice "voice/e11/7100010a01.opus"
    mx "\"Buenos días.\""


translate english e1171_368391ff:



    voice "voice/e11/7100020a01.opus"
    mx "\"...Sí.\""


translate english e1171_3cf62cd2:



    voice "voice/e11/7100030a01.opus"
    mx "\"Soy feliz aquí.\""


translate english e1171_eca6cce2:



    voice "voice/e11/7100040a01.opus"
    mx "\"Siempre creeré en TI, ¿sí?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
