

translate english c5182_0134c10f:


    xy "\"Man, this store REALLY goes all-out with the cat theme...\""


translate english c5182_01201faa:



    voice "voice/c51/8200010a01.opus"
    mx "\"S-Sure does, huh?\""


translate english c5182_62f527de:


    xy "\"Uh, Miyuki? You okay?\""


translate english c5182_fb398d68:



    voice "voice/c51/8200020a01.opus"
    mx "\"Honestly? No! Not really!\""


translate english c5182_1fa8cf4f:


    xy "\"Haah...\""


translate english c5182_5d4e3219:


    "Como siempre, Miyuki tiene una debilidad total por las cosas de gatos, y ahora está ahogándose en la inundación de ternura."


translate english c5182_70a054dc:


    xy "\"Don't you come here a lot, though?\""


translate english c5182_4eedd945:



    voice "voice/c51/8200030a01.opus"
    mx "\"I do indeed! And I'll have you know, I recently managed to stop passing out!\""


translate english c5182_61aaf4a3:


    xy "\"Good for you...\""


translate english c5182_b0bdce9a:


    "Acabemos con esto de una vez..."


translate english c5182_aa5af3ca:


    "Nos dirigimos al estante de collares."


translate english c5182_1f8bcc8f:


    xy "\"Man, they have a lot to choose from...\""


translate english c5182_98442600:



    voice "voice/c51/8200040a01.opus"
    mx "\"They're so cute...\""


translate english c5182_b3defb32:


    "La vitrina está llena de collares de todos los tamaños y colores."


translate english c5182_545c6029:


    "Algunos tienen cintas bordadas, otros están hechos con cuentas de colores, otros tienen volantes en los bordes..."


translate english c5182_85ca6ef9:


    xy "\"What do you guys think?\""


translate english c5182_b39152cd:



    voice "voice/c51/8200050a01.opus"
    mx "\"How about this one? It's got a cute little heart pendant!\""


translate english c5182_f32f5273:


    xy "\"Uh, Miyuki? Eru's a boy.\""


translate english c5182_97c5ea90:



    voice "voice/c51/8200060a01.opus"
    mx "\"Oh... Right.\""


translate english c5182_e98cdfa6:


    "Normalmente siempre mantiene la cabeza fría, pero cuando se trata de gatos, hombre, todo se va por la ventana..."


translate english c5182_54fe18a5:



    voice "voice/c51/8200070a02.opus"
    aoi "\"Boop boop...\""


translate english c5182_d6498e66:



    voice "voice/c51/8200080a02.opus"
    aoi "\"This one's good.\""


translate english c5182_76b7d54e:


    "Aoi elige un collar con un cascabel."


translate english c5182_63ee8d4f:



    voice "voice/c51/8200090a01.opus"
    mx "\"Oh, that's cute! I like this little touch!\""


translate english c5182_78cc6aa6:


    xy "\"Ooh, me too.\""


translate english c5182_6cb8df09:


    "Al mirarlo de cerca, el cascabel tiene forma de cabeza de gato."


translate english c5182_c18f38eb:



    voice "voice/c51/8200100a01.opus"
    mx "\"That'll look great on him.\""


translate english c5182_788965dd:



    voice "voice/c51/8200110a02.opus"
    aoi "\"Yeah! Definitely!\""


translate english c5182_4f860d86:


    xy "\"But don't cats hate bells?\""


translate english c5182_babe7d14:



    voice "voice/c51/8200120a01.opus"
    mx "\"I think it varies from cat to cat.\""


translate english c5182_e40fc8c3:



    voice "voice/c51/8200130a02.opus"
    aoi "\"Eru can handle it. Don't worry.\""


translate english c5182_07a41432:


    "Bueno, confío en que Aoi probablemente sabe de qué habla."


translate english c5182_432ebbfc:


    "Además, Eru ha estado un poco esquivo últimamente... Muchas veces ni siquiera viene cuando lo llamo..."


translate english c5182_2eb598a6:


    "Un cascabel probablemente haría encontrarlo diez veces más fácil."


translate english c5182_a13e97e3:


    xy "\"Let's go with this one, then.\""


translate english c5182_e1b601bd:



    voice "voice/c51/8200140a02.opus"
    aoi "\"Got it!\""


translate english c5182_87a2eb87:


    "Pagamos en la caja, luego tomamos nuestra compra."


translate english c5182_22fdfbbd:


    "Mientras tanto, Miyuki charla con la dependienta."


translate english c5182_f1d3d26d:


    "Está bastante claro por su conversación que ha estado aquí docenas de veces..."


translate english c5182_5e7b7a0f:


    xy "\"You and the cashier seem to get along pretty well, eh?\""


translate english c5182_9e26e774:



    voice "voice/c51/8200150a01.opus"
    mx "\"Well, I like to swing by whenever I have the chance.\""


translate english c5182_d46e361d:



    voice "voice/c51/8200160a01.opus"
    mx "\"And apparently Aoi's a regular, too.\""


translate english c5182_673365b8:



    voice "voice/c51/8200170a01.opus"
    mx "\"Didn't seem to recognize you, unfortunately.\""


translate english c5182_9f82d8f1:


    xy "\"No surprise there...\""


translate english c5182_0537e63d:


    "Al fin y al cabo, solo soy un don nadie."


translate english c5182_204fd214:


    "Estoy acostumbrado a que nadie recuerde mi cara."


translate english c5182_9cfa6046:


    xy "\"I mean, it's only my second time shopping here.\""


translate english c5182_1e649262:



    voice "voice/c51/8200180a01.opus"
    mx "\"What? Really?\""


translate english c5182_c3b6e4d9:


    xy "\"Yeah. The first time was when I bought that hairpin for Aoi, remember?\""


translate english c5182_04f9d785:



    voice "voice/c51/8200190a01.opus"
    mx "\"Oh...\""


translate english c5182_17a1d032:


    xy "\"Hmm? What's wrong?\""


translate english c5182_894f5ea2:



    voice "voice/c51/8200200a01.opus"
    mx "\"Oh, no, it's nothing.\""


translate english c5182_8654e629:



    voice "voice/c51/8200210a01.opus"
    mx "\"Let's get going.\""


translate english c5182_ae2e019c:


    xy "\"Sounds good.\""



translate english c5182_6d13b42c:


    "Algo en el comportamiento de Miyuki me pareció extraño justo ahora, pero qué más da."


translate english c5182_6a4d07d4:


    xy "\"Wait... Huh?\""


translate english c5182_fe14482a:


    xy "\"Where's Aoi?\""


translate english c5182_ea55ef75:



    voice "voice/c51/8200220a02.opus"
    aoi "\"Right here.\""


translate english c5182_1a2aaed9:


    xy "\"Whoa!!!\""


translate english c5182_d233cffa:


    "Está sentada junto a una figura de gato de la suerte, con su mameluco de gatito."


translate english c5182_37204e3f:


    xy "\"What are you doing?\""


translate english c5182_6dc3bafd:



    voice "voice/c51/8200230a02.opus"
    aoi "\"Aoi's pretending to be a beckoning cat!\""


translate english c5182_e77b53e6:


    xy "\"Okay, but... why...?\""


translate english c5182_139e8c40:



    voice "voice/c51/8200240a02.opus"
    aoi "\"Cats have the power to summon lots of customers!\""


translate english c5182_cda792e4:


    "Si tú lo dices..."


translate english c5182_0accd139:


    xy "\"......\""


translate english c5182_45b20e94:


    "Justo entonces, por capricho, agarro uno de los juguetes para gatos de la pared."


translate english c5182_dd7a97a7:



    voice "voice/c51/8200250a02.opus"
    aoi "\"Meow!\""


translate english c5182_8e9d09c4:



    voice "voice/c51/8200260a02.opus"
    aoi "\"Meow, meow!\""


translate english c5182_c980ae61:



    voice "voice/c51/8200270a02.opus"
    aoi "\"Meow, meow, meow, meow!\""


translate english c5182_d7805cc1:


    "Aparentemente está realmente comprometida con esto de los gatos."


translate english c5182_e7bca93f:


    "Esto es algo lindo—"


translate english c5182_d67805b7:



    voice "voice/c51/8200280a01.opus"
    mx "\"Hnng!\""


translate english c5182_8ccac16b:


    "Detrás de mí, Miyuki se desmaya..."


translate english c5182_1ece8533:


    "...y se estrella contra el estante."


translate english c5182_ba29d522:


    xy "\"Not again...\""


translate english c5182_4f9b2f8b:



    voice "voice/c51/8200290a02.opus"
    aoi "\"Boop boop?\""


translate english c5182_97699cdb:


    "Soltando una disculpa a la dependienta, los tres limpiamos apresuradamente nuestro desastre."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
