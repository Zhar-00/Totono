

translate english c5182_0134c10f:


    xy "\"Vaya, esta tienda REALMENTE se esfuerza con el tema de los gatos...\""


translate english c5182_01201faa:



    voice "voice/c51/8200010a01.opus"
    mx "\"S-Sí, ¿eh?\""


translate english c5182_62f527de:


    xy "\"Eh, ¿Miyuki? ¿Estás bien?\""


translate english c5182_fb398d68:



    voice "voice/c51/8200020a01.opus"
    mx "\"¿Honestamente? ¡No! ¡Para nada!\""


translate english c5182_1fa8cf4f:


    xy "\"Haah...\""


translate english c5182_5d4e3219:


    "Como siempre, Miyuki tiene una debilidad total por las cosas de gatos, y ahora está ahogándose en la inundación de ternura."


translate english c5182_70a054dc:


    xy "\"Pero tú vienes aquí seguido, ¿no?\""


translate english c5182_4eedd945:



    voice "voice/c51/8200030a01.opus"
    mx "\"¡En efecto! ¡Y que sepas que recientemente logré dejar de desmayarme!\""


translate english c5182_61aaf4a3:


    xy "\"Bien por ti...\""


translate english c5182_b0bdce9a:


    "Acabemos con esto de una vez..."


translate english c5182_aa5af3ca:


    "Nos dirigimos al estante de collares."


translate english c5182_1f8bcc8f:


    xy "\"Vaya, tienen mucho donde elegir...\""


translate english c5182_98442600:



    voice "voice/c51/8200040a01.opus"
    mx "\"Son tan lindos...\""


translate english c5182_b3defb32:


    "La vitrina está llena de collares de todos los tamaños y colores."


translate english c5182_545c6029:


    "Algunos tienen cintas bordadas, otros están hechos con cuentas de colores, otros tienen volantes en los bordes..."


translate english c5182_85ca6ef9:


    xy "\"¿Qué opinan ustedes?\""


translate english c5182_b39152cd:



    voice "voice/c51/8200050a01.opus"
    mx "\"¿Qué tal este? ¡Tiene un lindo dije de corazoncito!\""


translate english c5182_f32f5273:


    xy "\"Eh, ¿Miyuki? Eru es macho.\""


translate english c5182_97c5ea90:



    voice "voice/c51/8200060a01.opus"
    mx "\"Oh... Cierto.\""


translate english c5182_e98cdfa6:


    "Normalmente siempre mantiene la cabeza fría, pero cuando se trata de gatos, hombre, todo se va por la ventana..."


translate english c5182_54fe18a5:



    voice "voice/c51/8200070a02.opus"
    aoi "\"Boop boop...\""


translate english c5182_d6498e66:



    voice "voice/c51/8200080a02.opus"
    aoi "\"Este está bien.\""


translate english c5182_76b7d54e:


    "Aoi elige un collar con un cascabel."


translate english c5182_63ee8d4f:



    voice "voice/c51/8200090a01.opus"
    mx "\"¡Oh, qué lindo! ¡Me gusta este detallecito!\""


translate english c5182_78cc6aa6:


    xy "\"Uy, a mí también.\""


translate english c5182_6cb8df09:


    "Al mirarlo de cerca, el cascabel tiene forma de cabeza de gato."


translate english c5182_c18f38eb:



    voice "voice/c51/8200100a01.opus"
    mx "\"Se le va a ver genial.\""


translate english c5182_788965dd:



    voice "voice/c51/8200110a02.opus"
    aoi "\"¡Sí! ¡Sin duda!\""


translate english c5182_4f860d86:


    xy "\"¿Pero los gatos no odian las campanas?\""


translate english c5182_babe7d14:



    voice "voice/c51/8200120a01.opus"
    mx "\"Creo que varía de gato a gato.\""


translate english c5182_e40fc8c3:



    voice "voice/c51/8200130a02.opus"
    aoi "\"Eru puede con eso. No te preocupes.\""


translate english c5182_07a41432:


    "Bueno, confío en que Aoi probablemente sabe de qué habla."


translate english c5182_432ebbfc:


    "Además, Eru ha estado un poco esquivo últimamente... Muchas veces ni siquiera viene cuando lo llamo..."


translate english c5182_2eb598a6:


    "Un cascabel probablemente haría encontrarlo diez veces más fácil."


translate english c5182_a13e97e3:


    xy "\"Entonces nos llevamos este.\""


translate english c5182_e1b601bd:



    voice "voice/c51/8200140a02.opus"
    aoi "\"¡Entendido!\""


translate english c5182_87a2eb87:


    "Pagamos en la caja, luego tomamos nuestra compra."


translate english c5182_22fdfbbd:


    "Mientras tanto, Miyuki charla con la dependienta."


translate english c5182_f1d3d26d:


    "Está bastante claro por su conversación que ha estado aquí docenas de veces..."


translate english c5182_5e7b7a0f:


    xy "\"Tú y la cajera parecen llevarse bastante bien, ¿eh?\""


translate english c5182_9e26e774:



    voice "voice/c51/8200150a01.opus"
    mx "\"Bueno, me gusta pasar cuando tengo la oportunidad.\""


translate english c5182_d46e361d:



    voice "voice/c51/8200160a01.opus"
    mx "\"Y al parecer Aoi también es cliente frecuente.\""


translate english c5182_673365b8:



    voice "voice/c51/8200170a01.opus"
    mx "\"Lástima que no pareció reconocerte.\""


translate english c5182_9f82d8f1:


    xy "\"No me sorprende...\""


translate english c5182_0537e63d:


    "Al fin y al cabo, solo soy un don nadie."


translate english c5182_204fd214:


    "Estoy acostumbrado a que nadie recuerde mi cara."


translate english c5182_9cfa6046:


    xy "\"O sea, solo es la segunda vez que compro aquí.\""


translate english c5182_1e649262:



    voice "voice/c51/8200180a01.opus"
    mx "\"¿Qué? ¿En serio?\""


translate english c5182_c3b6e4d9:


    xy "\"Sí. La primera vez fue cuando le compré ese prendedor a Aoi, ¿recuerdas?\""


translate english c5182_04f9d785:



    voice "voice/c51/8200190a01.opus"
    mx "\"Oh...\""


translate english c5182_17a1d032:


    xy "\"¿Hmm? ¿Qué pasa?\""


translate english c5182_894f5ea2:



    voice "voice/c51/8200200a01.opus"
    mx "\"Oh, no, nada.\""


translate english c5182_8654e629:



    voice "voice/c51/8200210a01.opus"
    mx "\"Vámonos.\""


translate english c5182_ae2e019c:


    xy "\"Suena bien.\""



translate english c5182_6d13b42c:


    "Algo en el comportamiento de Miyuki me pareció extraño justo ahora, pero qué más da."


translate english c5182_6a4d07d4:


    xy "\"Espera... ¿Huh?\""


translate english c5182_fe14482a:


    xy "\"¿Dónde está Aoi?\""


translate english c5182_ea55ef75:



    voice "voice/c51/8200220a02.opus"
    aoi "\"Aquí.\""


translate english c5182_1a2aaed9:


    xy "\"¡¡¡Whoa!!!\""


translate english c5182_d233cffa:


    "Está sentada junto a una figura de gato de la suerte, con su mameluco de gatito."


translate english c5182_37204e3f:


    xy "\"¿Qué haces?\""


translate english c5182_6dc3bafd:



    voice "voice/c51/8200230a02.opus"
    aoi "\"¡Aoi está fingiendo ser un gato que llama!\""


translate english c5182_e77b53e6:


    xy "\"Vale, pero... ¿por qué...?\""


translate english c5182_139e8c40:



    voice "voice/c51/8200240a02.opus"
    aoi "\"¡Los gatos tienen el poder de atraer muchos clientes!\""


translate english c5182_cda792e4:


    "Si tú lo dices..."


translate english c5182_0accd139:


    xy "\"......\""


translate english c5182_45b20e94:


    "Justo entonces, por capricho, agarro uno de los juguetes para gatos de la pared."


translate english c5182_dd7a97a7:



    voice "voice/c51/8200250a02.opus"
    aoi "\"¡Miau!\""


translate english c5182_8e9d09c4:



    voice "voice/c51/8200260a02.opus"
    aoi "\"¡Miau, miau!\""


translate english c5182_c980ae61:



    voice "voice/c51/8200270a02.opus"
    aoi "\"¡Miau, miau, miau, miau!\""


translate english c5182_d7805cc1:


    "Aparentemente está realmente comprometida con esto de los gatos."


translate english c5182_e7bca93f:


    "Esto es algo lindo—"


translate english c5182_d67805b7:



    voice "voice/c51/8200280a01.opus"
    mx "\"¡Hnng!\""


translate english c5182_8ccac16b:


    "Detrás de mí, Miyuki se desmaya..."


translate english c5182_1ece8533:


    "...y se estrella contra el estante."


translate english c5182_ba29d522:


    xy "\"Otra vez no...\""


translate english c5182_4f9b2f8b:



    voice "voice/c51/8200290a02.opus"
    aoi "\"¿Boop boop?\""


translate english c5182_97699cdb:


    "Soltando una disculpa a la dependienta, los tres limpiamos apresuradamente nuestro desastre."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
