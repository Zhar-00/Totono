

translate english a2192a_660f1fce:


    xy "\"Here, this is for you.\""


translate english a2192a_1f1e2275:


    "Le entrego su regalo a Miyuki."


translate english a2192a_85c7726c:



    voice "voice/a21/92a00010a01.opus"
    mx "\"And now this is for you.\""


translate english a2192a_ef4017dc:


    "De inmediato se lo pasa a Aoi."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
