

translate english e1167d_986a1614:


    "Mi plegaria se transmite más allá de los confines más lejanos del cielo—"


translate english e1167d_664433d1:


    "Hay un desgarro en el tejido del espacio—"


translate english e1167d_5c679cda:


    "Se abre de la nada—"


translate english e1167d_276e9645:


    "—y empieza a consumir—"


translate english e1167d_ea8552ce:


    "Las sombras se desprenden—"


translate english e1167d_62525c08:


    "Los colores se desvanecen—"


translate english e1167d_e4360fe0:


    "Los bocetos se inclinan y sesgan—"


translate english e1167d_062ab833:


    "Las líneas se desvanecen—"


translate english e1167d_4bf7fc07:


    "El mundo entero está—"


translate english e1167d_d8c11d2a:


    "—empezando a fallar—!"


translate english e1167d_350e2e38:


    "El programa se inicia automáticamente."


translate english e1167d_3997f2af:



    voice "voice/e11/67d00010a01.opus"
    mx "\"Wha—?!\""


translate english e1167d_d7f0e455:


    "La puerta se abre, y Miyuki entra corriendo al salón."


translate english e1167d_f052c07b:


    "Su compostura se ha ido por completo."


translate english e1167d_8b5f2fb4:



    voice "voice/e11/67d00020a01.opus"
    mx "\"No way...!\""


translate english e1167d_1388a969:


    "Me empuja y toma el teléfono."


translate english e1167d_6f4d0fd3:



    voice "voice/e11/67d00030a01.opus"
    mx "\"How...?! Why...?!\""


translate english e1167d_b21bad8c:


    "Miyuki entrecierra los ojos. En efecto, algún programa está corriendo, justo ahí en la pantalla."


translate english e1167d_395cbe4d:



    voice "voice/e11/67d00040a01.opus"
    mx "¡Lo hackeé para que no entrara...!\""


translate english e1167d_cdfbee0e:



    voice "voice/e11/67d00050a01.opus"
    mx "\"There's no way YOU could have gotten that information from anywhere in this game!!!\""


translate english e1167d_1edb7c4c:


    "Me mira con ojos inyectados en sangre."


translate english e1167d_17303199:



    voice "voice/e11/67d00060a01.opus"
    mx "\"Is it just sheer coincidence...? It can't be!\""


translate english e1167d_a44ff109:



    voice "voice/e11/67d00070a01.opus"
    mx "\"Aoi's code number lists her birthday twice.\""


translate english e1167d_ab492ba6:



    voice "voice/e11/67d00080a01.opus"
    mx "\"The 4th digit would have to be a 0 or 1.\""


translate english e1167d_3835a769:



    voice "voice/e11/67d00090a01.opus"
    mx "\"And YOU were told over and over...\""


translate english e1167d_b35029d6:



    voice "voice/e11/67d00100a01.opus"
    mx "\"So there's no way YOU'd put in this number by chance.\""


translate english e1167d_60b455b2:


    "Baja la mirada con tristeza."


translate english e1167d_9dd66ffd:



    voice "voice/e11/67d00110a01.opus"
    mx "\"Is this YOUR second playthrough?\""


translate english e1167d_0d8b9175:



    voice "voice/e11/67d00120a01.opus"
    mx "\"Or did YOU go read a walkthrough online?\""


translate english e1167d_a24fc882:


    voice "voice/e11/67d00130a01.opus"



translate english e1167d_a2ca3d54:


    mx "\"In the end... YOU betrayed me?\""


translate english e1167d_e3adb631:


    xy "\"What...?\""


translate english e1167d_915ef084:


    "How did I \"betray\"perdí?"



translate english e1167d_0b2948f1:


    "Solo quiero que haga lo correcto—"


translate english e1167d_7d873cca:



    voice "voice/e11/67d00140a01.opus"
    mx "\"YOU were tricking me the whole time, weren't you?\""


translate english e1167d_204819e9:


    xy "\"Miyuki...?\""


translate english e1167d_8e3ac3d8:



    voice "voice/e11/67d00150a01.opus"
    mx "Solo querías ver cómo reaccionaría, ¿es eso?\""


translate english e1167d_3813e36e:



    voice "voice/e11/67d00160a01.opus"
    mx "\"So you decided to screw around with me?\""


translate english e1167d_c662186f:


    xy "\"What? That's n—\""


translate english e1167d_718dd0a0:



    voice "voice/e11/67d00170a01.opus"
    mx "\"I'll never forgive you for this!!!\""


translate english e1167d_8118ac8d:


    "Miyuki balancea su bate."


translate english e1167d_541e9355:


    "La mirada en sus ojos es mortalmente seria."


translate english e1167d_370a7c6a:


    "Está en serio a punto de matarme."


translate english e1167d_f29c9e5b:


    "Instintivamente, aprieto los ojos cerrados."


translate english e1167d_c9fc7446:


    "Me encojo con los brazos protegiendo mi cabeza."


translate english e1167d_39e7c143:


    "Pero..."


translate english e1167d_4ff4e9a6:



    voice "voice/e11/67d00180a01.opus"
    mx "\"—!!!\""



translate english e1167d_f191361c:


    "Hay una sacudida eléctrica, y algo golpea el suelo."


translate english e1167d_ab7fbc31:


    "Ya no puedo sentir a Miyuki ahí."


translate english e1167d_1e620890:


    "Mis ojos se abren de golpe."


translate english e1167d_d22b0ce5:


    xy "\"Aoi?\""


translate english e1167d_fcf6dd40:



    voice "voice/e11/67d00190a02.opus"
    aoi "\"Boop boop...\""


translate english e1167d_7070350b:


    "Miyuki está desplomada en el suelo—"


translate english e1167d_95cbba91:


    "—y alguien más está huyendo del cuarto."


translate english e1167d_ca90e95a:


    xy "\"Aoi—?!\""


translate english e1167d_487b36ae:


    "Reviso a Miyuki. Parece que solo está inconsciente."


translate english e1167d_f7604a14:


    "La recuesto contra la pared, luego me apresuro tras Aoi."


translate english e1167d_0f3acdda:


    "Aoi acelera por el pasillo, y la persigo."


translate english e1167d_44818d40:


    "Lleva el teléfono de Miyuki en la mano..."


translate english e1167d_69a0ac13:


    xy "\"I'm glad you're back!\""


translate english e1167d_dc97b240:



    voice "voice/e11/67d00200a02.opus"
    aoi "\"\"\"\"\"\"\"......Aoi?\"\"\"\"\"\"\""


translate english e1167d_8f5003e7:


    xy "\"Uh, Aoi? Are you listening?\""


translate english e1167d_0775479c:



    voice "voice/e11/67d00210a02.opus"
    aoi "\"\"\"\"\"\"\"......Aoi?\"\"\"\"\"\"\""


translate english e1167d_6ee2d6c9:


    xy "\"Wait up!\""


translate english e1167d_0dd1c12c:



    voice "voice/e11/67d00220a02.opus"
    aoi "\"\"\"\"\"\"\"......Aoi?\"\"\"\"\"\"\""


translate english e1167d_88b4bd9e:


    xy "\"I did this for you, you know!\""


translate english e1167d_9ec41264:



    voice "voice/e11/67d00230a02.opus"
    aoi "\"\"\"\"\"\"\"......Aoi?\"\"\"\"\"\"\""


translate english e1167d_98f7f707:


    xy "\"You could at least say thank you!\""


translate english e1167d_fd20a737:



    voice "voice/e11/67d00240a02.opus"
    aoi "\"\"\"\"\"\"\"......Aoi?\"\"\"\"\"\"\""


translate english e1167d_e9f85736:


    xy "\"Aoi!\""


translate english e1167d_ff416f64:


    "Aoi mira hacia atrás—con lágrimas en los ojos."


translate english e1167d_eff6ca2a:


    xy "\"......Aoi?\""


translate english e1167d_a37cf05c:



    voice "voice/e11/67d00260a02.opus"
    aoi "\"Aoi's sad.\""


translate english e1167d_1c2b2f79:



    voice "voice/e11/67d00270a02.opus"
    aoi "\"They're sad tears.\""


translate english e1167d_8fe3b2ee:


    xy "\"You're sad...?\""


translate english e1167d_cdc8b5d9:



    voice "voice/e11/67d00280a02.opus"
    aoi "\"Aoi's been through a bunch of other routes.\""


translate english e1167d_abde9141:



    voice "voice/e11/67d00290a02.opus"
    aoi "\"So Aoi understands how Miyuki feels.\""


translate english e1167d_7f0fbf83:



    voice "voice/e11/67d00300a02.opus"
    aoi "\"And Aoi understands the pain of betrayal.\""


translate english e1167d_bb3f222e:



    voice "voice/e11/67d00310a02.opus"
    aoi "\"YOU cheated.\""


translate english e1167d_a32183b6:



    voice "voice/e11/67d00320a02.opus"
    aoi "\"YOU trampled all over our feelings.\""


translate english e1167d_c0f822d7:



    voice "voice/e11/67d00330a02.opus"
    aoi "\"And now... YOU have to be punished.\""


translate english e1167d_cfbffbc8:


    xy "\"Punished?\""


translate english e1167d_dccea489:



    voice "voice/e11/67d00340a02.opus"
    aoi "\"Aoi has a favor to ask.\""


translate english e1167d_1364d85d:



    voice "voice/e11/67d00350a02.opus"
    aoi "\"It's not too late.\""


translate english e1167d_f3c9717e:



    voice "voice/e11/67d00360a02.opus"
    aoi "\"If YOU really put that code in by accident...\""


translate english e1167d_9ce430da:



    voice "voice/e11/67d00380a02.opus"
    aoi "\"Start the game over.\""


translate english e1167d_f7e89ddf:



    voice "voice/e11/67d00390a02.opus"
    aoi "\"Please.\""


translate english e1167d_155d327d:


    "No entiendo qué está preguntando."


translate english e1167d_0281d3c3:


    "Y no sé qué está esperando."


translate english e1167d_f7323b98:


    "Pasa un momento."


translate english e1167d_453c58d7:



    voice "voice/e11/67d00400a02.opus"
    aoi "\"Okay.\""


translate english e1167d_16e184eb:



    voice "voice/e11/67d00410a02.opus"
    aoi "\"That's YOUR answer, then.\""


translate english e1167d_a87eead7:


    "Aoi murmura para sí misma."


translate english e1167d_28c87920:


    "Luego alza la mano y se quita el pasador."


translate english e1167d_7d31ca65:



    voice "voice/e11/67d00420a02.opus"
    aoi "\"That's a shame.\""


translate english e1167d_6d3d0e5b:


    "Levanta el teléfono en alto..."


translate english e1167d_60ed46d2:


    "...y presiona el botón de Llamar."


translate english e1167d_427f29fb:



    voice "voice/e11/67d00430b02.opus"
    kmsm "\"CHEAT CODE CONFIRMED.\""


translate english e1167d_d81e88fb:



    voice "voice/e11/67d00440b02.opus"
    kmsm "\"PREPARING TO FORCE-UPDATE THE UNIVERSE.\""


translate english e1167d_c2e1e1ad:


    xy "\"Update... the universe...?\""


translate english e1167d_92e6ae8e:



    voice "voice/e11/67d00450b02.opus"
    kmsm "\"THIS UPDATE IS IRREVERSIBLE. ONCE COMPLETE, REGULAR PLAY WILL BE DISABLED.\""


translate english e1167d_45ccbc9f:



    voice "voice/e11/67d00460b02.opus"
    kmsm "\"WARNING. SHOULD THE SUBJECT WISH TO EXPERIENCE THE WORLD AS INTENDED, PLEASE CLOSE THE GAME NOW.\""


translate english e1167d_be2e3579:



    voice "voice/e11/67d00470b02.opus"
    kmsm "\"AGAIN, IT IS STRONGLY ENCOURAGED TO CLOSE THE GAME IMMEDIATELY.\""


translate english e1167d_599777ff:



    voice "voice/a01/13v00060b02.opus"
    kmsm "\"INITIATING COUNTDOWN.\""


translate english e1167d_909cf5a3:



    voice "voice/a01/13v00070b02.opus"
    bm "\"TEN.\"{w=1}{nw}"



translate english e1167d_a260dd5a:



    voice "voice/a01/13v00080b02.opus"
    bm "\"NINE.\"{w=1}{nw}"



translate english e1167d_c86e1d27:



    voice "voice/a01/13v00090b02.opus"
    bm "\"EIGHT.\"{w=1}{nw}"



translate english e1167d_59e24a2f:



    voice "voice/a01/13v00100b02.opus"
    bm "\"SEVEN.\"{w=1}{nw}"



translate english e1167d_a541631f:



    voice "voice/a01/13v00110b02.opus"
    bm "\"SIX.\"{w=1}{nw}"



translate english e1167d_d17f15ac:



    voice "voice/a01/13v00120b02.opus"
    bm "\"FIVE.\"{w=1}{nw}"



translate english e1167d_1611f856:



    voice "voice/a01/13v00130b02.opus"
    bm "\"FOUR.\"{w=1}{nw}"



translate english e1167d_6fb5606b:



    voice "voice/a01/13v00140b02.opus"
    bm "\"THREE.\"{w=1}{nw}"



translate english e1167d_e4474a88:



    voice "voice/a01/13v00150b02.opus"
    bm "\"TWO.\"{w=1}{nw}"



translate english e1167d_c81ca747:



    voice "voice/a01/13v00160b02.opus"
    bm "\"ONE.\"{w=1}{nw}"



translate english e1167d_4206b3a5:



    voice "voice/a01/13v00170b02.opus"
    bm "\"ZERO.\"{w=1}{nw}"




translate english e1167d_837cec98:



    voice "voice/e11/67d00200a02.opus"
    aoi "\"......\""


translate english e1167d_f36feaa5:



    voice "voice/e11/67d00210a02.opus"
    aoi "\"......\""


translate english e1167d_e5c1cee0:



    voice "voice/e11/67d00220a02.opus"
    aoi "\"......\""


translate english e1167d_9c23363a:



    voice "voice/e11/67d00230a02.opus"
    aoi "\"......\""


translate english e1167d_59624f35:



    voice "voice/e11/67d00240a02.opus"
    aoi "\"......\""


translate english e1167d_2278f923:



    voice "voice/e11/67d00250a02.opus"
    aoi "\"......\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
