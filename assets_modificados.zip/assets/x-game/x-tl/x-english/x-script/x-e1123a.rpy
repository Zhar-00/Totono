

translate english e1123a_9e728835:



    voice "voice/e11/23a00010a01.opus"
    mx "\"...That's funny.\""


translate english e1123a_eaa1bf80:



    voice "voice/e11/23a00020a01.opus"
    mx "\"You said you couldn't earlier.\""


translate english e1123a_95150941:


    xy "\"Hm...?\""


translate english e1123a_1f36a740:


    "Repaso mis recuerdos."


translate english e1123a_c1a3d253:


    "Qué raro... no recuerdo haberle dicho nunca que no..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
