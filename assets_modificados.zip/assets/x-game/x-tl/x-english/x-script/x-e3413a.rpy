

translate english e3413a_dbc0e60e:


    "Ya que estoy despierto, ¡bien podría ir a buscar al gato y tomarle unas fotos para Miyuki!"


translate english e3413a_4db10309:


    "Con su teléfono en mano, decido salir."


translate english e3413a_10f5863d:


    "Paso por el comedor hacia la puerta principal—"


translate english e3413a_8faa8deb:



    voice "voice/e34/13a00010a01.opus"
    mx "\"Hold it!\""


translate english e3413a_34bc9c52:


    "De repente, una voz llama desde el baño."


translate english e3413a_f3b30594:



    voice "voice/e34/13a00020a01.opus"
    mx "\"Shinichi...\""


translate english e3413a_fb2d291d:



    voice "voice/e34/13a00030a01.opus"
    mx "\"Where do you think you're going?\""


translate english strings:


    old "Я никуда не ухожу"
    new "No voy a ninguna parte"


    old "Я иду фотографировать кота"
    new "A tomarle fotos a un gato"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
