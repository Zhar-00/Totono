

translate english a9111_f6f5ff6f:


    "--Así sin más, la última función de Miyuki llegó y se fue."


translate english a9111_444d01b3:



    voice "voice/a91/1100010a01.opus"
    mx "\"¡Buenos días!\""


translate english a9111_db3f6295:


    "En el segundo en que entra al salón de clases, atrae al instante la atención de todos. Igual que siempre."


translate english a9111_330a76a8:


    "Excepto que ya no me habla."


translate english a9111_fa9b8ce1:


    "Y yo tampoco le hablo."


translate english a9111_d2197fe5:


    "Otra mañana más aquí en la escuela."


translate english a9111_9eeefe04:


    "Igual que siempre."


translate english a9111_7cedb681:


    "Al final, nunca fui a ver la obra."


translate english a9111_de9476eb:


    "Me dicen que fue un rotundo éxito."


translate english a9111_90c19e5b:


    "Puedo imaginarme a Miyuki en el escenario, besando al galán romántico..."


translate english a9111_46441c82:


    "Seguro fue un momento hermoso."


translate english a9111_4734b82a:


    "Pero me da igual."


translate english a9111_acb7107a:


    "Miyuki y yo ya no somos amigos."


translate english a9111_1cb7d98d:


    "Hemos vuelto a como éramos antes."


translate english a9111_ae6664e3:


    "Y probablemente sea lo mejor."


translate english a9111_93a1af37:



    voice "voice/a91/1100020b01.opus"
    xtl "\"Hombre, ¡esa estuvo cerca!\""


translate english a9111_959b7909:


    xy "\"¿El qué?\""


translate english a9111_0a197366:



    voice "voice/a91/1100030b01.opus"
    xtl "\"Desde hace un rato apestas a normie...\""


translate english a9111_226333ac:



    voice "voice/a91/1100040b01.opus"
    xtl "\"¡Estuviste así de cerca de morir, amigo!\""


translate english a9111_a3c96c37:


    xy "\"Lo dudo sinceramente.\""


translate english a9111_32695292:



    voice "voice/a91/1100050b01.opus"
    xtl "\"¡Sigan luchando, Chicos BD! ¡Muerte a los normies!\""


translate english a9111_9b551ce4:



    voice "voice/a91/1100060b01.opus"
    xtl "\"Mientras existan normies en este mundo...\""


translate english a9111_e9455196:



    voice "voice/a91/1100070b01.opus"
    xtl "\"¡NUESTRO TRABAJO NUNCA TERMINA!\""


translate english a9111_86151e48:


    xy "\"Consíganse un trabajo nuevo.\""


translate english a9111_8d54e054:


    "I don't know what this \"work\", ¡pero por favor déjame fuera!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
