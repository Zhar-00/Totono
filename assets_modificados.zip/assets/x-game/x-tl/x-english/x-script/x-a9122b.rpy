

translate english a9122b_4b153607:


    xy "\"Justo lo que merezco, ¿no crees?\""


translate english a9122b_3b4e3f65:


    "Murmuro hacia el cielo."


translate english a9122b_f85fdafe:


    "Ni qué decir tiene que nadie me responde."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
