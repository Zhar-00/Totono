

translate english e2237i_bfdd3312:



    voice "voice/e22/37i00010a01.opus"
    mx "\"No te preocupes. ¿Ves?\""


translate english e2237i_030ba22f:


    "Mete la mano en el bolsillo y saca—"


translate english e2237i_e4ddbae0:


    xy "\"¿Ropa interior de repuesto...?\""


translate english e2237i_154cb812:



    voice "voice/e22/37i00020a01.opus"
    mx "\"Lo vi venir de lejos.\""


translate english e2237i_71385574:


    xy "\"¿Oho?\""


translate english e2237i_c15256ae:


    "Sucumbo a las ganas de provocarla."


translate english e2237i_fce3cde2:


    xy "\"¿Este es tu fetiche?\""


translate english e2237i_afc5222b:



    voice "voice/e22/37i00030a01.opus"
    mx "\"Sí, supongo.\""


translate english e2237i_2e70e2f5:


    "En lugar de sonrojarse con timidez como esperaba, responde sin pestañear."


translate english e2237i_c54d6b92:



    voice "voice/e22/37i00040a01.opus"
    mx "\"Después de hacerlo tantas veces, supongo que ahora tengo fetiche por el sexo al aire libre.\""


translate english e2237i_7fe1cf16:


    xy "\"¿Eh...?\""


translate english e2237i_68d2fbd9:


    "Me dio la vuelta por completo—¡y ahora MI corazón late con fuerza!"


translate english e2237i_b3281f5c:



    voice "voice/e22/37i00050a01.opus"
    mx "\"En fin, ¿qué pasó con Akebono-kun?\""


translate english e2237i_3182bfb2:


    xy "\"¡Ay, mierda!\""


translate english e2237i_38835d65:


    "Miro, pero Yuutarou no está por ningún lado."


translate english e2237i_3bf86ff0:


    "Esbozando mentalmente una explicación, saco mi teléfono."


translate english e2237i_4118a894:


    xy "\"Oh, recibí un correo...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
