

translate english e2237i_bfdd3312:



    voice "voice/e22/37i00010a01.opus"
    mx "\"Don't worry. See?\""


translate english e2237i_030ba22f:


    "Mete la mano en el bolsillo y saca—"


translate english e2237i_e4ddbae0:


    xy "\"Spare panties...?\""


translate english e2237i_154cb812:



    voice "voice/e22/37i00020a01.opus"
    mx "\"I saw this coming a mile away.\""


translate english e2237i_71385574:


    xy "\"Oho?\""


translate english e2237i_c15256ae:


    "Sucumbo a las ganas de provocarla."


translate english e2237i_fce3cde2:


    xy "\"Is this your kink?\""


translate english e2237i_afc5222b:



    voice "voice/e22/37i00030a01.opus"
    mx "\"Yeah, I guess.\""


translate english e2237i_2e70e2f5:


    "En lugar de sonrojarse con timidez como esperaba, responde sin pestañear."


translate english e2237i_c54d6b92:



    voice "voice/e22/37i00040a01.opus"
    mx "\"After doing it so many times, I guess I have a fetish for outdoor sex now.\""


translate english e2237i_7fe1cf16:


    xy "\"Huh...?\""


translate english e2237i_68d2fbd9:


    "Me dio la vuelta por completo—¡y ahora MI corazón late con fuerza!"


translate english e2237i_b3281f5c:



    voice "voice/e22/37i00050a01.opus"
    mx "\"Anyway, what happened to Akebono-kun?\""


translate english e2237i_3182bfb2:


    xy "\"Oh, crap!\""


translate english e2237i_38835d65:


    "Miro, pero Yuutarou no está por ningún lado."


translate english e2237i_3bf86ff0:


    "Esbozando mentalmente una explicación, saco mi teléfono."


translate english e2237i_4118a894:


    xy "\"Oh, I got an email...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
