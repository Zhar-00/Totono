

translate english d4202_9f5a5f9f:



    voice "voice/d42/0200010a01.opus"
    mx "\"I'm in love with you.\""


translate english d4202_e3e21669:


    "Su cabello ondea con el viento."


translate english d4202_d4d6fcd3:


    "Por fin, el espacio congelado entre nosotros se derrite y vuelve a la vida."


translate english d4202_ebec4951:


    "Y se lo debemos a Aoi."


translate english d4202_ac9e65aa:


    xy "\"One of your club underlings... Haru-chan, was it?\""


translate english d4202_5969ab82:


    xy "\"She asked me to kiss you.\""


translate english d4202_ba27bb9c:



    voice "voice/d42/0200020a01.opus"
    mx "\"What?! She did?! Wh-What for?!\""


translate english d4202_920df9a1:


    xy "\"Two reasons.\""


translate english d4202_fa6477cf:


    xy "\"One, to help make the play a success...\""


translate english d4202_e2fa2030:


    xy "\"And two, because Aoi asked her to ask me.\""


translate english d4202_f74844e0:



    voice "voice/d42/0200030a01.opus"
    mx "\"Aoi asked her to?\""


translate english d4202_4b2d9e31:


    xy "\"She said she ran into Aoi a few times since her disappearance.\""


translate english d4202_cb73f85e:


    xy "\"And according to her, Aoi said she'd been praying for me and you to finally get together.\""


translate english d4202_d307f4a3:



    voice "voice/d42/0200040a01.opus"
    mx "\"...I see.\""


translate english d4202_a4739d46:


    "Ninguno lo dice, pero ambos lo sabemos."


translate english d4202_61f249c6:


    "Aoi eligió desaparecer para ayudar a que nuestra relación floreciera."


translate english d4202_da117f97:


    "Tenía miedo de interponerse en nuestro romance."


translate english d4202_3d081812:


    xy "\"Miyuki.\""


translate english d4202_fb83518e:



    voice "voice/d42/0200050a01.opus"
    mx "\"Oh...\""



translate english d4202_f66fc02f:


    "Me acerco a ella en silencio."


translate english d4202_f63d35c8:


    "Normalmente emana un aire intimidante, pero físicamente, soy mucho más grande que ella."


translate english d4202_94e02746:


    "Me mira hacia arriba, con los ojos llenos de esperanza y preocupación."


translate english d4202_02f48ea9:


    "Lo que sea que Aoi intentaba concederme al hacerse a un lado..."


translate english d4202_5e823dbc:


    "...por favor, que sea el valor para dar este último paso."


translate english d4202_7b56e203:


    "Déjame tener la fuerza para enfrentar mis sentimientos, aunque signifique que saldré herido."


translate english d4202_702960ed:


    "Es hora de confesar por fin todo lo que he sentido en secreto todo este tiempo."


translate english d4202_cad3998e:


    xy "\"I want to kiss you, Miyuki.\""


translate english d4202_f4011850:


    xy "\"Not for the play.\""


translate english d4202_01732112:


    xy "\"Not because Aoi wants me to.\""


translate english d4202_0ba4d90b:


    xy "\"But because I've always loved you.\""


translate english d4202_5ed8b2ee:


    "Dicen que la vida es una serie de elecciones."


translate english d4202_1a53b3be:


    "Pero eso es una sarta de tonterías."


translate english d4202_f6b4743b:


    "Dios no está allá arriba tirando los dados."


translate english d4202_56c70616:


    "Los 'y si' no existen."



translate english d4202_abb998f0:


    "El ayer lleva al hoy, y el hoy lleva al mañana."


translate english d4202_45837680:


    "¿Qué yace adelante?"


translate english d4202_f2b703e5:


    "Estoy a punto de averiguarlo."


translate english d4202_66481096:



    voice "voice/d42/0200060a01.opus"
    mx "\"Shinichi...\""


translate english d4202_3a6ff1e0:


    "Lentamente, nos acercamos—"


translate english d4202_3ada700d:



    voice "voice/d42/0200070a01.opus"
    mx "\"Will you... be my first?\""


translate english d4202_16707a35:


    "Cierro los ojos lentamente..."


translate english d4202_ebcda36d:


    "Y con esto, nuestros corazones por fin son uno."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
