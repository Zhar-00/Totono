

translate english e2320b_286c8abc:


    "Decido simplemente irme a la cama como un buen chico..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
