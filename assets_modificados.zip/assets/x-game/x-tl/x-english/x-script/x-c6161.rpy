

translate english c6161_8767409c:



    voice "voice/c61/6100010a01.opus"
    mx "\"\"......\"\""


translate english c6161_0accd139:


    xy "\"\"......\"\""


translate english c6161_8588a123:


    "Caminamos en silencio por el camino oscuro."


translate english c6161_235a3b4e:


    "Miyuki abandonó la función solo para arrastrarme hasta aquí."


translate english c6161_d9f50476:


    "Está tan mortalmente seria que ni siquiera me siento bien haciendo un chiste casual."


translate english c6161_fe4b4072:


    "Algo me dice que al final no hay ninguna sorpresa de cumpleaños."


translate english c6161_3d51b384:


    "Volvemos por el camino que tomé para llegar aquí."


translate english c6161_28be4b05:


    "Entonces, finalmente, llegamos—"


translate english c6161_aff22ff2:


    "—a la tienda de la esquina de la familia de Yuutarou."


translate english c6161_6fb06ae5:


    "Quizás Miyuki tiene el mismo malentendido sobre Yuutarou y Aoi."


translate english c6161_6e3e878a:


    "Si es así, probablemente debería pasar y explicarlo todo."


translate english c6161_1a749153:


    xy "\"Escucha, eh... A decir verdad, pasé por aquí de camino a la presentación justo ahora.\""


translate english c6161_f65c4cf6:


    xy "\"Se supone que Aoi estaba en cama con fiebre, pero la vi salir tambaleándose de la casa.\""


translate english c6161_374dcfa5:


    xy "\"Pensé que quizás me estaba engañando.\""


translate english c6161_e98fb9a3:


    xy "\"Pero todo fue solo un malentendido. ¿Conoces a esa chica Haru-chan de tu club? Ella—\""


translate english c6161_ea95673e:



    voice "voice/c61/6100020a01.opus"
    mx "\"Oh, conozco a Haru, claro.\""


translate english c6161_28f19ada:


    xy "\"¿Sí?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
