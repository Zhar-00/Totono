

translate english e2162a_dac3f309:


    xy "\"¿Qué tal este mameluco de gatito?\""


translate english e2162a_17ddac8b:



    voice "voice/e21/62a00010a01.opus"
    mx "\"—!!!\""



translate english e2162a_7fe1cf16:


    xy "\"¿Eh...?\""


translate english e2162a_d88e8a79:


    "Miyuki me lanza una mirada fulminante y me arrebata el enterizo de las manos."


translate english e2162a_54ad9f09:



    voice "voice/e21/62a00020a01.opus"
    mx "\"¿Crees que de verdad podría con algo así?\""


translate english e2162a_ff63d9e4:


    xy "\"Pues, digo...\""


translate english e2162a_fa425096:


    xy "\"...Nunca se sabe, ¿no?\""


translate english e2162a_6e488552:



    voice "voice/e21/62a00030a01.opus"
    mx "\"¡Ja, ni de broma!\""


translate english e2162a_11dfce78:


    "Miyuki devuelve el enterizo a la estantería."


translate english e2162a_51432a20:


    "Cielos... ¿Quién le orinó el cereal?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
