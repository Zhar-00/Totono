

translate english c5201_4326780a:



    voice "voice/c52/0100010a02.opus"
    aoi "\"Mmph... shhllpp... shllppp... mmllpp... shllpp... sslllrrrppp...!\""


translate english c5201_fc8acc6a:


    "...Mmm...?"


translate english c5201_1211f3a4:


    "¿Qué es ese sonido...?"


translate english c5201_60846715:



    voice "voice/c52/0100020a02.opus"
    aoi "\"Slrppp... mmllpp... mmh... mmh... mmph... slrrpp... rrpp... rrppp!!!\""


translate english c5201_a8ca80ac:



    voice "voice/c52/0100030a02.opus"
    aoi "\"Mmllpp... Boop boop?\""


translate english c5201_10995437:



    voice "voice/c52/0100040a02.opus"
    aoi "\"Shinichi? Are you awake?\""


translate english c5201_903c50c0:


    xy "\"What are you doing?\""


translate english c5201_c22e526c:



    voice "voice/c52/0100050a02.opus"
    aoi "\"Licking your cock.\""


translate english c5201_7c664be8:



    voice "voice/c52/0100060a02.opus"
    aoi "\"Mmmph... mmlllppp... sllrrpp... mmh... sllrrpp!\""


translate english c5201_bf84ce66:



    voice "voice/c52/0100070a02.opus"
    aoi "\"Mmllpp... You're so hard...\""


translate english c5201_b4f4cc0c:


    "Recorre mi longitud con la lengua de arriba abajo, deteniéndose de vez en cuando para apretarla con los labios."


translate english c5201_6a0c498b:


    "Mi placer empieza a acumularse rápidamente."


translate english c5201_a6b2ac48:


    "Pero cuanto más me la chupa, más empieza a activarse mi cerebro racional."


translate english c5201_5b1f0bfa:



    voice "voice/c52/0100080a02.opus"
    aoi "\"Mmllpp... mmllpp... sllrrrppp! Mmllpp... sllrrpp... ssllrrpppp!\""


translate english c5201_8096a5c0:



    voice "voice/c52/0100090a02.opus"
    aoi "\"Sllrrpp... sllrrr... slrrp! Mmm... Phaah! It's so yummy!\""


translate english c5201_d2f5ce6f:


    xy "\"Are you recharging again?\""


translate english c5201_0388b94e:



    voice "voice/c52/0100100a02.opus"
    aoi "\"Nope.\""


translate english c5201_4ef2e1b5:



    voice "voice/c52/0100110a02.opus"
    aoi "\"Just feel like doing it... because Aoi loves you.\""


translate english c5201_2387d2d1:


    xy "\"...Sorry.\""


translate english c5201_49ae52ce:


    "La aparto suavemente y me levanto."


translate english c5201_6f76dd12:


    "Aoi pierde el equilibrio y tropieza un poco."


translate english c5201_e700675d:


    xy "\"It's too early for me to get in the mood.\""


translate english c5201_9b23b884:



    voice "voice/c52/0100120a02.opus"
    aoi "\"How come...?\""


translate english c5201_c0a7f6c8:



    voice "voice/c52/0100130a02.opus"
    aoi "\"We haven't had sex at all since the first time.\""


translate english c5201_6ddc8eba:



    voice "voice/c52/0100140a02.opus"
    aoi "\"Do you not like me anymore?\""


translate english c5201_d5f2d7e6:


    xy "\"That's not the issue.\""


translate english c5201_0f558dd2:



    voice "voice/c52/0100150a02.opus"
    aoi "\"Then what is?\""


translate english c5201_b25225b4:


    "No sé."


translate english c5201_842c96e9:


    "Creo que todavía la amo."


translate english c5201_1f53d8f3:


    "Creo que todavía confío en ella."


translate english c5201_cb91ec67:


    "Pero mis sentimientos simplemente no cuadran."


translate english c5201_93f8c2e6:


    xy "\"Let's get ready for school.\""


translate english c5201_f2313347:



    voice "voice/c52/0100160a02.opus"
    aoi "\"Boop boop...\""


translate english c5201_5e46651c:


    "Ignorando a Aoi, salto de la cama y empiezo mi rutina matutina."


translate english c5201_3c1a88e1:


    "Me siento demasiado asqueado—y culpable—para mirarla a los ojos."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
