

translate english a2137_8f347b72:



    voice "voice/a21/3700010a01.opus"
    mx "\"Ten, toma un poco.\""


translate english a2137_ba513558:


    xy "\"¿En serio? ¿Lo dices en serio?\""


translate english a2137_edf258cb:



    voice "voice/a21/3700020a02.opus"
    aoi "\"¿Llegó la Navidad temprano?\""


translate english a2137_25b8e274:



    voice "voice/a21/3700030a01.opus"
    mx "\"No, tonto. Es solo que hoy hice de más.\""


translate english a2137_f1cb25f5:



    voice "voice/a21/3700040a02.opus"
    aoi "\"Una escena clásica de amiga de la infancia.\""


translate english a2137_4e6c6240:



    voice "voice/a21/3700050a01.opus"
    mx "\"Lo hice por mi propia cordura, ¿ok?\""


translate english a2137_c7de505d:



    voice "voice/a21/3700060a01.opus"
    mx "\"Ustedes con su jugo y sus carbohidratos y su pastel... Comer nada más que basura es malo para tu salud mental.\""


translate english a2137_b416ed90:



    voice "voice/a21/3700070a01.opus"
    mx "\"Ustedes dos lo van a comer, ¿verdad?\""


translate english a2137_3340fb88:



    voice "voice/a21/3700080a02.opus"
    aoi "\"¿Eres una tsundere?\""


translate english a2137_6e9b0ec4:



    voice "voice/a21/3700090a01.opus"
    mx "\"¡Entonces parece que no quieres nada!\""


translate english a2137_f0562bb1:



    voice "voice/a21/3700100a02.opus"
    aoi "\"¡No es cierto! ¡Dame!\""


translate english a2137_1c1c5545:


    "Aoi ahora es plenamente consciente de lo buena que es la cocina de Miyuki."


translate english a2137_48a49aa0:


    "En lo personal, lo sé desde hace años. Me ha cocinado un par de veces en el pasado."


translate english a2137_e4470314:



    voice "voice/a21/3700110a02.opus"
    bm "\"¡Vamos a comer!\" \"¡Sí!\""


translate english a2137_3925c4ba:


    "Y así, nuestros palillos empiezan a volar."


translate english a2137_dda95968:


    "¡Aros de calamar! ¡Bistec hamburguesa! ¡Empanadillas shaomai! ¡Ensalada de papa! ¡Hot dogs de pulpo!"


translate english a2137_7ecbe903:


    "¡Espinacas hervidas! ¡Hijiki al vapor! ¡Estofado de res! ¡Tiras de rábano seco! ¡Encurtidos salados!"


translate english a2137_c739a762:


    "La comida sigue llegando y llegando, y toda está deliciosa."


translate english a2137_235f22fc:



    voice "voice/a21/3700120a01.opus"
    mx "\"...¿Cómo está?\""


translate english a2137_48d519a3:


    xy "\"¿¡De alguna forma te volviste AÚN MEJOR cocinando!?\""


translate english a2137_a9808f70:



    voice "voice/a21/3700130a01.opus"
    mx "\"¿P-Puede ser, supongo? Cocino TODOS los días... ¿Y tú, Mukou-san?\""


translate english a2137_d70e5346:



    voice "voice/a21/3700140a02.opus"
    aoi "\"Sabe a tsundere.\""


translate english a2137_d322aee4:



    voice "voice/a21/3700150a01.opus"
    mx "\"Wow, de verdad que no quieres nada.\""


translate english a2137_7200940c:



    voice "voice/a21/3700160a02.opus"
    aoi "\"¡No es cierto! ¡Dame!\""


translate english a2137_e98aff3b:



    voice "voice/a21/3700170a02.opus"
    aoi "\"Your home cooking is godlike, Miyuki... Zappy recharged 100%%...\""


translate english a2137_5fd8facb:



    voice "voice/a21/3700180a01.opus"
    mx "\"Te lo sigo diciendo... Haah... Por el amor de Dios, POR FAVOR deja de llamarme así.\""


translate english a2137_461cf7e3:



    voice "voice/a21/3700190a01.opus"
    mx "\"¿No puedes respetar mis deseos ni UNA VEZ?\""


translate english a2137_f913b677:



    voice "voice/a21/3700200a02.opus"
    aoi "\"Oh... emm... está bien...\""


translate english a2137_9fc568cc:



    voice "voice/a21/3700210a02.opus"
    aoi "\"¿Miyuki-san...?\""


translate english a2137_437246ed:



    voice "voice/a21/3700220a01.opus"
    mx "\"\"\"\"\"......?\"\"?\"\"\""


translate english a2137_0accd139:


    xy "\"\"\"\"\"......?\"\"?\"\"\""


translate english a2137_21628deb:



    voice "voice/a21/3700230a02.opus"
    aoi "\"\"......?\"\""


translate english a2137_468d1bf6:



    voice "voice/a21/3700240a01.opus"
    mx "\"...¡Pffft!\""


translate english a2137_d5cf6ed6:



    voice "voice/a21/3700250a01.opus"
    mx "\"Ok, da igual. Olvídalo.\""


translate english a2137_d46b6dc3:


    xy "\"Miyuki, al parecer.\""


translate english a2137_227c6e0b:



    voice "voice/a21/3700260a02.opus"
    aoi "\"¿Aoi la regó?\""


translate english a2137_8fc2127e:



    voice "voice/a21/3700270a02.opus"
    aoi "\"¿Qué pasa? ¿Estás enojada conmigo?\""


translate english a2137_dc9e20f5:



    voice "voice/a21/3700280a01.opus"
    mx "\"No, no la regaste. Supongo que solo estoy acostumbrada a que me llames Miyuki.\""


translate english a2137_63bdec88:



    voice "voice/a21/3700290a02.opus"
    aoi "\"¿Bip bip...?\""


translate english a2137_9c6bd33a:


    xy "\"Suena a que tienes permiso de seguir llamándola así.\""


translate english a2137_f7f322a1:



    voice "voice/a21/3700300a02.opus"
    aoi "\"¿En serio? ¿Está bien, Miyuki?\""


translate english a2137_08d91d52:



    voice "voice/a21/3700310a01.opus"
    mx "\"Supongo que no tengo opción.\""


translate english a2137_b1b05001:



    voice "voice/a21/3700320a02.opus"
    aoi "\"Emm... En ese caso, Aoi también tiene un favor que pedir.\""


translate english a2137_bf3ddf60:



    voice "voice/a21/3700330a01.opus"
    mx "\"¿Qué es?\""


translate english a2137_967d4a6c:



    voice "voice/a21/3700340a02.opus"
    aoi "\"¿Me llamarás Aoi?\""


translate english a2137_151b2b47:



    voice "voice/a21/3700350a02.opus"
    aoi "\"¿Porfi?\""


translate english a2137_f0783b17:


    xy "\"¡Me parece justo! Si yo tengo que llamarla así, tú también.\""


translate english a2137_e1fe75d8:


    xy "\"Después de todo, todos somos amigos.\""


translate english a2137_2aa584cf:



    voice "voice/a21/3700360a01.opus"
    mx "\"Hrrmm...\""


translate english a2137_04e0de18:


    "Miyuki duda. Quizá no está del todo lista para cerrar la brecha."


translate english a2137_1294ac0e:



    voice "voice/a21/3700370a02.opus"
    aoi "\"¿No quieres...?\""


translate english a2137_9e9530ee:



    voice "voice/a21/3700380a01.opus"
    mx "\"¡E-Está bien! ¡Como sea!\""


translate english a2137_7512c121:



    voice "voice/a21/3700390a01.opus"
    mx "\"Ok... Entonces... Emm...\""


translate english a2137_989dcc62:



    voice "voice/a21/3700400a01.opus"
    mx "\"Lo único que tengo que hacer es... llamarte... ¿Aoi...?\""


translate english a2137_e3b705ab:



    voice "voice/a21/3700410a02.opus"
    aoi "\"\"\"\"\"......?\"\"?\"\"\""


translate english a2137_0accd139_1:


    xy "\"\"\"\"\"......?\"\"?\"\"\""


translate english a2137_02fb525b:



    voice "voice/a21/3700420a01.opus"
    mx "\"\"......?\"\""


translate english a2137_52f28b0d:


    xy "\"...¡Pffft!\""


translate english a2137_29117637:



    voice "voice/a21/3700430a01.opus"
    mx "\"¡Hey! ¿¡Qué es tan gracioso!?\""


translate english a2137_a561a4e5:



    voice "voice/a21/3700440a02.opus"
    aoi "\"Es raro.\""


translate english a2137_ee47272e:



    voice "voice/a21/3700450a01.opus"
    mx "\"¡Con permiso! ¡Estoy dando lo mejor de mí! ¡No seas tan—!\""


translate english a2137_a710fd01:


    xy "\"Tranquila. No hay nada que temer.\""


translate english a2137_e4487b28:



    voice "voice/a21/3700460a01.opus"
    mx "\"¡NO TENGO MIEDO!\""


translate english a2137_a6410597:



    voice "voice/a21/3700470a02.opus"
    aoi "\"Miyuki está tan roja como un tomate.\""


translate english a2137_0a15686d:


    xy "\"¡Jajaja! ¡Totalmente!\""


translate english a2137_30605360:



    voice "voice/a21/3700480a01.opus"
    mx "\"¡Grrrr! ¡Eso es! ¡Ya tuve suficiente! ¡Si solo van a reírse de mí, entonces vuelvo a llamarte Mukou-san y—!\""


translate english a2137_d6f24096:


    xy "\"¡No lo creo, señorita!\""


translate english a2137_dccec454:


    xy "\"¡Sin devoluciones!\""


translate english a2137_8cbb4c53:


    xy "\"¿Verdad, Aoi?\""


translate english a2137_d5d0ddeb:



    voice "voice/a21/3700490a02.opus"
    aoi "\"\"Mukou-san\" apesta. \"Aoi\" es mejor.\""


translate english a2137_f2429842:



    voice "voice/a21/3700500a01.opus"
    mx "\"¡Nnn... nnngghh...!\""


translate english a2137_0d94fd93:


    "Miyuki es tan divertida cuando está nerviosa... Al final, no logro contener la risa por un buen rato."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
