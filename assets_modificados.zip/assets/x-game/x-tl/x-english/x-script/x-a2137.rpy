

translate english a2137_8f347b72:



    voice "voice/a21/3700010a01.opus"
    mx "\"Here, have some.\""


translate english a2137_ba513558:


    xy "\"Really? You mean it?\""


translate english a2137_edf258cb:



    voice "voice/a21/3700020a02.opus"
    aoi "\"Did Christmas come early?\""


translate english a2137_25b8e274:



    voice "voice/a21/3700030a01.opus"
    mx "\"No, you goof. I just made extra today.\""


translate english a2137_f1cb25f5:



    voice "voice/a21/3700040a02.opus"
    aoi "\"A classic childhood friend scene.\""


translate english a2137_4e6c6240:



    voice "voice/a21/3700050a01.opus"
    mx "\"I made it for my own sanity, okay?\""


translate english a2137_c7de505d:



    voice "voice/a21/3700060a01.opus"
    mx "\"You people with your juice and carbs and cake... Eating nothing but garbage is bad for your mental health.\""


translate english a2137_b416ed90:



    voice "voice/a21/3700070a01.opus"
    mx "\"You'll both eat it, won't you?\""


translate english a2137_3340fb88:



    voice "voice/a21/3700080a02.opus"
    aoi "\"Are you a tsundere?\""


translate english a2137_6e9b0ec4:



    voice "voice/a21/3700090a01.opus"
    mx "\"Sounds like you don't want any, then!\""


translate english a2137_f0562bb1:



    voice "voice/a21/3700100a02.opus"
    aoi "\"Not true! Gimme!\""


translate english a2137_1c1c5545:


    "Aoi ahora es plenamente consciente de lo buena que es la cocina de Miyuki."


translate english a2137_48a49aa0:


    "En lo personal, lo sé desde hace años. Me ha cocinado un par de veces en el pasado."


translate english a2137_e4470314:



    voice "voice/a21/3700110a02.opus"
    bm "\"Let's dig in!\" \"Yay!\""


translate english a2137_3925c4ba:


    "Y así, nuestros palillos empiezan a volar."


translate english a2137_dda95968:


    "¡Aros de calamar! ¡Bistec hamburguesa! ¡Empanadillas shaomai! ¡Ensalada de papa! ¡Hot dogs de pulpo!"


translate english a2137_7ecbe903:


    "¡Espinacas hervidas! ¡Hijiki al vapor! ¡Estofado de res! ¡Tiras de rábano seco! ¡Encurtidos salados!"


translate english a2137_c739a762:


    "La comida sigue llegando y llegando, y toda está deliciosa."


translate english a2137_235f22fc:



    voice "voice/a21/3700120a01.opus"
    mx "\"...How is it?\""


translate english a2137_48d519a3:


    xy "\"Did you somehow get EVEN BETTER at cooking?!\""


translate english a2137_a9808f70:



    voice "voice/a21/3700130a01.opus"
    mx "\"M-Maybe, I guess? I DO cook every day... What about you, Mukou-san?\""


translate english a2137_d70e5346:



    voice "voice/a21/3700140a02.opus"
    aoi "\"Tastes like tsundere.\""


translate english a2137_d322aee4:



    voice "voice/a21/3700150a01.opus"
    mx "\"Wow, you must REALLY not want any.\""


translate english a2137_7200940c:



    voice "voice/a21/3700160a02.opus"
    aoi "\"Not true! Gimme!\""


translate english a2137_e98aff3b:



    voice "voice/a21/3700170a02.opus"
    aoi "\"Your home cooking is godlike, Miyuki... Zappy recharged 100%%...\""


translate english a2137_5fd8facb:



    voice "voice/a21/3700180a01.opus"
    mx "\"I keep telling you... Haah... For the love of god, PLEASE stop calling me that.\""


translate english a2137_461cf7e3:



    voice "voice/a21/3700190a01.opus"
    mx "\"Can't you respect my wishes, just ONCE?\""


translate english a2137_f913b677:



    voice "voice/a21/3700200a02.opus"
    aoi "\"Oh... umm... okay...\""


translate english a2137_9fc568cc:



    voice "voice/a21/3700210a02.opus"
    aoi "\"Miyuki-san...?\""


translate english a2137_437246ed:



    voice "voice/a21/3700220a01.opus"
    mx "\"\"\"\"\"......?\"\"?\"\"\""


translate english a2137_0accd139:


    xy "\"\"\"\"\"......?\"\"?\"\"\""


translate english a2137_21628deb:



    voice "voice/a21/3700230a02.opus"
    aoi "\"\"......?\"\""


translate english a2137_468d1bf6:



    voice "voice/a21/3700240a01.opus"
    mx "\"...Pffft!\""


translate english a2137_d5cf6ed6:



    voice "voice/a21/3700250a01.opus"
    mx "\"Okay, never mind. Forget it.\""


translate english a2137_d46b6dc3:


    xy "\"Miyuki it is, apparently.\""


translate english a2137_227c6e0b:



    voice "voice/a21/3700260a02.opus"
    aoi "\"Did Aoi mess up?\""


translate english a2137_8fc2127e:



    voice "voice/a21/3700270a02.opus"
    aoi "\"What's wrong? Are you mad at me?\""


translate english a2137_dc9e20f5:



    voice "voice/a21/3700280a01.opus"
    mx "\"No, you didn't mess up. I guess I'm just used to you calling me Miyuki.\""


translate english a2137_63bdec88:



    voice "voice/a21/3700290a02.opus"
    aoi "\"Boop boop...?\""


translate english a2137_9c6bd33a:


    xy "\"Sounds like you're allowed to keep calling her that.\""


translate english a2137_f7f322a1:



    voice "voice/a21/3700300a02.opus"
    aoi "\"Really? Is that okay, Miyuki?\""


translate english a2137_08d91d52:



    voice "voice/a21/3700310a01.opus"
    mx "\"I suppose I have no choice.\""


translate english a2137_b1b05001:



    voice "voice/a21/3700320a02.opus"
    aoi "\"Umm... In that case, Aoi has a favor to ask, too.\""


translate english a2137_bf3ddf60:



    voice "voice/a21/3700330a01.opus"
    mx "\"What is it?\""


translate english a2137_967d4a6c:



    voice "voice/a21/3700340a02.opus"
    aoi "\"Will you call me Aoi?\""


translate english a2137_151b2b47:



    voice "voice/a21/3700350a02.opus"
    aoi "\"Pretty please?\""


translate english a2137_f0783b17:


    xy "\"Seems fair to me! If I have to call her that, so do you.\""


translate english a2137_e1fe75d8:


    xy "\"We're all friends, after all.\""


translate english a2137_2aa584cf:



    voice "voice/a21/3700360a01.opus"
    mx "\"Hrrmm...\""


translate english a2137_04e0de18:


    "Miyuki duda. Quizá no está del todo lista para cerrar la brecha."


translate english a2137_1294ac0e:



    voice "voice/a21/3700370a02.opus"
    aoi "\"You don't want to...?\""


translate english a2137_9e9530ee:



    voice "voice/a21/3700380a01.opus"
    mx "\"F-Fine! Whatever!\""


translate english a2137_7512c121:



    voice "voice/a21/3700390a01.opus"
    mx "\"Okay... So... Umm...\""


translate english a2137_989dcc62:



    voice "voice/a21/3700400a01.opus"
    mx "\"All I have to do is... call you... Aoi...?\""


translate english a2137_e3b705ab:



    voice "voice/a21/3700410a02.opus"
    aoi "\"\"\"\"\"......?\"\"?\"\"\""


translate english a2137_0accd139_1:


    xy "\"\"\"\"\"......?\"\"?\"\"\""


translate english a2137_02fb525b:



    voice "voice/a21/3700420a01.opus"
    mx "\"\"......?\"\""


translate english a2137_52f28b0d:


    xy "\"...Pffft!\""


translate english a2137_29117637:



    voice "voice/a21/3700430a01.opus"
    mx "\"Hey! What's so funny?!\""


translate english a2137_a561a4e5:



    voice "voice/a21/3700440a02.opus"
    aoi "\"It's weird.\""


translate english a2137_ee47272e:



    voice "voice/a21/3700450a01.opus"
    mx "\"Excuse you! I'm doing my best! Don't be so—!\""


translate english a2137_a710fd01:


    xy "\"Relax. There's nothing to be afraid of.\""


translate english a2137_e4487b28:



    voice "voice/a21/3700460a01.opus"
    mx "\"I'M NOT AFRAID!\""


translate english a2137_a6410597:



    voice "voice/a21/3700470a02.opus"
    aoi "\"Miyuki's as red as a tomato.\""


translate english a2137_0a15686d:


    xy "\"Hahaha! She totally is!\""


translate english a2137_30605360:



    voice "voice/a21/3700480a01.opus"
    mx "\"Grrrr! That's it! I've had enough! If you're just going to laugh at me, then I'm going back to calling you Mukou-san, and—!\""


translate english a2137_d6f24096:


    xy "\"I don't think so, missy!\""


translate english a2137_dccec454:


    xy "\"No take-backsies!\""


translate english a2137_8cbb4c53:


    xy "\"Right, Aoi?\""


translate english a2137_d5d0ddeb:



    voice "voice/a21/3700490a02.opus"
    aoi "\" 'Mukou-san' sucks. 'Aoi' is better.\""


translate english a2137_f2429842:



    voice "voice/a21/3700500a01.opus"
    mx "\"Nnn... nnngghh...!\""


translate english a2137_0d94fd93:


    "Miyuki es tan divertida cuando está nerviosa... Al final, no logro contener la risa por un buen rato."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
