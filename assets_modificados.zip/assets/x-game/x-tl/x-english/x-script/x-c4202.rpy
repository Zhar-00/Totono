

translate english c4202_c84516da:


    xy "\"—¿Eh?\""


translate english c4202_a06c09b9:



    voice "voice/c42/0200020a01.opus"
    mx "\"...¿Qué pasa?\""


translate english c4202_9313a985:


    xy "\"Acabo de oír algo...\""


translate english c4202_ce7dd48d:


    "Un miau muy familiar."


translate english c4202_9baf9f69:


    "Apresuradamente, miro en dirección al sonido."


translate english c4202_7859b861:


    xy "\"¡Eru!\""


translate english c4202_cb19eabc:


    "Y, en efecto, es el gatito de Aoi, maullando desde debajo de la banca."


translate english c4202_70e424eb:


    "¿Cómo llegaste aquí desde mi casa, bolita de pelo?"


translate english c4202_dd6fa382:


    xy "\"¿Quieres que te siga o algo?\""


translate english c4202_bd8c1bd8:


    "Aoi había llamado a Eru \"transceiver cat.\""


translate english c4202_f25909f2:


    "Seguro, quizá era solo una de sus ilusiones."


translate english c4202_ecf0aced:


    "Pero ese mismo gatito de algún modo escapó de los confines de mi casa y viajó todo este camino solo para encontrarme."


translate english c4202_fd1ef7c8:


    xy "\"Eru...\""


translate english c4202_5545b9fe:



    voice "voice/c42/0200060a01.opus"
    mx "\"¡Shinichi!\""


translate english c4202_1cc0cf55:


    "Antes de que pueda dar un solo paso, Miyuki me llama."


translate english c4202_bfcfbbaa:


    "Su voz tiembla, con las manos apretadas en puños."


translate english c4202_b4e2cb05:



    voice "voice/c42/0200070a01.opus"
    mx "\"...¿Te vas?\""


translate english c4202_48c57920:



    voice "voice/c42/0200080a01.opus"
    mx "\"¿Justo en medio de nuestra... conversación?\""


translate english strings:


    old "Остаться с Миюки"
    new "Quedarme con Miyuki"


    old "Идти за Иру"
    new "Correr tras Eru"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
