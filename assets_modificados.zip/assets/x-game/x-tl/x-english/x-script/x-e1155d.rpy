

translate english e1155d_7c3722e9:



    voice "voice/e11/55d00010a01.opus"
    mx "\"Vamos, no seas así...\""


translate english e1155d_ee66b5c6:



    voice "voice/e11/55d00020a01.opus"
    mx "Solo... ¡BÉSAME...!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
