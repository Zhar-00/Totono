

translate english a3221_4153424d:


    xy "\"¿Qué opinas?\""


translate english a3221_d3a97d71:



    voice "voice/a32/2100010a01.opus"
    mx "\"Perfecto, gracias.\""


translate english a3221_83e3259a:


    "Miyuki revisa las fotos del gatito y luego guarda su teléfono."


translate english a3221_f80e80cc:


    xy "\"¿Siempre fuiste tan fanática de los gatos?\""


translate english a3221_39186a46:



    voice "voice/a32/2100020a01.opus"
    mx "\"Digamos que quiero lo que no puedo tener.\""


translate english a3221_3709a805:


    xy "\"Vaya, deberías verte la cara que pones cuando te vuelves loca por los gatos. Pareces un cruce entre un...\""


translate english a3221_a889c5a3:



    voice "voice/a32/2100030a01.opus"
    mx "\"¡Borra eso de tu cerebro, ahora!\""


translate english a3221_ff322aba:


    xy "\"Bien, bien...\""


translate english a3221_570402c6:


    "Lo siento, pero no hay forma de que pueda olvidar esa monstruosidad."


translate english a3221_16f62e87:



    voice "voice/a32/2100040a01.opus"
    mx "\"Míralos, dormidos allí... Casi como si de verdad fueran mamá y bebé...\""


translate english a3221_69c7f2bb:


    "Siguiendo su ejemplo, me asomo a la sala desde más allá de la puerta de vidrio."


translate english a3221_70a9a40a:


    "Aoi está acurrucada en el sofá con su mameluco de gatito, sosteniendo a Eru en brazos, roncando."


translate english a3221_63acdd9d:



    voice "voice/a32/2100050a01.opus"
    mx "\"......\""


translate english a3221_ae186e6b:



    voice "voice/a32/2100060a01.opus"
    mx "\"...Quizá me equivoqué.\""


translate english a3221_b79192f3:


    xy "\"Sí, quizá.\""


translate english a3221_b9245fda:


    "Ninguna cantidad de lógica o razón podría compararse con esa pequeña sonrisa satisfecha."


translate english a3221_909601ae:



    voice "voice/a32/2100070a01.opus"
    mx "\"Es raro, ¿sabes?\""


translate english a3221_78a2e5d9:



    voice "voice/a32/2100080a01.opus"
    mx "\"Siempre me molestaba su forma de actuar... Me juré que la corregiría...\""


translate english a3221_abb1584c:



    voice "voice/a32/2100090a01.opus"
    mx "\"Pero esa pequeña creída me volteó la tortilla por completo.\""


translate english a3221_edb2293d:



    voice "voice/a32/2100100a01.opus"
    mx "\"¿Y lo gracioso? Es como un soplo de aire fresco.\""


translate english a3221_9a3aaac1:



    voice "voice/a32/2100110a01.opus"
    mx "\"Simplemente... me siento tan libre.\""


translate english a3221_43e004af:


    "Tiene toda la razón."


translate english a3221_3c7d0df4:


    "Cuidar de un gatito no será fácil, pero sé que de lo contrario nos habríamos arrepentido."


translate english a3221_b2f86f3b:


    "Al final, a veces es importante ser fiel a tus propios deseos."


translate english a3221_4b65e799:


    xy "\"Bien, supongo que deberíamos terminar aquí y...\""


translate english a3221_fb486a43:



    voice "voice/a32/2100120a01.opus"
    mx "\"¡Espera!\""


translate english a3221_6169d484:


    xy "\"¿Qué, quieres que tome más fotos?\""


translate english a3221_72573f8d:



    voice "voice/a32/2100130a01.opus"
    mx "\"No, no es eso.\""


translate english a3221_7582c3a8:


    xy "\"¿Quieres quedarte a dormir aquí? Aunque no creo que sea buena idea.\""


translate english a3221_e0355b08:



    voice "voice/a32/2100140a01.opus"
    mx "\"No.\""


translate english a3221_d0fc2a07:



    voice "voice/a32/2100150a01.opus"
    mx "\"Hay algo que quiero decirte.\""


translate english a3221_d98a31a1:


    xy "\"¿Qué es... aaah?\""


translate english a3221_aa1aed7a:


    xy "\"¿Mi...yuki...?\""


translate english a3221_41b19c4f:



    voice "voice/a32/2100160a01.opus"
    mx "\"Ya dejé de aferrarme al pasado.\""


translate english a3221_3de0b7e8:


    "Miyuki me atrae hacia sí hasta que ninguno de los dos puede ver a Aoi."


translate english a3221_a210f343:


    "Su cuerpo está girado hacia mí... y sin embargo su rostro está vuelto hacia otro lado."


translate english a3221_6373ee18:


    "Estamos demasiado cerca. Demasiado cerca."


translate english a3221_ecf1eb8d:


    "El tiempo se ralentiza hasta casi detenerse."


translate english a3221_cbcab83a:



    voice "voice/a32/2100170a01.opus"
    mx "\"...Bésame.\""


translate english a3221_f860263f:


    "Beso... Beso... Beso..."


translate english a3221_feb08074:


    "Desde que Miyuki me contó sobre el clímax de la obra..."


translate english a3221_7e622c51:


    "La he besado innumerables veces en mis sueños."


translate english a3221_f603f2fb:


    "¿Es esto también un sueño?"


translate english a3221_55bca99a:


    "Si es así, necesito despertar, rápido—"


translate english a3221_2d172042:


    xy "\"Guau, eso fue... de la nada...\""


translate english a3221_1a949085:



    voice "voice/a32/2100180a01.opus"
    mx "\"No. De hecho, no es de la nada.\""


translate english a3221_4a5349a9:


    "Sus labios se mueven con su susurro."


translate english a3221_2b9d2a03:


    "No puedo permitirme enamorarme de ella."


translate english a3221_045ec9e0:


    "Y si nos besamos, definitivamente lo haré."


translate english a3221_af3b2212:


    "Lo que significa... que sé lo que tengo que hacer."


translate english a3221_ff5b3279:


    "Sé que necesito salir de aquí."


translate english a3221_1cdba030:


    "Pero mi corazón no me deja."


translate english a3221_0e055b64:


    "Puedo sentirlo latir en mi pecho. Mi corazón quiere que este beso suceda."


translate english a3221_5147d10d:



    voice "voice/a32/2100190a01.opus"
    mx "\"Tengo miedo... No quiero que mi primer beso sea en el escenario...\""


translate english a3221_4673fc58:



    voice "voice/a32/2100200a01.opus"
    mx "\"Así que... ¡quiero practicar un poco primero!\""


translate english a3221_9df0f4f2:


    xy "\"¿Practicar?\""


translate english a3221_30d8c8eb:



    voice "voice/a32/2100210a01.opus"
    mx "\"Sí, o sea, quiero agarrarle la mano, ¿sabes...?\""


translate english a3221_079d6737:



    voice "voice/a32/2100220a01.opus"
    mx "\"¿Te... parece bien?\""


translate english a3221_a7d8432f:


    xy "\"Para nada.\""


translate english a3221_46c1ab34:



    voice "voice/a32/2100230a01.opus"
    mx "\"¿Qué?\""


translate english a3221_35f35acb:


    xy "\"Ve a practicar con tu compañero de actuación. Este no es mi problema.\""


translate english a3221_6f05c2ad:



    voice "voice/a32/2100240a01.opus"
    mx "\"¿Perdón?\""


translate english a3221_61af0e70:


    xy "\"¿Qué? No lo es.\""


translate english a3221_642b7b3c:



    voice "voice/a32/2100250a01.opus"
    mx "\"Pero... ¡dijiste que me ayudarías a resolver esto!\""


translate english a3221_070289b0:



    voice "voice/a32/2100260a01.opus"
    mx "\"Así que junté todo mi valor para pedírtelo...\""


translate english a3221_ec1546a0:


    xy "\"—¿...Para ser tu compañero de práctica?\""


translate english a3221_241cf6c5:



    voice "voice/a32/2100270a01.opus"
    mx "\"Oh... E-Está bien, mira, sé lo que dije, pero...\""


translate english a3221_6f1d1410:


    xy "\"¿Qué soy, tu conejillo de indias?\""


translate english a3221_4be192f0:



    voice "voice/a32/2100280a01.opus"
    mx "\"¡N-No! Te equivocas...\""


translate english a3221_b9ecbd5a:


    xy "\"¡¿Entonces por qué carajos me dices eso?!\""


translate english a3221_071b2cdd:


    xy "\"¿¡Tienes idea de cómo me siento, pasando todo este tiempo contigo!?\""


translate english a3221_ddc5b81a:



    voice "voice/a32/2100290a02.opus"
    aoi "\"¡BAAASTA!\""


translate english a3221_90a6f7ad:


    "La puerta de vidrio se desliza y Aoi salta entre nosotros."


translate english a3221_5d046fd6:



    voice "voice/a32/2100300a02.opus"
    aoi "\"¡No se permite pelear, ustedes dos!\""


translate english a3221_1afa3ec1:



    voice "voice/a32/2100310a01.opus"
    mx "\"¿¡Aoi!?\""


translate english a3221_341cadc9:



    voice "voice/a32/2100320a02.opus"
    aoi "\"Justo cuando por fin nos llevamos bien...\""


translate english a3221_d32e87f4:



    voice "voice/a32/2100330a02.opus"
    aoi "\"No se... permite... pe...\""


translate english a3221_155c2691:



    voice "voice/a32/2100340a02.opus"
    aoi "\"Boop...\""


translate english a3221_83931868:


    xy "\"¿Qué demonios...? ¡¿Aoi!?\""


translate english a3221_582d2915:


    "El cuerpo de Aoi cae de lado, y la atrapo rápidamente en mis brazos."


translate english a3221_5003dc32:


    "Sus ojos vagan, desenfocados."


translate english a3221_6b1f99b6:


    xy "\"¿Qué pasa? ¿Te sientes mal?\""


translate english a3221_46942270:



    voice "voice/a32/2100350a02.opus"
    aoi "\"Boop boop...\""


translate english a3221_7cb6237f:



    voice "voice/a32/2100360a02.opus"
    aoi "\"La batería de Aoi se está muriendo.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
