

translate english a3221_4153424d:


    xy "\"What do you think?\""


translate english a3221_d3a97d71:



    voice "voice/a32/2100010a01.opus"
    mx "\"Perfect, thank you.\""


translate english a3221_83e3259a:


    "Miyuki revisa las fotos del gatito y luego guarda su teléfono."


translate english a3221_f80e80cc:


    xy "\"Were you always this much of a cat fanatic?\""


translate english a3221_39186a46:



    voice "voice/a32/2100020a01.opus"
    mx "\"I guess you could say I want what I can't have.\""


translate english a3221_3709a805:


    xy "\"Man, you should see the faces you make whenever you go all cat-crazy. You look like a cross between a—\""


translate english a3221_a889c5a3:



    voice "voice/a32/2100030a01.opus"
    mx "\"Delete that from your brain, now!\""


translate english a3221_ff322aba:


    xy "\"Fine, fine...\""


translate english a3221_570402c6:


    "Lo siento, pero no hay forma de que pueda olvidar esa monstruosidad."


translate english a3221_16f62e87:



    voice "voice/a32/2100040a01.opus"
    mx "\"Look at them, fast asleep in there... Almost like they really are mommy and baby...\""


translate english a3221_69c7f2bb:


    "Siguiendo su ejemplo, me asomo a la sala desde más allá de la puerta de vidrio."


translate english a3221_70a9a40a:


    "Aoi está acurrucada en el sofá con su mameluco de gatito, sosteniendo a Eru en brazos, roncando."


translate english a3221_63acdd9d:



    voice "voice/a32/2100050a01.opus"
    mx "\"......\""


translate english a3221_ae186e6b:



    voice "voice/a32/2100060a01.opus"
    mx "\"...Maybe I was wrong.\""


translate english a3221_b79192f3:


    xy "\"Yeah, maybe.\""


translate english a3221_b9245fda:


    "Ninguna cantidad de lógica o razón podría compararse con esa pequeña sonrisa satisfecha."


translate english a3221_909601ae:



    voice "voice/a32/2100070a01.opus"
    mx "\"It's weird, you know?\""


translate english a3221_78a2e5d9:



    voice "voice/a32/2100080a01.opus"
    mx "\"I always took issue with the way she would act... I swore to myself I'd set her straight...\""


translate english a3221_abb1584c:



    voice "voice/a32/2100090a01.opus"
    mx "\"But that little punk totally turned the tables on me.\""


translate english a3221_edb2293d:



    voice "voice/a32/2100100a01.opus"
    mx "\"And the funny thing is? It's like a breath of fresh air.\""


translate english a3221_9a3aaac1:



    voice "voice/a32/2100110a01.opus"
    mx "\"I just... feel so free.\""


translate english a3221_43e004af:


    "Tiene toda la razón."


translate english a3221_3c7d0df4:


    "Cuidar de un gatito no será fácil, pero sé que de lo contrario nos habríamos arrepentido."


translate english a3221_b2f86f3b:


    "Al final, a veces es importante ser fiel a tus propios deseos."


translate english a3221_4b65e799:


    xy "\"Alright, I guess we should call it a night here and—\""


translate english a3221_fb486a43:



    voice "voice/a32/2100120a01.opus"
    mx "\"Wait!\""


translate english a3221_6169d484:


    xy "\"What, you want me to take some more pictures?\""


translate english a3221_72573f8d:



    voice "voice/a32/2100130a01.opus"
    mx "\"No, that's not it.\""


translate english a3221_7582c3a8:


    xy "\"You wanna crash here for the night? I don't think it's a good idea, though.\""


translate english a3221_e0355b08:



    voice "voice/a32/2100140a01.opus"
    mx "\"No.\""


translate english a3221_d0fc2a07:



    voice "voice/a32/2100150a01.opus"
    mx "\"There's something I want to tell you.\""


translate english a3221_d98a31a1:


    xy "\"What's tha—aaah?!\""


translate english a3221_aa1aed7a:


    xy "\"Mi...yuki...?\""


translate english a3221_41b19c4f:



    voice "voice/a32/2100160a01.opus"
    mx "\"I'm done clinging to the past.\""


translate english a3221_3de0b7e8:


    "Miyuki me atrae hacia sí hasta que ninguno de los dos puede ver a Aoi."


translate english a3221_a210f343:


    "Su cuerpo está girado hacia mí... y sin embargo su rostro está vuelto hacia otro lado."


translate english a3221_6373ee18:


    "Estamos demasiado cerca. Demasiado cerca."


translate english a3221_ecf1eb8d:


    "El tiempo se ralentiza hasta casi detenerse."


translate english a3221_cbcab83a:



    voice "voice/a32/2100170a01.opus"
    mx "\"...Kiss me.\""


translate english a3221_f860263f:


    "Beso... Beso... Beso..."


translate english a3221_feb08074:


    "Desde que Miyuki me contó sobre el clímax de la obra..."


translate english a3221_7e622c51:


    "La he besado innumerables veces en mis sueños."


translate english a3221_f603f2fb:


    "¿Es esto también un sueño?"


translate english a3221_55bca99a:


    "Si es así, necesito despertar, rápido—"


translate english a3221_2d172042:


    xy "\"Wow, that was... random...\""


translate english a3221_1a949085:



    voice "voice/a32/2100180a01.opus"
    mx "\"No. It's not random, actually.\""


translate english a3221_4a5349a9:


    "Sus labios se mueven con su susurro."


translate english a3221_2b9d2a03:


    "No puedo permitirme enamorarme de ella."


translate english a3221_045ec9e0:


    "Y si nos besamos, definitivamente lo haré."


translate english a3221_af3b2212:


    "Lo que significa... que sé lo que tengo que hacer."


translate english a3221_ff5b3279:


    "Sé que necesito salir de aquí."


translate english a3221_1cdba030:


    "Pero mi corazón no me deja."


translate english a3221_0e055b64:


    "Puedo sentirlo latir en mi pecho. Mi corazón quiere que este beso suceda."


translate english a3221_5147d10d:



    voice "voice/a32/2100190a01.opus"
    mx "\"I'm scared... I don't want my first kiss to be onstage...\""


translate english a3221_4673fc58:



    voice "voice/a32/2100200a01.opus"
    mx "\"So... I want to get some practice in first!\""


translate english a3221_9df0f4f2:


    xy "\"Practice?\""


translate english a3221_30d8c8eb:



    voice "voice/a32/2100210a01.opus"
    mx "\"Yeah, like, I wanna get the hang of it, you know...\""


translate english a3221_079d6737:



    voice "voice/a32/2100220a01.opus"
    mx "\"Is that... cool with you?\""


translate english a3221_a7d8432f:


    xy "\"Hell no.\""


translate english a3221_46c1ab34:



    voice "voice/a32/2100230a01.opus"
    mx "\"What?\""


translate english a3221_35f35acb:


    xy "\"Go practice with your acting partner. This isn't my problem.\""


translate english a3221_6f05c2ad:



    voice "voice/a32/2100240a01.opus"
    mx "\"Excuse me?\""


translate english a3221_61af0e70:


    xy "\"What? It's not.\""


translate english a3221_642b7b3c:



    voice "voice/a32/2100250a01.opus"
    mx "\"But... you said you'd help me figure this out!\""


translate english a3221_070289b0:



    voice "voice/a32/2100260a01.opus"
    mx "\"So I worked up all my courage to ask you—\""


translate english a3221_ec1546a0:


    xy "\"—To be your practice partner?\""


translate english a3221_241cf6c5:



    voice "voice/a32/2100270a01.opus"
    mx "\"Oh... O-Okay, look, I know what I said, but—\""


translate english a3221_6f1d1410:


    xy "\"What am I, your guinea pig?\""


translate english a3221_4be192f0:



    voice "voice/a32/2100280a01.opus"
    mx "\"N-No! You've got it all wrong—\""


translate english a3221_b9ecbd5a:


    xy "\"Then why the fuck would you say that to me?!\""


translate english a3221_071b2cdd:


    xy "\"Do you have any idea how I feel, spending all this time with you?!\""


translate english a3221_ddc5b81a:



    voice "voice/a32/2100290a02.opus"
    aoi "\"STOOOP!\""


translate english a3221_90a6f7ad:


    "La puerta de vidrio se desliza y Aoi salta entre nosotros."


translate english a3221_5d046fd6:



    voice "voice/a32/2100300a02.opus"
    aoi "\"No fighting allowed, you two!\""


translate english a3221_1afa3ec1:



    voice "voice/a32/2100310a01.opus"
    mx "\"Aoi?!\""


translate english a3221_341cadc9:



    voice "voice/a32/2100320a02.opus"
    aoi "\"Just when we're finally getting along...\""


translate english a3221_d32e87f4:



    voice "voice/a32/2100330a02.opus"
    aoi "\"You're not... allowed... to... fi...\""


translate english a3221_155c2691:



    voice "voice/a32/2100340a02.opus"
    aoi "\"Boop...\""


translate english a3221_83931868:


    xy "\"What the—Aoi?!\""


translate english a3221_582d2915:


    "El cuerpo de Aoi cae de lado, y la atrapo rápidamente en mis brazos."


translate english a3221_5003dc32:


    "Sus ojos vagan, desenfocados."


translate english a3221_6b1f99b6:


    xy "\"What's wrong? You feeling sick?\""


translate english a3221_46942270:



    voice "voice/a32/2100350a02.opus"
    aoi "\"Boop boop...\""


translate english a3221_7cb6237f:



    voice "voice/a32/2100360a02.opus"
    aoi "\"Aoi's battery is dying.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
