

translate english e3242b_40802e7f:



    voice "voice/e32/42b00010a01.opus"
    mx "Haah... eres tan terco..."


translate english e3242b_6fa80e82:



    voice "voice/e32/42b00020a01.opus"
    mx "Está bien, pero solo tengo una cosa que decir."


translate english e3242b_f80ab82b:



    voice "voice/e32/42b00030a01.opus"
    mx "Aunque la Aoi que te mostré en el juego no sea más que ficción..."


translate english e3242b_a888137d:



    voice "voice/e32/42b00040a01.opus"
    mx "...La verdad es que la Aoi que conociste en el otro mundo era exactamente así."


translate english e3242b_416c5207:



    voice "voice/e32/42b00050a01.opus"
    mx "Abría las piernas para cualquier tipo que siquiera la mirara. Ella misma te lo dijo, ¿no?"



translate english e3242b_27f77f13:



    voice "voice/e32/42b00060a01.opus"
    mx "¿Quién podría amar a una zorra como ella?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
