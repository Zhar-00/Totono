

translate english c3201_c8a2dc6b:


    xy "\"¿Hmm? ¿Qué pasa, bola de pelo?\""



translate english c3201_655cf70d:



    voice "voice/c32/0100020a02.opus"
    aoi "\"¿Tienes hambre?\""


translate english c3201_5c2d4fee:


    xy "\"Después de todo, SIGUE siendo un gatito... ¿Deberíamos conseguirle leche?\""


translate english c3201_e4070512:


    xy "\"Pero probablemente todas las tiendas estén cerradas ya...\""


translate english c3201_b697305c:



    voice "voice/c32/0100040a02.opus"
    aoi "\"¿Quizá la tienda de la esquina?\""


translate english c3201_e55c792a:


    xy "\"Espera... ¿Los gatitos siquiera pueden tomar la misma leche que los humanos?\""


translate english c3201_122f1c48:



    voice "voice/c32/0100050a02.opus"
    aoi "\"Bip bip... No estoy seguro.\""


translate english c3201_2ee4ed69:


    "En cualquier caso, la cosita va a necesitar algo de comida tarde o temprano."


translate english c3201_21bf439d:


    xy "\"Hmm... Entonces a la tienda de la esquina.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
