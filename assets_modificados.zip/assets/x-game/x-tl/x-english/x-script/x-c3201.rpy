

translate english c3201_c8a2dc6b:


    xy "\"Hmm? What's up, furball?\""



translate english c3201_655cf70d:



    voice "voice/c32/0100020a02.opus"
    aoi "\"You hungry?\""


translate english c3201_5c2d4fee:


    xy "\"It IS still a kitten, after all... Should we get it some milk?\""


translate english c3201_e4070512:


    xy "\"But all the stores are probably closed by now...\""


translate english c3201_b697305c:



    voice "voice/c32/0100040a02.opus"
    aoi "\"Maybe the corner store?\""


translate english c3201_e55c792a:


    xy "\"Wait... Are kittens even allowed to drink the same milk as humans?\""


translate english c3201_122f1c48:



    voice "voice/c32/0100050a02.opus"
    aoi "\"Boop boop... Not sure.\""


translate english c3201_2ee4ed69:


    "En cualquier caso, la cosita va a necesitar algo de comida tarde o temprano."


translate english c3201_21bf439d:


    xy "\"Hmm... Corner store it is.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
