

translate english a3191_fe74503a:


    xy "\"¿Ya escampó afuera?\""


translate english a3191_99c0e876:


    "Cuando llegamos a la entrada principal, noto que afuera parece haber menos lluvia."


translate english a3191_f8ada31b:


    xy "\"Quizá deberíamos irnos a casa ahora mientras podemos.\""


translate english a3191_f50e81fe:



    voice "voice/a31/9100010a02.opus"
    aoi "\"¡Entendido! ¡Miyuki desapareció!\""


translate english a3191_0d980bcd:


    xy "\"...Espera, ¿qué?\""


translate english a3191_5d0fcf81:


    "Miro a mi alrededor."


translate english a3191_3f1a62ca:


    "Efectivamente, no la veo por ningún lado cerca de los casilleros de zapatos."


translate english a3191_3aae048b:


    "¿De verdad se fue a vagar por el edificio escolar? ¿De noche? ¿Sola?"


translate english a3191_0d05ff30:


    xy "\"¡¡¡AAAHH!!!\""


translate english a3191_d17accb5:


    xy "\"¡¿Q-Qué-Qué fue ese ruido?!\""


translate english a3191_199c7f05:



    voice "voice/a31/9100020a01.opus"
    mx "\"Ah, ups. ¿Los asusté?\""


translate english a3191_65809886:


    "Miyuki aparece desde la dirección del pasillo, con una sonrisa burlona."


translate english a3191_071b6d14:


    "Parece que sostiene algo."


translate english a3191_0e011ed2:



    voice "voice/a31/9100030a02.opus"
    aoi "\"¿Sopa de elote?\""


translate english a3191_7a035510:



    voice "voice/a31/9100040a01.opus"
    mx "\"Hace frío esta noche. Bebe esto y entra en calor.\""


translate english a3191_ac2eb980:



    voice "voice/a31/9100050a02.opus"
    aoi "\"¿Es para mí?\""


translate english a3191_8836f3c1:



    voice "voice/a31/9100060a01.opus"
    mx "\"Claro que sí. Es un símbolo de nuestra amistad restaurada.\""


translate english a3191_bce99899:



    voice "voice/a31/9100070a02.opus"
    aoi "\"¡G-Gracias!\""


translate english a3191_28342e32:



    voice "voice/a31/9100080a02.opus"
    aoi "\"¡Aoi se lo va a tomar ahora mismo!\""


translate english a3191_8bbe2867:



    voice "voice/a31/9100090a02.opus"
    aoi "\"Ggllpp... ggllpp... ggllpp...\""


translate english a3191_85811b65:



    voice "voice/a31/9100100a02.opus"
    aoi "\"Mmm... Está calientito y rico...\""


translate english a3191_58b5513f:



    voice "voice/a31/9100110a02.opus"
    aoi "\"Me hace sentir toda calientita.\""


translate english a3191_d9a5a449:


    "Aoi sonríe satisfecha."


translate english a3191_ae9b8743:



    voice "voice/a31/9100120a02.opus"
    aoi "\"¡Ah, es cierto!\""


translate english a3191_3a3368cb:


    xy "\"¿Hmm? Aoi, ¿a dónde vas?\""


translate english a3191_e0422d29:



    voice "voice/a31/9100130a02.opus"
    aoi "\"¡Entendido! ¡Miyuki desapareció!\""


translate english a3191_d5a85c60:



    voice "voice/a31/9100140a02.opus"
    aoi "\"¡Aoi también tiene un símbolo de amistad para ti!\""


translate english a3191_dc86eaaa:



    voice "voice/a31/9100150a01.opus"
    mx "\"¿Yabaley's?\""


translate english a3191_82e49da2:


    xy "\"Solo tómalo, Miyuki.\""


translate english a3191_81322788:



    voice "voice/a31/9100160a01.opus"
    mx "\"¿Qué? No, yo...\""


translate english a3191_b4d28aca:



    voice "voice/a31/9100170a02.opus"
    aoi "\"¿Es porque me odias?\""


translate english a3191_31976ba4:



    voice "voice/a31/9100180a01.opus"
    mx "\"¡Claro que no!\""


translate english a3191_998c4748:



    voice "voice/a31/9100190a01.opus"
    mx "\"...Bien. Acepto con gratitud este símbolo de tu afecto.\""


translate english a3191_57c1b0ba:


    "Mira con el ceño fruncido la lata de jugo de tomate recién abierta."


translate english a3191_f27ad4ac:



    voice "voice/a31/9100200a01.opus"
    mx "\"¡Salud!\""


translate english a3191_673e05f9:



    voice "voice/a31/9100210a01.opus"
    mx "\"¡Ggllpp... ggllpp... ggllpp... ggllpp...!\""


translate english a3191_6134b119:



    voice "voice/a31/9100220a01.opus"
    mx "\"Ggllpp... ggllpp... mm... ¿mmm...?\""


translate english a3191_092058e5:



    voice "voice/a31/9100230a01.opus"
    mx "\"Espera... ¿Esto de verdad está bueno?\""


translate english a3191_68cd4b3a:


    xy "\"¿En serio?\""


translate english a3191_8e549238:



    voice "voice/a31/9100240a01.opus"
    mx "\"¡Sí! Mucho mejor de lo que esperaba, al menos...\""


translate english a3191_813e3fff:



    voice "voice/a31/9100250a02.opus"
    aoi "\"¡Claro!\""


translate english a3191_b1c9153c:



    voice "voice/a31/9100260a02.opus"
    aoi "\"¡Está lleno de mi amor!\""


translate english a3191_32f54e84:



    voice "voice/a31/9100270a01.opus"
    mx "\"Sí, quizá... ¡Jeje!\""


translate english a3191_cd63a2b8:


    "Miyuki y Aoi comparten una sonrisa."


translate english a3191_8fc39fa7:


    "En realidad estoy empezando a sentirme algo excluido aquí..."


translate english a3191_61089105:



    voice "voice/a31/9100280a01.opus"
    mx "\"Eso me recuerda. Deberíamos comprar algo de comida.\""


translate english a3191_271f59b2:


    xy "\"¡Sí! Me muero de hambre después de todo lo que corremos...\""


translate english a3191_37e46589:


    xy "\"Ah. Te referías... al gato. Cierto.\""


translate english a3191_7aa4cb27:


    xy "\"Después de todo, SIGUE siendo un gatito... ¿Deberíamos comprarle leche?\""


translate english a3191_784cd12e:


    xy "\"Ah, pero Catnip probablemente esté cerrado a esta hora...\""


translate english a3191_dadc2815:



    voice "voice/a31/9100300a02.opus"
    aoi "\"¿Tal vez la tienda de la esquina?\""


translate english a3191_f2165178:


    xy "\"Espera... ¿Los gatitos siquiera pueden tomar la misma leche que los humanos?\""


translate english a3191_ea1436dd:



    voice "voice/a31/9100310a01.opus"
    mx "\"Sí pueden.\""


translate english a3191_f2a9c8e4:



    voice "voice/a31/9100320a01.opus"
    mx "\"Mientras esté pasteurizada, es segura.\""


translate english a3191_cf65cfaa:


    xy "\"¿Ah, en serio?\""


translate english a3191_fd632c79:



    voice "voice/a31/9100330a01.opus"
    mx "\"Estuve leyendo sobre eso en línea.\""


translate english a3191_32413ff4:



    voice "voice/a31/9100340a02.opus"
    aoi "\"Admítelo, Miyuki. Quieres un gato, ¿verdad?\""


translate english a3191_90593ccc:



    voice "voice/a31/9100350a01.opus"
    mx "\"N-No... No es eso...\""


translate english a3191_53d25f02:


    "No me imagino ninguna OTRA razón por la que investigarías ese tipo de cosa, pero da igual."


translate english a3191_1175ec05:


    xy "\"Bien, ¿y ahora dónde está la tienda de la esquina más cercana...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
