

translate english a3191_fe74503a:


    xy "\"Has it let up out there?\""


translate english a3191_99c0e876:


    "Cuando llegamos a la entrada principal, noto que afuera parece haber menos lluvia."


translate english a3191_f8ada31b:


    xy "\"Maybe we should head home now while we can.\""


translate english a3191_f50e81fe:



    voice "voice/a31/9100010a02.opus"
    aoi "\"Got it! Miyuki's missing!\""


translate english a3191_0d980bcd:


    xy "\"...Wait, what?\""


translate english a3191_5d0fcf81:


    "Miro a mi alrededor."


translate english a3191_3f1a62ca:


    "Efectivamente, no la veo por ningún lado cerca de los casilleros de zapatos."


translate english a3191_3aae048b:


    "¿De verdad se fue a vagar por el edificio escolar? ¿De noche? ¿Sola?"


translate english a3191_0d05ff30:


    xy "\"AAAAHH!!!\""


translate english a3191_d17accb5:


    xy "\"Wh-Wh-What was that sound?!\""


translate english a3191_199c7f05:



    voice "voice/a31/9100020a01.opus"
    mx "\"Oh, oops. Did I scare you?\""


translate english a3191_65809886:


    "Miyuki aparece desde la dirección del pasillo, con una sonrisa burlona."


translate english a3191_071b6d14:


    "Parece que sostiene algo."


translate english a3191_0e011ed2:



    voice "voice/a31/9100030a02.opus"
    aoi "\"Corn chowder?\""


translate english a3191_7a035510:



    voice "voice/a31/9100040a01.opus"
    mx "\"It's cold tonight. Drink this and warm up.\""


translate english a3191_ac2eb980:



    voice "voice/a31/9100050a02.opus"
    aoi "\"It's for me?\""


translate english a3191_8836f3c1:



    voice "voice/a31/9100060a01.opus"
    mx "\"Sure is. It's a token of our friendship restored.\""


translate english a3191_bce99899:



    voice "voice/a31/9100070a02.opus"
    aoi "\"Th-Thank you!\""


translate english a3191_28342e32:



    voice "voice/a31/9100080a02.opus"
    aoi "\"Aoi will drink it right now!\""


translate english a3191_8bbe2867:



    voice "voice/a31/9100090a02.opus"
    aoi "\"Ggllpp... ggllpp... ggllpp...\""


translate english a3191_85811b65:



    voice "voice/a31/9100100a02.opus"
    aoi "\"Mmm... It's nice and warm...\""


translate english a3191_58b5513f:



    voice "voice/a31/9100110a02.opus"
    aoi "\"Makes me feel all toasty.\""


translate english a3191_d9a5a449:


    "Aoi sonríe satisfecha."


translate english a3191_ae9b8743:



    voice "voice/a31/9100120a02.opus"
    aoi "\"Oh, that's right!\""


translate english a3191_3a3368cb:


    xy "\"Hmm? Aoi, where are you going?\""


translate english a3191_e0422d29:



    voice "voice/a31/9100130a02.opus"
    aoi "\"Got it! Miyuki's missing!\""


translate english a3191_d5a85c60:



    voice "voice/a31/9100140a02.opus"
    aoi "\"Aoi has a token of friendship for you, too!\""


translate english a3191_dc86eaaa:



    voice "voice/a31/9100150a01.opus"
    mx "\"Yabaley's?\""


translate english a3191_82e49da2:


    xy "\"Just take it, Miyuki.\""


translate english a3191_81322788:



    voice "voice/a31/9100160a01.opus"
    mx "\"What? No, I—\""


translate english a3191_b4d28aca:



    voice "voice/a31/9100170a02.opus"
    aoi "\"Is it because you hate me?\""


translate english a3191_31976ba4:



    voice "voice/a31/9100180a01.opus"
    mx "\"Of course not!\""


translate english a3191_998c4748:



    voice "voice/a31/9100190a01.opus"
    mx "\"...Fine. I gratefully accept this token of your affection.\""


translate english a3191_57c1b0ba:


    "Mira con el ceño fruncido la lata de jugo de tomate recién abierta."


translate english a3191_f27ad4ac:



    voice "voice/a31/9100200a01.opus"
    mx "\"Bottoms up!\""


translate english a3191_673e05f9:



    voice "voice/a31/9100210a01.opus"
    mx "\"Ggllpp... ggllpp... ggllpp... ggllpp...!\""


translate english a3191_6134b119:



    voice "voice/a31/9100220a01.opus"
    mx "\"Ggllpp... ggllpp... mm... mmm...?\""


translate english a3191_092058e5:



    voice "voice/a31/9100230a01.opus"
    mx "\"Wait... This stuff is actually good?\""


translate english a3191_68cd4b3a:


    xy "\"For real?\""


translate english a3191_8e549238:



    voice "voice/a31/9100240a01.opus"
    mx "\"Yeah! Way better than I was expecting, at least...\""


translate english a3191_813e3fff:



    voice "voice/a31/9100250a02.opus"
    aoi "\"Of course!\""


translate english a3191_b1c9153c:



    voice "voice/a31/9100260a02.opus"
    aoi "\"It's full of my love!\""


translate english a3191_32f54e84:



    voice "voice/a31/9100270a01.opus"
    mx "\"Yeah, maybe so... Hehe!\""


translate english a3191_cd63a2b8:


    "Miyuki y Aoi comparten una sonrisa."


translate english a3191_8fc39fa7:


    "En realidad estoy empezando a sentirme algo excluido aquí..."


translate english a3191_61089105:



    voice "voice/a31/9100280a01.opus"
    mx "\"That reminds me. We should pick up some food.\""


translate english a3191_271f59b2:


    xy "\"Yeah! I'm starving after all that running around we—\""


translate english a3191_37e46589:


    xy "\"Oh. You meant... for the cat. Right.\""


translate english a3191_7aa4cb27:


    xy "\"It IS still a kitten, after all... Should we get it some milk?\""


translate english a3191_784cd12e:


    xy "\"Oh, but Catnip's probably closed at this time of night...\""


translate english a3191_dadc2815:



    voice "voice/a31/9100300a02.opus"
    aoi "\"Maybe the corner store?\""


translate english a3191_f2165178:


    xy "\"Wait... Are kittens even allowed to drink the same milk as humans?\""


translate english a3191_ea1436dd:



    voice "voice/a31/9100310a01.opus"
    mx "\"They can, yes.\""


translate english a3191_f2a9c8e4:



    voice "voice/a31/9100320a01.opus"
    mx "\"As long as it's pasteurized, it's safe.\""


translate english a3191_cf65cfaa:


    xy "\"Oh, really?\""


translate english a3191_fd632c79:



    voice "voice/a31/9100330a01.opus"
    mx "\"I was reading about it online.\""


translate english a3191_32413ff4:



    voice "voice/a31/9100340a02.opus"
    aoi "\"Admit it, Miyuki. You want a cat, don't you?\""


translate english a3191_90593ccc:



    voice "voice/a31/9100350a01.opus"
    mx "\"N-No... That's not it...\""


translate english a3191_53d25f02:


    "No me imagino ninguna OTRA razón por la que investigarías ese tipo de cosa, pero da igual."


translate english a3191_1175ec05:


    xy "\"Okay, now where's the closest corner store...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
