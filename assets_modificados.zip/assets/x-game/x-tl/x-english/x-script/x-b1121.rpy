

translate english b1121_c7c89bba:


    "...¿Mmm? ¿Q-Qué demonios...?"


translate english b1121_80c3de54:


    "¿Estoy... en el salón de clases?"


translate english b1121_35a3cf85:


    "¿Entonces qué fue eso de hace un momento?"


translate english b1121_e43a61cb:


    xy "\"......Oh.\""


translate english b1121_cee85ac0:


    "Un minuto lo tengo en Auto, y al siguiente estoy de vuelta en la pantalla de título."


translate english b1121_f617091b:


    "Supongo que me desmayé mientras jugaba."


translate english b1121_537d4b0e:


    "Mis recuerdos están algo borrosos..."


translate english b1121_f1e1aeef:


    "Sacudiéndome para despertar, toco Nueva partida."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
