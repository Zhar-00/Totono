

translate english c3191_32097f71:


    xy "\"Aoi! Where are you?!\""


translate english c3191_f4fc61f7:


    "Mi voz resuena y se desvanece en la oscuridad."


translate english c3191_421c3a99:


    "El gimnasio está completamente oscuro."


translate english c3191_8e9a600c:


    "Normalmente no habría ni un alma aquí a esta hora."


translate english c3191_9a1b56a5:


    xy "\"Aoi! I know you're in here!\""


translate english c3191_59471e5b:



    voice "voice/c31/9100020a02.opus"
    aoi "\"Quiet!\""


translate english c3191_74e6507c:


    xy "\"I heard that!\""


translate english c3191_f8bb8eab:


    "Esa fue la voz de Aoi hace un momento, ¡estoy seguro!"


translate english c3191_2bb61214:


    xy "\"C'mon, answer me!\""


translate english c3191_c91eda74:


    "El gatito maúlla en lugar de Aoi."


translate english c3191_12f0aa11:


    "Sigo el sonido hasta la zona del escenario."


translate english c3191_65711612:


    xy "\"Aoi.\""


translate english c3191_07df4cc9:



    voice "voice/c31/9100040a02.opus"
    aoi "\"......\""


translate english c3191_e97f4add:


    xy "\"Gimme a break. What are you doing in that stupid onesie?\""


translate english c3191_300d48bb:


    xy "\"Did you really feel the need to put it on just because you rescued a kitten?\""


translate english c3191_696c985a:



    voice "voice/c31/9100050a02.opus"
    aoi "\"......\""


translate english c3191_698bca23:


    xy "\"You got caught out in the rain, didn't you? Did you forget to bring your umbrella? Again?\""


translate english c3191_24bf0687:


    xy "\"Look, we can't have you getting sick—\""


translate english c3191_47b2c4ab:



    voice "voice/c31/9100060a02.opus"
    aoi "\"......\""


translate english c3191_0eac9572:


    "Aoi no dice palabra."


translate english c3191_763026e9:


    "Se niega a responder."


translate english c3191_e1a81e54:


    "Extiendo la mano para tomar la suya."


translate english c3191_967cc4b8:


    xy "\"Let's just go back to my place and—\""


translate english c3191_56e00acc:



    voice "voice/c31/9100070a02.opus"
    aoi "\"No.\""


translate english c3191_7f55764c:


    "Aparta mi mano de un golpe, rechazando de plano mi ayuda."


translate english c3191_9c10954b:


    "Pero me niego a irme a casa con las manos vacías."


translate english c3191_47cd5a27:


    xy "\"Don't be like that. The little thing's probably freezing.\""


translate english c3191_68ca8357:


    "El gatito maúlla, como si estuviera de acuerdo."


translate english c3191_64243bfa:



    voice "voice/c31/9100090a02.opus"
    aoi "\"Go ahead... Take Eru, then.\""


translate english c3191_23901dd5:



    voice "voice/c31/9100100a02.opus"
    aoi "\"Aoi's going to disappear.\""


translate english c3191_e3adb631:


    xy "\"What...?\""


translate english c3191_fdf3a566:



    voice "voice/c31/9100110a02.opus"
    aoi "\"My existence has no purpose.\""


translate english c3191_7e70dc5a:


    xy "\"What? Don't be stup—\""


translate english c3191_6361a183:



    voice "voice/c31/9100120a02.opus"
    aoi "\"Aoi wants you and Miyuki to get together.\""


translate english c3191_53a0c1bf:



    voice "voice/c31/9100130a02.opus"
    aoi "\"That's why Aoi made friends with you.\""


translate english c3191_e49e8a97:


    "Sí, ella me lo dijo desde el principio."


translate english c3191_f6f2cb6c:


    "Pero eso ya no importa."


translate english c3191_f94bcaeb:



    voice "voice/c31/9100140a02.opus"
    aoi "\"Aoi broke the promise.\""


translate english c3191_48cf3724:



    voice "voice/c31/9100150a02.opus"
    aoi "\"Miyuki said she would cut ties if Aoi rescued the cat.\""


translate english c3191_c9b90be2:


    xy "\"So? I think you did the right thing—\""


translate english c3191_32757d15:



    voice "voice/c31/9100160a02.opus"
    aoi "\"That's not important.\""


translate english c3191_58c0470c:


    "El débil susurro de Aoi se clava en mi corazón, más afilado que cualquier grito."


translate english c3191_1b2681db:



    voice "voice/c31/9100170a02.opus"
    aoi "\"Aoi has no right to be Miyuki's friend anymore.\""


translate english c3191_202b958f:



    voice "voice/c31/9100180a02.opus"
    aoi "\"And Aoi can't be a romance option.\""


translate english c3191_6042f6e8:



    voice "voice/c31/9100190a02.opus"
    aoi "\"So now Aoi's life has no purpose.\""


translate english c3191_7a8a0edd:



    voice "voice/c31/9100200a02.opus"
    aoi "\"...Bye-bye.\""


translate english c3191_f1055486:


    "Aoi me da la espalda."


translate english c3191_c82f5207:


    "Su pequeña figura se desvanece en las sombras."


translate english c3191_5eeeb50c:


    "El eco de sus pasos se vuelve tenue."


translate english c3191_a4d67815:


    "Luego desaparece tras bambalinas."


translate english c3191_5f144c5e:


    "—¿De verdad es esto lo mejor?"


translate english c3191_e9f85736:


    xy "\"Aoi!\""


translate english c3191_f8df3452:


    "Antes de darme cuenta, me encuentro corriendo tras ella."


translate english c3191_6a0cfec4:


    "Me abalanzo y agarro su mano."


translate english c3191_6ee2d6c9:


    xy "\"Wait!\""


translate english c3191_625827f0:



    voice "voice/c31/9100210a02.opus"
    aoi "\"No!\""


translate english c3191_c2f715a1:


    "Aoi intenta escapar, pero le bloqueo el paso."


translate english c3191_b869d63d:



    voice "voice/c31/9100220a02.opus"
    aoi "\"......!\""


translate english c3191_c443bb30:


    "Sus ojos están inundados de lágrimas."


translate english c3191_a1e88f6d:


    "Lágrimas de tristeza..."


translate english c3191_98130385:


    xy "\"Your life DOES have a purpose!\""


translate english c3191_80fe39eb:



    voice "voice/c31/9100230a02.opus"
    aoi "\"No it doesn't.\""


translate english c3191_4bc0c35d:



    voice "voice/c31/9100240a02.opus"
    aoi "\"Aoi's just a transceiver... a weirdo...\""


translate english c3191_acedc26a:


    xy "\"I mean, yes, I admit, I did think you were weird at first.\""


translate english c3191_7304ee95:


    xy "\"Completely unpredictable, always alone... and then you randomly tried to blackmail us.\""


translate english c3191_e6775056:


    xy "\"But as time passed, I started to worry about you.\""


translate english c3191_9260d64a:


    xy "\"And I started to enjoy having you around.\""


translate english c3191_b06a9f0b:



    voice "voice/c31/9100250a02.opus"
    aoi "\"You're just confused.\""


translate english c3191_cd28d581:


    xy "\"No, I'm not!\""


translate english c3191_3c60a175:


    xy "\"Look at me. I've got absolutely nothing going for me. I hate being in the spotlight. My life is boring and uneventful, and I prefer to keep it that way.\""


translate english c3191_e88a3035:


    xy "\"And yet here I am, trespassing on school grounds at night.\""


translate english c3191_1f3ce17c:


    xy "\"All for the sake of tracking you down.\""


translate english c3191_0083ffb3:



    voice "voice/c31/9100260a02.opus"
    aoi "\"But... Miyuki...\""


translate english c3191_8899525a:


    xy "\"Miyuki doesn't matter right now!\""


translate english c3191_aa2b29f0:


    xy "\"I'm your friend, remember?\""


translate english c3191_6a697ac6:



    voice "voice/c31/9100270a02.opus"
    aoi "\"Fri...end...?\""


translate english c3191_8e753df7:


    "La presa se rompe, y las lágrimas ruedan por sus mejillas."


translate english c3191_ad8859b3:



    voice "voice/c31/9100280a02.opus"
    aoi "\"Is that... allowed?\""


translate english c3191_9daaa055:



    voice "voice/c31/9100290a02.opus"
    aoi "\"Are you sure you want to be my friend? Even if Miyuki cuts ties with me?\""


translate english c3191_aea83d2b:


    xy "\"I won't LET her cut ties with you.\""


translate english c3191_8541471d:


    xy "\"The three of us will be friends forever.\""


translate english c3191_8016ecec:



    voice "voice/c31/9100300a02.opus"
    aoi "\"Shinichi!!!\""


translate english c3191_44db71fe:



    voice "voice/c31/9100310a02.opus"
    aoi "\"—!!!\""


translate english c3191_3286f0f0:


    "Aoi salta a mis brazos."


translate english c3191_c4509b8b:



    voice "voice/c31/9100320a02.opus"
    aoi "\"Hnn... nnn... nnngh... waaahh...!\""


translate english c3191_9576beca:



    voice "voice/c31/9100330a02.opus"
    aoi "\"Th... Th... Thank you... so much...!\""


translate english c3191_7ddff1b8:



    voice "voice/c31/9100340a02.opus"
    aoi "\"Shinichi... Aoi... Aoi wants to... stay with you too...!\""


translate english c3191_c6326525:



    voice "voice/c31/9100350a02.opus"
    aoi "\"Aoi just wants to... stay friends with you...!\""


translate english c3191_2f0e0c92:


    "Entierra la cara en mi pecho y empieza a sollozar."


translate english c3191_73133192:


    "Le acaricio el cabello con suavidad."


translate english c3191_a8ddc340:


    "We're both so bad at this \"friendship\"la amistad."


translate english c3191_f98a0994:


    "Pero podemos ir descubriendo las cosas sobre la marcha."


translate english c3191_b9d37f96:


    "Estoy seguro de ello."


translate english c3191_f7b9f730:


    "Mientras tanto, el gatito nos maúlla como si nos animara."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
