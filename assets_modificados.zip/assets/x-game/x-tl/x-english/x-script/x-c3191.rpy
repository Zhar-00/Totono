

translate english c3191_32097f71:


    xy "\"¡Aoi! ¿¡Dónde estás!?\""


translate english c3191_f4fc61f7:


    "Mi voz resuena y se desvanece en la oscuridad."


translate english c3191_421c3a99:


    "El gimnasio está completamente oscuro."


translate english c3191_8e9a600c:


    "Normalmente no habría ni un alma aquí a esta hora."


translate english c3191_9a1b56a5:


    xy "\"¡Aoi! ¡Sé que estás aquí!\""


translate english c3191_59471e5b:



    voice "voice/c31/9100020a02.opus"
    aoi "\"¡Silencio!\""


translate english c3191_74e6507c:


    xy "\"¡Te oí!\""


translate english c3191_f8bb8eab:


    "Esa fue la voz de Aoi hace un momento, ¡estoy seguro!"


translate english c3191_2bb61214:


    xy "\"¡Vamos, respóndeme!\""


translate english c3191_c91eda74:


    "El gatito maúlla en lugar de Aoi."


translate english c3191_12f0aa11:


    "Sigo el sonido hasta la zona del escenario."


translate english c3191_65711612:


    xy "\"Aoi.\""


translate english c3191_07df4cc9:



    voice "voice/c31/9100040a02.opus"
    aoi "\"......\""


translate english c3191_e97f4add:


    xy "\"Dame un respiro. ¿Qué haces con ese estúpido enterizo?\""


translate english c3191_300d48bb:


    xy "\"¿De verdad sentiste la necesidad de ponértelo solo porque rescataste a un gatito?\""


translate english c3191_696c985a:



    voice "voice/c31/9100050a02.opus"
    aoi "\"......\""


translate english c3191_698bca23:


    xy "\"Te agarró la lluvia, ¿verdad? ¿Olvidaste traer tu paraguas? ¿Otra vez?\""


translate english c3191_24bf0687:


    xy "\"Mira, no podemos dejar que te enfermes—\""


translate english c3191_47b2c4ab:



    voice "voice/c31/9100060a02.opus"
    aoi "\"......\""


translate english c3191_0eac9572:


    "Aoi no dice palabra."


translate english c3191_763026e9:


    "Se niega a responder."


translate english c3191_e1a81e54:


    "Extiendo la mano para tomar la suya."


translate english c3191_967cc4b8:


    xy "\"Solo vamos a mi casa y—\""


translate english c3191_56e00acc:



    voice "voice/c31/9100070a02.opus"
    aoi "\"No.\""


translate english c3191_7f55764c:


    "Aparta mi mano de un golpe, rechazando de plano mi ayuda."


translate english c3191_9c10954b:


    "Pero me niego a irme a casa con las manos vacías."


translate english c3191_47cd5a27:


    xy "\"No seas así. La cosita probablemente se está congelando.\""


translate english c3191_68ca8357:


    "El gatito maúlla, como si estuviera de acuerdo."


translate english c3191_64243bfa:



    voice "voice/c31/9100090a02.opus"
    aoi "\"Adelante... Llévate a Eru, entonces.\""


translate english c3191_23901dd5:



    voice "voice/c31/9100100a02.opus"
    aoi "\"Aoi va a desaparecer.\""


translate english c3191_e3adb631:


    xy "\"¿Qué...?\""


translate english c3191_fdf3a566:



    voice "voice/c31/9100110a02.opus"
    aoi "\"Mi existencia no tiene propósito.\""


translate english c3191_7e70dc5a:


    xy "\"¿Qué? No seas estúpi—\""


translate english c3191_6361a183:



    voice "voice/c31/9100120a02.opus"
    aoi "\"Aoi quiere que tú y Miyuki estén juntos.\""


translate english c3191_53a0c1bf:



    voice "voice/c31/9100130a02.opus"
    aoi "\"Por eso Aoi se hizo tu amiga.\""


translate english c3191_e49e8a97:


    "Sí, ella me lo dijo desde el principio."


translate english c3191_f6f2cb6c:


    "Pero eso ya no importa."


translate english c3191_f94bcaeb:



    voice "voice/c31/9100140a02.opus"
    aoi "\"Aoi rompió la promesa.\""


translate english c3191_48cf3724:



    voice "voice/c31/9100150a02.opus"
    aoi "\"Miyuki dijo que cortaría lazos si Aoi rescataba al gato.\""


translate english c3191_c9b90be2:


    xy "\"¿Y? Creo que hiciste lo correcto—\""


translate english c3191_32757d15:



    voice "voice/c31/9100160a02.opus"
    aoi "\"Eso no importa.\""


translate english c3191_58c0470c:


    "El débil susurro de Aoi se clava en mi corazón, más afilado que cualquier grito."


translate english c3191_1b2681db:



    voice "voice/c31/9100170a02.opus"
    aoi "\"Aoi ya no tiene derecho a ser amiga de Miyuki.\""


translate english c3191_202b958f:



    voice "voice/c31/9100180a02.opus"
    aoi "\"Y Aoi no puede ser una opción romántica.\""


translate english c3191_6042f6e8:



    voice "voice/c31/9100190a02.opus"
    aoi "\"Así que ahora la vida de Aoi no tiene propósito.\""


translate english c3191_7a8a0edd:



    voice "voice/c31/9100200a02.opus"
    aoi "\"...Adiós.\""


translate english c3191_f1055486:


    "Aoi me da la espalda."


translate english c3191_c82f5207:


    "Su pequeña figura se desvanece en las sombras."


translate english c3191_5eeeb50c:


    "El eco de sus pasos se vuelve tenue."


translate english c3191_a4d67815:


    "Luego desaparece tras bambalinas."


translate english c3191_5f144c5e:


    "—¿De verdad es esto lo mejor?"


translate english c3191_e9f85736:


    xy "\"¡Aoi!\""


translate english c3191_f8df3452:


    "Antes de darme cuenta, me encuentro corriendo tras ella."


translate english c3191_6a0cfec4:


    "Me abalanzo y agarro su mano."


translate english c3191_6ee2d6c9:


    xy "\"¡Espera!\""


translate english c3191_625827f0:



    voice "voice/c31/9100210a02.opus"
    aoi "\"¡No!\""


translate english c3191_c2f715a1:


    "Aoi intenta escapar, pero le bloqueo el paso."


translate english c3191_b869d63d:



    voice "voice/c31/9100220a02.opus"
    aoi "\"......!\""


translate english c3191_c443bb30:


    "Sus ojos están inundados de lágrimas."


translate english c3191_a1e88f6d:


    "Lágrimas de tristeza..."


translate english c3191_98130385:


    xy "\"¡Tu vida SÍ tiene un propósito!\""


translate english c3191_80fe39eb:



    voice "voice/c31/9100230a02.opus"
    aoi "\"No, no lo tiene.\""


translate english c3191_4bc0c35d:



    voice "voice/c31/9100240a02.opus"
    aoi "\"Aoi es solo un transceptor... una rara...\""


translate english c3191_acedc26a:


    xy "\"O sea, sí, lo admito, al principio pensé que eras rara.\""


translate english c3191_7304ee95:


    xy "\"Completamente impredecible, siempre sola... y luego, de la nada, intentaste chantajearnos.\""


translate english c3191_e6775056:


    xy "\"Pero con el tiempo, empecé a preocuparme por ti.\""


translate english c3191_9260d64a:


    xy "\"Y empecé a disfrutar tenerte cerca.\""


translate english c3191_b06a9f0b:



    voice "voice/c31/9100250a02.opus"
    aoi "\"Solo estás confundida.\""


translate english c3191_cd28d581:


    xy "\"¡No, no lo estoy!\""


translate english c3191_3c60a175:


    xy "\"Mírame. No tengo absolutamente nada a mi favor. Odio estar en el centro de atención. Mi vida es aburrida y sin incidentes, y prefiero mantenerla así.\""


translate english c3191_e88a3035:


    xy "\"Y sin embargo, aquí estoy, allanando los terrenos de la escuela de noche.\""


translate english c3191_1f3ce17c:


    xy "\"Todo con tal de encontrarte.\""


translate english c3191_0083ffb3:



    voice "voice/c31/9100260a02.opus"
    aoi "\"Pero... Miyuki...\""


translate english c3191_8899525a:


    xy "\"¡Miyuki no importa ahora!\""


translate english c3191_aa2b29f0:


    xy "\"Soy tu amigo, ¿recuerdas?\""


translate english c3191_6a697ac6:



    voice "voice/c31/9100270a02.opus"
    aoi "\"¿A...migo...?\""


translate english c3191_8e753df7:


    "La presa se rompe, y las lágrimas ruedan por sus mejillas."


translate english c3191_ad8859b3:



    voice "voice/c31/9100280a02.opus"
    aoi "\"¿Eso... está permitido?\""


translate english c3191_9daaa055:



    voice "voice/c31/9100290a02.opus"
    aoi "\"¿Estás seguro de que quieres ser mi amigo? ¿Aunque Miyuki corte lazos conmigo?\""


translate english c3191_aea83d2b:


    xy "\"No voy a DEJAR que corte lazos contigo.\""


translate english c3191_8541471d:


    xy "\"Los tres seremos amigos por siempre.\""


translate english c3191_8016ecec:



    voice "voice/c31/9100300a02.opus"
    aoi "\"¡¡¡Shinichi!!!\""


translate english c3191_44db71fe:



    voice "voice/c31/9100310a02.opus"
    aoi "\"—!!!\""


translate english c3191_3286f0f0:


    "Aoi salta a mis brazos."


translate english c3191_c4509b8b:



    voice "voice/c31/9100320a02.opus"
    aoi "\"¡Hnn... nnn... nnngh... waaah...!\""


translate english c3191_9576beca:



    voice "voice/c31/9100330a02.opus"
    aoi "\"¡Mu... Mu... ¡Muchas... gracias...!\""


translate english c3191_7ddff1b8:



    voice "voice/c31/9100340a02.opus"
    aoi "\"¡Shinichi... Aoi... Aoi también quiere... quedarse contigo...!\""


translate english c3191_c6326525:



    voice "voice/c31/9100350a02.opus"
    aoi "\"¡Aoi solo quiere... seguir siendo tu amiga...!\""


translate english c3191_2f0e0c92:


    "Entierra la cara en mi pecho y empieza a sollozar."


translate english c3191_73133192:


    "Le acaricio el cabello con suavidad."


translate english c3191_a8ddc340:


    "We're both so bad at this \"friendship\"la amistad."


translate english c3191_f98a0994:


    "Pero podemos ir descubriendo las cosas sobre la marcha."


translate english c3191_b9d37f96:


    "Estoy seguro de ello."


translate english c3191_f7b9f730:


    "Mientras tanto, el gatito nos maúlla como si nos animara."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
