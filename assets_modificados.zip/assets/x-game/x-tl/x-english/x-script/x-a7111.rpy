

translate english a7111_4b392187:


    "La vida no es una autopista. La vida es una escalera."


translate english a7111_8d713614:


    "Solo tienes que seguir subiendo."


translate english a7111_d8f2be1f:


    "De lo contrario, si empiezas a pensarlo demasiado, te costará dar el siguiente paso."


translate english a7111_a13eecc0:


    "No hay caminos alternativos."


translate english a7111_69eeb23b:


    "No tiene sentido arrepentirse de las acciones que no tomaste."


translate english a7111_5fb20ccb:


    "Dicen que la vida es una serie de elecciones, pero eso es una tontería inventada por los viejos amargados."


translate english a7111_abb998f0:


    "El ayer lleva al hoy, y el hoy lleva al mañana."


translate english a7111_ea0bbe32:


    "Un paso a la vez."


translate english a7111_45837680:


    "¿Qué hay más adelante?"


translate english a7111_2c97b23c:



    voice "voice/a71/1100010b01.opus"
    xtl "\"¡EROTISMO!\""


translate english a7111_a99dd32f:


    "Oh, ¡es cierto! El erotismo. Gracias, Capitán."


translate english a7111_b7fe24b3:


    "...Espera, ¿qué?"


translate english a7111_20a755bb:


    "Eso es ridículo—"


translate english a7111_f02ffb93:



    voice "voice/a71/1100020a01.opus"
    mx "\"¿TÚ de verdad quieres verlo, eh?\""


translate english a7111_49c4f6db:



    voice "voice/a71/1100030a01.opus"
    mx "\"Ya veo... Supongo que los chicos no pueden evitarlo, después de todo...\""


translate english a7111_3da14c0b:


    "Ah. Ahora entiendo."


translate english a7111_64114a92:


    "...¡Claro que sí, soy un hombre!"


translate english a7111_15f4a391:



    voice "voice/a71/1100040a01.opus"
    mx "\"Haré una excepción especial contigo, ¿sí?\""


translate english a7111_c0e69726:


    "Puedo sentir mi cerebro racional desmoronarse..."


translate english a7111_9ad2adcd:


    "...mientras la pura emoción empieza a ahogarlo."


translate english a7111_a33613f7:



    voice "voice/a71/1100050a01.opus"
    mx "\"¿¡Qué demonios—!? ¡Shinichi!\""


translate english a7111_8ddf42d7:



    voice "voice/a71/1100060a01.opus"
    mx "\"¡Más despacio!\""


translate english a7111_b89afa41:



    voice "voice/a71/1100070b01.opus"
    xtl "\"¡No olvides ser gentil!\""


translate english a7111_f256fd1d:


    "¡Lo sé, Capitán!"


translate english a7111_e4d55076:


    "Prometí que ya no me mentiría a mí mismo."


translate english a7111_4687421d:


    "Ahora es momento de tomar la iniciativa y—"


translate english a7111_6257138c:



    voice "voice/a71/1100080a01.opus"
    mx "\"¡Basta, Shinichi! ¡Deja de actuar como loco! ¡Despierta de una vez!\""


translate english a7111_11169f4b:


    xy "\"No estoy loco.\""


translate english a7111_c82ade50:


    xy "\"Te amo, Miyuki.\""


translate english a7111_fb7410a9:



    voice "voice/a71/1100090a01.opus"
    mx "\"Oh... em... gracias...\""


translate english a7111_e3b90e1a:


    xy "\"Y por supuesto... también amo tus bragas...\""


translate english a7111_50cebeb4:



    voice "voice/a71/1100100a01.opus"
    mx "\"¿¡Qué!?\""


translate english a7111_6e8a55d1:


    xy "\"Y amo todo lo que hay debajo...\""


translate english a7111_c8d08946:



    voice "voice/a71/1100110a01.opus"
    mx "\"¡E-Enfermo! ¡Basta!\""


translate english a7111_97a2cfed:


    xy "\"¡Tengamos sexo...!\""


translate english a7111_dea2d896:



    voice "voice/a71/1100120a01.opus"
    mx "\"......?!\""



translate english a7111_b3242d8f:



    voice "voice/a71/1100130a01.opus"
    mx "\"G... G...\""


translate english a7111_177216ad:



    voice "voice/a71/1100140a01.opus"
    mx "\"¡¡¡CONTROLATE!!!\""


translate english a7111_a78fc1ae:


    xy "\"¡Ay, ay, ay, ay!\""


translate english a7111_4cfd79aa:


    xy "\"......¿Eh?\""


translate english a7111_37fcde2b:


    xy "\"¿Esto es... la vida real...?\""


translate english a7111_7d8ceed7:



    voice "voice/a71/1100150a01.opus"
    mx "\"¿¡Qué crees, genio!?\""


translate english a7111_ea339fd0:



    voice "voice/a71/1100160a01.opus"
    mx "\"¡Ahora saca la cabeza de debajo de mi falda! ¡Tonto!\""


translate english a7111_f9b81c58:


    xy "\"Oh... ¿Estaba soñando...?\""


translate english a7111_b796fa7b:



    voice "voice/a71/1100170a01.opus"
    mx "\"¡Dijiste que amas mis bragas!\""


translate english a7111_e29f0cb8:


    xy "\"Lo siento...\""


translate english a7111_cd5c19c8:


    "Maldigo mi subconsciente."


translate english a7111_5e47e9f5:


    "De todas las cosas que querría decirle a la cara, ¡esa NO está en la lista corta!"


translate english a7111_6eee8f4a:


    "¡Es tan vergonzoso que resulta hasta impresionante!"


translate english a7111_27496403:


    "Con razón se sentía tan realista..."


translate english a7111_8a381f01:


    "Bueno, ahora que estoy despierto—"


translate english a7111_dbb16119:



    voice "voice/a71/1100180a01.opus"
    mx "\"¿¡Q-Qué demonios!? ¿¡Por qué tu... tu Polo Sur está en posición de firme!?\""


translate english a7111_8b8e298d:


    xy "\"¿Eh? OH.\""


translate english a7111_95e30e1a:


    "Parece ser que mis zonas bajas están... llenas de ambición masculina..."


translate english a7111_d5fc498b:


    "Ay, Dios, ¡ahora sueno como Yuutarou!"


translate english a7111_ed9f3959:


    "Todo es culpa de ÉL... Sí, quedémonos con eso..."


translate english a7111_36b6d4ab:



    voice "voice/a71/1100190a01.opus"
    mx "\"¿¡Eso te pasa por pensar en mí!?\""


translate english a7111_de6e8051:


    xy "\"¡N-No, no entiendes! La erección matutina es solo parte normal de ser hombre, eso es todo.\""


translate english a7111_d404c24e:


    xy "\"¡No me puse así de duro fantaseando contigo!\""


translate english a7111_6edf8d6a:



    voice "voice/a71/1100200a01.opus"
    mx "\"¿N-No?\""


translate english a7111_b59b76bc:


    "Parece apenada, pero suena un poco decepcionada..."


translate english a7111_1afeee80:


    xy "\"Bueno, quiero decir... eh... Las dos cosas no están DEL TODO desligadas...\""


translate english a7111_544cc742:



    voice "voice/a71/1100210a01.opus"
    mx "\"¡Yo... claro que quiero que sepas que me halaga! ¡Porque ciertamente lo hace! ¡Lo admito!\""


translate english a7111_b263896b:



    voice "voice/a71/1100220a01.opus"
    mx "\"¡Pero hay un tiempo y un lugar para estas cosas! Todavía necesito tiempo para prepararme emocionalmente...\""


translate english a7111_b80d0721:


    xy "\"Tienes toda la razón.\""


translate english a7111_a8f88f03:



    voice "voice/a71/1100230a01.opus"
    mx "\"Como castigo, hoy no desayunas.\""


translate english a7111_a86adc54:


    xy "\"¡De verdad, de verdad lo siento! ¡Perdóname, ama!\""


translate english a7111_b313dc57:



    voice "voice/a71/1100240a01.opus"
    mx "\"¿Oho? ¿TÚ de verdad quieres comer mi comida, eh?\""


translate english a7111_992fbb5d:


    xy "\"¡Haré lo que sea!\""


translate english a7111_177a7c02:


    "No todos los días tengo la oportunidad de empezar el día con algo de la deliciosa comida casera de Miyuki..."


translate english a7111_50d7d569:


    "¡Hasta me postraré si hace falta!"


translate english a7111_376d70e5:



    voice "voice/a71/1100250a01.opus"
    mx "\"Bueno, si lo quieres tanto, supongo que podría reconsiderarlo.\""


translate english a7111_2898dc2f:


    xy "\"¿¡Lo dices en serio!?\""


translate english a7111_464cfb61:



    voice "voice/a71/1100260a01.opus"
    mx "\"Con una condición.\""


translate english a7111_218ac2d9:


    xy "\"¿Cuál?\""


translate english a7111_13f6a4b7:



    voice "voice/a71/1100270a01.opus"
    mx "\"Bueno, verás...\""


translate english a7111_e9deb51f:



    voice "voice/a71/1100280a01.opus"
    mx "\"\"\"\"......Kiss me.\"\"¿Eh?\"?!\""


translate english a7111_94ab1b0b:


    xy "\"...¿Sí...?\""


translate english a7111_0ad6ef11:



    voice "voice/a71/1100290a01.opus"
    mx "\"......Bésame.\""


translate english a7111_ecc4bde9:



    voice "voice/a71/1100300a01.opus"
    mx "\"¡Quiero un beso de buenos días!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
