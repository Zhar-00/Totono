

translate english e1151a_c86782c8:



    voice "voice/e11/51a00010a01.opus"
    mx "\"...Hey!\""


translate english e1151a_0e6a9305:



    voice "voice/e11/51a00011a01.opus"
    mx "\"Did you really think you could escape me?\""


translate english e1151a_f110c8ad:



    voice "voice/e11/51a00020a01.opus"
    mx "\"Now kiss me.\""


translate english e1151a_03e0c4d5:



    voice "voice/e11/51a00030a01.opus"
    mx "\"We'll start this whole world over again.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
