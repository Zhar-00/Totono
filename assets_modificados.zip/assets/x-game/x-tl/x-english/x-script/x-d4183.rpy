

translate english d4183_7698c627:



    voice "voice/d41/8300010b03.opus"
    c "\"Aoi-senpai kept saying her signal wouldn't go through.\""


translate english d4183_16ec07fe:


    xy "\"Was she trying to make a call?\""


translate english d4183_737779a6:



    voice "voice/d41/8300020b03.opus"
    c "\"Uh huh. Several, actually.\""


translate english d4183_40e55a35:



    voice "voice/d41/8300030b03.opus"
    c "\"She said she needed to get in touch with God in order to 'patch the game into the correct route.'\""



translate english d4183_579dcb49:



    voice "voice/d41/8300040b03.opus"
    c "\"But obviously she wasn't going to have any signal. She didn't even have a SIM card.\""


translate english d4183_8583e402:


    xy "\"Huh? What's a SIM card?\""


translate english d4183_9dead44a:



    voice "voice/d41/8300050b03.opus"
    c "\"Oh, uh... How do I put it... It's the IC card that holds your phone number, address book, and all that stuff.\""


translate english d4183_534c114c:



    voice "voice/d41/8300060b03.opus"
    c "\"Without it, your cell phone can't do any 'phone' type stuff.\""



translate english d4183_d524ed02:


    "Pensándolo bien, nunca revisé dentro de su teléfono..."


translate english d4183_af4c6cd0:


    xy "\"She never did send me a single email...\""


translate english d4183_2235001b:



    voice "voice/d41/8300070b03.opus"
    c "\"She gave me her contact info, though. Said it was a symbol of our new friendship.\""


translate english d4183_f2de900d:


    xy "\"Haha... Same here.\""


translate english d4183_42695cd9:



    voice "voice/d41/8300080b03.opus"
    c "\"She's a bit of an oddball, huh?\""


translate english d4183_da5991a0:


    "Haru-chan sonríe con timidez. Parece sentirse más cómoda conmigo ahora."


translate english d4183_be418b21:


    "Su sonrisa es tan linda que no puedo evitar mirarla..."


translate english d4183_3d2a60c0:


    "Si está en el club de teatro, ¿eso significa que compartirá el escenario con Miyuki en algún momento...?"


translate english d4183_8b19a13b:



    voice "voice/d41/8300090b03.opus"
    c "\"L-Listen, um!\""


translate english d4183_058f0d41:



    voice "voice/d41/8300100b03.opus"
    c "\"I feel like meeting Aoi-senpai has given me a tiny bit of courage.\""


translate english d4183_9dfb5f67:



    voice "voice/d41/8300110b03.opus"
    c "\"And I've decided... I want to turn over a new leaf.\""


translate english d4183_bd4ee532:



    voice "voice/d41/8300120b03.opus"
    c "\"So, um...\""


translate english d4183_e1d6ba53:



    voice "voice/d41/8300130b03.opus"
    c "\"I have a big favor to ask... Is that cool?\""


translate english d4183_cb3029f0:


    xy "\"Sure. You've been a huge help, so I'm happy to return the favor.\""


translate english d4183_3cf95522:



    voice "voice/d41/8300140b03.opus"
    c "\"There's someone I think you should kiss!\""


translate english d4183_46bc0fb0:


    xy "\"What?\""


translate english d4183_16f9d9d4:


    xy "\"Don't tell me... You want me to kiss you?\""


translate english d4183_fd855ae3:



    voice "voice/d41/8300150b03.opus"
    c "\"Yeah, I—What? No! I mean... What?! Whoa! No! No way! Aah! AAH!!!\""


translate english d4183_236abb33:



    voice "voice/d41/8300160b03.opus"
    c "\"That's not what I meant! At all! I don't want to kiss you in the least!!!\""


translate english d4183_3bf70163:


    xy "\"I... see...\""


translate english d4183_e2219e2a:



    voice "voice/d41/8300170b03.opus"
    c "\"Uh... well... I mean... I don't think you're gross or anything! That's not it! In fact, if anything, you're totally my type—Oh god, what am I saying?! AAAAAAAAAAAHHH!!!\""


translate english d4183_a6c3753d:


    xy "\"Let's just take a deep breath and calm down, shall we?\""


translate english d4183_5b192d97:



    voice "voice/d41/8300180b03.opus"
    c "\"R-Right...\""


translate english d4183_e54d807f:


    "Tímida y torpe hasta el extremo, esta chica..."


translate english d4183_188fa636:


    xy "\"Oh, sorry, one sec.\""


translate english d4183_c7ced3a3:


    "Saco mi teléfono y reviso mi bandeja de entrada."


translate english d4183_d411f41e:


    "Hay un correo nuevo de Miyuki."


translate english d4183_2a2909be:


    "—¿Estás ocupado más tarde?"


translate english d4183_ba461e0b:


    "—Necesito hablar contigo."


translate english d4183_61265481:


    "—Por favor, pasa por las jaulas de bateo esta noche."


translate english d4183_99c01cae:


    "—Es importante."




translate english d4183_12e64a21:


    xy "\"......\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
