

translate english d4183_7698c627:



    voice "voice/d41/8300010b03.opus"
    c "\"Aoi-senpai no dejaba de decir que su señal no pasaba.\""


translate english d4183_16ec07fe:


    xy "\"¿Estaba intentando llamar?\""


translate english d4183_737779a6:



    voice "voice/d41/8300020b03.opus"
    c "\"Ajá. Varias veces, de hecho.\""


translate english d4183_40e55a35:



    voice "voice/d41/8300030b03.opus"
    c "\"Dijo que necesitaba contactar a Dios para \"parchear el juego a la ruta correcta\".\""



translate english d4183_579dcb49:



    voice "voice/d41/8300040b03.opus"
    c "\"Pero obviamente no iba a tener señal. Ni siquiera tenía tarjeta SIM.\""


translate english d4183_8583e402:


    xy "\"¿Eh? ¿Qué es una tarjeta SIM?\""


translate english d4183_9dead44a:



    voice "voice/d41/8300050b03.opus"
    c "\"Oh, eh... Cómo te lo explico... Es la tarjeta IC que guarda tu número de teléfono, la agenda de contactos y todo eso.\""


translate english d4183_534c114c:



    voice "voice/d41/8300060b03.opus"
    c "\"Sin ella, tu celular no puede hacer nada de lo que hace un \"teléfono\".\""



translate english d4183_d524ed02:


    "Pensándolo bien, nunca revisé dentro de su teléfono..."


translate english d4183_af4c6cd0:


    xy "\"Nunca me envió ni un solo correo...\""


translate english d4183_2235001b:



    voice "voice/d41/8300070b03.opus"
    c "\"Aunque me dio su información de contacto. Dijo que era un símbolo de nuestra nueva amistad.\""


translate english d4183_f2de900d:


    xy "\"Jaja... Igual aquí.\""


translate english d4183_42695cd9:



    voice "voice/d41/8300080b03.opus"
    c "\"Es un poco rarita, ¿eh?\""


translate english d4183_da5991a0:


    "Haru-chan sonríe con timidez. Parece sentirse más cómoda conmigo ahora."


translate english d4183_be418b21:


    "Su sonrisa es tan linda que no puedo evitar mirarla..."


translate english d4183_3d2a60c0:


    "Si está en el club de teatro, ¿eso significa que compartirá el escenario con Miyuki en algún momento...?"


translate english d4183_8b19a13b:



    voice "voice/d41/8300090b03.opus"
    c "\"¡E-Escucha, em!\""


translate english d4183_058f0d41:



    voice "voice/d41/8300100b03.opus"
    c "\"Siento que conocer a Aoi-senpai me ha dado un poquito de valor.\""


translate english d4183_9dfb5f67:



    voice "voice/d41/8300110b03.opus"
    c "\"Y he decidido... que quiero pasar la página.\""


translate english d4183_bd4ee532:



    voice "voice/d41/8300120b03.opus"
    c "\"Así que, em...\""


translate english d4183_e1d6ba53:



    voice "voice/d41/8300130b03.opus"
    c "\"Tengo un gran favor que pedirte... ¿Está bien?\""


translate english d4183_cb3029f0:


    xy "\"Claro. Nos has ayudado muchísimo, así que con gusto te devuelvo el favor.\""


translate english d4183_3cf95522:



    voice "voice/d41/8300140b03.opus"
    c "\"¡Hay alguien a quien creo que deberías besar!\""


translate english d4183_46bc0fb0:


    xy "\"¿Qué?\""


translate english d4183_16f9d9d4:


    xy "\"No me digas... ¿Quieres que te bese?\""


translate english d4183_fd855ae3:



    voice "voice/d41/8300150b03.opus"
    c "\"Sí, yo—¿Qué? ¡No! Digo... ¿¡Qué!? ¡Uoh! ¡No! ¡Para nada! ¡Aah! ¡AAH!\""


translate english d4183_236abb33:



    voice "voice/d41/8300160b03.opus"
    c "\"¡No era eso lo que quería decir! ¡Para nada! ¡No quiero besarte ni un poquito!\""


translate english d4183_3bf70163:


    xy "\"Ya... veo...\""


translate english d4183_e2219e2a:



    voice "voice/d41/8300170b03.opus"
    c "\"Eh... bueno... digo... ¡no es que me des asco ni nada! ¡No es eso! De hecho, si acaso, eres totalmente mi tipo—¡Dios, qué estoy diciendo! ¡AAAAAAAAAAAH!\""


translate english d4183_a6c3753d:


    xy "\"Vamos a respirar hondo y calmarnos, ¿sí?\""


translate english d4183_5b192d97:



    voice "voice/d41/8300180b03.opus"
    c "\"S-Sí...\""


translate english d4183_e54d807f:


    "Tímida y torpe hasta el extremo, esta chica..."


translate english d4183_188fa636:


    xy "\"Oh, perdón, un segundo.\""


translate english d4183_c7ced3a3:


    "Saco mi teléfono y reviso mi bandeja de entrada."


translate english d4183_d411f41e:


    "Hay un correo nuevo de Miyuki."


translate english d4183_2a2909be:


    "—¿Estás ocupado más tarde?"


translate english d4183_ba461e0b:


    "—Necesito hablar contigo."


translate english d4183_61265481:


    "—Por favor, pasa por las jaulas de bateo esta noche."


translate english d4183_99c01cae:


    "—Es importante."




translate english d4183_12e64a21:


    xy "\"......\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
