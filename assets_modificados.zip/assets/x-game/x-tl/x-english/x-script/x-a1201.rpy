

translate english a1201_ecd5bc74:


    xy "\"Hey Yuutarou! Let's grab some lun—\""


translate english a1201_22179ccd:



    voice "voice/a12/0100010b01.opus"
    xtl "\"Nnnnngggghhhhhh...\""


translate english a1201_5c3d50ae:



    voice "voice/a12/0100020b01.opus"
    xtl "\"I'm not hungry...\""


translate english a1201_3187245f:


    xy "\"What's up? Feeling sick?\""


translate english a1201_43a75d0b:



    voice "voice/a12/0100030b01.opus"
    xtl "\"It's the panties...\""


translate english a1201_aed2031e:


    xy "\"You... ate them...?\""


translate english a1201_7db03946:



    voice "voice/a12/0100040b01.opus"
    xtl "\"No!\""


translate english a1201_d8ad7eae:



    voice "voice/a12/0100050b01.opus"
    xtl "\"I found out who they belong to.\""


translate english a1201_975bb64e:


    xy "\"I... see...\""


translate english a1201_638c1c2e:


    "No estoy seguro de querer saber la respuesta, pero..."


translate english a1201_585021e4:


    xy "\"Whose were they?\""


translate english a1201_19d75480:



    voice "voice/a12/0100060b01.opus"
    xtl "\"Ryuujirou's.\""


translate english a1201_0accd139:


    xy "\"\"......\"\""


translate english a1201_608b36a6:


    xy "\"Your... brother's...?\""


translate english a1201_f18a7d74:



    voice "voice/a12/0100070b01.opus"
    xtl "\"Yeah.\""


translate english a1201_a6312cbc:



    voice "voice/a12/0100080b01.opus"
    xtl "\"Apparently he bought them online. To wear.\""


translate english a1201_616c92d1:



    voice "voice/a12/0100090b01.opus"
    xtl "\"He said he... likes to crossdress.\""


translate english a1201_a871a814:


    xy "\"Well then... That's... something.\""


translate english a1201_39352fc5:



    voice "voice/a12/0100100b01.opus"
    xtl "\"\"......\"\""


translate english a1201_0accd139_1:


    xy "\"\"......\"\""


translate english a1201_b61dd641:



    voice "voice/a12/0100110b01.opus"
    xtl "\"Shinichi... I, uh... might have fa—\""


translate english a1201_5a306509:


    xy "\"Stop. Don't... Don't finish that sentence.\""


translate english a1201_f70e476f:



    voice "voice/a12/0100120b01.opus"
    xtl "\"Haha... Hahahahahaha...\""


translate english a1201_0f470887:



    voice "voice/a12/0100130b01.opus"
    xtl "\"My dreams... My dreams are dead...\""


translate english a1201_f3b14c86:


    xy "\"It's going to be okay, Captain. I know you'll find a new dream soon enough.\""


translate english a1201_d6515005:


    xy "\"For now... just give yourself some time to grieve.\""


translate english a1201_8cae49e4:



    voice "voice/a12/0100140b01.opus"
    xtl "\"Thank you, Shinichi... Thank you...!\""


translate english a1201_bc9f2e1e:


    "Yuutarou asiente entre lágrimas."


translate english a1201_42fd9a5a:


    "No tengo idea de qué hacer al respecto. Supongo que solo le daré una palmadita en el hombro."


translate english a1201_968ac531:


    "Mientras vuelvo de la cafetería con mi sándwich, contemplo regresar al salón... pero no me imagino que a ninguno de los dos nos guste sentarnos ahí en silencio juntos."



translate english a1201_a906dd2b:


    "En vez de eso, me dirijo a mi lugar favorito."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
