

translate english a1201_ecd5bc74:


    xy "\"¡Hey Yuutarou! Vamos por el almu—\""


translate english a1201_22179ccd:



    voice "voice/a12/0100010b01.opus"
    xtl "\"Nnnnngggghhhhhh...\""


translate english a1201_5c3d50ae:



    voice "voice/a12/0100020b01.opus"
    xtl "\"No tengo hambre...\""


translate english a1201_3187245f:


    xy "\"¿Qué pasa? ¿Te sientes mal?\""


translate english a1201_43a75d0b:



    voice "voice/a12/0100030b01.opus"
    xtl "\"Son las bragas...\""


translate english a1201_aed2031e:


    xy "\"¿Tú... te las comiste...?\""


translate english a1201_7db03946:



    voice "voice/a12/0100040b01.opus"
    xtl "\"¡No!\""


translate english a1201_d8ad7eae:



    voice "voice/a12/0100050b01.opus"
    xtl "\"Descubrí de quién son.\""


translate english a1201_975bb64e:


    xy "\"Ya... veo...\""


translate english a1201_638c1c2e:


    "No estoy seguro de querer saber la respuesta, pero..."


translate english a1201_585021e4:


    xy "\"¿De quién eran?\""


translate english a1201_19d75480:



    voice "voice/a12/0100060b01.opus"
    xtl "\"De Ryuujirou.\""


translate english a1201_0accd139:


    xy "\"\"......\"\""


translate english a1201_608b36a6:


    xy "\"¿De tu... hermano...?\""


translate english a1201_f18a7d74:



    voice "voice/a12/0100070b01.opus"
    xtl "\"Sí.\""


translate english a1201_a6312cbc:



    voice "voice/a12/0100080b01.opus"
    xtl "\"Aparentemente las compró en línea. Para ponérselas.\""


translate english a1201_616c92d1:



    voice "voice/a12/0100090b01.opus"
    xtl "\"Dijo que... le gusta travestirse.\""


translate english a1201_a871a814:


    xy "\"Bueno entonces... Eso es... algo.\""


translate english a1201_39352fc5:



    voice "voice/a12/0100100b01.opus"
    xtl "\"\"......\"\""


translate english a1201_0accd139_1:


    xy "\"\"......\"\""


translate english a1201_b61dd641:



    voice "voice/a12/0100110b01.opus"
    xtl "\"Shinichi... Yo, eh... quizás me haya paje—\""


translate english a1201_5a306509:


    xy "\"Para. No... No termines esa frase.\""


translate english a1201_f70e476f:



    voice "voice/a12/0100120b01.opus"
    xtl "\"Jaja... Jajajajajaja...\""


translate english a1201_0f470887:



    voice "voice/a12/0100130b01.opus"
    xtl "\"Mis sueños... Mis sueños están muertos...\""


translate english a1201_f3b14c86:


    xy "\"Va a estar bien, Capitán. Sé que pronto encontrarás un nuevo sueño.\""


translate english a1201_d6515005:


    xy "\"Por ahora... solo date algo de tiempo para lamentarlo.\""


translate english a1201_8cae49e4:



    voice "voice/a12/0100140b01.opus"
    xtl "\"¡Gracias, Shinichi... Gracias...!\""


translate english a1201_bc9f2e1e:


    "Yuutarou asiente entre lágrimas."


translate english a1201_42fd9a5a:


    "No tengo idea de qué hacer al respecto. Supongo que solo le daré una palmadita en el hombro."


translate english a1201_968ac531:


    "Mientras vuelvo de la cafetería con mi sándwich, contemplo regresar al salón... pero no me imagino que a ninguno de los dos nos guste sentarnos ahí en silencio juntos."



translate english a1201_a906dd2b:


    "En vez de eso, me dirijo a mi lugar favorito."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
