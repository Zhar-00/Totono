

translate english d4182b_f3bcfd96:


    "Haru-chan fue el testigo más improbable del mundo."


translate english d4182b_13176440:


    "Y sin embargo, según ella, Aoi había visitado la tienda de la esquina varias veces para comprar cosas... incluso después de su supuesta desaparición."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
