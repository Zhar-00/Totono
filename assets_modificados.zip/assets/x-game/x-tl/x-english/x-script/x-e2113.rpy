

translate english e2113_79fb36d3:



    voice "voice/e21/1300010b03.opus"
    c "\"Good morning, Sone-senpai!\""


translate english e2113_5a7f05b5:



    voice "voice/e21/1300020a01.opus"
    mx "\"Oh—Hello there! Good morning!\""


translate english e2113_e6bd9560:



    voice "voice/e21/1300030b03.opus"
    c "\"I... I... I see Susuki-senpai is with you!\""


translate english e2113_11fcf6d0:



    voice "voice/e21/1300040b03.opus"
    c "\"Good morning!!!\""


translate english e2113_a5c7159c:


    xy "\"Morning.\""



translate english e2113_9279c2de:


    "Justo entonces, nos interrumpe una compañera del club de teatro, Haru-chan."


translate english e2113_537f5a9b:



    voice "voice/e21/1300050b03.opus"
    c "\"Uh... uh... umm... er... uh...\""


translate english e2113_c55f8a71:


    xy "\"Hmm? Did you need something?\""


translate english e2113_c3152432:



    voice "voice/e21/1300060b03.opus"
    c "\"Huh? Oh, no, of course not!\""


translate english e2113_65708397:



    voice "voice/e21/1300070b03.opus"
    c "\"I don't need anything! Not really! SORRY FOR SAYING HI!!!\""


translate english e2113_403b5790:



    voice "voice/e21/1300080b03.opus"
    c "\"GOODBYE FOREVER!!!\""


translate english e2113_693b95d5:


    xy "\"H-Hold it!\""


translate english e2113_53cd8d0a:



    voice "voice/e21/1300090b03.opus"
    c "\"Aaah!\""


translate english e2113_8863daa4:


    xy "\"Did you just trip over thin air?\""


translate english e2113_373b2027:


    xy "\"Man, you're always such a klutz.\""


translate english e2113_935a59c3:



    voice "voice/e21/1300100a01.opus"
    mx "\"......\""


translate english e2113_563c0d3a:


    "Miyuki frunce los labios y le lanza una mirada fulminante a Haru-chan."


translate english e2113_b17edff0:


    "Luego da un paso hacia mí—"


translate english e2113_3dc4eb9b:



    voice "voice/e21/1300110a01.opus"
    mx "\"—!!!\""



translate english e2113_7fe1cf16:


    xy "\"Huh...?\""


translate english e2113_5ead1878:


    "—y me agarra la mano con firmeza."


translate english e2113_5f2b18ec:


    xy "\"Ow! Owowow!\""


translate english e2113_96b54c89:



    voice "voice/e21/1300120a01.opus"
    mx "\"Let's go!\""


translate english e2113_ba2d447a:


    xy "\"Huh? But—\""


translate english e2113_de111647:



    voice "voice/e21/1300130a01.opus"
    mx "\"Let's just go!\""


translate english e2113_1aca3f5a:


    "Y así, con mi mano atrapada en el torniquete de Miyuki, seguimos nuestro camino hacia la puerta de la escuela."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
