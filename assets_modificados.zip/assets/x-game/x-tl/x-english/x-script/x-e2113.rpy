

translate english e2113_79fb36d3:



    voice "voice/e21/1300010b03.opus"
    c "\"¡Buenos días, Sone-senpai!\""


translate english e2113_5a7f05b5:



    voice "voice/e21/1300020a01.opus"
    mx "\"¡Oh, hola! ¡Buenos días!\""


translate english e2113_e6bd9560:



    voice "voice/e21/1300030b03.opus"
    c "\"¡Yo... yo... ya veo que Susuki-senpai está contigo!\""


translate english e2113_11fcf6d0:



    voice "voice/e21/1300040b03.opus"
    c "\"¡¡¡Buenos días!!!\""


translate english e2113_a5c7159c:


    xy "\"Buenos días.\""



translate english e2113_9279c2de:


    "Justo entonces, nos interrumpe una compañera del club de teatro, Haru-chan."


translate english e2113_537f5a9b:



    voice "voice/e21/1300050b03.opus"
    c "\"Eh... eh... emm... este... eh...\""


translate english e2113_c55f8a71:


    xy "\"¿Hmm? ¿Necesitabas algo?\""


translate english e2113_c3152432:



    voice "voice/e21/1300060b03.opus"
    c "\"¿Eh? Oh, ¡no, claro que no!\""


translate english e2113_65708397:



    voice "voice/e21/1300070b03.opus"
    c "\"¡No necesito nada! ¡No realmente! ¡¡¡PERDÓN POR SALUDAR!!!\""


translate english e2113_403b5790:



    voice "voice/e21/1300080b03.opus"
    c "\"¡¡¡ADIÓS PARA SIEMPRE!!!\""


translate english e2113_693b95d5:


    xy "\"¡E-Espera!\""


translate english e2113_53cd8d0a:



    voice "voice/e21/1300090b03.opus"
    c "\"¡Aaah!\""


translate english e2113_8863daa4:


    xy "\"¿Acabas de tropezar con el aire?\""


translate english e2113_373b2027:


    xy "\"Hombre, siempre eres tan torpe.\""


translate english e2113_935a59c3:



    voice "voice/e21/1300100a01.opus"
    mx "\"......\""


translate english e2113_563c0d3a:


    "Miyuki frunce los labios y le lanza una mirada fulminante a Haru-chan."


translate english e2113_b17edff0:


    "Luego da un paso hacia mí—"


translate english e2113_3dc4eb9b:



    voice "voice/e21/1300110a01.opus"
    mx "\"—!!!\""



translate english e2113_7fe1cf16:


    xy "\"¿Eh...?\""


translate english e2113_5ead1878:


    "—y me agarra la mano con firmeza."


translate english e2113_5f2b18ec:


    xy "\"¡Ay! ¡Ayayay!\""


translate english e2113_96b54c89:



    voice "voice/e21/1300120a01.opus"
    mx "\"¡Vámonos!\""


translate english e2113_ba2d447a:


    xy "\"¿Eh? Pero—\""


translate english e2113_de111647:



    voice "voice/e21/1300130a01.opus"
    mx "\"¡Solo vámonos!\""


translate english e2113_1aca3f5a:


    "Y así, con mi mano atrapada en el torniquete de Miyuki, seguimos nuestro camino hacia la puerta de la escuela."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
