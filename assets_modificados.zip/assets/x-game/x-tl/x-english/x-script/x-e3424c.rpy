

translate english e3424c_f440a4b8:



    voice "voice/e34/24c00010b02.opus"
    kmsm "\"STILL, [[YOU] ARE AT THE CENTER OF THE UNIVERSE.\""


translate english e3424c_89d1fc31:



    voice "voice/e34/24c00020b02.opus"
    kmsm "\"SHOULD [[YOU] REAFFIRM YOUR INTENTION, [[YOU] MAY TRANSMIT [[YOUR] SIGNAL AT ANY TIME.\""


translate english e3424c_edd4b159:



    voice "voice/e34/24c00030b02.opus"
    kmsm "\"...SHOULD THE SUBJECT SO DESIRE.\""


translate english e3424c_0accd139:


    xy "\"......\""


translate english e3424c_fd07743d:


    xy "\"...Guess they hung up.\""


translate english e3424c_0312f3e0:


    "Con los hombros caídos, miro sin esperanza hacia el cielo nocturno."


translate english e3424c_7b238da8:


    "La luna brilla silenciosamente sobre mí."


translate english e3424c_42bd16f5:


    "Esa llamada no tenía ningún sentido."


translate english e3424c_72764f9b:


    "Diablos, ni YO tengo sentido. ¿Qué estoy haciendo siquiera?"


translate english e3424c_f6316dbb:


    "Y sin embargo, algo dentro de mi cabeza me dice que tengo que—"


translate english e3424c_ad904b97:



    voice "voice/e34/24c00050a01.opus"
    mx "\"—!!!\""



translate english e3424c_7fe1cf16:


    xy "\"Huh...?\""


translate english e3424c_94f7b73f:



    voice "voice/e34/24c00060a01.opus"
    mx "\"Shinichi—!!!\""


translate english e3424c_bcf42ed8:



    voice "voice/e34/24c00070a01.opus"
    mx "\"Haah, haah, haah...!\""


translate english e3424c_477f220c:


    "Jadeando por aire, Miyuki trepa por la escalera—"


translate english e3424c_9e02bee4:



    voice "voice/e34/24c00080a01.opus"
    mx "\"Shinichi!!!\""


translate english e3424c_1a2aaed9:


    xy "\"Whoa!!!\""


translate english e3424c_68f58cc8:


    "Se lanza a mis brazos tan rápido que casi me derriba al suelo."


translate english e3424c_65a0ba59:


    xy "\"Careful! Cool it, dummy!\""


translate english e3424c_4a5bde9c:



    voice "voice/e34/24c00090a01.opus"
    mx "\"Thank you...!\""


translate english e3424c_8115cae3:



    voice "voice/e34/24c00100a01.opus"
    mx "\"Thank you, thank you, thank you...!!!\""


translate english e3424c_5645c131:



    voice "voice/e34/24c00110a01.opus"
    mx "\"Thank you for staying!\""


translate english e3424c_4646204f:



    voice "voice/e34/24c00120a01.opus"
    mx "\"For staying here... in this world with me...\""


translate english e3424c_019133f9:



    voice "voice/e34/24c00130a01.opus"
    mx "\"Thank you... Thank you so much...!\""


translate english e3424c_ec1cb8f8:


    xy "\"Wh-Whoa there, hey now! Don't cry—Mmmph?!\""


translate english e3424c_3ec72823:



    voice "voice/e34/24c00140a01.opus"
    mx "\"Mmm—mmmph—mm—mmmm—!\""


translate english e3424c_0ec288c1:



    voice "voice/e34/24c00150a01.opus"
    mx "\"I love YOU—I really do—! Mmmm—mmph—mm—mmm—!\""


translate english e3424c_7001a9ae:



    voice "voice/e34/24c00160a01.opus"
    mx "\"I love YOU—so, so much—!\""


translate english e3424c_d0a932a6:



    voice "voice/e34/24c00170a01.opus"
    mx "\"So please—I'm begging YOU—don't leave me—!\""


translate english e3424c_7868a2d0:



    voice "voice/e34/24c00180a01.opus"
    mx "\"Stay with me—forever and ever—Mmmph!\""


translate english e3424c_965ff07a:


    "Me besa apasionadamente bajo el cielo estrellado."


translate english e3424c_c089af06:


    "Dura lo que parece una eternidad..."


translate english e3424c_d2c6bc70:


    "Una eternidad entre nosotros dos."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
