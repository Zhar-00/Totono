

translate english b5172_ab78d042:



    voice "voice/b51/7200010a01.opus"
    mx "\"Por cierto—\""


translate english b5172_a371551f:



    voice "voice/b51/7200020a01.opus"
    mx "\"¿Qué juego es este?\""


translate english b5172_56792165:


    xy "\"Oh, eh...\""


translate english b5172_f2019dfb:


    "Miyuki extiende la mano y recoge algo de mi escritorio."


translate english b5172_68d0f181:


    "Es el teléfono prestado que le pedí a Yuutarou."


translate english b5172_b5269d23:


    "La novela visual de antes sigue activa en la pantalla."


translate english b5172_4770c641:



    voice "voice/b51/7200030a01.opus"
    mx "\"Espera... ¿No se parece este personaje un poco a Aoi?\""


translate english b5172_98d363f1:



    voice "voice/b51/7200040a01.opus"
    mx "\"Y su diálogo—\""


translate english b5172_8eab7de1:


    xy "\"¡B-Basta! ¡Devuélvelo!\""


translate english b5172_81a648f3:



    voice "voice/b51/7200050a01.opus"
    mx "\"¿Por qué te asustaste tanto?\""


translate english b5172_ef0ba786:


    xy "\"¡No lo toques! ¡Es de una amiga mía!\""


translate english b5172_6cf07202:



    voice "voice/b51/7200060a01.opus"
    mx "\"Bueno, está bien. Si no quieres que lo toque, entonces te lo devuelvo.\""


translate english b5172_f0f72eb9:



    voice "voice/b51/7200070a01.opus"
    mx "\"¡Ups!\""


translate english b5172_d26228a1:



    voice "voice/b51/7200080a02.opus"
    aoi "\"¡Aaah!\""


translate english b5172_373f4e86:


    "Antes de que pueda devolverlo, se le resbala de la mano, se desliza por el suelo y desaparece bajo la cama."


translate english b5172_a26535c1:


    "Aoi deja escapar un chillido de sorpresa."


translate english b5172_a890a013:



    voice "voice/b51/7200090a01.opus"
    mx "\"Qué extraño. ¿Dijiste algo justo ahora?\""


translate english b5172_a3ed5804:


    xy "\"¿Eh? N-No, ¿por qué? ¿Quizá estás oyendo cosas?\""


translate english b5172_4e068fea:



    voice "voice/b51/7200100a01.opus"
    mx "\"¡Jajaja! Supongo que sí, ya que Aoi DEFINITIVAMENTE no está aquí.\""


translate english b5172_4b23dd81:


    "Con tono juguetón, Miyuki se agacha hasta el suelo para recuperar el teléfono."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
