

translate english a6121_db490de1:



    voice "voice/a61/2100010b01.opus"
    xtl "\"¡Buenos días, Shinichi!\""


translate english a6121_18129052:


    xy "\"¿Cómo está Aoi?\""


translate english a6121_dfb0c87d:



    voice "voice/a61/2100020b01.opus"
    xtl "\"Ay, por Dios... ¡Anoche fue una locura!\""


translate english a6121_a33fae90:



    voice "voice/a61/2100030b01.opus"
    xtl "\"Claramente no se sentía muy bien, así que intenté llevarla al hospital, ¡pero se negó por completo! ¡Dijo que era muy tarde!\""


translate english a6121_afd2f149:



    voice "voice/a61/2100040b01.opus"
    xtl "\"Entonces dijo que volvería al manga café, ¡pero mi viejo se opuso VEHEMENTEMENTE, como te imaginarás!\""



translate english a6121_016a071b:



    voice "voice/a61/2100050b01.opus"
    xtl "\"Así que terminó pasando la noche en nuestra casa.\""


translate english a6121_6e055e64:


    xy "\"¿Y luego qué pasó?\""


translate english a6121_a768ccb4:



    voice "voice/a61/2100060b01.opus"
    xtl "\"Bueno, esta mañana parecía totalmente bien.\""


translate english a6121_2c6d461d:


    xy "\"¿Qué? ¿En serio?\""


translate english a6121_8528747b:



    voice "voice/a61/2100070b01.opus"
    xtl "\"Sí. Creo que por ahora está a salvo.\""


translate english a6121_5c63dabd:



    voice "voice/a61/2100080b01.opus"
    xtl "\"Pero le dije que se quedara en casa a descansar hoy, por si acaso.\""


translate english a6121_d3798758:


    xy "\"¿E-En serio?\""


translate english a6121_ae62d4ed:



    voice "voice/a61/2100090b01.opus"
    xtl "\"¿Qué, crees que el capitán del Club de Chicos y Sueños te mentiría?\""


translate english a6121_ded0c2bf:


    xy "\"No, no... Claro que no. Muchas gracias, amigo. De verdad te debo una por esto.\""


translate english a6121_a9326be6:



    voice "voice/a61/2100100b01.opus"
    xtl "\"Mira, em, ¿Shinichi?\""


translate english a6121_eac18937:


    "Yuutarou se rasca la cabeza con incomodidad."


translate english a6121_f534ab01:



    voice "voice/a61/2100110b01.opus"
    xtl "\"¿Crees que Mukou y su familia...?\""


translate english a6121_76e75c57:


    xy "\"Sííí, al parecer no se llevan bien en este momento. Por eso duerme en el manga café casi todos los días.\""


translate english a6121_802f1f2f:


    xy "\"Aunque nunca habla realmente de eso más allá de eso.\""


translate english a6121_2ee75b1e:



    voice "voice/a61/2100120b01.opus"
    xtl "\"En ese caso, ¿quizá podríamos hacer que se quede con nosotros un tiempo?\""


translate english a6121_62a5b119:


    xy "\"¿Sí?\""


translate english a6121_bdffb4f1:



    voice "voice/a61/2100130b01.opus"
    xtl "\"Verás, mi papá decía que quería sacarla de las calles. Y es bien estricto con estas cosas, así que, ya sabes...\""


translate english a6121_eff017ed:


    "En general, Yuutarou parece bastante feliz con la idea."


translate english a6121_a3e03a53:


    "Personalmente, creo que preferiría que se quedara con ellos en vez de en el café de manga, pero..."


translate english a6121_4454fb12:


    xy "\"¿Seguro que es buena idea, tú y ella bajo el mismo techo?\""


translate english a6121_8f0ea3d3:



    voice "voice/a61/2100140b01.opus"
    xtl "\"¿Qu...? ¡Jajajaja! ¡Por favor! ¿Y eso qué se supone que significa?\""


translate english a6121_38fcf1c8:


    xy "\"Sabes a qué me refiero. Tú eres chico, ella es chica...\""


translate english a6121_535631b7:



    voice "voice/a61/2100150b01.opus"
    xtl "\"¡Hmph! ¡Me hiere, señor! ¡Mi corazón le pertenece solo a Sone-san!\""


translate english a6121_57892971:



    voice "voice/a61/2100160b01.opus"
    xtl "\"O sea, Mukou es... ya sabes... No es... Cómo decirlo... No la veo así. Si acaso, es como una hermanita.\""


translate english a6121_8aac5ed8:



    voice "voice/a61/2100170b01.opus"
    xtl "\"Ah, vivir con mi hermanita... De verdad, ¡sería el sueño hecho realidad de cualquier hombre...!\""


translate english a6121_0accd139:


    xy "\"\"......\"\""


translate english a6121_5b9ad220:


    "Bueno, mientras su papá esté ahí para supervisar, supongo que no hay de qué preocuparse."


translate english a6121_8961147a:


    "Solo me alegra que se sienta mejor."


translate english a6121_a5b76731:



    voice "voice/a31/8100190a01.opus"
    mx "\"\"......\"\""


translate english a6121_71ffe520:


    "Siento los ojos de alguien sobre mí y me doy la vuelta."


translate english a6121_ebe4e6ff:


    "Miyuki mira en silencio en mi dirección."



translate english a6121_c5de663d:



    voice "voice/a61/2100190b01.opus"
    xtl "\"Uah... ¿Qué demonios...?\""


translate english a6121_2f273e75:


    "Se acerca a zancadas sin siquiera saludar a nadie en su camino."


translate english a6121_1ebc6c99:



    voice "voice/a61/2100200b01.opus"
    xtl "\"¡¡¡S-Sone-san!!!\""


translate english a6121_464e5d95:



    voice "voice/a61/2100210b01.opus"
    xtl "\"¡Buenos dí...!\""


translate english a6121_71ad02aa:



    voice "voice/a61/2100220a01.opus"
    mx "\"Shinichi.\""


translate english a6121_0accd139_1:


    xy "\"\"......\"\""


translate english a6121_8ee95fe0:


    "Me entrega un sobre."


translate english a6121_b4ead7da:


    "Sus dedos tiemblan."


translate english a6121_2d07e03f:



    voice "voice/a61/2100230a01.opus"
    mx "\"Aquí tienes una entrada para la obra.\""


translate english a6121_35385fb7:



    voice "voice/a61/2100240a01.opus"
    mx "\"Te estaré esperando.\""


translate english a6121_0206cf56:



    voice "voice/a61/2100250a01.opus"
    mx "\"Por favor.\""


translate english a6121_cf60445d:


    "Deja el sobre sobre mi escritorio, luego gira con gracia sobre sus talones como si saliera por el ala izquierda del escenario..."


translate english a6121_31ae856a:


    "...y toda la clase es nuestro público."


translate english a6121_68222e36:


    "Susurros de desconcierto llenan el aire."


translate english a6121_15e624ae:



    voice "voice/a61/2100260b01.opus"
    xtl "\"¡Maldita sea!\""


translate english a6121_32c3b3d4:



    voice "voice/a61/2100270b01.opus"
    xtl "\"¡Siempre tuve mis sospechas, pero ahora veo la verdad! ¡Tú y Sone-san...!\""


translate english a6121_442ff36c:


    xy "\"Sí. Ayer me confesó su amor.\""


translate english a6121_5223f054:



    voice "voice/a61/2100280b01.opus"
    xtl "\"¿Qué? ¿En serio?\""


translate english a6121_c5d9b562:


    xy "\"Eso es todo lo que pasó.\""


translate english a6121_45d97258:



    voice "voice/a61/2100290b01.opus"
    xtl "\"¡¿Eso es todo?!\""


translate english a6121_6c1e156f:


    xy "\"No me interesa una relación con ella.\""


translate english a6121_f39cb009:



    voice "voice/a61/2100300b01.opus"
    xtl "\"¿Qu... qu... qu...?\""


translate english a6121_49515706:



    voice "voice/a61/2100310b01.opus"
    xtl "\"¡¿QUEEEEEEEEEEEE?!\""


translate english a6121_53ed5575:


    "Si tan solo pudiera decir que no me siento atraído por ella."


translate english a6121_365a6039:


    "Pero ni siquiera puedo mentir."


translate english a6121_4c5ac027:


    "Dios, desearía estar muerto."


translate english a6121_97271496:


    "...Pero, obviamente, tampoco me voy a morir."


translate english a6121_9f552b4f:


    "Mientras postergo mi decisión, el tiempo pasará..."


translate english a6121_3fdfedd0:


    "...hasta que, con el tiempo, Miyuki vuelva a desvanecerse de mi vida."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
