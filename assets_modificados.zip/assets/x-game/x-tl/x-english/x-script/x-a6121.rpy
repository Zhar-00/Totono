

translate english a6121_db490de1:



    voice "voice/a61/2100010b01.opus"
    xtl "\"Morning, Shinichi!\""


translate english a6121_18129052:


    xy "\"How's Aoi?\""


translate english a6121_dfb0c87d:



    voice "voice/a61/2100020b01.opus"
    xtl "\"Good grief... Last night was crazy!\""


translate english a6121_a33fae90:



    voice "voice/a61/2100030b01.opus"
    xtl "\"She clearly wasn't feeling too good, so I tried to take her to the hospital, but she totally refused! Said it was too late at night!\""


translate english a6121_afd2f149:



    voice "voice/a61/2100040b01.opus"
    xtl "\"So then she said she was going back to the manga cafe, but my old man was VEHEMENTLY OPPOSED, as you can imagine!\""



translate english a6121_016a071b:



    voice "voice/a61/2100050b01.opus"
    xtl "\"So she ended up spending the night at our house.\""


translate english a6121_6e055e64:


    xy "\"Then what happened?\""


translate english a6121_a768ccb4:



    voice "voice/a61/2100060b01.opus"
    xtl "\"Well, this morning she seemed totally fine.\""


translate english a6121_2c6d461d:


    xy "\"What? Really?\""


translate english a6121_8528747b:



    voice "voice/a61/2100070b01.opus"
    xtl "\"Yeah. I think she's in the clear for now.\""


translate english a6121_5c63dabd:



    voice "voice/a61/2100080b01.opus"
    xtl "\"But I told her to stay home and rest for today, just in case.\""


translate english a6121_d3798758:


    xy "\"Y-You did?\""


translate english a6121_ae62d4ed:



    voice "voice/a61/2100090b01.opus"
    xtl "\"What, you think the captain of the Boys and Dreams Club would lie to you?\""


translate english a6121_ded0c2bf:


    xy "\"No, no... Of course not. Thank you so much, dude. I really owe you for this.\""


translate english a6121_a9326be6:



    voice "voice/a61/2100100b01.opus"
    xtl "\"Look, uh, Shinichi?\""


translate english a6121_eac18937:


    "Yuutarou se rasca la cabeza con incomodidad."


translate english a6121_f534ab01:



    voice "voice/a61/2100110b01.opus"
    xtl "\"Do you think Mukou and her family...?\""


translate english a6121_76e75c57:


    xy "\"Yeahhh, they're not on good terms at the moment, apparently. That's why she sleeps at the manga cafe most days.\""


translate english a6121_802f1f2f:


    xy "\"She doesn't ever really talk about it beyond that, though.\""


translate english a6121_2ee75b1e:



    voice "voice/a61/2100120b01.opus"
    xtl "\"In that case, maybe we could have her stay with us for a while?\""


translate english a6121_62a5b119:


    xy "\"Yeah?\""


translate english a6121_bdffb4f1:



    voice "voice/a61/2100130b01.opus"
    xtl "\"See, my dad was saying he wanted to keep her off the streets. And he's a real hardass about this stuff, so, y'know...\""


translate english a6121_eff017ed:


    "En general, Yuutarou parece bastante feliz con la idea."


translate english a6121_a3e03a53:


    "Personalmente, creo que preferiría que se quedara con ellos en vez de en el café de manga, pero..."


translate english a6121_4454fb12:


    xy "\"You sure that's a good idea, you and her under the same roof?\""


translate english a6121_8f0ea3d3:



    voice "voice/a61/2100140b01.opus"
    xtl "\"Wha...? Hahahaha! Please! What's that supposed to mean?\""


translate english a6121_38fcf1c8:


    xy "\"You know what I mean. You're a guy, she's a girl—\""


translate english a6121_535631b7:



    voice "voice/a61/2100150b01.opus"
    xtl "\"Hmph! You wound me, sir! My heart belongs to Sone-san alone!\""


translate english a6121_57892971:



    voice "voice/a61/2100160b01.opus"
    xtl "\"I mean, Mukou's... you know... She's not... How do I put this... I don't see her that way. If anything, she's like a little sister!\""


translate english a6121_8aac5ed8:



    voice "voice/a61/2100170b01.opus"
    xtl "\"Ah, living together with my little sister... Truly, it would be any man's dream come true...!\""


translate english a6121_0accd139:


    xy "\"\"......\"\""


translate english a6121_5b9ad220:


    "Bueno, mientras su papá esté ahí para supervisar, supongo que no hay de qué preocuparse."


translate english a6121_8961147a:


    "Solo me alegra que se sienta mejor."


translate english a6121_a5b76731:



    voice "voice/a31/8100190a01.opus"
    mx "\"\"......\"\""


translate english a6121_71ffe520:


    "Siento los ojos de alguien sobre mí y me doy la vuelta."


translate english a6121_ebe4e6ff:


    "Miyuki mira en silencio en mi dirección."



translate english a6121_c5de663d:



    voice "voice/a61/2100190b01.opus"
    xtl "\"Whoa... What the...?\""


translate english a6121_2f273e75:


    "Se acerca a zancadas sin siquiera saludar a nadie en su camino."


translate english a6121_1ebc6c99:



    voice "voice/a61/2100200b01.opus"
    xtl "\"S-Sone-san!!!\""


translate english a6121_464e5d95:



    voice "voice/a61/2100210b01.opus"
    xtl "\"Good morni—!\""


translate english a6121_71ad02aa:



    voice "voice/a61/2100220a01.opus"
    mx "\"Shinichi.\""


translate english a6121_0accd139_1:


    xy "\"\"......\"\""


translate english a6121_8ee95fe0:


    "Me entrega un sobre."


translate english a6121_b4ead7da:


    "Sus dedos tiemblan."


translate english a6121_2d07e03f:



    voice "voice/a61/2100230a01.opus"
    mx "\"Here's a ticket to the play.\""


translate english a6121_35385fb7:



    voice "voice/a61/2100240a01.opus"
    mx "\"I'll be waiting.\""


translate english a6121_0206cf56:



    voice "voice/a61/2100250a01.opus"
    mx "\"Please.\""


translate english a6121_cf60445d:


    "Deja el sobre sobre mi escritorio, luego gira con gracia sobre sus talones como si saliera por el ala izquierda del escenario..."


translate english a6121_31ae856a:


    "...y toda la clase es nuestro público."


translate english a6121_68222e36:


    "Susurros de desconcierto llenan el aire."


translate english a6121_15e624ae:



    voice "voice/a61/2100260b01.opus"
    xtl "\"Goddamn it!\""


translate english a6121_32c3b3d4:



    voice "voice/a61/2100270b01.opus"
    xtl "\"I always had my suspicions, but now I see the truth! You and Sone-san—!\""


translate english a6121_442ff36c:


    xy "\"Yeah. She confessed her love to me yesterday.\""


translate english a6121_5223f054:



    voice "voice/a61/2100280b01.opus"
    xtl "\"What? Really?\""


translate english a6121_c5d9b562:


    xy "\"That's all that happened.\""


translate english a6121_45d97258:



    voice "voice/a61/2100290b01.opus"
    xtl "\"That's it?!\""


translate english a6121_6c1e156f:


    xy "\"I'm not interested in a relationship with her.\""


translate english a6121_f39cb009:



    voice "voice/a61/2100300b01.opus"
    xtl "\"Wh... wh... wh...\""


translate english a6121_49515706:



    voice "voice/a61/2100310b01.opus"
    xtl "\"WHAAAAAAAAAAAAAT?!\""


translate english a6121_53ed5575:


    "Si tan solo pudiera decir que no me siento atraído por ella."


translate english a6121_365a6039:


    "Pero ni siquiera puedo mentir."


translate english a6121_4c5ac027:


    "Dios, desearía estar muerto."


translate english a6121_97271496:


    "...Pero, obviamente, tampoco me voy a morir."


translate english a6121_9f552b4f:


    "Mientras postergo mi decisión, el tiempo pasará..."


translate english a6121_3fdfedd0:


    "...hasta que, con el tiempo, Miyuki vuelva a desvanecerse de mi vida."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
