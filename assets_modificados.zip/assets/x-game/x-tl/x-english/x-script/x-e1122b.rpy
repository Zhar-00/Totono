

translate english e1122b_1f4cd74c:


    xy "\"No, no puedo.\""


translate english e1122b_644fd62f:



    voice "voice/e11/22b00010a01.opus"
    mx "\"Vamoooos. No seas así.\""


translate english e1122b_e845429c:



    voice "voice/e11/22b00020a01.opus"
    mx "\"Nada bueno saldrá de rechazarme, ¿sabes? Deberías reconsiderarlo.\""


translate english e1122b_e567c13d:



    voice "voice/e11/22b00030a01.opus"
    mx "\"Ahora, ¿puedes profesarme tu amor?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
