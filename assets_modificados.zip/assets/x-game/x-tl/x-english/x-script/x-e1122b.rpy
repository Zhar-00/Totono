

translate english e1122b_1f4cd74c:


    xy "\"No, I can't.\""


translate english e1122b_644fd62f:



    voice "voice/e11/22b00010a01.opus"
    mx "\"Come onnn. Don't be like that.\""


translate english e1122b_e845429c:



    voice "voice/e11/22b00020a01.opus"
    mx "\"Nothing good will come of rejecting me, you know. You should reconsider.\""


translate english e1122b_e567c13d:



    voice "voice/e11/22b00030a01.opus"
    mx "\"Now, can you profess your love to me?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
