

translate english a6111_4bddc8cd:


    "La vida no es una autopista. La vida es una escalera."


translate english a6111_8d713614:


    "Solo tienes que seguir subiendo."


translate english a6111_d8f2be1f:


    "De lo contrario, si empiezas a pensarlo demasiado, te costará dar el siguiente paso."


translate english a6111_a13eecc0:


    "No hay caminos alternativos."


translate english a6111_69eeb23b:


    "No tiene sentido arrepentirse de las acciones que no tomaste."


translate english a6111_203c4466:


    "Dicen que la vida es una serie de elecciones, pero eso es una tontería inventada por los viejos amargados."


translate english a6111_a39bd66f:


    "El ayer lleva al hoy, y el hoy lleva al mañana."


translate english a6111_ea0bbe32:


    "Un paso a la vez."


translate english a6111_45837680:


    "¿Qué hay más adelante?"


translate english a6111_d4db3731:


    "No lo sabrás hasta que llegues."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
