

translate english d4232_a38c4ba9:


    xy "\"The whole time I was searching for you, I kept asking myself...\""


translate english d4232_abcf88fe:


    xy "\"Why was I so worried about you?\""


translate english d4232_e9e4774c:


    xy "\"Well, you know how Miyuki and I have basically grown up together?\""


translate english d4232_f4aa6966:


    xy "\"All that time, I kept stressing out over the small details.\""


translate english d4232_df1d0cf1:


    xy "\"I locked up all my emotions...\""


translate english d4232_68c455db:


    xy "\"...and lied to myself constantly.\""


translate english d4232_2647314a:



    voice "voice/d42/3200010a02.opus"
    aoi "\"Aoi wants to know.\""


translate english d4232_99462ae3:



    voice "voice/d42/3200020a02.opus"
    aoi "\"Tell me how you really feel.\""


translate english d4232_cdba5b3f:


    "Sus ojos nadan en emoción."


translate english d4232_9ff2c14c:


    "Siento el impulso de apartar la mirada."


translate english d4232_23dee630:


    "Pero no puedo avanzar a menos que se lo diga."


translate english d4232_2b82e767:


    xy "\"I... I'm in love with Miyuki.\""


translate english d4232_872892e8:


    xy "\"And I'm going to confess my feelings to her tonight.\""


translate english d4232_1d8b8cc7:


    xy "\"Honestly, I owe you big time. You helped me figure it all out.\""


translate english d4232_dc15330d:


    xy "\"Thank you so much. Seriously.\""


translate english d4232_76d7fc57:


    "Bajo la cabeza."


translate english d4232_16d1bf0b:


    "El silencio cae entre nosotros."


translate english d4232_98f86e60:


    "Por un rato, todo lo que puedo oír es la quietud de la noche."


translate english d4232_7ab71276:


    "Mientras tanto, espero la respuesta de Aoi..."


translate english d4232_38c169fd:



    voice "voice/d42/3200030a02.opus"
    aoi "\"Got it!\""


translate english d4232_bf9baf48:


    "Levanta la mano, con la voz temblorosa."


translate english d4232_04bba67f:



    voice "voice/d42/3200040a02.opus"
    aoi "\"Congratulations!\""


translate english d4232_4aa7ad9b:



    voice "voice/d42/3200050a02.opus"
    aoi "\"These... aren't sad tears, okay?\""


translate english d4232_6d45010c:



    voice "voice/d42/3200060a02.opus"
    aoi "\"They're happy tears.\""


translate english d4232_210eb4b9:



    voice "voice/d42/3200070a02.opus"
    aoi "\"Aoi's... really happy for you.\""


translate english d4232_4f93f5ff:


    "Y en efecto, gruesas lágrimas ruedan por sus mejillas."


translate english d4232_868baa14:


    "Una vez más, reprimo el impulso de desviar la mirada."


translate english d4232_968c2a93:



    voice "voice/d42/3200080a02.opus"
    aoi "\"Aoi understands how you feel.\""


translate english d4232_925afbe8:



    voice "voice/d42/3200090a02.opus"
    aoi "\"Now... Miyuki's waiting for you.\""


translate english d4232_d40653f3:



    voice "voice/d42/3200100a02.opus"
    aoi "\"Go on.\""


translate english d4232_dc128dde:



    voice "voice/d42/3200110a02.opus"
    aoi "\"Hurry!\""


translate english d4232_ad358d80:


    "Su voz es inusualmente ronca."


translate english d4232_5edc521a:


    "¿Qué le digo ahora siquiera?"


translate english d4232_347cb07b:



    voice "voice/d42/3200120a02.opus"
    aoi "\"Shinichi!\""


translate english d4232_f70185c7:


    xy "\"...R-Right.\""


translate english d4232_2673e142:


    "Me doy la vuelta y saco mi teléfono."


translate english d4232_9b489009:


    "Después de todo, Aoi ni siquiera respiraba hace unos minutos."


translate english d4232_e51a949c:


    "No puedo simplemente dejarla aquí arriba sola."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
