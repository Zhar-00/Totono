

translate english d4232_a38c4ba9:


    xy "\"Todo el tiempo que te estuve buscando, no dejé de preguntarme...\""


translate english d4232_abcf88fe:


    xy "\"¿Por qué estaba tan preocupado por ti?\""


translate english d4232_e9e4774c:


    xy "\"Bueno, ya sabes que Miyuki y yo básicamente crecimos juntos, ¿no?\""


translate english d4232_f4aa6966:


    xy "\"Todo ese tiempo, no dejé de agobiarme por los detalles pequeños.\""


translate english d4232_df1d0cf1:


    xy "\"Encerré todas mis emociones...\""


translate english d4232_68c455db:


    xy "\"...y me mentí a mí mismo constantemente.\""


translate english d4232_2647314a:



    voice "voice/d42/3200010a02.opus"
    aoi "\"Aoi quiere saber.\""


translate english d4232_99462ae3:



    voice "voice/d42/3200020a02.opus"
    aoi "\"Dime lo que sientes de verdad.\""


translate english d4232_cdba5b3f:


    "Sus ojos nadan en emoción."


translate english d4232_9ff2c14c:


    "Siento el impulso de apartar la mirada."


translate english d4232_23dee630:


    "Pero no puedo avanzar a menos que se lo diga."


translate english d4232_2b82e767:


    xy "\"Yo... estoy enamorado de Miyuki.\""


translate english d4232_872892e8:


    xy "\"Y voy a confesarle mis sentimientos esta noche.\""


translate english d4232_1d8b8cc7:


    xy "\"Honestamente, te debo una enorme. Me ayudaste a aclararlo todo.\""


translate english d4232_dc15330d:


    xy "\"Muchas gracias. En serio.\""


translate english d4232_76d7fc57:


    "Bajo la cabeza."


translate english d4232_16d1bf0b:


    "El silencio cae entre nosotros."


translate english d4232_98f86e60:


    "Por un rato, todo lo que puedo oír es la quietud de la noche."


translate english d4232_7ab71276:


    "Mientras tanto, espero la respuesta de Aoi..."


translate english d4232_38c169fd:



    voice "voice/d42/3200030a02.opus"
    aoi "\"¡Entendido!\""


translate english d4232_bf9baf48:


    "Levanta la mano, con la voz temblorosa."


translate english d4232_04bba67f:



    voice "voice/d42/3200040a02.opus"
    aoi "\"¡Felicidades!\""


translate english d4232_4aa7ad9b:



    voice "voice/d42/3200050a02.opus"
    aoi "\"Estas... no son lágrimas de tristeza, ¿eh?\""


translate english d4232_6d45010c:



    voice "voice/d42/3200060a02.opus"
    aoi "\"Son lágrimas de felicidad.\""


translate english d4232_210eb4b9:



    voice "voice/d42/3200070a02.opus"
    aoi "\"Aoi está... muy feliz por ti.\""


translate english d4232_4f93f5ff:


    "Y en efecto, gruesas lágrimas ruedan por sus mejillas."


translate english d4232_868baa14:


    "Una vez más, reprimo el impulso de desviar la mirada."


translate english d4232_968c2a93:



    voice "voice/d42/3200080a02.opus"
    aoi "\"Aoi entiende cómo te sientes.\""


translate english d4232_925afbe8:



    voice "voice/d42/3200090a02.opus"
    aoi "\"Ahora... Miyuki te está esperando.\""


translate english d4232_d40653f3:



    voice "voice/d42/3200100a02.opus"
    aoi "\"Ve.\""


translate english d4232_dc128dde:



    voice "voice/d42/3200110a02.opus"
    aoi "\"¡Apúrate!\""


translate english d4232_ad358d80:


    "Su voz es inusualmente ronca."


translate english d4232_5edc521a:


    "¿Qué le digo ahora siquiera?"


translate english d4232_347cb07b:



    voice "voice/d42/3200120a02.opus"
    aoi "\"¡Shinichi!\""


translate english d4232_f70185c7:


    xy "\"...E-Está bien.\""


translate english d4232_2673e142:


    "Me doy la vuelta y saco mi teléfono."


translate english d4232_9b489009:


    "Después de todo, Aoi ni siquiera respiraba hace unos minutos."


translate english d4232_e51a949c:


    "No puedo simplemente dejarla aquí arriba sola."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
