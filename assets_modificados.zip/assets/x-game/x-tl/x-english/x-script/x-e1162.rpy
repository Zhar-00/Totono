

translate english e1162_d79f712b:



    voice "voice/e11/6200010b01.opus"
    xtl "\"Está de vuelta en mi casa.\""


translate english e1162_46bc0fb0:


    xy "\"¿Qué?\""


translate english e1162_ceb435c0:



    voice "voice/e11/6200020b01.opus"
    xtl "\"¿Eh?\""


translate english e1162_3fd94ffa:



    voice "voice/e11/6200030b01.opus"
    xtl "\"¿Eso es raro?\""


translate english e1162_9267edd9:


    xy "\"¿A qué te refieres con que está... \"en tu casa\"?\""



translate english e1162_1525494e:


    xy "\"Es un personaje de videojuego, ¿no?\""


translate english e1162_97b90591:



    voice "voice/e11/6200040b01.opus"
    xtl "\"¿Personaje de videojuego? ¿De qué hablas?\""


translate english e1162_495851ef:


    xy "\"......¿Qué?\""


translate english e1162_4e71de72:


    "Parece que aquí está ocurriendo algún tipo de fallo de comunicación..."


translate english e1162_397bbef6:



    voice "voice/e11/6200050b01.opus"
    xtl "\"Está bien, lo que sea. Si quieres hablar con Mukou, solo ven conmigo.\""


translate english e1162_67ce4487:


    xy "\"E-Está bien...\""


translate english e1162_5f2d0fbc:



    voice "voice/e11/6200060b01.opus"
    xtl "\"¿Cómo está tu pierna? ¿Ya te sientes mejor?\""


translate english e1162_2fb65bfd:


    xy "\"...¿Mi pierna?\""


translate english e1162_7badaf6c:



    voice "voice/e11/6200070b01.opus"
    xtl "\"Estuviste en el hospital, ¿no?\""


translate english e1162_4071a8d2:


    xy "\"¿De qué hablas?\""


translate english e1162_6c6fce0c:



    voice "voice/e11/6200080b01.opus"
    xtl "\"¿Cómo que de qué hablo? Los profesores nos lo dijeron.\""


translate english e1162_dc6305f9:



    voice "voice/e11/6200090b01.opus"
    xtl "\"Y Sone-san dijo que fue a visitarte un montón de veces.\""


translate english e1162_d8f30276:


    xy "\"Ya... veo...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
