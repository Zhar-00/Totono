

translate english e1162_d79f712b:



    voice "voice/e11/6200010b01.opus"
    xtl "\"She's back at my place.\""


translate english e1162_46bc0fb0:


    xy "\"What?\""


translate english e1162_ceb435c0:



    voice "voice/e11/6200020b01.opus"
    xtl "\"Huh?\""


translate english e1162_3fd94ffa:



    voice "voice/e11/6200030b01.opus"
    xtl "\"Is that strange?\""


translate english e1162_9267edd9:


    xy "\"What do you mean, she's... 'at your place'?\""



translate english e1162_1525494e:


    xy "\"She's a video game character, isn't she?\""


translate english e1162_97b90591:



    voice "voice/e11/6200040b01.opus"
    xtl "\"Video game character? What are you talking about?\""


translate english e1162_495851ef:


    xy "\"......What?\""


translate english e1162_4e71de72:


    "Parece que aquí está ocurriendo algún tipo de fallo de comunicación..."


translate english e1162_397bbef6:



    voice "voice/e11/6200050b01.opus"
    xtl "\"Okay, whatever. If you wanna talk to Mukou, just come with me.\""


translate english e1162_67ce4487:


    xy "\"O-Okay...\""


translate english e1162_5f2d0fbc:



    voice "voice/e11/6200060b01.opus"
    xtl "\"How's your leg? Feeling better?\""


translate english e1162_2fb65bfd:


    xy "\"...My leg?\""


translate english e1162_7badaf6c:



    voice "voice/e11/6200070b01.opus"
    xtl "\"You were in the hospital, yeah?\""


translate english e1162_4071a8d2:


    xy "\"What are you talking about?\""


translate english e1162_6c6fce0c:



    voice "voice/e11/6200080b01.opus"
    xtl "\"What do you mean, what am I talking about? The teachers told us.\""


translate english e1162_dc6305f9:



    voice "voice/e11/6200090b01.opus"
    xtl "\"And Sone-san said she went to visit you a bunch of times.\""


translate english e1162_d8f30276:


    xy "\"I... see...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
