

translate english a0113w_c4a66fff:


    xy "\"Eh... ¿hola?\""


translate english a0113w_ef1fe97d:


    "¡Dios, marqué un número al azar y de verdad contestaron!"


translate english a0113w_91a866f5:


    xy "\"Eh... ¿hola?\""


translate english a0113w_0e4dc435:



    voice "voice/a01/13w00010a02.opus"
    bm "\"Shinichi...\""


translate english a0113w_cc0f1ece:



    voice "voice/a01/13w00020a02.opus"
    bm "\"Te deseamos lo mejor.\""


translate english a0113w_4553826f:


    xy "\"¿Qué?\""


translate english a0113w_6312aaa3:



    voice "voice/a01/13w00030a02.opus"
    bm "\"Adiós.\""


translate english a0113w_4e45c16a:


    "Con eso, la línea se corta."


translate english a0113w_d853d3ce:


    "¿Quién era esa?"


translate english a0113w_7bc5f66a:


    "¿Y cómo sabía mi nombre?"


translate english a0113w_7a9d2e73:


    "Es decir, ¡este teléfono ni siquiera es mío!"


translate english a0113w_f6bfa0f8:


    "¿Qué demonios...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
