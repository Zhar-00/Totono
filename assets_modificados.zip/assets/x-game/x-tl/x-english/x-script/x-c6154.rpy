

translate english c6154_e8e9e488:


    "Después de unos cuantos tonos, termino la llamada."


translate english c6154_4676f9a9:


    xy "\"She wasn't doing too well when I last saw her, so she's probably—Miyuki?\""


translate english c6154_3cac6646:



    voice "voice/c61/5400010a01.opus"
    mx "\"I knew it. They're together.\""


translate english c6154_33b44efc:


    "Miro y encuentro a Miyuki también con su teléfono."


translate english c6154_97f4a879:



    voice "voice/c61/5400020a01.opus"
    mx "\"Got it. Okay. I'll head there now.\""


translate english c6154_6a9e86b2:


    xy "\"Finished your call?\""


translate english c6154_6b9e5858:



    voice "voice/c61/5400030a01.opus"
    mx "\"Looks like Aoi didn't pick up, hmm?\""


translate english c6154_d990eaba:


    xy "\"She's probably just asleep.\""


translate english c6154_e2de76de:



    voice "voice/c61/5400040a01.opus"
    mx "\"What if she's out with someone?\""


translate english c6154_375b5a4e:



    voice "voice/c61/5400050a01.opus"
    mx "\"What if she flaked out on her date with you to go be with someone else?\""


translate english c6154_92b7a041:


    xy "\"...What are you talking about?\""


translate english c6154_ee76dcbc:



    voice "voice/c61/5400060a01.opus"
    mx "\"Come with me.\""


translate english c6154_fba218ae:


    "Sin decir otra palabra, Miyuki se dirige hacia la salida."


translate english c6154_4d0699e3:


    xy "\"Wait! What about the play?\""


translate english c6154_30f7e0e5:



    voice "voice/c61/5400070a01.opus"
    mx "\"I told you, I stepped down from the lead role.\""


translate english c6154_fadf75b6:


    xy "\"But you went to the trouble of getting me these tickets—\""


translate english c6154_b508df35:



    voice "voice/c61/5400080a01.opus"
    mx "\"I know you better than anyone.\""


translate english c6154_47a9d1fb:



    voice "voice/c61/5400090a01.opus"
    mx "\"I know how kind and brave you are... and most importantly...\""


translate english c6154_29bf2ce4:



    voice "voice/c61/5400100a01.opus"
    mx "\"I know your jealous side.\""


translate english c6154_357c4437:


    "Mi... lado celoso...?"


translate english c6154_8499bf2b:



    voice "voice/c61/5400110a01.opus"
    mx "\"You need to face reality.\""


translate english c6154_083e2e7a:



    voice "voice/c61/5400120a01.opus"
    mx "\"Now come with me.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
