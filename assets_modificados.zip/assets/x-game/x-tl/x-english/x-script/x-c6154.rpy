

translate english c6154_e8e9e488:


    "Después de unos cuantos tonos, termino la llamada."


translate english c6154_4676f9a9:


    xy "\"No estaba muy bien la última vez que la vi, así que probablemente—¿Miyuki?\""


translate english c6154_3cac6646:



    voice "voice/c61/5400010a01.opus"
    mx "\"Lo sabía. Están juntos.\""


translate english c6154_33b44efc:


    "Miro y encuentro a Miyuki también con su teléfono."


translate english c6154_97f4a879:



    voice "voice/c61/5400020a01.opus"
    mx "\"Entendido. Bien. Voy para allá ahora.\""


translate english c6154_6a9e86b2:


    xy "\"¿Terminaste tu llamada?\""


translate english c6154_6b9e5858:



    voice "voice/c61/5400030a01.opus"
    mx "\"Parece que Aoi no contestó, ¿hmm?\""


translate english c6154_d990eaba:


    xy "\"Probablemente solo está dormida.\""


translate english c6154_e2de76de:



    voice "voice/c61/5400040a01.opus"
    mx "\"¿Y si está afuera con alguien?\""


translate english c6154_375b5a4e:



    voice "voice/c61/5400050a01.opus"
    mx "\"¿Y si te canceló la cita para ir a estar con alguien más?\""


translate english c6154_92b7a041:


    xy "\"...¿De qué estás hablando?\""


translate english c6154_ee76dcbc:



    voice "voice/c61/5400060a01.opus"
    mx "\"Ven conmigo.\""


translate english c6154_fba218ae:


    "Sin decir otra palabra, Miyuki se dirige hacia la salida."


translate english c6154_4d0699e3:


    xy "\"¡Espera! ¿Y la obra?\""


translate english c6154_30f7e0e5:



    voice "voice/c61/5400070a01.opus"
    mx "\"Te dije que dejé el papel protagónico.\""


translate english c6154_fadf75b6:


    xy "\"Pero te tomaste la molestia de conseguirme estos boletos—\""


translate english c6154_b508df35:



    voice "voice/c61/5400080a01.opus"
    mx "\"Te conozco mejor que nadie.\""


translate english c6154_47a9d1fb:



    voice "voice/c61/5400090a01.opus"
    mx "\"Sé lo amable y valiente que eres... y lo más importante...\""


translate english c6154_29bf2ce4:



    voice "voice/c61/5400100a01.opus"
    mx "\"Conozco tu lado celoso.\""


translate english c6154_357c4437:


    "Mi... lado celoso...?"


translate english c6154_8499bf2b:



    voice "voice/c61/5400110a01.opus"
    mx "\"Necesitas enfrentar la realidad.\""


translate english c6154_083e2e7a:



    voice "voice/c61/5400120a01.opus"
    mx "\"Ahora ven conmigo.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
