

translate english e0114a_316996d9:


    xy "\"That sounds like fun...\""


translate english e0114a_012e10c1:


    "¿Tirar un smartphone desde el techo de la escuela?"


translate english e0114a_d8ae6275:


    "Normalmente Miyuki es una estudiante modelo total, así que es algo hilarante que siquiera lo sugiera..."


translate english e0114a_6496fd37:


    "Y nadie está mirando ahora, así que podríamos salirnos con la nuestra..."


translate english e0114a_854493f7:



    voice "voice/e01/14a00010a01.opus"
    mx "\"Just throw it into another dimension.\""


translate english e0114a_f4cbf917:


    xy "\"Okay!\""


translate english e0114a_6d548693:


    "Recojo el teléfono y tomo una respiración profunda."


translate english e0114a_bda44e0a:


    "Luego corro hacia la cerca de seguridad—"


translate english e0114a_3d157531:


    xy "\"HYAAAAAAAAAAHHHHH!!!\""


translate english e0114a_ced3f36d:


    "—y lo lanzo con todas mis fuerzas."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
