

translate english a3201_0accd139:


    xy "\"\"......\"\""


translate english a3201_218584d4:



    voice "voice/a32/0100010a02.opus"
    aoi "\"Boop boop?\""


translate english a3201_e94d9201:



    voice "voice/a32/0100020a02.opus"
    aoi "\"Shinichi, aren't you coming?\""


translate english a3201_40b22914:


    xy "\"Uhh... About that...\""


translate english a3201_7a9f336b:



    voice "voice/a32/0100030a01.opus"
    mx "\"It IS Akebono-kun's family store, after all.\""


translate english a3201_1675f747:



    voice "voice/a32/0100040a02.opus"
    aoi "\"Akebono Yuutarou?\""


translate english a3201_4d69c3dd:


    "Verás, los padres de Yuutarou tienen una tienda de conveniencia."


translate english a3201_b6bf0c3f:


    "Yuutarou suele terminar atendiendo la caja después de clases... Si llega a vernos a los tres entrando juntos a estas horas de la noche..."


translate english a3201_7e9b5049:


    "Bueno, digamos que las cosas no terminarán bien."


translate english a3201_db56d75e:


    xy "\"I'll go in by myself. You two wait here, okay?\""


translate english a3201_982b9271:



    voice "voice/a32/0100050a01.opus"
    mx "\"No way.\""


translate english a3201_185fa0f9:



    voice "voice/a32/0100060a02.opus"
    aoi "\"Boop boop...?\""


translate english a3201_ee92f359:



    voice "voice/a32/0100070a01.opus"
    mx "\"Sorry, but I'm about ready to cave over here.\""


translate english a3201_9307091a:


    "Tiene razón. Si dejo a estas dos solas juntas, Miyuki probablemente volverá a enloquecer con los gatos."


translate english a3201_5f409738:


    "Y para cuando volviera, probablemente estaría toda congestionada por sus alergias, y..."


translate english a3201_d4a6c1ef:


    "En realidad, eso suena algo tierno..."


translate english a3201_51a638d3:



    voice "voice/a32/0100090a02.opus"
    aoi "\"Got it!\""


translate english a3201_bbd17018:



    voice "voice/a32/0100100a02.opus"
    aoi "\"Aoi can do it.\""


translate english a3201_544e5968:


    xy "\"By yourself?\""


translate english a3201_0e5e50a8:



    voice "voice/a32/0100110a02.opus"
    aoi "\"By myself.\""


translate english a3201_a362c327:


    xy "\"...Do you remember which one to get?\""


translate english a3201_3966d731:



    voice "voice/a32/0100120a02.opus"
    aoi "\"Pasteurized milk.\""


translate english a3201_63fc9f81:



    voice "voice/a32/0100130a01.opus"
    mx "\"Be sure to get one that has it on the label, okay?\""


translate english a3201_5c287066:



    voice "voice/a32/0100140a02.opus"
    aoi "\"Got it!\""


translate english a3201_6d67c2fa:


    "Con eso, entra disparada a la tienda."


translate english a3201_0bb589e5:



    voice "voice/a32/0100150a01.opus"
    mx "\"I hope she manages to buy the right one.\""


translate english a3201_6d54a5b4:


    xy "\"I'm not too confident...\""


translate english a3201_b5c2e2b1:



    voice "voice/a32/0100160a01.opus"
    mx "\"She took the kitten in there.\""


translate english a3201_6032a319:


    xy "\"And she's still wearing that onesie.\""


translate english a3201_c7225368:



    voice "voice/a32/0100170a01.opus"
    mx "\"Maybe I should've handled it myself.\""


translate english a3201_38781d90:


    xy "\"But she said she wanted to do it, so...\""


translate english a3201_3cd39dfa:



    voice "voice/a32/0100180a01.opus"
    mx "\"\"......\"\""


translate english a3201_0accd139_1:


    xy "\"\"......\"\""


translate english a3201_1d30e780:


    "Un silencio incómodo se prolonga."


translate english a3201_ef044d8d:


    "¿Aoi nos dejó solos a propósito?"


translate english a3201_3666669e:


    "Tenue, puedo oír autos pasando a lo lejos."


translate english a3201_0262c5ee:


    "De alguna forma, el sonido de las llantas sobre el asfalto siempre es un poco distinto justo después de la lluvia."


translate english a3201_18d4b08e:


    "Otro cliente entra. Suena un timbre mientras las puertas automáticas se deslizan."


translate english a3201_d5e58266:


    xy "\"You know, I gotta admit...\""


translate english a3201_f1a43355:


    xy "\"Aoi might have adopted that cat purely on a whim, but...\""


translate english a3201_d77284d2:


    xy "\"I think she's just doing what she thinks is right.\""


translate english a3201_d1d3dab4:



    voice "voice/a32/0100190a01.opus"
    mx "\"It'll only end in suffering, you know.\""


translate english a3201_69d330f9:


    xy "\"Well, sure, maybe she can't tell reality from video games... And her lack of forethought is cause for concern...\""


translate english a3201_162e7503:


    xy "\"But honestly, I can't say I dislike that about her.\""


translate english a3201_190a15d9:


    xy "\"Sorry. Didn't meant to go off on that stupid tangent.\""


translate english a3201_cb545491:



    voice "voice/a32/0100200a01.opus"
    mx "\"...I don't think it was stupid.\""


translate english a3201_3da9a9cf:


    "Miyuki se queda callada, como pensativa."


translate english a3201_c57ddc2f:


    "Yo también me quedo callado."


translate english a3201_9b649a13:


    "El olor a lluvia persiste en el aire de la ciudad."


translate english a3201_1c43c22a:


    "Las estrellas titilan en el cielo despejado del oeste."


translate english a3201_94e4a22c:



    voice "voice/a32/0100210a01.opus"
    mx "\"Say, um...\""


translate english a3201_ae2c7513:



    voice "voice/a32/0100220a01.opus"
    mx "\"What about me?\""


translate english a3201_ddafd52f:



    voice "voice/a32/0100230a01.opus"
    mx "\"How would you feel if I were to... do what I think is best for myself?\""


translate english a3201_29cc6b1f:


    xy "\"What do you mean?\""


translate english a3201_472715b9:



    voice "voice/a32/0100240a01.opus"
    mx "\"...Well...\""


translate english a3201_007399e0:


    xy "\"Yeah...?\""


translate english a3201_d4d242a8:



    voice "voice/a32/0100250a01.opus"
    mx "\"If I were to... be honest with how I really feel—\""


translate english a3201_083793b7:



    voice "voice/a32/0100270a02.opus"
    aoi "\"Shhh!\""


translate english a3201_bb58c512:


    xy "\"Huh?\""


translate english a3201_86f82e2f:



    voice "voice/a32/0100280a01.opus"
    mx "\"Wha—?!\""


translate english a3201_7471e3e9:


    "Nos volteamos y encontramos a Aoi ahí de pie, con una bolsa de compras en la mano, espiándonos descaradamente."


translate english a3201_a6db720e:


    xy "\"G-Guess you managed to buy it, huh?\""


translate english a3201_602864ed:



    voice "voice/a32/0100290a02.opus"
    aoi "\"Sure did.\""


translate english a3201_a4cedf15:



    voice "voice/a32/0100300a01.opus"
    mx "\"G-Good for you! I'm proud of you!\""


translate english a3201_5189d026:



    voice "voice/a32/0100310a01.opus"
    mx "\"Now then, let's get going!\""


translate english a3201_1984ee9e:


    xy "\"R-Right!\""


translate english a3201_33bd79c1:


    "Miyuki se apresura como si estuviera ansiosa por salir de aquí."


translate english a3201_d27ae1ee:


    "La sigo apresuradamente."


translate english a3201_995486d6:



    voice "voice/a32/0100320a02.opus"
    aoi "\"Boop boop...\""


translate english a3201_e627d215:



    voice "voice/a32/0100330a02.opus"
    aoi "\"Does this mean Operation Alone Time was a disaster?\""


translate english a3201_f8c1f8f2:


    "Lo sabía... Ella planeó esto..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
