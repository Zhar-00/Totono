

translate english a3201_0accd139:


    xy "\"\"......\"\""


translate english a3201_218584d4:



    voice "voice/a32/0100010a02.opus"
    aoi "\"¿Boop boop?\""


translate english a3201_e94d9201:



    voice "voice/a32/0100020a02.opus"
    aoi "\"Shinichi, ¿no vienes?\""


translate english a3201_40b22914:


    xy "\"Ehh... Sobre eso...\""


translate english a3201_7a9f336b:



    voice "voice/a32/0100030a01.opus"
    mx "\"Después de todo, SÍ es la tienda de la familia de Akebono-kun.\""


translate english a3201_1675f747:



    voice "voice/a32/0100040a02.opus"
    aoi "\"¿Akebono Yuutarou?\""


translate english a3201_4d69c3dd:


    "Verás, los padres de Yuutarou tienen una tienda de conveniencia."


translate english a3201_b6bf0c3f:


    "Yuutarou suele terminar atendiendo la caja después de clases... Si llega a vernos a los tres entrando juntos a estas horas de la noche..."


translate english a3201_7e9b5049:


    "Bueno, digamos que las cosas no terminarán bien."


translate english a3201_db56d75e:


    xy "\"Entraré yo sola. Ustedes dos esperen aquí, ¿sí?\""


translate english a3201_982b9271:



    voice "voice/a32/0100050a01.opus"
    mx "\"Para nada.\""


translate english a3201_185fa0f9:



    voice "voice/a32/0100060a02.opus"
    aoi "\"¿Boop boop...?\""


translate english a3201_ee92f359:



    voice "voice/a32/0100070a01.opus"
    mx "\"Perdón, pero aquí ya casi me doy por vencida.\""


translate english a3201_9307091a:


    "Tiene razón. Si dejo a estas dos solas juntas, Miyuki probablemente volverá a enloquecer con los gatos."


translate english a3201_5f409738:


    "Y para cuando volviera, probablemente estaría toda congestionada por sus alergias, y..."


translate english a3201_d4a6c1ef:


    "En realidad, eso suena algo tierno..."


translate english a3201_51a638d3:



    voice "voice/a32/0100090a02.opus"
    aoi "\"¡Entendido!\""


translate english a3201_bbd17018:



    voice "voice/a32/0100100a02.opus"
    aoi "\"Aoi puede hacerlo.\""


translate english a3201_544e5968:


    xy "\"¿Tú sola?\""


translate english a3201_0e5e50a8:



    voice "voice/a32/0100110a02.opus"
    aoi "\"Yo sola.\""


translate english a3201_a362c327:


    xy "\"...¿Recuerdas cuál hay que comprar?\""


translate english a3201_3966d731:



    voice "voice/a32/0100120a02.opus"
    aoi "\"Leche pasteurizada.\""


translate english a3201_63fc9f81:



    voice "voice/a32/0100130a01.opus"
    mx "\"Asegúrate de agarrar una que lo diga en la etiqueta, ¿sí?\""


translate english a3201_5c287066:



    voice "voice/a32/0100140a02.opus"
    aoi "\"¡Entendido!\""


translate english a3201_6d67c2fa:


    "Con eso, entra disparada a la tienda."


translate english a3201_0bb589e5:



    voice "voice/a32/0100150a01.opus"
    mx "\"Espero que logre comprar la correcta.\""


translate english a3201_6d54a5b4:


    xy "\"No tengo mucha confianza...\""


translate english a3201_b5c2e2b1:



    voice "voice/a32/0100160a01.opus"
    mx "\"Se llevó al gatito allá dentro.\""


translate english a3201_6032a319:


    xy "\"Y todavía lleva puesto ese mameluco.\""


translate english a3201_c7225368:



    voice "voice/a32/0100170a01.opus"
    mx "\"Quizá debí encargarme yo.\""


translate english a3201_38781d90:


    xy "\"Pero dijo que quería hacerlo ella, así que...\""


translate english a3201_3cd39dfa:



    voice "voice/a32/0100180a01.opus"
    mx "\"\"......\"\""


translate english a3201_0accd139_1:


    xy "\"\"......\"\""


translate english a3201_1d30e780:


    "Un silencio incómodo se prolonga."


translate english a3201_ef044d8d:


    "¿Aoi nos dejó solos a propósito?"


translate english a3201_3666669e:


    "Tenue, puedo oír autos pasando a lo lejos."


translate english a3201_0262c5ee:


    "De alguna forma, el sonido de las llantas sobre el asfalto siempre es un poco distinto justo después de la lluvia."


translate english a3201_18d4b08e:


    "Otro cliente entra. Suena un timbre mientras las puertas automáticas se deslizan."


translate english a3201_d5e58266:


    xy "\"Sabes, tengo que admitir...\""


translate english a3201_f1a43355:


    xy "\"Puede que Aoi haya adoptado a ese gato por puro capricho, pero...\""


translate english a3201_d77284d2:


    xy "\"Creo que solo está haciendo lo que cree que es correcto.\""


translate english a3201_d1d3dab4:



    voice "voice/a32/0100190a01.opus"
    mx "\"Solo va a terminar en sufrimiento, ¿sabes?\""


translate english a3201_69d330f9:


    xy "\"Bueno, claro, quizá no distingue la realidad de los videojuegos... Y su falta de previsión es preocupante...\""


translate english a3201_162e7503:


    xy "\"Pero, sinceramente, no puedo decir que eso de ella no me guste.\""


translate english a3201_190a15d9:


    xy "\"Perdón. No quería irme por esa tangente tonta.\""


translate english a3201_cb545491:



    voice "voice/a32/0100200a01.opus"
    mx "\"...No creo que fuera tonta.\""


translate english a3201_3da9a9cf:


    "Miyuki se queda callada, como pensativa."


translate english a3201_c57ddc2f:


    "Yo también me quedo callado."


translate english a3201_9b649a13:


    "El olor a lluvia persiste en el aire de la ciudad."


translate english a3201_1c43c22a:


    "Las estrellas titilan en el cielo despejado del oeste."


translate english a3201_94e4a22c:



    voice "voice/a32/0100210a01.opus"
    mx "\"Oye, em...\""


translate english a3201_ae2c7513:



    voice "voice/a32/0100220a01.opus"
    mx "\"¿Y yo?\""


translate english a3201_ddafd52f:



    voice "voice/a32/0100230a01.opus"
    mx "\"¿Cómo te sentirías si yo... hiciera lo que creo que es mejor para mí?\""


translate english a3201_29cc6b1f:


    xy "\"¿A qué te refieres?\""


translate english a3201_472715b9:



    voice "voice/a32/0100240a01.opus"
    mx "\"...Bueno...\""


translate english a3201_007399e0:


    xy "\"¿Sí...?\""


translate english a3201_d4d242a8:



    voice "voice/a32/0100250a01.opus"
    mx "\"Si yo... fuera honesta con lo que de verdad siento...\""


translate english a3201_083793b7:



    voice "voice/a32/0100270a02.opus"
    aoi "\"¡Shhh!\""


translate english a3201_bb58c512:


    xy "\"¿Eh?\""


translate english a3201_86f82e2f:



    voice "voice/a32/0100280a01.opus"
    mx "\"¿Qu...?\""


translate english a3201_7471e3e9:


    "Nos volteamos y encontramos a Aoi ahí de pie, con una bolsa de compras en la mano, espiándonos descaradamente."


translate english a3201_a6db720e:


    xy "\"A-Así que lograste comprarla, ¿eh?\""


translate english a3201_602864ed:



    voice "voice/a32/0100290a02.opus"
    aoi "\"Eso hice.\""


translate english a3201_a4cedf15:



    voice "voice/a32/0100300a01.opus"
    mx "\"¡B-Bien por ti! ¡Estoy orgulloso de ti!\""


translate english a3201_5189d026:



    voice "voice/a32/0100310a01.opus"
    mx "\"¡Bueno, vamos!\""


translate english a3201_1984ee9e:


    xy "\"¡C-Cierto!\""


translate english a3201_33bd79c1:


    "Miyuki se apresura como si estuviera ansiosa por salir de aquí."


translate english a3201_d27ae1ee:


    "La sigo apresuradamente."


translate english a3201_995486d6:



    voice "voice/a32/0100320a02.opus"
    aoi "\"Boop boop...\""


translate english a3201_e627d215:



    voice "voice/a32/0100330a02.opus"
    aoi "\"¿Esto significa que la Operación Tiempo a Solas fue un desastre?\""


translate english a3201_f8c1f8f2:


    "Lo sabía... Ella planeó esto..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
