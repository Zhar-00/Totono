

translate english e1112c_b8cd450c:



    voice "voice/e11/12c00010a01.opus"
    mx "\"¿De verdad quieres elegir con tantas ganas?\""


translate english e1112c_17bd8286:



    voice "voice/e11/12c00020a01.opus"
    mx "\"Bueno, no te preocupes.\""


translate english e1112c_31ad7a58:



    voice "voice/e11/12c00030a01.opus"
    mx "\"Después de todo, parece que me entiendes de verdad.\""


translate english e1112c_9d383c4d:



    voice "voice/e11/12c00040a01.opus"
    mx "\"Te trataré bien.\""


translate english e1112c_952866e8:



    voice "voice/e11/12c00050a01.opus"
    mx "\"...Oye, Shinichi.\""


translate english e1112c_bfd21218:



    voice "voice/e11/12c00060a01.opus"
    mx "\"Lo que quieras, te lo daré. ¿Sí?\""


translate english e1112c_8e54ce07:



    voice "voice/e11/12c00070a01.opus"
    mx "\"Y ahora...\""



translate english e1112c_513c2bad:



    voice "voice/e11/12c00080a01.opus"
    mx "\"Cocinaré esta comida con todo mi amor, así que más vale que te limpies el plato.\""


translate english e1112c_82345dd4:


    "¿Es por eso que su sopa de miso es tan sabrosa...? ¿Porque la hizo con su amor...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
