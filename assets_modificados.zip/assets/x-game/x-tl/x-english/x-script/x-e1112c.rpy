

translate english e1112c_b8cd450c:



    voice "voice/e11/12c00010a01.opus"
    mx "\"Do you really want to choose that badly?\""


translate english e1112c_17bd8286:



    voice "voice/e11/12c00020a01.opus"
    mx "\"Well, don't you worry.\""


translate english e1112c_31ad7a58:



    voice "voice/e11/12c00030a01.opus"
    mx "\"You really seem to understand me, after all.\""


translate english e1112c_9d383c4d:



    voice "voice/e11/12c00040a01.opus"
    mx "\"I'll treat you right.\""


translate english e1112c_952866e8:



    voice "voice/e11/12c00050a01.opus"
    mx "\"...Hey, Shinichi?\""


translate english e1112c_bfd21218:



    voice "voice/e11/12c00060a01.opus"
    mx "\"Anything you want, I'll give it to you. Okay?\""


translate english e1112c_8e54ce07:



    voice "voice/e11/12c00070a01.opus"
    mx "\"Now then...\""



translate english e1112c_513c2bad:



    voice "voice/e11/12c00080a01.opus"
    mx "\"I cooked this meal with all my love, so you'd better clean your plate.\""


translate english e1112c_82345dd4:


    "¿Es por eso que su sopa de miso es tan sabrosa...? ¿Porque la hizo con su amor...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
