

translate english e2202a_d060050e:


    "Solo porque somos cercanos no significa que tenga derecho a hurgar en sus cosas."


translate english e2202a_20dd4af5:


    "Dejo su teléfono en la mesa y vuelvo a estudiar."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
