

translate english d7131_3c058af7:


    "El aire nocturno está quieto, pero mordazmente frío."


translate english d7131_2aafe5cf:


    "El cielo está despejado; las farolas proyectan la sombra de Aoi alargándose por el suelo."


translate english d7131_4b3a0716:


    "El mundo entero está en silencio salvo por nosotros—como si todo el ruido hubiera sido succionado hacia otra dimensión."


translate english d7131_205b9c9f:


    xy "\"Well, see ya.\""


translate english d7131_a9b6565e:


    "Esta es la parte donde cierro la puerta y echo el cerrojo."


translate english d7131_505dc747:


    "Pero justo cuando voy a cerrar la puerta—"


translate english d7131_9b07edbd:



    voice "voice/d71/3100010a02.opus"
    aoi "\"Got it.\""


translate english d7131_a8807850:


    "Aoi levanta la mano en el aire."


translate english d7131_f54da47b:


    "Su mirada está tan vacía como siempre."


translate english d7131_f666def4:


    "Tengo la sensación de que no me está mirando de verdad."


translate english d7131_59b34c3e:



    voice "voice/d71/3100020a02.opus"
    aoi "\"Shinichi.\""


translate english d7131_7247487d:



    voice "voice/d71/3100030a02.opus"
    aoi "\"Aoi's save files will disappear.\""


translate english d7131_41f32264:



    voice "voice/d71/3100040a02.opus"
    aoi "\"It'll all be lost.\""


translate english d7131_9373fcf0:



    voice "voice/d71/3100050a02.opus"
    aoi "\"But...\""


translate english d7131_78ec9d09:



    voice "voice/d71/3100060a02.opus"
    aoi "\"Aoi really enjoyed being your friend.\""


translate english d7131_669ca90d:



    voice "voice/d71/3100070a02.opus"
    aoi "\"And Aoi's glad to have been born into this world.\""


translate english d7131_37625cba:



    voice "voice/d71/3100080a02.opus"
    aoi "\"Even if everyone here forgets me...\""


translate english d7131_49d15608:



    voice "voice/d71/3100090a02.opus"
    aoi "\"YOU'LL remember, right?\""


translate english d7131_173a6c1d:


    "Sus palabras se sienten como una especie de maldición."


translate english d7131_33b45183:


    "No soy un personaje de un videojuego."


translate english d7131_e3e109bf:


    "No puedo simplemente reiniciar mis recuerdos y empezar de nuevo."


translate english d7131_afc509e6:


    "Pero antes de que mis crecientes emociones puedan tomar forma..."


translate english d7131_136c098e:


    "...cierro la puerta."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
