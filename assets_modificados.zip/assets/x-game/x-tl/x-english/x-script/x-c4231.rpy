

translate english c4231_276be0b2:


    "Y, en efecto, cuanto más hablamos, más parece recuperarse Aoi."


translate english c4231_fda35d4a:


    "Es casi como si de verdad estuviera recargando sus baterías."


translate english c4231_4f5a7902:


    xy "\"Hey, can I ask you something?\""


translate english c4231_1366632c:


    xy "\"Why did you ghost us like that?\""


translate english c4231_94523f01:



    voice "voice/c42/3100010a02.opus"
    aoi "\"......\""


translate english c4231_df1d2e16:


    "Conflictiva, Aoi mira al cielo."


translate english c4231_07dd65a2:


    "Las estrellas titilan en medio del mar de oscuridad."


translate english c4231_5ff9017c:


    "Y aquí estamos, en el centro del universo."


translate english c4231_999c1588:



    voice "voice/c42/3100020a02.opus"
    aoi "\"This world is a video game.\""



translate english c4231_e8b7d4a1:



    voice "voice/c42/3100030a02.opus"
    aoi "\"In this route, Aoi is a side character.\""


translate english c4231_2861d471:



    voice "voice/c42/3100040a02.opus"
    aoi "\"But... Aoi's glitched.\""


translate english c4231_d507aa35:



    voice "voice/c42/3100050a02.opus"
    aoi "\"There's a bug in the program.\""


translate english c4231_84a8705d:



    voice "voice/c42/3100060a02.opus"
    aoi "\"And it can't be patched unless my transmission goes through.\""


translate english c4231_0b4b83c8:



    voice "voice/c42/3100070a02.opus"
    aoi "\"So that's why Aoi disappeared.\""


translate english c4231_705fec0f:


    xy "\"With no explanation? No goodbye?\""


translate english c4231_63192d95:



    voice "voice/c42/3100080a02.opus"
    aoi "\"Once Aoi's gone, you're supposed to forget.\""


translate english c4231_22e2d1fe:



    voice "voice/c42/3100090a02.opus"
    aoi "\"That's the rule of this universe.\""


translate english c4231_e988c292:


    xy "\"Well, sorry, but I won't.\""


translate english c4231_2081146e:


    xy "\"Yuutarou and I searched the whole damn city for you.\""


translate english c4231_1db1e586:



    voice "voice/c42/3100100a02.opus"
    aoi "\"For me?\""


translate english c4231_ebfdf665:


    xy "\"There's something I really needed to get off my chest.\""


translate english c4231_59baea0f:


    "Todo ese tiempo que pasé corriendo por el pueblo, me preguntaba: ¿por qué la estoy buscando?"


translate english c4231_4462906f:


    "Y una vez que la encontré, ¿qué era lo que quería decir?"


translate english c4231_f1c66ac0:


    "Resulta que quería hablar de—"


translate english strings:


    old "Миюки"
    new "Miyuki"


    old "Сама Аой"
    new "Aoi misma"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
