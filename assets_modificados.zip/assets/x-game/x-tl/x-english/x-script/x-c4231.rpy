

translate english c4231_276be0b2:


    "Y, en efecto, cuanto más hablamos, más parece recuperarse Aoi."


translate english c4231_fda35d4a:


    "Es casi como si de verdad estuviera recargando sus baterías."


translate english c4231_4f5a7902:


    xy "\"Oye, ¿te puedo preguntar algo?\""


translate english c4231_1366632c:


    xy "\"¿Por qué nos desapareciste así?\""


translate english c4231_94523f01:



    voice "voice/c42/3100010a02.opus"
    aoi "\"......\""


translate english c4231_df1d2e16:


    "Conflictiva, Aoi mira al cielo."


translate english c4231_07dd65a2:


    "Las estrellas titilan en medio del mar de oscuridad."


translate english c4231_5ff9017c:


    "Y aquí estamos, en el centro del universo."


translate english c4231_999c1588:



    voice "voice/c42/3100020a02.opus"
    aoi "\"Este mundo es un videojuego.\""



translate english c4231_e8b7d4a1:



    voice "voice/c42/3100030a02.opus"
    aoi "\"En esta ruta, Aoi es un personaje secundario.\""


translate english c4231_2861d471:



    voice "voice/c42/3100040a02.opus"
    aoi "\"Pero... Aoi se bugueó.\""


translate english c4231_d507aa35:



    voice "voice/c42/3100050a02.opus"
    aoi "\"Hay un error en el programa.\""


translate english c4231_84a8705d:



    voice "voice/c42/3100060a02.opus"
    aoi "\"Y no se puede parchar a menos que mi transmisión llegue.\""


translate english c4231_0b4b83c8:



    voice "voice/c42/3100070a02.opus"
    aoi "\"Por eso Aoi desapareció.\""


translate english c4231_705fec0f:


    xy "\"¿Sin explicación? ¿Sin despedida?\""


translate english c4231_63192d95:



    voice "voice/c42/3100080a02.opus"
    aoi "\"Una vez que Aoi se va, se supone que debes olvidar.\""


translate english c4231_22e2d1fe:



    voice "voice/c42/3100090a02.opus"
    aoi "\"Esa es la regla de este universo.\""


translate english c4231_e988c292:


    xy "\"Bueno, lo siento, pero yo no lo haré.\""


translate english c4231_2081146e:


    xy "\"Yuutarou y yo buscamos por toda la maldita ciudad para encontrarte.\""


translate english c4231_1db1e586:



    voice "voice/c42/3100100a02.opus"
    aoi "\"¿Por mí?\""


translate english c4231_ebfdf665:


    xy "\"Hay algo que de verdad necesitaba sacar de mi pecho.\""


translate english c4231_59baea0f:


    "Todo ese tiempo que pasé corriendo por el pueblo, me preguntaba: ¿por qué la estoy buscando?"


translate english c4231_4462906f:


    "Y una vez que la encontré, ¿qué era lo que quería decir?"


translate english c4231_f1c66ac0:


    "Resulta que quería hablar de—"


translate english strings:


    old "Миюки"
    new "Miyuki"


    old "Сама Аой"
    new "Aoi misma"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
