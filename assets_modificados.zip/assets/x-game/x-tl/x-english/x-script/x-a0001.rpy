

translate english a0001_83fb0ea2:


    "La vida es como una escalera."


translate english a0001_8d713614:


    "Solo tienes que seguir subiendo."


translate english a0001_d8f2be1f:


    "De lo contrario, si empiezas a pensarlo demasiado, te costará dar el siguiente paso."


translate english a0001_a13eecc0:


    "No hay caminos alternativos."


translate english a0001_69eeb23b:


    "No tiene sentido arrepentirse de las acciones que no tomaste."


translate english a0001_203c4466:


    "Dicen que la vida es una serie de elecciones, pero eso es una tontería inventada por los viejos y amargados."


translate english a0001_a39bd66f:


    "El ayer conduce al hoy, y el hoy conduce al mañana."


translate english a0001_ea0bbe32:


    "Un paso a la vez."


translate english a0001_45837680:


    "¿Qué hay más adelante?"


translate english a0001_d4db3731:


    "No lo sabrás hasta que llegues."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
