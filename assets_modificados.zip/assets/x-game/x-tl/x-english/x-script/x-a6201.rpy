

translate english a6201_9c508c85:


    xy "\"Haah... haah... haah... haah...!\""


translate english a6201_1646c7d3:


    "Fuerzo a mis ahora pesadas piernas a llevarme hasta la escuela."


translate english a6201_41d82663:


    xy "\"Haah... haah... haah... nnguh!\""


translate english a6201_95b60af0:


    "Arrojando los zapatos, me apresuro hacia el viejo gimnasio donde se llevará a cabo la función."


translate english a6201_bb1c940d:


    xy "\"Haah... nng... Here... Ticket...\""


translate english a6201_1f01c057:


    "Estoy tan sin aliento que apenas puedo mantener una conversación con el de la taquilla."


translate english a6201_a9dec657:


    "Exhausto, entro tambaleándome al auditorio."


translate english a6201_1c66b88f:


    "La mayoría de los asientos ya están llenos."


translate english a6201_22abc015:


    "Solo faltan cinco minutos para que empiece la función."


translate english a6201_b1508e42:


    "La multitud zumba de emoción y curiosidad."


translate english a6201_b452e2e9:


    "Desesperado, registro la sala—"


translate english a6201_18dc83e2:


    xy "\"MIYUKI!\""


translate english a6201_495bcb29:



    voice "voice/a62/0100010a01.opus"
    mx "\"Shinichi...?\""


translate english a6201_731f6e95:


    "El gimnasio queda en absoluto silencio."


translate english a6201_ddc0801b:


    "De repente, todos los ojos están sobre mí."


translate english a6201_18a0c0ff:


    "Es como si estuviera otra vez en el escenario..."


translate english a6201_49e8a0c9:


    "Aunque, comparado con ella, soy solo un actor secundario."


translate english a6201_97796128:


    "Y estoy seguro de que se reirán de mis líneas."


translate english a6201_9b63bbe3:


    "Pero esto no es una actuación."


translate english a6201_b9ef0cba:



    voice "voice/a62/0100020a01.opus"
    mx "\"Wh-What's the matter?\""


translate english a6201_bae4e211:


    xy "\"I... I need to tell you something!\""


translate english a6201_051479dd:


    "Aún con la respiración entrecortada, fuerzo las palabras a todo volumen."


translate english a6201_962b90ab:


    xy "\"I LOVE YOU!\""


translate english a6201_40322c1c:



    voice "voice/a62/0100030a01.opus"
    mx "\"Huh...?\""


translate english a6201_c0255033:


    xy "\"It's the truth... All this time... I've never been able to admit it, but...\""


translate english a6201_496514d6:


    xy "\"I love you, Miyuki!\""


translate english a6201_b91e8484:



    voice "voice/a62/0100040a01.opus"
    mx "\"Oh... I... I see...\""


translate english a6201_7549b07a:


    "Parece que está conteniendo las lágrimas."


translate english a6201_e2979436:


    "Jadeo buscando aire."


translate english a6201_14d57031:



    voice "voice/a62/0100050a01.opus"
    mx "\"Th... Thank... you...\""


translate english a6201_f3fb519f:


    "Su expresión flaquea un poco."


translate english a6201_9d11a1f5:



    voice "voice/a62/0100060a01.opus"
    mx "\"I've... always hoped... you would... say that...\""


translate english a6201_74f60326:


    "Susurra con una vocecita que solo yo puedo oír."


translate english a6201_fa42117d:


    "Me acerco a ella—"


translate english a6201_88143995:


    "—y tomo su mano—"


translate english a6201_57527b69:



    voice "voice/a62/0100070b03.opus"
    c "\"Whoa, whoa, whoa! Hold it!\""


translate english a6201_b5fc0b4d:



    voice "voice/a62/0100080b03.opus"
    c "\"What are you doing?! The show's about to start!\""


translate english a6201_6ff3e941:


    xy "\"Oh, uh—\""


translate english a6201_1c6851bb:



    voice "voice/a62/0100090a01.opus"
    mx "\"Fan outreach!\""


translate english a6201_3e19b11a:


    "Así sin más, Miyuki vuelve a su personaje habitual."


translate english a6201_e7f82edb:



    voice "voice/a62/0100100a01.opus"
    mx "\"He says he's my biggest fan.\""


translate english a6201_9bccd459:



    voice "voice/a62/0100110b03.opus"
    c "\"Your fan...?\""


translate english a6201_f3e8ff87:



    voice "voice/a62/0100120a01.opus"
    mx "\"Yeah. He said he loves my acting and wants to support me.\""


translate english a6201_d3f8e7bf:



    voice "voice/a62/0100130b03.opus"
    c "\"...Is that true?\""


translate english a6201_a4079f04:



    voice "voice/a62/0100140a01.opus"
    mx "\"Of course. Isn't that right?\""


translate english a6201_c0c873b9:


    "Esto debe ser una excusa improvisada."


translate english a6201_1858ceb0:


    "De lo contrario, mis acciones solo causarán drama para Miyuki y el resto del club de teatro."


translate english a6201_856d0a4e:


    "Si no quiero arruinar esta función, mi única opción es seguirle la corriente."


translate english a6201_b3a03a9d:


    "Está escrito en toda la cara de Miyuki."


translate english a6201_cf62d1a2:



    voice "voice/a62/0100150a01.opus"
    mx "\"Let's talk after the show, okay?\""


translate english a6201_036e2589:



    voice "voice/a62/0100160a01.opus"
    mx "\"Let's go, Haru-chan.\""


translate english a6201_9f4d8eec:



    voice "voice/a62/0100170b03.opus"
    c "\"O-Okay...\""


translate english a6201_c6a59d50:


    "Miyuki se aleja."


translate english a6201_ae5439d0:


    "La función está a punto de empezar."


translate english a6201_281f0726:


    "As a would-be \"fan\", solo puedo verla irse."



translate english a6201_af33f701:


    "Sé que debería, y aun así—"


translate english a6201_8d8213d9:


    xy "\"WAIT!!!\""


translate english a6201_3d88033a:



    voice "voice/a62/0100180a01.opus"
    mx "\"\"......!\"\""


translate english a6201_1aa0ea5f:


    "Miyuki se detiene en seco, aún de espaldas."


translate english a6201_ab59ccbb:


    "Si subes a ese escenario—"


translate english a6201_fdb79716:


    "Si esta obra sigue ese guion—"


translate english a6201_24fbef81:



    voice "voice/a62/0100190a01.opus"
    mx "\"Wh... What is it?\""


translate english a6201_e531dc9a:


    "Su personaje se está resquebrajando."


translate english a6201_57b4cb3f:


    "Tenía un solo objetivo al venir aquí."


translate english a6201_d1b61f17:


    "Mi objetivo era decirle lo que sentía."


translate english a6201_64f07ce4:


    "Honestamente, debería haber planeado lo que pasaría después..."


translate english a6201_fefcf006:


    "Pero no lo hice."


translate english a6201_8c107808:



    voice "voice/a62/0100200a01.opus"
    mx "\"Shinichi...?\""


translate english a6201_ae8437fc:


    "Puedo ver la mirada suplicante en sus ojos."


translate english a6201_1cba78ff:


    "Rogándome que me la lleve—"


translate english a6201_ef94310b:


    "Pero es demasiado tarde."


translate english a6201_f57da32a:


    xy "\"Break a leg up there.\""


translate english a6201_a50a1403:



    voice "voice/a62/0100210a01.opus"
    mx "\"......!\""


translate english a6201_a19beda2:


    "Miyuki desaparece tras bambalinas sin decir otra palabra."


translate english a6201_664d5b5c:


    "Débilmente, me derrumbo en una silla vacía."


translate english a6201_33d3478c:


    "Estoy demasiado agotado para moverme."


translate english a6201_eaa39fe6:


    "Llegué demasiado tarde."


translate english a6201_499590bc:


    "Demasiado tarde para cambiar algo."


translate english a6201_97ef083f:


    "Estoy totalmente indefenso."


translate english a6201_55b9c699:


    "¿Estoy tomando la decisión de mantenerme firme aquí?"


translate english a6201_22dde288:


    "No."


translate english a6201_3f05d4e8:


    "Simplemente soy incapaz de moverme."


translate english a6201_ddcef977:


    "Y ahora..."


translate english a6201_ddad3f6f:


    "Ahora ella va a besar a otro chico."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
