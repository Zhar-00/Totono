

translate english c6162_27d127fc:



    voice "voice/c61/6200010a01.opus"
    mx "\"Él es el problema.\""


translate english c6162_db19b371:


    "...No lo entiendo."


translate english c6162_dbfae5b4:


    "¿Qué tiene de malo que Aoi pase el rato con Haru-chan?"


translate english c6162_3a1c551f:


    "Espera..."


translate english c6162_35e8c559:


    xy "\"¿Acabas de decir 'él'?\""



translate english c6162_445f4fee:


    "Justo entonces, las puertas automáticas se deslizan abriéndose."


translate english c6162_d5900cbf:



    voice "voice/c61/6200020b01.opus"
    xtl "\"¡Shinichi!\""


translate english c6162_c5e9a931:



    voice "voice/c61/6200030b01.opus"
    xtl "\"¡¡¡Lo siento mucho, amigo!!!\""


translate english c6162_2abc6a8c:


    "Yuutarou sale corriendo y cae de rodillas."


translate english c6162_b3eca164:


    xy "\"Whoa, ¿qué pasa?\""


translate english c6162_6130957e:



    voice "voice/c61/6200040b01.opus"
    xtl "\"¡Nunca pensé que Ryuujirou fuera ese tipo de persona...!\""


translate english c6162_28ab2945:



    voice "voice/c61/6200050b01.opus"
    xtl "\"¡Yo solo... no tengo excusa!\""


translate english c6162_1fc9f68a:


    xy "\"¿Qué pasa con tu hermano? No lo entiendo...\""


translate english c6162_0a21da5a:



    voice "voice/c61/6200060a01.opus"
    mx "\"Siempre tuve mis sospechas, pero esto lo confirma.\""


translate english c6162_7d202843:


    "Miyuki se gira hacia mí."


translate english c6162_0df0c50a:



    voice "voice/c61/6200070a01.opus"
    mx "\"Ryuujirou ES Haru-chan.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
