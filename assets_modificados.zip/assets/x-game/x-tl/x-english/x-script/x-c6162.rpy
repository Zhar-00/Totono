

translate english c6162_27d127fc:



    voice "voice/c61/6200010a01.opus"
    mx "\"He's the problem.\""


translate english c6162_db19b371:


    "...No lo entiendo."


translate english c6162_dbfae5b4:


    "¿Qué tiene de malo que Aoi pase el rato con Haru-chan?"


translate english c6162_3a1c551f:


    "Espera..."


translate english c6162_35e8c559:


    xy "\"Did you just say 'he'?\""



translate english c6162_445f4fee:


    "Justo entonces, las puertas automáticas se deslizan abriéndose."


translate english c6162_d5900cbf:



    voice "voice/c61/6200020b01.opus"
    xtl "\"Shinichi!\""


translate english c6162_c5e9a931:



    voice "voice/c61/6200030b01.opus"
    xtl "\"I'm so sorry, dude!!!\""


translate english c6162_2abc6a8c:


    "Yuutarou sale corriendo y cae de rodillas."


translate english c6162_b3eca164:


    xy "\"Whoa, what's going on?\""


translate english c6162_6130957e:



    voice "voice/c61/6200040b01.opus"
    xtl "\"I never thought Ryuujirou was that kind of guy...!\""


translate english c6162_28ab2945:



    voice "voice/c61/6200050b01.opus"
    xtl "\"I just... I have no excuse!!!\""


translate english c6162_1fc9f68a:


    xy "\"What's going on with your brother? I don't get it...\""


translate english c6162_0a21da5a:



    voice "voice/c61/6200060a01.opus"
    mx "\"I always had my suspicions, but this just confirms it.\""


translate english c6162_7d202843:


    "Miyuki se gira hacia mí."


translate english c6162_0df0c50a:



    voice "voice/c61/6200070a01.opus"
    mx "\"Ryuujirou IS Haru-chan.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
