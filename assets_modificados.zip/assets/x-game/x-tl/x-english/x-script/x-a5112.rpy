

translate english a5112_bb6697ff:


    xy "\"Morning.\""


translate english a5112_21498629:



    voice "voice/a51/1200010b01.opus"
    xtl "\"SHINICHI! GOOD MORNING!!!\""


translate english a5112_f0577fb2:


    xy "\"Stop shouting!\""


translate english a5112_4672cf7a:



    voice "voice/a51/1200020b01.opus"
    xtl "\"Hah hah! What's this? Are you curious what's got me so worked up?\""


translate english a5112_f4f44435:


    xy "\"Not in the least.\""


translate english a5112_2b9f560a:



    voice "voice/a51/1200030b01.opus"
    xtl "\"Well, you see—\""


translate english a5112_ab701318:


    xy "\"Don't ignore me!\""


translate english a5112_8d46ff88:



    voice "voice/a51/1200040b01.opus"
    xtl "\"It turns out! My brother Ryuujirou! Has a crush on someone!!!\""


translate english a5112_68cd4b3a:


    xy "\"Really?\""


translate english a5112_9ac76c30:



    voice "voice/a51/1200050b01.opus"
    xtl "\"Really really! I just got an email from the man himself!\""


translate english a5112_de384297:


    xy "\"Well, that's good. Now he can have a more healthy romantic outlet.\""


translate english a5112_f6264b1e:



    voice "voice/a51/1200060b01.opus"
    xtl "\"Yeah...\""


translate english a5112_320df4fe:



    voice "voice/a51/1200070b01.opus"
    xtl "\"You're right...\""


translate english a5112_a015f02a:


    xy "\"What? Aren't you happy for him?\""


translate english a5112_d07d85ed:



    voice "voice/a51/1200080b01.opus"
    xtl "\"It's just... now that it's gone... it's surprising how much it hurts...\""


translate english a5112_a0a70fa4:



    voice "voice/a51/1200090b01.opus"
    xtl "\"My sad, phantom romance...\""


translate english a5112_99145ff2:


    xy "\"He was your brother!\""


translate english a5112_a5b763b5:



    voice "voice/a51/1200100b01.opus"
    xtl "\"But think about it, Shinichi! He was cute, and he confessed to me! Does that sort of thing happen every day?! It doesn't! It really doesn't!\""


translate english a5112_0a517a9a:



    voice "voice/a51/1200110b01.opus"
    xtl "\"So, I need some advice!\""



translate english a5112_16f430c0:



    voice "voice/a51/1200120b01.opus"
    xtl "\"Shinichi, you've gotten pretty friendly with Mukou, yeah? Pretty close, you might say?\""


translate english a5112_62aeb137:



    voice "voice/a51/1200130b01.opus"
    xtl "\"And Mukou is pretty friendly with Sone-san— There! You see that?\""


translate english a5112_9bff0447:


    xy "\"See what?\""


translate english a5112_9572e2b2:



    voice "voice/a51/1200140b01.opus"
    xtl "\"The path to Sone-san's heart!\""


translate english a5112_64332899:


    xy "\"Do Not Enter.\""


translate english a5112_c6da683d:



    voice "voice/a51/1200150b01.opus"
    xtl "\"Please, Shinichi! I'm begging you! Pleeease help me get to know Sone-san! PLEASE!\""


translate english a5112_d43125ed:


    xy "\"No can do.\""


translate english a5112_d54a5101:



    voice "voice/a51/1200160b01.opus"
    xtl "\"Lend me your strength, God of Dreams!\""


translate english a5112_a47a96b6:


    xy "\"Find a different god.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
