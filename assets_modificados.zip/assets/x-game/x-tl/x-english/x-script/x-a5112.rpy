

translate english a5112_bb6697ff:


    xy "\"Buenos días.\""


translate english a5112_21498629:



    voice "voice/a51/1200010b01.opus"
    xtl "\"¡¡¡SHINICHI! BUENOS DÍAS!!!\""


translate english a5112_f0577fb2:


    xy "\"¡Deja de gritar!\""


translate english a5112_4672cf7a:



    voice "voice/a51/1200020b01.opus"
    xtl "\"¡Jaja! ¿Qué es esto? ¿Tienes curiosidad por saber qué me tiene tan emocionado?\""


translate english a5112_f4f44435:


    xy "\"En lo más mínimo.\""


translate english a5112_2b9f560a:



    voice "voice/a51/1200030b01.opus"
    xtl "\"Bueno, verás...\""


translate english a5112_ab701318:


    xy "\"¡No me ignores!\""


translate english a5112_8d46ff88:



    voice "voice/a51/1200040b01.opus"
    xtl "\"¡Resulta que! ¡Mi hermano Ryuujirou! ¡Le gusta alguien!\""


translate english a5112_68cd4b3a:


    xy "\"¿En serio?\""


translate english a5112_9ac76c30:



    voice "voice/a51/1200050b01.opus"
    xtl "\"¡En serio, en serio! ¡Acabo de recibir un correo del propio sujeto!\""


translate english a5112_de384297:


    xy "\"Bueno, eso está bien. Ahora puede tener una salida romántica más sana.\""


translate english a5112_f6264b1e:



    voice "voice/a51/1200060b01.opus"
    xtl "\"Sí...\""


translate english a5112_320df4fe:



    voice "voice/a51/1200070b01.opus"
    xtl "\"Tienes razón...\""


translate english a5112_a015f02a:


    xy "\"¿Qué? ¿No te alegras por él?\""


translate english a5112_d07d85ed:



    voice "voice/a51/1200080b01.opus"
    xtl "\"Es solo que... ahora que se acabó... sorprende cuánto duele...\""


translate english a5112_a0a70fa4:



    voice "voice/a51/1200090b01.opus"
    xtl "\"Mi triste romance fantasma...\""


translate english a5112_99145ff2:


    xy "\"¡Era tu hermano!\""


translate english a5112_a5b763b5:



    voice "voice/a51/1200100b01.opus"
    xtl "\"¡Pero piénsalo, Shinichi! ¡Era lindo y me confesó su amor! ¿¡Ese tipo de cosas pasan todos los días!? ¡No! ¡De verdad que no!\""


translate english a5112_0a517a9a:



    voice "voice/a51/1200110b01.opus"
    xtl "\"¡Así que necesito un consejo!\""



translate english a5112_16f430c0:



    voice "voice/a51/1200120b01.opus"
    xtl "\"Shinichi, te has vuelto bastante amigable con Mukou, ¿eh? Bastante cercano, podría decirse, ¿no?\""


translate english a5112_62aeb137:



    voice "voice/a51/1200130b01.opus"
    xtl "\"Y Mukou es bastante amigable con Sone-san... ¡Ahí! ¿Ves eso?\""


translate english a5112_9bff0447:


    xy "\"¿Ver qué?\""


translate english a5112_9572e2b2:



    voice "voice/a51/1200140b01.opus"
    xtl "\"¡El camino al corazón de Sone-san!\""


translate english a5112_64332899:


    xy "\"Prohibido el paso.\""


translate english a5112_c6da683d:



    voice "voice/a51/1200150b01.opus"
    xtl "\"¡Por favor, Shinichi! ¡Te lo ruego! ¡Porfaaa ayúdame a conocer a Sone-san! ¡POR FAVOR!\""


translate english a5112_d43125ed:


    xy "\"No se puede.\""


translate english a5112_d54a5101:



    voice "voice/a51/1200160b01.opus"
    xtl "\"¡Préstame tu fuerza, Dios de los Sueños!\""


translate english a5112_a47a96b6:


    xy "\"Busca a otro dios.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
