

translate english d6113_6911e186:


    xy "\"Sorry, buddy. The show's starting soon. I gotta go.\""


translate english d6113_98012ff8:


    "Me abro paso a la fuerza más allá de él y abro la puerta."


translate english d6113_9d1cbb6d:


    xy "\"Hey! Get your butt back in there!\""


translate english d6113_e51edf22:


    xy "\"Aoi's not feeling good. I need you to stay here and look after her, okay?\""


translate english d6113_0028e2bb:


    "Lo recojo, lo lanzo de vuelta dentro de la casa y cierro la puerta con firmeza."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
