

translate english d6113_6911e186:


    xy "\"Perdón, amigo. La función empieza pronto. Me tengo que ir.\""


translate english d6113_98012ff8:


    "Me abro paso a la fuerza más allá de él y abro la puerta."


translate english d6113_9d1cbb6d:


    xy "\"¡Hey! ¡Regresa ahí dentro!\""


translate english d6113_e51edf22:


    xy "\"Aoi no se siente bien. Necesito que te quedes aquí y la cuides, ¿sí?\""


translate english d6113_0028e2bb:


    "Lo recojo, lo lanzo de vuelta dentro de la casa y cierro la puerta con firmeza."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
