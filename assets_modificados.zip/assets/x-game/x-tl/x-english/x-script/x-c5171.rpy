

translate english c5171_6e48dd07:


    "Hoy estamos en una librería en medio del distrito comercial."


translate english c5171_b7e404a8:


    "Hojeo casualmente un manga mientras espero a que Aoi termine sus compras."


translate english c5171_92d6c999:


    "Empezamos explorando la tienda juntos, pero luego apareció un montón de gente con nuestro uniforme escolar."


translate english c5171_1541035e:


    "Sigo siendo el don nadie de la clase."


translate english c5171_0870723c:


    "Últimamente he recibido suficiente atención para toda una vida... y si es posible, me gustaría evitar cualquier drama futuro."


translate english c5171_f6e346f6:



    voice "voice/c51/7100010a02.opus"
    aoi "\"Gracias por esperar.\""


translate english c5171_bff19d12:


    "Aoi sale de la tienda con los ojos brillantes."


translate english c5171_5eaaacea:


    xy "\"¿Qué compraste?\""


translate english c5171_7c146ba2:



    voice "voice/c51/7100020a02.opus"
    aoi "\"Un libro.\""


translate english c5171_90561617:


    xy "\"Sí, eso lo podía adivinar.\""


translate english c5171_64db046c:



    voice "voice/c51/7100030a02.opus"
    aoi "\"Un libro sobre gatos.\""


translate english c5171_d1d64dcc:


    xy "\"Ah, ya veo.\""


translate english c5171_46206053:


    "Definitivamente es una buena idea aprender más sobre ellos ahora que adoptó a Eru y todo eso."


translate english c5171_b46b24f2:


    "Dicho esto, puedo decir por el tamaño de la bolsa que lleva que definitivamente compró al menos otros dos libros..."


translate english c5171_5b985f5f:


    xy "\"¿Qué más compraste?\""


translate english c5171_3498246f:



    voice "voice/c51/7100040a02.opus"
    aoi "\"Es... un secreto.\""


translate english c5171_97383491:


    xy "\"¿No me lo puedes decir?\""


translate english c5171_7b69cc89:



    voice "voice/c51/7100050a02.opus"
    aoi "\"Nop.\""


translate english c5171_b4c13556:


    xy "\"...¿Por qué no?\""


translate english c5171_fc41bebe:



    voice "voice/c51/7100060a02.opus"
    aoi "\"Porque es un secreto.\""


translate english c5171_25de250a:


    "Su voz suena extrañamente firme."


translate english c5171_d467d9bf:


    "...Ahora tengo curiosidad."


translate english c5171_d9337d09:


    "Pero supongo que no puedo obligarla a decirme..."


translate english c5171_775771e4:


    xy "\"Bueno, ¡vámonos a casa!\""


translate english c5171_d937a582:



    voice "voice/c51/7100070a02.opus"
    aoi "\"¡Bien!\""


translate english c5171_de0e214a:


    "Guío a Aoi de vuelta por el distrito comercial."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
