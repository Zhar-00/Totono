

translate english a5132_08a510ef:


    xy "\"Oh...\""


translate english a5132_c9f3dd33:


    "El pupitre de Aoi está vacío."


translate english a5132_c4bc2c08:


    "¿Sigue sintiéndose mal por lo de ayer?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
