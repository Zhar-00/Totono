

translate english e2173_499d4e06:


    xy "\"Y bien, ¿qué compraste?\""


translate english e2173_a192dca3:



    voice "voice/e21/7300010a01.opus"
    mx "\"¿Yo? Oh, nada especial...\""


translate english e2173_72e2102e:


    "ella se retira \"Magic Tricks 101.\""



translate english e2173_7db31ebc:


    "ella se retira \"The Witch's Guide to Black Magic.\""



translate english e2173_78c8a567:


    "ella se retira \"The World Heritage Photobook.\""



translate english e2173_d7874bc8:



    voice "voice/e21/7300020a01.opus"
    mx "\"¡Solo otro para la colección! Jaja...\""


translate english e2173_12e64a21:


    xy "\"......\""


translate english e2173_657aba9a:


    "Parece un poco raro, pero está bien..."


translate english e2173_a012bb38:


    "No tenía idea de que le gustara ese tipo de cosas."


translate english e2173_a562213e:


    "Casi se siente como si me estuviera ocultando algo..."


translate english e2173_902ea85f:


    "Dicho esto, puedo decir por el tamaño de la bolsa que lleva que definitivamente compró al menos otro libro..."


translate english e2173_668a8f0e:


    xy "\"¿Y ese de ahí?\""


translate english e2173_c031da49:



    voice "voice/e21/7300030a01.opus"
    mx "\"Ah, cierto. ¿Esto?\""


translate english e2173_fa09a39e:



    voice "voice/e21/7300040a01.opus"
    mx "\"Programación para Dummies.\""



translate english e2173_064744c1:


    xy "\"¿Haciendo un videojuego o algo así?\""


translate english e2173_5bf5ea5f:



    voice "voice/e21/7300050a01.opus"
    mx "\"¡Sí, algo así!\""


translate english e2173_72a384b2:


    xy "\"Y, ¿qué es eso de en medio?\""


translate english e2173_bcdf4d07:



    voice "voice/e21/7300060a01.opus"
    mx "\"¡Nada!\""


translate english e2173_12de2809:



    voice "voice/e21/7300070a01.opus"
    mx "\"¡No hay nada escondido ahí!\""


translate english e2173_15c2d24d:


    "Hmm... ¿Qué tipo de libro querría ocultar de la dependienta?"


translate english e2173_f27c3a92:


    xy "\"Ah, eso me recuerda. Mencionaste algo en clase el otro día...\""


translate english e2173_f824476a:


    xy "\"Algo sobre el número de este mes de una revista con una colección de fotos sexys—\""


translate english e2173_dc2b9298:



    voice "voice/e21/7300080a01.opus"
    mx "\"¡No!\""


translate english e2173_00705a61:



    voice "voice/e21/7300090a01.opus"
    mx "\"¡Nunca compraría algo así!\""


translate english e2173_1fd30a61:


    xy "\"¡Claro que no! Nunca comprarías algo así.\""


translate english e2173_a860a337:



    voice "voice/e21/7300100a01.opus"
    mx "\"......!\""


translate english e2173_689b4e8d:


    "La cara de Miyuki se sonroja de un rojo brillante, y se queda en silencio."


translate english e2173_c5565d79:


    "Soy un hombre misericordioso, así que la dejaré libre."


translate english e2173_e770c2ed:


    "Justo entonces, Miyuki se gira y murmura en voz baja, apenas lo suficiente para que la oiga..."


translate english e2173_b3c8462d:



    voice "voice/e21/7300110a01.opus"
    mx "\"La próxima vez, lo juro...\""


translate english e2173_b18fd9a5:



    voice "voice/e21/7300120a01.opus"
    mx "\"Te voy a coger hasta que pierdas la cabeza.\""


translate english e2173_f48405ae:


    "Oh, no... Cualquier cosa menos eso..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
