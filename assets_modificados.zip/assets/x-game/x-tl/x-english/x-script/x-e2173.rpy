

translate english e2173_499d4e06:


    xy "\"So, what did you get?\""


translate english e2173_a192dca3:



    voice "voice/e21/7300010a01.opus"
    mx "\"Me? Oh, nothing special...\""


translate english e2173_72e2102e:


    "ella se retira \"Magic Tricks 101.\""



translate english e2173_7db31ebc:


    "ella se retira \"The Witch's Guide to Black Magic.\""



translate english e2173_78c8a567:


    "ella se retira \"The World Heritage Photobook.\""



translate english e2173_d7874bc8:



    voice "voice/e21/7300020a01.opus"
    mx "\"Just another one for the collection! Haha...\""


translate english e2173_12e64a21:


    xy "\"......\""


translate english e2173_657aba9a:


    "Parece un poco raro, pero está bien..."


translate english e2173_a012bb38:


    "No tenía idea de que le gustara ese tipo de cosas."


translate english e2173_a562213e:


    "Casi se siente como si me estuviera ocultando algo..."


translate english e2173_902ea85f:


    "Dicho esto, puedo decir por el tamaño de la bolsa que lleva que definitivamente compró al menos otro libro..."


translate english e2173_668a8f0e:


    xy "\"What about that one?\""


translate english e2173_c031da49:



    voice "voice/e21/7300030a01.opus"
    mx "\"Oh, right. This?\""


translate english e2173_fa09a39e:



    voice "voice/e21/7300040a01.opus"
    mx "\"Programming For Dummies.\""



translate english e2173_064744c1:


    xy "\"Making a video game or something?\""


translate english e2173_5bf5ea5f:



    voice "voice/e21/7300050a01.opus"
    mx "\"Yeah, something like that!\""


translate english e2173_72a384b2:


    xy "\"So, what's that in the middle there?\""


translate english e2173_bcdf4d07:



    voice "voice/e21/7300060a01.opus"
    mx "\"Nothing!\""


translate english e2173_12de2809:



    voice "voice/e21/7300070a01.opus"
    mx "\"There's nothing hidden in there!\""


translate english e2173_15c2d24d:


    "Hmm... ¿Qué tipo de libro querría ocultar de la dependienta?"


translate english e2173_f27c3a92:


    xy "\"Oh, that reminds me. You mentioned something in class the other day...\""


translate english e2173_f824476a:


    xy "\"Something about this month's issue of some magazine featuring a sexy photo collection—\""


translate english e2173_dc2b9298:



    voice "voice/e21/7300080a01.opus"
    mx "\"No!\""


translate english e2173_00705a61:



    voice "voice/e21/7300090a01.opus"
    mx "\"I'd never buy something like that!!!\""


translate english e2173_1fd30a61:


    xy "\"Of course not! You'd never buy anything like that.\""


translate english e2173_a860a337:



    voice "voice/e21/7300100a01.opus"
    mx "\"......!\""


translate english e2173_689b4e8d:


    "La cara de Miyuki se sonroja de un rojo brillante, y se queda en silencio."


translate english e2173_c5565d79:


    "Soy un hombre misericordioso, así que la dejaré libre."


translate english e2173_e770c2ed:


    "Justo entonces, Miyuki se gira y murmura en voz baja, apenas lo suficiente para que la oiga..."


translate english e2173_b3c8462d:



    voice "voice/e21/7300110a01.opus"
    mx "\"Next time, I swear...\""


translate english e2173_b18fd9a5:



    voice "voice/e21/7300120a01.opus"
    mx "\"I'm gonna fuck your brains out.\""


translate english e2173_f48405ae:


    "Oh, no... Cualquier cosa menos eso..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
