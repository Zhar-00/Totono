

translate english e2181f_91e07fba:


    xy "\"¡¿Eh?!\""


translate english e2181f_88b89cba:


    "Parpadeo."


translate english e2181f_9b307b90:


    xy "\"¡¿La bola acaba de desaparecer?!\""


translate english e2181f_86970217:



    voice "voice/e21/81f00010a01.opus"
    mx "\"Es una bola demoníaca desaparecedora.\""


translate english e2181f_3384cd73:



    voice "voice/e21/81f00020a01.opus"
    mx "\"Bastante genial, ¿eh?\""


translate english e2181f_113d7f11:


    "Bien, ahora solo estás exagerando..."


translate english e2181f_f824ab5c:


    "Admito que ES bastante genial, sin embargo..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
