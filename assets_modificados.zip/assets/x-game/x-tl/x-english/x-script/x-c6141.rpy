

translate english c6141_64f0a83e:


    "Me apresuro por el camino, bajo los rojizos rayos del atardecer."


translate english c6141_364ba956:


    "Si corro, todavía puedo llegar a tiempo para la obra."


translate english c6141_45906e12:


    "Admito que di un desvío enorme, ¡pero al menos resolví ese malentendido!"


translate english c6141_a8a31a08:


    "Vaya, me da mucha vergüenza haber dudado de Aoi o de Yuutarou."


translate english c6141_97662ad6:


    "Claro que aún me gustaría saber por qué Aoi salió de la casa."


translate english c6141_16041d4b:


    "Sobre todo porque lo hizo a mis espaldas..."


translate english c6141_11762da7:


    xy "\"I'm sure there's gotta be a good reason for it... right...?\""


translate english c6141_f1b797ca:


    "Haru-chan está en el club de teatro."


translate english c6141_2bec0b6a:


    "No puedo descartar la posibilidad de que las dos estén preparando algún tipo de sorpresa de cumpleaños para mí."


translate english c6141_c1e49b67:


    "Quizás debería fingir que no vi nada."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
