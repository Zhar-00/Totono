

translate english e0116b_ef5554fd:


    xy "\"No del todo.\""


translate english e0116b_6fbb596a:



    voice "voice/e01/16b00010a01.opus"
    mx "\"...Ya veo.\""


translate english e0116b_01722762:



    voice "voice/e01/16b00020a01.opus"
    mx "\"Supongo que tendré que esforzarme un poco más.\""


translate english e0116b_863f4604:


    xy "\"No te fuerces, ¿sí?\""


translate english e0116b_9084e98a:


    xy "\"Tiendes a obsesionarte con estas cosas.\""


translate english e0116b_85bf981d:



    voice "voice/e01/16b00030a01.opus"
    mx "\"No te preocupes.\""


translate english e0116b_2cd301e7:



    voice "voice/e01/16b00040a01.opus"
    mx "\"Créeme, lo veo todo perfectamente bien.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
