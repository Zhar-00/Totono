

translate english e0116b_ef5554fd:


    xy "\"Not quite.\""


translate english e0116b_6fbb596a:



    voice "voice/e01/16b00010a01.opus"
    mx "\"...I see.\""


translate english e0116b_01722762:



    voice "voice/e01/16b00020a01.opus"
    mx "\"Guess I'll just have to try a little harder.\""


translate english e0116b_863f4604:


    xy "\"Don't force yourself, alright?\""


translate english e0116b_9084e98a:


    xy "\"You tend to get tunnel vision over these things.\""


translate english e0116b_85bf981d:



    voice "voice/e01/16b00030a01.opus"
    mx "\"Don't worry.\""


translate english e0116b_2cd301e7:



    voice "voice/e01/16b00040a01.opus"
    mx "\"Trust me, I can see it all just fine.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
