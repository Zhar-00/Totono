

translate english e2182d_9675c199:


    xy "\"How about... doing it at school?\""


translate english e2182d_41b8258c:



    voice "voice/e21/82d00010a01.opus"
    mx "\"......Yeah...\""


translate english e2182d_364a72d9:



    voice "voice/e21/82d00020a01.opus"
    mx "\"To tell the truth, I've been thinking about it myself.\""


translate english e2182d_288607ab:


    xy "\"Oh... Cool.\""


translate english e2182d_bf782d7b:


    "Parece que estamos en la misma página."


translate english e2182d_95c608a0:


    "Supongo que eso significa que somos... sexualmente compatibles..."


translate english e2182d_aad01f55:


    "El pensamiento me da un poco de timidez."


translate english e2182d_44aa9e13:



    voice "voice/e21/82d00030a01.opus"
    mx "\"So... You know that empty desk in the classroom?\""


translate english e2182d_9443a274:



    voice "voice/e21/82d00040a01.opus"
    mx "\"They told me to move it up to the roof. And I was thinking you could help me.\""


translate english e2182d_887abc63:



    voice "voice/e21/82d00050a01.opus"
    mx "\"What if... we do it then?\""


translate english e2182d_c727edce:


    "El techo ciertamente nos ofrecería bastante privacidad..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
