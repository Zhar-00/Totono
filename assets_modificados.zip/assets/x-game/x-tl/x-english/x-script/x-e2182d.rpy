

translate english e2182d_9675c199:


    xy "\"¿Qué tal... hacerlo en la escuela?\""


translate english e2182d_41b8258c:



    voice "voice/e21/82d00010a01.opus"
    mx "\"......Sí...\""


translate english e2182d_364a72d9:



    voice "voice/e21/82d00020a01.opus"
    mx "\"A decir verdad, yo también lo he estado pensando.\""


translate english e2182d_288607ab:


    xy "\"Oh... Genial.\""


translate english e2182d_bf782d7b:


    "Parece que estamos en la misma página."


translate english e2182d_95c608a0:


    "Supongo que eso significa que somos... sexualmente compatibles..."


translate english e2182d_aad01f55:


    "El pensamiento me da un poco de timidez."


translate english e2182d_44aa9e13:



    voice "voice/e21/82d00030a01.opus"
    mx "\"Y... ¿Conoces ese escritorio vacío en el salón?\""


translate english e2182d_9443a274:



    voice "voice/e21/82d00040a01.opus"
    mx "\"Me dijeron que lo suba a la azotea. Y estaba pensando que podrías ayudarme.\""


translate english e2182d_887abc63:



    voice "voice/e21/82d00050a01.opus"
    mx "\"¿Qué tal si... lo hacemos entonces?\""


translate english e2182d_c727edce:


    "El techo ciertamente nos ofrecería bastante privacidad..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
