

translate english e1112a_dc42d0f6:



    voice "voice/e11/12a00010a01.opus"
    mx "\"You're wasting your time.\""


translate english e1112a_620777f8:



    voice "voice/e11/12a00020a01.opus"
    mx "\"I'm the one who gets to choose, you know.\""


translate english e1112a_9bd38e35:



    voice "voice/e11/12a00030a01.opus"
    mx "\"Hmm... Let's see... What scene shall we play this time...?\""


translate english e1112a_6efb1e60:


    "Miyuki contiene una sonrisa mientras habla."


translate english e1112a_1ef7f98f:


    "Mientras tanto, recojo mi tazón de sopa de miso."


translate english e1112a_bbcacbbe:


    "Mmm... Delicioso..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
