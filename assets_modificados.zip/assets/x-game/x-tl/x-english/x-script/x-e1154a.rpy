

translate english e1154a_014f7d1e:



    voice "voice/e11/54a00010a01.opus"
    mx "\"¡Te dije que no sirve de nada!\""


translate english e1154a_92a1fd2c:


    "Miyuki baja su bate."


translate english e1154a_30e2a72a:


    "Pero hay vacilación en su golpe."


translate english e1154a_fc81ed3c:


    "Por reflejo, me inclino hacia atrás, esquivando el bate por un pelo."


translate english e1154a_05b7bd7e:


    "La mesa se rompe."


translate english e1154a_fffa4faa:


    "Mi sopa de miso intacta sale volando por el aire."


translate english e1154a_5941fe4c:



    voice "voice/e11/54a00020a01.opus"
    mx "\"¡Ay!\""


translate english e1154a_4c59ddcf:


    "El bate sale volando de su mano y cae al suelo."


translate english e1154a_a0abbdbf:


    "Mi cerebro me grita que salga corriendo—así que corro a la puerta principal."


translate english e1154a_ddd4f5d2:


    "Pero mis zapatos no están ahí. Están en una caja en algún lado."


translate english e1154a_c42c3d9a:


    "Y hay un pesado candado en la perilla de la puerta."


translate english e1154a_3d7f62ab:


    "No es para mantener a los intrusos fuera..."


translate english e1154a_9b042018:


    "¡Es para mantener a los prisioneros dentro!"


translate english e1154a_66623085:



    voice "voice/e11/54a00030a01.opus"
    mx "\"No te dejaré escapar.\""


translate english e1154a_cf4006b7:


    "Su sombra se cierne sobre mí desde atrás."


translate english e1154a_ae4effc8:


    "Puedo ver que sostiene su abollado bate de metal."


translate english e1154a_f4fb9e7b:



    voice "voice/e11/54a00040a01.opus"
    mx "\"—!!!\""


translate english e1154a_f05f14c5:


    xy "\"¡¡¡GUH!!!\""


translate english e1154a_b58feb65:


    "Pensando rápido, desvío su bate con un paraguas que colgaba cerca de la puerta."


translate english e1154a_b3e73606:


    "Un impacto sordo resuena en mis dedos, pero no tengo tiempo de preocuparme por eso ahora."


translate english e1154a_56e9ccea:


    "Lanzo mi cuerpo contra ella y la hago caer hacia atrás."


translate english e1154a_23129f98:



    voice "voice/e11/54a00050a01.opus"
    mx "\"¡¡¡AAAH!!!\""


translate english e1154a_291c287b:


    "Miyuki siempre ha sido del tipo atlético, pero como hombre, llevo la ventaja."


translate english e1154a_85515319:


    "La inmovilizo en el suelo."


translate english e1154a_b3139b27:


    "Luego uso mi mano libre para hurgar en sus bolsillos, buscando la llave del candado—"


translate english e1154a_2f71cb38:



    voice "voice/e11/54a00060a01.opus"
    mx "\"¡Hnn! Nnn... ¡nnnngh! ¡Suéltame!\""


translate english e1154a_b0bd490c:


    xy "\"¡Lo haré si te calmas!\""


translate english e1154a_61b72782:



    voice "voice/e11/54a00070a01.opus"
    mx "\"¡ESTOY calmado!\""


translate english e1154a_3e044546:


    xy "\"¡Mentiroso! ¡¿Y por qué demonios estás tan enojado, eh?!\""


translate english e1154a_42baba27:



    voice "voice/e11/54a00080a01.opus"
    mx "\"¡Nunca lo entenderías!\""


translate english e1154a_bedc0f7a:


    xy "\"¡¿Y qué te hace pensar que no?! ¡Estamos hablando de ti y de mí! ¡¿No nos conocemos acaso desde siempre?!\""


translate english e1154a_e331de18:



    voice "voice/e11/54a00090a01.opus"
    mx "\"¿Tú y... yo?\""


translate english e1154a_be4f5ee0:


    xy "\"¡Sí! ¡Así que cálmate de una vez!\""


translate english e1154a_86e20f42:


    xy "\"¡Solo háblame y dime qué pasó!\""


translate english e1154a_27e25fae:



    voice "voice/e11/54a00100a01.opus"
    mx "\"......\""


translate english e1154a_671b4333:


    "Los ojos de Miyuki se iluminan con algún tipo de comprensión."


translate english e1154a_1657ffa3:


    "Sus labios se contraen débilmente..."


translate english e1154a_e8946b5c:


    "Tan débilmente que no puedo oír ni una palabra, aunque literalmente estoy encima de ella."


translate english e1154a_546c3973:


    xy "\"¿Qué fue eso?\""


translate english e1154a_1829c190:


    "Me inclino cerca y acerco mi oído a sus labios—"


translate english e1154a_e8da5ee7:


    xy "\"—¡AYYY!!!\""


translate english e1154a_eee9c7ec:


    "Un dolor agudo recorre mi lóbulo de la oreja."


translate english e1154a_8de71598:


    "Aprovecha esa oportunidad para empujarme."


translate english e1154a_305164dd:


    "Recupero el equilibrio. Mientras tanto, me duele tanto la oreja que casi me pregunto si me la arrancó de un mordisco."


translate english e1154a_b3689625:


    "El bate yace a sus pies."


translate english e1154a_80eded55:


    "Si peleo contra ella uno a uno, no tengo ninguna posibilidad."


translate english e1154a_c300e8ae:


    "Pero tengo un as bajo la manga."


translate english e1154a_21667bca:



    voice "voice/e11/54a00110a01.opus"
    mx "\"¿¡Lo robaste...!?\""


translate english e1154a_66f8782d:


    "No pude encontrar la llave del candado, pero SÍ encontré su teléfono."


translate english e1154a_4f70b806:



    voice "voice/e11/54a00120a01.opus"
    mx "\"¡Me engañaste!\""


translate english e1154a_96eafcef:



    voice "voice/e11/54a00130a01.opus"
    mx "\"¡¡¡Alto ahí!!!\""


translate english e1154a_ff97194b:


    "¡Lo siento, nena! ¡No se puede!"


translate english e1154a_7a45d02f:


    "La ignoro y corro a toda velocidad hacia el baño."


translate english e1154a_905b3816:



    voice "voice/e11/54a00140a01.opus"
    mx "\"¡Abre! ¡Abre esta puerta AHORA MISMO!\""


translate english e1154a_bb6d2d0e:



    voice "voice/e11/54a00150a01.opus"
    mx "\"¡¿Qué haces con mi teléfono?!\""


translate english e1154a_31287c3b:


    "Miyuki me grita a través de la puerta."


translate english e1154a_3e7fda03:


    "Obviamente, no voy a desbloquear la puerta para ella."


translate english e1154a_bd449156:


    "Si no puedo escapar por mi cuenta, entonces necesito pedir ayuda y ganar tiempo hasta que lleguen."


translate english e1154a_04f7e253:


    "Navego rápidamente por el teléfono de Miyuki—"


translate english e1154a_ad2ee883:


    xy "\"......¿¡Sin servicio!?\""


translate english e1154a_707dcec0:


    "¡No puedo comunicarme con el 999!"


translate english e1154a_7c448d22:



    voice "voice/e11/54a00160a01.opus"
    mx "\"...¿Shinichi?\""


translate english e1154a_0555ae69:



    voice "voice/e11/54a00170a01.opus"
    mx "\"No hay a dónde correr.\""


translate english e1154a_835f73a7:



    voice "voice/e11/54a00180a01.opus"
    mx "\"¡Ahora sé un buen chico y sal!\""


translate english e1154a_b93c2b4b:



    voice "voice/e11/54a00190a01.opus"
    mx "\"Si no...\""


translate english e1154a_f4f8996c:



    voice "voice/e11/54a00200a01.opus"
    mx "\"Haré que tus últimos momentos sean un infierno en la tierra.\""


translate english e1154a_95d13de0:


    "¿Fue un error encerrarme aquí?"


translate english e1154a_1fc0736c:


    "Sin ningún servicio, ¡no puedo pedir ayuda!"


translate english e1154a_86a78ad7:


    "No planeé esto... y no creo que pueda escabullirme si intento correr."


translate english e1154a_8ffac346:


    "Entonces, ¿qué opciones tengo?"


translate english e1154a_79733153:


    "¿Solo... elegir a un dios y rezar?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
