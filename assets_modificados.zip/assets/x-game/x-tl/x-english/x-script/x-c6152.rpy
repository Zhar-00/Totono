

translate english c6152_12259ca7:


    xy "\"She's feeling sick today.\""


translate english c6152_b251eca6:



    voice "voice/c61/5200010a01.opus"
    mx "\"She's sick?!\""


translate english c6152_ce3eee32:


    xy "\"Don't worry. It's nothing serious.\""


translate english c6152_322720b5:


    "La expresión de Miyuki se endurece, pero agito la mano para descartar su preocupación."


translate english c6152_5c708e7c:


    xy "\"Just a minor fever. You know how she's been under the weather lately.\""


translate english c6152_04e2d6f1:



    voice "voice/c61/5200020a01.opus"
    mx "\"You should try calling her.\""


translate english c6152_96b5de67:


    xy "\"Her phone's always out of service, though.\""


translate english c6152_d935a094:



    voice "voice/c61/5200030a01.opus"
    mx "\"Call your house phone, then.\""


translate english c6152_11bd8457:


    xy "\"Seriously, you don't need to worry abou—\""


translate english c6152_07b5364b:



    voice "voice/c61/5200040a01.opus"
    mx "\"Please.\""


translate english c6152_c325a8af:


    "La mirada en sus ojos es mortalmente seria."


translate english c6152_feef524a:


    "Qué raro... ¿Por qué insiste tanto en esto?"


translate english c6152_298fe798:


    "Qué más da. Es solo una mísera llamada telefónica, supongo."


translate english c6152_016bbf2d:


    "Como me pidió, saco mi teléfono celular."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
