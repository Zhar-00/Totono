

translate english c6152_12259ca7:


    xy "\"Hoy se siente mal.\""


translate english c6152_b251eca6:



    voice "voice/c61/5200010a01.opus"
    mx "\"¡¿Está enferma?!\""


translate english c6152_ce3eee32:


    xy "\"No te preocupes. No es nada serio.\""


translate english c6152_322720b5:


    "La expresión de Miyuki se endurece, pero agito la mano para descartar su preocupación."


translate english c6152_5c708e7c:


    xy "\"Solo una fiebre leve. Ya sabes cómo ha estado decaída últimamente.\""


translate english c6152_04e2d6f1:



    voice "voice/c61/5200020a01.opus"
    mx "\"Deberías intentar llamarla.\""


translate english c6152_96b5de67:


    xy "\"Pero su teléfono siempre está fuera de servicio.\""


translate english c6152_d935a094:



    voice "voice/c61/5200030a01.opus"
    mx "\"Llama a tu teléfono de casa, entonces.\""


translate english c6152_11bd8457:


    xy "\"En serio, no tienes que preocuparte por—\""


translate english c6152_07b5364b:



    voice "voice/c61/5200040a01.opus"
    mx "\"Por favor.\""


translate english c6152_c325a8af:


    "La mirada en sus ojos es mortalmente seria."


translate english c6152_feef524a:


    "Qué raro... ¿Por qué insiste tanto en esto?"


translate english c6152_298fe798:


    "Qué más da. Es solo una mísera llamada telefónica, supongo."


translate english c6152_016bbf2d:


    "Como me pidió, saco mi teléfono celular."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
