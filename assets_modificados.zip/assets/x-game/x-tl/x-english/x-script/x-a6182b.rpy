

translate english a6182b_e556a393:


    xy "\"Lo siento.\""


translate english a6182b_b39e1e9e:



    voice "voice/a61/82b00010a02.opus"
    aoi "\"¿Shinichi?\""


translate english a6182b_f8e9c0f6:


    xy "\"Simplemente no puedo hacerlo.\""


translate english a6182b_fae5bc87:


    xy "\"Al final del día, no puedo cambiar quién soy.\""


translate english a6182b_e47b8508:


    xy "\"Sé que es patético de mi parte, pero... no quiero interponerme en los sueños de Miyuki.\""


translate english a6182b_07571612:


    xy "Nunca dejaría que ella besara a otro chico.\""


translate english a6182b_35104841:


    xy "\"Así que no puedo permitirme enamorarme de ella.\""


translate english a6182b_8a12bf58:


    xy "\"Solo sería una carga para ella.\""


translate english a6182b_8037f362:



    voice "voice/a61/82b00020a02.opus"
    aoi "\"Estás equivo—\""


translate english a6182b_d0a759d5:


    xy "\"No existen los milagros.\""


translate english a6182b_4e3e4371:


    xy "\"Ni los dioses.\""


translate english a6182b_e0674c1f:


    xy "\"Todo eso... Todo eso es fantasía.\""


translate english a6182b_cd4496c2:


    xy "\"Lo sabes, ¿verdad?\""


translate english a6182b_18ffc65f:


    "Me doy la vuelta para mirarla—"


translate english a6182b_fba1f433:


    "—pero no hay nadie."


translate english a6182b_783df5c1:


    "Estoy completamente solo."


translate english a6182b_77a2bc22:


    "Todo estaba solo en mi cabeza."


translate english a6182b_831da751:


    xy "\"Cielos. ¿Con quién creía que estaba hablando?\""


translate english a6182b_7ca7a167:


    "Murmurando para mí mismo, pateo el bate tirado en el suelo."


translate english a6182b_0982c903:


    "No logré batear ni una sola vez."


translate english a6182b_2caded7e:


    "Y probablemente nunca vuelva a batear en el resto de mi vida."


translate english a6182b_7546750d:


    "No es que debiera haber esperado algo distinto."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
