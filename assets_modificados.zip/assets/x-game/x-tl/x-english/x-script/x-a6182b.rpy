

translate english a6182b_e556a393:


    xy "\"I'm sorry.\""


translate english a6182b_b39e1e9e:



    voice "voice/a61/82b00010a02.opus"
    aoi "\"Shinichi?\""


translate english a6182b_f8e9c0f6:


    xy "\"I just can't do it.\""


translate english a6182b_fae5bc87:


    xy "\"At the end of the day, I can't change who I am.\""


translate english a6182b_e47b8508:


    xy "\"I know it's pathetic of me, but... I don't want to get in the way of Miyuki's dreams.\""


translate english a6182b_07571612:


    xy "Nunca dejaría que ella besara a otro chico.\""


translate english a6182b_35104841:


    xy "\"So I can't let myself fall for her.\""


translate english a6182b_8a12bf58:


    xy "\"I'd just be a burden on her.\""


translate english a6182b_8037f362:



    voice "voice/a61/82b00020a02.opus"
    aoi "\"You're wr—\""


translate english a6182b_d0a759d5:


    xy "\"There are no miracles.\""


translate english a6182b_4e3e4371:


    xy "\"No gods.\""


translate english a6182b_e0674c1f:


    xy "\"All of it... All of it is fantasy.\""


translate english a6182b_cd4496c2:


    xy "\"You know that, right?\""


translate english a6182b_18ffc65f:


    "Me doy la vuelta para mirarla—"


translate english a6182b_fba1f433:


    "—pero no hay nadie."


translate english a6182b_783df5c1:


    "Estoy completamente solo."


translate english a6182b_77a2bc22:


    "Todo estaba solo en mi cabeza."


translate english a6182b_831da751:


    xy "\"Good grief. Who did I think I was talking to?\""


translate english a6182b_7ca7a167:


    "Murmurando para mí mismo, pateo el bate tirado en el suelo."


translate english a6182b_0982c903:


    "No logré batear ni una sola vez."


translate english a6182b_2caded7e:


    "Y probablemente nunca vuelva a batear en el resto de mi vida."


translate english a6182b_7546750d:


    "No es que debiera haber esperado algo distinto."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
