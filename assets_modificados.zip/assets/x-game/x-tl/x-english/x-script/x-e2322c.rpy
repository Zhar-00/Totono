

translate english e2322c_a9fb7252:


    "La cagué otra vez..."


translate english e2322c_316011d4:


    "Si fallo una tercera vez, no tendré otra oportunidad hasta mañana como mínimo."


translate english e2322c_28e22ea0:


    "Esta es la oportunidad de mi vida, y no puedo dejarla pasar."


translate english e2322c_3032b19a:


    "Concentro toda mi atención en la pantalla del teléfono."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
