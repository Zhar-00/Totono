

translate english a2181_ff93c824:



    voice "voice/a21/8100010a02.opus"
    aoi "\"We're here.\""


translate english a2181_aca346bf:


    "—se detiene en una tienda en las afueras de la zona comercial detrás de la estación de tren."


translate english a2181_abac3c53:


    "\"Catnip,\"la tienda de regalos para amantes de los gatos."


translate english a2181_d0d1a61d:


    "En la vitrina puedo ver figuritas de gatos, peluches de gatos, relojes con forma de gato, cortinas estampadas con gatos... y así sucesivamente."


translate english a2181_a83dcd93:


    "Además de mercancía con temática felina, parece que también venden artículos para dueños de gatos. Juguetes y croquetas y esas cosas."


translate english a2181_b870a5b4:


    xy "\"Cats galore, eh?\""


translate english a2181_05020645:


    "Me pregunto cómo se verá por dentro..."


translate english a2181_dd41d5fa:


    "Justo cuando alcanzo la manija de la puerta en forma de cola—"


translate english a2181_a330a7c3:



    voice "voice/a21/8100020a02.opus"
    aoi "\"Boop boop... Miyuki?\""


translate english a2181_2f69bddc:



    voice "voice/a21/8100030a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2181_470ef0bf:



    voice "voice/a21/8100040a02.opus"
    aoi "\"Miyuki, aren't you coming?\""


translate english a2181_6c38ffe0:



    voice "voice/a21/8100050a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2181_33e0bfc4:



    voice "voice/a21/8100060a02.opus"
    aoi "\"She's not listening...\""


translate english a2181_a8112fdb:



    voice "voice/a21/8100070a02.opus"
    aoi "\"Is something wrong?\""


translate english a2181_1f77d66c:


    xy "\"D-Don't ask me...\""


translate english a2181_4d1fe251:



    voice "voice/a21/8100080a01.opus"
    mx "Lo siento, pero no voy.\""


translate english a2181_66beddf6:



    voice "voice/a21/8100090a02.opus"
    aoi "\"...Boop boop...\""


translate english a2181_e6d1ea15:


    xy "\"So you want me and Aoi to go by ourselves?\""


translate english a2181_c23c7a60:



    voice "voice/a21/8100100a01.opus"
    mx "\"D-Do whatever you like! I don't care!\""


translate english a2181_4cdc8b43:



    voice "voice/a21/8100110a02.opus"
    aoi "\"That's no good. We all have to go together.\""


translate english a2181_7d5dc0ce:


    xy "\"Where exactly are we going, by the way?\""


translate english a2181_4f1bf0f0:



    voice "voice/a21/8100120a02.opus"
    aoi "\"A store called Catnip.\""


translate english a2181_64d23d40:


    xy "\"Never heard of it.\""



translate english a2181_da361f3a:



    voice "voice/a21/8100130a02.opus"
    aoi "\"It just opened last week. They sell lots of cat stuff.\""


translate english a2181_ba3358a1:



    voice "voice/a21/8100140a01.opus"
    mx "\"Let's go.\""


translate english a2181_4b2400f3:


    xy "\"Wait, what? What happened to staying focused on--\""


translate english a2181_2994e508:



    voice "voice/a21/8100150a01.opus"
    mx "\"Let's GO!\""


translate english a2181_5dd45b30:


    xy "\"She must really like cats, huh?\""


translate english a2181_9a05c4bf:



    voice "voice/a21/8100160a02.opus"
    aoi "\"Seems that way.\""


translate english a2181_6bf290d9:



    voice "voice/a21/8100170a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2181_256854c6:


    "Miyuki contempla, embelesada, la vitrina: un lado notablemente femenino suyo que normalmente nunca dejaría ver."


translate english a2181_d37259e4:


    xy "\"Earth to Miyuki!\""


translate english a2181_55ea3d36:



    voice "voice/a21/8100180a01.opus"
    mx "\"Aah!\""


translate english a2181_1b72dc52:



    voice "voice/a21/8100190a01.opus"
    mx "\"Y-You scared me!\""


translate english a2181_a06c07d8:


    xy "\"We're going inside!\""


translate english a2181_7ea42f1c:



    voice "voice/a21/8100200a01.opus"
    mx "\"Wait! I'm not emotionally prepared!\""


translate english a2181_9c2e63fd:


    xy "\"Too bad. Now come on!\""


translate english a2181_f9aec2dd:



    voice "voice/a21/8100210a01.opus"
    mx "\"Ack! Hey! Slow down!\""


translate english a2181_74b81e22:


    "Agarro a Miyuki por la manga y la arrastro adentro tras Aoi."


translate english a2181_fce354e9:



    voice "voice/a21/8100220a02.opus"
    aoi "\"Boop boop... Amazing...\""


translate english a2181_2f6d6bd5:


    "En cuanto entramos, Aoi va directo a los estantes."


translate english a2181_dc2ceecc:


    "Efectivamente, resulta que Catnip está repleta hasta el tope de todo tipo de artículos con temática de gatos."


translate english a2181_b14ba8a4:


    "Los peluches, las figuritas, el reloj de la pared, las luces del techo, incluso el piso de azulejos: nada más que gatos hasta donde alcanza la vista."


translate english a2181_449f7d36:


    "La campanita que tintineó sobre nuestras cabezas al entrar probablemente venía de un collar de gato o algo así."


translate english a2181_d5c08ee4:


    xy "\"They really went all-out in here...\""


translate english a2181_46ec4f9b:



    voice "voice/a21/8100230a01.opus"
    mx "\"...I'm so happy...\""


translate english a2181_bd80b0b9:


    xy "\"Hey Miyuki, you doing okay?\""


translate english a2181_8c89e016:



    voice "voice/a21/8100240a01.opus"
    mx "\"I think I'm a little lightheaded...\""


translate english a2181_27754f11:



    voice "voice/a21/8100250a01.opus"
    mx "\"I'm... not sure I can take it...\""


translate english a2181_8784078d:


    xy "\"Whoa there, calm down! Since when have you been this cat-crazy?\""


translate english a2181_3fcc4186:



    voice "voice/a21/8100260a01.opus"
    mx "\"I can't help it...\""


translate english a2181_af42770d:



    voice "voice/a21/8100270a01.opus"
    mx "\"...They're just adorable...\""


translate english a2181_51fb3e10:



    voice "voice/a21/8100280a02.opus"
    aoi "\"Miyuki's adorable, too.\""


translate english a2181_0237e431:


    "De acuerdo."


translate english a2181_6fa49bec:


    "Hoy en día estoy acostumbrado a verla siempre en modo reina, pero esto se acerca más a la Miyuki que solía conocer."


translate english a2181_93d8d5cc:



    voice "voice/a21/8100290a02.opus"
    aoi "\"Got it!\""


translate english a2181_34a96bef:


    xy "\"What's up?\""


translate english a2181_68639f5c:



    voice "voice/a21/8100300a02.opus"
    aoi "\"How's this?\""


translate english a2181_9aea408a:


    xy "\"Whoa!\""


translate english a2181_00f1ca4e:


    "Aoi asoma de detrás de la cortina del probador, llevando... ¿¿un mameluco de gatito...??"


translate english a2181_d33bb47b:


    xy "\"Dang, girl. That looks PERFECT on you.\""


translate english a2181_9dc3849c:



    voice "voice/a21/8100310a02.opus"
    aoi "\"What do you think, Miyuki?\""


translate english a2181_b7782c5f:



    voice "voice/a21/8100320a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2181_52c3ec49:



    voice "voice/a21/8100330a02.opus"
    aoi "\"Boop boop... Miyuki?\""


translate english a2181_0b25b17d:



    voice "voice/a21/8100340a01.opus"
    mx "\"S-Sorry! You're overloading my brain right now!\""


translate english a2181_3328e44c:



    voice "voice/a21/8100350a02.opus"
    aoi "\"With what?\""


translate english a2181_b00fdae7:



    voice "voice/a21/8100360a01.opus"
    mx "\"Hey! Cut it out! Don't look at me like that!\""


translate english a2181_06c3a446:



    voice "voice/a21/8100370a02.opus"
    aoi "\"Boop boop?\""


translate english a2181_6a03ded8:



    voice "voice/a21/8100380a01.opus"
    mx "\"Aaah!\""


translate english a2181_4f12e539:


    "Y así, ¡Aoi gato asesta el golpe final."


translate english a2181_911d12ec:



    voice "voice/a21/8100390a02.opus"
    aoi "\"Does it hurt? Aoi will help you.\""


translate english a2181_ac48df4e:



    voice "voice/a21/8100400a01.opus"
    mx "\"Oh god... I'm dying...\""


translate english a2181_137a885b:



    voice "voice/a21/8100410a01.opus"
    mx "\"I'm... dead...\""


translate english a2181_cad58742:


    "El cuerpo de Miyuki se inclina de lado—"


translate english a2181_4ea1da0a:



    voice "voice/a21/8100420a02.opus"
    aoi "\"Boop boop... Miyuki?\""


translate english a2181_620c2ba2:


    xy "\"Oh shit!\""


translate english a2181_664ae63c:


    "—y se desploma, llevándose un estante consigo."


translate english a2181_c0be34ce:


    "Al menos se fue con una sonrisa, supongo..."


translate english a2181_7bd831b4:



    voice "voice/a21/8100430a01.opus"
    mx "\"I... I'm so sorry... I don't know what I was thinking...\""


translate english a2181_87563c6d:



    voice "voice/a21/8100440a02.opus"
    aoi "\"Aoi is sorry too...\""


translate english a2181_8a9a486e:


    "Nota: Sigue llevando el mameluco de gatito."


translate english a2181_9d47747d:



    voice "voice/a21/8100450a01.opus"
    mx "\"I... I told you, that outfit is dangerous!\""


translate english a2181_36507b87:



    voice "voice/a21/8100460a02.opus"
    aoi "\"Then Aoi won't buy it.\""


translate english a2181_df798298:



    voice "voice/a21/8100470a01.opus"
    mx "\"You have to.\""


translate english a2181_636bfae6:



    voice "voice/a21/8100480a02.opus"
    aoi "\"Huh? But--\""


translate english a2181_36de0087:



    voice "voice/a21/8100490a01.opus"
    mx "\"Don't worry about me. Just buy it!\""


translate english a2181_f9039fe0:


    xy "\"Looks like Miyuki digs the onesie after all.\""


translate english a2181_49b80467:



    voice "voice/a21/8100500a02.opus"
    aoi "\"Really?\""


translate english a2181_25b1dd97:


    xy "\"Totally.\""


translate english a2181_792f3bf9:



    voice "voice/a21/8100510a02.opus"
    aoi "\"Okay then. Aoi WILL buy it!\""


translate english a2181_a8059d50:


    "Con eso, se apresura hacia la caja."


translate english a2181_4b3d251a:


    xy "\"Good grief. You're a total cat fanatic, aren't you?\""


translate english a2181_3104d936:



    voice "voice/a21/8100520a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2181_b0eaebdb:


    xy "\"Hmm? What's the matter, Miyuki?\""


translate english a2181_58383bd6:



    voice "voice/a21/8100530a01.opus"
    mx "\"Look.\""


translate english a2181_b214a87d:


    "Miyuki señala un pasador con forma de gato exhibido cerca de la ventana."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
