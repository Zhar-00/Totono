

translate english e1154d_MAIN_9ea2f78c:


    " "



translate english e1154d_1b012769:



    voice "voice/e11/54d00010a01.opus"
    mx "\"¿Por qué no correspondes a mi afecto?\""


translate english e1154d_3eca8d81:



    voice "voice/e11/54d00020a01.opus"
    mx "\"¡Te amo tanto!\""


translate english e1154d_aa74f525:



    voice "voice/e11/54d00030a01.opus"
    mx "\"¡Tanto, que tengo que matarte!\""


translate english e1154d_104c2fa0:



    voice "voice/e11/54d00040a01.opus"
    mx "\"¡Tengo que matar a la persona que amo, una y otra y otra y otra vez!\""


translate english e1154d_d2469c4f:



    voice "voice/e11/54d00050a01.opus"
    mx "\"¡Estoy perdiendo la puta cabeza!\""


translate english e1154d_72f25ca5:



    voice "voice/e11/54d00060a01.opus"
    mx "\"Por favor...\""


translate english e1154d_553a6e7a:



    voice "voice/e11/54d00070a01.opus"
    mx "\"¿No me vas a ayudar?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
