

translate english e1154d_MAIN_9ea2f78c:


    " "



translate english e1154d_1b012769:



    voice "voice/e11/54d00010a01.opus"
    mx "\"Why won't YOU return my affection?\""


translate english e1154d_3eca8d81:



    voice "voice/e11/54d00020a01.opus"
    mx "\"I love YOU so much!\""


translate english e1154d_aa74f525:



    voice "voice/e11/54d00030a01.opus"
    mx "\"So much, I have to kill YOU!\""


translate english e1154d_104c2fa0:



    voice "voice/e11/54d00040a01.opus"
    mx "\"I have to kill the person I love, over and over and over and over!!!\""


translate english e1154d_d2469c4f:



    voice "voice/e11/54d00050a01.opus"
    mx "\"I'm losing my fucking mind!!!\""


translate english e1154d_72f25ca5:



    voice "voice/e11/54d00060a01.opus"
    mx "\"Please...\""


translate english e1154d_553a6e7a:



    voice "voice/e11/54d00070a01.opus"
    mx "\"Won't YOU help me?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
