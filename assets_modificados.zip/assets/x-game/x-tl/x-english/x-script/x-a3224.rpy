

translate english a3224_7eb3ad41:


    "Paso a paso, caminamos lentamente por el pueblo crepuscular hasta llegar al manga café."


translate english a3224_8b09c83f:



    voice "voice/a32/2400010a02.opus"
    aoi "\"Shinichi, gracias.\""


translate english a3224_49be8b13:


    "Aoi se baja de mi espalda."


translate english a3224_460fbffd:


    xy "\"¿Seguro que no necesitas ir al hospital?\""


translate english a3224_d64ad9ac:



    voice "voice/a32/2400020a02.opus"
    aoi "\"El chispazo recargó mis baterías.\""


translate english a3224_e0de65e2:



    voice "voice/a32/2400030a02.opus"
    aoi "\"Todo gracias al CG del evento.\""


translate english a3224_3d17c5b7:


    "¿De qué CG está hablando?"


translate english a3224_922bb985:


    "La buena noticia es que no parece tan mareada como estaba afuera de mi casa."


translate english a3224_95bef4f4:


    xy "\"Descansa mucho, ¿me oyes?\""


translate english a3224_d4525f9d:


    xy "\"Yo cuidaré de Eru.\""


translate english a3224_8e9c98e0:



    voice "voice/a32/2400040a02.opus"
    aoi "\"Por favor, hazlo.\""


translate english a3224_6d8f42bd:


    "Aoi me saluda con la mano."


translate english a3224_15e96269:



    voice "voice/a32/2400050a02.opus"
    aoi "\"Bye-bye.\""


translate english a3224_78fcbfc1:


    xy "\"Que tengas buena noche.\""


translate english a3224_b93956cf:


    "Con eso, desaparece lentamente en el café."


translate english a3224_ce112445:


    "La veo irse hasta que las puertas del elevador se cierran."


translate english a3224_c06f7f51:


    "Pensándolo bien, este ha sido un día de mil demonios."


translate english a3224_1a18c9f4:


    "Yo mismo todavía tengo cosas que procesar."


translate english a3224_39e7c143:


    "Pero..."


translate english a3224_c89305d5:


    xy "\"Hola, pequeñito. ¿Quieres dormir en mi cama?\""


translate english a3224_6d267e6e:


    "Eru y yo nos metemos bajo las cobijas."


translate english a3224_151dac76:


    "Puedo sentir el agotamiento pesando sobre cada centímetro de mi cuerpo."


translate english a3224_d6c2d6c6:


    "Estoy demasiado cansado para pensar ahora."


translate english a3224_83d7eb02:


    "Y sin embargo, de alguna forma el sueño me elude."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
