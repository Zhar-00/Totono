

translate english e1167b_ada099b0:


    "Las palabras salen de mis labios sin querer."


translate english e1167b_0a35ec9f:


    "Pero debería haberlo esperado."


translate english e1167b_fc0e4b4a:


    "After all, I don't know what \"code number\"estaba hablando Aoi."



translate english e1167b_22f1bec2:



    voice "voice/e11/67b00010a01.opus"
    mx "\"Jejeh... jejejejeh...\""


translate english e1167b_a5f88d2e:



    voice "voice/e11/67b00020a01.opus"
    mx "\"¡¡¡AAAJAJAJAJAJAJAJAJAJAJA—!!!\""


translate english e1167b_38d79090:



    voice "voice/e11/67b00030a01.opus"
    mx "\"¿Te equivocaste?\""


translate english e1167b_3024a526:



    voice "voice/e11/67b00040a01.opus"
    mx "\"¡Dios mío, olvidaste el número secreto de Aoi!\""


translate english e1167b_0c53966e:



    voice "voice/e11/67b00050a01.opus"
    mx "\"¿Cómo pudiste olvidar el cumpleaños de tu preciosa Aoi-chan?\""


translate english e1167b_9d0c4c9e:


    xy "\"Miyuki...\""


translate english e1167b_f0599e59:


    "Siento que es la primera vez en mi vida que veo a Miyuki tan... jubilosa."


translate english e1167b_9326818a:



    voice "voice/e11/67b00060a01.opus"
    mx "\"Está bien entonces. Te lo diré.\""


translate english e1167b_c96ac500:



    voice "voice/e11/67b00070a01.opus"
    mx "\"Aquí está...\""


translate english e1167b_8cf4c6ef:



    voice "voice/e11/67b00080a01.opus"
    mx "\"El número secreto para traer a Aoi de vuelta...\""


translate english e1167b_2e73ab13:



    voice "voice/e11/67b00090a01.opus"
    mx "\"999-0523-0523.\""


translate english e1167b_08daf0de:



    voice "voice/e11/67b00100a01.opus"
    mx "Luego marca el cumpleaños de Aoi—0523—dos veces.\""


translate english e1167b_16c7784f:



    voice "voice/e11/67b00110a01.opus"
    mx "¿Después de que prácticamente te lo dejé en bandeja?\""


translate english e1167b_2d49de94:



    voice "voice/e11/67b00120a01.opus"
    mx "\"Bien entonces. Lo marcaré por ti.\""


translate english e1167b_e9b2ea4c:


    "Miyuki toma el teléfono y lo sostiene en ángulo para que pueda verla teclear el número que acaba de decirme."


translate english e1167b_8d9169c3:


    "Pulsa el botón de Llamar."


translate english e1167b_39e7c143:


    "Pero..."


translate english e1167b_066ee1b7:



    voice "voice/e11/67b00130b02.opus"
    kmsm "\"EL NÚMERO QUE HA MARCADO NO ESTÁ EN SERVICIO EN ESTE MOMENTO.\""


translate english e1167b_1fc27314:


    "La llamada no se conecta."


translate english e1167b_2513c9e2:


    xy "\"¿Por qué...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
