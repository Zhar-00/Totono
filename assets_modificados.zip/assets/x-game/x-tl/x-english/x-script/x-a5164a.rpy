

translate english a5164a_a4978c8c:


    "Your \"god\"no es real, Aoi."


translate english a5164a_0874a850:


    "¿Todo eso de las baterías y las transmisiones? Es solo tu fantasía inventada."


translate english a5164a_904deab0:


    "Los videojuegos no son lo mismo que la vida real."


translate english a5164a_15729ff1:


    "Solo estás engañada."


translate english a5164a_d275fbd2:


    "...Si tan solo hubiera podido decirle eso."


translate english a5164a_39aeeae6:



    voice "voice/a51/64a00010a02.opus"
    aoi "\"Shinichi...\""


translate english a5164a_ce233fe8:


    "Las lágrimas corren por sus mejillas, dejándome helado en el sitio."


translate english a5164a_9c51e329:


    "Puedo sentir su calor en mi piel."


translate english a5164a_f4b58b1c:


    "La mirada de sus ojos me atraviesa hasta el alma."


translate english a5164a_1a6873d2:


    "No logro apartarme."


translate english a5164a_b2caf680:


    xy "\"Aoi...\""


translate english a5164a_ff34c65f:


    "Me inclino hacia ella—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
