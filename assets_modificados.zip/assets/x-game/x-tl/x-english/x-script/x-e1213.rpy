

translate english e1213_59d247dd:



    voice "voice/e12/1300010a01.opus"
    mx "\"Having fun?\""


translate english e1213_59f9c40e:


    xy "\"Whoa!\""


translate english e1213_3a6fe296:


    "Oigo una voz repentina detrás de mí y casi salto del susto."


translate english e1213_b741704f:


    xy "\"Don't scare me like that!\""


translate english e1213_69dcbc5d:



    voice "voice/e12/1300020a01.opus"
    mx "\"Wow, rude much?\""


translate english e1213_6e5b3b8c:



    voice "voice/e12/1300030a01.opus"
    mx "\"And here I let you borrow my phone so you could spend a little time with Aoi.\""


translate english e1213_72403086:



    voice "voice/e12/1300040a01.opus"
    mx "\"Oh, I get it... Were you in the middle of a sex scene or something?\""


translate english e1213_f696af49:


    xy "\"N-No! Of course not!\""


translate english e1213_c8e2d9e2:



    voice "voice/e12/1300050a01.opus"
    mx "\"You sure about that?\""


translate english e1213_54b2dce6:


    xy "\"......Nngh...\""


translate english e1213_238ae1d9:



    voice "voice/e12/1300060a01.opus"
    mx "\"Well, whatever. I'll let you off easy today.\""


translate english e1213_1535b472:



    voice "voice/e12/1300070a01.opus"
    mx "\"Now you understand, right?\""


translate english e1213_c0ccbedf:



    voice "voice/e12/1300080a01.opus"
    mx "\"Aoi is just a heroine in a visual novel. She's not real.\""


translate english e1213_8b540364:


    "...¿De dónde salió eso?"


translate english e1213_5413882d:


    xy "\"Well, yeah, obviously!\""


translate english e1213_78854a01:



    voice "voice/e12/1300090a01.opus"
    mx "\"Good.\""


translate english e1213_d1e82bf8:



    voice "voice/e12/1300100a01.opus"
    mx "\"I trust YOU.\""


translate english e1213_4b69bdce:


    "Sonríe y me palmea el hombro."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
