

translate english e1213_59d247dd:



    voice "voice/e12/1300010a01.opus"
    mx "\"¿Divirtiéndote?\""


translate english e1213_59f9c40e:


    xy "\"¡Uoh!\""


translate english e1213_3a6fe296:


    "Oigo una voz repentina detrás de mí y casi salto del susto."


translate english e1213_b741704f:


    xy "\"¡No me asustes así!\""


translate english e1213_69dcbc5d:



    voice "voice/e12/1300020a01.opus"
    mx "\"Uy, qué grosero.\""


translate english e1213_6e5b3b8c:



    voice "voice/e12/1300030a01.opus"
    mx "\"Y yo que te presté mi teléfono para que pasaras un ratito con Aoi.\""


translate english e1213_72403086:



    voice "voice/e12/1300040a01.opus"
    mx "\"Ah, ya entiendo... ¿Estabas en medio de una escena de sexo o algo así?\""


translate english e1213_f696af49:


    xy "\"¡N-No! ¡Claro que no!\""


translate english e1213_c8e2d9e2:



    voice "voice/e12/1300050a01.opus"
    mx "\"¿Estás seguro?\""


translate english e1213_54b2dce6:


    xy "\"......Nngh...\""


translate english e1213_238ae1d9:



    voice "voice/e12/1300060a01.opus"
    mx "\"Bueno, da igual. Hoy te dejaré pasar.\""


translate english e1213_1535b472:



    voice "voice/e12/1300070a01.opus"
    mx "\"Ahora ya lo entiendes, ¿verdad?\""


translate english e1213_c0ccbedf:



    voice "voice/e12/1300080a01.opus"
    mx "\"Aoi es solo una heroína de una novela visual. No es real.\""


translate english e1213_8b540364:


    "...¿De dónde salió eso?"


translate english e1213_5413882d:


    xy "\"¡Pues sí, obviamente!\""


translate english e1213_78854a01:



    voice "voice/e12/1300090a01.opus"
    mx "\"Bien.\""


translate english e1213_d1e82bf8:



    voice "voice/e12/1300100a01.opus"
    mx "\"Confío en TI.\""


translate english e1213_4b69bdce:


    "Sonríe y me palmea el hombro."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
