

translate english a7212a_57b3b55f:



    voice "voice/a72/12a00010a01.opus"
    mx "\"Will you... take my virginity?\""


translate english a7212a_240c3e06:


    "A su petición, pongo una mano alrededor de mi verga y la guío hasta su entrada."


translate english a7212a_765c6f0b:


    "Antes de poder meter la punta—"


translate english a7212a_b1946fa6:



    voice "voice/a72/12a00020a01.opus"
    mx "\"Nn... nnn...\""


translate english a7212a_c2029096:


    xy "\"Just relax, Miyuki.\""


translate english a7212a_0baf883f:



    voice "voice/a72/12a00030a01.opus"
    mx "\"Oh... Sorry!\""


translate english a7212a_aea172fd:



    voice "voice/a72/12a00040a01.opus"
    mx "\"Um... How's this...?\""


translate english a7212a_4244078e:


    "Empujo contra ella, pero sus labios permanecen firmemente sellados, negándome la entrada."


translate english a7212a_3cf145fa:


    xy "\"Hmm... You're still a bit too tight.\""


translate english a7212a_1f00e12b:



    voice "voice/a72/12a00050a01.opus"
    mx "\"I guess I'm just... nervous...\""


translate english a7212a_57703c50:


    xy "\"Even though we're not onstage?\""


translate english a7212a_01b1f8b6:



    voice "voice/a72/12a00060a01.opus"
    mx "\"This isn't just another rehearsal, you know! Stupid!\""


translate english a7212a_d34cf220:


    "La expresión de su cara realmente me transporta al pasado..."


translate english a7212a_84226a90:


    xy "\"I love you for who you are.\""


translate english a7212a_7cbcd2ba:


    xy "\"And I wanna keep the real you all to myself.\""


translate english a7212a_93032958:



    voice "voice/a72/12a00070a01.opus"
    mx "\"Shinichi...?\""


translate english a7212a_752e03c1:



    voice "voice/a72/12a00080a01.opus"
    mx "\"Wh-Where did THAT come from?!\""


translate english a7212a_a2d06511:



    voice "voice/a72/12a00090a01.opus"
    mx "\"Warn me before you say stuff like that... My heart can't take it... you jerk!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
