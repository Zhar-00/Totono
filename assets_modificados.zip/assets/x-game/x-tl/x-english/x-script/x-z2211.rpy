

translate english z2211_15833a7d:



    voice "voice/z22/1100010a01.opus"
    mx "¡Feliz año nuevo!"


translate english z2211_e80ad671:



    voice "voice/z22/1100020a01.opus"
    mx "Hagamos de este año uno genial."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
