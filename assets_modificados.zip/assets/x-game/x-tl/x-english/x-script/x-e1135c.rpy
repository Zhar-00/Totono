

translate english e1135c_2db18ccf:


    "Me mira con tristeza..."


translate english e1135c_c59fbf1f:


    "...y me veo atraído a su mirada."


translate english e1135c_7cdcd21b:



    voice "voice/e11/35c00010a01.opus"
    mx "\"Esa noche...\""


translate english e1135c_75108e8e:



    voice "voice/e11/35c00020a01.opus"
    mx "\"...descubrí cómo modificar el universo.\""


translate english e1135c_52751fa4:


    "Una repentina ráfaga de viento se levanta."


translate english e1135c_9fe2165d:


    "Miro hacia arriba y encuentro oscuras nubes de tormenta arremolinándose en el cielo sobre nosotros donde antes solo había un atardecer."


translate english e1135c_8d381b60:



    voice "voice/e11/35c00030a01.opus"
    mx "\"Era la primera vez que programaba algo.\""


translate english e1135c_89a12ccc:



    voice "voice/e11/35c00040a01.opus"
    mx "\"Y necesitaba tiempo para descifrarlo.\""


translate english e1135c_a521faba:



    voice "voice/e11/35c00050a01.opus"
    mx "\"Así que empecé por tomarte como cautivo.\""


translate english e1135c_cdde9d57:


    xy "\"¿Que hiciste qué...?\""


translate english e1135c_77c6a319:


    "No puedo empezar a procesar lo que está diciendo."


translate english e1135c_3a1c551f:


    "Espera..."


translate english e1135c_888c799b:


    "¿Está Miyuki empezando a difuminar las líneas entre la ficción y la realidad...?"


translate english e1135c_73c40d6c:



    voice "voice/e11/35c00060a01.opus"
    mx "\"Con la ayuda de Dios, hice una droga que podía difuminar la línea entre la ficción y la realidad.\""


translate english e1135c_f4a8080d:



    voice "voice/e11/35c00070a01.opus"
    mx "\"¿Recuerdas todas esas veces en que de repente te daba sueño?\""


translate english e1135c_fcf0aaf1:



    voice "voice/e11/35c00080a01.opus"
    mx "\"Confundiste los eventos del juego con eventos de la vida real.\""


translate english e1135c_be0b4cc1:



    voice "voice/e11/35c00090a01.opus"
    mx "\"Y creíste que Aoi era solo un personaje de videojuego.\""


translate english e1135c_5797a8c4:


    "Esto son palabras de locos."


translate english e1135c_aa7cf251:


    "Normalmente simplemente me habría reído de todo."


translate english e1135c_2e2389ba:


    "Pero... algo no está bien."


translate english e1135c_e72533ff:


    "Algo está... pasando."


translate english e1135c_019ce32f:


    "Algo más allá del reino de mi comprensión—"


translate english e1135c_373aaa99:



    voice "voice/e11/35c00100a01.opus"
    mx "\"Podemos ser felices juntos, solo nosotros dos.\""


translate english e1135c_5f75b42e:



    voice "voice/e11/35c00110a01.opus"
    mx "\"No tenemos nada que temer.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
