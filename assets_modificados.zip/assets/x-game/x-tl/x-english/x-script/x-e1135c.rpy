

translate english e1135c_2db18ccf:


    "Me mira con tristeza..."


translate english e1135c_c59fbf1f:


    "...y me veo atraído a su mirada."


translate english e1135c_7cdcd21b:



    voice "voice/e11/35c00010a01.opus"
    mx "\"That night...\""


translate english e1135c_75108e8e:



    voice "voice/e11/35c00020a01.opus"
    mx "\"...I discovered how to modify the universe.\""


translate english e1135c_52751fa4:


    "Una repentina ráfaga de viento se levanta."


translate english e1135c_9fe2165d:


    "Miro hacia arriba y encuentro oscuras nubes de tormenta arremolinándose en el cielo sobre nosotros donde antes solo había un atardecer."


translate english e1135c_8d381b60:



    voice "voice/e11/35c00030a01.opus"
    mx "\"It was my first time programming anything.\""


translate english e1135c_89a12ccc:



    voice "voice/e11/35c00040a01.opus"
    mx "\"And I needed time to figure it out.\""


translate english e1135c_a521faba:



    voice "voice/e11/35c00050a01.opus"
    mx "\"So I started by taking you captive.\""


translate english e1135c_cdde9d57:


    xy "\"You what...?\""


translate english e1135c_77c6a319:


    "No puedo empezar a procesar lo que está diciendo."


translate english e1135c_3a1c551f:


    "Espera..."


translate english e1135c_888c799b:


    "¿Está Miyuki empezando a difuminar las líneas entre la ficción y la realidad...?"


translate english e1135c_73c40d6c:



    voice "voice/e11/35c00060a01.opus"
    mx "\"With God's help, I made a drug that could blur the lines between fiction and reality.\""


translate english e1135c_f4a8080d:



    voice "voice/e11/35c00070a01.opus"
    mx "\"Remember all those times you'd suddenly get sleepy?\""


translate english e1135c_fcf0aaf1:



    voice "voice/e11/35c00080a01.opus"
    mx "\"You mistook the events of the game for events in real life.\""


translate english e1135c_be0b4cc1:



    voice "voice/e11/35c00090a01.opus"
    mx "\"And you believed Aoi was just a video game character.\""


translate english e1135c_5797a8c4:


    "Esto son palabras de locos."


translate english e1135c_aa7cf251:


    "Normalmente simplemente me habría reído de todo."


translate english e1135c_2e2389ba:


    "Pero... algo no está bien."


translate english e1135c_e72533ff:


    "Algo está... pasando."


translate english e1135c_019ce32f:


    "Algo más allá del reino de mi comprensión—"


translate english e1135c_373aaa99:



    voice "voice/e11/35c00100a01.opus"
    mx "\"We can be happy together, just the two of us.\""


translate english e1135c_5f75b42e:



    voice "voice/e11/35c00110a01.opus"
    mx "\"We have nothing to fear.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
