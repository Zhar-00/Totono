

translate english a5122_741e4800:



    voice "voice/a51/2200010a01.opus"
    mx "\"\"......!\"\""


translate english a5122_574461b4:


    "Estamos completamente solos junto al escenario."


translate english a5122_d57bba86:


    "Miyuki me mira fijamente a los ojos."


translate english a5122_34c711f0:



    voice "voice/a22/1100010a01.opus"
    mx "\"There's going to be...}"


translate english a5122_958cd961:


    voice "voice/a22/1100020a01.opus"



translate english a5122_646f0cf4:


    extend "un beso.\""



translate english a5122_9c2ecd65:



    voice "voice/a51/2200080a01.opus"
    mx "\"Shinichi...\""


translate english a5122_28f47eed:



    voice "voice/a51/2200090a01.opus"
    mx "\"You're hiding something from me about Aoi, aren't you?\""


translate english a5122_b66eddd1:


    xy "\"Me? Hiding something?\""


translate english a5122_5f3d8b6d:


    "Vale, entonces esto no es por el incidente de anoche, supongo..."


translate english a5122_7ebf2af8:



    voice "voice/a51/2200100a01.opus"
    mx "\"That night!\""


translate english a5122_aa87bec1:



    voice "voice/a51/2200110a01.opus"
    mx "\"That night in the rain, when we found Aoi here... You figured it out somehow, right? What did you go back to your house for?\""


translate english a5122_8b8f6876:


    xy "\"Huh? ...Oh, right!\""


translate english a5122_a0535a72:


    "Dios... Si le digo que estaba buscando pistas en un videojuego, me va a dar una paliza..."


translate english a5122_41c57be2:



    voice "voice/a51/2200120a01.opus"
    mx "\"Tell me this instant!\""


translate english a5122_24b5d64a:


    xy "\"...I went back to play a video game.\""


translate english a5122_5e6cb24d:



    voice "voice/a51/2200130a01.opus"
    mx "\"A video game?\""


translate english a5122_1632f7df:


    xy "\"Aoi's acting out scenes from a mobile game. She's been doing it ever since we first met.\""


translate english a5122_04df9194:



    voice "voice/a51/2200140a01.opus"
    mx "\"So you used that game to predict the future?\""


translate english a5122_215521aa:


    xy "\"I wasn't actually expecting her to be in here! I guess she's just REALLY dedicated to the game script.\""


translate english a5122_c4957a00:



    voice "voice/a51/2200150a01.opus"
    mx "\"Haah...\""


translate english a5122_4f879f65:


    "Miyuki suelta un suspiro pesado."


translate english a5122_3472c103:



    voice "voice/a51/2200160a01.opus"
    mx "\"And she adopts a cat in the game?\""


translate english a5122_88c635c6:


    xy "\"Yeah. You know when we found Eru? I swear, it was almost like a 1:1 reproduction—\""


translate english a5122_5b7a4154:



    voice "voice/a51/2200170a01.opus"
    mx "\"Reciting lines is one thing. And cat ears aren't hard to come by.\""


translate english a5122_8c5b2b2e:



    voice "voice/a51/2200180a01.opus"
    mx "\"But what about the cat?\""


translate english a5122_bb58c512:


    xy "\"Huh? ...Oh, right!\""


translate english a5122_ee9a1567:



    voice "voice/a51/2200190a01.opus"
    mx "\"The kitten. Eru.\""


translate english a5122_5c02ea24:


    xy "\"Oh, well, I was worried about leaving the little thing all by itself in my house, so I brought him to school. I'm letting him hang out up on the roof for now, and—\""


translate english a5122_d74c1f46:



    voice "voice/a51/2200200a01.opus"
    mx "\"Not that!\""


translate english a5122_956dabdb:



    voice "voice/a51/2200210a01.opus"
    mx "\"What I mean is, how did she 'just happen' to find a stray cat?\""


translate english a5122_02aaf7b3:



    voice "voice/a51/2200220a01.opus"
    mx "\"Did she go out of her way to get one from a shelter just so she could act out a scene from the game?\""


translate english a5122_06edadb5:


    xy "\"Oh... well...\""


translate english a5122_4c7d337e:


    "Tiene razón."


translate english a5122_8bd17cf9:


    "No me imagino que Aoi llegara tan lejos."


translate english a5122_e7be471e:


    xy "\"Maybe it was a coincidence...?\""


translate english a5122_e4623736:



    voice "voice/a51/2200230a01.opus"
    mx "\"A coincidence? Really?\""


translate english a5122_1bff15b3:


    xy "\"Maybe God answered her prayers...?\""


translate english a5122_4220f78d:



    voice "voice/a51/2200240a01.opus"
    mx "\"......!\""


translate english a5122_eef96bc4:


    xy "\"Miyuki, wait! Where are you g—\""


translate english a5122_9ce1078f:



    voice "voice/a51/2200250a01.opus"
    mx "\"Home.\""


translate english a5122_e30fa301:



    voice "voice/a51/2200260a01.opus"
    mx "\"I need to check something. I'll call you later.\""


translate english a5122_b45ce086:


    xy "\"When is 'later'?\""


translate english a5122_ce98c44d:


    xy "\"...The heck is her deal?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
