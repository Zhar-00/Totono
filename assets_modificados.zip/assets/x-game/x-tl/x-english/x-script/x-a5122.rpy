

translate english a5122_741e4800:



    voice "voice/a51/2200010a01.opus"
    mx "\"\"......!\"\""


translate english a5122_574461b4:


    "Estamos completamente solos junto al escenario."


translate english a5122_d57bba86:


    "Miyuki me mira fijamente a los ojos."


translate english a5122_34c711f0:



    voice "voice/a22/1100010a01.opus"
    mx "\"Va a haber...}"


translate english a5122_958cd961:


    voice "voice/a22/1100020a01.opus"



translate english a5122_646f0cf4:


    extend "un beso.\""



translate english a5122_9c2ecd65:



    voice "voice/a51/2200080a01.opus"
    mx "\"Shinichi...\""


translate english a5122_28f47eed:



    voice "voice/a51/2200090a01.opus"
    mx "\"Me estás ocultando algo sobre Aoi, ¿verdad?\""


translate english a5122_b66eddd1:


    xy "\"¿Yo? ¿Ocultar algo?\""


translate english a5122_5f3d8b6d:


    "Vale, entonces esto no es por el incidente de anoche, supongo..."


translate english a5122_7ebf2af8:



    voice "voice/a51/2200100a01.opus"
    mx "\"¡Esa noche!\""


translate english a5122_aa87bec1:



    voice "voice/a51/2200110a01.opus"
    mx "\"Esa noche bajo la lluvia, cuando encontramos a Aoi aquí... De alguna forma lo dedujiste, ¿verdad? ¿Para qué volviste a tu casa?\""


translate english a5122_8b8f6876:


    xy "\"¿Eh? ...¡Ah, cierto!\""


translate english a5122_a0535a72:


    "Dios... Si le digo que estaba buscando pistas en un videojuego, me va a dar una paliza..."


translate english a5122_41c57be2:



    voice "voice/a51/2200120a01.opus"
    mx "\"¡Dímelo ahora mismo!\""


translate english a5122_24b5d64a:


    xy "\"...Volví para jugar un videojuego.\""


translate english a5122_5e6cb24d:



    voice "voice/a51/2200130a01.opus"
    mx "\"¿Un videojuego?\""


translate english a5122_1632f7df:


    xy "\"Aoi está actuando escenas de un juego para celular. Lo ha estado haciendo desde que nos conocimos.\""


translate english a5122_04df9194:



    voice "voice/a51/2200140a01.opus"
    mx "\"¿Así que usaste ese juego para predecir el futuro?\""


translate english a5122_215521aa:


    xy "\"¡En realidad no esperaba que estuviera aquí! Supongo que está REALMENTE dedicada al guion del juego.\""


translate english a5122_c4957a00:



    voice "voice/a51/2200150a01.opus"
    mx "\"Haah...\""


translate english a5122_4f879f65:


    "Miyuki suelta un suspiro pesado."


translate english a5122_3472c103:



    voice "voice/a51/2200160a01.opus"
    mx "\"¿Y adopta un gato en el juego?\""


translate english a5122_88c635c6:


    xy "\"Sí. ¿Sabes cuando encontramos a Eru? Te juro que fue casi como una reproducción exacta...\""


translate english a5122_5b7a4154:



    voice "voice/a51/2200170a01.opus"
    mx "\"Recitar líneas es una cosa. Y las orejas de gato no son difíciles de conseguir.\""


translate english a5122_8c5b2b2e:



    voice "voice/a51/2200180a01.opus"
    mx "\"¿Pero y el gato?\""


translate english a5122_bb58c512:


    xy "\"¿Eh? ...¡Ah, cierto!\""


translate english a5122_ee9a1567:



    voice "voice/a51/2200190a01.opus"
    mx "\"El gatito. Eru.\""


translate english a5122_5c02ea24:


    xy "\"Ah, bueno, me preocupaba dejar a la cosita sola en mi casa, así que lo traje a la escuela. Por ahora lo estoy dejando estar arriba, en el techo, y...\""


translate english a5122_d74c1f46:



    voice "voice/a51/2200200a01.opus"
    mx "\"¡No eso!\""


translate english a5122_956dabdb:



    voice "voice/a51/2200210a01.opus"
    mx "\"Lo que digo es, ¿cómo 'de casualidad' encontró un gato callejero?\""


translate english a5122_02aaf7b3:



    voice "voice/a51/2200220a01.opus"
    mx "\"¿Acaso se molestó en conseguir uno de un refugio solo para poder actuar una escena del juego?\""


translate english a5122_06edadb5:


    xy "\"Oh... bueno...\""


translate english a5122_4c7d337e:


    "Tiene razón."


translate english a5122_8bd17cf9:


    "No me imagino que Aoi llegara tan lejos."


translate english a5122_e7be471e:


    xy "\"¿Quizá fue coincidencia...?\""


translate english a5122_e4623736:



    voice "voice/a51/2200230a01.opus"
    mx "\"¿Una coincidencia? ¿En serio?\""


translate english a5122_1bff15b3:


    xy "\"¿Quizá Dios respondió sus plegarias...?\""


translate english a5122_4220f78d:



    voice "voice/a51/2200240a01.opus"
    mx "\"......!\""


translate english a5122_eef96bc4:


    xy "\"¡Miyuki, espera! ¿A dónde va...\""


translate english a5122_9ce1078f:



    voice "voice/a51/2200250a01.opus"
    mx "\"A casa.\""


translate english a5122_e30fa301:



    voice "voice/a51/2200260a01.opus"
    mx "\"Necesito revisar algo. Te llamo después.\""


translate english a5122_b45ce086:


    xy "\"¿Cuándo es 'después'?\""


translate english a5122_ce98c44d:


    xy "\"...¿Qué diablos le pasa?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
