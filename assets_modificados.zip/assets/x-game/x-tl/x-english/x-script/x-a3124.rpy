

translate english a3124_0f53f776:


    "Sus ojos brillan con un destello sobrenatural."


translate english a3124_14ea5d4a:


    xy "\"Huh...?\""


translate english a3124_3f2674aa:


    "De repente, algo se siente mal."


translate english a3124_492c22f7:


    "Levanto la vista y encuentro nubes oscuras arremolinándose en el cielo sobre nosotros."


translate english a3124_77064198:


    "Hace unos momentos era un día perfectamente soleado... pero ahora vientos tempestuosos corren a nuestro alrededor."


translate english a3124_399bdfcf:


    "Se siente como si el tiempo mismo fuera succionado hacia un portal de otro mundo, dejándonos atrapados en el purgatorio entre el crepúsculo y la noche."


translate english a3124_b2e67c4a:


    "El mundo se derrumba."


translate english a3124_e7c11160:


    "La coraza protectora se desprende y la frontera titubea, amenazando con revelar lo que hay más allá—"



translate english a3124_ce39032c:



    voice "voice/a31/2400010a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english a3124_d53d7abc:


    xy "\"Aoi...?\""


translate english a3124_533925da:


    xy "\"What are you doing?\""


translate english a3124_3faa0e86:



    voice "voice/a31/2400020a02.opus"
    aoi "\"Boop boop...\""


translate english a3124_db36e4cb:



    voice "voice/a31/2400030a02.opus"
    aoi "\"Collected a bunch of Shinichi event CGs.\""


translate english a3124_35add8dc:



    voice "voice/a31/2400040a02.opus"
    aoi "\"Recharge complete. Now Aoi can transmit to God... and then...\""


translate english a3124_007ade3b:



    voice "voice/a31/2400050a02.opus"
    aoi "\"The universe will get an update patch.\""


translate english a3124_a9bd5839:


    "¿Una... actualización...?"


translate english a3124_50cab6bf:


    "¿Como el tipo de cosa que un programa de computadora descargaría de internet?"


translate english a3124_cab5edc5:



    voice "voice/a31/2400060a02.opus"
    aoi "\"The way things are going, the plot is going to break down.\""


translate english a3124_313b1f04:



    voice "voice/a31/2400070a02.opus"
    aoi "\"Shinichi and Miyuki won't end up together.\""


translate english a3124_69b95176:



    voice "voice/a31/2400080a02.opus"
    aoi "\"And that's no good.\""


translate english a3124_7be37146:



    voice "voice/a31/2400090a02.opus"
    aoi "\"So Aoi will have God overwrite the universe.\""


translate english a3124_4598b16a:



    voice "voice/a31/2400100a02.opus"
    aoi "\"That way Miyuki will never end up with anyone else.\""


translate english a3124_bb67c92f:



    voice "voice/a31/2400110a02.opus"
    aoi "\"That way you won't get cucked.\""


translate english strings:


    old "Остановить её"
    new "Detenerla"


    old "Позволить ей сделать это"
    new "Dejarla hacerlo"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
