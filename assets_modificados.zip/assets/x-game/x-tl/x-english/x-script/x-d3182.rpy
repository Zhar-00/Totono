

translate english d3182_51984f6f:


    xy "\"...The hell am I thinking?\""


translate english d3182_74b6aea2:


    "Finalmente, vuelvo a mis sentidos."


translate english d3182_5862819c:


    "¿Estoy considerando en serio entrar a escondidas al recinto escolar de noche para buscar a Aoi solo porque un videojuego me dijo que podría estar aquí?"


translate english d3182_f65c6125:


    "Dios, soy tan estúpido."


translate english d3182_8f7c2caf:


    "¿Cómo se las arreglaría Aoi para colarse al campus con un gatito?"


translate english d3182_e486e877:


    xy "\"...No chance.\""


translate english d3182_5472d897:


    "Me doy la vuelta y me dirijo a casa."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
