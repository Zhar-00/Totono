

translate english e1212_e6ef3bc7:



    voice "voice/e12/1200010a02.opus"
    aoi "\"Mmph... shhllpp... shllppp... mmllpp... shllpp... sslllrrrppp...!\""


translate english e1212_db99f715:


    "...Mmm...? ¿Qué es ese sonido...?"


translate english e1212_23390ff3:



    voice "voice/e12/1200020a02.opus"
    aoi "\"Slrppp... mmllpp... mmh... mmh... mmph... slrrpp... rrpp... rrppp!!!\""


translate english e1212_143903d0:



    voice "voice/e12/1200030a02.opus"
    aoi "\"Mmllpp... ¿Bip bip?\""


translate english e1212_5c2fde1c:



    voice "voice/e12/1200040a02.opus"
    aoi "\"¿Shinichi? ¿Estás despierto, miau?\""


translate english e1212_37204e3f:


    xy "\"¿Qué estás haciendo?\""


translate english e1212_a17c6589:



    voice "voice/e12/1200050a02.opus"
    aoi "\"Lamiendo tu verga, miau.\""


translate english e1212_4c777630:


    xy "\"¿Qué pasa con el... ya sabes... el atuendo?\""


translate english e1212_698bc35a:



    voice "voice/e12/1200060a02.opus"
    aoi "\"¿Las orejas de gato, miau?\""


translate english e1212_a84f087f:


    xy "\"Sí. ¿Por qué las llevas puestas?\""


translate english e1212_07658b95:



    voice "voice/e12/1200070a02.opus"
    aoi "\"Porque es lindo, miau.\""


translate english e1212_ffee14ff:


    "Quiero decir, sí, SÍ es lindo..."


translate english e1212_d9acc737:



    voice "voice/e12/1200080a02.opus"
    aoi "\"¿Conseguiste un CG nuevo, miau?\""


translate english e1212_d61f4c9e:


    xy "\"Tú y tu cerebro de gamer... ¡Guau, oye!\""


translate english e1212_7f096d31:



    voice "voice/e12/1200090a02.opus"
    aoi "\"Sllrrpp... sllrrr... slrrp! Mmm... ¡Phaah! ¡Está tan rico, miau!\""


translate english e1212_ba64b861:



    voice "voice/e12/1200100a02.opus"
    aoi "\"¡Dame tu leche, miau!\""


translate english e1212_1637a25f:


    xy "\"¿Mi... leche...?\""


translate english e1212_992f656d:



    voice "voice/e12/1200110a02.opus"
    aoi "\"La gatita tiene hambre, miau.\""


translate english e1212_d59fbfb6:



    voice "voice/e12/1200120a02.opus"
    aoi "\"La gatita quiere esa leche caliente... ¡Mmmph!\""


translate english e1212_9107c696:


    "...Así que ESO es lo que busca."


translate english e1212_d8d26ae8:



    voice "voice/e12/1200130a02.opus"
    aoi "\"Has estado tan distante conmigo últimamente, miau. No me prestas nada de atención, miau.\""


translate english e1212_b565422c:



    voice "voice/e12/1200140a02.opus"
    aoi "\"Cualquier chica normal iría a buscar a otro tipo, miau.\""


translate english e1212_feb2052e:


    xy "\"Perdón... Es que he estado tan ocupado con el club de teatro estos días...\""


translate english e1212_96b450bc:



    voice "voice/e12/1200150a02.opus"
    aoi "\"Sin excusas, miau. Mmllpp... ¡mmmh!\""


translate english e1212_671e7d18:


    xy "\"¡¿Nnng?!\""


translate english e1212_b6ea7cf3:


    "Un dolor agudo me atraviesa la ingle, y suelto un grito de sorpresa."


translate english e1212_cfa2031a:


    xy "\"¡Sin dientes! ¡No lo muerdas!\""


translate english e1212_69443246:



    voice "voice/e12/1200160a02.opus"
    aoi "\"Solo un mordisquito, miau. Este es tu castigo por ser un idiota, miau.\""


translate english e1212_a6301f3d:



    voice "voice/e12/1200170a02.opus"
    aoi "\"Si quieres mantener tu verga de una pieza, suelta esa leche.\""


translate english e1212_36c47219:


    "¿¡Eso es una amenaza?!?"


translate english e1212_d9e2fa10:



    voice "voice/e12/1200180a02.opus"
    aoi "\"¿Mmmm? ¿Por qué se está ablandando, miau?\""


translate english e1212_234de3ec:


    "¿¡Por qué crees, genio?!?"


translate english e1212_ef168ec9:



    voice "voice/e12/1200190a02.opus"
    aoi "\"Mmllpp... lllppphhh... shhllpp... slrrpp... shhllpp!\""


translate english e1212_faa81ce5:



    voice "voice/e12/1200200a02.opus"
    aoi "\"Mmmph... shhllpp... sllrrppp! Mmmph... sllrrpp... ssslllrrrrpppp!\""


translate english e1212_2fceb9ea:



    voice "voice/e12/1200210a02.opus"
    aoi "\"Se está poniendo duro otra vez, miau...\""


translate english e1212_3e812fd5:


    "Chupa vigorosamente para revivir mi erección."


translate english e1212_97c59cff:



    voice "voice/e12/1200220a02.opus"
    aoi "\"Ahora solo ven, miau. Aoi quiere esa leche de verga, miau.\""


translate english e1212_0accd139:


    xy "\"\"\"......!!!\"¿Hmm?\"\""


translate english e1212_dcbabb74:


    "...Qué raro..."


translate english e1212_f09f36fa:


    "Aoi es definitivamente linda, y podría verme acabando bastante rápido si bajo la guardia..."


translate english e1212_37b526d7:


    "No está nada mal despertar con una mamada... y sin embargo, por alguna razón, no estoy del todo satisfecho..."


translate english e1212_11c0754b:


    xy "\"......¿Hmm?\""


translate english e1212_a37901dc:


    "Detrás de ella, puedo ver algo moviéndose arriba y abajo."


translate english e1212_4e6a28d2:


    "¿Eso es... una cola...?"


translate english e1212_68a6c0cc:



    voice "voice/e12/1200230a02.opus"
    aoi "\"Mmmh... mmmh... miau... mmm... ssllrrpp... sslllrrppp... miau... ¡mmm!\""


translate english e1212_2609ef3f:



    voice "voice/e12/1200240a02.opus"
    aoi "\"Shinichi, tus bolas se están apretando... ¿Vas a venir pronto, miau? ¿Ahora, purrhaps?\""


translate english e1212_76f045a7:


    xy "\"Oh, definitivamente me estoy acercando...\""


translate english e1212_eb3c415f:


    xy "\"¡Pero me interesa más ESTO!\""


translate english e1212_d9041a87:



    voice "voice/e12/1200250a02.opus"
    aoi "\"¡¡¡MIAAAAAUUUUU!!!\""


translate english e1212_99e3d5a1:


    "Extiendo la mano y agarro su cola."


translate english e1212_792d0d4a:



    voice "voice/e12/1200260a02.opus"
    aoi "\"¡N-No toques eso, miau!\""


translate english e1212_2e67c8bd:



    voice "voice/e12/1200270a02.opus"
    aoi "\"No es de buena educación tocar la cola de una gatita— ¡¡¡MIAAAAAUUUUU!!!\""


translate english e1212_c2f1653f:



    voice "voice/e12/1200280a02.opus"
    aoi "\"Miiiiaaauuu...\""


translate english e1212_769df0b4:


    "Aoi pierde el equilibrio y se derrumba sobre la cama."


translate english e1212_e39e8d6a:


    "Me muevo para quedar ahora yo encima de ella, y agarro su cola con fuerza."


translate english e1212_5417b407:


    "Puedo ver una cadena de cuentas en su base... subiendo directamente por su ojete."


translate english e1212_a0cfa600:


    xy "\"¿Qué pasa cuando toco tu cola?\""


translate english e1212_9b4ad638:



    voice "voice/e12/1200290a02.opus"
    aoi "\"Bueno... mi cola... emm... Es mi punto débil, miau... Así que cada vez que la tocas así...\""


translate english e1212_89cd1601:


    xy "\"¿Así, dices?\""


translate english e1212_ba1a1a82:



    voice "voice/e12/1200300a02.opus"
    aoi "\"¡Miiiiau! ¡Miau! ¡Basta! ¡Basta eso, miau! ¡No puedes moverla así!!!\""


translate english e1212_fa5dd4bb:


    xy "\"¿Por qué? ¿Duele?\""


translate english e1212_dbca83c4:



    voice "voice/e12/1200310a02.opus"
    aoi "\"Miau...\""


translate english e1212_fd1b4b1e:


    "Suelto de inmediato."


translate english e1212_149bd5e0:


    xy "\"Si duele, paro.\""


translate english e1212_658ffe09:



    voice "voice/e12/1200320a02.opus"
    aoi "\"Nn... nnn... Eres un abusón...\""


translate english e1212_8c89b0f6:


    "Parece estar al borde de las lágrimas."


translate english e1212_73d351ea:



    voice "voice/e12/1200330a02.opus"
    aoi "\"No duele, miau...\""


translate english e1212_838935c1:



    voice "voice/e12/1200340a02.opus"
    aoi "\"Se siente bien... pero es tan intenso que me marea, miau.\""


translate english e1212_84cd0312:


    xy "\"Eso explica por qué estás tan mojada.\""


translate english e1212_4941958b:


    "No la he tocado el coño en absoluto—en ABSOLUTO—y ya está hinchado y goteando."


translate english e1212_cd957d8b:


    xy "\"Bueno, entonces, ya que estamos—\""


translate english e1212_269f721b:



    voice "voice/e12/1200350a02.opus"
    aoi "\"¿Miau...? ¡Ah! ¿Qué estás haciendo? Restregando... tu verga... contra mí...\""


translate english e1212_99dadb37:



    voice "voice/e12/1200360a02.opus"
    aoi "\"¡MIAAAAAUUUUU—! ¡Miau! ¡Miau! ¡Miau—Nnnng!!!\""


translate english e1212_980cc70f:



    voice "voice/e12/1200370a02.opus"
    aoi "\"La verga de Shinichi... ¡Nnhaah! Está—dentro de mí—¡miau!!!\""


translate english e1212_ee81ef6d:


    "Incluso sin ningún preludio, el coño de Aoi me recibe ansiosamente."


translate english e1212_50848515:


    xy "\"Dijiste que tienes hambre de leche, ¿no?\""


translate english e1212_a9a0c18f:



    voice "voice/e12/1200380a02.opus"
    aoi "\"No era esa boca la que decía, miau...\""


translate english e1212_5c6079d9:


    xy "\"¿Entonces no la quieres?\""


translate english e1212_4ffca835:



    voice "voice/e12/1200390a02.opus"
    aoi "\"Miau—¡Nnnnn...! ¡Eres un abusón, miau!\""


translate english e1212_dc787293:


    "Aoi me mira fijamente por un momento."


translate english e1212_29f405d1:



    voice "voice/e12/1200400a02.opus"
    aoi "\"¡Nn... nnn! ¡Nnn! ¡Nnn!\""


translate english e1212_c020eca7:


    "Se aprieta sobre mí y empieza a mover sus caderas."


translate english e1212_74993749:



    voice "voice/e12/1200410a02.opus"
    aoi "\"¡Dame tu leche de verga! ¡¡¡Nnnn!!! ¡Inúndame—ahora miau!!!\""


translate english e1212_c72b20f9:



    voice "voice/e12/1200420a02.opus"
    aoi "\"Aoi va a—usar su coño—para hacerte venir, miau... ¡Aaaahh!\""


translate english e1212_9187a0c6:


    "Está poniendo tanto esfuerzo en esto... ¡mejor le echo una mano!"


translate english e1212_790d4a2e:


    "Levanto su pierna y la penetro profundamente, hasta el fondo."


translate english e1212_148c734c:



    voice "voice/e12/1200430a02.opus"
    aoi "\"¡¡¡MIAAAAAUUUUU...!!!\""


translate english e1212_9d73ef99:



    voice "voice/e12/1200440a02.opus"
    aoi "\"Ay, Dios... ¡miau...! ¡Está tan profundo... Muy, muy profundo...!\""


translate english e1212_1b1a3318:



    voice "voice/e12/1200450a02.opus"
    aoi "\"¡Tu... verga... está... golpeando... bien adentro de mí...!\""


translate english e1212_77db234f:



    voice "voice/e12/1200460a02.opus"
    aoi "\"¡¡¡HAAAAAAHH! ¡Aah! ¡Aah, aah, aah! ¡A-Así no, miau! ¡Es demasiado intenso!!!\""


translate english e1212_4787d10b:



    voice "voice/e12/1200470a02.opus"
    aoi "\"¡Se siente! ¡Como si! ¡Estuvieras! ¡Devastando! ¡Todo mi interior—! ¡¡¡AAAHH!!!\""


translate english e1212_8c187458:


    "Debe ser realmente intenso."


translate english e1212_b620a884:


    "Puedo sentir su espasmo cada vez que mi longitud golpea sus partes más profundas."


translate english e1212_663674ce:



    voice "voice/e12/1200480a02.opus"
    aoi "\"¡Haahh! ¡Aah! ¡Aah! ¡Aah! ¡Aah! ¡Ay, Dios! ¡Shinichi! ¡Se siente tan bien!\""


translate english e1212_d0e5a546:



    voice "voice/e12/1200490a02.opus"
    aoi "\"¡No pares! ¡Sigue! ¡Aaaahh! ¡Aoi va a... va a venir—!\""


translate english e1212_c2baba7d:


    xy "\"¿Cuál es la prisa?\""


translate english e1212_72927323:


    "Mientras embisto, agarro el juguete de cola en su culo y lo sacudo bien."


translate english e1212_4684c7df:



    voice "voice/e12/1200500a02.opus"
    aoi "\"¡¡¡MIAAAAAUUUUU—!!!\""


translate english e1212_31fc8f4d:



    voice "voice/e12/1200510a02.opus"
    aoi "\"¡Miau! ¡Aaah! ¡Miau! ¡Nnn! ¡Nnn... nnn... nnnnnggg—!!!\""


translate english e1212_da5dfee2:



    voice "voice/e12/1200520a02.opus"
    aoi "\"¡Ay, Dios! ¡Es demasiado intenso, miau! ¡Aoi—Aoi no puede soportarlo ahora miiiiaaauuu!!!\""


translate english e1212_4b5dfb33:



    voice "voice/e12/1200530a02.opus"
    aoi "\"¡Estás golpeando... todos mis puntos débiles...! ¡Dame... Dame más!!!\""


translate english e1212_ada92c4f:


    xy "\"Creí que querías mi leche.\""


translate english e1212_c7f5c56e:



    voice "voice/e12/1200540a02.opus"
    aoi "\"Nnng... B-Bueno... sí, pero... pero—¡Haaah! ¡Nnng—!\""


translate english e1212_490502af:


    xy "\"Entonces aguanta un poco más, ¿sí?\""


translate english e1212_5ac1ba56:



    voice "voice/e12/1200550a02.opus"
    aoi "\"¿A-Aguantar, miau?\""


translate english e1212_5475c306:



    voice "voice/e12/1200560a02.opus"
    aoi "\"V-Vale... Aoi dará lo mejor de sí, miau...\""


translate english e1212_70faf046:


    "Aoi asiente atentamente."


translate english e1212_8b6c2798:


    "Mientras tanto, sigo meciendo mis caderas de un lado a otro..."


translate english e1212_0d9b7c26:



    voice "voice/e12/1200570a02.opus"
    aoi "\"—!!!\""


translate english e1212_7139c780:


    "Luego saco lentamente su juguete de cola..."


translate english e1212_2ae7141f:



    voice "voice/e12/1200580a02.opus"
    aoi "\"¡Aah! ¡Nnn... nnnn...!\""


translate english e1212_d9584053:


    "Pero justo antes de sacarlo por completo, lo vuelvo a meter..."


translate english e1212_71ee5036:



    voice "voice/e12/1200590a02.opus"
    aoi "\"¡Nnn... nn... nng... gghhhh...!\""


translate english e1212_ca8db2ad:


    "Sincronizo mis embestidas para que mi polla se alterne con el juguete."


translate english e1212_c858f1e4:



    voice "voice/e12/1200600a02.opus"
    aoi "\"¡Nnng! ¡Nn... nnnnn! ¡Aaah!\""


translate english e1212_f2ae94d0:


    "Luego aumento gradualmente mi velocidad—"


translate english e1212_3c3f3be0:



    voice "voice/e12/1200610a02.opus"
    aoi "\"¡Aaah! ¡Aah! ¡Aah! ¡Aaahh! ¡Basta! ¡Ay, Dios, Aoi no—\""


translate english e1212_109d4967:


    xy "\"¿No puedes aguantar más?\""


translate english e1212_63144607:



    voice "voice/e12/1200620a02.opus"
    aoi "\"P-Perdón... miau...\""


translate english e1212_ce3fd025:



    voice "voice/e12/1200630a02.opus"
    aoi "\"Entre... que agarras mi cola... y... tu verga... se siente... tan bien... ¡Aoi no puede... pensar bien, miau...!\""


translate english e1212_d7afa3d7:



    voice "voice/e12/1200640a02.opus"
    aoi "\"¡Mi cuerpo... se mueve... por impulso...! ¡Mi coño... se aprieta, miau...! ¡Aaahh!\""


translate english e1212_c473347d:



    voice "voice/e12/1200650a02.opus"
    aoi "\"¡Perdón por... ser una gatita tan zorra...! ¡Haahh! ¡Aah! ¡Aaaahh!!!\""


translate english e1212_560df794:


    xy "\"SUPONGO que te perdono...\""


translate english e1212_58ced121:


    "Aunque me hago el calmado, puedo decir que me acerco a mi límite."


translate english e1212_1a04cc60:


    xy "\"Muy bien, voy a hacerte venir conmigo.\""


translate english e1212_3c74ea6d:



    voice "voice/e12/1200660a02.opus"
    aoi "\"¡S-Sí, por favor, miau...! Mi culo y mi coño están todos chorreando... ¡Aoi ya no aguanta, miau...!\""


translate english e1212_cd0f487d:



    voice "voice/e12/1200670a02.opus"
    aoi "\"¡Haaahh! ¡Aah! ¡Aaahh! ¿Vas a venir, miau? Aoi lo siente palpitar adentro, miau...\""


translate english e1212_aa7d4191:



    voice "voice/e12/1200680a02.opus"
    aoi "\"¡HaaAAH! ¡Aah! ¡Aaaahh! ¡Aoi va a venir! ¡Podemos venir juntos, miau!\""


translate english e1212_1f965b9f:



    voice "voice/e12/1200690a02.opus"
    aoi "\"¡Llena mi zorrito coño de gatita con tu leche de verga caliente, miau!!!\""


translate english e1212_9776f239:



    voice "voice/e12/1200700a02.opus"
    aoi "\"¡Aah! ¡Aaahh! ¡Ya viene! ¡Ya viene, ya viene, ya viene! ¡Ay, Dios! ¡Aoi también se viene! ¡Miau! ¡Miiiiaaauuu!\""


translate english e1212_aee9d234:



    voice "voice/e12/1200710a02.opus"
    aoi "\"¡¡¡MIEEEEOOOOOOOOOWWWWWWW...!!!\""


translate english e1212_95bec3dd:



    voice "voice/e12/1200720a02.opus"
    aoi "\"¡Miau! ¡Miau! ¡Miau! ¡Miau, miau... miau... miiiiau... mm... nnn...!\""


translate english e1212_4f329625:



    voice "voice/e12/1200730a02.opus"
    aoi "\"¡Nnn! ¿¡Todavía?! ¿Sigues... viniendo... miau? Se siente—¡MIAU!—como mucho... miau...\""


translate english e1212_25c78096:



    voice "voice/e12/1200740a02.opus"
    aoi "\"¡Nn... nngghh... nnn... nnnnn...! Uf... miau... nnn... nnnng...\""


translate english e1212_ecadb68e:


    "El cuerpo de Aoi se convulsiona una y otra vez mientras llega a su clímax."


translate english e1212_60e47bc8:


    "Su cola se contrae cada vez que su ojete se aprieta... Es tan jodidamente lindo..."


translate english e1212_1f3cf0ac:


    "Mientras tanto, disparo hasta la última gota de semen en su apretado coñito."


translate english e1212_6e9ae7c5:



    voice "voice/e12/1200750a02.opus"
    aoi "\"Aah... nnn... nn... Mi pancita... está tan llena... de tu leche de verga, miau...\""


translate english e1212_254a3d9f:



    voice "voice/e12/1200760a02.opus"
    aoi "\"Está tan caliente... y fresca, miau... Miau... Aah... nnn... nnnn...\""


translate english e1212_e767bb14:



    voice "voice/e12/1200770a02.opus"
    aoi "\"¡Aoi te ama... tanto, miau...!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
