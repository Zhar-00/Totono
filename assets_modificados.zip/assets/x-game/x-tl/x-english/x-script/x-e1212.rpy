

translate english e1212_e6ef3bc7:



    voice "voice/e12/1200010a02.opus"
    aoi "\"Mmph... shhllpp... shllppp... mmllpp... shllpp... sslllrrrppp...!\""


translate english e1212_db99f715:


    "...Mmm...? ¿Qué es ese sonido...?"


translate english e1212_23390ff3:



    voice "voice/e12/1200020a02.opus"
    aoi "\"Slrppp... mmllpp... mmh... mmh... mmph... slrrpp... rrpp... rrppp!!!\""


translate english e1212_143903d0:



    voice "voice/e12/1200030a02.opus"
    aoi "\"Mmllpp... Boop boop?\""


translate english e1212_5c2fde1c:



    voice "voice/e12/1200040a02.opus"
    aoi "\"Shinichi? Are you awake, meow?\""


translate english e1212_37204e3f:


    xy "\"What are you doing?\""


translate english e1212_a17c6589:



    voice "voice/e12/1200050a02.opus"
    aoi "\"Licking your cock, meow.\""


translate english e1212_4c777630:


    xy "\"What's with the... you know... the getup?\""


translate english e1212_698bc35a:



    voice "voice/e12/1200060a02.opus"
    aoi "\"The cat ears, meow?\""


translate english e1212_a84f087f:


    xy "\"Yeah. Why are you wearing them?\""


translate english e1212_07658b95:



    voice "voice/e12/1200070a02.opus"
    aoi "\"Because it's cute, meow.\""


translate english e1212_ffee14ff:


    "Quiero decir, sí, SÍ es lindo..."


translate english e1212_d9acc737:



    voice "voice/e12/1200080a02.opus"
    aoi "\"Did you get a new CG, meow?\""


translate english e1212_d61f4c9e:


    xy "\"You and your gamer brain... Whoa, hey!\""


translate english e1212_7f096d31:



    voice "voice/e12/1200090a02.opus"
    aoi "\"Sllrrpp... sllrrr... slrrp! Mmm... Phaah! It's so yummy, meow!\""


translate english e1212_ba64b861:



    voice "voice/e12/1200100a02.opus"
    aoi "\"Give me your milk, meow!\""


translate english e1212_1637a25f:


    xy "\"My... milk...?\""


translate english e1212_992f656d:



    voice "voice/e12/1200110a02.opus"
    aoi "\"Kitty's hungry, meow.\""


translate english e1212_d59fbfb6:



    voice "voice/e12/1200120a02.opus"
    aoi "\"Kitty wants that warm milk... Mmmph!\""


translate english e1212_9107c696:


    "...Así que ESO es lo que busca."


translate english e1212_d8d26ae8:



    voice "voice/e12/1200130a02.opus"
    aoi "\"You've been so distant with me lately, meow. You won't give me any attention, meow.\""


translate english e1212_b565422c:



    voice "voice/e12/1200140a02.opus"
    aoi "\"Any normal girl would go find some other guy, meow.\""


translate english e1212_feb2052e:


    xy "\"I'm sorry... I've just been so busy with the theatre club these days...\""


translate english e1212_96b450bc:



    voice "voice/e12/1200150a02.opus"
    aoi "\"No excuses, meow. Mmllpp... mmmh!\""


translate english e1212_671e7d18:


    xy "\"Nnng?!?\""


translate english e1212_b6ea7cf3:


    "Un dolor agudo me atraviesa la ingle, y suelto un grito de sorpresa."


translate english e1212_cfa2031a:


    xy "\"No teeth! Don't bite it!\""


translate english e1212_69443246:



    voice "voice/e12/1200160a02.opus"
    aoi "\"Just a nibble, meow. This is your punishment for being a jerk, meow.\""


translate english e1212_a6301f3d:



    voice "voice/e12/1200170a02.opus"
    aoi "\"If you want to keep your cock in one piece, cough up that milk.\""


translate english e1212_36c47219:


    "¿¡Eso es una amenaza?!?"


translate english e1212_d9e2fa10:



    voice "voice/e12/1200180a02.opus"
    aoi "\"Mmmm? Why is it going soft, meow?\""


translate english e1212_234de3ec:


    "¿¡Por qué crees, genio?!?"


translate english e1212_ef168ec9:



    voice "voice/e12/1200190a02.opus"
    aoi "\"Mmllpp... lllppphhh... shhllpp... slrrpp... shhllpp!\""


translate english e1212_faa81ce5:



    voice "voice/e12/1200200a02.opus"
    aoi "\"Mmmph... shhllpp... sllrrppp! Mmmph... sllrrpp... ssslllrrrrpppp!\""


translate english e1212_2fceb9ea:



    voice "voice/e12/1200210a02.opus"
    aoi "\"It's getting hard again, meow...\""


translate english e1212_3e812fd5:


    "Chupa vigorosamente para revivir mi erección."


translate english e1212_97c59cff:



    voice "voice/e12/1200220a02.opus"
    aoi "\"Now just go ahead and cum, meow. Aoi wants that dick milk, meow.\""


translate english e1212_0accd139:


    xy "\"\"\"......!!!\"¿Hmm?\"\""


translate english e1212_dcbabb74:


    "...Qué raro..."


translate english e1212_f09f36fa:


    "Aoi es definitivamente linda, y podría verme acabando bastante rápido si bajo la guardia..."


translate english e1212_37b526d7:


    "No está nada mal despertar con una mamada... y sin embargo, por alguna razón, no estoy del todo satisfecho..."


translate english e1212_11c0754b:


    xy "\"......Hmm?\""


translate english e1212_a37901dc:


    "Detrás de ella, puedo ver algo moviéndose arriba y abajo."


translate english e1212_4e6a28d2:


    "¿Eso es... una cola...?"


translate english e1212_68a6c0cc:



    voice "voice/e12/1200230a02.opus"
    aoi "\"Mmmh... mmmh... meow... mmm... ssllrrpp... sslllrrppp... meow... mmm!\""


translate english e1212_2609ef3f:



    voice "voice/e12/1200240a02.opus"
    aoi "\"Shinichi, your balls are getting tight... Are you gonna cum soon, meow? Right now, purrhaps?\""


translate english e1212_76f045a7:


    xy "\"Oh, I'm definitely getting there...\""


translate english e1212_eb3c415f:


    xy "\"But I'm more interested in THIS!\""


translate english e1212_d9041a87:



    voice "voice/e12/1200250a02.opus"
    aoi "\"MEOOOOOWWWW!!!\""


translate english e1212_99e3d5a1:


    "Extiendo la mano y agarro su cola."


translate english e1212_792d0d4a:



    voice "voice/e12/1200260a02.opus"
    aoi "\"D-Don't touch that, meow!\""


translate english e1212_2e67c8bd:



    voice "voice/e12/1200270a02.opus"
    aoi "\"It's not polite to touch a kitty's tail— MEOOOOWWWW!!!\""


translate english e1212_c2f1653f:



    voice "voice/e12/1200280a02.opus"
    aoi "\"Meoooowww...\""


translate english e1212_769df0b4:


    "Aoi pierde el equilibrio y se derrumba sobre la cama."


translate english e1212_e39e8d6a:


    "Me muevo para quedar ahora yo encima de ella, y agarro su cola con fuerza."


translate english e1212_5417b407:


    "Puedo ver una cadena de cuentas en su base... subiendo directamente por su ojete."


translate english e1212_a0cfa600:


    xy "\"What happens when I touch your tail?\""


translate english e1212_9b4ad638:



    voice "voice/e12/1200290a02.opus"
    aoi "\"Well... my tail... umm... It's my weak spot, meow... So whenever you touch it like that...\""


translate english e1212_89cd1601:


    xy "\"Like this, you mean?\""


translate english e1212_ba1a1a82:



    voice "voice/e12/1200300a02.opus"
    aoi "\"Meoooww! Meow! Stop! Stop that, meow! You can't move it around like that!!!\""


translate english e1212_fa5dd4bb:


    xy "\"Why? Does it hurt?\""


translate english e1212_dbca83c4:



    voice "voice/e12/1200310a02.opus"
    aoi "\"Meow...\""


translate english e1212_fd1b4b1e:


    "Suelto de inmediato."


translate english e1212_149bd5e0:


    xy "\"If it hurts, I'll stop.\""


translate english e1212_658ffe09:



    voice "voice/e12/1200320a02.opus"
    aoi "\"Nn... nnn... You bully...\""


translate english e1212_8c89b0f6:


    "Parece estar al borde de las lágrimas."


translate english e1212_73d351ea:



    voice "voice/e12/1200330a02.opus"
    aoi "\"It doesn't hurt, meow...\""


translate english e1212_838935c1:



    voice "voice/e12/1200340a02.opus"
    aoi "\"It feels good... but it's so intense, it makes me dizzy, meow.\""


translate english e1212_84cd0312:


    xy "\"That explains why you're so wet.\""


translate english e1212_4941958b:


    "No la he tocado el coño en absoluto—en ABSOLUTO—y ya está hinchado y goteando."


translate english e1212_cd957d8b:


    xy "\"Well then, we might as well—\""


translate english e1212_269f721b:



    voice "voice/e12/1200350a02.opus"
    aoi "\"Meow...? Ah! What are you doing? Rubbing... your cock... against me...\""


translate english e1212_99dadb37:



    voice "voice/e12/1200360a02.opus"
    aoi "\"MEOOOOOWWWW—! Meow! Meow! Meow—Nnnng!!!\""


translate english e1212_980cc70f:



    voice "voice/e12/1200370a02.opus"
    aoi "\"Shinichi's cock... Nnhaah! It's—inside me—meow!!!\""


translate english e1212_ee81ef6d:


    "Incluso sin ningún preludio, el coño de Aoi me recibe ansiosamente."


translate english e1212_50848515:


    xy "\"You said you're hungry for milk, didn't you?\""


translate english e1212_a9a0c18f:



    voice "voice/e12/1200380a02.opus"
    aoi "\"That's not the mouth I meant, meow...\""


translate english e1212_5c6079d9:


    xy "\"So you don't want it, then?\""


translate english e1212_4ffca835:



    voice "voice/e12/1200390a02.opus"
    aoi "\"Meow—Nnnnn...! You're such a bully, meow!\""


translate english e1212_dc787293:


    "Aoi me mira fijamente por un momento."


translate english e1212_29f405d1:



    voice "voice/e12/1200400a02.opus"
    aoi "\"Nn... nnn! Nnn! Nnn!\""


translate english e1212_c020eca7:


    "Se aprieta sobre mí y empieza a mover sus caderas."


translate english e1212_74993749:



    voice "voice/e12/1200410a02.opus"
    aoi "\"Give me your dick milk! Nnnn!!! Flood me—right meow!!!\""


translate english e1212_c72b20f9:



    voice "voice/e12/1200420a02.opus"
    aoi "\"Aoi's gonna—use her pussy—to get you off, meow... Aaaahh!\""


translate english e1212_9187a0c6:


    "Está poniendo tanto esfuerzo en esto... ¡mejor le echo una mano!"


translate english e1212_790d4a2e:


    "Levanto su pierna y la penetro profundamente, hasta el fondo."


translate english e1212_148c734c:



    voice "voice/e12/1200430a02.opus"
    aoi "\"MEOOOOWWWW...!!!\""


translate english e1212_9d73ef99:



    voice "voice/e12/1200440a02.opus"
    aoi "\"Oh my god... meow...!!! It's so deep... Really, really deep...!\""


translate english e1212_1b1a3318:



    voice "voice/e12/1200450a02.opus"
    aoi "\"Your... cock is... slamming... deep inside me...!\""


translate english e1212_77db234f:



    voice "voice/e12/1200460a02.opus"
    aoi "\"HAAAAAAHH! Aah! Aah, aah, aah! N-Not like that, meow! That's too intense!!!\""


translate english e1212_4787d10b:



    voice "voice/e12/1200470a02.opus"
    aoi "\"It feels! Like! You're! Ravaging! My whole insides—! AAAAHH!!!\""


translate english e1212_8c187458:


    "Debe ser realmente intenso."


translate english e1212_b620a884:


    "Puedo sentir su espasmo cada vez que mi longitud golpea sus partes más profundas."


translate english e1212_663674ce:



    voice "voice/e12/1200480a02.opus"
    aoi "\"Haahh! Aah! Aah! Aah! Aah! Oh god! Shinichi! It feels so good!\""


translate english e1212_d0e5a546:



    voice "voice/e12/1200490a02.opus"
    aoi "\"Don't stop! Keep going! Aaaahh! Aoi's gonna... gonna cum—!\""


translate english e1212_c2baba7d:


    xy "\"What's the rush?\""


translate english e1212_72927323:


    "Mientras embisto, agarro el juguete de cola en su culo y lo sacudo bien."


translate english e1212_4684c7df:



    voice "voice/e12/1200500a02.opus"
    aoi "\"MEOOOOOWWWW—!!!\""


translate english e1212_31fc8f4d:



    voice "voice/e12/1200510a02.opus"
    aoi "\"Meow! Aaah! Meow! Nnn! Nnn... nnn... nnnnnggg—!!!\""


translate english e1212_da5dfee2:



    voice "voice/e12/1200520a02.opus"
    aoi "\"Oh god! It's too intense, meow! Aoi—Aoi can't handle it right meoooowww!!!\""


translate english e1212_4b5dfb33:



    voice "voice/e12/1200530a02.opus"
    aoi "\"You're hitting... all my weak spots...!!! Give me... Give me more!!!\""


translate english e1212_ada92c4f:


    xy "\"I thought you wanted my milk?\""


translate english e1212_c7f5c56e:



    voice "voice/e12/1200540a02.opus"
    aoi "\"Nnng... W-Well... yeah, but... but—Haaah! Nnng—!\""


translate english e1212_490502af:


    xy "\"Then just hang in there a little longer, alright?\""


translate english e1212_5ac1ba56:



    voice "voice/e12/1200550a02.opus"
    aoi "\"H-Hang in there, meow?\""


translate english e1212_5475c306:



    voice "voice/e12/1200560a02.opus"
    aoi "\"O-Okay... Aoi will try her best, meow...\""


translate english e1212_70faf046:


    "Aoi asiente atentamente."


translate english e1212_8b6c2798:


    "Mientras tanto, sigo meciendo mis caderas de un lado a otro..."


translate english e1212_0d9b7c26:



    voice "voice/e12/1200570a02.opus"
    aoi "\"—!!!\""


translate english e1212_7139c780:


    "Luego saco lentamente su juguete de cola..."


translate english e1212_2ae7141f:



    voice "voice/e12/1200580a02.opus"
    aoi "\"Aah! Nnn... nnnn...!\""


translate english e1212_d9584053:


    "Pero justo antes de sacarlo por completo, lo vuelvo a meter..."


translate english e1212_71ee5036:



    voice "voice/e12/1200590a02.opus"
    aoi "\"Nnn... nn... nng... gghhhh...!\""


translate english e1212_ca8db2ad:


    "Sincronizo mis embestidas para que mi polla se alterne con el juguete."


translate english e1212_c858f1e4:



    voice "voice/e12/1200600a02.opus"
    aoi "\"Nnng! Nn... nnnnn!!! Aaah!!!\""


translate english e1212_f2ae94d0:


    "Luego aumento gradualmente mi velocidad—"


translate english e1212_3c3f3be0:



    voice "voice/e12/1200610a02.opus"
    aoi "\"Aaah! Aah! Aah! Aaahh!!! Stop! Oh god, Aoi can't—\""


translate english e1212_109d4967:


    xy "\"Can't hang in there any longer?\""


translate english e1212_63144607:



    voice "voice/e12/1200620a02.opus"
    aoi "\"S-Sorry... meow...\""


translate english e1212_ce3fd025:



    voice "voice/e12/1200630a02.opus"
    aoi "\"Between... you grabbing my tail... and... your cock... it feels... so good... Aoi can't... think straight, meow...!\""


translate english e1212_d7afa3d7:



    voice "voice/e12/1200640a02.opus"
    aoi "\"My body's... moving... on impulse...! My pussy's... clamping down, meow... Aaahh!\""


translate english e1212_c473347d:



    voice "voice/e12/1200650a02.opus"
    aoi "\"Sorry for... being such a slutty kitty...!!! Haahh! Aah! Aaaahh!!!\""


translate english e1212_560df794:


    xy "\"I GUESS I forgive you...\""


translate english e1212_58ced121:


    "Aunque me hago el calmado, puedo decir que me acerco a mi límite."


translate english e1212_1a04cc60:


    xy "\"Alright, I'm gonna make you cum with me.\""


translate english e1212_3c74ea6d:



    voice "voice/e12/1200660a02.opus"
    aoi "\"Y-Yes please, meow...! My ass and pussy are both all sloppy wet... Aoi can't take it anymore, meow...!\""


translate english e1212_cd0f487d:



    voice "voice/e12/1200670a02.opus"
    aoi "\"Haaahh! Aah! Aaahh!!! Are you gonna cum, meow? Aoi can feel it twitching inside, meow...\""


translate english e1212_aa7d4191:



    voice "voice/e12/1200680a02.opus"
    aoi "\"HaaAAH! Aah! Aaaahh! Aoi's gonna cum! We can cum together, meow!\""


translate english e1212_1f965b9f:



    voice "voice/e12/1200690a02.opus"
    aoi "\"Fill my slutty kitty pussy with your hot dick milk, meow!!!\""


translate english e1212_9776f239:



    voice "voice/e12/1200700a02.opus"
    aoi "\"Aah! Aaahh! It's coming! It's coming, it's coming, it's coming!!! Oh god! Aoi's cumming too! Meow! Meoooowww!\""


translate english e1212_aee9d234:



    voice "voice/e12/1200710a02.opus"
    aoi "\"MEEEEOOOOOOOOOWWWWWWW...!!!\""


translate english e1212_95bec3dd:



    voice "voice/e12/1200720a02.opus"
    aoi "\"Meow! Meow! Meow! Meow, meow... meow... meooww... mm... nnn...!\""


translate english e1212_4f329625:



    voice "voice/e12/1200730a02.opus"
    aoi "\"Nnn! Still?! Are you... still cumming... meow? It feels—MEOW!—like a lot... meow...\""


translate english e1212_25c78096:



    voice "voice/e12/1200740a02.opus"
    aoi "\"Nn... nngghh... nnn... nnnnn...! Whew... meow... nnn... nnnng...\""


translate english e1212_ecadb68e:


    "El cuerpo de Aoi se convulsiona una y otra vez mientras llega a su clímax."


translate english e1212_60e47bc8:


    "Su cola se contrae cada vez que su ojete se aprieta... Es tan jodidamente lindo..."


translate english e1212_1f3cf0ac:


    "Mientras tanto, disparo hasta la última gota de semen en su apretado coñito."


translate english e1212_6e9ae7c5:



    voice "voice/e12/1200750a02.opus"
    aoi "\"Aah... nnn... nn... My tummy... is so full... of your dick milk, meow...\""


translate english e1212_254a3d9f:



    voice "voice/e12/1200760a02.opus"
    aoi "\"It's so hot... and fresh, meow... Meow... Aah... nnn... nnnn...\""


translate english e1212_e767bb14:



    voice "voice/e12/1200770a02.opus"
    aoi "\"Aoi loves you... so much, meow...!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
