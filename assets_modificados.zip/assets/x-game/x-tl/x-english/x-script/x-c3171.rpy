

translate english c3171_e09ddac3:


    "—pero no puedo dormir."


translate english c3171_58e18a05:


    "Mi cerebro no deja de pensar en ello."


translate english c3171_ae46ab8f:


    "El teléfono prestado descansa cargando junto a mi almohada."


translate english c3171_902bb761:


    "No lo he jugado desde aquel día durante la clase..."


translate english c3171_be134c4a:


    "¿Quizá aprendería algo útil sobre Aoi si avanzo un poco en el juego...?"


translate english strings:


    old "Поиграть в игру"
    new "Jugar el juego"


    old "Заставить себя уснуть"
    new "Forzarme a dormir"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
