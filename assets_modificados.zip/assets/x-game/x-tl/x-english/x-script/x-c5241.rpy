

translate english c5241_94aed492:


    "La puerta se cierra, y los pasos de Miyuki se desvanecen."


translate english c5241_c8d0927b:


    "Miro el vasto cielo azul, con mis sentimientos aún hechos un lío."


translate english c5241_7ccdefe8:


    xy "\"I'll get another chance, huh...?\""


translate english c5241_4c4b53d7:


    "Sus últimas palabras resuenan en mi mente."


translate english c5241_341adeaf:


    "Es casi como si supiera que voy a arruinarlo con seguridad..."


translate english c5241_4236f3d3:



    voice "voice/c52/4100010a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c5241_f8674dba:


    "De la nada, Aoi de repente empieza a transmitir."


translate english c5241_df9a3988:



    voice "voice/c52/4100020a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c5241_49db79f5:



    voice "voice/c52/4100030a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c5241_c3aa72af:



    voice "voice/c52/4100040a02.opus"
    aoi "\"...Boop boop...\""



translate english c5241_bea09d2b:


    xy "\"No service?\""


translate english c5241_b09e61ed:



    voice "voice/c52/4100050a02.opus"
    aoi "\"Aoi can't save the game.\""


translate english c5241_e999d0b2:



    voice "voice/c52/4100060a02.opus"
    aoi "\"Did God go away somewhere?\""


translate english c5241_0e51abf8:


    xy "\"Supposing He did... what then?\""


translate english c5241_2baa84b8:



    voice "voice/c52/4100070a02.opus"
    aoi "\"\"......\"\""


translate english c5241_e23e8ad9:



    voice "voice/c52/4100080a02.opus"
    aoi "\"It's not a fun thought.\""


translate english c5241_80252036:



    voice "voice/c52/4100090a02.opus"
    aoi "\"Aoi feels restless... and stir-crazy...\""


translate english c5241_2a49a3ae:


    xy "\"Feeling scared, huh?\""


translate english c5241_a85ad9dd:



    voice "voice/c52/4100100a02.opus"
    aoi "\"Scared?\""


translate english c5241_141f7854:


    "Rechazada por sus compañeros... Viviendo sola en un café de manga..."


translate english c5241_c9d50f69:


    "Nunca podía aceptar la realidad."


translate english c5241_e42beb8f:


    "Necesitaba una nueva realidad a la que pudiera escapar..."


translate english c5241_534e1158:


    "Así que inventó a su Dios."


translate english c5241_5842d28e:


    "Con la ayuda de Dios, podía recargar sus partidas y esforzarse por un mejor resultado en la vida real."


translate english c5241_46613bf4:


    "Al menos, eso es lo que tuvo que decirse a sí misma, supongo."


translate english c5241_ee22b55b:


    "Pero ahora su señal no llega."


translate english c5241_dd29d1d6:


    "No puede recargar su partida."


translate english c5241_ae5cb9ab:



    voice "voice/c52/4100110a02.opus"
    aoi "\"Yeah... It's scary.\""


translate english c5241_9c6ef9e4:



    voice "voice/c52/4100120a02.opus"
    aoi "\"Aoi's just... scared.\""


translate english c5241_f1f50246:



    voice "voice/c52/4100130a02.opus"
    aoi "\"What about you?\""


translate english c5241_d6dfe0f4:


    xy "\"Me?\""


translate english c5241_5109df0f:



    voice "voice/c52/4100140a02.opus"
    aoi "\"When we talk, Aoi can tell... You're restless and stir-crazy, too...\""


translate english c5241_846a95af:



    voice "voice/c52/4100150a02.opus"
    aoi "\"So that means you must be scared, too.\""


translate english c5241_8e7e1055:


    xy "\"I...\""


translate english c5241_58d9dbcf:


    "Me quedo en silencio."


translate english c5241_d1d1f86b:


    "No puedo mentirle."


translate english c5241_eb2d2cf5:



    voice "voice/c52/4100160a02.opus"
    aoi "\"It's normal.\""


translate english c5241_d88e24f1:



    voice "voice/c52/4100170a02.opus"
    aoi "\"Aoi's not a normal girl. Aoi doesn't understand normal emotions.\""


translate english c5241_7f2c2725:



    voice "voice/c52/4100180a02.opus"
    aoi "\"My brain's all weird and spacey... All Aoi does is get into trouble...\""


translate english c5241_7286de12:



    voice "voice/c52/4100190a02.opus"
    aoi "\"And everyone spreads all these bad rumors about me...\""


translate english c5241_c9ec605a:



    voice "voice/c52/4100200a02.opus"
    aoi "\"So it's normal to be scared.\""


translate english c5241_35f72ecb:



    voice "voice/c52/4100210a02.opus"
    aoi "\"It's normal to be suspicious.\""


translate english c5241_0accd139:


    xy "\"\"......\"\""


translate english c5241_96ba310f:



    voice "voice/c52/4100220a02.opus"
    aoi "\"But...\""


translate english c5241_c604f945:


    "Sus ojos son tan deslumbrantes..."


translate english c5241_34f189bf:



    voice "voice/c52/4100230a02.opus"
    aoi "\"Aoi doesn't want things to stay like this.\""


translate english c5241_d4116b9b:



    voice "voice/c52/4100240a02.opus"
    aoi "\"Aoi loves you...\""


translate english c5241_d5b6738d:



    voice "voice/c52/4100250a02.opus"
    aoi "\"But we keep misunderstanding each other...\""


translate english c5241_f510cd21:



    voice "voice/c52/4100260a02.opus"
    aoi "\"Aoi can't just put off making a decision out of fear.\""


translate english c5241_65e221d3:


    "Toma suavemente mi mano entre las suyas."


translate english c5241_c3d60bcb:



    voice "voice/c52/4100270a02.opus"
    aoi "\"Please...\""


translate english c5241_a6fcd499:



    voice "voice/c52/4100280a02.opus"
    aoi "\"Please trust me.\""


translate english c5241_1ad6b06e:



    voice "voice/c52/4100290a02.opus"
    aoi "\"Trust that Aoi loves you...\""


translate english c5241_bd48be2c:



    voice "voice/c52/4100300a02.opus"
    aoi "\"Trust that these feelings are real...\""


translate english c5241_7f942b6a:



    voice "voice/c52/4100310a02.opus"
    aoi "\"Aoi needs you to believe everything.\""


translate english c5241_d76727ec:


    "Durante los últimos días, le he tenido tanto miedo."


translate english c5241_38ebd399:


    "Pero el sentimiento probablemente fue mutuo."


translate english c5241_d112aad5:


    "Temerosos del rechazo, nos hemos mantenido a distancia."


translate english c5241_0bb7057b:


    "Pero finalmente ha reunido todo su valor para hablar de ello."


translate english c5241_04f75bbc:


    "Incluso sin sus partidas, confía en que la escucharé."


translate english c5241_570a718d:


    "Y ahora es mi turno."


translate english c5241_36ad65e4:


    xy "\"Wanna come with me?\""


translate english c5241_cc040ab2:


    "Le tiendo los boletos para la obra."


translate english c5241_7355e433:



    voice "voice/c52/4100320a02.opus"
    aoi "\"Boop boop... Just the two of us?\""


translate english c5241_0f9492aa:


    xy "\"Yeah. It'll be a real, actual date this time around.\""


translate english c5241_5aff7616:



    voice "voice/c52/4100330a02.opus"
    aoi "\"A date...\""


translate english c5241_187a3b27:



    voice "voice/c52/4100340a02.opus"
    aoi "\"Like, a... a romantic sorta date?\""


translate english c5241_1278a070:


    xy "\"Of course. We're boyfriend and girlfriend, aren't we?\""


translate english c5241_0c6ccea5:



    voice "voice/c52/4100350a02.opus"
    aoi "\"We are...!\""


translate english c5241_0cadb5a5:



    voice "voice/c52/4100360a02.opus"
    aoi "\"Got it!!!\""


translate english c5241_e1215a88:


    "Su mano se alza hacia el cielo."


translate english c5241_1a66acf8:


    "Aferrado en su palma está el pasador de gatito que le compré."


translate english c5241_9f60dfb1:



    voice "voice/c52/4100370a02.opus"
    aoi "\"Aoi can wear her hairpin and everything!\""


translate english c5241_5e5a1f20:



    voice "voice/c52/4100380a02.opus"
    aoi "\"Aoi's going on a real date with Shinichi!\""


translate english c5241_1b3b51f6:


    xy "\"I mean, it won't be super fancy—\""


translate english c5241_4b27608e:



    voice "voice/c52/4100390a02.opus"
    aoi "\"But Aoi's really excited!\""


translate english c5241_95048257:



    voice "voice/c52/4100400a02.opus"
    aoi "\"And really, really happy...\""


translate english c5241_3070f0e8:



    voice "voice/c52/4100410a02.opus"
    aoi "\"Feels like the whole world is topsy-turvy...\""


translate english c5241_83e1d180:



    voice "voice/c52/4100420a02.opus"
    aoi "\"Aoi's... just so... happy... Boop boop?\""


translate english c5241_7fe1cf16:


    xy "\"Huh...?\""


translate english c5241_7b8a4723:


    "Aoi se derrumba al suelo."


translate english c5241_9c36e3c4:


    xy "\"Aoi?! You okay?!\""


translate english c5241_35cbd1b0:



    voice "voice/c52/4100430a02.opus"
    aoi "\"It hurts...\""


translate english c5241_23b291e5:


    xy "\"You weren't supposed to literally get topsy-turvy, you dork!\""


translate english c5241_2832c613:



    voice "voice/c52/4100440a02.opus"
    aoi "\"Boop boop... Sorry...\""


translate english c5241_a027f9ba:


    "Con su brazo alrededor de mi hombro, susurra en mi oído."


translate english c5241_69708a68:



    voice "voice/c52/4100450a02.opus"
    aoi "\"Aoi's battery is getting really low...\""


translate english c5241_ef9e7e9a:


    "No entiendo por qué se ve tan miserable... pero..."


translate english c5241_58768702:


    "Para mí, todavía se siente como si el mundo que ella ve fuera totalmente distinto al mío."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
