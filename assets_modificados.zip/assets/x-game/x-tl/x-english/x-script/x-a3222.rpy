

translate english a3222_fec07c19:



    voice "voice/a32/2200010a02.opus"
    aoi "\"¡Aah...!\""


translate english a3222_871bb559:


    xy "\"¡Aoi!\""


translate english a3222_7ac38128:


    "En el segundo en que salimos, Aoi pierde el equilibrio."


translate english a3222_a99c7b09:


    "Actuando rápido, le paso el brazo por encima de mi hombro para mantenerla de pie."


translate english a3222_868aa791:



    voice "voice/a32/2200020a01.opus"
    mx "\"¡Espera! Te ayudo a llevarla de vuelta al...\""


translate english a3222_a9bc9455:


    xy "\"Hoy no. Lo siento.\""


translate english a3222_67426df7:



    voice "voice/a32/2200030a01.opus"
    mx "\"\"\"......\"\"\""


translate english a3222_5212b539:


    xy "\"Hasta mañana.\""


translate english a3222_a6c281bd:



    voice "voice/a32/2200040a02.opus"
    aoi "\"Bye-bye... Miyuki...\""


translate english a3222_04231276:



    voice "voice/a32/2200050a01.opus"
    mx "\"\"\"......\"\"\""


translate english a3222_8fa861ba:


    "Me alejo con Aoi, dejando a Miyuki parada ahí en silencio."


translate english a3222_ba3c6137:


    "Con un brazo alrededor de mis hombros, Aoi cojea por la calle con su uniforme recién secado."


translate english a3222_73b2ca75:


    xy "\"¿Seguro que quieres volver al manga café?\""


translate english a3222_d882c826:


    xy "\"Siempre podrías quedarte un par de noches en mi casa, ¿sabes?\""


translate english a3222_4316d6ef:



    voice "voice/a32/2200060a02.opus"
    aoi "\"Eso activaría una bandera de evento arriesgada.\""


translate english a3222_2ac8ccb7:


    xy "\"Bien, ¿y el hospital?\""


translate english a3222_a16354ef:



    voice "voice/a32/2200070a02.opus"
    aoi "\"Aoi necesita recargarse.\""


translate english a3222_9977ad53:



    voice "voice/a32/2200080a02.opus"
    aoi "\"El hospital no ayudará con eso.\""


translate english a3222_9921868b:


    xy "\"Entonces al menos déjame llamarte un taxi.\""


translate english a3222_fe811d62:



    voice "voice/a32/2200090a02.opus"
    aoi "\"Aoi estará bien.\""


translate english a3222_f1a88e31:


    "Lo juro, una vez que se le mete algo en la cabeza, se niega a que la convenzan..."


translate english a3222_c9bb7d60:


    "Por suerte no parece tener fiebre, así que probablemente no es grave... pero si me da otro susto como ese, definitivamente llamo un taxi."


translate english a3222_f7efcdba:



    voice "voice/a32/2200100a02.opus"
    aoi "\"Shinichi...\""


translate english a3222_fd03822d:


    xy "\"¿Hm? ¿Qué pasa?\""


translate english a3222_afaa82af:



    voice "voice/a32/2200110a02.opus"
    aoi "\"¿Por qué te hiciste mi amigo?\""


translate english a3222_06edadb5:


    xy "\"Oh... Bueno...\""


translate english a3222_1b72838d:


    "Repaso vagamente mis recuerdos... hasta aquel día en que intercambié correos con Aoi por primera vez."


translate english a3222_df7d3fc4:


    "Ese fue el día en que oficialmente nos volvimos \"friends.\""


translate english a3222_c1cbb13d:


    "Luego tomó una foto de Miyuki y de mí juntos, y..."


translate english a3222_e4cf22ea:


    xy "\"No quería que anduvieras pasando esa foto.\""


translate english a3222_de868a95:



    voice "voice/a32/2200120a02.opus"
    aoi "\"¿Esa era toda tu razón?\""


translate english a3222_c34fe598:


    xy "\"Bueno, o sea, tenía que hacer ALGO, ¿no?\""


translate english a3222_56adb0b5:



    voice "voice/a32/2200130a02.opus"
    aoi "\"Pero no tienes la paciencia para lidiar con otras personas.\""


translate english a3222_4c7d337e:


    "No está equivocada."


translate english a3222_2b27b9f1:


    "Mukou Aoi es fácilmente la chica más molesta de nuestra clase. Hasta sostener una conversación con ella es agotador."


translate english a3222_51f48229:


    "Y sin embargo lo hice de todos modos."


translate english a3222_ae741523:


    xy "\"Supongo que... me recordaste a Miyuki.\""


translate english a3222_1ec5ad90:


    xy "\"Cuando éramos pequeños, Miyuki también tenía problemas para encajar. Era una solitaria, igual que tú.\""


translate english a3222_159adb5c:



    voice "voice/a32/2200140a02.opus"
    aoi "\"Bye-bye... Miyuki...\""


translate english a3222_cc916362:



    voice "voice/a32/2200150a02.opus"
    aoi "\"Así que eso era... Querías ayudar a Miyuki...\""


translate english a3222_a5a3263c:



    voice "voice/a32/2200160a02.opus"
    aoi "\"Boop boop...\""


translate english a3222_bb58c512:


    xy "\"¿Eh?\""


translate english a3222_3e79df23:


    "Un minuto va tambaleándose sobre sus propios pies, y al siguiente se desploma al suelo."


translate english a3222_68082ef9:


    xy "\"¡¿E-Estás bien?!\""


translate english a3222_18ce5c6d:



    voice "voice/a32/2200170a02.opus"
    aoi "\"Sí...\""


translate english a3222_ac7555c8:


    xy "\"¡Espera un segundo!\""


translate english a3222_bd38e63b:


    "Saco mi teléfono para llamar un taxi—"


translate english a3222_a7ede83d:



    voice "voice/a32/2200180a02.opus"
    aoi "\"No, gracias.\""


translate english a3222_2c3c74ec:



    voice "voice/a32/2200190a02.opus"
    aoi "\"Aquí es donde nos despedimos.\""


translate english a3222_d888fb5b:


    xy "\"¡No te voy a dejar aquí así nada más!\""


translate english a3222_bea15754:



    voice "voice/a32/2200200a02.opus"
    aoi "\"Está bien.\""


translate english a3222_a2c31439:


    "Aoi habla suavemente, con la mirada distante."


translate english a3222_52d8d150:



    voice "voice/a32/2200210a02.opus"
    aoi "\"Una vez que estás en una ruta, todas las demás chicas se desvanecen en el fondo.\""


translate english a3222_5d643e97:



    voice "voice/a32/2200220a02.opus"
    aoi "\"Así que te olvidarás de mí pronto.\""


translate english a3222_295059bb:



    voice "voice/a32/2200230a02.opus"
    aoi "\"Y olvidarás que me dejaste aquí.\""


translate english a3222_0ae97208:


    xy "\"¡Sobre mi cadáver!\""


translate english a3222_2f4d8f04:


    "Suspirando, me agacho al borde de la calle."


translate english a3222_ecead709:


    xy "\"Súbete.\""


translate english a3222_eb8c670d:



    voice "voice/a32/2200240a02.opus"
    aoi "\"¿¡Boop boop...!?\""


translate english a3222_b1636645:


    xy "\"Te voy a cargar.\""


translate english a3222_b3284abb:



    voice "voice/a32/2200250a02.opus"
    aoi "\"¿Para qué?\""


translate english a3222_697ab248:


    xy "\"¡Bueno, no me dejas llamarte un taxi!\""


translate english a3222_5f29e921:


    xy "\"Además, será más rápido si solo caminamos. Ahora súbete.\""


translate english a3222_9d087517:



    voice "voice/a32/2200260a02.opus"
    aoi "\"Pero Aoi...\""


translate english a3222_1ed18575:


    xy "\"¡Dije que te subas!\""


translate english a3222_9986f101:


    xy "\"O sea, ¿para qué más están los amigos?\""


translate english a3222_876074ac:



    voice "voice/a32/2200270a02.opus"
    aoi "\"Amigos...\""


translate english a3222_b3d0ee86:



    voice "voice/a32/2200280a02.opus"
    aoi "\"...Está bien.\""


translate english a3222_a15a5bdc:


    "Aoi se sube a mi espalda, y partimos bajo la luz de la luna."


translate english a3222_1440a77d:


    "Es tan suave... y cálida... y pequeña..."


translate english a3222_533bba97:


    xy "\"Guau, casi no pesas nada. ¿Estás comiendo bien?\""


translate english a3222_acbbce82:



    voice "voice/a32/2200290a02.opus"
    aoi "\"Aoi toma mucho Yabaley's.\""


translate english a3222_8546d283:


    xy "\"¡Necesitas algo con más calorías! A este paso te vas a desvanecer.\""


translate english a3222_db87c061:



    voice "voice/a32/2200300a02.opus"
    aoi "\"Pero tiene amor dentro.\""


translate english a3222_dc599832:


    xy "\"¿Amor?\""


translate english a3222_93af43a2:



    voice "voice/a32/2200310a02.opus"
    aoi "\"Aoi se ha estado divirtiendo tanto cada día.\""


translate english a3222_798cf9bd:



    voice "voice/a32/2200320a02.opus"
    aoi "\"Todas esas emociones olvidadas hace mucho han vuelto de golpe.\""


translate english a3222_63c14429:



    voice "voice/a32/2200330a02.opus"
    aoi "\"Y todo es gracias a ti.\""


translate english a3222_b5609599:



    voice "voice/a32/2200340a02.opus"
    aoi "\"Me gustas, Shinichi.\""


translate english a3222_a8da3440:



    voice "voice/a32/2200350a02.opus"
    aoi "\"Me gustas un montón. Te amo.\""


translate english a3222_0accd139:


    xy "\"\"\"......\"\"\""


translate english a3222_814f3e54:



    voice "voice/a32/2200360a02.opus"
    aoi "\"Shinichi, tienes toda la cara roja.\""


translate english a3222_8a213fef:



    voice "voice/a32/2200370a02.opus"
    aoi "\"¿Aoi sonó como tu novia ahora?\""


translate english a3222_b91bf1fc:


    xy "\"N-No...\""


translate english a3222_2b01f08d:



    voice "voice/a32/2200380a02.opus"
    aoi "\"Aoi se siente tan feliz ahora.\""


translate english a3222_a638f794:



    voice "voice/a32/2200390a02.opus"
    aoi "\"Súper feliz.\""


translate english a3222_f9c06378:



    voice "voice/a32/2200400a02.opus"
    aoi "\"Ser tu amiga es lo mejor que hay.\""


translate english a3222_5409a1e2:



    voice "voice/a32/2200410a02.opus"
    aoi "\"Quizá... pudo haber habido una ruta de Aoi.\""


translate english a3222_275f0fd4:



    voice "voice/a32/2200420a02.opus"
    aoi "\"Pero no ahora.\""


translate english a3222_aeb7513f:



    voice "voice/a32/2200430a02.opus"
    aoi "\"Esta es la ruta de Miyuki.\""


translate english a3222_450fcd36:


    xy "\"Ya te dije, deja de hablar como si estuviéramos en una no...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
