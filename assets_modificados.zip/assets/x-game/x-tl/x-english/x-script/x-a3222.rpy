

translate english a3222_fec07c19:



    voice "voice/a32/2200010a02.opus"
    aoi "\"Aah...!\""


translate english a3222_871bb559:


    xy "\"Aoi!\""


translate english a3222_7ac38128:


    "En el segundo en que salimos, Aoi pierde el equilibrio."


translate english a3222_a99c7b09:


    "Actuando rápido, le paso el brazo por encima de mi hombro para mantenerla de pie."


translate english a3222_868aa791:



    voice "voice/a32/2200020a01.opus"
    mx "\"Wait! I'll help you get her back to the—\""


translate english a3222_a9bc9455:


    xy "\"Not today. Sorry.\""


translate english a3222_67426df7:



    voice "voice/a32/2200030a01.opus"
    mx "\"\"\"......\"\"\""


translate english a3222_5212b539:


    xy "\"See you tomorrow.\""


translate english a3222_a6c281bd:



    voice "voice/a32/2200040a02.opus"
    aoi "\"Bye-bye... Miyuki...\""


translate english a3222_04231276:



    voice "voice/a32/2200050a01.opus"
    mx "\"\"\"......\"\"\""


translate english a3222_8fa861ba:


    "Me alejo con Aoi, dejando a Miyuki parada ahí en silencio."


translate english a3222_ba3c6137:


    "Con un brazo alrededor de mis hombros, Aoi cojea por la calle con su uniforme recién secado."


translate english a3222_73b2ca75:


    xy "\"You sure you want to go back to the manga cafe?\""


translate english a3222_d882c826:


    xy "\"You could always stay a couple nights at my place, you know.\""


translate english a3222_4316d6ef:



    voice "voice/a32/2200060a02.opus"
    aoi "\"That would trigger a risky event flag.\""


translate english a3222_2ac8ccb7:


    xy "\"Okay, what about the hospital?\""


translate english a3222_a16354ef:



    voice "voice/a32/2200070a02.opus"
    aoi "\"Aoi needs to recharge.\""


translate english a3222_9977ad53:



    voice "voice/a32/2200080a02.opus"
    aoi "\"The hospital won't help with that.\""


translate english a3222_9921868b:


    xy "\"Then at least let me call you a taxi.\""


translate english a3222_fe811d62:



    voice "voice/a32/2200090a02.opus"
    aoi "\"Aoi will be fine.\""


translate english a3222_f1a88e31:


    "Lo juro, una vez que se le mete algo en la cabeza, se niega a que la convenzan..."


translate english a3222_c9bb7d60:


    "Por suerte no parece tener fiebre, así que probablemente no es grave... pero si me da otro susto como ese, definitivamente llamo un taxi."


translate english a3222_f7efcdba:



    voice "voice/a32/2200100a02.opus"
    aoi "\"Shinichi...\""


translate english a3222_fd03822d:


    xy "\"Hm? What's up?\""


translate english a3222_afaa82af:



    voice "voice/a32/2200110a02.opus"
    aoi "\"Why did you make friends with me?\""


translate english a3222_06edadb5:


    xy "\"Oh... Well...\""


translate english a3222_1b72838d:


    "Repaso vagamente mis recuerdos... hasta aquel día en que intercambié correos con Aoi por primera vez."


translate english a3222_df7d3fc4:


    "Ese fue el día en que oficialmente nos volvimos \"friends.\""


translate english a3222_c1cbb13d:


    "Luego tomó una foto de Miyuki y de mí juntos, y..."


translate english a3222_e4cf22ea:


    xy "\"I didn't want you to spread that photo around.\""


translate english a3222_de868a95:



    voice "voice/a32/2200120a02.opus"
    aoi "\"That was your whole reason?\""


translate english a3222_c34fe598:


    xy "\"Well, I mean, I had to do SOMETHING, right?\""


translate english a3222_56adb0b5:



    voice "voice/a32/2200130a02.opus"
    aoi "\"But you don't have the patience to deal with other people.\""


translate english a3222_4c7d337e:


    "No está equivocada."


translate english a3222_2b27b9f1:


    "Mukou Aoi es fácilmente la chica más molesta de nuestra clase. Hasta sostener una conversación con ella es agotador."


translate english a3222_51f48229:


    "Y sin embargo lo hice de todos modos."


translate english a3222_ae741523:


    xy "\"I guess... you reminded me of Miyuki.\""


translate english a3222_1ec5ad90:


    xy "\"When we were little, Miyuki had trouble fitting in, too. She was a loner, just like you.\""


translate english a3222_159adb5c:



    voice "voice/a32/2200140a02.opus"
    aoi "\"Bye-bye... Miyuki...\""


translate english a3222_cc916362:



    voice "voice/a32/2200150a02.opus"
    aoi "\"So that's it... You wanted to help Miyuki...\""


translate english a3222_a5a3263c:



    voice "voice/a32/2200160a02.opus"
    aoi "\"Boop boop...\""


translate english a3222_bb58c512:


    xy "\"Huh?\""


translate english a3222_3e79df23:


    "Un minuto va tambaleándose sobre sus propios pies, y al siguiente se desploma al suelo."


translate english a3222_68082ef9:


    xy "\"Y-You okay?!\""


translate english a3222_18ce5c6d:



    voice "voice/a32/2200170a02.opus"
    aoi "\"Yeah...\""


translate english a3222_ac7555c8:


    xy "\"Hold on a sec!\""


translate english a3222_bd38e63b:


    "Saco mi teléfono para llamar un taxi—"


translate english a3222_a7ede83d:



    voice "voice/a32/2200180a02.opus"
    aoi "\"No thanks.\""


translate english a3222_2c3c74ec:



    voice "voice/a32/2200190a02.opus"
    aoi "\"This is where we say goodbye.\""


translate english a3222_d888fb5b:


    xy "\"I'm not just gonna leave you here!\""


translate english a3222_bea15754:



    voice "voice/a32/2200200a02.opus"
    aoi "\"It's fine.\""


translate english a3222_a2c31439:


    "Aoi habla suavemente, con la mirada distante."


translate english a3222_52d8d150:



    voice "voice/a32/2200210a02.opus"
    aoi "\"Once you're on a route, all the other girls fade into the background.\""


translate english a3222_5d643e97:



    voice "voice/a32/2200220a02.opus"
    aoi "\"So you'll forget about me soon enough.\""


translate english a3222_295059bb:



    voice "voice/a32/2200230a02.opus"
    aoi "\"And you'll forget you left me here.\""


translate english a3222_0ae97208:


    xy "\"Over my dead body!\""


translate english a3222_2f4d8f04:


    "Suspirando, me agacho al borde de la calle."


translate english a3222_ecead709:


    xy "\"Hop on.\""


translate english a3222_eb8c670d:



    voice "voice/a32/2200240a02.opus"
    aoi "\"Boop boop...?!\""


translate english a3222_b1636645:


    xy "\"I'll carry you.\""


translate english a3222_b3284abb:



    voice "voice/a32/2200250a02.opus"
    aoi "\"What for?\""


translate english a3222_697ab248:


    xy "\"Well, you won't let me call you a taxi!\""


translate english a3222_5f29e921:


    xy "\"Besides, it'll be faster to just walk there. Now hop on.\""


translate english a3222_9d087517:



    voice "voice/a32/2200260a02.opus"
    aoi "\"But Aoi—\""


translate english a3222_1ed18575:


    xy "\"I said, hop on!\""


translate english a3222_9986f101:


    xy "\"I mean, what else are friends for?\""


translate english a3222_876074ac:



    voice "voice/a32/2200270a02.opus"
    aoi "\"Friends...\""


translate english a3222_b3d0ee86:



    voice "voice/a32/2200280a02.opus"
    aoi "\"...Okay.\""


translate english a3222_a15a5bdc:


    "Aoi se sube a mi espalda, y partimos bajo la luz de la luna."


translate english a3222_1440a77d:


    "Es tan suave... y cálida... y pequeña..."


translate english a3222_533bba97:


    xy "\"Wow, you weigh, like, nothing almost. Are you making sure to eat?\""


translate english a3222_acbbce82:



    voice "voice/a32/2200290a02.opus"
    aoi "\"Aoi drinks a lot of Yabaley's.\""


translate english a3222_8546d283:


    xy "\"You need something with more calories! You're gonna fade away to nothing at this rate.\""


translate english a3222_db87c061:



    voice "voice/a32/2200300a02.opus"
    aoi "\"But it has love in it.\""


translate english a3222_dc599832:


    xy "\"Love?\""


translate english a3222_93af43a2:



    voice "voice/a32/2200310a02.opus"
    aoi "\"Aoi's been having so much fun every day.\""


translate english a3222_798cf9bd:



    voice "voice/a32/2200320a02.opus"
    aoi "\"All those long-forgotten emotions have come rushing back.\""


translate english a3222_63c14429:



    voice "voice/a32/2200330a02.opus"
    aoi "\"And it's all thanks to you.\""


translate english a3222_b5609599:



    voice "voice/a32/2200340a02.opus"
    aoi "\"I like you, Shinichi.\""


translate english a3222_a8da3440:



    voice "voice/a32/2200350a02.opus"
    aoi "\"I like you a whole bunch. I love you.\""


translate english a3222_0accd139:


    xy "\"\"\"......\"\"\""


translate english a3222_814f3e54:



    voice "voice/a32/2200360a02.opus"
    aoi "\"Shinichi, your face is all red.\""


translate english a3222_8a213fef:



    voice "voice/a32/2200370a02.opus"
    aoi "\"Did Aoi sound like your girlfriend just now?\""


translate english a3222_b91bf1fc:


    xy "\"N-No...\""


translate english a3222_2b01f08d:



    voice "voice/a32/2200380a02.opus"
    aoi "\"Aoi feels so happy now.\""


translate english a3222_a638f794:



    voice "voice/a32/2200390a02.opus"
    aoi "\"Super happy.\""


translate english a3222_f9c06378:



    voice "voice/a32/2200400a02.opus"
    aoi "\"Being your friend is the best thing ever.\""


translate english a3222_5409a1e2:



    voice "voice/a32/2200410a02.opus"
    aoi "\"Maybe... there could've been an Aoi route.\""


translate english a3222_275f0fd4:



    voice "voice/a32/2200420a02.opus"
    aoi "\"But not now.\""


translate english a3222_aeb7513f:



    voice "voice/a32/2200430a02.opus"
    aoi "\"This is Miyuki's route.\""


translate english a3222_450fcd36:


    xy "\"I told you, stop talking like we're in a vi—\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
