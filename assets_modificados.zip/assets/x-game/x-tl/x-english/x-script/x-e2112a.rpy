

translate english e2112a_da1e0d65:


    "Creo que entiendo lo que intenta decir."


translate english e2112a_b7222fed:


    "Así que me acerco a ella."


translate english e2112a_5f5a013c:


    "Mientras su mano izquierda se cierne a regañadientes entre nosotros, extiendo la derecha—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
