

translate english e2032b_fdde3b72:


    xy "\"No, Miyuki.\""


translate english e2032b_7af6578b:


    "Admito que nos divertimos mucho aquí juntos."


translate english e2032b_c0507c64:


    "Pero no, no creo que esto deba seguir para siempre."


translate english e2032b_2b9aec48:


    xy "\"I mean, we're still in school, and—\""


translate english e2032b_cf838cae:



    voice "voice/e20/32b00010a01.opus"
    mx "\"I get that!\""


translate english e2032b_6b30bd56:


    "De la nada, Miyuki empieza a gritar."


translate english e2032b_2c6e7fd9:



    voice "voice/e20/32b00020a01.opus"
    mx "\"I get it, okay?!\""


translate english e2032b_fe53bec4:



    voice "voice/e20/32b00030a01.opus"
    mx "\"I know we shouldn't be living like this!\""


translate english e2032b_770ea92f:



    voice "voice/e20/32b00040a01.opus"
    mx "\"And I know it can't last forever!\""


translate english e2032b_7a8ef805:



    voice "voice/e20/32b00050a01.opus"
    mx "\"But... if that's how you feel... then...\""


translate english e2032b_ffc588f8:



    voice "voice/e20/32b00060a01.opus"
    mx "\"Take me away from this world...\""


translate english e2032b_455f3549:



    voice "voice/e20/32b00070a01.opus"
    mx "\"We can go back to the old game... the way things were...\""


translate english e2032b_ab180b13:



    voice "voice/e20/32b00080a01.opus"
    mx "\"Just don't stop loving me...!\""


translate english e2032b_c26f2acd:


    xy "\"...Sorry, uh...\""


translate english e2032b_793bfbaf:


    xy "\"I... I don't understand what you're talking about.\""


translate english e2032b_1f75152c:



    voice "voice/e20/32b00090a01.opus"
    mx "\"......\""


translate english e2032b_292ff08e:



    voice "voice/e20/32b00100a01.opus"
    mx "\"Fine.\""


translate english e2032b_12ef4fc2:



    voice "voice/e20/32b00110a01.opus"
    mx "\"Let's start over.\""


translate english e2032b_d371827c:



    voice "voice/e20/32b00120a01.opus"
    mx "\"I'll start the whole world over.\""


translate english e2032b_3ee1d97c:


    xy "\"Start the world over...?\""


translate english e2032b_ead13e03:



    voice "voice/e20/32b00130a01.opus"
    mx "\"I'll reset this route.\""


translate english e2032b_7e2fe190:



    voice "voice/e20/32b00140a01.opus"
    mx "\"I believe in YOU, okay?\""


translate english e2032b_be2f8254:



    voice "voice/e20/32b00150a01.opus"
    mx "\"I trust that YOU'LL understand how I feel this time around.\""


translate english e2032b_0d8b2d41:


    "Murmura para sí misma..."


translate english e2032b_531165e9:


    "...y toca la pantalla de su teléfono."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
