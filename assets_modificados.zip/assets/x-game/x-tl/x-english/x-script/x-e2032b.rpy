

translate english e2032b_fdde3b72:


    xy "\"No, Miyuki.\""


translate english e2032b_7af6578b:


    "Admito que nos divertimos mucho aquí juntos."


translate english e2032b_c0507c64:


    "Pero no, no creo que esto deba seguir para siempre."


translate english e2032b_2b9aec48:


    xy "\"Digo, todavía estamos en la escuela, y—\""


translate english e2032b_cf838cae:



    voice "voice/e20/32b00010a01.opus"
    mx "\"¡Lo entiendo!\""


translate english e2032b_6b30bd56:


    "De la nada, Miyuki empieza a gritar."


translate english e2032b_2c6e7fd9:



    voice "voice/e20/32b00020a01.opus"
    mx "\"¡Lo entiendo, ¿sí?!\""


translate english e2032b_fe53bec4:



    voice "voice/e20/32b00030a01.opus"
    mx "\"¡Sé que no deberíamos estar viviendo así!\""


translate english e2032b_770ea92f:



    voice "voice/e20/32b00040a01.opus"
    mx "\"¡Y sé que no puede durar para siempre!\""


translate english e2032b_7a8ef805:



    voice "voice/e20/32b00050a01.opus"
    mx "\"Pero... si eso es lo que sientes... entonces...\""


translate english e2032b_ffc588f8:



    voice "voice/e20/32b00060a01.opus"
    mx "\"Sácame de este mundo...\""


translate english e2032b_455f3549:



    voice "voice/e20/32b00070a01.opus"
    mx "\"Podemos volver al juego antiguo... a como eran las cosas...\""


translate english e2032b_ab180b13:



    voice "voice/e20/32b00080a01.opus"
    mx "\"¡Solo no dejes de amarme...!\""


translate english e2032b_c26f2acd:


    xy "\"...Perdón, eh...\""


translate english e2032b_793bfbaf:


    xy "\"Yo... no entiendo de qué estás hablando.\""


translate english e2032b_1f75152c:



    voice "voice/e20/32b00090a01.opus"
    mx "\"......\""


translate english e2032b_292ff08e:



    voice "voice/e20/32b00100a01.opus"
    mx "\"Bien.\""


translate english e2032b_12ef4fc2:



    voice "voice/e20/32b00110a01.opus"
    mx "\"Empecemos de nuevo.\""


translate english e2032b_d371827c:



    voice "voice/e20/32b00120a01.opus"
    mx "\"Empezaré el mundo entero de nuevo.\""


translate english e2032b_3ee1d97c:


    xy "\"¿Empezar el mundo de nuevo...?\""


translate english e2032b_ead13e03:



    voice "voice/e20/32b00130a01.opus"
    mx "\"Reiniciaré esta ruta.\""


translate english e2032b_7e2fe190:



    voice "voice/e20/32b00140a01.opus"
    mx "\"Creo en TI, ¿sí?\""


translate english e2032b_be2f8254:



    voice "voice/e20/32b00150a01.opus"
    mx "\"Confío en que esta vez entenderás cómo me siento.\""


translate english e2032b_0d8b2d41:


    "Murmura para sí misma..."


translate english e2032b_531165e9:


    "...y toca la pantalla de su teléfono."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
