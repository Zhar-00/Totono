

translate english a1132b_4548f5f2:


    xy "\"Hmmm... I don't think it works like that.\""


translate english a1132b_4c6b99d9:


    xy "\"You can't just DECIDE to be friends, you know?\""


translate english a1132b_b490b36f:


    "A decir verdad, es solo una excusa."


translate english a1132b_c6b025a4:


    "Mi verdadera razón tiene que ver con Miyuki."


translate english a1132b_7ace8e06:


    "No quiero estar cerca de ella más de lo necesario."


translate english a1132b_48f0c80f:


    xy "\"I can't make any promises.\""


translate english a1132b_cb2a6812:



    voice "voice/a11/32b00010a02.opus"
    aoi "\"You can't?\""


translate english a1132b_880ffb61:



    voice "voice/a11/32b00020a02.opus"
    aoi "\"What about Miyuki?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
