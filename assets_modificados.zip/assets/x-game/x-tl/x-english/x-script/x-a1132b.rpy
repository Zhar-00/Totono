

translate english a1132b_4548f5f2:


    xy "\"Mmm... No creo que funcione así.\""


translate english a1132b_4c6b99d9:


    xy "\"No puedes simplemente DECIDIR ser amigos, ¿sabes?\""


translate english a1132b_b490b36f:


    "A decir verdad, es solo una excusa."


translate english a1132b_c6b025a4:


    "Mi verdadera razón tiene que ver con Miyuki."


translate english a1132b_7ace8e06:


    "No quiero estar cerca de ella más de lo necesario."


translate english a1132b_48f0c80f:


    xy "\"No puedo prometer nada.\""


translate english a1132b_cb2a6812:



    voice "voice/a11/32b00010a02.opus"
    aoi "\"¿No puedes?\""


translate english a1132b_880ffb61:



    voice "voice/a11/32b00020a02.opus"
    aoi "\"¿Y Miyuki?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
