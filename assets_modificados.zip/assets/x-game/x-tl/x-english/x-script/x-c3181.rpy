

translate english c3181_7e337848:


    "—Veinte minutos después..."


translate english c3181_3a134259:


    "Estoy parado frente a la puerta de la escuela."


translate english c3181_a4c34179:


    "Están completamente cerradas con llave; incluso hay un candado en la puerta peatonal."


translate english c3181_1c785fec:


    "No hay otra forma de colarse."


translate english c3181_f60ec7f5:


    "Pero si ese juego es fiel a la realidad, entonces Aoi definitivamente está ahí."


translate english c3181_8d23e345:


    "Esta es mi última oportunidad de dar marcha atrás."


translate english c3181_b26fd824:


    "Me detengo en la entrada para respirar hondo."


translate english strings:


    old "Прокрасться в школу"
    new "Colarme en la escuela"


    old "Сдаться и пойти домой"
    new "Rendirme e irme a casa"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
