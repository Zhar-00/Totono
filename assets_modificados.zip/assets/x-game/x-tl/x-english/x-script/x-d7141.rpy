

translate english d7141_11292feb:


    "...Se acabó."


translate english d7141_65bf6db4:


    "Ya no tengo que agonizar por la traición de mi novia."


translate english d7141_29b78ea0:


    "Tuve mi venganza. Estoy satisfecho."


translate english d7141_2298774f:


    "Por fin, todo se acabó."


translate english d7141_005bd48d:


    "Todo."


translate english d7141_781ec564:


    "Me tambaleo de vuelta a la casa con piernas temblorosas."


translate english d7141_bbbc4c5e:



    voice "voice/d71/4100010a01.opus"
    mx "\"Shinichi...\""


translate english d7141_77fe258f:


    xy "\"Miyuki? I didn't realize you were still here...\""


translate english d7141_150b1fee:


    "Pensé que la sala de estar estaba vacía..."


translate english d7141_fcf9fbac:


    "...y sin embargo, ahí está ella, esperándome."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
