


translate english a0113u_38c0fb9a:


    xy "\"......What the?\""


translate english a0113u_0ca56d58:


    "¿Marqué mal?"


translate english a0113u_398cab30:


    "No, espera... Aunque así fuera, esto sigue sin tener sentido."


translate english a0113u_c4c1e2b0:


    "Cuando hay un problema para conectar una llamada, normalmente deberías oír uno de esos mensajes automatizados, ¿no?"


translate english a0113u_c247c1c9:


    "Es como si este teléfono estuviera roto o algo así..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
