

translate english e2164a_235eca0a:


    "El precio es... más o menos lo que esperaba, sí."


translate english e2164a_b5527cdd:


    "Qué más da. Miyuki realmente parece que le gusta, así que—"


translate english e2164a_92cc46fc:


    xy "\"¿Quieres que te lo compre?\""


translate english e2164a_2e7dcbca:



    voice "voice/e21/64a00010a01.opus"
    mx "\"¿Eh? Pero...\""


translate english e2164a_9f69503b:


    xy "\"Lo quieres, ¿no?\""


translate english e2164a_76dcc8da:



    voice "voice/e21/64a00020a01.opus"
    mx "\"No me quedaría bien—\""


translate english e2164a_86e433a0:


    xy "\"Claro que sí.\""


translate english e2164a_e38843eb:



    voice "voice/e21/64a00030a01.opus"
    mx "\"¿Tú crees...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
