

translate english e2164a_235eca0a:


    "El precio es... más o menos lo que esperaba, sí."


translate english e2164a_b5527cdd:


    "Qué más da. Miyuki realmente parece que le gusta, así que—"


translate english e2164a_92cc46fc:


    xy "\"Want me to buy it for you?\""


translate english e2164a_2e7dcbca:



    voice "voice/e21/64a00010a01.opus"
    mx "\"Huh? But...\""


translate english e2164a_9f69503b:


    xy "\"You want it, don't you?\""


translate english e2164a_76dcc8da:



    voice "voice/e21/64a00020a01.opus"
    mx "\"It wouldn't look good on me—\""


translate english e2164a_86e433a0:


    xy "\"Sure it will.\""


translate english e2164a_e38843eb:



    voice "voice/e21/64a00030a01.opus"
    mx "\"You think so...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
