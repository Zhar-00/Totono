

translate english c5181_f1e15343:



    voice "voice/c51/8100010a01.opus"
    mx "\"¡Ya llegué!\""


translate english c5181_af1c7a81:



    voice "voice/c51/8100020a01.opus"
    mx "\"Conseguí helado de Kawakami.\""


translate english c5181_1922c294:



    voice "voice/c51/8100030a02.opus"
    aoi "\"¡Gracias!\""


translate english c5181_71a9631b:



    voice "voice/c51/8100040a01.opus"
    mx "\"Ahora, vámonos, ¿sí?\""


translate english c5181_958d144c:


    "Miyuki se marcha, con los ojos brillantes."


translate english c5181_67af52aa:


    "Realmente ama Catnip, ¿verdad..."


translate english c5181_3e5a7a8e:


    "Caminamos junto al río, disfrutando de nuestro helado."


translate english c5181_d58fbab5:



    voice "voice/c51/8100050a01.opus"
    mx "\"¡Mmmm! ¡Está tan ricooo!\""


translate english c5181_4ff35c79:



    voice "voice/c51/8100060a01.opus"
    mx "\"El sabor de frijol rojo fue la decisión correcta.\""


translate english c5181_a69aac39:



    voice "voice/c51/8100070a02.opus"
    aoi "\"¡El de fresa también está bastante bueno!\""


translate english c5181_601e0f2c:


    "Saborean sus golosinas lado a lado."


translate english c5181_7d64aac2:


    "Se siente como un déjà vu."


translate english c5181_b0079499:


    xy "\"Miyuki, ¿seguro que puedes comer eso con tu dieta?\""


translate english c5181_2613cb8c:



    voice "voice/c51/8100080a01.opus"
    mx "\"Ah, dejé la obra.\""


translate english c5181_5c2d1a76:


    xy "\"¿La dejaste?\""


translate english c5181_93663c40:



    voice "voice/c51/8100090a01.opus"
    mx "\"Mi senpai y yo no pudimos ponernos de acuerdo sobre la escena final, así que ahora están cambiando todo el guion.\""


translate english c5181_5d462e76:



    voice "voice/c51/8100100a02.opus"
    aoi "\"Ay no, Miyuki... Qué horrible. Practicaste tanto para eso...\""


translate english c5181_783a6de2:



    voice "voice/c51/8100110a01.opus"
    mx "\"¡Está bien! ¡De verdad!\""


translate english c5181_c01c542b:



    voice "voice/c51/8100120a01.opus"
    mx "\"¿Y qué si me perdí un papel protagónico? Tengo ambiciones mucho más elevadas que eso.\""


translate english c5181_28d75442:



    voice "voice/c51/8100130a02.opus"
    aoi "\"¿Elevadas? ¿Como en el espacio?\""


translate english c5181_15abe3fc:


    "No tan elevado, tonto..."


translate english c5181_7bdbde5f:



    voice "voice/c51/8100140a01.opus"
    mx "\"No, no. Mucho más alto.\""


translate english c5181_87fdeadc:



    voice "voice/c51/8100150a01.opus"
    mx "\"Mil veces más alto que eso.\""


translate english c5181_13feb370:


    "Miyuki mira al cielo."


translate english c5181_b9232647:


    "De alguna manera me recuerda a Aoi."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
