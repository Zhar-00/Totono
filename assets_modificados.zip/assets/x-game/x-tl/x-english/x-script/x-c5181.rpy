

translate english c5181_f1e15343:



    voice "voice/c51/8100010a01.opus"
    mx "\"I'm back!\""


translate english c5181_af1c7a81:



    voice "voice/c51/8100020a01.opus"
    mx "\"Got us some ice cream from Kawakami.\""


translate english c5181_1922c294:



    voice "voice/c51/8100030a02.opus"
    aoi "\"Thank you!\""


translate english c5181_71a9631b:



    voice "voice/c51/8100040a01.opus"
    mx "\"Now then, let's get going, shall we?\""


translate english c5181_958d144c:


    "Miyuki se marcha, con los ojos brillantes."


translate english c5181_67af52aa:


    "Realmente ama Catnip, ¿verdad..."


translate english c5181_3e5a7a8e:


    "Caminamos junto al río, disfrutando de nuestro helado."


translate english c5181_d58fbab5:



    voice "voice/c51/8100050a01.opus"
    mx "\"Mmmm! It's so gooood!\""


translate english c5181_4ff35c79:



    voice "voice/c51/8100060a01.opus"
    mx "\"Red bean flavor was totally the right call.\""


translate english c5181_a69aac39:



    voice "voice/c51/8100070a02.opus"
    aoi "\"Strawberry's pretty good, too!\""


translate english c5181_601e0f2c:


    "Saborean sus golosinas lado a lado."


translate english c5181_7d64aac2:


    "Se siente como un déjà vu."


translate english c5181_b0079499:


    xy "\"Miyuki, are you sure you're allowed to eat that on your diet?\""


translate english c5181_2613cb8c:



    voice "voice/c51/8100080a01.opus"
    mx "\"Oh, I quit the play.\""


translate english c5181_5c2d1a76:


    xy "\"You quit?\""


translate english c5181_93663c40:



    voice "voice/c51/8100090a01.opus"
    mx "\"My senpai and I just couldn't agree on what to do about the final scene, so now they're changing the whole script.\""


translate english c5181_5d462e76:



    voice "voice/c51/8100100a02.opus"
    aoi "\"Oh no, Miyuki... That's awful. You practiced so hard for it...\""


translate english c5181_783a6de2:



    voice "voice/c51/8100110a01.opus"
    mx "\"It's fine! Really!\""


translate english c5181_c01c542b:



    voice "voice/c51/8100120a01.opus"
    mx "\"So what if I missed out on a leading role? I have far more lofty ambitions than that.\""


translate english c5181_28d75442:



    voice "voice/c51/8100130a02.opus"
    aoi "\"Lofty? Like in space?\""


translate english c5181_15abe3fc:


    "No tan elevado, tonto..."


translate english c5181_7bdbde5f:



    voice "voice/c51/8100140a01.opus"
    mx "\"No, no. Way higher.\""


translate english c5181_87fdeadc:



    voice "voice/c51/8100150a01.opus"
    mx "\"A thousand times higher than that.\""


translate english c5181_13feb370:


    "Miyuki mira al cielo."


translate english c5181_b9232647:


    "De alguna manera me recuerda a Aoi."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
