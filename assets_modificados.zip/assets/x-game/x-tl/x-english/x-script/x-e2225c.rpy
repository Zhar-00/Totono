

translate english e2225c_c018b486:



    voice "voice/e22/25c00010a01.opus"
    mx "Aah... nnn... nngghh... nn... Cada vez que te corres dentro de mí..."



translate english e2225c_01f3872b:



    voice "voice/e22/25c00020a01.opus"
    mx "Me siento tan validada... Estar aquí... Estar contigo..."



translate english e2225c_6ade5ada:



    voice "voice/e22/25c00030a01.opus"
    mx "Todo se siente tan bien..."


translate english e2225c_cdb8685f:



    voice "voice/e22/25c00040a01.opus"
    mx "Nunca te dejaré ir..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
