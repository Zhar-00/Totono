

translate english a1161_f9a3f9ff:



    voice "voice/a11/6100010a02.opus"
    aoi "\"Miyuki!\""


translate english a1161_5a299783:



    voice "voice/a11/6100020a02.opus"
    aoi "\"Let's have lunch tog—\""


translate english a1161_15a26ad8:



    voice "voice/a11/6100030a01.opus"
    mx "\"Sorry, I already have plans with some other friends.\""


translate english a1161_a3ec95c0:



    voice "voice/a11/6100040a02.opus"
    aoi "\"Oh...\""


translate english a1161_702b4c4a:



    voice "voice/a11/6100050a01.opus"
    mx "\"Also, I'd prefer if you didn't refer to me in that way.\""


translate english a1161_7c987658:



    voice "voice/a11/6100060a02.opus"
    aoi "\"Got it.\""


translate english a1161_ac2d6953:



    voice "voice/a11/6100070a02.opus"
    aoi "\"Miyuki! About the math homework—\""


translate english a1161_0495bc0a:



    voice "voice/a11/6100080a01.opus"
    mx "\"There's no point in doing it if you don't figure it out yourself. Letting you see mine won't do you any favors in the long run.\""


translate english a1161_6da3facd:



    voice "voice/a11/6100090a02.opus"
    aoi "\"Okay.\""


translate english a1161_aea73492:



    voice "voice/a11/6100100a02.opus"
    aoi "\"Miyuki, you're so nice.\""


translate english a1161_870ab2a3:



    voice "voice/a11/6100110a01.opus"
    mx "\"Just don't expect me to coddle you.\""


translate english a1161_6180efcf:



    voice "voice/a11/6100120a01.opus"
    mx "\"Also, could you please stop calling me that?\""


translate english a1161_ebd6a76a:



    voice "voice/a11/6100130a02.opus"
    aoi "\"Sorry.\""


translate english a1161_92542a9d:



    voice "voice/a11/6100140a02.opus"
    aoi "\"Miyuki, do you wanna team up for the art proj—\""


translate english a1161_1400420f:



    voice "voice/a11/6100150a01.opus"
    mx "\"Stop calling me that.\""


translate english a1161_cc99ed02:



    voice "voice/a11/6100160a02.opus"
    aoi "\"Sorry.\""


translate english a1161_189b8ebc:



    voice "voice/a11/6100170a01.opus"
    mx "\"Anyway, I have a specific friend I always team up with.\""


translate english a1161_c70f7684:



    voice "voice/a11/6100180a02.opus"
    aoi "\"Then what about tomorr—\""


translate english a1161_62678170:



    voice "voice/a11/6100190a01.opus"
    mx "\"Not tomorrow, not ever. Now go ask someone else.\""


translate english a1161_fdfdcc53:



    voice "voice/a11/6100200a02.opus"
    aoi "\"Miyuki! Let's hang out after school.\""


translate english a1161_3b80340e:



    voice "voice/a11/6100210a01.opus"
    mx "\"You're doing it again.\""


translate english a1161_d8c0a20f:



    voice "voice/a11/6100220a02.opus"
    aoi "\"Sorry.\""


translate english a1161_09eaabd8:



    voice "voice/a11/6100230a01.opus"
    mx "\"I have rehearsal today, so I don't think I'll have time.\""


translate english a1161_f3c9ff0f:



    voice "voice/a11/6100240a02.opus"
    aoi "\"Aoi can wait.\""


translate english a1161_77cfe349:



    voice "voice/a11/6100250a01.opus"
    mx "\"Rehearsal gets out pretty late.\""


translate english a1161_f2183195:



    voice "voice/a11/6100260a02.opus"
    aoi "\"Aoi can still wait.\""


translate english a1161_86d6926f:



    voice "voice/a11/6100270a01.opus"
    mx "\"I'm probably going to hang out with the rest of the theatre club afterwards.\""


translate english a1161_718cfa16:



    voice "voice/a11/6100280a02.opus"
    aoi "\"We're friends.\""


translate english a1161_b1e6b8e7:



    voice "voice/a11/6100290a02.opus"
    aoi "\"So Aoi will wait.\""


translate english a1161_95a0032d:



    voice "voice/a11/6100300a01.opus"
    mx "\"Haah... Suit yourself, then.\""


translate english a1161_f2588066:


    "Con su bate de béisbol al hombro, Miyuki sale del salón sin mirar atrás."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
