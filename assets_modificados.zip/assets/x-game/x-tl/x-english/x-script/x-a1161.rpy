

translate english a1161_f9a3f9ff:



    voice "voice/a11/6100010a02.opus"
    aoi "\"¡Miyuki!\""


translate english a1161_5a299783:



    voice "voice/a11/6100020a02.opus"
    aoi "\"Almorcemos jun—\""


translate english a1161_15a26ad8:



    voice "voice/a11/6100030a01.opus"
    mx "\"Perdón, ya tengo planes con otras amigas.\""


translate english a1161_a3ec95c0:



    voice "voice/a11/6100040a02.opus"
    aoi "\"Oh...\""


translate english a1161_702b4c4a:



    voice "voice/a11/6100050a01.opus"
    mx "\"Además, preferiría que no te refirieras a mí de esa forma.\""


translate english a1161_7c987658:



    voice "voice/a11/6100060a02.opus"
    aoi "\"Entendido.\""


translate english a1161_ac2d6953:



    voice "voice/a11/6100070a02.opus"
    aoi "\"¡Miyuki! Sobre la tarea de mate—\""


translate english a1161_0495bc0a:



    voice "voice/a11/6100080a01.opus"
    mx "\"No tiene caso hacerla si no la resuelves tú mismo. Dejarte ver la mía no te ayudará a la larga.\""


translate english a1161_6da3facd:



    voice "voice/a11/6100090a02.opus"
    aoi "\"Ok.\""


translate english a1161_aea73492:



    voice "voice/a11/6100100a02.opus"
    aoi "\"Miyuki, eres tan linda.\""


translate english a1161_870ab2a3:



    voice "voice/a11/6100110a01.opus"
    mx "\"Pero no esperes que te consienta.\""


translate english a1161_6180efcf:



    voice "voice/a11/6100120a01.opus"
    mx "\"Además, ¿podrías dejar de llamarme así?\""


translate english a1161_ebd6a76a:



    voice "voice/a11/6100130a02.opus"
    aoi "\"Perdón.\""


translate english a1161_92542a9d:



    voice "voice/a11/6100140a02.opus"
    aoi "\"Miyuki, ¿quieres unirte conmigo para el proyecto de arte—\""


translate english a1161_1400420f:



    voice "voice/a11/6100150a01.opus"
    mx "\"Deja de llamarme así.\""


translate english a1161_cc99ed02:



    voice "voice/a11/6100160a02.opus"
    aoi "\"Perdón.\""


translate english a1161_189b8ebc:



    voice "voice/a11/6100170a01.opus"
    mx "\"En fin, tengo una amiga específica con quien siempre me junto.\""


translate english a1161_c70f7684:



    voice "voice/a11/6100180a02.opus"
    aoi "\"Entonces ¿qué tal maña—?\""


translate english a1161_62678170:



    voice "voice/a11/6100190a01.opus"
    mx "\"Ni mañana ni nunca. Ahora ve a preguntarle a alguien más.\""


translate english a1161_fdfdcc53:



    voice "voice/a11/6100200a02.opus"
    aoi "\"¡Miyuki! Salgamos después de clases.\""


translate english a1161_3b80340e:



    voice "voice/a11/6100210a01.opus"
    mx "\"Lo volviste a hacer.\""


translate english a1161_d8c0a20f:



    voice "voice/a11/6100220a02.opus"
    aoi "\"Perdón.\""


translate english a1161_09eaabd8:



    voice "voice/a11/6100230a01.opus"
    mx "\"Hoy tengo ensayo, así que no creo tener tiempo.\""


translate english a1161_f3c9ff0f:



    voice "voice/a11/6100240a02.opus"
    aoi "\"Aoi puede esperar.\""


translate english a1161_77cfe349:



    voice "voice/a11/6100250a01.opus"
    mx "\"El ensayo termina bastante tarde.\""


translate english a1161_f2183195:



    voice "voice/a11/6100260a02.opus"
    aoi "\"Aoi puede esperar igual.\""


translate english a1161_86d6926f:



    voice "voice/a11/6100270a01.opus"
    mx "\"Probablemente me junte con el resto del club de teatro después.\""


translate english a1161_718cfa16:



    voice "voice/a11/6100280a02.opus"
    aoi "\"Somos amigas.\""


translate english a1161_b1e6b8e7:



    voice "voice/a11/6100290a02.opus"
    aoi "\"Así que Aoi esperará.\""


translate english a1161_95a0032d:



    voice "voice/a11/6100300a01.opus"
    mx "\"Haah... Como quieras, entonces.\""


translate english a1161_f2588066:


    "Con su bate de béisbol al hombro, Miyuki sale del salón sin mirar atrás."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
