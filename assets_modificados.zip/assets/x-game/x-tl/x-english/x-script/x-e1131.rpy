

translate english e1131_0c06bdf3:



    voice "voice/e11/3100010a01.opus"
    mx "\"Escucha, Shinichi.\""


translate english e1131_9cf4565b:


    "Miyuki interrumpe."


translate english e1131_56d1f85b:



    voice "voice/e11/3100020a01.opus"
    mx "\"Tengo algo que quiero decirte.\""


translate english e1131_7b1596e5:



    voice "voice/e11/3100030a01.opus"
    mx "\"Subamos a la azotea de la escuela.\""


translate english e1131_eb5640ba:


    xy "\"Mmm... Está bien.\""


translate english e1131_412473ef:


    "Dejando de lado el pequeño detalle de que es fin de semana, subir juntos al techo es una actividad bastante común para nosotros."


translate english e1131_c45d6df1:


    "Dudo que realmente necesite estar en guardia—"


translate english e1131_bb2360cf:



    voice "voice/e11/3100040a01.opus"
    mx "\"¡Oh, espera!\""


translate english e1131_d27eeafa:


    xy "\"¿Eh?\""


translate english e1131_8554e825:



    voice "voice/e11/3100050a01.opus"
    mx "\"No te tomes esa sopa de miso. Creo que puede estar pasada.\""


translate english e1131_87f66815:


    "Para mí se ve perfectamente bien, pero si ella dice que se echó a perder, supongo que así debe ser."


translate english e1131_bece92e5:


    "Vuelvo a dejar el tazón y tomo el pescado a la parrilla en su lugar."


translate english e1131_2d491a4c:



    voice "voice/e11/3100060a01.opus"
    mx "\"Y ahora, vamos a cortarte ese pelo.\""


translate english e1131_e2cd55a7:


    xy "\"¿Qué tiene de malo mi pelo?\""


translate english e1131_6a90875b:



    voice "voice/e11/3100070a01.opus"
    mx "\"¡Está todo greñudo!\""


translate english e1131_8a941212:


    "Entonces me doy cuenta."


translate english e1131_fe3c48d2:


    "Mi cabello ha crecido tanto que toca mi cuello."


translate english e1131_b4aed259:


    "¿Cuándo pasó ESO...?"


translate english e1131_d3389c82:



    voice "voice/e11/3100080a01.opus"
    mx "\"Hora de arreglarte, señor.\""


translate english e1131_81e67f25:


    "Extiende un periódico en el suelo y me hace sentarme sobre él."


translate english e1131_0ab4d8d4:


    "Con las tijeras en mano, hace su mejor imitación de peluquera."


translate english e1131_ff967e1f:


    "Corte, corte, corte, corte..."


translate english e1131_db6e2ed7:


    "Los sonidos de su peine y sus tijeras crean un ritmo ligero y agradable."


translate english e1131_2dac2363:


    "Su cuerpo se balancea de arriba abajo, y sus pechos rebotan con los movimientos, justo delante de mi cara."


translate english e1131_b4c0f267:


    "Nada mal."


translate english e1131_a0b81d20:



    voice "voice/e11/3100090a01.opus"
    mx "\"...¿Shinichi? ¿Pasa algo?\""


translate english e1131_75cbe31f:


    xy "\"No, no... Solo pensaba que eres bastante buena en esto.\""


translate english e1131_997b47af:



    voice "voice/e11/3100100a01.opus"
    mx "\"Bueno, a estas alturas ya he practicado bastante, ¿sabes?\""


translate english e1131_c102eed7:


    "¿A quién más le ha estado cortando el cabello?"


translate english e1131_ebf6a925:


    "De hecho, estoy un poco celoso."


translate english e1131_a2bf0a97:



    voice "voice/e11/3100110a01.opus"
    mx "\"Al principio era malísima.\""


translate english e1131_2fc5a4a2:



    voice "voice/e11/3100120a01.opus"
    mx "\"Me emocioné un poco y casi te corto—\""


translate english e1131_0699559d:


    xy "\"¿Casi me cortas qué?\""


translate english e1131_f5e792cd:


    xy "\"...¡Iik!\""


translate english e1131_695bd953:


    xy "\"¡Uoh! ¡¿M-Miyuki?! ¡Esa es mi oreja! ¡No hablas en serio, verdad?!\""


translate english e1131_37044f38:



    voice "voice/e11/3100130a01.opus"
    mx "\"¿Qué, no confías en mí?\""


translate english e1131_56140990:


    xy "\"C-Claro que confío en ti, pero...\""


translate english e1131_39f4a1fa:



    voice "voice/e11/3100140a01.opus"
    mx "\"Sigue moviéndote y se me puede resbalar la mano.\""


translate english e1131_ffbbe9d0:


    xy "\"¡No me estoy moviendo!\""


translate english e1131_0881cb85:



    voice "voice/e11/3100150a01.opus"
    mx "\"Bien.\""


translate english e1131_f68c1090:



    voice "voice/e11/3100160a01.opus"
    mx "\"Ya está, terminado.\""


translate english e1131_eac5f8a7:


    xy "\"G-Genial...\""


translate english e1131_b11d415f:


    "Pero antes de que pueda soltar un suspiro de alivio—"


translate english e1131_b5a60c7e:



    voice "voice/e11/3100170a01.opus"
    mx "\"Ahora te afeitaré.\""


translate english e1131_8200f6fe:


    xy "\"¿Q-Qué...? ¿Afeitarme...?\""


translate english e1131_c6ba3493:



    voice "voice/e11/3100180a01.opus"
    mx "\"No te preocupes. No te voy a cortar.\""


translate english e1131_0d73e069:


    "Me cubre los ojos con una toalla tibia y húmeda."


translate english e1131_2026e452:



    voice "voice/e11/3100190a01.opus"
    mx "\"Quédate quieto, ¿sí?\""


translate english e1131_a35e7343:


    xy "\"Está bien...\""


translate english e1131_532912eb:


    "Siento que unta la crema de afeitar en mi cara."


translate english e1131_bb3e7cd2:


    "La navaja de barbero de grado profesional se desliza sobre mi piel."


translate english e1131_9810caf4:



    voice "voice/e11/3100200a01.opus"
    mx "\"¡Mira lo larga que te ha crecido la barba!\""


translate english e1131_c6c38130:



    voice "voice/e11/3100210a01.opus"
    mx "\"Será mejor que te arregle.\""


translate english e1131_6f324b95:


    "Se inclina hacia adelante, apretando su pecho contra mí."


translate english e1131_4ce6c1d0:


    "Pero en lugar de disfrutarlo, estoy un poco demasiado distraído por el afilado instrumento que sostiene en mi garganta..."


translate english e1131_af042826:



    voice "voice/e11/3100220a01.opus"
    mx "\"Escucha, em... He estado pensando mucho...\""


translate english e1131_d2440001:



    voice "voice/e11/3100230a01.opus"
    mx "\"Quiero tener TU bebé.\""


translate english e1131_3f9c0829:


    xy "\"¡¿Bwugh?!\""


translate english e1131_859eef8a:


    "La toalla casi se resbala de mi cara."


translate english e1131_3a243529:



    voice "voice/e11/3100240a01.opus"
    mx "\"...¿Qué pasa?\""


translate english e1131_651a53a9:



    voice "voice/e11/3100250a01.opus"
    mx "\"Sigue moviéndote así y te puedo cortar la yugular.\""


translate english e1131_0accd139:


    xy "\"......\""


translate english e1131_3c3ff5d9:


    "Puedo sentir la fría hoja de metal en mi piel."


translate english e1131_eda68fde:



    voice "voice/e11/3100260a01.opus"
    mx "\"Además, no creo que sea tan sorprendente.\""


translate english e1131_7c9122c0:



    voice "voice/e11/3100270a01.opus"
    mx "\"Piensa en todo el sexo que hemos tenido.\""


translate english e1131_35ac7406:



    voice "voice/e11/3100280a01.opus"
    mx "\"Te di mi virginidad por tu cumpleaños... te atendí con uniforme de sirvienta... hasta lo hicimos en la azotea de la escuela.\""


translate english e1131_9622414b:


    "Espera, ¿qué? Qué raro... Mi memoria está borrosa..."


translate english e1131_9f735308:



    voice "voice/e11/3100290a01.opus"
    mx "\"Ah, cierto. No te acordarías de que te di mi virginidad.\""


translate english e1131_b427bf90:



    voice "voice/e11/3100300a01.opus"
    mx "\"Ni del servicio de sirvienta...\""


translate english e1131_5dd92220:



    voice "voice/e11/3100310a01.opus"
    mx "\"Ni de la vez que dejamos ese escritorio todo mojado...\""


translate english e1131_778cba48:



    voice "voice/e11/3100320a01.opus"
    mx "\"Esos recuerdos desaparecieron cuando recargué.\""


translate english e1131_f0f82971:


    "¿Recargada? ¿De qué está hablando?"


translate english e1131_732edbc2:


    "Como para sobrescribir mi confusión, la navaja se detiene de repente en mi garganta."


translate english e1131_5c163b78:



    voice "voice/e11/3100330a01.opus"
    mx "\"Pero el asunto es que... yo sí me acuerdo.\""


translate english e1131_3b08a885:



    voice "voice/e11/3100340a01.opus"
    mx "\"Me acuerdo de cuánto te esforzaste TÚ por subir mis puntos de afecto... y luego consumamos nuestro amor juntos.\""


translate english e1131_5e8899f9:



    voice "voice/e11/3100350a01.opus"
    mx "\"Supongo que TÚ tampoco lo has olvidado, ¿verdad?\""


translate english e1131_a8d56b6c:



    voice "voice/e11/3100360a01.opus"
    mx "\"Dime... TÚ me amas, ¿verdad?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
