


translate english a7161_94e4bd3a:



    voice "voice/a71/6100050a01.opus"
    mx "\"Happy birthday, sweetie.\""



translate english a7161_b3877598:


    xy "\"Thanks.\""



translate english a7161_fcf68c82:


    "Nos sentamos uno frente al otro en la mesa."



translate english a7161_d8d20b7d:


    "Entre nosotros hay un pastel de cumpleaños que Miyuki horneó ella misma."



translate english a7161_a41db1c6:


    "With just the two of us, it's not really a \"party\", pero es todo lo que podría pedir."



translate english a7161_80e6c4bc:


    xy "\"Man, how long's it been since the last time we celebrated my birthday together?\""



translate english a7161_c5fc2a34:



    voice "voice/a71/6100060a01.opus"
    mx "\"Since grade school, at least.\""



translate english a7161_471ac925:



    voice "voice/a71/6100070a01.opus"
    mx "\"But now things are finally back to normal.\""



translate english a7161_59b25197:


    xy "\"I'd say they're even BETTER than normal, personally.\""



translate english a7161_6d73b146:



    voice "voice/a71/6100080a01.opus"
    mx "\"...Yeah...\""



translate english a7161_76f47b85:


    "En aquel entonces solo éramos amigos..."



translate english a7161_809f4b6d:


    "...pero ahora estamos enamorados."



translate english a7161_ce6c43c6:


    "Sigue pareciendo demasiado bueno para ser verdad."



translate english a7161_e4157688:



    voice "voice/a71/6100090a01.opus"
    mx "\"Now then, time to cut the cake!\""



translate english a7161_47dce96f:


    "Miyuki saca un cuchillo de pastel de su bolsa."



translate english a7161_8d0bcb8c:


    xy "\"...Isn't this cake kinda big for just the two of us?\""



translate english a7161_bfd44510:



    voice "voice/a71/6100100a01.opus"
    mx "\"Oh, it's fine! You can never have too much birthday cake!\""



translate english a7161_6475611e:


    xy "\"...You made this thing for yourself, didn't you...\""



translate english a7161_b30922f6:



    voice "voice/a71/6100110a01.opus"
    mx "\"What was that?\""



translate english a7161_b50d5a91:


    xy "\"N-Nothing!\""



translate english a7161_a165443a:


    "Probablemente no debería hacerla enojar mientras sostiene cubiertos..."



translate english a7161_4070cf9f:


    "Mientras tanto, coloca una rebanada de pastel en cada uno de nuestros platos."



translate english a7161_8fd11235:


    xy "\"Wow, this looks great...\""



translate english a7161_290b6c17:



    voice "voice/a71/6100120a01.opus"
    mx "\"Go ahead and dig in!\""



translate english a7161_f5daa9c3:


    xy "\"Nom nom... gllpp... Mmm...\""



translate english a7161_0accd139:


    xy "\"......\""



translate english a7161_d314d85c:



    voice "voice/a71/6100130a01.opus"
    mx "\"Hmm?\""



translate english a7161_089d28c3:



    voice "voice/a71/6100140a01.opus"
    mx "\"Shinichi, what's wrong?\""



translate english a7161_1d289f79:



    voice "voice/a71/6100150a01.opus"
    mx "\"Does it... taste bad or something?\""



translate english a7161_415d7c49:


    xy "\"No, it's great. Really great! I just...\""



translate english a7161_f174f264:


    xy "\"I feel like I'm dreaming.\""



translate english a7161_fbf3a3b9:



    voice "voice/a71/6100160a01.opus"
    mx "\"...You won't wake up and change your mind, will you?\""



translate english a7161_d06065bd:



    voice "voice/a71/6100170a01.opus"
    mx "\"We'll be together for the rest of our lives, right?\""



translate english a7161_a56afd3a:



    voice "voice/a71/6100180a01.opus"
    mx "\"Forever and ever?\""



translate english a7161_d6815867:


    "Su expresión es mortalmente seria."



translate english a7161_264b9c2b:


    "Es como si de verdad se creyera la leyenda de la escuela..."



translate english a7161_6c4855c4:


    "...o fuera incapaz de distinguir entre la ficción y la realidad."



translate english a7161_0eb1e0f0:


    "Pero haré todo lo que esté en mi poder para ayudarla a sentirse segura."



translate english a7161_44a12b30:



    voice "voice/a71/6100190a01.opus"
    mx "\"Kiss me...\""



translate english a7161_844b512f:


    "Me susurra al oído."



translate english a7161_7e9dfaf5:



    voice "voice/a71/6100200a01.opus"
    mx "\"Your kiss always calms me down...\""



translate english a7161_51589a8e:



    voice "voice/a71/6100210a01.opus"
    mx "\"Make me forget all my worries, okay...?\""



translate english a7161_1c988645:


    "Como un imán, mis labios son atraídos hacia los suyos."



translate english a7161_433131f4:


    "Nunca supe que un beso de cumpleaños pudiera saber tan dulce."




translate english a7161_c909e306:



    voice "voice/a71/6100010a01.opus"
    mx "\"Happy Birthday·To·You\""


translate english a7161_8e5ea8d5:



    voice "voice/a71/6100020a01.opus"
    mx "\"Happy Birthday·To·You\""


translate english a7161_15dbd921:



    voice "voice/a71/6100030a01.opus"
    mx "\"Happy Birthday·To·You\""


translate english a7161_fbaf8930:



    voice "voice/a71/6100040a01.opus"
    mx "\"Happy Birthday·To·You\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
