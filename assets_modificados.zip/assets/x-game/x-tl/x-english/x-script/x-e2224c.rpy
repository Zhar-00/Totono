

translate english e2224c_e64e3382:



    voice "voice/e22/24c00010a01.opus"
    mx "\"The events of the past no longer have any bearing here.\""


translate english e2224c_3bccf8aa:



    voice "voice/e22/24c00020a01.opus"
    mx "\"You are in a new world now.\""


translate english e2224c_fb5eb58b:



    voice "voice/e22/24c00030a01.opus"
    mx "\"I want us to start over and express our love for each other like it's our first time.\""


translate english e2224c_17e8bf5d:



    voice "voice/e22/24c00040a01.opus"
    mx "\"Please... Just follow your heart.\""


translate english e2224c_6a216243:


    "Supongo que tendré que hacer lo que pide..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
