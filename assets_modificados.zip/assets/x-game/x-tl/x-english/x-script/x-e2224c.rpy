

translate english e2224c_e64e3382:



    voice "voice/e22/24c00010a01.opus"
    mx "\"Los eventos del pasado ya no tienen ninguna relevancia aquí.\""


translate english e2224c_3bccf8aa:



    voice "voice/e22/24c00020a01.opus"
    mx "\"Ahora estás en un mundo nuevo.\""


translate english e2224c_fb5eb58b:



    voice "voice/e22/24c00030a01.opus"
    mx "\"Quiero que empecemos de nuevo y nos expresemos nuestro amor como si fuera nuestra primera vez.\""


translate english e2224c_17e8bf5d:



    voice "voice/e22/24c00040a01.opus"
    mx "\"Por favor... Solo sigue a tu corazón.\""


translate english e2224c_6a216243:


    "Supongo que tendré que hacer lo que pide..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
