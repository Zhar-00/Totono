

translate english a1211_07aed14f:


    "Esa noche, después de que se pone el sol, salgo de casa."


translate english a1211_1595173c:


    "El viento me alborota el cabello mientras camino junto al río."


translate english a1211_30a35480:


    "Finalmente, llego a una vieja y destartalada jaula de bateo cubierta."


translate english a1211_09e584a6:


    "Puedo oír el agudo chasquido de un bate resonando desde dentro."


translate english a1211_c26467e0:


    "El sonido es poco frecuente, en el mejor de los casos."


translate english a1211_142937e1:


    "Como era de esperar, solo hay un cliente dentro."


translate english a1211_80ecc12c:


    "Su forma es tan hermosa que cautiva a cualquiera que la vea."


translate english a1211_f8e9b06f:


    "...Suponiendo que no se distraigan con el ondear de su falda."


translate english a1211_1a892aa7:


    xy "\"Al menos quítate el uniforme primero.\""


translate english a1211_050a98e2:



    voice "voice/a12/1100010a01.opus"
    mx "\"Estoy practicando para el ensayo.\""


translate english a1211_4553826f:


    xy "\"¿Qué?\""


translate english a1211_2d7152da:



    voice "voice/a12/1100020a01.opus"
    mx "\"Se supone que debo jugar softbol con uniforme escolar.\""


translate english a1211_0accd139:


    xy "\"\"\"\"\"......\"\"\"\"\""


translate english a1211_b9f93b60:


    "Eeeh... ¿Qué tipo de jugada se supone que es esta, de nuevo?"



translate english a1211_59f2eb43:


    "Haría una réplica, pero la estética de su swing me deja sin palabras."


translate english a1211_24394925:


    "Es simplemente... hechizante."


translate english a1211_f7834575:



    voice "voice/a12/1100030a01.opus"
    mx "\"Uf...\""


translate english a1211_f47ba312:



    voice "voice/a12/1100040a01.opus"
    mx "\"¿Quieres tu turno?\""


translate english a1211_25a4d5f3:


    xy "\"Paso.\""


translate english a1211_af5d6ab4:



    voice "voice/a12/1100050a01.opus"
    mx "\"Antes te encantaba, ¿sabes?\""


translate english a1211_0c2dfa56:


    xy "\"Sí, hace como un millón de años.\""


translate english a1211_bbf4fd97:



    voice "voice/a12/1100060a01.opus"
    mx "\"Apenas.\""


translate english a1211_4bf7028d:


    xy "\"Como sea. No estoy aquí para jugar. Necesito hablar contigo.\""


translate english a1211_f82eed0a:



    voice "voice/a12/1100070a01.opus"
    mx "\"Sobre Mukou-san, ¿verdad?\""


translate english a1211_30c6a723:


    xy "\"¡¿C-Cómo lo supiste?!\""


translate english a1211_b4b4aa9c:



    voice "voice/a12/1100080a01.opus"
    mx "\"Está escrito en toda tu cara.\""


translate english a1211_8112eb5f:



    voice "voice/a12/1100090a01.opus"
    mx "\"Vas a decirme que haga amigos con ella.\""


translate english a1211_038215fe:


    "Como siempre, ella me cala al instante."


translate english a1211_667726df:


    "Bueno. No tiene sentido andarse con rodeos ahora."


translate english a1211_ae47b4ce:


    "Debería ser honesto con ella sobre lo que siento."


translate english a1211_5f788ac7:


    xy "\"Por favor, Miyuki...\""


translate english a1211_246d4794:


    xy "\"¡Aoi necesita una amiga...! ¡Por favor, pasa algo de tiempo con ella!\""


translate english a1211_d404e637:



    voice "voice/a12/1100100a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a1211_0dd70768:



    voice "voice/a12/1100110a01.opus"
    mx "\"¿Desde cuándo empezaste a llamarla Aoi?\""


translate english a1211_5df9a8f3:


    xy "\"¿Eh? Oh, eh... bueno...\""


translate english a1211_1cbdb10a:



    voice "voice/a12/1100120a01.opus"
    mx "\"Me temo que tengo que declinar. Es imposible que sea su amiga.\""


translate english a1211_30556e76:


    xy "\"...¿Sigues molesta por lo del chantaje?\""


translate english a1211_3d7f7c47:



    voice "voice/a12/1100130a01.opus"
    mx "\"No.\""


translate english a1211_e1f71f4d:


    xy "\"Ella ha estado hablando contigo mucho desde entonces, ¿verdad?\""


translate english a1211_4bd4e2d9:



    voice "voice/a12/1100140a01.opus"
    mx "\"Es extremadamente molesto.\""


translate english a1211_47db5c66:


    xy "\"Pero está haciendo un esfuerzo.\""


translate english a1211_1da98256:



    voice "voice/a12/1100150a01.opus"
    mx "\"Sí, pero no se detiene a pensar en cómo me hace sentir A MÍ.\""


translate english a1211_05377168:


    xy "\"Quizás si fueras su amiga, podrías enseñarle—\""


translate english a1211_535aba25:



    voice "voice/a12/1100160a01.opus"
    mx "\"¡Solo PARA!\""


translate english a1211_f90d3e28:


    "Su voz resuena por todo el edificio."


translate english a1211_14bcbe5b:



    voice "voice/a12/1100170a01.opus"
    mx "\"¿Crees que es fácil ser yo?\""


translate english a1211_5f2933bd:



    voice "voice/a12/1100180a01.opus"
    mx "\"Lo que pasa con ser popular es que a la gente le encanta hablar. ¿Sabes cuánta gente me odia?\""


translate english a1211_dab0c919:



    voice "voice/a12/1100181a01.opus"
    mx "\"Nunca he sido una mariposa social. Tengo que esforzarme DURAMENTE para encajar en la escuela. ¡Seguramente tú de entre todos deberías entenderlo!\""


translate english a1211_aa467680:


    "Recuerdo cuando éramos más jóvenes..."


translate english a1211_60618b87:


    "En aquel entonces, sus talentos naturales la alejaban de todos los demás."


translate english a1211_2c4e6017:


    "Desentonaba por completo."


translate english a1211_3166b01d:


    "Así que sí, no se convirtió en reina por casualidad."


translate english a1211_e743e0c7:



    voice "voice/a12/1100190a01.opus"
    mx "\"Pero luego está Mukou-san, afirmando que el mundo es solo un juego. ¡Pasándola de lo mejor en su pequeña fantasía escapista!\""


translate english a1211_f184e3a6:



    voice "voice/a12/1100200a01.opus"
    mx "\"¡La única razón por la que no puede hacer amigos es porque en realidad no QUIERE amigos!\""


translate english a1211_f17b0e76:


    xy "\"...Perdón.\""


translate english a1211_247059e2:


    xy "\"No debí sacar conclusiones precipitadas sobre ti.\""


translate english a1211_65a35859:


    "Miyuki respira hondo, como si intentara calmarse."


translate english a1211_9e558528:



    voice "voice/a12/1100210a01.opus"
    mx "\"Igual... perdón por gritarte así.\""


translate english a1211_0052fb05:


    xy "\"Nah, digo, fue mi culpa.\""


translate english a1211_c2a09a70:


    "No me había dado cuenta de por qué exactamente Miyuki le guardaba rencor a Aoi por confundir la realidad con los videojuegos."


translate english a1211_07a63521:


    "Pero Miyuki ha estado esforzándose mucho por cambiar."


translate english a1211_8846aa54:


    "Es infeliz, obligada a fingir frente a todos sus amigos."


translate english a1211_959788ac:


    "Así que es natural que le resulte irritante que Aoi eluda toda responsabilidad personal minimizando sus errores."


translate english a1211_6fabe121:


    xy "\"Es solo que... Lo que pasa es que...\""


translate english a1211_a9c3c1c2:


    "Reuniendo los últimos restos de mi valor, miro a Miyuki a los ojos."


translate english a1211_90003199:


    xy "\"Es exactamente por eso que creo que nos necesita cerca, ¿sabes?\""


translate english a1211_10731d38:


    xy "\"Va a arruinar su vida si sigue convencida de que puede barrer todos sus errores bajo la alfombra.\""


translate english a1211_abd187dc:


    xy "\"Pero quizás si estamos para ella, podemos lograr que empiece a tomarse la vida más en serio. Quizás solo necesita un pequeño empujón.\""


translate english a1211_2d23473f:


    xy "\"Por eso quiero ayudarla a dar el primer paso.\""


translate english a1211_a1eae6ab:



    voice "voice/a12/1100220a01.opus"
    mx "\"De verdad no has cambiado nada.\""


translate english a1211_cb53ed85:


    xy "\"¿Eh? ¿De dónde salió eso?\""


translate english a1211_a7f10bd4:



    voice "voice/a12/1100230a01.opus"
    mx "\"...Bien, me rindo.\""


translate english a1211_d0a7f073:


    "La expresión de Miyuki me dice que se ha resignado a su destino."


translate english a1211_26033f00:



    voice "voice/a12/1100240a01.opus"
    mx "\"Tienes un punto razonable. Así que... SUPONGO que te ayudaré.\""


translate english a1211_00420486:


    xy "\"¿En serio? ¡Genial! ¡Gracias!\""


translate english a1211_8f8905d6:



    voice "voice/a12/1100250a01.opus"
    mx "\"Pero déjame decir esto.\""


translate english a1211_666e9cd4:


    "Por una fracción de segundo, Miyuki aparta la mirada."


translate english a1211_0530c0fb:



    voice "voice/a12/1100260a01.opus"
    mx "\"Tiene un motivo oculto.\""


translate english a1211_73cb02e4:


    "Sí... Aoi no solo quiere hacerse nuestra amiga."


translate english a1211_da5bfafd:


    "Su verdadero objetivo es descaradamente obvio: ser la tercera rueda que una a Miyuki y a mí."


translate english a1211_7d8e29f2:


    "En lo personal, no quiero dejarme acercar más a Miyuki."


translate english a1211_06ec06a8:


    "Ambos solo saldremos heridos. Lo sé."


translate english a1211_39e7c143:


    "Pero..."


translate english a1211_aec592cb:


    xy "\"Lo único que quiero es que pruebe lo que es tener amigos de verdad por una vez.\""


translate english a1211_5bfac712:



    voice "voice/a12/1100270a01.opus"
    mx "\"Y todo esto es por SU bien, ¿eh?\""


translate english a1211_1acf3fb6:


    "Por alguna razón, Miyuki parece un poco triste."


translate english a1211_d7e269a5:


    "...Probablemente solo me lo estoy imaginando."


translate english a1211_70285268:



    voice "voice/a12/1100280a01.opus"
    mx "\"...Daré lo mejor de mí.\""


translate english a1211_7d0734c8:


    xy "\"¡Lo agradezco mucho!\""


translate english a1211_cfe2ecb3:



    voice "voice/a12/1100290a01.opus"
    mx "\"A cambio— ¿tú también me ayudarás con algo?\""


translate english a1211_ad31adb3:


    "Miyuki toma el bate de béisbol apoyado contra la pared."


translate english a1211_3dfb4c36:



    voice "voice/a12/1100300a01.opus"
    mx "\"Estas habilidades de béisbol me dieron el papel principal en la próxima actuación...\""


translate english a1211_95938a14:



    voice "voice/a12/1100310a01.opus"
    mx "\"Y van a venir exalumnos a verla y todo... Esta podría ser mi gran oportunidad.\""


translate english a1211_c0cdd81f:


    xy "\"Wow...\""


translate english a1211_08d7b28a:



    voice "voice/a12/1100320a01.opus"
    mx "\"¿No te alegras aunque sea un poco por mí?\""


translate english a1211_0df884ca:


    xy "\"¡Sí! Cruzo los dedos para que todo salga bien.\""


translate english a1211_2ab6a3aa:


    "Después de todo, cuanto más distancia entre nosotros, mejor."


translate english a1211_9eb67fe9:


    "Pongo lo que espero sea una sonrisa convincente."


translate english a1211_0112703c:



    voice "voice/a12/1100330a01.opus"
    mx "\"Dicho esto, no puedo darme el lujo de hacer el ridículo en ese escenario.\""


translate english a1211_052e4dbe:


    xy "\"Sin duda.\""


translate english a1211_924b94af:



    voice "voice/a12/1100340a01.opus"
    mx "\"No puedo darme el lujo de avergonzarme.\""


translate english a1211_cbe26355:


    xy "\"Ajá.\""


translate english a1211_29aab36b:



    voice "voice/a12/1100350a01.opus"
    mx "\"No puedo darme el lujo de deshonrarme.\""


translate english a1211_a93ade40:


    xy "\"Ok, ya... ya entendí esa parte.\""


translate english a1211_aee15c09:


    xy "\"¿Y?\""


translate english a1211_97d91071:



    voice "voice/a12/1100360a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a1211_dc7b36fd:



    voice "voice/a12/1100370a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a1211_0a554518:



    voice "voice/a12/1100380a01.opus"
    mx "\"¿Hola...? ¿Hay alguien ahí...?\""



translate english a1211_d64af453:



    voice "voice/a12/1100390a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a1211_7ae1f79b:



    voice "voice/a12/1100400a01.opus"
    mx "\"...D-Da igual.\""


translate english a1211_57a94f60:


    xy "\"Espera, ¿qué?\""


translate english a1211_985265aa:



    voice "voice/a12/1100410a01.opus"
    mx "\"Cambié de opinión.\""


translate english a1211_bab031a2:


    xy "\"¿Sobre qué?\""


translate english a1211_b46c4fbe:



    voice "voice/a12/1100420a01.opus"
    mx "\"Debería resolverlo por mi cuenta.\""


translate english a1211_2847fad1:


    xy "\"¿Después de todo eso? ¿En serio vas a dejarme plantado?\""


translate english a1211_ba468ebc:



    voice "voice/a12/1100430a01.opus"
    mx "\"Aguántate.\""


translate english a1211_851b3bd3:


    xy "\"De verdad disfrutas hacerme perder el tiempo, ¿eh?\""


translate english a1211_873bcf0a:



    voice "voice/a12/1100440a01.opus"
    mx "\"Bueno, es que...\""


translate english a1211_2ec6b0f8:



    voice "voice/a12/1100450a01.opus"
    mx "\"Es mi problema y lo manejaré.\""


translate english a1211_d4482df0:


    "...Ahí va otra vez."


translate english a1211_01ac0b8e:


    "Justo cuando por fin tengo la oportunidad de hablar con ella a solas, sus malos hábitos empiezan a salir a la luz."


translate english a1211_b3e12473:


    xy "\"¿Seguro que lo tienes todo bajo control?\""


translate english a1211_f1b2ba01:



    voice "voice/a12/1100460a01.opus"
    mx "\"Segurísimo.\""


translate english a1211_bfe57f43:


    "Miyuki me lanza una mirada decidida, y suelto un suspiro."


translate english a1211_b1c8b895:


    xy "\"Bien, bueno... Sé que ya no eres una niña pequeña, pero...\""


translate english a1211_cc888123:


    xy "\"Tiendes a llenar el plato demasiado, si sabes a qué me refiero.\""


translate english a1211_d2f7683d:



    voice "voice/a12/1100470a01.opus"
    mx "\"¿Qué...?\""


translate english a1211_6e348d4d:


    xy "\"También te esfuerzas demasiado en tu pequeña actuación del salón.\""


translate english a1211_c88154af:


    xy "\"Es como si tuvieras doble personalidad. A veces siento que te estás matando por eso.\""


translate english a1211_ea5a1ce9:



    voice "voice/a12/1100480a01.opus"
    mx "\"¡No es cierto!\""


translate english a1211_035a01dd:


    xy "\"Sí lo es.\""


translate english a1211_847904d1:



    voice "voice/a12/1100490a01.opus"
    mx "\"¡No es cierto!\""


translate english a1211_fa828ad6:


    xy "\"¡Sí lo es!\""


translate english a1211_e8543d11:



    voice "voice/a12/1100500a01.opus"
    mx "\"¡NO!\""


translate english a1211_619e8d8a:


    xy "\"¡SÍ!\""


translate english a1211_dda7003b:



    voice "voice/a12/1100510a01.opus"
    mx "\"¿Qh...? ¡Pffft!\""


translate english a1211_3a2a4084:


    "La tensión se rompe, y Miyuki se ríe."


translate english a1211_5b144b79:



    voice "voice/a12/1100520a01.opus"
    mx "\"Dios... Se siente justo como en los viejos tiempos.\""


translate english a1211_32817e20:


    xy "\"¿E-En serio?\""


translate english a1211_4c017c9a:


    "Al final del día, no puedo borrar nuestra historia juntos."


translate english a1211_6b248124:


    xy "\"Bueno... Si alguna vez me necesitas, sabes dónde encontrarme. Con gusto te ayudo. Tampoco es como que tenga otra cosa que hacer.\""


translate english a1211_1c380d5a:



    voice "voice/a12/1100540a01.opus"
    mx "\"Perdedor.\""


translate english a1211_a0ace320:


    xy "\"Cállate, nerd.\""


translate english a1211_d684591f:


    "Miyuki toma su bate y mete otra moneda en la máquina."


translate english a1211_cc0dc32e:



    voice "voice/a12/1100550a01.opus"
    mx "\"Gracias.\""


translate english a1211_5b5b6f04:


    "Mantiene la espalda vuelta hacia mí mientras habla. Luego se dirige al cajón de bateo."



translate english a1211_ff8ee72d:



    voice "voice/a12/1100560a01.opus"
    mx "\"Hay algo en ti que de verdad me hace—\""


translate english a1211_3bc3d02c:



    voice "voice/a12/1100570a01.opus"
    mx "\"—¡creer en ti!\""


translate english a1211_5801102d:


    "La pelota sale disparada hacia el cielo nocturno y desaparece de la vista."


translate english a1211_f2fda74a:


    "Y por el más breve de los instantes, se siente como si esa pelota pudiera rasgar el tejido del universo... hacia lo que sea que haya más allá."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
