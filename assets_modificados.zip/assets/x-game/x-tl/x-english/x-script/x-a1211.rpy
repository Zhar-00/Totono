

translate english a1211_07aed14f:


    "Esa noche, después de que se pone el sol, salgo de casa."


translate english a1211_1595173c:


    "El viento me alborota el cabello mientras camino junto al río."


translate english a1211_30a35480:


    "Finalmente, llego a una vieja y destartalada jaula de bateo cubierta."


translate english a1211_09e584a6:


    "Puedo oír el agudo chasquido de un bate resonando desde dentro."


translate english a1211_c26467e0:


    "El sonido es poco frecuente, en el mejor de los casos."


translate english a1211_142937e1:


    "Como era de esperar, solo hay un cliente dentro."


translate english a1211_80ecc12c:


    "Su forma es tan hermosa que cautiva a cualquiera que la vea."


translate english a1211_f8e9b06f:


    "...Suponiendo que no se distraigan con el ondear de su falda."


translate english a1211_1a892aa7:


    xy "\"At least change out of your uniform first.\""


translate english a1211_050a98e2:



    voice "voice/a12/1100010a01.opus"
    mx "\"I'm practicing for rehearsal.\""


translate english a1211_4553826f:


    xy "\"What?\""


translate english a1211_2d7152da:



    voice "voice/a12/1100020a01.opus"
    mx "\"I'm supposed to play softball in a school uniform.\""


translate english a1211_0accd139:


    xy "\"\"\"\"\"......\"\"\"\"\""


translate english a1211_b9f93b60:


    "Eeeh... ¿Qué tipo de jugada se supone que es esta, de nuevo?"



translate english a1211_59f2eb43:


    "Haría una réplica, pero la estética de su swing me deja sin palabras."


translate english a1211_24394925:


    "Es simplemente... hechizante."


translate english a1211_f7834575:



    voice "voice/a12/1100030a01.opus"
    mx "\"Whew...\""


translate english a1211_f47ba312:



    voice "voice/a12/1100040a01.opus"
    mx "\"Want a turn?\""


translate english a1211_25a4d5f3:


    xy "\"I'll pass.\""


translate english a1211_af5d6ab4:



    voice "voice/a12/1100050a01.opus"
    mx "\"You used to love it, you know.\""


translate english a1211_0c2dfa56:


    xy "\"Yeah, like, a million years ago.\""


translate english a1211_bbf4fd97:



    voice "voice/a12/1100060a01.opus"
    mx "\"Hardly.\""


translate english a1211_4bf7028d:


    xy "\"Whatever. I'm not here to play. I need to talk to you.\""


translate english a1211_f82eed0a:



    voice "voice/a12/1100070a01.opus"
    mx "\"About Mukou-san, right?\""


translate english a1211_30c6a723:


    xy "\"H-How did you know?!\""


translate english a1211_b4b4aa9c:



    voice "voice/a12/1100080a01.opus"
    mx "\"It's written all over your face.\""


translate english a1211_8112eb5f:



    voice "voice/a12/1100090a01.opus"
    mx "\"You're going to tell me to make friends with her.\""


translate english a1211_038215fe:


    "Como siempre, ella me cala al instante."


translate english a1211_667726df:


    "Bueno. No tiene sentido andarse con rodeos ahora."


translate english a1211_ae47b4ce:


    "Debería ser honesto con ella sobre lo que siento."


translate english a1211_5f788ac7:


    xy "\"Please, Miyuki...\""


translate english a1211_246d4794:


    xy "\"Aoi needs a friend... Please just spend some time with her!\""


translate english a1211_d404e637:



    voice "voice/a12/1100100a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a1211_0dd70768:



    voice "voice/a12/1100110a01.opus"
    mx "\"Since when did you start calling her Aoi?\""


translate english a1211_5df9a8f3:


    xy "\"Huh? Oh, uh... well...\""


translate english a1211_1cbdb10a:



    voice "voice/a12/1100120a01.opus"
    mx "\"I'm afraid I have to decline. I can't possibly be friends with her.\""


translate english a1211_30556e76:


    xy "\"...Are you still upset about the blackmail thing?\""


translate english a1211_3d7f7c47:



    voice "voice/a12/1100130a01.opus"
    mx "\"No.\""


translate english a1211_e1f71f4d:


    xy "\"She's been talking to you a lot since then, right?\""


translate english a1211_4bd4e2d9:



    voice "voice/a12/1100140a01.opus"
    mx "\"It's extremely annoying.\""


translate english a1211_47db5c66:


    xy "\"But she's making an effort.\""


translate english a1211_1da98256:



    voice "voice/a12/1100150a01.opus"
    mx "\"Yeah, but she doesn't stop to think about how it makes ME feel.\""


translate english a1211_05377168:


    xy "\"Maybe if you were her friend, you could teach her—\""


translate english a1211_535aba25:



    voice "voice/a12/1100160a01.opus"
    mx "\"Just STOP!\""


translate english a1211_f90d3e28:


    "Su voz resuena por todo el edificio."


translate english a1211_14bcbe5b:



    voice "voice/a12/1100170a01.opus"
    mx "\"Do you think it's easy being me?\""


translate english a1211_5f2933bd:



    voice "voice/a12/1100180a01.opus"
    mx "\"The thing about being popular is that people love to talk. Do you know how many people hate my guts?\""


translate english a1211_dab0c919:



    voice "voice/a12/1100181a01.opus"
    mx "\"I've never been a social butterfly. I have to work HARD to fit in at school. Surely you of all people understand that!\""


translate english a1211_aa467680:


    "Recuerdo cuando éramos más jóvenes..."


translate english a1211_60618b87:


    "En aquel entonces, sus talentos naturales la alejaban de todos los demás."


translate english a1211_2c4e6017:


    "Desentonaba por completo."


translate english a1211_3166b01d:


    "Así que sí, no se convirtió en reina por casualidad."


translate english a1211_e743e0c7:



    voice "voice/a12/1100190a01.opus"
    mx "\"But then there's Mukou-san, claiming the world's just a game. Having the time of her life in her little escapist fantasy!\""


translate english a1211_f184e3a6:



    voice "voice/a12/1100200a01.opus"
    mx "\"The only reason she can't make friends is because she doesn't actually WANT friends.\""


translate english a1211_f17b0e76:


    xy "\"...I'm sorry.\""


translate english a1211_247059e2:


    xy "\"I shouldn't have jumped to conclusions about you.\""


translate english a1211_65a35859:


    "Miyuki respira hondo, como si intentara calmarse."


translate english a1211_9e558528:



    voice "voice/a12/1100210a01.opus"
    mx "\"Likewise... I'm sorry for shouting at you like that.\""


translate english a1211_0052fb05:


    xy "\"Nah, I mean, it was my fault.\""


translate english a1211_c2a09a70:


    "No me había dado cuenta de por qué exactamente Miyuki le guardaba rencor a Aoi por confundir la realidad con los videojuegos."


translate english a1211_07a63521:


    "Pero Miyuki ha estado esforzándose mucho por cambiar."


translate english a1211_8846aa54:


    "Es infeliz, obligada a fingir frente a todos sus amigos."


translate english a1211_959788ac:


    "Así que es natural que le resulte irritante que Aoi eluda toda responsabilidad personal minimizando sus errores."


translate english a1211_6fabe121:


    xy "\"It's just... The thing is...\""


translate english a1211_a9c3c1c2:


    "Reuniendo los últimos restos de mi valor, miro a Miyuki a los ojos."


translate english a1211_90003199:


    xy "\"That's exactly why I think she needs us around, you know?\""


translate english a1211_10731d38:


    xy "\"She's gonna mess her life up if she stays convinced that she can just sweep all her mistakes under the rug.\""


translate english a1211_abd187dc:


    xy "\"But maybe if we're there for her, we can get her to start taking life more seriously. Maybe she just needs a little push.\""


translate english a1211_2d23473f:


    xy "\"That's why I want to help her take the first step.\""


translate english a1211_a1eae6ab:



    voice "voice/a12/1100220a01.opus"
    mx "\"You really haven't changed a bit.\""


translate english a1211_cb53ed85:


    xy "\"Huh? Where did that come from?\""


translate english a1211_a7f10bd4:



    voice "voice/a12/1100230a01.opus"
    mx "\"...Fine, I give up.\""


translate english a1211_d0a7f073:


    "La expresión de Miyuki me dice que se ha resignado a su destino."


translate english a1211_26033f00:



    voice "voice/a12/1100240a01.opus"
    mx "\"You have a reasonable point. So... I GUESS I'll help you out.\""


translate english a1211_00420486:


    xy "\"Really? Awesome! Thank you!\""


translate english a1211_8f8905d6:



    voice "voice/a12/1100250a01.opus"
    mx "\"But let me say this.\""


translate english a1211_666e9cd4:


    "Por una fracción de segundo, Miyuki aparta la mirada."


translate english a1211_0530c0fb:



    voice "voice/a12/1100260a01.opus"
    mx "\"She's got an ulterior motive.\""


translate english a1211_73cb02e4:


    "Sí... Aoi no solo quiere hacerse nuestra amiga."


translate english a1211_da5bfafd:


    "Su verdadero objetivo es descaradamente obvio: ser la tercera rueda que una a Miyuki y a mí."


translate english a1211_7d8e29f2:


    "En lo personal, no quiero dejarme acercar más a Miyuki."


translate english a1211_06ec06a8:


    "Ambos solo saldremos heridos. Lo sé."


translate english a1211_39e7c143:


    "Pero..."


translate english a1211_aec592cb:


    xy "\"All I want is for her to have a taste of what it's like to have real friends for once.\""


translate english a1211_5bfac712:



    voice "voice/a12/1100270a01.opus"
    mx "\"And this is all for HER sake, is it?\""


translate english a1211_1acf3fb6:


    "Por alguna razón, Miyuki parece un poco triste."


translate english a1211_d7e269a5:


    "...Probablemente solo me lo estoy imaginando."


translate english a1211_70285268:



    voice "voice/a12/1100280a01.opus"
    mx "\"...I'll give it my best shot.\""


translate english a1211_7d0734c8:


    xy "\"I really appreciate it!\""


translate english a1211_cfe2ecb3:



    voice "voice/a12/1100290a01.opus"
    mx "\"In exchange—will you help me with something, too?\""


translate english a1211_ad31adb3:


    "Miyuki toma el bate de béisbol apoyado contra la pared."


translate english a1211_3dfb4c36:



    voice "voice/a12/1100300a01.opus"
    mx "\"These baseball skills landed me the leading role in the upcoming performance...\""


translate english a1211_95938a14:



    voice "voice/a12/1100310a01.opus"
    mx "\"And there's going to be former graduates coming to see it and everything... This might be my big break.\""


translate english a1211_c0cdd81f:


    xy "\"Wow...\""


translate english a1211_08d7b28a:



    voice "voice/a12/1100320a01.opus"
    mx "\"Aren't you even a little happy for me?\""


translate english a1211_0df884ca:


    xy "\"I am! Fingers crossed that everything works out.\""


translate english a1211_2ab6a3aa:


    "Después de todo, cuanto más distancia entre nosotros, mejor."


translate english a1211_9eb67fe9:


    "Pongo lo que espero sea una sonrisa convincente."


translate english a1211_0112703c:



    voice "voice/a12/1100330a01.opus"
    mx "\"That said, I absolutely CANNOT afford to make a fool of myself up there on stage.\""


translate english a1211_052e4dbe:


    xy "\"For sure.\""


translate english a1211_924b94af:



    voice "voice/a12/1100340a01.opus"
    mx "\"I can't afford to embarrass myself.\""


translate english a1211_cbe26355:


    xy "\"Mmhmm.\""


translate english a1211_29aab36b:



    voice "voice/a12/1100350a01.opus"
    mx "\"I can't afford to disgrace myself.\""


translate english a1211_a93ade40:


    xy "\"Okay, I... I get that part.\""


translate english a1211_aee15c09:


    xy "\"And?\""


translate english a1211_97d91071:



    voice "voice/a12/1100360a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a1211_dc7b36fd:



    voice "voice/a12/1100370a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a1211_0a554518:



    voice "voice/a12/1100380a01.opus"
    mx "\"Hello...? Anybody in there...?\""



translate english a1211_d64af453:



    voice "voice/a12/1100390a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a1211_7ae1f79b:



    voice "voice/a12/1100400a01.opus"
    mx "\"...N-Never mind.\""


translate english a1211_57a94f60:


    xy "\"Wait, what?\""


translate english a1211_985265aa:



    voice "voice/a12/1100410a01.opus"
    mx "\"I changed my mind.\""


translate english a1211_bab031a2:


    xy "\"About?\""


translate english a1211_b46c4fbe:



    voice "voice/a12/1100420a01.opus"
    mx "\"I should just figure something out on my own.\""


translate english a1211_2847fad1:


    xy "\"After all that? Are you seriously gonna leave me hanging?\""


translate english a1211_ba468ebc:



    voice "voice/a12/1100430a01.opus"
    mx "\"Deal with it.\""


translate english a1211_851b3bd3:


    xy "\"You really enjoy dicking me around, don't you?\""


translate english a1211_873bcf0a:



    voice "voice/a12/1100440a01.opus"
    mx "\"Well, it's just...\""


translate english a1211_2ec6b0f8:



    voice "voice/a12/1100450a01.opus"
    mx "\"It's my problem to handle.\""


translate english a1211_d4482df0:


    "...Ahí va otra vez."


translate english a1211_01ac0b8e:


    "Justo cuando por fin tengo la oportunidad de hablar con ella a solas, sus malos hábitos empiezan a salir a la luz."


translate english a1211_b3e12473:


    xy "\"You sure you got it all under control?\""


translate english a1211_f1b2ba01:



    voice "voice/a12/1100460a01.opus"
    mx "\"Positive.\""


translate english a1211_bfe57f43:


    "Miyuki me lanza una mirada decidida, y suelto un suspiro."


translate english a1211_b1c8b895:


    xy "\"Right, well... I know you're not a little kid anymore, but...\""


translate english a1211_cc888123:


    xy "\"You tend to pile your plate a little too high, if you know what I mean.\""


translate english a1211_d2f7683d:



    voice "voice/a12/1100470a01.opus"
    mx "\"What...?\""


translate english a1211_6e348d4d:


    xy "\"You put too much effort into your little classroom act, too.\""


translate english a1211_c88154af:


    xy "\"It's like you have a split personality. Sometimes I get the sense you're killing yourself over it.\""


translate english a1211_ea5a1ce9:



    voice "voice/a12/1100480a01.opus"
    mx "\"No I'm not!\""


translate english a1211_035a01dd:


    xy "\"Yes, you are.\""


translate english a1211_847904d1:



    voice "voice/a12/1100490a01.opus"
    mx "\"Not true!\""


translate english a1211_fa828ad6:


    xy "\"Is so!\""


translate english a1211_e8543d11:



    voice "voice/a12/1100500a01.opus"
    mx "\"NUH-UH!\""


translate english a1211_619e8d8a:


    xy "\"YEAH-HUH!\""


translate english a1211_dda7003b:



    voice "voice/a12/1100510a01.opus"
    mx "\"Wha... Pffft!\""


translate english a1211_3a2a4084:


    "La tensión se rompe, y Miyuki se ríe."


translate english a1211_5b144b79:



    voice "voice/a12/1100520a01.opus"
    mx "\"God... Feels just like old times.\""


translate english a1211_32817e20:


    xy "\"D-Does it?\""


translate english a1211_4c017c9a:


    "Al final del día, no puedo borrar nuestra historia juntos."


translate english a1211_6b248124:


    xy "\"Well... If you ever need me, you know where to find me. I'm happy to help. Not like I've got anything else going on.\""


translate english a1211_1c380d5a:



    voice "voice/a12/1100540a01.opus"
    mx "\"Loser.\""


translate english a1211_a0ace320:


    xy "\"Shut up, tryhard.\""


translate english a1211_d684591f:


    "Miyuki toma su bate y mete otra moneda en la máquina."


translate english a1211_cc0dc32e:



    voice "voice/a12/1100550a01.opus"
    mx "\"Thanks.\""


translate english a1211_5b5b6f04:


    "Mantiene la espalda vuelta hacia mí mientras habla. Luego se dirige al cajón de bateo."



translate english a1211_ff8ee72d:



    voice "voice/a12/1100560a01.opus"
    mx "\"There's just something about you that really makes me—\""


translate english a1211_3bc3d02c:



    voice "voice/a12/1100570a01.opus"
    mx "\"—believe in you!\""


translate english a1211_5801102d:


    "La pelota sale disparada hacia el cielo nocturno y desaparece de la vista."


translate english a1211_f2fda74a:


    "Y por el más breve de los instantes, se siente como si esa pelota pudiera rasgar el tejido del universo... hacia lo que sea que haya más allá."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
