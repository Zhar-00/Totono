

translate english a3162_22794746:



    voice "voice/a31/6200010a01.opus"
    mx "\"Shinichi! Don't you dare zone out on me right now!\""


translate english a3162_6218a458:



    voice "voice/a31/6200020a01.opus"
    mx "\"You call yourself Aoi's friend?! Don't you think you ought to be there for her?\""


translate english a3162_0f8ce698:


    xy "\"Oh... Right...\""


translate english a3162_90447f13:


    "Miyuki me devuelve a la realidad."


translate english a3162_e361ccb7:


    "Aoi, la autoproclamada \"transceiver.\""


translate english a3162_92c11ae8:


    "Aoi, la chica con una sola entrada en su agenda."


translate english a3162_0eed0957:


    "Nosotros dos somos sus únicos amigos..."


translate english a3162_d5964e4f:


    "Y ahora mismo, somos los únicos que pueden ayudarla."


translate english a3162_00b0ecf9:


    xy "\"Miyuki?\""


translate english a3162_c3f49af9:



    voice "voice/a31/6200030a01.opus"
    mx "\"Yeah?\""


translate english a3162_0270d326:


    xy "\"Thank you for helping me look for her.\""


translate english a3162_b0299ed7:



    voice "voice/a31/6200031a01.opus"
    mx "\"O-Of course I'd help!\""


translate english a3162_9395b678:


    "De alguna forma puedo imaginarme su expresión exacta."


translate english a3162_e01fb034:


    "La conozco, y sé que le gusta ser amiga de Aoi."


translate english a3162_f5887d8d:


    "She would never actually end the friendship. She only threatened to \"cut ties\"por lo mucho que le importa."


translate english a3162_f23e2206:


    "De lo contrario, no estaría aquí afuera en la oscuridad, bajo la lluvia torrencial, intentando ver cómo está."


translate english a3162_be066262:



    voice "voice/a31/6200032a01.opus"
    mx "\"Whatever. We need to find her.\""


translate english a3162_c9507e22:


    "Escarbo en mis recuerdos."


translate english a3162_50126789:


    "Todos los días que pasamos con Aoi..."


translate english a3162_d81ec830:


    "Sé que nuestra amistad era genuina."


translate english a3162_e4f6e358:


    "Tiene que haber una pista aquí en algún lado..."


translate english a3162_ea6f5bfa:


    "¡Tiene que haberla...!"


translate english a3162_858eca91:


    xy "\"The visual novel!\""


translate english a3162_11db615a:



    voice "voice/a31/6200033a01.opus"
    mx "\"Wait, what? What did you just—\""


translate english a3162_13be17bc:


    xy "\"I gotta swing back by my place real fast. I think I have an idea.\""


translate english a3162_3179ef45:



    voice "voice/a31/6200040a01.opus"
    mx "\"Yeah? Is it a good one, at least?\""


translate english a3162_695cfa1d:


    xy "\"No clue, but it's gotta be better than searching at random.\""


translate english a3162_6fdbef9c:



    voice "voice/a31/6200050a01.opus"
    mx "\"Alright then. I'll meet you there.\""


translate english a3162_169c207d:


    "Cuelgo y me apresuro a casa."


translate english a3162_f982cf97:


    "Ese juego para móvil que me prestó Yuutarou... tiene una escena de gato callejero casi idéntica."


translate english a3162_23338ddb:


    "Si está actuando escenas de él, entonces quizá necesite jugar más para ver a dónde va después."


translate english a3162_2e057305:


    "En cuanto mi casa aparece a la vista, me descubro corriendo por el sendero y entrando por la puerta principal."


translate english a3162_da19a725:


    "Luego subo corriendo las escaleras a mi cuarto y agarro el teléfono prestado que había dejado cargando en mi cama."



translate english a3162_09ccb084:



    voice "voice/a31/6200060a02.opus"
    aoi "\"Meow! I'm the mommy cat.\""


translate english a3162_6cc3b3c8:


    "Necesito llegar a la siguiente escena lo antes posible... Impaciente, pulso el botón de Saltar."


translate english a3162_998dbac6:


    "El texto pasa a toda velocidad."


translate english a3162_2203e0ae:


    "...Espera..."


translate english a3162_62386a76:


    "Right now I'm skipping through the \"past\" to line up with the real-world \"present day,\"del mundo real, pero... ¿y si leo más adelante?"


translate english a3162_429b2517:


    "Es decir... este es uno de esos juegos tipo simulador de citas, ¿no?"


translate english a3162_31c3a876:


    "Lo que significa que el protagonista probablemente terminará con la heroína al final..."


translate english a3162_948462d5:


    "Entonces... ¿eso significa que Aoi intentará actuar esa parte en la vida real también...?"


translate english a3162_9aea408a:


    xy "\"Whoa!\""


translate english a3162_f2c4e14e:


    "Un efecto de sonido repentino me toma por sorpresa."


translate english a3162_042bee82:


    "Mi mano resbala y deselecciono el botón de Saltar por accidente."


translate english a3162_b8f1cf20:


    xy "\"Wait... Is this—?\""


translate english a3162_bd2749e5:


    xy "\"Coming!\""


translate english a3162_a05748a4:



    voice "voice/a31/6200070a01.opus"
    mx "\"Shinichi! Do you know where she went?!\""


translate english a3162_7ee78672:


    "Miyuki pregunta entre jadeos... y yo asiento."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
