

translate english a2161_7a8d5f28:


    xy "\"Perdón por interrumpir...\""


translate english a2161_1baa930e:


    "Asomo la cabeza por la puerta."


translate english a2161_9beb9616:


    "El gimnasio está vacío."


translate english a2161_aaaa152f:


    "¿El ensayo ya terminó?"


translate english a2161_32f1aded:


    "El único sonido es el tenue zumbido de la iluminación del escenario."


translate english a2161_a0552b69:


    xy "\"Ehh... ¿Miyuki?\""


translate english a2161_52a3de6f:



    voice "voice/a21/6100010a02.opus"
    aoi "\"Puedo sentir la chispa... Miyuki está por allá.\""


translate english a2161_0193f5c4:


    xy "\"¡¿Qué demonios?! ¡¿Aoi, qué estás haciendo?!\""


translate english a2161_18ee9443:



    voice "voice/a21/6100020a02.opus"
    aoi "\"Bip bip... Shinichi, ¿no vienes tú también?\""


translate english a2161_0c7301f1:


    xy "\"¡E-Es cierto! ¡Claro!\""


translate english a2161_b27f42df:


    "Su expresión sigue tan vacía como siempre, pero parece inusualmente animada..."


translate english a2161_f6d37293:


    "Me apresuro tras ella hacia la zona de backstage."


translate english a2161_8f2800e8:



    voice "voice/a21/6100030b03.opus"
    bm "\"......?!\""


translate english a2161_a68e9ff2:


    xy "\"Oh, hola.\""


translate english a2161_1a46fc8b:


    "Alguien sale del cuarto de utilería."


translate english a2161_9e167b07:


    xy "\"Perdón por molestar. Estamos buscando a—\""


translate english a2161_5e0c67c5:



    voice "voice/a21/6100040b03.opus"
    bm "\"¡AAAAAAAHHHHHH!\""


translate english a2161_b02853c4:


    "De inmediato vuelve a saltar adentro y cierra la puerta."


translate english a2161_e21ceccd:



    voice "voice/a21/6100050a02.opus"
    aoi "\"Salió corriendo.\""


translate english a2161_843ea1b4:


    xy "\"¿Fue algo que dije...?\""


translate english a2161_4d5310ed:



    voice "voice/a21/6100060a02.opus"
    aoi "\"¿Estás molesta?\""


translate english a2161_0df9ff28:


    "¿Quién no se molestaría ahora? ¡Una chica linda me miró una vez y salió corriendo gritando!"


translate english a2161_b898e591:



    voice "voice/a21/6100070b03.opus"
    bm "\"Eh... Emm...\""


translate english a2161_476b5513:


    xy "\"Oh. Hola otra vez.\""


translate english a2161_b8a8a603:



    voice "voice/a21/6100080a02.opus"
    aoi "\"¡Volvió!\""


translate english a2161_278358a9:


    "Un solo ojo se asoma por la rendija de la puerta."


translate english a2161_9ac05005:



    voice "voice/a21/6100090b03.opus"
    bm "\"¡Yo... Lo siento mucho! Es solo que soy algo tímida, así que en cuanto vi una cara conocida, me asusté...\""


translate english a2161_fcdf2c59:



    voice "voice/a21/6100100b03.opus"
    bm "\"Están buscando a Sone-senpai, ¿verdad? Yo... iré a buscarla.\""


translate english a2161_aadaf462:


    "Con eso, desaparece en el cuarto de utilería, cerrando la puerta con cuidado tras de sí."


translate english a2161_f99ff148:


    "Qué chica tan tímida... Espera, ¿qué?"


translate english a2161_f78162fa:


    "¿Reconoció mi cara?"


translate english a2161_7c0aa1c6:



    voice "voice/a21/6100110a02.opus"
    aoi "\"Una nueva opción romántica. Será mejor que no engañes a nadie.\""


translate english a2161_690e2655:


    xy "\"¿Qué? Yo no—\""


translate english a2161_da9ff0d0:



    voice "voice/a21/6100120a01.opus"
    mx "\"¡Cómo te atreves, Shinichi!\""


translate english a2161_88d0cf79:



    voice "voice/a21/6100130a01.opus"
    mx "\"¡¿Qué demonios le hiciste a la pobre Haru-chan?! ¡La oí gritar aquí afuera!\""


translate english a2161_116c7d3e:


    xy "\"No hice nada—\""


translate english a2161_1f22692f:



    voice "voice/a21/6100140a02.opus"
    aoi "\"¡Está engañando a dos!\""


translate english a2161_f6c29cc2:



    voice "voice/a21/6100150a01.opus"
    mx "\"¡¿Engañando a dos?!\""


translate english a2161_25974e06:


    xy "\"¡No!\""


translate english a2161_922b86cf:


    xy "\"¡¿Cómo puedo engañar a una novia que no tengo?!\""


translate english a2161_27778812:



    voice "voice/a21/6100160a01.opus"
    mx "\"Bueno, supongo que tienes un punto ahí...\""


translate english a2161_dc7aa8a4:


    xy "\"En fin, ¿ya terminó el ensayo?\""


translate english a2161_823af299:



    voice "voice/a21/6100170a01.opus"
    mx "\"Ajá. Acabó hace unos minutos.\""


translate english a2161_d1adc777:



    voice "voice/a21/6100180a02.opus"
    aoi "\"Aoi quería verlo...\""


translate english a2161_3251ea51:



    voice "voice/a21/6100190a01.opus"
    mx "\"No arruines la sorpresa, ahora. Cuando llegue la función de debut—\""


translate english a2161_197fece4:



    voice "voice/a21/6100200a01.opus"
    mx "\"—te dejaré ver mi glorioso swing completo en acción.\""


translate english a2161_aa6c6fcf:



    voice "voice/a21/6100210a02.opus"
    aoi "\"Eres tan genial...\""


translate english a2161_2da31054:



    voice "voice/a21/6100220a01.opus"
    mx "\"¡Jeje!\""


translate english a2161_2cf5d451:


    "El swing de práctica de Miyuki deja a Aoi sin palabras."


translate english a2161_d4f60b8c:


    "Mientras tanto, Miyuki parece estar de buen ánimo."


translate english a2161_ac225b8b:



    voice "voice/a21/6100230a01.opus"
    mx "\"¿Quieres intentar darle un swing tú mismo?\""


translate english a2161_fa1f7ac1:



    voice "voice/a21/6100240a02.opus"
    aoi "\"¿En serio?\""


translate english a2161_337c5416:



    voice "voice/a21/6100250a01.opus"
    mx "\"Claro.\""


translate english a2161_2762a977:


    xy "\"En ese caso, ¿por qué no vamos a las jaulas de bateo?\""


translate english a2161_5ad87939:



    voice "voice/a21/6100260a02.opus"
    aoi "\"¿Jaulas de bateo?\""


translate english a2161_b52f350c:



    voice "voice/a21/6100270a01.opus"
    mx "Quizá no sea muy divertido ir en grupo...\""


translate english a2161_9fc39cae:



    voice "voice/a21/6100280a02.opus"
    aoi "\"¿Porfi? ¡Aoi quiere ir!\""


translate english a2161_e17424bb:


    xy "\"¿Vamos, Miyuki? ¿Solo esta vez?\""


translate english a2161_7c62faf9:



    voice "voice/a21/6100290a01.opus"
    mx "\"Dios... ¡BIEN! ¡Como sea! Pasemos por ahí mañana todos.\""


translate english a2161_d0cf410b:



    voice "voice/a21/6100300a02.opus"
    aoi "\"¡Gracias, Miyuki!\""


translate english a2161_9237f7a3:



    voice "voice/a21/6100310a01.opus"
    mx "\"No es gran cosa. No tienes que agradecerme.\""


translate english a2161_c0fa0b7b:



    voice "voice/a21/6100320a01.opus"
    mx "\"En fin, ¡vamos! ¡A casa!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
