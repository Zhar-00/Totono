

translate english a2161_7a8d5f28:


    xy "\"Sorry to interrupt...\""


translate english a2161_1baa930e:


    "Asomo la cabeza por la puerta."


translate english a2161_9beb9616:


    "El gimnasio está vacío."


translate english a2161_aaaa152f:


    "¿El ensayo ya terminó?"


translate english a2161_32f1aded:


    "El único sonido es el tenue zumbido de la iluminación del escenario."


translate english a2161_a0552b69:


    xy "\"Uhh... Miyuki?\""


translate english a2161_52a3de6f:



    voice "voice/a21/6100010a02.opus"
    aoi "\"I can feel the zappy... Miyuki's over that way.\""


translate english a2161_0193f5c4:


    xy "\"What the?! Aoi, what are you doing?!\""


translate english a2161_18ee9443:



    voice "voice/a21/6100020a02.opus"
    aoi "\"Boop boop... Shinichi, aren't you coming too?\""


translate english a2161_0c7301f1:


    xy "\"R-Right! Of course!\""


translate english a2161_b27f42df:


    "Su expresión sigue tan vacía como siempre, pero parece inusualmente animada..."


translate english a2161_f6d37293:


    "Me apresuro tras ella hacia la zona de backstage."


translate english a2161_8f2800e8:



    voice "voice/a21/6100030b03.opus"
    bm "\"......?!\""


translate english a2161_a68e9ff2:


    xy "\"Oh, hi.\""


translate english a2161_1a46fc8b:


    "Alguien sale del cuarto de utilería."


translate english a2161_9e167b07:


    xy "\"Sorry to bother you. We're looking for—\""


translate english a2161_5e0c67c5:



    voice "voice/a21/6100040b03.opus"
    bm "\"AAAAAAAAHHHHHH!!!\""


translate english a2161_b02853c4:


    "De inmediato vuelve a saltar adentro y cierra la puerta."


translate english a2161_e21ceccd:



    voice "voice/a21/6100050a02.opus"
    aoi "\"She ran away.\""


translate english a2161_843ea1b4:


    xy "\"Was it something I said...?\""


translate english a2161_4d5310ed:



    voice "voice/a21/6100060a02.opus"
    aoi "\"Are you upset?\""


translate english a2161_0df9ff28:


    "¿Quién no se molestaría ahora? ¡Una chica linda me miró una vez y salió corriendo gritando!"


translate english a2161_b898e591:



    voice "voice/a21/6100070b03.opus"
    bm "\"Uh... Umm...\""


translate english a2161_476b5513:


    xy "\"Oh. Hi again.\""


translate english a2161_b8a8a603:



    voice "voice/a21/6100080a02.opus"
    aoi "\"She's back!\""


translate english a2161_278358a9:


    "Un solo ojo se asoma por la rendija de la puerta."


translate english a2161_9ac05005:



    voice "voice/a21/6100090b03.opus"
    bm "\"I... I'm really sorry! I'm just kinda shy, so the second I saw a familiar face, I freaked out...\""


translate english a2161_fcdf2c59:



    voice "voice/a21/6100100b03.opus"
    bm "\"You're looking for Sone-senpai, right? I... I'll go get her.\""


translate english a2161_aadaf462:


    "Con eso, desaparece en el cuarto de utilería, cerrando la puerta con cuidado tras de sí."


translate english a2161_f99ff148:


    "Qué chica tan tímida... Espera, ¿qué?"


translate english a2161_f78162fa:


    "¿Reconoció mi cara?"


translate english a2161_7c0aa1c6:



    voice "voice/a21/6100110a02.opus"
    aoi "\"A new romance option. You better not cheat.\""


translate english a2161_690e2655:


    xy "\"What? I wouldn—\""


translate english a2161_da9ff0d0:



    voice "voice/a21/6100120a01.opus"
    mx "\"How dare you, Shinichi!\""


translate english a2161_88d0cf79:



    voice "voice/a21/6100130a01.opus"
    mx "\"What on earth did you do to poor Haru-chan?! I heard her screaming out here!\""


translate english a2161_116c7d3e:


    xy "\"I didn't do anyth—\""


translate english a2161_1f22692f:



    voice "voice/a21/6100140a02.opus"
    aoi "\"He's two-timing!\""


translate english a2161_f6c29cc2:



    voice "voice/a21/6100150a01.opus"
    mx "\"Two-timing?!\""


translate english a2161_25974e06:


    xy "\"No!\""


translate english a2161_922b86cf:


    xy "\"How can I cheat on a girlfriend I don't have?!\""


translate english a2161_27778812:



    voice "voice/a21/6100160a01.opus"
    mx "\"Well, I guess you've got a point there...\""


translate english a2161_dc7aa8a4:


    xy "\"Anyway, did rehearsal end already?\""


translate english a2161_823af299:



    voice "voice/a21/6100170a01.opus"
    mx "\"Mmhmm. Just finished a few minutes ago.\""


translate english a2161_d1adc777:



    voice "voice/a21/6100180a02.opus"
    aoi "\"Aoi wanted to see it...\""


translate english a2161_3251ea51:



    voice "voice/a21/6100190a01.opus"
    mx "\"No spoiling the surprise, now. Once the debut performance rolls around—\""


translate english a2161_197fece4:



    voice "voice/a21/6100200a01.opus"
    mx "\"—I'll let you see my glorious full swing in action.\""


translate english a2161_aa6c6fcf:



    voice "voice/a21/6100210a02.opus"
    aoi "\"You're so cool...\""


translate english a2161_2da31054:



    voice "voice/a21/6100220a01.opus"
    mx "\"Hehe!\""


translate english a2161_2cf5d451:


    "El swing de práctica de Miyuki deja a Aoi sin palabras."


translate english a2161_d4f60b8c:


    "Mientras tanto, Miyuki parece estar de buen ánimo."


translate english a2161_ac225b8b:



    voice "voice/a21/6100230a01.opus"
    mx "\"Wanna try swinging it around yourself?\""


translate english a2161_fa1f7ac1:



    voice "voice/a21/6100240a02.opus"
    aoi "\"Really?\""


translate english a2161_337c5416:



    voice "voice/a21/6100250a01.opus"
    mx "\"Of course.\""


translate english a2161_2762a977:


    xy "\"In that case, why don't we hit up the batting cages?\""


translate english a2161_5ad87939:



    voice "voice/a21/6100260a02.opus"
    aoi "\"Batting cages?\""


translate english a2161_b52f350c:



    voice "voice/a21/6100270a01.opus"
    mx "Quizá no sea muy divertido ir en grupo...\""


translate english a2161_9fc39cae:



    voice "voice/a21/6100280a02.opus"
    aoi "\"Pretty please? Aoi wants to go!\""


translate english a2161_e17424bb:


    xy "\"C'mon, Miyuki? Just this once?\""


translate english a2161_7c62faf9:



    voice "voice/a21/6100290a01.opus"
    mx "\"God... FINE! Whatever! Let's all swing by there tomorrow.\""


translate english a2161_d0cf410b:



    voice "voice/a21/6100300a02.opus"
    aoi "\"Thank you, Miyuki!\""


translate english a2161_9237f7a3:



    voice "voice/a21/6100310a01.opus"
    mx "\"It's no big deal. You don't have to thank me.\""


translate english a2161_c0fa0b7b:



    voice "voice/a21/6100320a01.opus"
    mx "\"Anyway, come on. Let's go home!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
