

translate english e1152b_bc036457:


    xy "\"This is too sudden... I can't just kiss you right here...!\""


translate english e1152b_6d0c1914:



    voice "voice/e11/52b00010a01.opus"
    mx "\"Then perish.\""


translate english e1152b_46bc0fb0:


    xy "\"What?\""


translate english e1152b_dfe3bbc0:



    voice "voice/e11/52b00020a01.opus"
    mx "\"I'll start the day over again.\""


translate english e1152b_5409217f:



    voice "voice/e11/52b00030a01.opus"
    mx "\"As many times as it takes, over and over and over, for all eternity... until you kiss me.\""


translate english e1152b_5cbd7b0e:



    voice "voice/e11/52b00040a01.opus"
    mx "\"I'll program in an infinite loop until you choose 'Kiss her'.\""



translate english e1152b_b872ecef:



    voice "voice/e11/52b00050a01.opus"
    mx "\"Then you'll finally give in, won't you?\""


translate english e1152b_78ef5fe2:



    voice "voice/e11/52b00060a01.opus"
    mx "\"You'll understand you have no choice but to be with me...\""


translate english e1152b_83b21de7:


    xy "\"Wh-What are you—\""


translate english e1152b_8de4f3af:


    "Oigo un sonido agudo y metálico."


translate english e1152b_5f03e721:


    "Ha recogido... su bate de béisbol."


translate english e1152b_733f0e82:


    xy "\"C-Could you maybe stop messing around like this, please?\""


translate english e1152b_8ac7e111:



    voice "voice/e11/52b00070a01.opus"
    mx "\"I know YOU remember.\""


translate english e1152b_4f7decd6:



    voice "voice/e11/52b00080a01.opus"
    mx "\"I know YOU know I'm not joking.\""


translate english e1152b_c387b389:



    voice "voice/e11/52b00090a01.opus"
    mx "\"Now behave yourself and submit to me.\""


translate english e1152b_b1d358de:


    "Su figura es cautivadoramente hermosa."


translate english e1152b_b176dea2:


    "Mientras el bate se balancea hacia mí, decido—"


translate english strings:


    old "Сопротивляться"
    new "Contraatacar"


    old "Подчиняться"
    new "Someterme"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
