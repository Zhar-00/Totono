

translate english e1152b_bc036457:


    xy "\"Es demasiado repentino... ¡No puedo besarte así nomás aquí...!\""


translate english e1152b_6d0c1914:



    voice "voice/e11/52b00010a01.opus"
    mx "\"Entonces perece.\""


translate english e1152b_46bc0fb0:


    xy "\"¿Qué?\""


translate english e1152b_dfe3bbc0:



    voice "voice/e11/52b00020a01.opus"
    mx "\"Empezaré el día otra vez.\""


translate english e1152b_5409217f:



    voice "voice/e11/52b00030a01.opus"
    mx "\"Cuantas veces haga falta, una y otra y otra vez, por toda la eternidad... hasta que me beses.\""


translate english e1152b_5cbd7b0e:



    voice "voice/e11/52b00040a01.opus"
    mx "\"Programaré un bucle infinito hasta que elijas \"Besarla\".\""



translate english e1152b_b872ecef:



    voice "voice/e11/52b00050a01.opus"
    mx "\"Entonces por fin cederás, ¿no?\""


translate english e1152b_78ef5fe2:



    voice "voice/e11/52b00060a01.opus"
    mx "\"Entenderás que no tienes más opción que estar conmigo...\""


translate english e1152b_83b21de7:


    xy "\"¿Q-Qué estás—\""


translate english e1152b_8de4f3af:


    "Oigo un sonido agudo y metálico."


translate english e1152b_5f03e721:


    "Ha recogido... su bate de béisbol."


translate english e1152b_733f0e82:


    xy "\"¿P-Podrías dejar de hacer estas cosas, por favor?\""


translate english e1152b_8ac7e111:



    voice "voice/e11/52b00070a01.opus"
    mx "\"Sé que TÚ te acuerdas.\""


translate english e1152b_4f7decd6:



    voice "voice/e11/52b00080a01.opus"
    mx "\"Sé que TÚ sabes que no estoy bromeando.\""


translate english e1152b_c387b389:



    voice "voice/e11/52b00090a01.opus"
    mx "\"Ahora pórtate bien y sométete a mí.\""


translate english e1152b_b1d358de:


    "Su figura es cautivadoramente hermosa."


translate english e1152b_b176dea2:


    "Mientras el bate se balancea hacia mí, decido—"


translate english strings:


    old "Сопротивляться"
    new "Contraatacar"


    old "Подчиняться"
    new "Someterme"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
