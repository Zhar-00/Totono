

translate english a3111_eefc8674:



    voice "voice/a31/1100010b01.opus"
    xtl "\"Me confesó su amor.\""


translate english a3111_3aa14d0e:


    xy "\"...¿Qué?\""


translate english a3111_c4c4ce68:



    voice "voice/a31/1100020b01.opus"
    xtl "\"Dijo que fui la primera persona que miró más allá de sus pasatiempos raros.\""


translate english a3111_213ed703:



    voice "voice/a31/1100030b01.opus"
    xtl "\"Que siempre me quiso como hermano, pero... Últimamente se dio cuenta de que es algo más que eso.\""


translate english a3111_8ca43c7c:



    voice "voice/a31/1100040b01.opus"
    xtl "\"Ryuujirou... me confesó su amor... travestido.\""


translate english a3111_4777b0d0:


    xy "\"¿Qué... llevaba puesto...?\""


translate english a3111_58944c6d:



    voice "voice/a31/1100050b01.opus"
    xtl "\"Un traje de baño escolar de niña...\""


translate english a3111_67f84cce:


    xy "\"...¿No bromees?\""


translate english a3111_9d54d766:



    voice "voice/a31/1100060b01.opus"
    xtl "\"¡No, no es broma! ¡Ya tengo suficiente con tratar de entender mi jodida vida!\""



translate english a3111_379b0859:


    "Esto es algo bastante pesado a primera hora de la mañana..."


translate english a3111_a5bc3692:


    xy "\"O sea, tendrás que rechazarlo, ¿no?\""


translate english a3111_0f2a0427:



    voice "voice/a31/1100070b01.opus"
    xtl "\"¡Pero... pero...!\""


translate english a3111_dcf136e3:



    voice "voice/a31/1100080b01.opus"
    xtl "\"Con ese traje de baño... Ryuujirou, él...\""


translate english a3111_863bf17e:



    voice "voice/a31/1100090b01.opus"
    xtl "\"Estaba l<I></I>ndo...\""


translate english a3111_0138dd6d:



    voice "voice/a31/1100100b01.opus"
    xtl "\"¡¡¡ESTABA LINDO!!!\""


translate english a3111_631d5fad:



    voice "voice/a31/1100110b01.opus"
    xtl "\"¡¡¡MI HERMANITO NO PUEDE SER TAN LINDO!!!\""


translate english a3111_6f97917a:


    "Suena a una novela ligera mediocre..."


translate english a3111_8e29e90b:



    voice "voice/a31/1100120a01.opus"
    mx "\"¡Buenos días a todos!\""


translate english a3111_80382007:



    voice "voice/a31/1100130b01.opus"
    xtl "\"¡B-Buenos días, Sone-san!\""


translate english a3111_0ddb8f31:



    voice "voice/a31/1100140a01.opus"
    mx "\"¿Akebono-kun...? ¿Qué te tiene llorando tan temprano?\""


translate english a3111_8327cdbb:



    voice "voice/a31/1100150b01.opus"
    xtl "\"¡Sone-san! ¡Es una larga historia, pero escúchame! ¡Al final, seguro que estarás llorando conmigo...!\""


translate english a3111_90521ecd:



    voice "voice/a31/1100160a01.opus"
    mx "\"Espera, ¿dónde está Aoi?\""


translate english a3111_7c8febd8:



    voice "voice/a31/1100170a01.opus"
    mx "\"Shinichi, ¿la has visto?\""


translate english a3111_5aa6263f:



    voice "voice/a22/1100010a01.opus"
    mx "\"Va a haber..."


translate english a3111_958cd961:


    voice "voice/a22/1100020a01.opus"



translate english a3111_646f0cf4:


    extend "un beso.\""



translate english a3111_ba7b0279:



    voice "voice/a31/1100240a01.opus"
    mx "\"--Em, ¿Shinichi? ¿Estás escuchando?\""


translate english a3111_c82b8c3f:


    xy "\"Ah, em... {nw=1}"



translate english a3111_1bdc0001:


    extend "Pensándolo bien, no la he visto esta mañana.\""


translate english a3111_cef652f7:



    voice "voice/a31/1100250a01.opus"
    mx "\"Llega tarde, ¿no crees?\""


translate english a3111_8b8b4d32:


    "Normalmente Aoi ya está sentada en su pupitre mirando al vacío cuando llego..."


translate english a3111_07ef5e72:



    voice "voice/a31/1100260b01.opus"
    xtl "\"Hnn... nnn... ¡waahh...!\""


translate english a3111_a94661eb:


    xy "\"¿Hm? ¿Qué pasa, Yuutarou?\""


translate english a3111_01092e89:



    voice "voice/a31/1100270b01.opus"
    xtl "\"Ella me... ignoró por completo...\""


translate english a3111_75c0ee1c:



    voice "voice/a31/1100280b01.opus"
    xtl "\"Espera... ¡Shinichi! ¿Desde cuándo eres tan amiguito de...?\""


translate english a3111_4612b6f7:



    voice "voice/a31/1100290a02.opus"
    aoi "\"¡Buenos días, Miyuki!\""


translate english a3111_d1d979cb:



    voice "voice/a31/1100300a01.opus"
    mx "\"Buenos días, Aoi. ¡Llegas tarde!\""


translate english a3111_7ea0999f:



    voice "voice/a31/1100310a02.opus"
    aoi "\"Debí estar demasiado emocionada por ir al béisbol... No oí la alarma.\""


translate english a3111_e7741738:


    "Eso dice ella..."


translate english a3111_0accd139:


    xy "\"......\""


translate english a3111_108bd13f:


    "Pero no es lo que me parece a mí."


translate english a3111_da539642:


    "No solo parece tener sueño: parece agotada."


translate english a3111_dc0e94c5:


    "¿Quizá hay algo que la estresa?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
