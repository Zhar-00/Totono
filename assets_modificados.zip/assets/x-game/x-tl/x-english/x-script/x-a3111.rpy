

translate english a3111_eefc8674:



    voice "voice/a31/1100010b01.opus"
    xtl "\"He confessed his love to me.\""


translate english a3111_3aa14d0e:


    xy "\"...What?\""


translate english a3111_c4c4ce68:



    voice "voice/a31/1100020b01.opus"
    xtl "\"He said I was the first person to look past his weird hobbies.\""


translate english a3111_213ed703:



    voice "voice/a31/1100030b01.opus"
    xtl "\"That he always loved me as a brother, but... Lately he's realized it's something more than that.\""


translate english a3111_8ca43c7c:



    voice "voice/a31/1100040b01.opus"
    xtl "\"Ryuujirou... confessed his love to me... while crossdressing.\""


translate english a3111_4777b0d0:


    xy "\"What... was he wearing...?\""


translate english a3111_58944c6d:



    voice "voice/a31/1100050b01.opus"
    xtl "\"A girl's school swimsuit...\""


translate english a3111_67f84cce:


    xy "\"...No kidding?\""


translate english a3111_9d54d766:



    voice "voice/a31/1100060b01.opus"
    xtl "\"No, I'm not kidding! I'm too busy trying to figure out my fucked-up life!\""



translate english a3111_379b0859:


    "Esto es algo bastante pesado a primera hora de la mañana..."


translate english a3111_a5bc3692:


    xy "\"I mean, you'll have to turn him down, right?\""


translate english a3111_0f2a0427:



    voice "voice/a31/1100070b01.opus"
    xtl "\"But... but...!\""


translate english a3111_dcf136e3:



    voice "voice/a31/1100080b01.opus"
    xtl "\"In that swimsuit... Ryuujirou, he...\""


translate english a3111_863bf17e:



    voice "voice/a31/1100090b01.opus"
    xtl "\"He was c<I></I>ute...\""


translate english a3111_0138dd6d:



    voice "voice/a31/1100100b01.opus"
    xtl "\"HE WAS CUTE!!!\""


translate english a3111_631d5fad:



    voice "voice/a31/1100110b01.opus"
    xtl "\"MY LITTLE BROTHER CAN'T BE THAT CUTE!!!\""


translate english a3111_6f97917a:


    "Suena a una novela ligera mediocre..."


translate english a3111_8e29e90b:



    voice "voice/a31/1100120a01.opus"
    mx "\"Good morning, everyone!\""


translate english a3111_80382007:



    voice "voice/a31/1100130b01.opus"
    xtl "\"G-Good morning, Sone-san!\""


translate english a3111_0ddb8f31:



    voice "voice/a31/1100140a01.opus"
    mx "\"Akebono-kun...? What's got you crying this early in the morning?\""


translate english a3111_8327cdbb:



    voice "voice/a31/1100150b01.opus"
    xtl "\"Sone-san! It's a long story, but hear me out! By the end, I'm sure you'll be crying along with m--\""


translate english a3111_90521ecd:



    voice "voice/a31/1100160a01.opus"
    mx "\"Wait, where's Aoi?\""


translate english a3111_7c8febd8:



    voice "voice/a31/1100170a01.opus"
    mx "\"Shinichi, have you seen her?\""


translate english a3111_5aa6263f:



    voice "voice/a22/1100010a01.opus"
    mx "\"There's going to be..."


translate english a3111_958cd961:


    voice "voice/a22/1100020a01.opus"



translate english a3111_646f0cf4:


    extend "un beso.\""



translate english a3111_ba7b0279:



    voice "voice/a31/1100240a01.opus"
    mx "\"--Uh, Shinichi? Are you listening?\""


translate english a3111_c82b8c3f:


    xy "\"Oh, uh... {nw=1}"



translate english a3111_1bdc0001:


    extend "Pensándolo bien, no la he visto esta mañana.\""


translate english a3111_cef652f7:



    voice "voice/a31/1100250a01.opus"
    mx "\"She's late, don't you think?\""


translate english a3111_8b8b4d32:


    "Normalmente Aoi ya está sentada en su pupitre mirando al vacío cuando llego..."


translate english a3111_07ef5e72:



    voice "voice/a31/1100260b01.opus"
    xtl "\"Hnn... nnn... waahh...!\""


translate english a3111_a94661eb:


    xy "\"Hm? What's wrong, Yuutarou?\""


translate english a3111_01092e89:



    voice "voice/a31/1100270b01.opus"
    xtl "\"She completely... ignored me...\""


translate english a3111_75c0ee1c:



    voice "voice/a31/1100280b01.opus"
    xtl "\"Wait... Shinichi! Since when have you been all buddy-buddy with--\""


translate english a3111_4612b6f7:



    voice "voice/a31/1100290a02.opus"
    aoi "\"Morning, Miyuki!\""


translate english a3111_d1d979cb:



    voice "voice/a31/1100300a01.opus"
    mx "\"Good morning, Aoi. You're late!\""


translate english a3111_7ea0999f:



    voice "voice/a31/1100310a02.opus"
    aoi "\"Must've been too excited about going to the batting cages... Slept through my alarm.\""


translate english a3111_e7741738:


    "Eso dice ella..."


translate english a3111_0accd139:


    xy "\"......\""


translate english a3111_108bd13f:


    "Pero no es lo que me parece a mí."


translate english a3111_da539642:


    "No solo parece tener sueño: parece agotada."


translate english a3111_dc0e94c5:


    "¿Quizá hay algo que la estresa?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
