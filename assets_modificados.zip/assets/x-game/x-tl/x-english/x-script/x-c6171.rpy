

translate english c6171_b3e15780:


    "Ryuujirou es el hermano menor de Yuutarou."


translate english c6171_830f9dd1:


    "Yuutarou ha estado agonizando por él durante días... ¿y ahora Miyuki afirma que él y Haru-chan son en realidad la misma persona?"


translate english c6171_c31e1add:


    xy "\"¡Pero Haru-chan no parece un chico para nada!\""


translate english c6171_d7bdec5c:



    voice "voice/c61/7100010b01.opus"
    xtl "\"...Exacto.\""


translate english c6171_58a66ab6:


    "Ah. Cierto."


translate english c6171_1a35c282:


    "Yuutarou me ha contado una y otra vez sobre la peligrosa belleza de Ryuujirou."


translate english c6171_39278614:


    "Y si lo pienso, sí que explica algunas cosas..."


translate english c6171_379133b9:


    "Like why \"she\"llevaba un uniforme de trabajo de hombre en la tienda de la esquina..."



translate english c6171_336f9ca9:


    xy "\"Espera... ¡Pero Haru-chan usaba uniforme de chica en la escuela!\""


translate english c6171_3c5e89af:



    voice "voice/c61/7100020a01.opus"
    mx "\"Es solo un disfraz.\""


translate english c6171_a4762a2d:



    voice "voice/c61/7100030a01.opus"
    mx "\"En la obra, un personaje masculino se viste de mujer para suplir a alguien en el equipo de softbol femenil.\""


translate english c6171_0accd139:


    xy "\"......\""


translate english c6171_802d3837:


    "Llevaba un uniforme de chica cuando lo conocimos, así que debí simplemente asumir..."


translate english c6171_9e8c4714:


    "Come to think of it, that would explain why \"she\"se puso tan nervioso como para esconderse en el armario de utilería."



translate english c6171_590cbdba:


    "Después de todo, probablemente haría lo mismo si el amigo de mi hermano me sorprendiera travestido..."


translate english c6171_d6468e22:


    xy "\"¿Pero no se llama Ryuujirou? ¿Por qué usaría Haru?\""


translate english c6171_0c8b82b2:



    voice "voice/c61/7100040a01.opus"
    mx "\"¿Alguna vez oíste \"Haru wa akebono\"?\""



translate english c6171_6e08d86f:


    xy "\"Claro... \"En primavera, el amanecer\"... Esa famosa cita de Sei Shounagon o de quien sea...\""



translate english c6171_013c4d66:



    voice "voice/c61/7100050a01.opus"
    mx "\"Y bien. ¿Ya te cayó el veinte?\""


translate english c6171_047d624a:



    voice "voice/c61/7100060a01.opus"
    mx "\"Haru-chan es un chico.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
