

translate english c6171_b3e15780:


    "Ryuujirou es el hermano menor de Yuutarou."


translate english c6171_830f9dd1:


    "Yuutarou ha estado agonizando por él durante días... ¿y ahora Miyuki afirma que él y Haru-chan son en realidad la misma persona?"


translate english c6171_c31e1add:


    xy "\"But Haru-chan doesn't look like a guy at all!\""


translate english c6171_d7bdec5c:



    voice "voice/c61/7100010b01.opus"
    xtl "\"...Exactly.\""


translate english c6171_58a66ab6:


    "Ah. Cierto."


translate english c6171_1a35c282:


    "Yuutarou me ha contado una y otra vez sobre la peligrosa belleza de Ryuujirou."


translate english c6171_39278614:


    "Y si lo pienso, sí que explica algunas cosas..."


translate english c6171_379133b9:


    "Like why \"she\"llevaba un uniforme de trabajo de hombre en la tienda de la esquina..."



translate english c6171_336f9ca9:


    xy "\"Wait... But Haru-chan was wearing a girl's uniform at school!\""


translate english c6171_3c5e89af:



    voice "voice/c61/7100020a01.opus"
    mx "\"It's just a costume.\""


translate english c6171_a4762a2d:



    voice "voice/c61/7100030a01.opus"
    mx "\"In the play, a male character crossdresses in order to fill in on the girls' softball team.\""


translate english c6171_0accd139:


    xy "\"......\""


translate english c6171_802d3837:


    "Llevaba un uniforme de chica cuando lo conocimos, así que debí simplemente asumir..."


translate english c6171_9e8c4714:


    "Come to think of it, that would explain why \"she\"se puso tan nervioso como para esconderse en el armario de utilería."



translate english c6171_590cbdba:


    "Después de todo, probablemente haría lo mismo si el amigo de mi hermano me sorprendiera travestido..."


translate english c6171_d6468e22:


    xy "\"But isn't his name Ryuujirou? Why would he go by Haru?\""


translate english c6171_0c8b82b2:



    voice "voice/c61/7100040a01.opus"
    mx "\"Ever heard of 'Haru wa akebono'?\""



translate english c6171_6e08d86f:


    xy "\"Of course... 'In spring it is the dawn'... That famous quote by Sei Shounagon or whoever...\""



translate english c6171_013c4d66:



    voice "voice/c61/7100050a01.opus"
    mx "\"So. Has it sunk in yet?\""


translate english c6171_047d624a:



    voice "voice/c61/7100060a01.opus"
    mx "\"Haru-chan is a guy.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
