

translate english c5111_b0792202:


    "A la mañana siguiente—"


translate english c5111_ab757707:


    xy "\"¡Buenos días!\""


translate english c5111_7b6fa8c3:



    voice "voice/c51/1100010b01.opus"
    xtl "\"¡Hey, buenos días!\""


translate english c5111_d269a0a3:



    voice "voice/c51/1100020a02.opus"
    aoi "\"Boop boop...\""


translate english c5111_a1b93e3c:



    voice "voice/c51/1100030b01.opus"
    xtl "\"¡Oh, es Mukou!\""


translate english c5111_765f4d0f:



    voice "voice/c51/1100040b01.opus"
    xtl "\"¡¿La encontraste?!\""


translate english c5111_673cc05d:


    xy "\"Sí, supongo que sí.\""


translate english c5111_f6c1181d:



    voice "voice/c51/1100050b01.opus"
    xtl "\"¡Genial! ¡Me alegro mucho por ti!\""


translate english c5111_9db541a3:



    voice "voice/c51/1100060a02.opus"
    aoi "\"¿Yuutarou?\""


translate english c5111_5897eac9:



    voice "voice/c51/1100070b01.opus"
    xtl "\"¿S-Sí? ¿Qué pasa?\""


translate english c5111_553907e1:


    "Aoi se acerca directamente a Yuutarou y lo mira fijamente a los ojos."


translate english c5111_e8eb419b:



    voice "voice/c51/1100080a02.opus"
    aoi "\"Gracias por buscarme.\""


translate english c5111_d92ac5a1:



    voice "voice/c51/1100090a02.opus"
    aoi "\"Significa mucho para mí.\""


translate english c5111_67990187:



    voice "voice/c51/1100100b01.opus"
    xtl "\"¿Huh...?\""


translate english c5111_4b3103ae:


    "Yuutarou le echa un vistazo a su sonrisa y se queda congelado en el sitio."


translate english c5111_dbbf4049:



    voice "voice/c51/1100110b01.opus"
    xtl "\"¡O-Oh, claro! ¡Bah! ¡Solo estaba haciendo mi trabajo como capitán del Club de Chicos y Sueños!\""


translate english c5111_1703a5c6:


    xy "\"Wow, alguien está avergonzado...\""


translate english c5111_e462a442:



    voice "voice/c51/1100120b01.opus"
    xtl "\"¡No estoy avergonzado!\""


translate english c5111_bbbbfdb0:



    voice "voice/c51/1100130a02.opus"
    aoi "\"¿Eres tsundere?\""


translate english c5111_bc393056:


    "Dios, espero que no."


translate english c5111_e9f96838:



    voice "voice/c51/1100140b01.opus"
    xtl "\"Por cierto, Shinichi.\""


translate english c5111_53144367:



    voice "voice/c51/1100150b01.opus"
    xtl "\"Hablaste con ella, ¿verdad?\""


translate english c5111_9c930293:


    xy "\"Sí, claro que sí.\""


translate english c5111_61e79c4c:



    voice "voice/c51/1100160b01.opus"
    xtl "\"Espera... Entonces... ¡¿E-E-Eso significa?!\""


translate english c5111_e75faf37:



    voice "voice/c51/1100170b01.opus"
    xtl "\"¡¿U-U-U-Ustedes dos hicieron el delicioso?!\""


translate english c5111_5209dd7a:


    xy "\"¿En español, por favor?\""


translate english c5111_f2f810ae:



    voice "voice/c51/1100180b01.opus"
    xtl "\"¡Dependiendo de tu respuesta, podría meterte un petardo en el culo y dejar que la naturaleza haga lo suyo!\""


translate english c5111_d36dc40c:


    xy "\"Bueno, mira—\""


translate english c5111_80dd5d1b:



    voice "voice/c51/1100190a02.opus"
    aoi "\"Nos electrizamos.\""


translate english c5111_841f7250:


    xy "\"¡¿Aoi?! ¡¿Nos estabas espiando?!\""


translate english c5111_cf5d04aa:



    voice "voice/c51/1100200b01.opus"
    xtl "\"¿Y eso qué significa?\""


translate english c5111_13443af0:



    voice "voice/c51/1100210a02.opus"
    aoi "\"Tuvimos sexo.\""


translate english c5111_077ad8a6:


    xy "\"¡Hey!\""


translate english c5111_cf65a6c3:



    voice "voice/c51/1100220a02.opus"
    aoi "\"Whm hmmh shhkh.\""


translate english c5111_c3af7262:



    voice "voice/c51/1100230b01.opus"
    xtl "\"¿Q-Qué acabas de...?\""


translate english c5111_bc617d2a:


    xy "\"¡Seguro que solo estaba... estornudando! ¿Verdad, Aoi?\""


translate english c5111_50d34e92:



    voice "voice/c51/1100240a02.opus"
    aoi "\"Wehh hahh sepphh.\""


translate english c5111_ba16375f:



    voice "voice/c51/1100250a01.opus"
    mx "\"......\""


translate english c5111_f674c57b:


    "La puerta se abre y Miyuki entra al salón de clases."


translate english c5111_4602b6e8:


    "But her usual \"good morning\"está notablemente ausente."


translate english c5111_fa671542:


    "En cambio, camina directamente hacia nosotros, con los labios apretados."


translate english c5111_b48c30b5:



    voice "voice/c51/1100260a02.opus"
    aoi "\"Boop boop... boop... boop...\""


translate english c5111_7dc7544c:


    "La sangre se drena del rostro de Aoi."


translate english c5111_636ddb4c:


    "Esta es la primera vez que se ven en bastante tiempo."


translate english c5111_969ffff9:


    "Y Aoi sabe que Miyuki no estaba contenta con su pequeño acto de desaparición—"


translate english c5111_a068bdd9:



    voice "voice/c51/1100270a02.opus"
    aoi "\"M-Miyuki... Escucha... Este...\""


translate english c5111_7b381bfa:



    voice "voice/c51/1100280a01.opus"
    mx "\"Shinichi.\""


translate english c5111_92407349:


    xy "\"¿Huh...? ¿Yo?\""


translate english c5111_0eebac7b:


    "Miyuki ignora a Aoi y me llama a mí en su lugar."


translate english c5111_3b9b361e:



    voice "voice/c51/1100290a01.opus"
    mx "\"Ven conmigo.\""


translate english c5111_5f20f02f:


    xy "\"¿Qué? Pero—\""


translate english c5111_2c905c10:



    voice "voice/c51/1100300a01.opus"
    mx "\"¡He dicho que VENGAS CONMIGO!\""


translate english c5111_dca83342:


    "Con eso, la abeja reina me convoca a mí, el don nadie de la clase, justo delante de todos."


translate english c5111_90043d5a:


    "Al instante, todo el salón zumba de curiosidad ante este giro inesperado de la trama."


translate english c5111_71609f61:



    voice "voice/c51/1100310a01.opus"
    mx "\"¡Ahora! ¡Date prisa!\""


translate english c5111_9c053333:


    xy "\"¡Y-Ya voy!\""


translate english c5111_042b8f76:



    voice "voice/c51/1100320a02.opus"
    aoi "\"Shinichi...\""


translate english c5111_6f3b2e7c:


    xy "\"Yo voy a hablar con ella. Tú espera aquí, ¿sí?\""


translate english c5111_e58938b2:


    "Llamo a Aoi, luego me doy la vuelta y salgo del salón con Miyuki."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
