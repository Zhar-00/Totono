

translate english e2181c_91e07fba:


    xy "\"Huh?!\""


translate english e2181c_dd7d783a:


    "Mi bate corta el aire vacío."


translate english e2181c_b5753447:


    "Adiviné correctamente, y sin embargo ella superó todas mis expectativas..."


translate english e2181c_af5b0dcf:


    xy "\"You've gotten good...\""


translate english e2181c_0979f322:



    voice "voice/e21/81c00010a01.opus"
    mx "\"Do you have any idea how much practice I've put in?\""


translate english e2181c_a8147290:


    "Buen punto... No puedo empezar a imaginar..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
