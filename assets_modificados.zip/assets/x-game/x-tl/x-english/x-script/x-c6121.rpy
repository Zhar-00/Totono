

translate english c6121_7ae625c4:


    "El hecho es que Aoi no ha estado actuando como ella misma los últimos días."


translate english c6121_1cb5b184:


    "Su brillo se ha ido por completo. Simplemente... sobrevive cada día, de un momento al siguiente."


translate english c6121_ca95c308:


    "Había asumido que estaba físicamente enferma, pero..."


translate english c6121_0df8c437:


    xy "\"—!!!\""



translate english c6121_bb190408:


    "El sonido de la puerta abriéndose me hace estremecer."


translate english c6121_9ea0ddb7:



    voice "voice/c61/2100010a02.opus"
    aoi "\"Boop boop...\""



translate english c6121_bdb1e576:


    "Aoi sale, con la cara aún sonrojada."


translate english c6121_16c6497a:


    "Le dije que se quedara en casa y descansara."


translate english c6121_74fef27a:


    "Pero aquí está, rompiendo nuestra promesa."


translate english c6121_2ad09e32:


    "Mira hacia abajo al pasador de gatito en su mano."


translate english c6121_384fb9bc:



    voice "voice/c61/2100020a02.opus"
    aoi "\"Shinichi...\""


translate english c6121_85c9cd86:



    voice "voice/c61/2100030a02.opus"
    aoi "\"Por favor, perdóname...\""


translate english c6121_905b1025:


    "Mientras susurra, se tambalea hacia la calle en una neblina febril."


translate english c6121_0accd139:


    xy "\"......\""


translate english c6121_71d5ebc6:


    "Todavía puedo oír el doloroso ruego de Aoi resonando en mis oídos."


translate english c6121_ebfc801a:


    "Mordiéndome el labio, tomo una decisión."


translate english c6121_cd397fca:


    "No puedo pasar por alto esta pequeña excursión."


translate english c6121_09913a59:


    "Salgo de los arbustos y la sigo."


translate english c6121_1ea8528b:



    voice "voice/c61/2100040a02.opus"
    aoi "\"Boop boop... boop...\""


translate english c6121_167408e5:


    "Se tambalea como si caminara sobre nubes."


translate english c6121_01318387:


    "Casi como si siguiera una señal invisible."


translate english c6121_99092b03:


    "Luego se sale del camino a la escuela y..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
