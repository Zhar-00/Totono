

translate english e1135b_27aedc86:



    voice "voice/e11/35b00010a01.opus"
    mx "Olvidé que no has leído mi diario...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
