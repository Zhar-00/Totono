

translate english e1112d_acd6775f:



    voice "voice/e11/12d00010a01.opus"
    mx "\"......No.\""


translate english e1112d_5c27d5f4:



    voice "voice/e11/12d00020a01.opus"
    mx "\"You'll never get what you want.\""


translate english e1112d_2676b293:



    voice "voice/e11/12d00030a01.opus"
    mx "\"Why won't you just love me?\""


translate english e1112d_24e593e9:



    voice "voice/e11/12d00040a01.opus"
    mx "\"It would be so much easier for you that way.\""


translate english e1112d_f4397b1d:


    "Esquivando la pregunta, tomo un sorbo de su sopa de miso casera."


translate english e1112d_67340557:


    "Al tocar el tazón mis labios, mis dedos rozan mi barbilla."


translate english e1112d_e819c497:


    "...¿Qué demonios?"


translate english e1112d_23eafc99:


    "¿Desde cuándo me creció tanto la barba?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
