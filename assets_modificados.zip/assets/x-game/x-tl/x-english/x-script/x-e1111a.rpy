

translate english e1111a_2f69f6c0:



    voice "voice/e11/11a00010a01_d.opus"
    mx "\"Good morning.\""


translate english e1111a_a98a1c74:



    voice "voice/e11/11a00010a01_c.opus"
    mx "\"Good morning.\""


translate english e1111a_9375daa1:



    voice "voice/e11/11a00010a01.opus"
    mx "\"Good morning.\""


translate english e1111a_42e216e6:



    voice "voice/e11/11a00010a01_b.opus"
    mx "\"Good morning.\""


translate english e1111a_9375daa1_1:



    voice "voice/e11/11a00010a01.opus"
    mx "\"Good morning.\""


translate english e1111a_bf9ec16c:


    "Miyuki me saluda mientras prepara nuestro desayuno."


translate english e1111a_21e4d357:



    voice "voice/e11/11a00020a01_c.opus"
    mx "\"What should we do today?\""


translate english e1111a_21e4d357_1:



    voice "voice/e11/11a00020a01_c.opus"
    mx "\"What should we do today?\""


translate english e1111a_212ea595:



    voice "voice/e11/11a00020a01_b.opus"
    mx "\"What should we do today?\""


translate english e1111a_212ea595_1:



    voice "voice/e11/11a00020a01_b.opus"
    mx "\"What should we do today?\""


translate english e1111a_196c6d9b:



    voice "voice/e11/11a00020a01.opus"
    mx "\"What should we do today?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
