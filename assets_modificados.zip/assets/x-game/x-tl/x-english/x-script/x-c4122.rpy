

translate english c4122_334e948b:



    voice "voice/c41/2200010a02.opus"
    aoi "\"He should fuck her.\""


translate english c4122_123bf37c:



    voice "voice/c41/2200020b01.opus"
    xtl "\"Nngah?!\""


translate english c4122_3acb8c0d:


    xy "\"Aoi! Watch your mouth!\""


translate english c4122_58f294a0:



    voice "voice/c41/2200030a02.opus"
    aoi "\"He'll get addicted to carnal pleasure.\""


translate english c4122_360e4d90:



    voice "voice/c41/2200040a02.opus"
    aoi "\"His masculine instincts will kick in.\""


translate english c4122_24519b83:


    xy "\"Okay, that's enough of that, thank you—\""


translate english c4122_76b60535:



    voice "voice/c41/2200050a02.opus"
    aoi "\"Should Aoi fuck him?\""


translate english c4122_85fb4014:


    xy "\"I told you, stop talking like that!\""


translate english c4122_5097cebf:



    voice "voice/c41/2200060b01.opus"
    xtl "\"Private Shinichi!\""


translate english c4122_0ae00915:


    xy "\"What? What's that look for?\""


translate english c4122_2a77987a:



    voice "voice/c41/2200070b01.opus"
    xtl "\"As of this moment, I, Akebono Yuutarou, captain of the Boys and Dreams Club, have just come to terms with my true feelings! I'm in love with you!\""


translate english c4122_000e116e:


    xy "\"Come again?\""


translate english c4122_24c97a9e:



    voice "voice/c41/2200080a02.opus"
    aoi "\"Is this BL?\""


translate english c4122_236fd946:



    voice "voice/c41/2200090b01.opus"
    xtl "\"I'm in love with you—maybe? I mean, I might be? Probably? Most likely? For the most part? Almost entirely?\""


translate english c4122_8184099d:



    voice "voice/c41/2200100b01.opus"
    xtl "\"I am... I'm not... I am... I'm not... I am... AAAGGHH! I don't know! I don't understand myself!\""


translate english c4122_15ec0b26:



    voice "voice/c41/2200110b01.opus"
    xtl "\"Damn it! If only my masculine instincts would kick in! Someone, please! Help me get addicted to carnal pleasure!\""


translate english c4122_3310835d:



    voice "voice/c41/2200120b01.opus"
    xtl "\"Alright then! Mukou-san, I'm counting on you!\""


translate english c4122_3eea9f33:



    voice "voice/c41/2200130a02.opus"
    aoi "\"You wanna fuck?\""


translate english c4122_e474b1e4:



    voice "voice/c41/2200140b01.opus"
    xtl "\"Nonsense! I'm a gentleman!\""


translate english c4122_d4228271:



    voice "voice/c41/2200150b01.opus"
    xtl "\"I don't 'fuck'—I make love!\""


translate english c4122_97d0f62a:



    voice "voice/c41/2200160a02.opus"
    aoi "\"How do you make it?\""


translate english c4122_8cbacc36:



    voice "voice/c41/2200170b01.opus"
    xtl "\"Oh, I'm sure you can help me figure it out!\""


translate english c4122_4817ae8c:



    voice "voice/c41/2200180b01.opus"
    xtl "\"OW!\""


translate english c4122_4bda6231:


    xy "\"Dipshit! It's eight in the morning! Don't talk about this crap at full volume!\""


translate english c4122_c6917e19:



    voice "voice/c41/2200190a02.opus"
    aoi "\"Are you jealous?\""


translate english c4122_8c1e24a8:


    xy "\"No!\""


translate english c4122_6ce2752d:



    voice "voice/c41/2200200a01.opus"
    mx "\"Good morning!\""



translate english c4122_521efa78:



    voice "voice/c41/2200210b01.opus"
    xtl "\"G-Good morning, Sone-san!!!\""


translate english c4122_3e3540cc:


    "Miyuki entra al salón con la cabeza bien alta, como siempre."


translate english c4122_f2edb704:


    "Antes de llegar a su escritorio, nos lanza una mirada de reojo."


translate english c4122_acc71d33:



    voice "voice/c41/2200220a01.opus"
    mx "\"......\""


translate english c4122_3725c094:


    "Al instante, la cara de Aoi se desmorona."


translate english c4122_7cae1c02:



    voice "voice/c41/2200230a02.opus"
    aoi "\"Shinichi...\""


translate english c4122_030e2fa5:


    xy "\"Don't worry. I'll handle it.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
