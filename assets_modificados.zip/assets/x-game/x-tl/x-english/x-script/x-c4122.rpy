

translate english c4122_334e948b:



    voice "voice/c41/2200010a02.opus"
    aoi "\"Debería follársela.\""


translate english c4122_123bf37c:



    voice "voice/c41/2200020b01.opus"
    xtl "\"¿¡Nngah!?\""


translate english c4122_3acb8c0d:


    xy "\"¡Aoi! ¡Cuida tu boca!\""


translate english c4122_58f294a0:



    voice "voice/c41/2200030a02.opus"
    aoi "\"Se volverá adicto al placer carnal.\""


translate english c4122_360e4d90:



    voice "voice/c41/2200040a02.opus"
    aoi "\"Sus instintos masculinos se activarán.\""


translate english c4122_24519b83:


    xy "\"Okay, ya es suficiente de eso, gracias—\""


translate english c4122_76b60535:



    voice "voice/c41/2200050a02.opus"
    aoi "\"¿Debería Aoi follárselo?\""


translate english c4122_85fb4014:


    xy "\"¡Te dije que dejes de hablar así!\""


translate english c4122_5097cebf:



    voice "voice/c41/2200060b01.opus"
    xtl "\"¡Soldado Shinichi!\""


translate english c4122_0ae00915:


    xy "\"¿Qué? ¿A qué viene esa cara?\""


translate english c4122_2a77987a:



    voice "voice/c41/2200070b01.opus"
    xtl "\"¡A partir de este momento, yo, Akebono Yuutarou, capitán del Club de Chicos y Sueños, acabo de aceptar mis verdaderos sentimientos! ¡Estoy enamorado de ti!\""


translate english c4122_000e116e:


    xy "\"¿Cómo dices?\""


translate english c4122_24c97a9e:



    voice "voice/c41/2200080a02.opus"
    aoi "\"¿Esto es BL?\""


translate english c4122_236fd946:



    voice "voice/c41/2200090b01.opus"
    xtl "\"Estoy enamorado de ti—¿quizá? O sea, ¿podría ser? ¿Probablemente? ¿Muy probablemente? ¿En su mayor parte? ¿Casi totalmente?\""


translate english c4122_8184099d:



    voice "voice/c41/2200100b01.opus"
    xtl "\"Estoy... no estoy... estoy... no estoy... estoy... ¡AAAGGHH! ¡No lo sé! ¡No me entiendo a mí mismo!\""


translate english c4122_15ec0b26:



    voice "voice/c41/2200110b01.opus"
    xtl "\"¡Maldita sea! ¡Si tan solo se activaran mis instintos masculinos! ¡Alguien, por favor! ¡Ayúdenme a volverme adicto al placer carnal!\""


translate english c4122_3310835d:



    voice "voice/c41/2200120b01.opus"
    xtl "\"¡Entonces así será! ¡Mukou-san, cuento contigo!\""


translate english c4122_3eea9f33:



    voice "voice/c41/2200130a02.opus"
    aoi "\"¿Quieres follar?\""


translate english c4122_e474b1e4:



    voice "voice/c41/2200140b01.opus"
    xtl "\"¡Tonterías! ¡Soy un caballero!\""


translate english c4122_d4228271:



    voice "voice/c41/2200150b01.opus"
    xtl "\"¡Yo no \"follo\"—yo hago el amor!\""


translate english c4122_97d0f62a:



    voice "voice/c41/2200160a02.opus"
    aoi "\"¿Cómo lo haces?\""


translate english c4122_8cbacc36:



    voice "voice/c41/2200170b01.opus"
    xtl "\"¡Oh, estoy seguro de que puedes ayudarme a descubrirlo!\""


translate english c4122_4817ae8c:



    voice "voice/c41/2200180b01.opus"
    xtl "\"¡AY!\""


translate english c4122_4bda6231:


    xy "\"¡Imbécil! ¡Son las ocho de la mañana! ¡No hables de estas cosas a todo volumen!\""


translate english c4122_c6917e19:



    voice "voice/c41/2200190a02.opus"
    aoi "\"¿Estás celoso?\""


translate english c4122_8c1e24a8:


    xy "\"¡No!\""


translate english c4122_6ce2752d:



    voice "voice/c41/2200200a01.opus"
    mx "\"¡Buenos días!\""



translate english c4122_521efa78:



    voice "voice/c41/2200210b01.opus"
    xtl "\"¡B-Buenos días, Sone-san!!!\""


translate english c4122_3e3540cc:


    "Miyuki entra al salón con la cabeza bien alta, como siempre."


translate english c4122_f2edb704:


    "Antes de llegar a su escritorio, nos lanza una mirada de reojo."


translate english c4122_acc71d33:



    voice "voice/c41/2200220a01.opus"
    mx "\"......\""


translate english c4122_3725c094:


    "Al instante, la cara de Aoi se desmorona."


translate english c4122_7cae1c02:



    voice "voice/c41/2200230a02.opus"
    aoi "\"Shinichi...\""


translate english c4122_030e2fa5:


    xy "\"No te preocupes. Yo me encargo.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
