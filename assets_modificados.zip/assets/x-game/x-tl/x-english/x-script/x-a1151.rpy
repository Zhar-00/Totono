

translate english a1151_a6a48fb0:


    "El mismo salón de siempre..."


translate english a1151_ce59c9cf:


    "La misma charla de siempre..."


translate english a1151_e1270192:


    "Y ahí está sentada Aoi..."


translate english a1151_d10eae40:



    voice "voice/a11/5100010a02.opus"
    aoi "\"Bip bip...\""


translate english a1151_33b7b58e:


    "...mirando al vacío en su pupitre, como de costumbre."



translate english a1151_4729b468:


    "Parece bastante aburrida."


translate english a1151_a12cd01c:


    "¿TODAVÍA no tiene señal?"


translate english a1151_2270413f:


    "A estas alturas, empiezo a pensar que quizá su teléfono está roto."


translate english a1151_b7841fca:



    voice "voice/a11/5100020b01.opus"
    xtl "\"¡Shinichi! ¡Shinichi! ¡Ven aquí!\""


translate english a1151_1d8c4646:


    xy "\"¿Qué quieres? Estoy en medio de—\""


translate english a1151_bc46ac4b:



    voice "voice/a11/5100030b01.opus"
    xtl "\"¡Te lo suplico! ¡Es importante!\""


translate english a1151_0accd139:


    xy "\"\"\"......\"\"\""


translate english a1151_ad7e2a52:


    xy "\"Bien, bien.\""


translate english a1151_2118363c:


    "A regañadientes, me dirijo a mi asiento."


translate english a1151_0d11df99:


    xy "\"...Entonces ¿qué es?\""


translate english a1151_e7a3c64d:



    voice "voice/a11/5100040b01.opus"
    xtl "\"¡Necesito un consejo!\""


translate english a1151_39b2951f:


    xy "\"¡Pfft! ¡Por favor! ¿¡Qué tienes que preocuparte tú!?\""


translate english a1151_39350d43:



    voice "voice/a11/5100050b01.opus"
    xtl "\"¡Shhh! ¡Baja la voz, bocón!\""


translate english a1151_61ac669a:


    xy "\"¿Es tan serio?\""


translate english a1151_0a610301:



    voice "voice/a11/5100060b01.opus"
    xtl "\"Amigo, es crítico. Hay vidas en juego.\""


translate english a1151_94f2aeb4:



    voice "voice/a11/5100070b01.opus"
    xtl "\"Ok... Es... Es esto.\""


translate english a1151_9215fe23:


    "Yuutarou abre su mochila para mostrarme... un par de..."


translate english a1151_972be0b5:


    xy "\"...¿Bragas?\""


translate english a1151_cf1d3a35:



    voice "voice/a11/5100080b01.opus"
    xtl "\"Sí, en efecto— ¡la esencia misma de los sueños del hombre!\""


translate english a1151_0accd139_1:


    xy "\"\"\"......\"\"\""


translate english a1151_a690a0af:



    voice "voice/a11/5100090b01.opus"
    xtl "\"¡Un artefacto de la ambición masculina!\""


translate english a1151_889ce12e:


    "Sí, ya entendí, gracias."


translate english a1151_e131696a:


    xy "\"¿Las robaste?\""


translate english a1151_288eb300:



    voice "voice/a11/5100100b01.opus"
    xtl "\"¡Cómo te atreves!\""


translate english a1151_6ab17f78:



    voice "voice/a11/5100110b01.opus"
    xtl "\"Las ENCONTRÉ.\""


translate english a1151_6c5ef6c4:


    xy "\"Tú... las encontraste...\""


translate english a1151_92fb9867:



    voice "voice/a11/5100120b01.opus"
    xtl "\"Así es.\""


translate english a1151_109bc516:



    voice "voice/a11/5100130b01.opus"
    xtl "\"Justo afuera de la puerta de nuestra casa.\""


translate english a1151_3aa14d0e:


    xy "\"...¿Qué?\""


translate english a1151_f4329124:



    voice "voice/a11/5100140b01.opus"
    xtl "\"Encontré un sueño tirado justo afuera de la puerta de nuestra casa...\""


translate english a1151_4d2739c3:


    xy "\"Dijiste que solo hay cuatro personas en tu familia, ¿verdad?\""


translate english a1151_fefac1ba:


    xy "\"Olvidé... ¿Tenías una hermana mayor?\""


translate english a1151_665b052c:



    voice "voice/a11/5100150b01.opus"
    xtl "\"Nop.\""


translate english a1151_5556bd49:


    xy "\"¿Una hermana menor, quizás?\""


translate english a1151_a2cc9e69:



    voice "voice/a11/5100160b01.opus"
    xtl "\"¡Nada de eso, compadre!\""


translate english a1151_e346cd6b:


    xy "\"Ok, entonces ¿QUÉ tienes?\""


translate english a1151_71092947:



    voice "voice/a11/5100170b01.opus"
    xtl "\"Un papá, una mamá, un hermanito y yo.\""


translate english a1151_0accd139_2:


    xy "\"\"\"......\"\"\""


translate english a1151_374cbc59:



    voice "voice/a11/5100180b01.opus"
    xtl "\"\"\"......\"\"\""


translate english a1151_789fc27f:



    voice "voice/a11/5100190b01.opus"
    xtl "\"Dime, Shinichi, mi hermano en los sueños...\""


translate english a1151_c1ee1e96:



    voice "voice/a11/5100200b01.opus"
    xtl "\"¿¡Qué hago con este artefacto!?\""


translate english a1151_33d7c13c:


    xy "\"Lo que quieras, supongo.\""


translate english a1151_c555ec8f:



    voice "voice/a11/5100210b01.opus"
    xtl "\"¿Puedo pajearme con ellas? ¿Debería? ¿Simplemente lo hago?\""


translate english a1151_719f95a5:



    voice "voice/a11/5100220b01.opus"
    xtl "\"Pero... en el caso remoto de que sean de mi mamá...\""


translate english a1151_5d0c9470:



    voice "voice/a11/5100230b01.opus"
    xtl "\"¡¡¡MIS SUEÑOS ESTÁN MUERTOS!!!\""


translate english a1151_aa94bb6a:


    xy "\"Qué mal por ti.\""


translate english a1151_394ec6b4:



    voice "voice/a11/5100240a01.opus"
    mx "\"¡Buenos días!\""


translate english a1151_5619f007:



    voice "voice/a11/5100250b01.opus"
    xtl "\"¡B-Buenos días!\""


translate english a1151_d6a358d0:


    "Con la llegada de Miyuki, el salón cobra vida."


translate english a1151_c16a5a34:


    "De verdad que es la estrella del espectáculo..."


translate english a1151_95c89b19:



    voice "voice/a11/5100260b01.opus"
    xtl "\"Haah... Sone-san se ve tan encantadora como siempre esta mañana...\""


translate english a1151_e2dedb8d:


    "Yuutarou la contempla, embelesado."


translate english a1151_603d9a44:


    "Otra vez. La misma escena que se repite cada mañana."


translate english a1151_6f530b4d:


    "O eso creía—"


translate english a1151_f1449dcf:



    voice "voice/a11/5100270a02.opus"
    aoi "\"¡Entendido!\""


translate english a1151_c73b0c5b:



    voice "voice/a11/5100280a01.opus"
    mx "\"¿Mukou-san...?\""


translate english a1151_49d42901:


    "Esta vez Aoi se pone de pie de un salto, con la mano en el aire, los ojos en Miyuki."


translate english a1151_49c43254:



    voice "voice/a11/5100290b01.opus"
    xtl "\"Qué raro. ¿Qué le pasa hoy?\""


translate english a1151_98569031:


    xy "\"Oh, Dios.\""


translate english a1151_cdc2bca6:


    "Tengo un presentimiento realmente, REALMENTE malo sobre esto."


translate english a1151_63f442d5:


    "Esa foto probablemente sigue en el teléfono de Aoi—"


translate english a1151_a4413ca3:



    voice "voice/a11/5100300a01.opus"
    mx "\"¿Me necesitas para algo?\""


translate english a1151_720f9aee:



    voice "voice/a11/5100310a02.opus"
    aoi "\"Aoi lo siente mucho.\""


translate english a1151_e71f0e1d:


    "Baja la cabeza."


translate english a1151_818bf9cc:



    voice "voice/a11/5100320a02.opus"
    aoi "\"Ayer fue todo mi culpa.\""


translate english a1151_df028b96:



    voice "voice/a11/5100330a01.opus"
    mx "\"Oh... Cierto. Eso.\""


translate english a1151_e4977e59:


    "Nuestros compañeros observan esta interacción con leve desconcierto."


translate english a1151_0960fb35:


    "Percibiendo su confusión, Miyuki sonríe."


translate english a1151_8b5942d7:



    voice "voice/a11/5100340a01.opus"
    mx "\"No te preocupes. No has hecho nada malo.\""


translate english a1151_93caac15:



    voice "voice/a11/5100350a02.opus"
    aoi "\"¿Me perdonas?\""


translate english a1151_f780f304:



    voice "voice/a11/5100360a01.opus"
    mx "\"No necesitas pedir perdón por algo que no hiciste, tonta.\""


translate english a1151_401d18d9:



    voice "voice/a11/5100370a02.opus"
    aoi "\"Entonces... Aoi tiene un favor que pedir.\""


translate english a1151_2794d887:



    voice "voice/a11/5100380a01.opus"
    mx "\"¿Un favor?\""


translate english a1151_8e4c44cb:



    voice "voice/a11/5100390a02.opus"
    aoi "\"Aoi quiere ser amiga de Miyuki.\""


translate english a1151_861a21e5:



    voice "voice/a11/5100400a02.opus"
    aoi "\"¿Podemos?\""


translate english a1151_dfc2d40d:



    voice "voice/a11/5100410a01.opus"
    mx "\"No seas tonta.\""


translate english a1151_5eacade5:


    "Miyuki pone su sonrisa más deslumbrante."


translate english a1151_2bfb4674:



    voice "voice/a11/5100420a01.opus"
    mx "\"Estamos en la misma clase, ¿no? ¡Entonces ya somos las mejores amigas!\""


translate english a1151_fbd96d4f:



    voice "voice/a11/5100430a02.opus"
    aoi "\"Amigas...\""


translate english a1151_9df64dad:



    voice "voice/a11/5100440a01.opus"
    mx "\"¿Era todo lo que necesitabas?\""


translate english a1151_7380a9a1:



    voice "voice/a11/5100450a02.opus"
    aoi "\"Emm... ¿Podemos intercambiar correos electróni—\""


translate english a1151_a29a1965:



    voice "voice/a11/5100460a01.opus"
    mx "\"Perdón, no tengo tiempo ahora.\""


translate english a1151_824b8877:



    voice "voice/a11/5100470a01.opus"
    mx "\"Quizás después.\""


translate english a1151_b3c56f61:



    voice "voice/a11/5100480a02.opus"
    aoi "\"Bip bip...\""


translate english a1151_db3b623d:


    "Miyuki termina rápido la conversación, con la sonrisa inquebrantable."


translate english a1151_20b331e9:


    "Momentos después, el salón vuelve a la normalidad."


translate english a1151_75f98528:



    voice "voice/a11/5100490b01.opus"
    xtl "\"Hombre, ¡no me esperaba eso para nada!\""


translate english a1151_f3c3673c:


    xy "\"Yo tampoco.\""


translate english a1151_a065386e:


    "Aoi regresa a su pupitre y toma asiento."


translate english a1151_49235493:


    "Su expresión sigue tan vacía como siempre... pero sus ojos están cuidadosamente fijos en el teléfono entre sus manos."


translate english a1151_fdf13359:


    "El asunto es que conozco a Miyuki desde hace mucho tiempo."


translate english a1151_a4b01697:


    "¿Esa sonrisa deslumbrante suya?"


translate english a1151_dde76b9a:


    "Es completamente falsa."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
