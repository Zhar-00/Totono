

translate english a7233_a2543890:



    voice "voice/a72/3300010a01.opus"
    mx "\"Me temo que un \"perdón\" no basta.\""


translate english a7233_93115faa:


    xy "\"¿A qué te refieres con que no basta? ¿Qué esperas que haga?\""


translate english a7233_fb2ae289:



    voice "voice/a72/3300020a01.opus"
    mx "\"Como castigo... quiero que batees un jonrón en mi lugar.\""


translate english a7233_d27eeafa:


    xy "\"¿Eh?\""


translate english a7233_32985aaf:



    voice "voice/a72/3300030a01.opus"
    mx "\"Más te vale batear hasta lograrlo.\""


translate english a7233_00e3022f:



    voice "voice/a72/3300040a01.opus"
    mx "\"¿O tienes demasiado miedo de poncharte?\""


translate english a7233_cd0020f8:


    xy "\"Okay, trato hecho.\""


translate english a7233_e0db1f56:


    xy "\"No puedo dejar que me llames gallina, ¿o sí?\""


translate english a7233_8062da32:


    "A regañadientes, me levanto de la banca."


translate english a7233_1a367e63:


    "Miyuki me entrega un bate de béisbol de metal."


translate english a7233_0c431bd2:


    xy "\"¡Prepárate para aprender!\""


translate english a7233_6577d817:


    "Practico algunos swings."


translate english a7233_e3dabd0e:


    "Sé que mi postura de bateo no es perfecta."


translate english a7233_b11fa0e4:


    "Sobre todo en comparación con la suya."


translate english a7233_1b4614a8:



    voice "voice/a72/3300050a01.opus"
    mx "\"¡Te ves genial, Shinichi!\""


translate english a7233_69423a03:


    xy "\"¡Para nada!\""


translate english a7233_885727b2:



    voice "voice/a72/3300060a01.opus"
    mx "\"¡No, en serio! ¡Eres el más genial!\""


translate english a7233_d142d249:


    "O sea, estoy dando lo mejor de mí..."


translate english a7233_c04e786e:


    "Pero el resto depende de la pura suerte."


translate english a7233_d491341d:


    "Lo único que puedo hacer es reunir todo mi fuerza—"


translate english a7233_50eabfe9:


    "—y dar el swing."


translate english a7233_dce0a003:


    xy "\"¡¡¡Bien, trae eso!!!\""


translate english a7233_a03e5642:



    voice "voice/a72/3300070a01.opus"
    mx "\"¡Puedes hacerlo!\""


translate english a7233_0df8c437:


    xy "\"—!!!\""



translate english a7233_f53ecada:


    "Sé que esto sonará ridículo..."


translate english a7233_279dfd64:


    "Créeme, yo tampoco puedo creerlo."


translate english a7233_87349808:


    "Pero, lo creas o no, cuando golpeé esa pelota—"


translate english a7233_6f565f4c:


    "—it nailed that \"Home Run\"objetivo justo en el centro a mi primer intento."


translate english a7233_b62c0522:


    "Como si Dios lo hiciera solo para burlarse de mí."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
