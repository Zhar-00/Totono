

translate english a7233_a2543890:



    voice "voice/a72/3300010a01.opus"
    mx "\"Sorry won't cut it, I'm afraid.\""


translate english a7233_93115faa:


    xy "\"What do you mean, it won't cut it? What do you expect me to do?\""


translate english a7233_fb2ae289:



    voice "voice/a72/3300020a01.opus"
    mx "\"As your punishment... I want you to hit a home run in my place.\""


translate english a7233_d27eeafa:


    xy "\"Huh?\""


translate english a7233_32985aaf:



    voice "voice/a72/3300030a01.opus"
    mx "\"You better swing that bat until you get one.\""


translate english a7233_00e3022f:



    voice "voice/a72/3300040a01.opus"
    mx "\"Or are you too scared you'll strike out?\""


translate english a7233_cd0020f8:


    xy "\"Okay, you're on.\""


translate english a7233_e0db1f56:


    xy "\"Can't have you calling me some kind of chicken, now can I?\""


translate english a7233_8062da32:


    "A regañadientes, me levanto de la banca."


translate english a7233_1a367e63:


    "Miyuki me entrega un bate de béisbol de metal."


translate english a7233_0c431bd2:


    xy "\"Prepare to get schooled!\""


translate english a7233_6577d817:


    "Practico algunos swings."


translate english a7233_e3dabd0e:


    "Sé que mi postura de bateo no es perfecta."


translate english a7233_b11fa0e4:


    "Sobre todo en comparación con la suya."


translate english a7233_1b4614a8:



    voice "voice/a72/3300050a01.opus"
    mx "\"Looking cool, Shinichi!\""


translate english a7233_69423a03:


    xy "\"Hardly!\""


translate english a7233_885727b2:



    voice "voice/a72/3300060a01.opus"
    mx "\"No, really! You're the coolest!\""


translate english a7233_d142d249:


    "O sea, estoy dando lo mejor de mí..."


translate english a7233_c04e786e:


    "Pero el resto depende de la pura suerte."


translate english a7233_d491341d:


    "Lo único que puedo hacer es reunir todo mi fuerza—"


translate english a7233_50eabfe9:


    "—y dar el swing."


translate english a7233_dce0a003:


    xy "\"Alright, bring it on!!!\""


translate english a7233_a03e5642:



    voice "voice/a72/3300070a01.opus"
    mx "\"You can do it!\""


translate english a7233_0df8c437:


    xy "\"—!!!\""



translate english a7233_f53ecada:


    "Sé que esto sonará ridículo..."


translate english a7233_279dfd64:


    "Créeme, yo tampoco puedo creerlo."


translate english a7233_87349808:


    "Pero, lo creas o no, cuando golpeé esa pelota—"


translate english a7233_6f565f4c:


    "—it nailed that \"Home Run\"objetivo justo en el centro a mi primer intento."


translate english a7233_b62c0522:


    "Como si Dios lo hiciera solo para burlarse de mí."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
