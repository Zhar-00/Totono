

translate english e2163a_94e91448:


    "Al parecer es un artículo hecho a mano único. Junto a él hay un segundo pin, ligeramente distinto, del mismo estilo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
