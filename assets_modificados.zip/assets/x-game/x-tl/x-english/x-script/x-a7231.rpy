

translate english a7231_2e11cb7a:



    voice "voice/a72/3100010a01.opus"
    mx "\"—!!!\""


translate english a7231_b1b5adcf:



    voice "voice/a72/3100020a01.opus"
    mx "\"Aaagh! So close...\""


translate english a7231_6094a3f9:


    xy "\"You nearly had it that time.\""


translate english a7231_daea9c05:



    voice "voice/a72/3100030a01.opus"
    mx "\"I'm not giving up! I'll get it this time!\""


translate english a7231_687babb1:


    "Hoy rentamos las jaulas de bateo solo para nosotros."


translate english a7231_cd8a3fb0:


    "Miyuki golpea pelota tras pelota."


translate english a7231_ef3a48ce:


    "Su forma sigue siendo tan cautivadoramente hermosa como siempre."


translate english a7231_6ab61c32:


    xy "\"Hmm?\""


translate english a7231_bc213b84:


    "Oigo un pequeño miau debajo de mí."


translate english a7231_7da5a3da:


    "Miro bajo la banca y encuentro—"


translate english a7231_36962783:


    xy "\"Wait... I know you...\""


translate english a7231_c0ba8549:



    voice "voice/a72/3100050a01.opus"
    mx "\"Ugghhh... So close! I got a triple that time!\""


translate english a7231_1c607ff6:



    voice "voice/a72/3100060a01.opus"
    mx "\"Hmm... I know I've almost got it...\""


translate english a7231_ea76653d:



    voice "voice/a72/3100070a01.opus"
    mx "\"What the?! Shinichi! You weren't even watching?!\""


translate english a7231_fb0f3a31:


    xy "\"Oh, sorry. I got distracted by this random cat.\""


translate english a7231_e0fd43a3:



    voice "voice/a72/3100080a01.opus"
    mx "\"There's a cat?!\""


translate english a7231_2cae7d8c:



    voice "voice/a72/3100090a01.opus"
    mx "\"So there is! A little black cat!\""


translate english a7231_6edd1e9b:



    voice "voice/a72/3100100a01.opus"
    mx "\"Shinichi, take pics! Get some close-up shots for me!\""


translate english a7231_8ae28e0a:


    xy "\"Huh? But my phone... Wait, where'd I even put my phone...?\""


translate english a7231_27edb0c2:



    voice "voice/a72/3100110a01.opus"
    mx "\"Just use mine! Here!\""


translate english a7231_62c34fdf:


    xy "\"Oh, okay!\""


translate english a7231_fa17cf5d:


    "Me entrega su teléfono, y lo tomo."


translate english a7231_2f8edf98:


    "Espera, ¿qué demonios?"


translate english a7231_2929cc70:


    "Es un smartphone... ¿Qué pasó con su viejo teléfono plegable?"


translate english a7231_a292709e:



    voice "voice/a72/3100120a01.opus"
    mx "\"Shinichi!\""


translate english a7231_3c159382:


    xy "\"R-Right! Alright, little buddy, just hold still...\""


translate english a7231_d0966ef2:


    xy "\"Gah! Hey! I said hold still!\""


translate english a7231_a74c4ed2:


    xy "\"Damn... I wasn't fast enough...\""


translate english a7231_155ca366:



    voice "voice/a72/3100140a01.opus"
    mx "\"What a waste of a perfect opportunity...\""


translate english a7231_de03fda3:


    xy "\"Look, I'm sorry, okay?\""


translate english a7231_49186791:


    "Santo cielo... Miyuki ama a los gatos DEMASIADO..."


translate english a7231_edebfbe6:


    "Suelto un suspiro y me dispongo a devolverle su teléfono—"


translate english a7231_5ae91284:


    "—pero justo entonces, mi dedo toca el botón equivocado."


translate english a7231_84932efe:


    "De la nada, una foto aparece en la pantalla."


translate english a7231_21769d5f:


    "Es esa foto que tomamos juntos."


translate english a7231_c08e6cce:


    "Nos vemos tan felices juntos—"


translate english a7231_cc074210:


    "...Espera."


translate english a7231_e2bee24c:


    "Aguanta un segundo."


translate english a7231_be168b60:


    "La azotea es nuestro pequeño lugar especial solo para los dos..."


translate english a7231_1eeed321:


    "...Entonces, ¿quién demonios nos tomó esta foto?"


translate english a7231_d20742ca:



    voice "voice/a72/3100150a01.opus"
    mx "\"...Shinichi?\""


translate english a7231_a4db7067:



    voice "voice/a72/3100160a01.opus"
    mx "\"Whoa, hold on! Are you going through my phone?!\""


translate english a7231_35be402c:


    xy "\"Oh, sorry! I didn't mean to—"


translate english a7231_717e63ad:



    voice "voice/a72/3100170a01.opus"
    mx "\"Give it back!\""


translate english a7231_f75dd020:


    "Antes de que pueda responder, una Miyuki muy sonrojada me arrebata el teléfono."


translate english a7231_f4337073:



    voice "voice/a72/3100180a01.opus"
    mx "\"You weren't reading my diary, were you?!\""


translate english a7231_cc44bfae:


    xy "\"Your diary's on there?\""


translate english a7231_897624d7:


    "Ahora que lo menciona, creo recordar haber visto una carpeta llena de lo que parecían fotos de notas escritas a mano, a juzgar por las miniaturas."


translate english a7231_22b8f5f9:


    xy "\"You take pictures of your diary entries? What for?\""


translate english a7231_9a65e9cf:


    "¿Quién se tomaría la molestia de hacer todo ese esfuerzo?"


translate english a7231_0d9f66c6:



    voice "voice/a72/3100190a01.opus"
    mx "\"Sh-Shut up! It's a free country, you know!\""


translate english a7231_bb09b673:



    voice "voice/a72/3100200a01.opus"
    mx "\"I just want to be able to look back on my memories with you at any given time! Is that so wrong?\""


translate english a7231_f547017a:


    xy "\"No, not at all.\""


translate english a7231_171dffe4:


    "Miyuki siempre ha sido del tipo meticuloso."


translate english a7231_2258f347:


    "Aunque creo que se está alterando un poco de más por esto..."


translate english a7231_c14a98d1:


    "Pero, para ser justos, no fue muy bien de mi parte mirar cosas en su teléfono, para empezar."


translate english a7231_b2d68090:


    xy "\"I'm really sorry, Miyuki. I shouldn't have looked.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
