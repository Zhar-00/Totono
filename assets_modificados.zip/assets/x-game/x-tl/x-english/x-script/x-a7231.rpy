

translate english a7231_2e11cb7a:



    voice "voice/a72/3100010a01.opus"
    mx "\"—!!!\""


translate english a7231_b1b5adcf:



    voice "voice/a72/3100020a01.opus"
    mx "\"¡Aaagh! Tan cerca...\""


translate english a7231_6094a3f9:


    xy "\"Casi lo logras esa vez.\""


translate english a7231_daea9c05:



    voice "voice/a72/3100030a01.opus"
    mx "\"¡No me rindo! ¡Esta vez sí lo logro!\""


translate english a7231_687babb1:


    "Hoy rentamos las jaulas de bateo solo para nosotros."


translate english a7231_cd8a3fb0:


    "Miyuki golpea pelota tras pelota."


translate english a7231_ef3a48ce:


    "Su forma sigue siendo tan cautivadoramente hermosa como siempre."


translate english a7231_6ab61c32:


    xy "\"¿Hmm?\""


translate english a7231_bc213b84:


    "Oigo un pequeño miau debajo de mí."


translate english a7231_7da5a3da:


    "Miro bajo la banca y encuentro—"


translate english a7231_36962783:


    xy "\"Espera... te conozco...\""


translate english a7231_c0ba8549:



    voice "voice/a72/3100050a01.opus"
    mx "\"Uuugh... ¡Tan cerca! ¡Esta vez hice un triple!\""


translate english a7231_1c607ff6:



    voice "voice/a72/3100060a01.opus"
    mx "\"Hmm... Sé que casi lo tengo...\""


translate english a7231_ea76653d:



    voice "voice/a72/3100070a01.opus"
    mx "\"¿¡Qué demonios!? ¡Shinichi! ¿¡Ni siquiera estabas mirando!?\""


translate english a7231_fb0f3a31:


    xy "\"Oh, perdón. Me distraje con este gato al azar.\""


translate english a7231_e0fd43a3:



    voice "voice/a72/3100080a01.opus"
    mx "\"¿¡Hay un gato!?\""


translate english a7231_2cae7d8c:



    voice "voice/a72/3100090a01.opus"
    mx "\"¡Pues sí! ¡Un gatito negro!\""


translate english a7231_6edd1e9b:



    voice "voice/a72/3100100a01.opus"
    mx "\"¡Shinichi, tómale fotos! ¡Sácame primeros planos!\""


translate english a7231_8ae28e0a:


    xy "\"¿Eh? Pero mi celular... Espera, ¿dónde puse mi celular...?\""


translate english a7231_27edb0c2:



    voice "voice/a72/3100110a01.opus"
    mx "\"¡Usa el mío! ¡Toma!\""


translate english a7231_62c34fdf:


    xy "\"¡Oh, okay!\""


translate english a7231_fa17cf5d:


    "Me entrega su teléfono, y lo tomo."


translate english a7231_2f8edf98:


    "Espera, ¿qué demonios?"


translate english a7231_2929cc70:


    "Es un smartphone... ¿Qué pasó con su viejo teléfono plegable?"


translate english a7231_a292709e:



    voice "voice/a72/3100120a01.opus"
    mx "\"¡Shinichi!\""


translate english a7231_3c159382:


    xy "\"¡C-Cierto! Bien, amiguito, quédate quieto...\""


translate english a7231_d0966ef2:


    xy "\"¡Gah! ¡Oye! ¡Dije que te quedes quieto!\""


translate english a7231_a74c4ed2:


    xy "\"Demonios... No fui lo bastante rápido...\""


translate english a7231_155ca366:



    voice "voice/a72/3100140a01.opus"
    mx "\"Qué desperdicio de una oportunidad perfecta...\""


translate english a7231_de03fda3:


    xy "\"Mira, lo siento, ¿sí?\""


translate english a7231_49186791:


    "Santo cielo... Miyuki ama a los gatos DEMASIADO..."


translate english a7231_edebfbe6:


    "Suelto un suspiro y me dispongo a devolverle su teléfono—"


translate english a7231_5ae91284:


    "—pero justo entonces, mi dedo toca el botón equivocado."


translate english a7231_84932efe:


    "De la nada, una foto aparece en la pantalla."


translate english a7231_21769d5f:


    "Es esa foto que tomamos juntos."


translate english a7231_c08e6cce:


    "Nos vemos tan felices juntos—"


translate english a7231_cc074210:


    "...Espera."


translate english a7231_e2bee24c:


    "Aguanta un segundo."


translate english a7231_be168b60:


    "La azotea es nuestro pequeño lugar especial solo para los dos..."


translate english a7231_1eeed321:


    "...Entonces, ¿quién demonios nos tomó esta foto?"


translate english a7231_d20742ca:



    voice "voice/a72/3100150a01.opus"
    mx "\"...¿Shinichi?\""


translate english a7231_a4db7067:



    voice "voice/a72/3100160a01.opus"
    mx "\"¡Uah, espera! ¿¡Estás revisando mi celular!?\""


translate english a7231_35be402c:


    xy "\"¡Oh, perdón! No quería—"


translate english a7231_717e63ad:



    voice "voice/a72/3100170a01.opus"
    mx "\"¡Devuélvemelo!\""


translate english a7231_f75dd020:


    "Antes de que pueda responder, una Miyuki muy sonrojada me arrebata el teléfono."


translate english a7231_f4337073:



    voice "voice/a72/3100180a01.opus"
    mx "\"¿¡No estabas leyendo mi diario, verdad!?\""


translate english a7231_cc44bfae:


    xy "\"¿Tienes tu diario ahí?\""


translate english a7231_897624d7:


    "Ahora que lo menciona, creo recordar haber visto una carpeta llena de lo que parecían fotos de notas escritas a mano, a juzgar por las miniaturas."


translate english a7231_22b8f5f9:


    xy "\"¿Tomas fotos de las entradas de tu diario? ¿Para qué?\""


translate english a7231_9a65e9cf:


    "¿Quién se tomaría la molestia de hacer todo ese esfuerzo?"


translate english a7231_0d9f66c6:



    voice "voice/a72/3100190a01.opus"
    mx "\"¡C-Cállate! ¡Es un país libre, sabes!\""


translate english a7231_bb09b673:



    voice "voice/a72/3100200a01.opus"
    mx "\"¡Solo quiero poder recordar mis memorias contigo en cualquier momento! ¿¡Es tan malo!?\""


translate english a7231_f547017a:


    xy "\"No, para nada.\""


translate english a7231_171dffe4:


    "Miyuki siempre ha sido del tipo meticuloso."


translate english a7231_2258f347:


    "Aunque creo que se está alterando un poco de más por esto..."


translate english a7231_c14a98d1:


    "Pero, para ser justos, no fue muy bien de mi parte mirar cosas en su teléfono, para empezar."


translate english a7231_b2d68090:


    xy "\"De verdad lo siento, Miyuki. No debí mirar.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
