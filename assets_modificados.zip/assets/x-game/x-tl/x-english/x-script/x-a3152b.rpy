

translate english a3152b_76fec904:



    voice "voice/a31/52b00010a02.opus"
    aoi "\"¡Entendido!\""


translate english a3152b_6708a573:



    voice "voice/a31/52b00020a02.opus"
    aoi "\"Shinichi no quiere que le pongan los cuernos.\""


translate english a3152b_ccac2050:



    voice "voice/a31/52b00030a01.opus"
    mx "\"¿Que no qué?\""


translate english a3152b_2c5394d9:


    "El tono de Aoi es perfectamente inocente."


translate english a3152b_8cb55205:


    "Me toma por sorpresa, y no logro detenerla a tiempo."


translate english a3152b_610e15a7:



    voice "voice/a31/52b00040a02.opus"
    aoi "\"Odia la idea de que beses o tengas sexo con otros chicos. Lo pone furioso.\""


translate english a3152b_9b7b0d6c:



    voice "voice/a31/52b00050a02.opus"
    aoi "\"Así que se niega a enamorarse de ti.\""


translate english a3152b_6834c0b3:



    voice "voice/a31/52b00060a01.opus"
    mx "\"\"......¡¿Cómo TE ATREVES?!\"\""


translate english a3152b_c107b40f:



    voice "voice/a31/52b00070a01.opus"
    mx "\"...¿Shinichi?\""


translate english a3152b_716836e1:


    "Miyuki pregunta en voz baja."


translate english a3152b_fcf0c8e2:



    voice "voice/a31/52b00080a01.opus"
    mx "\"¿Es cierto? ¿Es... lo que de verdad sientes?\""


translate english a3152b_0d2dea61:



    voice "voice/a31/52b00090a01.opus"
    mx "\"¿Crees que yo... me enamoraría de otro hombre?\""


translate english a3152b_512a249e:



    voice "voice/a31/52b00100a01.opus"
    mx "\"¿De verdad lo crees?\""


translate english a3152b_12dd8fc4:


    xy "\"N-No, no es que...\""


translate english a3152b_fb8cbb5c:



    voice "voice/a31/52b00110a01.opus"
    mx "\"......¡Cómo TE ATREVES!\""


translate english a3152b_256a0bc0:



    voice "voice/a31/52b00120a01.opus"
    mx "\"¿Tienes idea de lo difícil que ha sido contenerme cuando estoy contigo?\""


translate english a3152b_777176f7:



    voice "voice/a31/52b00130a01.opus"
    mx "\"¿Puedes siquiera imaginar cómo me sentí fingiendo ser tan amiguita así?\""


translate english a3152b_f7b61ba7:


    xy "\"Mira, te estás haciendo una idea equivocada...\""


translate english a3152b_e9a8b055:



    voice "voice/a31/52b00140a01.opus"
    mx "\"¡No quiero escucharlo!\""


translate english a3152b_ede9787e:



    voice "voice/a31/52b00150a01.opus"
    mx "\"¡Nunca debí aceptar esto!\""


translate english a3152b_b8cb3677:



    voice "voice/a31/52b00160a01.opus"
    mx "\"Si hubiera sabido que iba a terminar sufriendo así...\""


translate english a3152b_408b803e:



    voice "voice/a31/52b00170a01.opus"
    mx "\"¡Nunca me habría... dejado acercarme a ti...!\""


translate english a3152b_6eba066a:



    voice "voice/a31/52b00180a01.opus"
    mx "\"¡Adiós para siempre!\""


translate english a3152b_3798636e:



    voice "voice/a31/52b00190a02.opus"
    aoi "\"¡Miyuki...!\""


translate english a3152b_da0d0ae1:


    "Aoi intenta detenerla, pero Miyuki ni siquiera voltea a mirar."


translate english a3152b_24d2686a:


    "Sé que necesito decir algo... lo que sea..."


translate english a3152b_c72a212d:


    "Pero las palabras no salen."


translate english a3152b_3b1a8346:


    "Todo lo que Aoi dijo sobre mí era verdad."


translate english a3152b_de12f081:


    "No tengo excusa."


translate english a3152b_a49abd8d:


    "Momentos después, Miyuki se desvanece en la noche."


translate english a3152b_8867426d:



    voice "voice/a31/52b00200a02.opus"
    aoi "\"¿Está... enojada...?\""


translate english a3152b_a80e5f6f:



    voice "voice/a31/52b00210a02.opus"
    aoi "\"¿Es mi culpa?\""


translate english a3152b_1c83c506:


    xy "\"No.\""


translate english a3152b_ae65a576:


    "Aoi solo estaba enunciando los hechos, nada más."


translate english a3152b_c61786cb:



    voice "voice/a31/52b00220a02.opus"
    aoi "\"¿No vas a ir tras ella?\""


translate english a3152b_dff24487:


    "Si no voy tras ella ahora, nunca tendré una segunda oportunidad."


translate english a3152b_d92917a9:


    "Lo siento en las entrañas."


translate english a3152b_b34e0420:


    "...Y sin embargo no logro decidirme a hacerlo."


translate english a3152b_5a8c46e6:



    voice "voice/a31/52b00230a02.opus"
    aoi "\"¿Tienes miedo de arruinarlo?\""


translate english a3152b_99bbe989:


    "Respiro hondo, llenando mis pulmones con el aire frío de la noche."


translate english a3152b_8488b6a1:


    xy "\"Esto estaba destinado a pasar, tarde o temprano.\""


translate english a3152b_68848644:



    voice "voice/a31/52b00240a02.opus"
    aoi "\"¿El destino...?\""


translate english a3152b_faa4758d:


    "Siempre esperé que pudiéramos quedarnos juntos."


translate english a3152b_4b6bfa45:


    "Que estos días duraran para siempre."


translate english a3152b_a77018d4:


    "Pero ya no somos niños pequeños."


translate english a3152b_b8f246c1:


    "Nuestras circunstancias son complicadas ahora. Pensamos demasiado las cosas. Caminamos con pies de plomo. Nos alteramos por nada."


translate english a3152b_0672ab9e:


    "Miyuki es la reina de toda la escuela."


translate english a3152b_e800efbf:


    "Como la luna colgada en el cielo, está en un pedestal muy fuera de mi alcance."


translate english a3152b_de9f7ee5:


    "Ni siquiera merezco contarme entre sus amigos."


translate english a3152b_09bd6ff0:



    voice "voice/a31/52b00250a02.opus"
    aoi "\"Entendido.\""


translate english a3152b_426e382b:


    "Aoi de pronto alza la mano."


translate english a3152b_ac7b2027:



    voice "voice/a31/52b00260a02.opus"
    aoi "\"Esta es la ruta del final malo.\""


translate english a3152b_f664f19b:



    voice "voice/a31/52b00270a02.opus"
    aoi "\"Tomaste la decisión equivocada.\""


translate english a3152b_6be79f5c:



    voice "voice/a31/52b00280a02.opus"
    aoi "\"Necesitas volver a cargar tu archivo de guardado.\""


translate english a3152b_2ae29a2c:


    "Ahí está de nuevo su cerebro gamer."


translate english a3152b_4ace824a:


    "Miro hacia el cielo."


translate english a3152b_38f04e7a:


    "Es asombrosamente hermoso, la forma en que la luz de las estrellas titila a través del tiempo y el espacio para llegar hasta nosotros aquí abajo, en la Tierra."


translate english a3152b_83fb0ea2:


    "La vida es como una escalera."


translate english a3152b_8d713614:


    "Solo tienes que seguir subiendo."


translate english a3152b_d8f2be1f:


    "De lo contrario, si empiezas a pensarlo demasiado, te costará dar el siguiente paso."


translate english a3152b_a13eecc0:


    "No hay caminos alternativos."


translate english a3152b_69eeb23b:


    "No tiene sentido arrepentirse de las acciones que no tomaste."


translate english a3152b_203c4466:


    "Dicen que la vida es una serie de elecciones, pero eso es una tontería inventada por los viejos y amargados."


translate english a3152b_a39bd66f:


    "El ayer conduce al hoy, y el hoy conduce al mañana."


translate english a3152b_1f3cad8d:


    "Un paso a la vez..."


translate english a3152b_73ebdf64:


    xy "\"¿No recuerdas lo que dije?\""


translate english a3152b_e7afc85f:


    xy "\"No estoy hecho para un final de cuento de hadas.\""


translate english a3152b_2d85b23a:


    "Mientras murmuro para mí mismo, miro hacia atrás."


translate english a3152b_c875a9e0:


    "Pero no hay nadie ahí de pie."


translate english a3152b_519f646c:


    "Mi voz se desvanece en la noche."


translate english a3152b_2f7478b2:


    xy "\"Jaja...\""


translate english a3152b_791a88a0:


    "Vaya, de verdad debo estar perdiendo la cabeza."


translate english a3152b_82e73e6f:


    "¿A quién le hablaba? ¿A mí mismo?"


translate english a3152b_f3666c50:


    xy "\"¿Hm...?\""


translate english a3152b_4496adbe:


    xy "\"¿Un correo?\""


translate english a3152b_9434be54:


    "Se adjunta una sola foto."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
