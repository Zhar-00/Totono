

translate english a3152b_76fec904:



    voice "voice/a31/52b00010a02.opus"
    aoi "\"Got it!\""


translate english a3152b_6708a573:



    voice "voice/a31/52b00020a02.opus"
    aoi "\"Shinichi doesn't want to be cucked.\""


translate english a3152b_ccac2050:



    voice "voice/a31/52b00030a01.opus"
    mx "\"He what?\""


translate english a3152b_2c5394d9:


    "El tono de Aoi es perfectamente inocente."


translate english a3152b_8cb55205:


    "Me toma por sorpresa, y no logro detenerla a tiempo."


translate english a3152b_610e15a7:



    voice "voice/a31/52b00040a02.opus"
    aoi "\"He hates the thought of you kissing or having sex with other guys. It makes him furious.\""


translate english a3152b_9b7b0d6c:



    voice "voice/a31/52b00050a02.opus"
    aoi "\"So he refuses to fall in love with you.\""


translate english a3152b_6834c0b3:



    voice "voice/a31/52b00060a01.opus"
    mx "\"\"......¡¿Cómo TE ATREVES?!\"\""


translate english a3152b_c107b40f:



    voice "voice/a31/52b00070a01.opus"
    mx "\"...Shinichi?\""


translate english a3152b_716836e1:


    "Miyuki pregunta en voz baja."


translate english a3152b_fcf0c8e2:



    voice "voice/a31/52b00080a01.opus"
    mx "\"Is this true? Is this... how you actually feel?\""


translate english a3152b_0d2dea61:



    voice "voice/a31/52b00090a01.opus"
    mx "\"You think I would... fall for some other man?\""


translate english a3152b_512a249e:



    voice "voice/a31/52b00100a01.opus"
    mx "\"Do you seriously believe that?\""


translate english a3152b_12dd8fc4:


    xy "\"N-No, that's not—\""


translate english a3152b_fb8cbb5c:



    voice "voice/a31/52b00110a01.opus"
    mx "\"......How DARE you!\""


translate english a3152b_256a0bc0:



    voice "voice/a31/52b00120a01.opus"
    mx "\"Do you have any idea how hard it's been to hold myself back around you?\""


translate english a3152b_777176f7:



    voice "voice/a31/52b00130a01.opus"
    mx "\"Can you even begin to imagine how I felt pretending to be all buddy-buddy like this?\""


translate english a3152b_f7b61ba7:


    xy "\"Look, you've got the wrong idea—\""


translate english a3152b_e9a8b055:



    voice "voice/a31/52b00140a01.opus"
    mx "\"I don't want to hear it!\""


translate english a3152b_ede9787e:



    voice "voice/a31/52b00150a01.opus"
    mx "\"I never should have agreed to this!\""


translate english a3152b_b8cb3677:



    voice "voice/a31/52b00160a01.opus"
    mx "\"If I'd known I'd end up suffering like this...\""


translate english a3152b_408b803e:



    voice "voice/a31/52b00170a01.opus"
    mx "\"I never would have... let myself get close to you...!\""


translate english a3152b_6eba066a:



    voice "voice/a31/52b00180a01.opus"
    mx "\"Goodbye forever!\""


translate english a3152b_3798636e:



    voice "voice/a31/52b00190a02.opus"
    aoi "\"Miyuki—!\""


translate english a3152b_da0d0ae1:


    "Aoi intenta detenerla, pero Miyuki ni siquiera voltea a mirar."


translate english a3152b_24d2686a:


    "Sé que necesito decir algo... lo que sea..."


translate english a3152b_c72a212d:


    "Pero las palabras no salen."


translate english a3152b_3b1a8346:


    "Todo lo que Aoi dijo sobre mí era verdad."


translate english a3152b_de12f081:


    "No tengo excusa."


translate english a3152b_a49abd8d:


    "Momentos después, Miyuki se desvanece en la noche."


translate english a3152b_8867426d:



    voice "voice/a31/52b00200a02.opus"
    aoi "\"Is she... mad...?\""


translate english a3152b_a80e5f6f:



    voice "voice/a31/52b00210a02.opus"
    aoi "\"Is it my fault?\""


translate english a3152b_1c83c506:


    xy "\"No.\""


translate english a3152b_ae65a576:


    "Aoi solo estaba enunciando los hechos, nada más."


translate english a3152b_c61786cb:



    voice "voice/a31/52b00220a02.opus"
    aoi "\"Aren't you gonna go after her?\""


translate english a3152b_dff24487:


    "Si no voy tras ella ahora, nunca tendré una segunda oportunidad."


translate english a3152b_d92917a9:


    "Lo siento en las entrañas."


translate english a3152b_b34e0420:


    "...Y sin embargo no logro decidirme a hacerlo."


translate english a3152b_5a8c46e6:



    voice "voice/a31/52b00230a02.opus"
    aoi "\"Are you afraid of messing up?\""


translate english a3152b_99bbe989:


    "Respiro hondo, llenando mis pulmones con el aire frío de la noche."


translate english a3152b_8488b6a1:


    xy "\"This was fated to happen, sooner or later.\""


translate english a3152b_68848644:



    voice "voice/a31/52b00240a02.opus"
    aoi "\"Fate...?\""


translate english a3152b_faa4758d:


    "Siempre esperé que pudiéramos quedarnos juntos."


translate english a3152b_4b6bfa45:


    "Que estos días duraran para siempre."


translate english a3152b_a77018d4:


    "Pero ya no somos niños pequeños."


translate english a3152b_b8f246c1:


    "Nuestras circunstancias son complicadas ahora. Pensamos demasiado las cosas. Caminamos con pies de plomo. Nos alteramos por nada."


translate english a3152b_0672ab9e:


    "Miyuki es la reina de toda la escuela."


translate english a3152b_e800efbf:


    "Como la luna colgada en el cielo, está en un pedestal muy fuera de mi alcance."


translate english a3152b_de9f7ee5:


    "Ni siquiera merezco contarme entre sus amigos."


translate english a3152b_09bd6ff0:



    voice "voice/a31/52b00250a02.opus"
    aoi "\"Got it.\""


translate english a3152b_426e382b:


    "Aoi de pronto alza la mano."


translate english a3152b_ac7b2027:



    voice "voice/a31/52b00260a02.opus"
    aoi "\"This is the bad ending route.\""


translate english a3152b_f664f19b:



    voice "voice/a31/52b00270a02.opus"
    aoi "\"You made the wrong choice.\""


translate english a3152b_6be79f5c:



    voice "voice/a31/52b00280a02.opus"
    aoi "\"You need to reload your save file.\""


translate english a3152b_2ae29a2c:


    "Ahí está de nuevo su cerebro gamer."


translate english a3152b_4ace824a:


    "Miro hacia el cielo."


translate english a3152b_38f04e7a:


    "Es asombrosamente hermoso, la forma en que la luz de las estrellas titila a través del tiempo y el espacio para llegar hasta nosotros aquí abajo, en la Tierra."


translate english a3152b_83fb0ea2:


    "La vida es como una escalera."


translate english a3152b_8d713614:


    "Solo tienes que seguir subiendo."


translate english a3152b_d8f2be1f:


    "De lo contrario, si empiezas a pensarlo demasiado, te costará dar el siguiente paso."


translate english a3152b_a13eecc0:


    "No hay caminos alternativos."


translate english a3152b_69eeb23b:


    "No tiene sentido arrepentirse de las acciones que no tomaste."


translate english a3152b_203c4466:


    "Dicen que la vida es una serie de elecciones, pero eso es una tontería inventada por los viejos y amargados."


translate english a3152b_a39bd66f:


    "El ayer conduce al hoy, y el hoy conduce al mañana."


translate english a3152b_1f3cad8d:


    "Un paso a la vez..."


translate english a3152b_73ebdf64:


    xy "\"Don't you remember what I said?\""


translate english a3152b_e7afc85f:


    xy "\"I'm not cut out for a fairytale ending.\""


translate english a3152b_2d85b23a:


    "Mientras murmuro para mí mismo, miro hacia atrás."


translate english a3152b_c875a9e0:


    "Pero no hay nadie ahí de pie."


translate english a3152b_519f646c:


    "Mi voz se desvanece en la noche."


translate english a3152b_2f7478b2:


    xy "\"Haha...\""


translate english a3152b_791a88a0:


    "Vaya, de verdad debo estar perdiendo la cabeza."


translate english a3152b_82e73e6f:


    "¿A quién le hablaba? ¿A mí mismo?"


translate english a3152b_f3666c50:


    xy "\"Hm...?\""


translate english a3152b_4496adbe:


    xy "\"An email?\""


translate english a3152b_9434be54:


    "Se adjunta una sola foto."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
