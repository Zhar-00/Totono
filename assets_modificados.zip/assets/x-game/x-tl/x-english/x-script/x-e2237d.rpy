

translate english e2237d_26986a85:


    "Mi conexión con Miyuki no necesita palabras."


translate english e2237d_1388823a:


    "Mientras el pensamiento me cruza la mente, pierdo el control por completo."


translate english e2237d_58dc45b3:


    "De repente, ya no me importan los pequeños detalles como dónde estamos o qué hacemos."


translate english e2237d_03a9829b:



    voice "voice/e22/37d00010a01.opus"
    mx "\"¡¡¡Haahh!!! ¡Aah! ¡Aaahh! ¡Aah! ¡Aaahh! ¡Ay, joder—ay, joder—nnngghh! ¡Nnn! ¡Nnng!!!\""


translate english e2237d_bdfb252b:



    voice "voice/e22/37d00020a01.opus"
    mx "\"¡Ay, Dios! Sllrpp, shhlpp... nnn... mmnn! ¡Nnhaah! ¡Shinichi, me vengo otra vez—!\""


translate english e2237d_9ccd768e:



    voice "voice/e22/37d00030a01.opus"
    mx "\"¡Me vengo! ¡Por favor! ¡AAAAAAHH! ¡Vente conmigo—vente conmigo—nnng—!\""


translate english e2237d_c0c9c4d1:



    voice "voice/e22/37d00040a01.opus"
    mx "\"¡Aah! ¡Me vengo! ¡Me vengo! ¡Aah, aah, aah! ¡NnhaaaaaaaAAAAAAAAAAAAAAAAAAHHHH!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
