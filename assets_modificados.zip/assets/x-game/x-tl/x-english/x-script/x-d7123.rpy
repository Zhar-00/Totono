

translate english d7123_2d27d3dd:


    "Había confinado temporalmente a Eru al segundo piso para que Miyuki no tuviera un ataque de alergia."


translate english d7123_a3fe4800:


    "Lo levanto con suavidad."


translate english d7123_545d6bca:


    xy "\"This is where we say goodbye.\""


translate english d7123_ac1e26a6:


    "Sorprendentemente, Eru no emite sonido alguno."


translate english d7123_65711612:


    xy "\"Aoi.\""


translate english d7123_13476ecc:


    xy "\"You'll look after him, won't you?\""


translate english d7123_fae8f42e:



    voice "voice/d71/2300010a02.opus"
    aoi "\"Yeah.\""


translate english d7123_786a366b:


    "Aoi asiente como si estuviera preparada para esto."


translate english d7123_71239b07:


    "Dejo a Eru en el suelo."


translate english d7123_61f25ab3:


    "The \"transceiver cat\"me mira de vuelta, solo una vez."



translate english d7123_bd7a3d50:


    "Desvío la mirada."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
