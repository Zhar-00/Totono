

translate english c7111_992d8ccf:



    voice "voice/c71/1100010a02.opus"
    aoi "\"Aoi es...\""


translate english c7111_8ebdea92:



    voice "voice/c71/1100020a02.opus"
    aoi "\"...una ruta romántica.\""


translate english c7111_f8da82c7:



    voice "voice/c71/1100030a02.opus"
    aoi "\"Solo un personaje 2D.\""


translate english c7111_a980fe5e:



    voice "voice/c71/1100040a02.opus"
    aoi "\"Sin alma, sin sustancia, sin familia, sin amigos, sin cumpleaños...\""


translate english c7111_86d2e4ac:



    voice "voice/c71/1100050a02.opus"
    aoi "\"Nada.\""


translate english c7111_bdb6ea20:



    voice "voice/c71/1100060a02.opus"
    aoi "\"Pero entonces llegaste tú.\""


translate english c7111_af602cee:



    voice "voice/c71/1100070a02.opus"
    aoi "\"Y me diste todo.\""


translate english c7111_58ba655c:



    voice "voice/c71/1100080a02.opus"
    aoi "\"Gracias, Shinichi.\""


translate english c7111_589874e3:


    "La venda cae de mis ojos."


translate english c7111_faf2a94b:


    "Frente a mí hay un pastel iluminado por velas."


translate english c7111_22dd7ae9:



    voice "voice/c71/1100100a01ex.opus"
    bm "\"Feliz cumpleaños a ti...\""


translate english c7111_2eb6b420:



    voice "voice/c71/1100130a01ex.opus"
    bm "\"Feliz cumpleaños a tiii...\""


translate english c7111_5cb339aa:



    voice "voice/c71/1100160a01ex.opus"
    bm "\"Feliz cumpleaños, querido Shinichiii...\""


translate english c7111_be5c2b12:



    voice "voice/c71/1100190a01ex.opus"
    bm "\"¡Feliz cumpleaños a tiii!\""


translate english c7111_aec6234e:


    xy "\"¡Pfffoooooooo!\""


translate english c7111_01_6af5add4:



    voice "voice/c71/1100210b01.opus"
    xtl "\"¡Feliz cumpleaños, Shinichi, mi hermano! ¡Has dado otro paso hacia la hombría de verdad!\""


translate english c7111_01_2c10865f:



    voice "voice/c71/1100220b01.opus"
    xtl "\"¿Cuántos años tienes ya? Se me olvida.\""


translate english c7111_01_c75e93f4:


    xy "\"Los mismos que tú, genio.\""


translate english c7111_01_657e6c3c:



    voice "voice/c71/1100230a02.opus"
    aoi "\"Por ley tienes que tener al menos 18.\""


translate english c7111_01_b8c96dc7:


    xy "\"¿A qué te refieres con por ley?\""


translate english c7111_01_76e97e06:



    voice "voice/c71/1100240a01.opus"
    mx "\"¡Bueno, basta de payasadas!\""


translate english c7111_01_faef43da:



    voice "voice/c71/1100250a01.opus"
    mx "\"Feliz cumpleaños, Shinichi.\""


translate english c7111_01_365d80d8:


    xy "\"¡Uoh! ¡Mira el tamaño de esa cosa!\""


translate english c7111_01_db1e847d:


    "Miyuki me entrega un enorme ramo de flores."


translate english c7111_01_fa7ed41b:


    "Puedo oler los lirios desde aquí."


translate english c7111_01_80a5a1b1:


    "Ha estado preparando varias cosas para mí, pero no me había dado cuenta de que había preparado un regalo tan atento."


translate english c7111_01_022877ee:


    "Esto va camino de ser una fiesta de cumpleaños de mil demonios..."


translate english c7111_01_c7a2fab9:


    "Luchando con mis emociones, me obligo a hablar."


translate english c7111_01_5fd4ab8b:


    xy "\"Gracias, todos.\""


translate english c7111_01_4479d4cd:



    voice "voice/c71/1100260a01.opus"
    mx "\"¡Ah, no nos des las gracias todavía!\""


translate english c7111_01_3b4d78e1:



    voice "voice/c71/1100270a01.opus"
    mx "\"¡Y ahora, es hora de tus regalos!\""


translate english c7111_01_39ecc509:



    voice "voice/c71/1100280a01.opus"
    mx "\"¿Quién debería ir primero...? ¿Qué tal tú, Aoi?\""


translate english c7111_01_c5368c7b:



    voice "voice/c71/1100290a02.opus"
    aoi "\"¡Entendido!\""


translate english c7111_01_1154d6d2:


    "La mano de Aoi se dispara al aire. Luego sale corriendo al pasillo."


translate english c7111_01_a881a614:



    voice "voice/c71/1100300a02.opus"
    aoi "\"¡Hnn...!\""


translate english c7111_01_a9598eda:


    "Vuelve, arrastrando una caja grande y pesada."


translate english c7111_01_69b16c13:


    "Aunque tira con todas sus fuerzas, la caja apenas avanza unos centímetros."


translate english c7111_01_c8fea615:



    voice "voice/c71/1100310a02.opus"
    aoi "\"Bup bup... bup bup bup bup bup...\""


translate english c7111_01_bc1ab039:



    voice "voice/c71/1100320b01.opus"
    xtl "\"Ehh... ¿Tal vez debería a—?\""


translate english c7111_01_aaa4de39:



    voice "voice/c71/1100330a02.opus"
    aoi "\"No necesito ayuda...\""


translate english c7111_01_281c8e2c:



    voice "voice/c71/1100340a02.opus"
    aoi "\"Este es...\""


translate english c7111_01_c0eb33ef:



    voice "voice/c71/1100350a02.opus"
    aoi "\"...mi regalo...\""


translate english c7111_01_d66bb447:



    voice "voice/c71/1100360a02.opus"
    aoi "\"...para...\""


translate english c7111_01_d18b15e7:



    voice "voice/c71/1100370a02.opus"
    aoi "\"...Shi... ¡aaah!\""


translate english c7111_01_21b6ec03:



    voice "voice/c71/1100380a02.opus"
    aoi "\"Bup bup bup...\""


translate english c7111_01_3da9991f:



    voice "voice/c71/1100390b01.opus"
    xtl "\"Ups...\""


translate english c7111_01_8aeecfe3:



    voice "voice/c71/1100400a01.opus"
    mx "\"¿Aoi, estás bien?\""


translate english c7111_01_5930cf24:



    voice "voice/c71/1100410a02.opus"
    aoi "\"Aoi la cagó...\""


translate english c7111_01_5189b392:


    "La caja se abre, derramando su contenido."


translate english c7111_01_6959592c:


    xy "\"¿Yabaley's...?\""


translate english c7111_01_160f40b2:



    voice "voice/c71/1100420a02.opus"
    aoi "\"¡Es saludable!\""


translate english c7111_01_63a518bb:



    voice "voice/c71/1100430b01.opus"
    xtl "\"¿Ese es tu regalo de cumpleaños?\""


translate english c7111_01_165c8f2a:



    voice "voice/c71/1100440a02.opus"
    aoi "\"Bup bup...\""


translate english c7111_01_f8fc35b3:


    "Aoi entra a la cocina y abre el refrigerador."


translate english c7111_01_a4c1d01a:



    voice "voice/c71/1100450a02.opus"
    aoi "\"¡Es el paraíso del tomate!\""


translate english c7111_01_ac2d4566:



    voice "voice/c71/1100460b01.opus"
    xtl "\"Clásico.\""


translate english c7111_01_a8391d4e:



    voice "voice/c71/1100470a01.opus"
    mx "\"...¿Qué hiciste con todas las cosas que había ahí?\""


translate english c7111_01_badebb34:



    voice "voice/c71/1100480a02.opus"
    aoi "\"Las tiré.\""


translate english c7111_01_280fa8ce:



    voice "voice/c71/1100490a01.opus"
    mx "\"¿¡Perdón!?\""


translate english c7111_01_00053f7c:



    voice "voice/c71/1100500a02.opus"
    aoi "\"¡Esto es lo que a Aoi le gusta!\""


translate english c7111_01_7e069992:



    voice "voice/c71/1100510a02.opus"
    aoi "\"¡Así que ahora Aoi se lo da a Shinichi!\""


translate english c7111_01_a625c96f:



    voice "voice/c71/1100520a02.opus"
    aoi "\"¿Te... gusta...?\""


translate english c7111_01_cab84f3c:


    xy "\"Sí. Gracias.\""


translate english c7111_01_e907b90c:


    xy "\"Parece que de aquí en adelante voy a recibir un montón de vitaminas.\""


translate english c7111_01_5bb13ec3:



    voice "voice/c71/1100530a01.opus"
    mx "\"...Vas a enfermarte tomando todo eso.\""


translate english c7111_01_ff4ef4f4:



    voice "voice/c71/1100540a01.opus"
    mx "\"Supongo que será mejor que siga haciéndote almuerzos.\""


translate english c7111_01_7511aded:



    voice "voice/c71/1100550b01.opus"
    xtl "\"¿¡Almuerzos caseros de tu amiga de la infancia!?\""


translate english c7111_01_e4c2b077:



    voice "voice/c71/1100560b01.opus"
    xtl "\"¡Bastardo! ¡Los has estado comiendo, ¿verdad!? ¡¿Verdad!?\""


translate english c7111_01_eac08f91:



    voice "voice/c71/1100570a02.opus"
    aoi "\"Yo también.\""


translate english c7111_01_0276ef20:



    voice "voice/c71/1100580b01.opus"
    xtl "\"¡¿Jajajajaja?! ¡¿Recibes LOS DOS en el almuerzo?!\""


translate english c7111_01_b176edf2:



    voice "voice/c71/1100590b01.opus"
    xtl "\"¡Qué envidia! ¡Qué popular eres! ¡Cuánta envidia! ¡Qué sueño! ¡Qué normie!\""


translate english c7111_01_874d682b:



    voice "voice/c71/1100600b01.opus"
    xtl "\"¡¡¡M U E R E !!!\""


translate english c7111_01_745ff181:



    voice "voice/c71/1100610a01.opus"
    mx "\"Aguanta, Yuutarou-kun.\""


translate english c7111_01_ea39fd3d:



    voice "voice/c71/1100620b01.opus"
    xtl "\"¡S-Sone-san me compadece...!\""


translate english c7111_01_11a2a5ce:



    voice "voice/c71/1100630b01.opus"
    xtl "\"Qué extraño... No lo entiendo... ¿¡Por qué su compasión absoluta hace que mis sueños crezcan tanto...!?\""


translate english c7111_01_53222268:


    "Parece feliz..."


translate english c7111_01_bcffb082:


    "Estoy casi un poco impresionado."


translate english c7111_01_fb0e7faf:



    voice "voice/c71/1100650a01.opus"
    mx "\"Bueno, ya basta de tonterías.\""


translate english c7111_01_5e7fcda7:


    "Miyuki gira en redondo, con su largo cabello ondulando tras ella."


translate english c7111_01_5b7e652e:



    voice "voice/c71/1100660a01.opus"
    mx "\"Vamos al grano.\""


translate english c7111_01_77778228:


    "—A lo que vinimos."


translate english c7111_01_32b960b2:


    "Esa es la frase clave."


translate english c7111_01_ef804af1:


    "Yuutarou se pone tenso."


translate english c7111_01_cb6bdf45:


    "Intento mantener la cara seria."


translate english c7111_01_ee2fce02:



    voice "voice/c71/1100670b01.opus"
    xtl "\"Uhhh... Supongo que es mi turno, ¿no?\""


translate english c7111_01_9f8947b2:



    voice "voice/c71/1100680b01.opus"
    xtl "\"Ja... ja...\""


translate english c7111_01_bd2bc112:



    voice "voice/c71/1100690b01.opus"
    xtl "\"¡Feliz cumpleaños!\""


translate english c7111_01_89786a67:


    "Balbuceando, Yuutarou extiende su regalo."


translate english c7111_01_cfa0a9c4:


    xy "\"¿Un DVD?\""


translate english c7111_01_ca79eaae:



    voice "voice/c71/1100700b01.opus"
    xtl "\"¡Síp! Es una edición súper especial ultra rara.\""


translate english c7111_01_a6538779:



    voice "voice/c71/1100710a02.opus"
    aoi "\"Más vale que no sea sin censura.\""


translate english c7111_01_0e334c95:



    voice "voice/c71/1100720a02.opus"
    aoi "\"Podríamos meternos en problemas con la policía.\""


translate english c7111_01_572e8b9d:



    voice "voice/c71/1100730b01.opus"
    xtl "\"Jajajajajaja...\""


translate english c7111_01_e4f9216b:


    "Yuutarou ríe con torpeza."


translate english c7111_01_ef5542e7:


    "Aunque Aoi no parece darse cuenta."


translate english c7111_01_938b7820:


    xy "\"¿Podemos ver qué tiene?\""


translate english c7111_01_9c3fc7c1:



    voice "voice/c71/1100740b01.opus"
    xtl "\"¡Ah, claro! Solo... lo pondré en el reproductor para ti.\""


translate english c7111_01_3e44bd19:



    voice "voice/c71/1100750b01.opus"
    xtl "\"Podemos verlo todos mientras nos comemos el pastel.\""


translate english c7111_01_a489f5f4:



    voice "voice/c71/1100760a02.opus"
    aoi "\"¡Entendido!\""


translate english c7111_01_82c8c432:


    "Aoi levanta la mano hacia el techo."


translate english c7111_01_8779ca90:



    voice "voice/c71/1100770a02.opus"
    aoi "\"¿Y el regalo de Miyuki?\""


translate english c7111_01_c41a5884:



    voice "voice/c71/1100780a01.opus"
    mx "\"¿Eh? ¿Yo?\""


translate english c7111_01_34200d5c:



    voice "voice/c71/1100790a01.opus"
    mx "\"Mmm, veamos... Creo que guardaré el mío para el final.\""


translate english c7111_01_f5f67f73:



    voice "voice/c71/1100800a02.opus"
    aoi "\"¿Para el final...?\""


translate english c7111_01_10ca66be:


    "Justo entonces, suena el timbre."


translate english c7111_01_4f31193a:



    voice "voice/c71/1100810a02.opus"
    aoi "\"¿Bup bup?\""


translate english c7111_01_d81a175a:



    voice "voice/c71/1100820b01.opus"
    xtl "\"Ah, ya llegó. Voy por él.\""


translate english c7111_01_274407be:


    "Yuutarou sale corriendo de la sala."


translate english c7111_01_57d3bbe9:



    voice "voice/c71/1100830a02.opus"
    aoi "\"¿Quién es?\""


translate english c7111_01_bd8131a5:


    xy "\"Ah, ¿no te dijimos?\""


translate english c7111_01_feab549b:


    xy "\"Invitamos a una persona más.\""


translate english c7111_01_86f2a4bd:



    voice "voice/c71/1100840a02.opus"
    aoi "\"¿Otro invitado a la fiesta?\""


translate english c7111_01_7e71ddbe:


    xy "\"¿Sabes que Yuutarou dijo que se consiguió novia?\""


translate english c7111_01_36c2a0ea:



    voice "voice/c71/1100850a02.opus"
    aoi "\"¿Una novia imaginaria?\""


translate english c7111_01_4f8ea495:


    xy "\"O eso pensé, en todo caso. Así que le dije que la invitara, y—\""


translate english c7111_01_9e5a0fe5:



    voice "voice/c71/1100860a02.opus"
    aoi "\"¿Es real?\""


translate english c7111_01_af41fcb4:



    voice "voice/c71/1100870b03.opus"
    c "\"Perdón por la demora...\""


translate english c7111_01_fedb0f72:



    voice "voice/c71/1100880a02.opus"
    aoi "\"¿Eh?\""


translate english c7111_01_9049925d:


    "Aoi se queda helada, pero a mí no me sorprende."


translate english c7111_01_9a1afea1:


    "Después de todo, probablemente reconoce esa voz."


translate english c7111_01_3785587c:



    voice "voice/c71/1100890b01.opus"
    xtl "\"¡Ejem! ¡Gracias a todos por esperar!\""


translate english c7111_01_9c03d330:



    voice "voice/c71/1100900b01.opus"
    xtl "\"¡Permítanme presentarles a mi novia, Haru!\""


translate english c7111_01_b0db1d63:



    voice "voice/c71/1100910b03.opus"
    c "\"Eh... ehhh... emm...\""


translate english c7111_01_41201a0d:



    voice "voice/c71/1100920b03.opus"
    c "\"M-Mucho gusto... todos...\""


translate english c7111_01_219ca226:



    voice "voice/c71/1100930b03.opus"
    c "\"Me llamo... Haru... Gracias por recibirme...\""


translate english c7111_01_1a5fe434:


    "Haru (Ryuujirou) susurra débilmente."


translate english c7111_01_76c39486:



    voice "voice/c71/1100940b01.opus"
    xtl "\"Jajajajajaja...\""


translate english c7111_01_b56c29e7:


    "El hermano de Yuutarou—"


translate english c7111_01_d0ba9147:



    voice "voice/c71/1100950a01.opus"
    mx "\"......\""


translate english c7111_01_786df749:


    "El compañero actor de Miyuki—"


translate english c7111_01_2c0a3cce:



    voice "voice/c71/1100960a02.opus"
    aoi "\"......\""


translate english c7111_01_882e11cd:


    "Y el amante secreto de Aoi."


translate english c7111_01_9d6b4ae3:



    voice "voice/c71/1100970a02.opus"
    aoi "\"Bup bup... bup...\""


translate english c7111_01_d194a4c4:


    "La tensión flota en el aire."


translate english c7111_01_67dff208:


    xy "\"¿Hmm?\""


translate english c7111_01_f68000ef:


    xy "\"Aoi, ¿la conoces?\""


translate english c7111_01_927e7ca0:



    voice "voice/c71/1100980a02.opus"
    aoi "\"¡No!\""


translate english c7111_01_0b9d3519:


    xy "\"¿Eh? Qué raro...\""


translate english c7111_01_5293fed5:


    xy "\"¿No era ella la que te ayudó a escoger la leche de Eru en la tienda de la esquina?\""


translate english c7111_01_47cc8e53:



    voice "voice/c71/1100990a02.opus"
    aoi "\"¿Bup bup...?\""


translate english c7111_01_e023adc4:



    voice "voice/c71/1101000a02.opus"
    aoi "\"Oh... Sí, pero eso es todo—\""


translate english c7111_01_185e7f8d:



    voice "voice/c71/1101010a01.opus"
    mx "\"¡Ya, ya! ¡No nos fijemos en los detalles!\""


translate english c7111_01_ec4104ba:



    voice "voice/c71/1101020a01.opus"
    mx "\"¿Por qué no comemos todos un poco de pastel?\""


translate english c7111_01_cf3e7841:


    "Los cinco nos sentamos alrededor de la mesa y comemos nuestro pastel."


translate english c7111_01_5606d7e7:


    "Aoi termina sentada junto a Ryuujirou."


translate english c7111_01_fb97b14d:



    voice "voice/c71/1101030a02.opus"
    aoi "\"......\""


translate english c7111_01_bd2dc399:



    voice "voice/c71/1101040b03.opus"
    c "\"......\""


translate english c7111_01_3bd87e50:


    "Nadie dice una palabra."


translate english c7111_01_fdc7cdba:


    "Poco a poco, el pastel desaparece."


translate english c7111_01_9aa11c3c:


    "Aoi aún parece presa del pánico."


translate english c7111_01_a0ad52d0:


    "No deja de mirar por toda la habitación."


translate english c7111_01_1564807d:


    "Apenas puedo contener un arrebato de alegría."


translate english c7111_01_e0a136a6:



    voice "voice/c71/1101050b03.opus"
    c "\"¡P-Pero, este...!\""


translate english c7111_01_56a9ccb9:



    voice "voice/c71/1101060b03.opus"
    c "\"¡Feliz... cumpleaños...!\""


translate english c7111_01_e2073b0e:


    "Incapaz de soportar la tensión en la habitación, Ryuujirou se levanta de su silla."


translate english c7111_01_2276ca02:


    "Le habíamos dicho que ensayara esta línea de antemano—pero su voz tiembla tanto que me pregunto cómo logró entrar al club de teatro."


translate english c7111_01_7be47f4a:



    voice "voice/c71/1101070b03.opus"
    c "\"Aquí tienes... mi regalo.\""


translate english c7111_01_6bd7d109:


    "Ryuujirou me entrega una caja pequeña."


translate english c7111_01_bc6a0b56:


    xy "\"Mmmm...\""


translate english c7111_01_e1da154f:


    "La tomo sin dar las gracias."


translate english c7111_01_2e42b78c:


    "Luego la abro lentamente, para hacerla sudar de verdad."


translate english c7111_01_4daabbdb:


    xy "\"¡Uoh!\""


translate english c7111_01_36e9b90e:


    xy "\"¡Esta es la horquilla que le di a Aoi!\""


translate english c7111_01_88aaae67:



    voice "voice/c71/1101080a02.opus"
    aoi "\"¿¡Bup bup...!?\""


translate english c7111_01_4371dfa8:


    "Aoi empieza a hurgar en su bolsillo."


translate english c7111_01_eb539b50:



    voice "voice/c71/1101090a02.opus"
    aoi "\"Pero la que me diste está justo—\""


translate english c7111_01_dc698e90:



    voice "voice/c71/1101100b03.opus"
    c "\"La dejaste caer... en mi cuarto.\""


translate english c7111_01_e33beeff:



    voice "voice/c71/1101110a02.opus"
    aoi "\"—?!\""


translate english c7111_01_89c75976:


    "La expresión de Aoi se tensa."


translate english c7111_01_e6da6c18:


    "Sus ojos están muy abiertos, como si alguien acabara de empujarla por un acantilado."


translate english c7111_01_472b4eb2:


    "...Esta es exactamente la cara que quería ver en su rostro."


translate english c7111_01_feffe5e5:


    "Pero apenas estamos empezando."


translate english c7111_01_429e6c34:


    xy "\"Qué raro. Creí que era hecha a mano y única en su tipo.\""


translate english c7111_01_1c8000d9:



    voice "voice/c71/1101120a02.opus"
    aoi "\"¡No! ¡Aoi jamás la dejaría caer!\""


translate english c7111_01_e7d78f4f:



    voice "voice/c71/1101130a02.opus"
    aoi "\"¡Es un regalo tuyo! ¡Aoi siempre la cuida muy bien!\""


translate english c7111_01_969862f2:



    voice "voice/c71/1101140a01.opus"
    mx "\"Estás mintiendo, ¿verdad?\""


translate english c7111_01_43d8df5d:



    voice "voice/c71/1101150a02.opus"
    aoi "\"¿¡Miyuki!? Aoi nunca—\""


translate english c7111_01_7b75fd10:



    voice "voice/c71/1101160a01.opus"
    mx "\"Hablé con la empleada de Catnip.\""


translate english c7111_01_c39f1bf4:



    voice "voice/c71/1101170a01.opus"
    mx "\"El día de la presentación, entraste a la tienda, ardiendo de fiebre, y volviste a comprar la misma horquilla.\""


translate english c7111_01_9cba9158:



    voice "voice/c71/1101180a01.opus"
    mx "\"La perdiste, así que necesitabas un reemplazo. ¿No es así?\""


translate english c7111_01_a0247aee:



    voice "voice/c71/1101190a02.opus"
    aoi "\"¡Aoi nunca hizo eso!\""


translate english c7111_01_b222d57d:



    voice "voice/c71/1101200a01.opus"
    mx "\"Ah, y la empleada también me dijo...\""


translate english c7111_01_bd50a14c:



    voice "voice/c71/1101210a01.opus"
    mx "\"Vas mucho allá con Haru-chan, ¿verdad?\""


translate english c7111_01_cbd37446:



    voice "voice/c71/1101230a02.opus"
    aoi "\"Pues... ¡pero...!\""


translate english c7111_01_c6503b30:



    voice "voice/c71/1101240a01.opus"
    mx "\"Ahora es tu oportunidad de disculparte.\""


translate english c7111_01_49814540:


    "Miyuki's using her \"friendly advice\"tono de voz."



translate english c7111_01_53256943:



    voice "voice/c71/1101250a01.opus"
    mx "\"Si confiesas, estoy segura de que Shinichi te perdonará.\""


translate english c7111_01_55ee58dc:



    voice "voice/c71/1101260a02.opus"
    aoi "\"Pero... Aoi no está mintiendo...\""


translate english c7111_01_6132d793:



    voice "voice/c71/1101270a02.opus"
    aoi "\"Este es mi tesoro...\""


translate english c7111_01_b150c065:



    voice "voice/c71/1101280a02.opus"
    aoi "\"Aoi jamás lo perdería...\""


translate english c7111_01_4d3cad7b:



    voice "voice/c71/1101290a01.opus"
    mx "\"¿Entonces al menos admites que estuviste allí?\""


translate english c7111_01_700a5a5d:



    voice "voice/c71/1101300a02.opus"
    aoi "\"Bup... bup...\""


translate english c7111_01_c84c18cb:



    voice "voice/c71/1101310a01.opus"
    mx "\"Entraste al cuarto de Haru-chan, ¿sí?\""


translate english c7111_01_f169fbfa:



    voice "voice/c71/1101320a02.opus"
    aoi "\"¿El cuarto... de Haru-chan...? Pues...\""


translate english c7111_01_adcf7101:


    "Su voz es apenas un susurro."


translate english c7111_01_46219f34:


    "Sus labios tiemblan, y se queda callada."


translate english c7111_01_77a1adce:


    xy "\"Yuutarou.\""


translate english c7111_01_13753754:



    voice "voice/c71/1101330b01.opus"
    xtl "\"E-En eso.\""


translate english c7111_01_999dfa7a:


    "Yuutarou's \"gift\"está en la bandeja del disco."



translate english c7111_01_0cda95dc:


    "Presiona el botón de Reproducir, y la pantalla se ilumina con—"


translate english c7111_01_dd723e72:



    voice "voice/c71/1101340a02.opus"
    aoi "\"¿¡Bup bup!?\""


translate english c7111_01_99851e75:


    "—imágenes de la cámara de seguridad de la tienda de la esquina."


translate english c7111_01_86258342:


    "La tienda está tenuemente iluminada y vacía de otros clientes."


translate english c7111_01_db05d1ed:


    "Detrás del mostrador, Ryuujirou y Aoi comparten un tierno abrazo."


translate english c7111_01_f4c0d22b:



    voice "voice/c71/1101350a02.opus"
    aoi "\"Esto... no puede estar pasando...\""


translate english c7111_01_de809d4a:


    "Luego la cámara hace zoom, y las imágenes se distorsionan más."


translate english c7111_01_117bd20f:


    "Muestra a Ryuujirou y Aoi besándose."


translate english c7111_01_b1320a0d:


    "Una y otra vez..."


translate english c7111_01_cb0c852d:



    voice "voice/c71/1101360b01.opus"
    xtl "\"Encontré esto en las cámaras de seguridad de la tienda.\""


translate english c7111_01_58093fa2:


    xy "\"Dime, Aoi.\""


translate english c7111_01_b5f75d8c:


    "Al parecer soy todo un monstruo celoso."


translate english c7111_01_c3e9393d:


    "Mientras lucho contra las ganas de destrozar la televisión..."


translate english c7111_01_d1f01bb3:


    "Me obligo a hablar con calma."


translate english c7111_01_e1f6ba35:


    xy "\"Somos novios, ¿no?\""


translate english c7111_01_2558865c:


    xy "\"Entonces, ¿por qué lo besaste?\""


translate english c7111_01_7cd5faf6:



    voice "voice/c71/1101370a02.opus"
    aoi "\"Bup bup...\""


translate english c7111_01_04b02ec0:


    xy "\"Eres mi novia, ¿no?\""


translate english c7111_01_465675ba:


    xy "\"Me dijiste que creyera en ti, ¿no es así?\""


translate english c7111_01_aa433987:


    xy "\"¿Y lloraste y todo?\""


translate english c7111_01_10e563fa:


    xy "\"¿Y qué era eso? ¿Solo una actuación?\""


translate english c7111_01_2ef98a63:



    voice "voice/c71/1101380a02.opus"
    aoi "\"Shinichi...\""


translate english c7111_01_dc603459:


    xy "\"Lo intenté. Lo intenté con todas mis fuerzas.\""


translate english c7111_01_1441b30f:


    xy "\"Intenté aceptarte. Intenté confiar en ti.\""


translate english c7111_01_eb5924fc:


    xy "\"¿Pero qué sentías por mí?\""


translate english c7111_01_ef8349d7:


    xy "\"¿Qué tenías en la cabeza cuando lo besabas?\""


translate english c7111_01_0983de7b:



    voice "voice/c71/1101390a02.opus"
    aoi "\"Aoi te ama...\""


translate english c7111_01_4dbbba5c:



    voice "voice/c71/1101400a02.opus"
    aoi "\"Aoi te ama tanto... Por eso—\""


translate english c7111_01_ea9089fd:


    xy "\"¡MALDITA SEA!\""


translate english c7111_01_cb9227b3:


    "Ya no lo soporto."


translate english c7111_01_8d822c14:


    "Se lo lanzo."


translate english c7111_01_1776fff7:



    voice "voice/c71/1101410a02.opus"
    aoi "\"¡Eso es...!\""


translate english c7111_01_1f290c43:


    "Ella no intenta esquivarlo."


translate english c7111_01_d61c8f3c:


    "Le da en la cara y cae a sus pies."


translate english c7111_01_ecac674b:


    xy "\"¡Qué homenaje tan increíble! ¡Estoy impresionado!\""


translate english c7111_01_8a2fe4aa:


    xy "\"¿¡Me amas tanto que te acuestas con otros tipos!?\""


translate english c7111_01_6606869f:


    "...Es el condón que encontramos en el bote de basura."


translate english c7111_01_cf8c62d9:


    xy "\"Lo encontré el día de la obra, cuando nos colamos en el cuarto de Ryuujirou.\""


translate english c7111_01_5d62679d:



    voice "voice/c71/1101420a02.opus"
    aoi "\"¿Tú sabías...?\""


translate english c7111_01_c8f7b517:


    xy "\"Todo.\""


translate english c7111_01_35768402:


    xy "\"Sabía que Haru era el hermano de Yuutarou.\""


translate english c7111_01_aa0c825c:


    xy "\"Sabía que estuvieron solos juntos en ese departamento.\""


translate english c7111_01_6020ee8a:


    xy "\"Pero me hice el tonto.\""


translate english c7111_01_d3cfac19:


    xy "\"Todo este tiempo actué como si todo estuviera bien.\""


translate english c7111_01_f60a063d:


    xy "\"Me aguanté los sentimientos e hice el papel de novio feliz.\""


translate english c7111_01_e7dac985:


    xy "\"Estar cerca de ti me enfermaba... vomité decenas de veces...\""


translate english c7111_01_0b346fe0:


    xy "\"Me estremecía cada vez que pedías tener sexo.\""


translate english c7111_01_e75ad978:


    xy "\"Pero lo soporté.\""


translate english c7111_01_2d8b049a:


    xy "\"Me dije que tenía que apretar los dientes y aguantar.\""


translate english c7111_01_edc39e91:


    xy "\"¡Todo para poder restregártelo en la cara aquí y ahora!\""


translate english c7111_01_f86962b0:


    "Mi amor por Aoi se ha ido."


translate english c7111_01_f5ccdf9b:


    "Mi sentido racional se ha ido."


translate english c7111_01_5b627b08:


    "Todo lo que queda es odio."


translate english c7111_01_9b915487:


    "Y sed de venganza."


translate english c7111_01_e81d4ed6:


    "O eso creía."


translate english c7111_01_f69ae731:


    "Y sin embargo, aún puedo sentir una ira ardiente en algún lugar muy dentro de mí."


translate english c7111_01_5b0c0a72:


    xy "\"Entonces, ¿qué estabas haciendo?\""


translate english c7111_01_ad70b622:


    xy "\"Cancelaste nuestra cita para estar a solas con otro tipo, ¿no? ¡Así que qué carajo estabas haciendo!?\""


translate english c7111_01_ed88878b:


    xy "\"Quería creer en ti... de verdad que sí...\""


translate english c7111_01_88cebf2d:


    xy "\"¿Por qué me traicionarías así...?\""


translate english c7111_01_719ea20c:



    voice "voice/c71/1101430a02.opus"
    aoi "\"......\""


translate english c7111_01_9ffbec82:


    xy "\"¡Te hice una pregunta, Aoi!\""


translate english c7111_01_969895ac:



    voice "voice/c71/1101440a02.opus"
    aoi "\"......Pues...\""


translate english c7111_01_96a05aee:



    voice "voice/c71/1101450a02.opus"
    aoi "\"Es... el propósito de Aoi...\""


translate english c7111_01_22067f46:


    xy "\"¿Cómo?\""


translate english c7111_01_32e02d16:



    voice "voice/c71/1101460a02.opus"
    aoi "\"Dios me dijo... que lo hiciera...\""


translate english c7111_01_69031881:


    xy "\"¡¡¡Tu maldito dios!!!\""


translate english c7111_01_5d29f2db:



    voice "voice/c71/1101470b03.opus"
    c "\"¡Basta! ¡Por favor!\""


translate english c7111_01_7f960423:


    "Antes de que pueda arremeter, Ryuujirou se mete entre nosotros."


translate english c7111_01_03f14456:



    voice "voice/c71/1101480b03.opus"
    c "\"Por favor, solo... basta...\""


translate english c7111_01_f78a1bed:



    voice "voice/c71/1101490b03.opus"
    c "\"Cooperé con tu pequeña farsa, tal como pediste...\""


translate english c7111_01_ce724022:



    voice "voice/c71/1101500b03.opus"
    c "\"Todo esto es mi culpa.\""


translate english c7111_01_b0231d45:



    voice "voice/c71/1101510b03.opus"
    c "\"Nunca debí ceder a la tentación.\""


translate english c7111_01_f5b68a7e:



    voice "voice/c71/1101520b03.opus"
    c "\"Así que por favor, solo... déjala ir...\""


translate english c7111_01_e3ab9dc6:


    xy "\"Y bien, ¿te la cogiste?\""


translate english c7111_01_dba2bd1c:


    xy "\"Te la cogiste, ¿verdad?\""


translate english c7111_01_27ecbbf5:



    voice "voice/c71/1101530b03.opus"
    c "\"¡Ya te dije que no!\""


translate english c7111_01_c0a2279e:



    voice "voice/c71/1101540b03.opus"
    c "\"A medio camino, Aoi-senpai cambió de opinión... Dijo que te amaba demasiado... Así que luego—\""


translate english c7111_01_a54d4ca6:


    xy "\"¿No lo hicieron? ¿¡Después de que ya habían abierto un condón!?\""


translate english c7111_01_3dad408e:



    voice "voice/c71/1101550b03.opus"
    c "\"......Exacto.\""


translate english c7111_01_5979747e:


    xy "\"¡Ja! ¡Uoh! ¡Eso es amor! ¡Estoy tan conmovido que podría llorar!\""


translate english c7111_01_c34d35da:


    xy "\"...No me trago esa mierda.\""


translate english c7111_01_74091f04:


    "Golpeo la mesa con el puño, pero es curioso—a estas alturas, ni siquiera siento el dolor."


translate english c7111_01_f48f2c8c:


    xy "\"Sé directo conmigo.\""


translate english c7111_01_20ec651d:


    xy "\"Ustedes simplemente cogieron sin condón, ¿verdad?\""


translate english c7111_01_2d5f2267:


    xy "\"Primero se la chuparon y se lamieron, y luego, cuando llegó el momento de metérsela...\""


translate english c7111_01_300d8a07:


    xy "\"Estabas como \"¡Aoi quiere la descarga cruda!\" ¿No es lo que dijiste? ¿Y bien?\""



translate english c7111_01_4883fda1:


    xy "\"¿Crees que podría creer que ustedes dos llegaron tan lejos solo para dejarlo ahí después de abrir un condón?\""


translate english c7111_01_9d1cdb9e:


    xy "\"¡¡¡NADIE EN SU SANO JUICIO CREERÍA ESO!!!\""


translate english c7111_01_3eca3ab1:



    voice "voice/c71/1101560b03.opus"
    c "\"......\""


translate english c7111_01_f253e515:



    voice "voice/c71/1101570b01.opus"
    xtl "\"......\""


translate english c7111_01_53136740:



    voice "voice/c71/1101580a01.opus"
    mx "\"......\""


translate english c7111_01_0f0c21bc:


    "Nadie discute."


translate english c7111_01_35565c2d:


    "Probablemente porque nadie puede."


translate english c7111_01_fba8f7aa:


    xy "\"Ja... jaja... jajajajaja...\""


translate english c7111_01_bb05ab41:


    "Esto es hilarante."


translate english c7111_01_6eabde42:


    "Me duelen las costillas de tanto reír."


translate english c7111_01_f11ecd02:


    "De hecho, también estoy llorando..."


translate english c7111_01_416c852a:


    "¿Son lágrimas de frustración?"


translate english c7111_01_6fa13c34:


    "¿O de tristeza?"


translate english c7111_01_feb79385:


    "¿O... quizás son lágrimas de felicidad?"


translate english c7111_01_f99ba3e8:



    voice "voice/c71/1101590a02.opus"
    aoi "\"Bup bup bup bup bup bup bup bup bup bup bup bup bup bup bup...\""


translate english c7111_01_9cafb752:


    "De la nada, Aoi saca su teléfono y lo levanta en el aire."


translate english c7111_01_7621912e:



    voice "voice/c71/1101600a02.opus"
    aoi "\"Bup bup bup bup bup bup bup bup bup bup bup bup bup bup bup...\""


translate english c7111_01_49cde488:



    voice "voice/c71/1101610a02.opus"
    aoi "\"Bup bup bup bup bup bup bup bup bup bup bup bup bup bup bup...\""


translate english c7111_01_82693ef1:



    voice "voice/c71/1101620a02.opus"
    aoi "\"Dios... Por favor...\""


translate english c7111_01_5218bded:



    voice "voice/c71/1101630a02.opus"
    aoi "\"¡Por favor, capta mi señal...!\""


translate english c7111_01_5b070dd2:



    voice "voice/c71/1101640a02.opus"
    aoi "\"¡Aoi se bugeó...! ¡Aoi la regó...!\""


translate english c7111_01_59d7f0f3:



    voice "voice/c71/1101660a02.opus"
    aoi "\"¡Aoi no quiere... un final malo...!\""


translate english c7111_01_bce55f9e:



    voice "voice/c71/1101670a02.opus"
    aoi "\"¡Por favor, déjame recargar mi archivo guardado...! ¡Por favor, déjame...! ¡Déjame intentarlo otra vez...!\""


translate english c7111_01_c00366ec:



    voice "voice/c71/1101680a02.opus"
    aoi "\"¡¡¡Por favor, Dios... Dios...!!!\""


translate english c7111_01_2791c7c1:


    aoi "\"¿¡Por qué no me respondes...!?\""


translate english c7111_01_079b2228:


    "Le arrebato el teléfono."


translate english c7111_01_ba8ce78f:



    voice "voice/c71/1101690a02.opus"
    aoi "\"¡Aaah! ¡No!\""


translate english c7111_01_965d813e:


    xy "\"¡Cállate de una vez!\""


translate english c7111_01_e7c03537:


    "La pantalla muestra su llamada en curso a \"God\"."



translate english c7111_01_e6bde475:


    xy "\"¿Me engañaste porque DIOS te lo dijo?\""


translate english c7111_01_3b62a7f8:


    xy "\"¡Eso es un montón de pendejadas!\""


translate english c7111_01_1eec5be4:



    voice "voice/c71/1101700a02.opus"
    aoi "\"¡Aaah...!\""


translate english c7111_01_aa20005f:


    "Lanzo su teléfono al suelo."


translate english c7111_01_6d160644:


    "La pantalla se hace añicos al impacto."


translate english c7111_01_3e8347cb:


    "Aoi solo lo mira fijamente."


translate english c7111_01_b1a2a066:


    "Solo hay una cosa que quiero de ella ahora."


translate english strings:


    old "Сказать мне правду"
    new "Dime la verdad"


    old "Съебаться из моего дома"
    new "Vete a la mierda de mi casa"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
