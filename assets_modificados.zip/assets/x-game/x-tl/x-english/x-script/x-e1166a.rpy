

translate english e1166a_88b63a29:



    voice "voice/e11/66a00010b02.opus"
    kmsm "\"EL NÚMERO QUE HA MARCADO NO ESTÁ EN SERVICIO EN ESTE MOMENTO.\""


translate english e1166a_faa99759:


    xy "\"Estás bromeando...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
