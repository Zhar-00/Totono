

translate english e1166a_88b63a29:



    voice "voice/e11/66a00010b02.opus"
    kmsm "\"THE NUMBER YOU HAVE DIALED IS NOT IN SERVICE AT THIS TIME.\""


translate english e1166a_faa99759:


    xy "\"You're kidding me...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
