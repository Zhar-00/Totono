

translate english c7141_040fd94b:


    "Pasa una cantidad indeterminada de tiempo."


translate english c7141_ce7c0c16:



    voice "voice/c71/4100010a02.opus"
    aoi "\"Recharge... complete...\""


translate english c7141_c578eb2b:



    voice "voice/c71/4100020a02.opus"
    aoi "\"So full... of zappy...\""


translate english c7141_2ee5afa1:


    "Yazgo en la cama con Aoi en mis brazos."


translate english c7141_0f9c9f08:


    "En cuanto a Ryuujirou, bajó las escaleras antes, al borde de desmayarse."


translate english c7141_4734d63f:


    "Debe haber gastado hasta su última energía solo para darnos algo de tiempo a solas."


translate english c7141_eae6c0a2:



    voice "voice/c71/4100030a02.opus"
    aoi "\"Shin...ichi...?\""


translate english c7141_a64ae2ce:


    xy "\"Don't worry. I'm right here.\""


translate english c7141_854695b7:


    "Le susurro de vuelta mientras murmura, medio dormida."


translate english c7141_419d18ca:



    voice "voice/c71/4100040a02.opus"
    aoi "\"Boop boop...\""


translate english c7141_a41b19c7:



    voice "voice/c71/4100050a02.opus"
    aoi "\"Let's... go on... a date again... sometime...\""


translate english c7141_aead4c73:



    voice "voice/c71/4100060a02.opus"
    aoi "\"Aoi can... wear the... hairpin...\""


translate english c7141_50b2fae4:


    "Aprieta el puño."


translate english c7141_2aaa49d6:


    "Dentro está la horquilla de gatito, grabada con todos sus recuerdos más felices."


translate english c7141_7b47ac28:


    xy "\"Yeah, that sounds nice.\""


translate english c7141_81aa479f:


    "Esta vez, me gustaría tener una cita muy cursi y romántica..."


translate english c7141_f37a32a7:



    voice "voice/c71/4100070a02.opus"
    aoi "\"Promise... me...\""


translate english c7141_3c568a45:


    xy "\"Okay. I promise.\""


translate english c7141_a35775b1:


    "Puede que no lo recuerde por la mañana."


translate english c7141_006b3ec5:


    "Pero voy a asegurarme de cumplir esta promesa de todos modos."


translate english c7141_ec8cb406:


    "Pensándolo bien, es algo gracioso."


translate english c7141_60b54eed:


    "¿Por qué un celoso bastardo como yo—un tipo que nunca creyó ni una vez en su pequeño mundo—decidiría de repente perdonarla?"


translate english c7141_328e972b:


    "¿Por qué invitaría a Ryuujirou de vuelta—y tendría un trío—solo para recuperarla?"


translate english c7141_0fd4d656:


    "\"\"\"......\"\"\""


translate english c7141_2d9e328e:


    xy "\"Fate...\""


translate english c7141_ba52c4f0:


    "La gente no puede controlar su destino."


translate english c7141_71bb77dd:


    "Eso debe ser lo que me impulsó a hacerlo."


translate english c7141_7aca7041:


    "Al menos, no se me ocurre otra cosa."


translate english c7141_ab3725ba:


    xy "\"Fate must have brought me and Aoi together, huh?\""


translate english c7141_d9fda7df:



    voice "voice/c71/4100080a01.opus"
    mx "\"Wrong.\""


translate english c7141_6ab61c32:


    xy "\"Hmm?\""


translate english c7141_07d8ce2d:


    "¿Estoy oyendo cosas?"


translate english c7141_27aa5400:


    "Creí oír una voz de algún lado..."


translate english c7141_622142de:


    "Justo entonces, oigo un golpeteo bajo la cama."


translate english c7141_f1a4546b:


    "Y lo siguiente que sé—"


translate english c7141_a61173b7:



    voice "voice/c71/4100090a01.opus"
    mx "\"......\""


translate english c7141_16026a25:


    "Miyuki aparece, con los ojos rojos de llorar, su expresión... sorprendentemente vacía."


translate english c7141_d67c5fb9:



    voice "voice/c71/4100100a01.opus"
    mx "\"You betrayed me.\""


translate english c7141_1786c65f:


    xy "\"I what...?\""


translate english c7141_b48eb85d:



    voice "voice/c71/4100110a01.opus"
    mx "\"Wait right here. I need to go get something.\""


translate english c7141_5734c9ee:


    "Con eso, Miyuki sale de la habitación."


translate english c7141_4ea49a61:


    "¿Qué diablos fue eso?"


translate english c7141_8059644d:



    voice "voice/c71/4100120a02.opus"
    aoi "\"Boop boop...?\""


translate english c7141_b02686a0:



    voice "voice/c71/4100130a02.opus"
    aoi "\"Shinichi, where are you going?\""


translate english c7141_5e592db1:


    "Aoi se aferra a mí adormilada."


translate english c7141_a2e9a9e4:


    xy "\"Oh, nowhere. Miyuki's just—\""


translate english c7141_a370bddc:



    voice "voice/c71/4100140a02.opus"
    aoi "\"Miyuki...?\""



translate english c7141_634fafe4:



    voice "voice/c71/4100150a02.opus"
    aoi "\"Shinichi... Are you in love with her?\""


translate english c7141_86866b7f:



    voice "voice/c71/4100160a02.opus"
    aoi "\"Have you... changed your mind about me?\""


translate english c7141_9282d259:



    voice "voice/c71/4100170a02.opus"
    aoi "\"Are you going to abandon me?\""


translate english c7141_4c10e4bd:


    xy "\"Of course not!\""


translate english c7141_ebf5c5ac:


    "Con un poco de consuelo, Aoi sonríe, con la mente todavía a medio camino en el mundo de los sueños."


translate english c7141_57430b1a:



    voice "voice/c71/4100180a02.opus"
    aoi "\"Aoi cares about Miyuki. She's my best friend.\""


translate english c7141_d1265a47:



    voice "voice/c71/4100190a02.opus"
    aoi "\"But... please...\""


translate english c7141_5913aa13:



    voice "voice/c71/4100200a02.opus"
    aoi "\"Right now, just forget about her and fall asleep with me...\""


translate english c7141_2d14ee3c:



    voice "voice/c71/4100210a02.opus"
    aoi "\"Boop boop... boop... boop...\""


translate english c7141_837431a0:


    "Aoi empieza a roncar, con sus brazos aún envueltos alrededor de los míos."


translate english c7141_4b709786:


    "...Ahora lo entiendo."


translate english c7141_2f1ebd0d:


    "Esto no es la realidad."


translate english c7141_3478ddea:


    "Esto es solo un sueño."


translate english c7141_a2ad598a:


    "Debo haber estado soñando—"


translate english c7141_76d897ba:


    xy "\"—?!\""



translate english c7141_18841d62:


    "¿Qué diablos?"


translate english c7141_bf40259e:


    "Eso sonó como Eru hace un momento."


translate english c7141_02547da0:



    voice "voice/c71/4100230a02.opus"
    aoi "\"......\""


translate english c7141_d3cd358c:


    "Aoi sigue durmiendo como un bebé."


translate english c7141_759dc787:


    "Intento levantarme, pero no suelta mi brazo."


translate english c7141_ccb8b880:


    "Me aparto suavemente, tratando de no despertarla—"


translate english c7141_289547df:


    "Entonces oigo el sonido de pasos acercándose."


translate english c7141_0fc50500:


    "Si Miyuki estaba bajo mi cama hace un momento—¿cuánto tiempo estuvo ahí?"


translate english c7141_87550d83:


    "Debe haber estado ahí debajo desde antes de que espiara a Aoi y Ryuujirou teniendo sexo."


translate english c7141_cb93c33c:


    "Lo que significa que debe haber estado ahí debajo desde antes de que subieran aquí."


translate english c7141_5f6a4b55:


    "Y eso significa... que los tres tuvimos sexo a centímetros de ella—"


translate english c7141_eb342908:



    voice "voice/c71/4100240a01.opus"
    mx "\"I'm back.\""


translate english c7141_ae1942ae:


    xy "\"What the...?\""


translate english c7141_c090aa75:


    "En sus brazos está mi ramo de cumpleaños."


translate english c7141_a14e2cd1:


    "Un largo y sangriento arañazo se extiende por su mejilla."


translate english c7141_1e4ff5b6:


    xy "\"Where's Eru...?\""


translate english c7141_8e7ddae1:



    voice "voice/c71/4100250a01.opus"
    mx "\"It's a real shame about him.\""


translate english c7141_7f4c86ae:


    "Sonríe como si le faltaran varios tornillos."


translate english c7141_314c398f:


    "El ramo cae como una funda fragante."


translate english c7141_d9bee486:


    "Dentro hay un bate de metal manchado de sangre."


translate english c7141_c6699a93:



    voice "voice/c71/4100260a01.opus"
    mx "\"But that's what he gets for getting in my way.\""


translate english c7141_46b4eed8:



    voice "voice/c71/4100270a01.opus"
    mx "\"He was so cute... Oh well.\""


translate english c7141_5c64dc09:


    xy "\"Wh... What the FUCK did you do to Eru?!\""


translate english c7141_f21ea32d:



    voice "voice/c71/4100280a02.opus"
    aoi "\"Boop boop...\""


translate english c7141_052795a2:


    "Mi grito despierta a Aoi."


translate english c7141_9d271368:



    voice "voice/c71/4100290a02.opus"
    aoi "\"What's wrong... with Eru...?\""


translate english c7141_4218c0ae:



    voice "voice/c71/4100300a01.opus"
    mx "\"Here, let me show you.\""


translate english c7141_f3752517:



    voice "voice/c71/4100310a02.opus"
    aoi "\"Huh?\""


translate english c7141_97c6ec75:


    "La cabeza de Aoi se parte."


translate english c7141_aa6001f6:


    "...¿Se parte?"


translate english c7141_b07b54ea:


    "Todo es rojo."


translate english c7141_398ce918:


    "Nada se siente real."


translate english c7141_2396073e:


    "La sonrisa de Miyuki flota tras mis párpados—la expresión de su rostro justo antes de blandir ese bate."


translate english c7141_38bbd5f4:


    "Miyuki... blandió su bate... y golpeó... a Aoi..."


translate english c7141_c30f20f5:


    "La sangre gotea por mi frente y hacia mis ojos."


translate english c7141_10bb1eda:



    voice "voice/c71/4100320a01.opus"
    mx "\"Hey, Shinichi?\""


translate english c7141_6986806c:



    voice "voice/c71/4100330a01.opus"
    mx "\"I still need to give you my present, don't I?\""


translate english c7141_3a19fc2f:



    voice "voice/c71/4100340a01.opus"
    mx "\"Here you go.\""


translate english c7141_62fd3db4:


    xy "\"Bwugh!!!\""


translate english c7141_2ad3fb9e:


    xy "\"Wh-What are you doing?! Sto—Bwggh!!!\""


translate english c7141_ef5a0847:


    "Una sensación indescriptible abruma todo mi rostro."


translate english c7141_2d3891dd:


    "Me derrumbo sobre la cama, inmovilizado, mi visión no es más que carmesí."


translate english c7141_dd9fd396:


    xy "\"St—op—! What are you—Bwggh!\""


translate english c7141_161fee93:



    voice "voice/c71/4100350a01.opus"
    mx "\"Happy birthday to you...\""


translate english c7141_37fd0f53:


    "Eso fue raro..."


translate english c7141_5858b0b4:


    "¿Qué diablos fue ese sonido?"


translate english c7141_812ee929:


    "Oh, dios—¡¿está golpeando a Aoi otra vez?!"


translate english c7141_6b0a743a:


    xy "\"S-Stop!!!\""


translate english c7141_6633f40c:


    xy "\"Don't hurt her!!!\""


translate english c7141_5e0f9436:


    "Extiendo la mano para detenerla—"


translate english c7141_e819c497:


    "...¿Qué demonios?"


translate english c7141_247b61a6:


    "Mi brazo derecho no se mueve."


translate english c7141_df456b32:



    voice "voice/c71/4100360a01.opus"
    mx "\"Happy birthday to youuu...\""


translate english c7141_128ca892:


    xy "\"Ugh...!\""


translate english c7141_c3b691a1:


    "Siento un impacto en mi costado izquierdo."


translate english c7141_3b97a766:


    "Ahora mi brazo izquierdo tampoco se mueve."


translate english c7141_39e068ca:


    "Ah, ya entiendo."


translate english c7141_cf4ae8ec:



    voice "voice/c71/4100370a01.opus"
    mx "\"Happy birthday, dear Shinichiii...\""


translate english c7141_d82c8ac9:


    "Mi pierna derecha..."


translate english c7141_6c838574:



    voice "voice/c71/4100380a01.opus"
    mx "\"Happy birthday to youuu!\""


translate english c7141_73f9e31f:


    "Mi pierna izquierda..."


translate english c7141_12e64a21:


    xy "\"......\""


translate english c7141_ebc503b4:



    voice "voice/c71/4100390a01.opus"
    mx "\"Haha! Hahahahahaha...!!!\""


translate english c7141_f64dcc6d:



    voice "voice/c71/4100400a01.opus"
    mx "\"Confused, are we?\""


translate english c7141_2c4a8f4c:



    voice "voice/c71/4100410a01.opus"
    mx "\"You're too blinded and numb from the pain, hmm?\""


translate english c7141_54477c60:



    voice "voice/c71/4100420a01.opus"
    mx "\"The person I hit...\""


translate english c7141_9f265c4b:



    voice "voice/c71/4100430a01.opus"
    mx "\"...was you, Shinichi.\""


translate english c7141_b8af3f97:


    "Por supuesto que lo era."


translate english c7141_0cf9a1dc:


    "Mis piernas..."


translate english c7141_043e1b7a:


    "No, mis cuatro extremidades están rotas ahora."


translate english c7141_d75618a9:


    xy "\"Why... are you doing this...?\""


translate english c7141_6939ce05:



    voice "voice/c71/4100440a01.opus"
    mx "\"Well, Aoi's already dead.\""


translate english c7141_1feb099e:



    voice "voice/c71/4100450a01.opus"
    mx "\"No fun in hitting a dead body, now is there?\""


translate english c7141_85ccceb2:


    "Mis manos no se mueven."


translate english c7141_3eac6a21:


    "Ni siquiera puedo limpiarme la sangre de los ojos."


translate english c7141_8fd6c607:



    voice "voice/c71/4100460a01.opus"
    mx "\"You want to see it for yourself, is that it?\""


translate english c7141_a0ac1def:



    voice "voice/c71/4100470a01.opus"
    mx "\"I'm not sure that's a good idea. It's so gory, the ratings board will have a field day. Might have to censor it.\""


translate english c7141_ceb83cb8:



    voice "voice/c71/4100480a01.opus"
    mx "\"...Oh, wait. I forget, do you still think this world is real life?\""


translate english c7141_43adcb21:


    xy "\"What the fuck are you talking about?!\""


translate english c7141_667dd9ec:


    "Cada nervio de mi cuerpo grita con adrenalina y pura emoción."


translate english c7141_d98564a9:


    "Poco a poco, las lágrimas asoman a mis ojos, luego ruedan por mis mejillas, despejando mi visión apenas un poco."


translate english c7141_0a7e374f:


    "Ahí, puedo ver... algo que solía ser Aoi."


translate english c7141_19e7a889:


    "La sangre empapa profundamente mi colchón."


translate english c7141_083c67cf:


    "¿Qué está pasando?"


translate english c7141_71c518e9:


    "¿Qué carajos está pasando?"


translate english c7141_2abf5448:


    xy "\"You're... insane...\""


translate english c7141_a5db22fe:



    voice "voice/c71/4100490a01.opus"
    mx "\"Yup! I'm insane, alright.\""


translate english c7141_a099d230:



    voice "voice/c71/4100500a01.opus"
    mx "\"It'd be weirder if I wasn't, actually, considering what I just did.\""


translate english c7141_13c2e0b2:


    "La expresión de Miyuki me recuerda a la forma en que Aoi solía verse, cuando la conocimos."


translate english c7141_98969260:


    "Su mirada apunta hacia mí, pero en realidad no me ve."


translate english c7141_e4e5202e:


    "En cambio, es como si estuviera... mirando algún otro mundo lejano."


translate english c7141_be3df758:



    voice "voice/c71/4100510a01.opus"
    mx "\"The moment I found out you abandoned me at the batting cages to go fuck Aoi on the roof...\""


translate english c7141_8631b85f:



    voice "voice/c71/4100520a01.opus"
    mx "\"Honestly, I think that was the point I truly lost it.\""


translate english c7141_f69b20fe:



    voice "voice/c71/4100530a01.opus"
    mx "\"It really hurts, being betrayed by the one you vowed to love for all eternity...\""


translate english c7141_8df791ee:



    voice "voice/c71/4100540a01.opus"
    mx "\"But maybe you know what that feels like now, hmm?\""


translate english c7141_2c84cca1:


    "Habla como si la hubiera engañado con Aoi."


translate english c7141_f9eef90b:


    "No seas ridícula."


translate english c7141_49655f2e:


    "Claro, sabía que sentía algo por mí."


translate english c7141_6e197cbc:


    "Pero por eso siempre fui tan cuidadoso de mantener mi distancia."


translate english c7141_512f101f:



    voice "voice/c71/4100550a01.opus"
    mx "\"So I changed my mind.\""


translate english c7141_b636b94e:



    voice "voice/c71/4100560a01.opus"
    mx "\"I knew Aoi was hiding something big.\""


translate english c7141_c4af366b:



    voice "voice/c71/4100570a01.opus"
    mx "\"And I knew you didn't mean to hurt me.\""


translate english c7141_1a4540c9:



    voice "voice/c71/4100580a01.opus"
    mx "\"So I decided to give you another chance.\""


translate english c7141_7c13d5c6:


    xy "\"For what...?\""


translate english c7141_e3062ebf:



    voice "voice/c71/4100590a01.opus"
    mx "\"If I hadn't spread that rumor or dragged you to the corner store, you probably never would've noticed...\""


translate english c7141_7dd5afb8:



    voice "voice/c71/4100600a01.opus"
    mx "\"...that Aoi was fucking some other guy.\""


translate english c7141_bf4fa52c:


    "Pensándolo bien... tiene razón."


translate english c7141_498ec6a9:


    "Miyuki era siempre la que me metía esas dudas en la cabeza."


translate english c7141_e9b4bbdd:



    voice "voice/c71/4100610a01.opus"
    mx "\"When you found proof of her cheating in that apartment and vowed to get your revenge, oh, I was so happy I could fly.\""


translate english c7141_e3c66e20:



    voice "voice/c71/4100620a01.opus"
    mx "\"I helped you plan it all... And I was always there to console you, too.\""


translate english c7141_f1275105:



    voice "voice/c71/4100630a01.opus"
    mx "\"All during the birthday party today, I could barely contain myself! It was the most challenging performance I've ever had to give.\""


translate english c7141_0928eba2:



    voice "voice/c71/4100640a01.opus"
    mx "\"So naturally, anyone with half a brain would want a front-row seat to the trainwreck, right?\""


translate english c7141_9d57c967:



    voice "voice/c71/4100650a01.opus"
    mx "\"I waited by the stairs and listened in on the whole thing.\""


translate english c7141_5556e6d0:



    voice "voice/c71/4100660a01.opus"
    mx "\"When Aoi walked out of the living room, boy, did I ever panic. I dashed right up the stairs and hid under your bed.\""


translate english c7141_b787e1e0:



    voice "voice/c71/4100670a01.opus"
    mx "\"Then, when she and Ryuujirou started having sex, well... I wasn't expecting it, but I was over the moon.\""


translate english c7141_eeaf7c80:



    voice "voice/c71/4100680a01.opus"
    mx "\"I thought, this means Shinichi will hate her guts.\""


translate english c7141_2574c426:



    voice "voice/c71/4100690a01.opus"
    mx "\"At last, my dream would come true. At last, we would be together.\""


translate english c7141_a7db73e3:



    voice "voice/c71/4100700a01.opus"
    mx "\"And I believed it right up until the moment you walked into the room.\""


translate english c7141_05aaca55:



    voice "voice/c71/4100710a01.opus"
    mx "\"So, can you imagine?\""


translate english c7141_64c4c05a:



    voice "voice/c71/4100720a01.opus"
    mx "\"Everything that went through my head while I was down there?\""


translate english c7141_8a8463ec:



    voice "voice/c71/4100730a01.opus"
    mx "\"I mean, think about it. The love of my life was just inches away, with his face in some other girl's vagina, sucking out some other guy's semen!\""


translate english c7141_65522383:



    voice "voice/c71/4100740a01.opus"
    mx "\"I mean, you were just THAT enamored with her?\""


translate english c7141_23973af4:



    voice "voice/c71/4100750a01.opus"
    mx "\"I was powerless. All I could do was lie under the bed and pray.\""


translate english c7141_5eb53ae1:



    voice "voice/c71/4100760a01.opus"
    mx "\"I believed in you. I believed that in the end, you would choose me.\""


translate english c7141_fec84a9f:



    voice "voice/c71/4100770a01.opus"
    mx "\"But in the meantime, all I could do was listen to you idiots bumping uglies for hours on end.\""


translate english c7141_dbfb4147:



    voice "voice/c71/4100780a01.opus"
    mx "\"—Stop!\""


translate english c7141_b58f0165:



    voice "voice/c71/4100790a01.opus"
    mx "\"—Don't tell her you love her!\""


translate english c7141_3fd6d495:



    voice "voice/c71/4100800a01.opus"
    mx "\"But my prayers fell on deaf ears.\""


translate english c7141_903cbf39:



    voice "voice/c71/4100810a01.opus"
    mx "\"So, what? What was I, chopped liver?\""


translate english c7141_a6a5762a:



    voice "voice/c71/4100820a01.opus"
    mx "\"What kind of idiot was I, silently weeping tears of joy in the hopes that we'd finally be together?\""


translate english c7141_7edb7c9d:



    voice "voice/c71/4100830a01.opus"
    mx "\"The person who promised to love me forever... was betraying me, directly overhead. Could you stay sane after that? Could you?!\""


translate english c7141_639a3ee3:


    "Mi cuerpo se niega a moverse."


translate english c7141_5edd6a65:


    "En absoluto."


translate english c7141_6be141ef:


    "Y nadie viene a salvarme."


translate english c7141_d3a29a43:


    "No se me ocurre ninguna forma de salir de esto."


translate english c7141_10f8eb08:


    "Miro de nuevo el cuerpo sin vida de Aoi."


translate english c7141_9918b2c1:


    "No sé qué hacer."


translate english c7141_b41fd282:


    "No entiendo."


translate english c7141_a8339e8a:


    xy "\"Why...?\""


translate english c7141_223aa633:


    xy "\"Why are you doing this to me...?\""


translate english c7141_83ca011d:



    voice "voice/c71/4100840a01.opus"
    mx "\"You broke our vows.\""


translate english c7141_7daacfd8:



    voice "voice/c71/4100850a01.opus"
    mx "\"You're a traitor. Serves you right, don't you think?\""


translate english c7141_7df6d5c8:


    xy "\"I'm telling you, I never betrayed y—\""


translate english c7141_a973ae8f:



    voice "voice/c71/4100860a01.opus"
    mx "\"I'm not talking to you.\""


translate english c7141_b9935b2a:



    voice "voice/c71/4100870a01.opus"
    mx "\"I'm talking to YOU.\""


translate english c7141_17635f45:



    voice "voice/c71/4100880a01.opus"
    mx "\"YOU were the one who promised me your eternal love in the first route.\""


translate english c7141_79d3c894:



    voice "voice/c71/4100890a01.opus"
    mx "\"And YOU were the one who made all those choices Shinichi would never have made!\""


translate english c7141_c865fe30:


    "Miyuki... ¿Con quién estás hablando...?"


translate english c7141_d3d66b99:



    voice "voice/c71/4100900a01.opus"
    mx "\"Look... YOU remember, don't YOU?\""


translate english c7141_83f25dd8:



    voice "voice/c71/4100910a01.opus"
    mx "\"After the play, when we pledged our love to one another and shared a kiss beneath the starry sky...\""


translate english c7141_6a7c50a7:


    "¿Qué le pasa?"


translate english c7141_9fe5f2d7:


    "No puedo entender ni una sola cosa de lo que dice..."


translate english c7141_af45a3e6:



    voice "voice/c71/4100920a01.opus"
    mx "\"YOU were supposed to only ever choose the options that would lead to MY route.\""


translate english c7141_9f30864e:



    voice "voice/c71/4100930a01.opus"
    mx "\"YOU had one job: to love me forever and ever!\""


translate english c7141_003bfffc:



    voice "voice/c71/4100940a01.opus"
    mx "\"Do YOU realize... just how hard I tried to keep YOU out of Aoi's route? Surely YOU do, right?\""


translate english c7141_34985677:



    voice "voice/c71/4100950a01.opus"
    mx "\"So why won't YOU return my feelings?\""


translate english c7141_b80e1101:



    voice "voice/c71/4100960a01.opus"
    mx "\"Just say it! Say you love me more than anyone else!\""


translate english strings:


    old "Я люблю тебя"
    new "Te amo"


    old "Я тебя ненавижу"
    new "Te odio"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
