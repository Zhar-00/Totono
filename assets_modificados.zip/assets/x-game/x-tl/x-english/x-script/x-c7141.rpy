

translate english c7141_040fd94b:


    "Pasa una cantidad indeterminada de tiempo."


translate english c7141_ce7c0c16:



    voice "voice/c71/4100010a02.opus"
    aoi "\"Recarga... completa...\""


translate english c7141_c578eb2b:



    voice "voice/c71/4100020a02.opus"
    aoi "\"Tan llena... de descarga...\""


translate english c7141_2ee5afa1:


    "Yazgo en la cama con Aoi en mis brazos."


translate english c7141_0f9c9f08:


    "En cuanto a Ryuujirou, bajó las escaleras antes, al borde de desmayarse."


translate english c7141_4734d63f:


    "Debe haber gastado hasta su última energía solo para darnos algo de tiempo a solas."


translate english c7141_eae6c0a2:



    voice "voice/c71/4100030a02.opus"
    aoi "\"¿Shin...ichi...?\""


translate english c7141_a64ae2ce:


    xy "\"No te preocupes. Estoy aquí.\""


translate english c7141_854695b7:


    "Le susurro de vuelta mientras murmura, medio dormida."


translate english c7141_419d18ca:



    voice "voice/c71/4100040a02.opus"
    aoi "\"Bup bup...\""


translate english c7141_a41b19c7:



    voice "voice/c71/4100050a02.opus"
    aoi "\"Vamos... a salir... otra vez... alguna vez...\""


translate english c7141_aead4c73:



    voice "voice/c71/4100060a02.opus"
    aoi "\"Aoi puede... usar la... horquilla...\""


translate english c7141_50b2fae4:


    "Aprieta el puño."


translate english c7141_2aaa49d6:


    "Dentro está la horquilla de gatito, grabada con todos sus recuerdos más felices."


translate english c7141_7b47ac28:


    xy "\"Sí, suena bien.\""


translate english c7141_81aa479f:


    "Esta vez, me gustaría tener una cita muy cursi y romántica..."


translate english c7141_f37a32a7:



    voice "voice/c71/4100070a02.opus"
    aoi "\"Prométe...melo...\""


translate english c7141_3c568a45:


    xy "\"Está bien. Lo prometo.\""


translate english c7141_a35775b1:


    "Puede que no lo recuerde por la mañana."


translate english c7141_006b3ec5:


    "Pero voy a asegurarme de cumplir esta promesa de todos modos."


translate english c7141_ec8cb406:


    "Pensándolo bien, es algo gracioso."


translate english c7141_60b54eed:


    "¿Por qué un celoso bastardo como yo—un tipo que nunca creyó ni una vez en su pequeño mundo—decidiría de repente perdonarla?"


translate english c7141_328e972b:


    "¿Por qué invitaría a Ryuujirou de vuelta—y tendría un trío—solo para recuperarla?"


translate english c7141_0fd4d656:


    "\"\"\"......\"\"\""


translate english c7141_2d9e328e:


    xy "\"El destino...\""


translate english c7141_ba52c4f0:


    "La gente no puede controlar su destino."


translate english c7141_71bb77dd:


    "Eso debe ser lo que me impulsó a hacerlo."


translate english c7141_7aca7041:


    "Al menos, no se me ocurre otra cosa."


translate english c7141_ab3725ba:


    xy "\"El destino debe habernos unido a Aoi y a mí, ¿eh?\""


translate english c7141_d9fda7df:



    voice "voice/c71/4100080a01.opus"
    mx "\"Te equivocas.\""


translate english c7141_6ab61c32:


    xy "\"¿Hmm?\""


translate english c7141_07d8ce2d:


    "¿Estoy oyendo cosas?"


translate english c7141_27aa5400:


    "Creí oír una voz de algún lado..."


translate english c7141_622142de:


    "Justo entonces, oigo un golpeteo bajo la cama."


translate english c7141_f1a4546b:


    "Y lo siguiente que sé—"


translate english c7141_a61173b7:



    voice "voice/c71/4100090a01.opus"
    mx "\"......\""


translate english c7141_16026a25:


    "Miyuki aparece, con los ojos rojos de llorar, su expresión... sorprendentemente vacía."


translate english c7141_d67c5fb9:



    voice "voice/c71/4100100a01.opus"
    mx "\"Me traicionaste.\""


translate english c7141_1786c65f:


    xy "\"¿Que yo qué...?\""


translate english c7141_b48eb85d:



    voice "voice/c71/4100110a01.opus"
    mx "\"Espérame aquí. Tengo que ir por algo.\""


translate english c7141_5734c9ee:


    "Con eso, Miyuki sale de la habitación."


translate english c7141_4ea49a61:


    "¿Qué diablos fue eso?"


translate english c7141_8059644d:



    voice "voice/c71/4100120a02.opus"
    aoi "\"¿Bup bup...?\""


translate english c7141_b02686a0:



    voice "voice/c71/4100130a02.opus"
    aoi "\"Shinichi, ¿a dónde vas?\""


translate english c7141_5e592db1:


    "Aoi se aferra a mí adormilada."


translate english c7141_a2e9a9e4:


    xy "\"Oh, a ningún lado. Es que Miyuki—\""


translate english c7141_a370bddc:



    voice "voice/c71/4100140a02.opus"
    aoi "\"¿Miyuki...?\""



translate english c7141_634fafe4:



    voice "voice/c71/4100150a02.opus"
    aoi "\"Shinichi... ¿Estás enamorado de ella?\""


translate english c7141_86866b7f:



    voice "voice/c71/4100160a02.opus"
    aoi "\"¿Has... cambiado de opinión sobre mí?\""


translate english c7141_9282d259:



    voice "voice/c71/4100170a02.opus"
    aoi "\"¿Vas a abandonarme?\""


translate english c7141_4c10e4bd:


    xy "\"¡Claro que no!\""


translate english c7141_ebf5c5ac:


    "Con un poco de consuelo, Aoi sonríe, con la mente todavía a medio camino en el mundo de los sueños."


translate english c7141_57430b1a:



    voice "voice/c71/4100180a02.opus"
    aoi "\"A Aoi le importa Miyuki. Es mi mejor amiga.\""


translate english c7141_d1265a47:



    voice "voice/c71/4100190a02.opus"
    aoi "\"Pero... por favor...\""


translate english c7141_5913aa13:



    voice "voice/c71/4100200a02.opus"
    aoi "\"Ahora mismo, solo olvídate de ella y duérmete conmigo...\""


translate english c7141_2d14ee3c:



    voice "voice/c71/4100210a02.opus"
    aoi "\"Bup bup... bup... bup...\""


translate english c7141_837431a0:


    "Aoi empieza a roncar, con sus brazos aún envueltos alrededor de los míos."


translate english c7141_4b709786:


    "...Ahora lo entiendo."


translate english c7141_2f1ebd0d:


    "Esto no es la realidad."


translate english c7141_3478ddea:


    "Esto es solo un sueño."


translate english c7141_a2ad598a:


    "Debo haber estado soñando—"


translate english c7141_76d897ba:


    xy "\"—?!\""



translate english c7141_18841d62:


    "¿Qué diablos?"


translate english c7141_bf40259e:


    "Eso sonó como Eru hace un momento."


translate english c7141_02547da0:



    voice "voice/c71/4100230a02.opus"
    aoi "\"......\""


translate english c7141_d3cd358c:


    "Aoi sigue durmiendo como un bebé."


translate english c7141_759dc787:


    "Intento levantarme, pero no suelta mi brazo."


translate english c7141_ccb8b880:


    "Me aparto suavemente, tratando de no despertarla—"


translate english c7141_289547df:


    "Entonces oigo el sonido de pasos acercándose."


translate english c7141_0fc50500:


    "Si Miyuki estaba bajo mi cama hace un momento—¿cuánto tiempo estuvo ahí?"


translate english c7141_87550d83:


    "Debe haber estado ahí debajo desde antes de que espiara a Aoi y Ryuujirou teniendo sexo."


translate english c7141_cb93c33c:


    "Lo que significa que debe haber estado ahí debajo desde antes de que subieran aquí."


translate english c7141_5f6a4b55:


    "Y eso significa... que los tres tuvimos sexo a centímetros de ella—"


translate english c7141_eb342908:



    voice "voice/c71/4100240a01.opus"
    mx "\"Ya volví.\""


translate english c7141_ae1942ae:


    xy "\"¿Qué...?\""


translate english c7141_c090aa75:


    "En sus brazos está mi ramo de cumpleaños."


translate english c7141_a14e2cd1:


    "Un largo y sangriento arañazo se extiende por su mejilla."


translate english c7141_1e4ff5b6:


    xy "\"¿Dónde está Eru...?\""


translate english c7141_8e7ddae1:



    voice "voice/c71/4100250a01.opus"
    mx "\"Es una verdadera lástima lo de él.\""


translate english c7141_7f4c86ae:


    "Sonríe como si le faltaran varios tornillos."


translate english c7141_314c398f:


    "El ramo cae como una funda fragante."


translate english c7141_d9bee486:


    "Dentro hay un bate de metal manchado de sangre."


translate english c7141_c6699a93:



    voice "voice/c71/4100260a01.opus"
    mx "\"Pero se lo merece por meterse en mi camino.\""


translate english c7141_46b4eed8:



    voice "voice/c71/4100270a01.opus"
    mx "\"Era tan lindo... En fin.\""


translate english c7141_5c64dc09:


    xy "\"¿¡Qu... Qué CARAJO le hiciste a Eru!?\""


translate english c7141_f21ea32d:



    voice "voice/c71/4100280a02.opus"
    aoi "\"Bup bup...\""


translate english c7141_052795a2:


    "Mi grito despierta a Aoi."


translate english c7141_9d271368:



    voice "voice/c71/4100290a02.opus"
    aoi "\"¿Qué pasa... con Eru...?\""


translate english c7141_4218c0ae:



    voice "voice/c71/4100300a01.opus"
    mx "\"Aquí, déjame mostrarte.\""


translate english c7141_f3752517:



    voice "voice/c71/4100310a02.opus"
    aoi "\"¿Eh?\""


translate english c7141_97c6ec75:


    "La cabeza de Aoi se parte."


translate english c7141_aa6001f6:


    "...¿Se parte?"


translate english c7141_b07b54ea:


    "Todo es rojo."


translate english c7141_398ce918:


    "Nada se siente real."


translate english c7141_2396073e:


    "La sonrisa de Miyuki flota tras mis párpados—la expresión de su rostro justo antes de blandir ese bate."


translate english c7141_38bbd5f4:


    "Miyuki... blandió su bate... y golpeó... a Aoi..."


translate english c7141_c30f20f5:


    "La sangre gotea por mi frente y hacia mis ojos."


translate english c7141_10bb1eda:



    voice "voice/c71/4100320a01.opus"
    mx "\"Oye, Shinichi.\""


translate english c7141_6986806c:



    voice "voice/c71/4100330a01.opus"
    mx "\"Todavía tengo que darte mi regalo, ¿no?\""


translate english c7141_3a19fc2f:



    voice "voice/c71/4100340a01.opus"
    mx "\"Aquí tienes.\""


translate english c7141_62fd3db4:


    xy "\"¡¡¡Bwugh!!!\""


translate english c7141_2ad3fb9e:


    xy "\"¿¡Q-Qué estás haciendo!? ¡Basta—Bwggh!!!\""


translate english c7141_ef5a0847:


    "Una sensación indescriptible abruma todo mi rostro."


translate english c7141_2d3891dd:


    "Me derrumbo sobre la cama, inmovilizado, mi visión no es más que carmesí."


translate english c7141_dd9fd396:


    xy "\"¡B-Basta—! ¡¿Qué estás—Bwggh!\""


translate english c7141_161fee93:



    voice "voice/c71/4100350a01.opus"
    mx "\"Feliz cumpleaños a ti...\""


translate english c7141_37fd0f53:


    "Eso fue raro..."


translate english c7141_5858b0b4:


    "¿Qué diablos fue ese sonido?"


translate english c7141_812ee929:


    "Oh, dios—¡¿está golpeando a Aoi otra vez?!"


translate english c7141_6b0a743a:


    xy "\"¡¡¡B-Basta!!!\""


translate english c7141_6633f40c:


    xy "\"¡¡¡No la lastimes!!!\""


translate english c7141_5e0f9436:


    "Extiendo la mano para detenerla—"


translate english c7141_e819c497:


    "...¿Qué demonios?"


translate english c7141_247b61a6:


    "Mi brazo derecho no se mueve."


translate english c7141_df456b32:



    voice "voice/c71/4100360a01.opus"
    mx "\"Feliz cumpleaños a tiii...\""


translate english c7141_128ca892:


    xy "\"¡Ugh...!\""


translate english c7141_c3b691a1:


    "Siento un impacto en mi costado izquierdo."


translate english c7141_3b97a766:


    "Ahora mi brazo izquierdo tampoco se mueve."


translate english c7141_39e068ca:


    "Ah, ya entiendo."


translate english c7141_cf4ae8ec:



    voice "voice/c71/4100370a01.opus"
    mx "\"Feliz cumpleaños, querido Shinichiii...\""


translate english c7141_d82c8ac9:


    "Mi pierna derecha..."


translate english c7141_6c838574:



    voice "voice/c71/4100380a01.opus"
    mx "\"¡Feliz cumpleaños a tiii!\""


translate english c7141_73f9e31f:


    "Mi pierna izquierda..."


translate english c7141_12e64a21:


    xy "\"......\""


translate english c7141_ebc503b4:



    voice "voice/c71/4100390a01.opus"
    mx "\"¡Ja! ¡Jajajajajaja...!\""


translate english c7141_f64dcc6d:



    voice "voice/c71/4100400a01.opus"
    mx "\"Confundido, ¿verdad?\""


translate english c7141_2c4a8f4c:



    voice "voice/c71/4100410a01.opus"
    mx "\"Estás demasiado cegado y adormecido por el dolor, ¿mm?\""


translate english c7141_54477c60:



    voice "voice/c71/4100420a01.opus"
    mx "\"La persona a la que golpeé...\""


translate english c7141_9f265c4b:



    voice "voice/c71/4100430a01.opus"
    mx "\"...fuiste tú, Shinichi.\""


translate english c7141_b8af3f97:


    "Por supuesto que lo era."


translate english c7141_0cf9a1dc:


    "Mis piernas..."


translate english c7141_043e1b7a:


    "No, mis cuatro extremidades están rotas ahora."


translate english c7141_d75618a9:


    xy "\"¿Por... qué estás haciendo esto...?\""


translate english c7141_6939ce05:



    voice "voice/c71/4100440a01.opus"
    mx "\"Bueno, Aoi ya está muerta.\""


translate english c7141_1feb099e:



    voice "voice/c71/4100450a01.opus"
    mx "\"No tiene gracia golpear un cadáver, ¿o sí?\""


translate english c7141_85ccceb2:


    "Mis manos no se mueven."


translate english c7141_3eac6a21:


    "Ni siquiera puedo limpiarme la sangre de los ojos."


translate english c7141_8fd6c607:



    voice "voice/c71/4100460a01.opus"
    mx "\"Quieres verlo por ti mismo, ¿es eso?\""


translate english c7141_a0ac1def:



    voice "voice/c71/4100470a01.opus"
    mx "\"No estoy seguro de que sea buena idea. Es tan sangriento que la junta de clasificación se va a dar un festín. Quizá tenga que censurarlo.\""


translate english c7141_ceb83cb8:



    voice "voice/c71/4100480a01.opus"
    mx "\"...Oh, espera. Se me olvida, ¿todavía crees que este mundo es la vida real?\""


translate english c7141_43adcb21:


    xy "\"¿¡De qué carajo estás hablando!?\""


translate english c7141_667dd9ec:


    "Cada nervio de mi cuerpo grita con adrenalina y pura emoción."


translate english c7141_d98564a9:


    "Poco a poco, las lágrimas asoman a mis ojos, luego ruedan por mis mejillas, despejando mi visión apenas un poco."


translate english c7141_0a7e374f:


    "Ahí, puedo ver... algo que solía ser Aoi."


translate english c7141_19e7a889:


    "La sangre empapa profundamente mi colchón."


translate english c7141_083c67cf:


    "¿Qué está pasando?"


translate english c7141_71c518e9:


    "¿Qué carajos está pasando?"


translate english c7141_2abf5448:


    xy "\"Estás... loca...\""


translate english c7141_a5db22fe:



    voice "voice/c71/4100490a01.opus"
    mx "\"¡Síp! Estoy loca, sin duda.\""


translate english c7141_a099d230:



    voice "voice/c71/4100500a01.opus"
    mx "\"De hecho, sería más raro si no lo estuviera, considerando lo que acabo de hacer.\""


translate english c7141_13c2e0b2:


    "La expresión de Miyuki me recuerda a la forma en que Aoi solía verse, cuando la conocimos."


translate english c7141_98969260:


    "Su mirada apunta hacia mí, pero en realidad no me ve."


translate english c7141_e4e5202e:


    "En cambio, es como si estuviera... mirando algún otro mundo lejano."


translate english c7141_be3df758:



    voice "voice/c71/4100510a01.opus"
    mx "\"Desde el momento en que me di cuenta de que me abandonaste en la jaula de bateo para ir a coger con Aoi en la azotea...\""


translate english c7141_8631b85f:



    voice "voice/c71/4100520a01.opus"
    mx "\"Honestamente, creo que ese fue el punto en que perdí la cabeza de verdad.\""


translate english c7141_f69b20fe:



    voice "voice/c71/4100530a01.opus"
    mx "\"Duele mucho que te traicione aquel a quien juraste amar por toda la eternidad...\""


translate english c7141_8df791ee:



    voice "voice/c71/4100540a01.opus"
    mx "\"Pero quizá ahora ya sepas cómo se siente, ¿mm?\""


translate english c7141_2c84cca1:


    "Habla como si la hubiera engañado con Aoi."


translate english c7141_f9eef90b:


    "No seas ridícula."


translate english c7141_49655f2e:


    "Claro, sabía que sentía algo por mí."


translate english c7141_6e197cbc:


    "Pero por eso siempre fui tan cuidadoso de mantener mi distancia."


translate english c7141_512f101f:



    voice "voice/c71/4100550a01.opus"
    mx "\"Así que cambié de opinión.\""


translate english c7141_b636b94e:



    voice "voice/c71/4100560a01.opus"
    mx "\"Sabía que Aoi escondía algo grande.\""


translate english c7141_c4af366b:



    voice "voice/c71/4100570a01.opus"
    mx "\"Y sabía que no tenías la intención de lastimarme.\""


translate english c7141_1a4540c9:



    voice "voice/c71/4100580a01.opus"
    mx "\"Así que decidí darte otra oportunidad.\""


translate english c7141_7c13d5c6:


    xy "\"¿Para qué...?\""


translate english c7141_e3062ebf:



    voice "voice/c71/4100590a01.opus"
    mx "\"Si no hubiera esparcido ese rumor ni te hubiera arrastrado a la tienda de la esquina, probablemente nunca te habrías dado cuenta...\""


translate english c7141_7dd5afb8:



    voice "voice/c71/4100600a01.opus"
    mx "\"...de que Aoi se estaba acostando con otro tipo.\""


translate english c7141_bf4fa52c:


    "Pensándolo bien... tiene razón."


translate english c7141_498ec6a9:


    "Miyuki era siempre la que me metía esas dudas en la cabeza."


translate english c7141_e9b4bbdd:



    voice "voice/c71/4100610a01.opus"
    mx "\"Cuando encontraste pruebas de su engaño en ese departamento y juraste vengarte, ay, estaba tan feliz que podía volar.\""


translate english c7141_e3c66e20:



    voice "voice/c71/4100620a01.opus"
    mx "\"Te ayudé a planearlo todo... Y siempre estuve ahí para consolarte, también.\""


translate english c7141_f1275105:



    voice "voice/c71/4100630a01.opus"
    mx "\"Durante toda la fiesta de cumpleaños de hoy, apenas podía contenerme. Fue la actuación más difícil que he tenido que dar.\""


translate english c7141_0928eba2:



    voice "voice/c71/4100640a01.opus"
    mx "\"Así que, naturalmente, cualquiera con medio cerebro querría un asiento en primera fila para el desastre, ¿no?\""


translate english c7141_9d57c967:



    voice "voice/c71/4100650a01.opus"
    mx "\"Esperé junto a las escaleras y escuché todo.\""


translate english c7141_5556e6d0:



    voice "voice/c71/4100660a01.opus"
    mx "\"Cuando Aoi salió de la sala, uy, sí que entré en pánico. Subí corriendo las escaleras y me escondí debajo de tu cama.\""


translate english c7141_b787e1e0:



    voice "voice/c71/4100670a01.opus"
    mx "\"Luego, cuando ella y Ryuujirou empezaron a tener sexo, bueno... no me lo esperaba, pero estaba en el cielo.\""


translate english c7141_eeaf7c80:



    voice "voice/c71/4100680a01.opus"
    mx "\"Pensé, esto significa que Shinichi la odiará con todas sus fuerzas.\""


translate english c7141_2574c426:



    voice "voice/c71/4100690a01.opus"
    mx "\"Por fin, mi sueño se haría realidad. Por fin, estaríamos juntos.\""


translate english c7141_a7db73e3:



    voice "voice/c71/4100700a01.opus"
    mx "\"Y lo creí hasta el mismísimo momento en que entraste al cuarto.\""


translate english c7141_05aaca55:



    voice "voice/c71/4100710a01.opus"
    mx "\"Así que, ¿puedes imaginarlo?\""


translate english c7141_64c4c05a:



    voice "voice/c71/4100720a01.opus"
    mx "\"¿Todo lo que pasó por mi cabeza mientras estaba ahí abajo?\""


translate english c7141_8a8463ec:



    voice "voice/c71/4100730a01.opus"
    mx "\"Digo, piénsalo. El amor de mi vida estaba a centímetros de mí, con la cara en la vagina de otra chica, chupando el semen de otro tipo.\""


translate english c7141_65522383:



    voice "voice/c71/4100740a01.opus"
    mx "\"Digo, ¿estabas TAN encaprichado con ella?\""


translate english c7141_23973af4:



    voice "voice/c71/4100750a01.opus"
    mx "\"No tenía poder. Todo lo que podía hacer era quedarme bajo la cama y rezar.\""


translate english c7141_5eb53ae1:



    voice "voice/c71/4100760a01.opus"
    mx "\"Creí en ti. Creí que al final me elegirías.\""


translate english c7141_fec84a9f:



    voice "voice/c71/4100770a01.opus"
    mx "\"Pero mientras tanto, todo lo que podía hacer era escuchar a ustedes idiotas dándole por horas y horas.\""


translate english c7141_dbfb4147:



    voice "voice/c71/4100780a01.opus"
    mx "\"—¡Basta!\""


translate english c7141_b58f0165:



    voice "voice/c71/4100790a01.opus"
    mx "\"—¡No le digas que la amas!\""


translate english c7141_3fd6d495:



    voice "voice/c71/4100800a01.opus"
    mx "\"Pero mis rezos cayeron en oídos sordos.\""


translate english c7141_903cbf39:



    voice "voice/c71/4100810a01.opus"
    mx "\"Entonces, ¿qué? ¿Qué era yo, hígado picado?\""


translate english c7141_a6a5762a:



    voice "voice/c71/4100820a01.opus"
    mx "\"¿Qué clase de idiota era, llorando en silencio lágrimas de alegría con la esperanza de que por fin estuviéramos juntos?\""


translate english c7141_7edb7c9d:



    voice "voice/c71/4100830a01.opus"
    mx "\"La persona que prometió amarme por siempre... me estaba traicionando, justo encima de mí. ¿Podrías mantener la cordura después de eso? ¡¿Podrías?!\""


translate english c7141_639a3ee3:


    "Mi cuerpo se niega a moverse."


translate english c7141_5edd6a65:


    "En absoluto."


translate english c7141_6be141ef:


    "Y nadie viene a salvarme."


translate english c7141_d3a29a43:


    "No se me ocurre ninguna forma de salir de esto."


translate english c7141_10f8eb08:


    "Miro de nuevo el cuerpo sin vida de Aoi."


translate english c7141_9918b2c1:


    "No sé qué hacer."


translate english c7141_b41fd282:


    "No entiendo."


translate english c7141_a8339e8a:


    xy "\"¿Por...?\""


translate english c7141_223aa633:


    xy "\"¿Por qué me haces esto...?\""


translate english c7141_83ca011d:



    voice "voice/c71/4100840a01.opus"
    mx "\"Rompiste nuestros votos.\""


translate english c7141_7daacfd8:



    voice "voice/c71/4100850a01.opus"
    mx "\"Eres un traidor. Te lo mereces, ¿no crees?\""


translate english c7141_7df6d5c8:


    xy "\"Te digo que nunca te trai—\""


translate english c7141_a973ae8f:



    voice "voice/c71/4100860a01.opus"
    mx "\"No estoy hablando contigo.\""


translate english c7141_b9935b2a:



    voice "voice/c71/4100870a01.opus"
    mx "\"Estoy hablando contigo, TÚ.\""


translate english c7141_17635f45:



    voice "voice/c71/4100880a01.opus"
    mx "\"TÚ fuiste quien me prometió amor eterno en la primera ruta.\""


translate english c7141_79d3c894:



    voice "voice/c71/4100890a01.opus"
    mx "\"¡Y TÚ fuiste quien tomó todas esas decisiones que Shinichi nunca habría tomado!\""


translate english c7141_c865fe30:


    "Miyuki... ¿Con quién estás hablando...?"


translate english c7141_d3d66b99:



    voice "voice/c71/4100900a01.opus"
    mx "\"Mira... TÚ te acuerdas, ¿verdad?\""


translate english c7141_83f25dd8:



    voice "voice/c71/4100910a01.opus"
    mx "\"Después de la obra, cuando nos juramos amor y compartimos un beso bajo el cielo estrellado...\""


translate english c7141_6a7c50a7:


    "¿Qué le pasa?"


translate english c7141_9fe5f2d7:


    "No puedo entender ni una sola cosa de lo que dice..."


translate english c7141_af45a3e6:



    voice "voice/c71/4100920a01.opus"
    mx "\"Se suponía que TÚ solo elegirías las opciones que llevaran a MI ruta.\""


translate english c7141_9f30864e:



    voice "voice/c71/4100930a01.opus"
    mx "\"¡Tenías un solo trabajo: amarme por siempre jamás!\""


translate english c7141_003bfffc:



    voice "voice/c71/4100940a01.opus"
    mx "\"¿TÚ te das cuenta... de cuánto me esforcé por mantenerte fuera de la ruta de Aoi? Seguro que sí, ¿verdad?\""


translate english c7141_34985677:



    voice "voice/c71/4100950a01.opus"
    mx "\"Entonces, ¿por qué no me correspondes?\""


translate english c7141_b80e1101:



    voice "voice/c71/4100960a01.opus"
    mx "\"¡Solo dilo! ¡Di que me amas más que a nadie!\""


translate english strings:


    old "Я люблю тебя"
    new "Te amo"


    old "Я тебя ненавижу"
    new "Te odio"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
