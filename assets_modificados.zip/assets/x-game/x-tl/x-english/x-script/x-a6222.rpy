

translate english a6222_a73c2c26:


    xy "\"Hey, Miyuki...\""


translate english a6222_8384f2b3:


    xy "\"Wanna climb up?\""


translate english a6222_488831b2:



    voice "voice/a62/2200010a01.opus"
    mx "\"...Sure.\""


translate english a6222_59844a25:


    "Guío a Miyuki por la escalera hasta la cima de la azotea."


translate english a6222_12e64a21:


    xy "\"......\""


translate english a6222_48cb9de0:



    voice "voice/a62/2200020a01.opus"
    mx "\"......\""


translate english a6222_447b0b29:


    "No hay palabras que empiecen a describirlo."


translate english a6222_51bc807b:


    "De mañana o de tarde, la vista desde aquí arriba es completamente hermosa, impresionante..."


translate english a6222_2148e4e1:


    "Pero la vista de noche supera a ambas con creces."


translate english a6222_6f9b12d2:


    xy "\"It really does feel like we're at the center of the universe, huh?\""


translate english a6222_a04a21e5:



    voice "voice/a62/2200030a01.opus"
    mx "\"I could believe it.\""


translate english a6222_bec20ccc:


    "La tierra y el cielo se han transformado cada uno en un mar de luces centelleantes."


translate english a6222_6480ed37:


    "Los dos nos encontramos demasiado absortos para notar el frío punzante."


translate english a6222_60a324cb:


    xy "\"Say, Miyuki?\""


translate english a6222_f9f24cb0:


    xy "\"Have you heard the school legend about the roof?\""


translate english a6222_8a8139fe:



    voice "voice/a62/2200040a01.opus"
    mx "\"What...? Th-There's a legend?!\""


translate english a6222_72d70607:


    "Las ardientes mejillas de Miyuki la delatan por completo."


translate english a6222_c7f80ed5:



    voice "voice/a62/2200050a01.opus"
    mx "\"Oh, right, that! Of course I've heard about it!\""


translate english a6222_a48ea487:



    voice "voice/a62/2200060a01.opus"
    mx "\"I get invited up here all the time, you know!\""


translate english a6222_3b43d46b:


    xy "\"Plus, it was the reason you first confessed your feelings to m—\""


translate english a6222_05533552:



    voice "voice/a62/2200070a01.opus"
    mx "\"I told you to forget that ever happened!\""


translate english a6222_e556a393:


    xy "\"Sorry.\""


translate english a6222_13a75528:


    "—Si dos personas comparten un beso en la azotea, su amor será eterno."


translate english a6222_e620f507:


    "Seguro que todas y cada una de las personas que van a nuestra escuela lo saben."


translate english a6222_adb82bf6:


    xy "\"Do you think it's true?\""


translate english a6222_d0167be1:



    voice "voice/a62/2200080a01.opus"
    mx "\"I don't believe in rumors.\""


translate english a6222_c856955d:



    voice "voice/a62/2200090a01.opus"
    mx "\"That's just not the sort of person I am.\""


translate english a6222_1ad6b858:



    voice "voice/a62/2200100a01.opus"
    mx "\"But... I guess... maybe... I'm willing to try...\""


translate english a6222_0833d2fb:


    xy "\"Did Aoi change your mind?\""


translate english a6222_3da22f4c:



    voice "voice/a62/2200110a01.opus"
    mx "\"\"\"......\"\"\""


translate english a6222_e90e451f:


    "Miyuki asiente."


translate english a6222_dd679b35:


    "Hace una pausa por un momento—"


translate english a6222_b166336c:


    "—luego me mira directo a los ojos."


translate english a6222_147a6269:



    voice "voice/a62/2200120a01.opus"
    mx "\"Listen, Shinichi...\""


translate english a6222_c259bf66:



    voice "voice/a62/2200130a01.opus"
    mx "\"Will you help me...\""


translate english a6222_92e27f97:



    voice "voice/a62/2200140a01.opus"
    mx "\"...make this place the center of my universe?\""


translate english a6222_SELECT_21db6d58:


    "Asiento con la cabeza y me acerco."



translate english a6222_SELECT_6728bd12:


    "Nos miramos a los ojos."



translate english a6222_SELECT_3fab1af9:


    "Sonríe, aliviada."



translate english a6222_SELECT_ebd6a075:


    "Esta es la verdadera Miyuki."



translate english a6222_SELECT_b3a8e80e:


    "La chica detrás del personaje del escenario."



translate english a6222_SELECT_2de4fd1d:


    "Y yo soy el único a quien se la muestra."



translate english a6222_SELECT_54c73e1d:


    "Cierra los ojos."



translate english a6222_SELECT_6e7ebd0a:


    "Suavemente la rodeo con mis brazos."



translate english a6222_SELECT_a2e6280b:


    "Respiración superficial."



translate english a6222_SELECT_33b3f9cc:


    "Piel sonrojada."



translate english a6222_SELECT_94dff8c4:


    "Magnetizado por su encanto—"



translate english a6222_SELECT_599c00bc:


    "—la beso."



translate english a6222_SELECT_01c05c23:


    "Nos hemos amado durante tanto tiempo."



translate english a6222_SELECT_27875467:


    "Y hemos intentado ocultarlo todo este tiempo."



translate english a6222_SELECT_bb82e2a9:


    "Pero ahora nuestro beso nos unirá por la eternidad."



translate english a6222_SELECT_a6ddbab8:


    "Mi corazón late de alegría mientras mis sentidos empiezan a desvanecerse... hasta que lo único que queda es Miyuki."



translate english a6222_SELECT_911c663c:


    "Siento que estoy en la gloria..."



translate english a6222_SELECT_7be03a1a:


    "...o flotando en el espacio."



translate english a6222_SELECT_b62966fe:



    voice "voice/a62/2200150a01.opus"
    mx "\"Promise me...\""



translate english a6222_SELECT_cad8ed36:



    voice "voice/a62/2200160a01.opus"
    mx "\"Promise me you'll never let me go, Shinichi.\""



translate english strings:


    old "Кивнуть"
    new "Asentir"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
