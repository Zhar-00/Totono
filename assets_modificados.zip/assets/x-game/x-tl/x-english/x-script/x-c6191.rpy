

translate english c6191_324e19b7:



    voice "voice/c61/9100010a02.opus"
    aoi "\"Shinichi?\""


translate english c6191_545367b3:


    xy "\"...What?\""


translate english c6191_65bf0572:



    voice "voice/c61/9100020a02.opus"
    aoi "\"Question!\""


translate english c6191_0cf3fffe:


    "Aoi me sonríe radiantemente."


translate english c6191_6d50621f:



    voice "voice/c61/9100030a02.opus"
    aoi "\"Is there anything you want real bad?\""


translate english c6191_5df275c3:


    xy "\"What do you mean?\""


translate english c6191_c993ea5a:



    voice "voice/c61/9100040a02.opus"
    aoi "\"Anything you'd really like to get as a gift?\""


translate english c6191_f2545062:



    voice "voice/c61/9100050a02.opus"
    aoi "\"Like when you gave me this hairpin.\""


translate english c6191_85dd2acb:


    "Aoi saca un pasador de gatito de su bolsillo. En efecto, se ve exactamente como el que le di."


translate english c6191_5276096e:


    "Siempre decía que lo cuidaría bien."


translate english c6191_4acdb5f7:


    "Pero... ¿es realmente el mismo?"


translate english c6191_c632ea3f:



    voice "voice/c61/9100060a02.opus"
    aoi "\"...Shinichi?\""


translate english c6191_260bf132:


    xy "\"What brought this on all of a sudden?\""


translate english c6191_8ab019ac:



    voice "voice/c61/9100070a02.opus"
    aoi "\"Huh? Oh, nothing... Just... um...\""


translate english c6191_8e200f11:



    voice "voice/c61/9100080a02.opus"
    aoi "\"Aoi wants to know more about you.\""


translate english c6191_ecffd538:


    xy "\"Ah. I see.\""


translate english c6191_65911237:


    xy "\"It's kinda hard to answer on the spot...\""


translate english c6191_6155e7e2:



    voice "voice/c61/9100090a02.opus"
    aoi "\"Think long and hard about it!\""


translate english c6191_fc693277:



    voice "voice/c61/9100100a02.opus"
    aoi "\"There's gotta be something you want!\""


translate english c6191_9bfb7f6d:


    xy "\"Let's see...\""


translate english c6191_d4f9db5b:


    "Una respuesta en broma me viene a la mente."


translate english c6191_f87ab162:


    xy "\"Someone who will love me forever, I guess?\""


translate english c6191_7083f428:



    voice "voice/c61/9100110a02.opus"
    aoi "\"Boop boop...?\""


translate english c6191_33616894:


    "Aoi se sonroja ligeramente."


translate english c6191_bbeb1010:



    voice "voice/c61/9100120a02.opus"
    aoi "\"Yeah... That sounds good to me, too.\""


translate english c6191_070fb704:


    xy "\"Let's go with that, then.\""


translate english c6191_9c9311b1:



    voice "voice/c61/9100130a02.opus"
    aoi "\"Okay...\""


translate english c6191_ce622865:



    voice "voice/c61/9100140a02.opus"
    aoi "\"Boop boop?\""


translate english c6191_134d134b:


    "Hace una pausa, luego ladea la cabeza."


translate english c6191_fadfaa35:



    voice "voice/c61/9100150a02.opus"
    aoi "\"That's not a gift!\""


translate english c6191_10213da3:



    voice "voice/c61/9100160a02.opus"
    aoi "\"Isn't there anything else?\""


translate english c6191_9d72a322:


    xy "\"Like I said, it's hard to think of anything when you put me on the spot...\""


translate english c6191_fb33a46a:


    xy "\"Like... If I asked you what YOU want—\""


translate english c6191_2b07e310:



    voice "voice/c61/9100170a02.opus"
    aoi "\"Shinichi!\""


translate english c6191_59f9c40e:


    xy "\"Whoa!\""


translate english c6191_65c168d7:


    "Me retiro, pero Aoi se aferra a mí de todos modos."


translate english c6191_3d260ede:



    voice "voice/c61/9100180a02.opus"
    aoi "\"Aoi wants Shinichi!\""


translate english c6191_0a2981ab:



    voice "voice/c61/9100190a02.opus"
    aoi "\"Aoi just... loves you... so much...\""


translate english c6191_d1ebe3af:



    voice "voice/c61/9100200a02.opus"
    aoi "\"Aoi doesn't need anything else.\""


translate english c6191_281e26d0:


    "Me mira con amor en los ojos."


translate english c6191_504ada3f:


    "El atardecer me deslumbra."


translate english c6191_79ba502a:


    "Me siento mareado."


translate english c6191_2766a9e0:


    "Mi cerebro se sacude dentro de mi cabeza."


translate english c6191_2eea4f38:


    "Podría perderlo por completo."


translate english c6191_b96a1fd1:



    voice "voice/c61/9100210a02.opus"
    aoi "\"Aoi loves you...\""


translate english c6191_febd2d90:


    "Su mano se desliza por mi espalda."


translate english c6191_3ec72b06:



    voice "voice/c61/9100220a02.opus"
    aoi "\"Let's...\""


translate english c6191_f30f745a:


    "Me frota el culo."


translate english c6191_75e04183:



    voice "voice/c61/9100230a02.opus"
    aoi "\"...have sex...\""


translate english c6191_7fdc9d9a:


    "Justo entonces, mi bolsillo vibra."


translate english c6191_d8ef8487:


    xy "\"Mmm, sorry!\""


translate english c6191_3d78872e:


    "La aparto y saco apresuradamente mi teléfono."


translate english c6191_5f441c5b:


    "Es un correo de Miyuki."


translate english c6191_9e7170c6:


    "Y si Aoi supiera lo que dice, todo se vendría abajo."


translate english c6191_c04942b9:



    voice "voice/c61/9100240a02.opus"
    aoi "\"Shinichi...?\""


translate english c6191_b70391d4:


    xy "\"Sorry, Miyuki wants to see me.\""


translate english c6191_0af9ef8b:



    voice "voice/c61/9100250a02.opus"
    aoi "\"Umm... What about your gift...?\""


translate english c6191_8cdae425:


    xy "\"Just get me whatever!\""


translate english c6191_157fd6c4:


    xy "\"Get me something you'd like!\""


translate english c6191_fef71315:



    voice "voice/c61/9100260a02.opus"
    aoi "\"Something Aoi would like...?\""


translate english c6191_2813bdcd:


    xy "\"Anyway, see ya!\""


translate english c6191_3aa01884:


    "Con eso, bajo corriendo la escalera."


translate english c6191_f429ef20:



    voice "voice/c61/9100270a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c6191_a9801a28:


    "Por encima de mí, puedo oírla débilmente empezar a \"transmitting\"."



translate english c6191_37918acd:


    xy "\"...Hrrkk...\""


translate english c6191_7fac5a4e:


    "En el instante en que la puerta se cierra—"


translate english c6191_23a0f6b9:


    xy "\"Urp... hhgg... hhhllllggggg!!!\""


translate english c6191_fdc4388f:


    "Mi náusea me abruma."


translate english c6191_44c0dab8:


    xy "\"Guh... nng... hhhggg... nnnn...\""


translate english c6191_9bafc574:



    voice "voice/c61/9100280a01.opus"
    mx "\"Shinichi? You okay?\""


translate english c6191_9b600985:


    xy "\"Nnggh... nnn... Miyuki...\""


translate english c6191_c3fe74a7:


    "Miyuki debió haber estado mirando todo el asunto."


translate english c6191_ebe9ab99:


    "Me frota suavemente la espalda."


translate english c6191_9059fd45:


    xy "\"Nngh... Sorry about that...\""


translate english c6191_4f5361d7:


    xy "\"Whenever she touches me... I just get so... Hggh!\""


translate english c6191_68c10b61:


    "El recuerdo de su sonrisa amenaza con hacerme vomitar de nuevo."


translate english c6191_a00a88ff:


    "Cuando puso sus brazos alrededor de mí, me hizo erizar la piel."


translate english c6191_07691fa9:


    "Después de todo, sé lo que hizo con esas manos..."


translate english c6191_150f82e5:


    "Las usó para... tocar a otro chico..."


translate english c6191_ed4749fc:



    voice "voice/c61/9100290a01.opus"
    mx "\"Just take it easy, okay?\""


translate english c6191_12358161:


    xy "\"...Thanks.\""


translate english c6191_229fdf07:


    "Miyuki me consuela e incluso limpia el desastre que hice."


translate english c6191_6817594a:


    "Sin ella, estoy seguro de que ya habría perdido la cabeza por completo."


translate english c6191_2c8cd394:


    xy "\"So, I got your email. What did you want to talk about?\""


translate english c6191_614eb912:


    xy "\"Did you find out how she got another one of these?\""


translate english c6191_67a4f966:


    "Saco el pasador de gatito de mi bolsillo."


translate english c6191_fb2644e8:


    "Esta es la prueba de que me traicionó."


translate english c6191_ebe41ecf:


    "Y sin embargo, de alguna manera tiene un pasador casi idéntico en su posesión."


translate english c6191_7c3f645f:



    voice "voice/c61/9100300a01.opus"
    mx "\"I confirmed it with Catnip. These pins are handmade and one-of-a-kind.\""


translate english c6191_12569322:



    voice "voice/c61/9100310a01.opus"
    mx "\"And Aoi showed up to buy one the same day they restocked.\""


translate english c6191_65969c88:


    "...Eso lo decide todo."


translate english c6191_c2c32e8b:


    "Contengo mi náusea—"


translate english c6191_4ccd4655:


    xy "\"Okay... I've made up my mind. You know that idea you had?\""


translate english c6191_fd46b99e:


    xy "\"Let's do it.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
