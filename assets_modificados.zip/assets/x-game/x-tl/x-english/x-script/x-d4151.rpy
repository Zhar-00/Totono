

translate english d4151_7bec3e08:


    "Esa fue la última vez que vi a Aoi antes de que desapareciera."


translate english d4151_3c027f7e:



    voice "voice/d41/5100010a01.opus"
    mx "\"I bet she adopted that cat. That's why she's ghosting us.\""


translate english d4151_21aaad28:



    voice "voice/d41/5100020a01.opus"
    mx "\"...This is my fault.\""


translate english d4151_8708b557:


    "Miyuki estuvo decaída durante mucho tiempo después de eso."


translate english d4151_9c330415:


    "Pero en cuanto a mí, tengo que creer que su desaparición fue más que solo eso..."


translate english d4151_8aec3f2d:


    "Tiene que haber alguna otra razón... Algo que no entendemos..."


translate english d4151_30297148:


    "Pero incluso sin Aoi cerca, mi relación con Miyuki se mantuvo fuerte."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
