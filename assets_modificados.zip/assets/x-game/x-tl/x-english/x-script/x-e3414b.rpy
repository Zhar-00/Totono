

translate english e3414b_7379456a:


    xy "\"No voy a ningún lado.\""


translate english e3414b_12ec8d80:



    voice "voice/e34/14b00010a01.opus"
    mx "\"Tu cerebro no está completamente despierto todavía, ¿verdad?\""


translate english e3414b_54a01e02:


    "Sí, quizá no."


translate english e3414b_8f47fe20:


    "Es un complejo de departamentos con portón."


translate english e3414b_f38b6262:


    "No hay forma de que un gato callejero se haya colado en el pasillo... y si está fuera del edificio, entonces no debería haber podido oírlo en primer lugar."


translate english e3414b_63795a78:


    "Debo haber estado oyendo cosas. Probablemente solo sea el hijo de algún vecino llorando."


translate english e3414b_8ce1c36f:


    "Suspiro y me doy la vuelta."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
