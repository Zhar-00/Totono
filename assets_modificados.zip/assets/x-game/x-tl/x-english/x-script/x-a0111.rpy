

translate english a0111_bf11a8a6:


    "En lo alto de la escalera, salgo al deslumbrante atardecer."


translate english a0111_3f9bf9ff:


    "Esta es la azotea de la escuela. A la mayoría de los estudiantes se les niega la entrada."


translate english a0111_dad2c43b:


    "Uno pensaría que ya estaría acostumbrado a la vista desde aquí arriba, pero al parecer basta con unas horas de diferencia para que el mundo luzca como nuevo."


translate english a0111_df2fef3d:


    xy "\"Yuutarou? You up here?\""


translate english a0111_dfffcbac:


    "Sin respuesta."


translate english a0111_c7c32ace:


    "Lo único que me recibe es la apacible brisa otoñal."


translate english a0111_af58fdd6:


    "Ha brotado hierba entre las grietas del concreto, y la pila de pupitres al otro lado se está oxidando por la exposición a la intemperie."


translate english a0111_949c6185:


    "Aquí arriba, casi se siente como un lugar olvidado, perdido en el tiempo."



translate english a0111_ddc2f6e6:


    "Me encanta."


translate english a0111_3f89ed5e:


    "En concreto, me encanta la vista de 360 grados del pueblo allá abajo."


translate english a0111_34ae9b33:


    "He vivido toda mi vida aquí. Cada centímetro de este pueblo está lleno de recuerdos nostálgicos."


translate english a0111_c00f058e:


    "Cuanto más lo contemplo, más tranquilo me siento."


translate english a0111_a36441c6:


    "Cuando me votaron al azar para el comité de limpieza del campus, no estaba precisamente entusiasmado... Pero si hubiera conocido antes esta pequeña ventaja, quizá me habría ofrecido como voluntario."



translate english a0111_83956a09:


    "Solo se permite el acceso a la azotea a dos grupos: el club de astronomía (para observar las estrellas) y el comité de limpieza (para subir y bajar pupitres)."


translate english a0111_eddcbe54:


    "Dicho esto, me han contado que hay un montón de llaves de repuesto dando vueltas si sabes dónde buscar."


translate english a0111_8c3ca76f:


    "La azotea de la escuela tiene cierta leyenda, ¿sabes?"


translate english a0111_96a1ddaf:


    "Como resultado, de vez en cuando otros estudiantes me piden que les abra la puerta."


translate english a0111_7c5d3153:


    "Por eso estoy aquí arriba hoy, a petición de mi amigo Yuutarou."


translate english a0111_f77b7e77:


    "Por desgracia, parece que llega tarde—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
