

translate english a0131_54a02f96:


    "Mukou Aoi..."


translate english a0131_4a1e5475:


    "El nombre no me suena para nada."


translate english a0131_2bb5d3ad:


    "Para ser honesto, no soy muy sociable."


translate english a0131_917b00e9:


    "Soy bastante torpe en lo social."


translate english a0131_1b3a19c3:


    "O sea, ya llevamos casi seis meses y todavía no sé los nombres de todas las chicas de nuestra clase."


translate english a0131_4f1da032:


    "¿Pero esa despistada de primera?"



translate english a0131_8d5a411a:


    "Es difícil creer que pudiera olvidar a alguien tan... única... como ella."


translate english a0131_10a82463:


    xy "\"Haah...\""


translate english a0131_3db00e0f:


    "Me meto a la cama."


translate english a0131_40b9fb2f:



    voice "voice/a01/3100010a02.opus"
    aoi "\"Wanna... get zappy?\""


translate english a0131_56f66454:


    "Allá atrás, en la azotea..."


translate english a0131_2e186744:


    "Todo, desde su pose hasta su apariencia..."


translate english a0131_f9e3c882:


    "Y todo lo que dijo..."


translate english a0131_e3a5c17e:


    "Era idéntico a esa escena del juego para móvil."


translate english a0131_085452ab:


    "Casi como si hubiera saltado de la pantalla a la vida real."


translate english a0131_bd6f584d:


    "And the protagonist's name was \"Susuki Shinichi,\"también..."


translate english a0131_9d09f1c0:


    "No, no puede ser."


translate english a0131_56e6b0f9:


    "No tengo el poder de convertir los videojuegos en realidad, ¿o sí...?"


translate english a0131_e65d36ad:


    xy "\"Whoa there, buddy.\""


translate english a0131_9fe7a5eb:


    "¡Ahora YO soy el que tiene el cerebro de gamer!"


translate english a0131_69272594:


    "Esa novela visual estaba en el teléfono de Mukou."


translate english a0131_7bc7428f:


    "Probablemente se sabe todos los diálogos de memoria."


translate english a0131_d563f316:


    "¡Probablemente solo lo estaba actuando!"


translate english a0131_c3271f99:


    "¡Y probablemente puso el nombre del protagonista como el mío a propósito!"


translate english a0131_0e11ab73:


    "...¿Pero por qué?"


translate english a0131_dc5a0714:


    xy "\"Forget it.\""


translate english a0131_9d5427d9:


    "Estoy dejando que mi imaginación se desboque."


translate english a0131_36f5951c:


    "Me tapo la cabeza con la cobija y aprieto los ojos."


translate english a0131_bf0d2aa0:


    "Esa noche, en mis sueños, veo a Miyuki..."


translate english a0131_83ee3581:


    "...y nos besamos."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
