

translate english e1166b_6a14c3f6:


    "De alguna manera, Dios respondió a mis plegarias."


translate english e1166b_8badc3f3:


    "Mis dedos se mueven solos para introducir—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
