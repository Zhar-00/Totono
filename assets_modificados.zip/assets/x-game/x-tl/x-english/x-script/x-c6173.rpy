

translate english c6173_2cd9d565:



    voice "voice/c61/7300010b01.opus"
    xtl "\"Creo que, en el fondo, lo sabía.\""


translate english c6173_acfe6e3f:


    "Yuutarou articula las palabras con dificultad."


translate english c6173_a508904e:



    voice "voice/c61/7300020b01.opus"
    xtl "\"¿Te acuerdas de cuando te dije que Ryuujirou se consiguió novia?\""


translate english c6173_91295d5a:



    voice "voice/c61/7300030b01.opus"
    xtl "\"Pensándolo bien, fue justo cuando Mukou empezó a pasar por la tienda.\""


translate english c6173_0e144fcd:



    voice "voice/c61/7300040b01.opus"
    xtl "\"Últimamente pasan mucho tiempo juntos por ahí.\""


translate english c6173_0accd139:


    xy "\"......\""


translate english c6173_e0bd8cdb:


    "A Aoi se la veía a menudo visitando Catnip con un amigo..."


translate english c6173_4188e583:



    voice "voice/c61/7300050b01.opus"
    xtl "\"Y a Ryuujirou le encantan las novelas visuales, los juegos y esas cosas, así que tienen unas conversaciones intensísimas...\""


translate english c6173_0accd139_1:


    xy "\"......\""


translate english c6173_ac001639:



    voice "voice/c61/7300060a01.opus"
    mx "\"¡Shinichi! ¡Reacciona!\""


translate english c6173_cc61f676:


    xy "\"¿Miyuki...?\""



translate english c6173_4d9cf1b0:



    voice "voice/c61/7300070a01.opus"
    mx "\"Aoi te mintió y canceló sus planes de cita para estar con otro chico. Pero eso es todo lo que sabemos con certeza.\""


translate english c6173_9608934d:



    voice "voice/c61/7300080a01.opus"
    mx "\"No tenemos pruebas de que en realidad te esté engañando.\""


translate english c6173_4a45e348:


    "Engaño."


translate english c6173_be4b7fcc:


    "Mi vista se nubla."


translate english c6173_d0aba525:


    "Quizás los rumores tenían razón."


translate english c6173_26da047c:


    "Me engañó... me traicionó... y ahora está con otro tipo..."


translate english c6173_eb6ee636:



    voice "voice/c61/7300090a02.opus"
    aoi "\"Aoi necesita que te creas todo.\""


translate english c6173_7fec02a7:


    xy "\"Esto... Esto no puede ser real...\""


translate english c6173_af500c40:



    voice "voice/c61/7300100a01.opus"
    mx "\"Tus sentimientos pueden esperar hasta que averigües la verdad.\""


translate english c6173_cd05d73e:



    voice "voice/c61/7300110a01.opus"
    mx "\"Vamos.\""


translate english c6173_833a4a2b:


    "Cegado por la desesperación, la voz de Miyuki es la única luz guía que queda en mi oscuridad."


translate english c6173_1c06b67a:


    "Aferrándome a esa tenue esperanza, camino por el camino."


translate english c6173_c1d3be2b:



    voice "voice/c61/7300120b01.opus"
    xtl "\"Ryuujirou no contesta el teléfono, así que este es el único lugar que se me ocurre revisar.\""


translate english c6173_857dfc92:



    voice "voice/c61/7300130b01.opus"
    xtl "\"Comparte un departamento aquí con una amiga modelo. Es su \"vestidor\", o lo que sea...\""



translate english c6173_194f8d9d:



    voice "voice/c61/7300140a01.opus"
    mx "\"¿Aquí?\""


translate english c6173_e05c228d:



    voice "voice/c61/7300150b01.opus"
    xtl "\"Sí. Al parecer su amiga está en la cima de la popularidad.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
