

translate english c6173_2cd9d565:



    voice "voice/c61/7300010b01.opus"
    xtl "\"I think, deep down, I knew.\""


translate english c6173_acfe6e3f:


    "Yuutarou articula las palabras con dificultad."


translate english c6173_a508904e:



    voice "voice/c61/7300020b01.opus"
    xtl "\"Remember when I told you Ryuujirou got himself a girlfriend?\""


translate english c6173_91295d5a:



    voice "voice/c61/7300030b01.opus"
    xtl "\"Thinking back, that was right around the time Mukou started coming by the store.\""


translate english c6173_0e144fcd:



    voice "voice/c61/7300040b01.opus"
    xtl "\"Lately they've been spending a lot of time out and about together.\""


translate english c6173_0accd139:


    xy "\"......\""


translate english c6173_e0bd8cdb:


    "A Aoi se la veía a menudo visitando Catnip con un amigo..."


translate english c6173_4188e583:



    voice "voice/c61/7300050b01.opus"
    xtl "\"And Ryuujirou's a big fan of visual novels and games and stuff, so they'd have all these intense conversations...\""


translate english c6173_0accd139_1:


    xy "\"......\""


translate english c6173_ac001639:



    voice "voice/c61/7300060a01.opus"
    mx "\"Shinichi! Pull yourself together!\""


translate english c6173_cc61f676:


    xy "\"Miyuki...?\""



translate english c6173_4d9cf1b0:



    voice "voice/c61/7300070a01.opus"
    mx "\"Aoi lied to you and broke off your date plans in order to be with another guy. But that's all we know for sure.\""


translate english c6173_9608934d:



    voice "voice/c61/7300080a01.opus"
    mx "\"We don't have proof that she's actually cheating.\""


translate english c6173_4a45e348:


    "Engaño."


translate english c6173_be4b7fcc:


    "Mi vista se nubla."


translate english c6173_d0aba525:


    "Quizás los rumores tenían razón."


translate english c6173_26da047c:


    "Me engañó... me traicionó... y ahora está con otro tipo..."


translate english c6173_eb6ee636:



    voice "voice/c61/7300090a02.opus"
    aoi "\"Aoi needs you to believe everything.\""


translate english c6173_7fec02a7:


    xy "\"This... This can't be real...\""


translate english c6173_af500c40:



    voice "voice/c61/7300100a01.opus"
    mx "\"Your feelings can wait until after you learn the truth.\""


translate english c6173_cd05d73e:



    voice "voice/c61/7300110a01.opus"
    mx "\"Let's go.\""


translate english c6173_833a4a2b:


    "Cegado por la desesperación, la voz de Miyuki es la única luz guía que queda en mi oscuridad."


translate english c6173_1c06b67a:


    "Aferrándome a esa tenue esperanza, camino por el camino."


translate english c6173_c1d3be2b:



    voice "voice/c61/7300120b01.opus"
    xtl "\"Ryuujirou's not answering his phone, so this is the only place I can think of to check.\""


translate english c6173_857dfc92:



    voice "voice/c61/7300130b01.opus"
    xtl "\"He shares an apartment here with one of his model friends. It's their 'dressing room,' or whatever...\""



translate english c6173_194f8d9d:



    voice "voice/c61/7300140a01.opus"
    mx "\"Here?\""


translate english c6173_e05c228d:



    voice "voice/c61/7300150b01.opus"
    xtl "\"Yeah. His friend's at the height of popularity, apparently.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
