

translate english a1141_0accd139:


    xy "\"......\""


translate english a1141_8e1024f0:


    "Acostado en la cama, miro mi teléfono."


translate english a1141_50a74014:


    "La pequeña y solitaria Aoi, sin un solo amigo..."


translate english a1141_ab1a4c51:


    "Ni siquiera sabe qué son los amigos."


translate english a1141_64f2444f:


    "Quizá esto sea el destino."


translate english a1141_9b0ee546:


    "Al menos me gustaría que tuviera a alguien con quien charlar en la escuela por la mañana..."


translate english a1141_06070001:


    "La verdad, quizá debería meterme en mis propios asuntos, pero no puedo evitarlo."


translate english a1141_2cddaf94:


    "Pensándolo bien, todavía no he recibido ese correo que intenté enviarme desde su teléfono."


translate english a1141_154fef76:


    "Y le envié unos cuantos después de clases, pero nada..."


translate english a1141_8d48f3ce:


    "Como experimento, pulso el botón de llamar."


translate english a1141_74e50dbb:


    "...No contesta."


translate english a1141_f3ec483d:


    "¿De verdad su teléfono no tiene nada de señal?"


translate english a1141_91b83b48:


    "Puedo imaginarla de pie allá arriba, en la azotea sobre las escaleras..."


translate english a1141_850953c2:


    "It's painfully ironic that the self-styled \"transceiver girl\"sea la única que no capta ninguna señal."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
