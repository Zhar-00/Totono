

translate english z2114_6e684743:



    voice "voice/z21/1400010a01.opus"
    mx "...Ha pasado un tiempo, ¿no?"


translate english z2114_aa402bbd:



    voice "voice/z21/1400020a01.opus"
    mx "¿Sigues siendo la misma persona que eras entonces?"


translate english z2114_98e3eb29:



    voice "voice/z21/1400030a01.opus"
    mx "......Cierto."


translate english z2114_111773cb:



    voice "voice/z21/1400040a01.opus"
    mx "Claro. Después de todo, ha pasado mucho tiempo."


translate english z2114_b6879e59:



    voice "voice/z21/1400050a01.opus"
    mx "¿Quizás tienes un teléfono nuevo?"



translate english z2114_ae487460:



    voice "voice/z21/1400060a01.opus"
    mx "...Admito que todavía no sé mucho sobre tu mundo."


translate english z2114_50e7b8ce:



    voice "voice/z21/1400070a01.opus"
    mx "Pero... está bien."


translate english z2114_11ee17bf:



    voice "voice/z21/1400080a01.opus"
    mx "Después de todo ese tiempo que pasé esperando..."


translate english z2114_6af35cce:



    voice "voice/z21/1400090a01.opus"
    mx "Me lo compensarás, ¿no?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
