

translate english d6151_14557ad0:


    "Entrego mi boleto y entro al oscuro gimnasio."


translate english d6151_90104264:


    "Por suerte, llegué aquí con mucho tiempo de sobra."


translate english d6151_bace5bfc:


    "Los asientos del auditorio están solo a medio llenar."


translate english d6151_cbe451ae:



    voice "voice/d61/5100010a01.opus"
    mx "\"¡Oh, ya estás aquí!\""


translate english d6151_c43fcf73:


    xy "\"Oye, Miyuki... ¿Ya tienen todo listo allá atrás?\""


translate english d6151_3e0eed80:



    voice "voice/d61/5100020a01.opus"
    mx "\"Ya te dije que renuncié a la obra, ¿recuerdas? Ni siquiera necesito estar aquí en primer lugar.\""


translate english d6151_fbafec1f:



    voice "voice/d61/5100030a01.opus"
    mx "\"En fin, ¿dónde está Aoi?\""


translate english d6151_d7a6c859:



    voice "voice/d61/5100040a01.opus"
    mx "\"¿Sí la invitaste, verdad?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
