

translate english a3152a_99a66a15:



    voice "voice/a31/52a00010a02.opus"
    aoi "\"Oh!\""


translate english a3152a_1d03fc99:


    "Ella no está prestando atención."


translate english a3152a_e92ac44b:



    voice "voice/a31/52a00020a02.opus"
    aoi "\"There's a box!\""


translate english a3152a_69fb81e1:


    xy "\"That... sure is a box, yep...\""


translate english a3152a_72222efc:



    voice "voice/a31/52a00030a01.opus"
    mx "\"And? What about i—\""


translate english a3152a_6d3f0d77:


    "Justo entonces, oímos un pequeño miau desde adentro."


translate english a3152a_8c423ce5:


    "Y así, la furia de Miyuki se evapora."


translate english a3152a_f5f5d43e:



    voice "voice/a31/52a00050a02.opus"
    aoi "\"Time to open it.\""


translate english a3152a_022c1c97:



    voice "voice/a31/52a00060a01.opus"
    mx "\"Wait! Don't you d—\""


translate english a3152a_3a6b4b74:



    voice "voice/a31/52a00080a01.opus"
    mx "\"Aaah!\""


translate english a3152a_d2795efd:



    voice "voice/a31/52a00090a02.opus"
    aoi "\"Is it a kitty?\""


translate english a3152a_ec49ae17:


    xy "\"That... sure is a cat, yep...\""


translate english a3152a_f2f06c27:



    voice "voice/a31/52a00100a01.opus"
    mx "\"I... I'm not looking! I'M NOT LOOKING!\""


translate english a3152a_6241c201:


    xy "\"A teeny tiny little black kitten.\""


translate english a3152a_5cb6a887:


    xy "\"Oh, wait, there's a streak of white on its forehead...\""


translate english a3152a_53ccd861:



    voice "voice/a31/52a00110a02.opus"
    aoi "\"Looks like a thunderbolt.\""


translate english a3152a_cbb30321:



    voice "voice/a31/52a00120a01.opus"
    mx "\"Y-You don't have to describe it to me!\""


translate english a3152a_1f46598f:



    voice "voice/a31/52a00130a02.opus"
    aoi "\"Eru! Let's show Miyuki your little face!\""


translate english a3152a_da5b7134:



    voice "voice/a31/52a00140a01.opus"
    mx "\"Oh god, don't NAME IT!\""


translate english a3152a_14a2aa2a:


    "Miyuki chilla, con el rostro enterrado en las manos, mientras Aoi levanta al gatito en su dirección."


translate english a3152a_6c7bfc5d:



    voice "voice/a31/52a00150a02.opus"
    aoi "\"Don't you wanna see?\""


translate english a3152a_53ad182a:



    voice "voice/a31/52a00160a01.opus"
    mx "\"Aaagh! Please don't!\""


translate english a3152a_b5213dd4:



    voice "voice/a31/52a00170a02.opus"
    aoi "\"Look at the cute kitten.\""


translate english a3152a_78bc95f9:



    voice "voice/a31/52a00180a02.opus"
    aoi "\"Cute is justice!\""


translate english a3152a_e877a387:



    voice "voice/a31/52a00190a01.opus"
    mx "\"I don't want to! I don't want to see anyth—\""


translate english a3152a_018b4c0a:



    voice "voice/a31/52a00200a01.opus"
    mx "\"Aachoo!\""


translate english a3152a_8e4c6206:


    "Estornuda fuerte, y la fuerza la hace sacar la cara de entre las manos."


translate english a3152a_60ee7bde:



    voice "voice/a31/52a00210a01.opus"
    mx "\"...Oh...\""


translate english a3152a_6f209719:



    voice "voice/a31/52a00220a02.opus"
    aoi "\"She saw.\""


translate english a3152a_31c14bf1:


    "La mirada de ojos abiertos de Miyuki está fascinada con el gatito."


translate english a3152a_b6365db6:


    "Parece como si fuera a abalanzarse sobre él en cualquier momento..."


translate english a3152a_414a477f:



    voice "voice/a31/52a00240a01.opus"
    mx "\"It's so... so...\""


translate english a3152a_1a883675:



    voice "voice/a31/52a00250a01.opus"
    mx "\"So cu—aaaachoo!\""


translate english a3152a_107e7b13:



    voice "voice/a31/52a00260a02.opus"
    aoi "\"Boop boop...? Are you sick?\""


translate english a3152a_63102c75:



    voice "voice/a31/52a00270a01.opus"
    mx "\"I'm just allergic, that's all.\""


translate english a3152a_ad8bfff5:


    "Miyuki sorbe por la nariz."


translate english a3152a_b5c5d859:



    voice "voice/a31/52a00280a01.opus"
    mx "\"Sadly, I could never own a cat. C'mon, Shinichi, let's go.\""


translate english a3152a_f2751cbf:


    xy "\"Huh? But...\""


translate english a3152a_bcc41e13:



    voice "voice/a31/52a00290a02.opus"
    aoi "\"Wait! Don't you d—\""


translate english a3152a_5b4cfb85:


    xy "\"The hell do you think you're doing?\""


translate english a3152a_0e58a4f5:


    "Aparto los ojos de ella por dos segundos y ya se está poniendo las orejas de gato de su mameluco..."


translate english a3152a_f66b0c0a:



    voice "voice/a31/52a00300a02.opus"
    aoi "\"I'm the mommy cat.\""


translate english a3152a_ad25b5eb:


    xy "\"Nice try. Cats don't talk. They meow.\""


translate english a3152a_1ac3866e:



    voice "voice/a31/52a00310a02.opus"
    aoi "\"Boop boop...\""


translate english a3152a_317def1e:


    "Aoi se mira a sí misma con el ceño fruncido por un momento."


translate english a3152a_5bb6d4f2:



    voice "voice/a31/52a00320a02.opus"
    aoi "\"Meow! I'm the mommy cat.\""


translate english a3152a_fdcb9225:


    "Recuerdo esto..."


translate english a3152a_e6ac9b6b:


    "Esto mismo pasó exactamente en ese juego también..."


translate english a3152a_4d3596b2:



    voice "voice/a31/52a00330a02.opus"
    aoi "\"That day we went to Catnip, Aoi realized you're a super mega cat fanatic, meow!\""


translate english a3152a_1d2e4c0c:



    voice "voice/a31/52a00340a02.opus"
    aoi "\"That's why you're going to help me, Miyuki! Purrrr!\""


translate english a3152a_6991d20e:



    voice "voice/a31/52a00350a01.opus"
    mx "\"I refuse.\""


translate english a3152a_d21dbd9f:



    voice "voice/a31/52a00360a02.opus"
    aoi "\"Boop boop...? Are you sick?\""


translate english a3152a_5c4e7616:


    "El tono de Miyuki es sorprendentemente gélido."


translate english a3152a_7b399620:



    voice "voice/a31/52a00370a01.opus"
    mx "\"Do you have a place for this cat to live? The manga cafe doesn't allow pets, you know.\""


translate english a3152a_83db28fc:



    voice "voice/a31/52a00380a02.opus"
    aoi "\"Um...\""


translate english a3152a_ed062311:



    voice "voice/a31/52a00390a01.opus"
    mx "\"Are you going back to your parents' house, then? Will you beg them to let you both stay?\""


translate english a3152a_8ca08fb6:



    voice "voice/a31/52a00400a02.opus"
    aoi "\"Boop boop... But Miyuki...\""


translate english a3152a_3932c83d:



    voice "voice/a31/52a00410a02.opus"
    aoi "\"If we choose not to rescue the kitten, we'll trigger the bad ending route, and—\""


translate english a3152a_9e5dc2ad:



    voice "voice/a31/52a00420a01.opus"
    mx "\"I'm warning you now, as your friend.\""



translate english a3152a_c094ff21:


    "El semblante de Miyuki se contorsiona ferozmente."


translate english a3152a_b4f6ec36:



    voice "voice/a31/52a00430a01.opus"
    mx "\"This isn't a game.\""


translate english a3152a_6b8f5e8e:



    voice "voice/a31/52a00440a01.opus"
    mx "\"If you try to adopt that cat...\""


translate english a3152a_d7bb31e6:



    voice "voice/a31/52a00450a01.opus"
    mx "\"I'm cutting ties with you!\""


translate english a3152a_c4cadafd:


    "Y así, Miyuki gira hábilmente sobre sus talones y se aleja."


translate english a3152a_7c5d8aff:


    "Su largo cabello ondea bajo la luz de la luna mientras desaparece en la oscuridad de la noche."


translate english a3152a_0cf49434:


    "El gatito le maúlla, pero ella no voltea."


translate english a3152a_a64b96a2:


    "Momentos después, se ha ido."


translate english a3152a_ebcaef6c:


    "Fue todo tan repentino que no tuve tiempo de reaccionar..."


translate english a3152a_4f17646a:


    "Lo único que pude hacer fue verla irse."


translate english a3152a_8da1c824:


    "Mientras tanto, el recuerdo de nuestra conversación flota en mi cabeza."


translate english a3152a_862680e7:


    "—\"I want to help her come to terms with her reality.\""


translate english a3152a_e3cc12d6:


    "—\"And I think that's the best thing we can do for her.\""


translate english a3152a_6cd2f41b:



    voice "voice/a31/52a00470a02.opus"
    aoi "\"Cutting ties?\""


translate english a3152a_d08d4060:


    "La mirada de Aoi vaga hacia la distancia mientras se quita las orejas de gato."


translate english a3152a_56876731:


    "Pero esta no es su mirada distraída habitual."


translate english a3152a_a73c4e8d:


    "En vez de eso, parece buscar desesperadamente algo que no logra localizar..."


translate english a3152a_3c442c06:


    xy "\"You alright?\""


translate english a3152a_6798043d:



    voice "voice/a31/52a00480a02.opus"
    aoi "\"Shinichi, explain to me...\""


translate english a3152a_5ccb1893:



    voice "voice/a31/52a00490a02.opus"
    aoi "\"What does 'cutting ties' mean?\""


translate english a3152a_04f47f1f:


    xy "\"Well... I imagine it means she'll stop being friends with you, or maybe stop talking to you at all...\""


translate english a3152a_a5c8b4be:



    voice "voice/a31/52a00500a02.opus"
    aoi "\"She's gonna stop... being my friend?\""


translate english a3152a_c47f13d5:



    voice "voice/a31/52a00510a02.opus"
    aoi "\"Does she hate me?\""


translate english a3152a_2e39fade:


    xy "\"No, she doesn't hate you.\""


translate english a3152a_d7b48269:



    voice "voice/a31/52a00520a02.opus"
    aoi "\"But if she's gonna cut ties...\""


translate english a3152a_a297f9e5:


    xy "\"Knowing her, she just snapped and lashed out a little harder than she meant to.\""



translate english a3152a_078b70c5:



    voice "voice/a31/52a00530a02.opus"
    aoi "\"Boop boop...\""


translate english a3152a_a594d64c:


    "Aoi se queda callada."


translate english a3152a_0391c9b4:


    "But her emotional reaction is noticeably different compared to the time she attempted to \"blackmail\"emparejarnos con esa foto."


translate english a3152a_d3eb8de2:


    "...Tengo que hacer algo."


translate english a3152a_6b801029:


    xy "\"We could keep the kitten at my place.\""


translate english a3152a_2ab09a89:


    xy "\"It's a big house, and my parents aren't around. Turns out living alone has its perks!\""


translate english a3152a_3d357d95:



    voice "voice/a31/52a00540a02.opus"
    aoi "\"But Eru would be left alone whenever we're at school.\""


translate english a3152a_476b113a:



    voice "voice/a31/52a00550a02.opus"
    aoi "\"That's not safe.\""


translate english a3152a_5b73a4ab:


    xy "\"...Yeah. Fair point.\""


translate english a3152a_afdae4d4:


    "La verdad, no me sentiría cómodo dejando a un gatito tan pequeño valerse por sí mismo durante horas."


translate english a3152a_6336121c:



    voice "voice/a31/52a00560a02.opus"
    aoi "\"Got it.\""


translate english a3152a_9898910e:


    "Aoi alza la mano en silencio."


translate english a3152a_2d4d61da:



    voice "voice/a31/52a00570a02.opus"
    aoi "\"It took a long time, but... Aoi is Miyuki's friend now.\""


translate english a3152a_5519190f:



    voice "voice/a31/52a00580a02.opus"
    aoi "\"And Aoi doesn't want to have to cut ties.\""


translate english a3152a_10b5ce31:



    voice "voice/a31/52a00590a02.opus"
    aoi "\"So... the kitten will have to stay here.\""


translate english a3152a_0accd139:


    xy "\"......\""


translate english a3152a_8258ef62:


    "Recuerdo lo que dijo Miyuki de camino a casa el otro día."


translate english a3152a_066ce3fe:


    "Admitió que veía a su antiguo yo en Aoi."


translate english a3152a_21fe2423:


    "Y si fuera cualquier compañero común, nunca habría amenazado con cortar lazos."


translate english a3152a_7132904b:


    "No habría arriesgado causar revuelo."


translate english a3152a_47e13d4b:


    "Solo habría sonreído y actuado amablemente, sin importar qué."


translate english a3152a_a1422387:


    "Y sin embargo, cuando se trataba de Aoi, Miyuki no actuó amablemente."


translate english a3152a_06ecbe3c:


    xy "\"You sure?\""


translate english a3152a_5b63547f:



    voice "voice/a31/52a00600a02.opus"
    aoi "\"...Yeah. Fair point.\""


translate english a3152a_b3c7b482:


    "Mientras el gatito se restriega contra su pierna, Aoi lo levanta con suavidad y lo devuelve a la caja de cartón."


translate english a3152a_09e1488c:



    voice "voice/a31/52a00610a02.opus"
    aoi "\"I'm sorry, Eru...\""


translate english a3152a_e4a31092:


    "Acaricia al gatito con tristeza."


translate english a3152a_9f24f2e8:



    voice "voice/a31/52a00630a02.opus"
    aoi "\"Someone nice will come along and adopt you for sure.\""


translate english a3152a_5b33342f:



    voice "voice/a31/52a00650a02.opus"
    aoi "\"You'll be happier that way.\""


translate english a3152a_098192dc:



    voice "voice/a31/52a00660a02.opus"
    aoi "\"Don't worry... You'll see...\""


translate english a3152a_bf4fa835:


    "Sigue acariciando al gatito una y otra vez. Al parecer no logra decidirse a irse."


translate english a3152a_80caa3e2:


    xy "\"...Aoi?\""


translate english a3152a_2d75d825:



    voice "voice/a31/52a00670a02.opus"
    aoi "\"...It's okay.\""


translate english a3152a_4b68dfb2:



    voice "voice/a31/52a00680a02.opus"
    aoi "\"Bye-bye, Eru.\""


translate english a3152a_92a4f6c1:


    "Con eso, Aoi por fin se levanta y voltea, y efectivamente—"


translate english a3152a_a39700e2:



    voice "voice/a31/52a00690a02.opus"
    aoi "\"...Boop boop...?\""


translate english a3152a_c3943bf9:


    "—su rostro está empapado de lágrimas."


translate english a3152a_a0926fb0:


    "Por reflejo, extiendo la mano y le acaricio el cabello."


translate english a3152a_66300fa8:



    voice "voice/a31/52a00700a02.opus"
    aoi "\"It's so weird...\""


translate english a3152a_21bd8b49:



    voice "voice/a31/52a00710a02.opus"
    aoi "\"Aoi's not happy... so what are these tears for?\""


translate english a3152a_0a3444b5:


    xy "\"Well... I imagine it means she'll stop being friends with you, or maybe stop talking to you at all...\""


translate english a3152a_ae90a7f9:


    xy "\"They can't all be happy tears, you know.\""


translate english a3152a_1dc4e2f7:


    "En el salón, Aoi nunca solía mostrar emoción alguna."


translate english a3152a_1210b59f:


    "Pero una vez que nos hicimos amigos de ella, aprendió a sonreír."


translate english a3152a_f17f743b:


    "Y aprendió a llorar."


translate english a3152a_3509eeed:


    xy "\"Sometimes you cry when you're sad, too.\""


translate english a3152a_a25d0622:


    "Pero esto no es algo malo."


translate english a3152a_58fee6ba:


    "Está cambiando para bien."


translate english a3152a_b9d37f96:


    "Estoy seguro."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
