

translate english c7122_ba8b0768:


    xy "\"Todo eran mentiras, ¿verdad?\""


translate english c7122_cce15bd8:


    "Mi boca se mueve por voluntad propia."


translate english c7122_f57760b9:


    xy "\"Nunca me amaste.\""


translate english c7122_40000775:


    xy "\"Solo querías CGs.\""


translate english c7122_895fbb0c:


    xy "\"Así que me engañaste sin pensarlo dos veces...\""


translate english c7122_3bfb3544:



    voice "voice/c71/2200010a02.opus"
    aoi "\"......\""


translate english c7122_4a1b59a6:


    "Justo entonces—"


translate english c7122_7ea4ad25:


    "El rostro de Aoi se retuerce de angustia."


translate english c7122_4917bef6:


    "Pura emoción brota en sus ojos."


translate english c7122_8628869c:



    voice "voice/c71/2200020a02.opus"
    aoi "\"Shinichi...\""



translate english c7122_081c5a72:



    voice "voice/c71/2200030a02.opus"
    aoi "\"Aoi te traicionó.\""


translate english c7122_e1b39d6a:



    voice "voice/c71/2200040a02.opus"
    aoi "\"E hizo todo tipo de cosas horribles.\""


translate english c7122_2e4f3b8c:



    voice "voice/c71/2200050a02.opus"
    aoi "\"Mintió... Guardó secretos...\""


translate english c7122_15af0f50:



    voice "voice/c71/2200060a02.opus"
    aoi "\"¡Pero... pero... pero—!\""


translate english c7122_0c2c8f6b:



    voice "voice/c71/2200070a02.opus"
    aoi "\"Por favor, créeme en esta una cosa.\""


translate english c7122_3fe31612:



    voice "voice/c71/2200080a02.opus"
    aoi "\"Shinichi, tú eres...\""


translate english c7122_a56baf5e:



    voice "voice/c71/2200090a02.opus"
    aoi "\"¡Tú eres la primera persona de la que Aoi se enamoró de verdad!\""


translate english c7122_d3eb2bdb:



    voice "voice/c71/2200100a02.opus"
    aoi "\"¡Así que Aoi estaba desesperada por no perder nuestros recuerdos juntos!\""


translate english c7122_278fd9aa:



    voice "voice/c71/2200110a02.opus"
    aoi "\"¡Aoi no quería tener que empezar de cero...!\""


translate english c7122_0accd139:


    xy "\"\"......\"\""


translate english c7122_92458fa3:


    "¿Cómo puedo distinguir la verdad de la mentira?"


translate english c7122_b2c3ce8a:


    "¿Cómo puedo separar el hecho de la ficción?"


translate english c7122_b25225b4:


    "No lo sé."


translate english c7122_39e7c143:


    "\"¡Pero... pero... pero—!\""


translate english c7122_7d59df42:


    "Si se supone que debo creer que sus lágrimas eran falsas, bueno, preferiría matarme."


translate english c7122_fea67470:


    xy "\"Así que esa es la razón por la que me engañaste, ¿eh?\""


translate english c7122_ffd16219:



    voice "voice/c71/2200120a02.opus"
    aoi "\"Excepto que... Aoi no pudo llegar hasta el final.\""


translate english c7122_e3176e67:



    voice "voice/c71/2200130a02.opus"
    aoi "\"Aoi te amaba demasiado.\""


translate english c7122_5678cede:


    xy "\"¿Por qué lo escondiste?\""


translate english c7122_9e24e764:


    xy "\"¿Por qué no me lo dijiste simplemente?\""


translate english c7122_264b3286:



    voice "voice/c71/2200140a02.opus"
    aoi "\"Porque... me odiarías por eso.\""


translate english c7122_cd28d581:


    xy "\"¡No es cierto!\""


translate english c7122_0e5e57c0:



    voice "voice/c71/2200150a02.opus"
    aoi "\"¡Sí es cierto!\""


translate english c7122_e5fb26cc:


    "Aoi sonríe con tristeza."


translate english c7122_e508cb5b:


    "Casi como si me viera a través."


translate english c7122_5bfe6a7f:



    voice "voice/c71/2200160a02.opus"
    aoi "\"Aoi es un avatar de Dios.\""


translate english c7122_d060bc68:



    voice "voice/c71/2200170a02.opus"
    aoi "\"Mis recuerdos están sincronizados con eso.\""


translate english c7122_e13f1b2b:



    voice "voice/c71/2200180a02.opus"
    aoi "\"Así que...\""


translate english c7122_525eb11d:



    voice "voice/c71/2200190a02.opus"
    aoi "\"Aoi tiene recuerdos de otros mundos... de otras formas físicas.\""


translate english c7122_fe6774c1:


    xy "\"¿Otros mundos...?\""


translate english c7122_2964342e:



    voice "voice/c71/2200200a02.opus"
    aoi "\"A Aoi la han convertido en incontables chicas diferentes...\""


translate english c7122_1262a869:



    voice "voice/c71/2200210a02.opus"
    aoi "\"Y ha coleccionado montones y montones de CGs.\""


translate english c7122_b3dfb51a:



    voice "voice/c71/2200220a02.opus"
    aoi "\"A Aoi le encanta que se la metan.\""


translate english c7122_40b86294:



    voice "voice/c71/2200230a02.opus"
    aoi "\"Docenas de una vez.\""


translate english c7122_581dfc24:



    voice "voice/c71/2200240a02.opus"
    aoi "\"Aoi también ha tenido sexo con chicas.\""


translate english c7122_bd66b5db:



    voice "voice/c71/2200250a02.opus"
    aoi "\"Y con nerds feos.\""


translate english c7122_f7662bf5:



    voice "voice/c71/2200260a02.opus"
    aoi "\"Y con viejos calvos.\""


translate english c7122_be8cc03e:



    voice "voice/c71/2200270a02.opus"
    aoi "\"Y con niños prepúberes.\""


translate english c7122_7bd805ab:



    voice "voice/c71/2200280a02.opus"
    aoi "\"Y con perros.\""


translate english c7122_44867bc6:



    voice "voice/c71/2200290a02.opus"
    aoi "\"Aoi puede hacer garganta profunda o recibirlo por el culo.\""


translate english c7122_fcf3cb8e:



    voice "voice/c71/2200300a02.opus"
    aoi "\"Y a Aoi le encanta el spitroast.\""


translate english c7122_09b951bf:



    voice "voice/c71/2200310a02.opus"
    aoi "\"El scat tampoco está descartado.\""


translate english c7122_84c1e496:



    voice "voice/c71/2200320a02.opus"
    aoi "\"Así es Aoi, y ya.\""


translate english c7122_87b094d5:



    voice "voice/c71/2200330a02.opus"
    aoi "\"Aoi puede adoptar formas distintas, pero no cambia.\""


translate english c7122_df724bb7:



    voice "voice/c71/2200340a02.opus"
    aoi "\"Y a ti no te gustan las chicas así.\""


translate english c7122_c1cb1e17:



    voice "voice/c71/2200350a02.opus"
    aoi "\"Nunca estarías de acuerdo con que yo anduviera acostándome con cualquiera.\""


translate english c7122_a223f57d:


    xy "\"Eso... no es cierto...\""


translate english c7122_d833c604:



    voice "voice/c71/2200360a02.opus"
    aoi "\"Sí lo es.\""


translate english c7122_15f72289:



    voice "voice/c71/2200380a02.opus"
    aoi "\"Hay otras rutas así.\""


translate english c7122_8c1e24a8:


    xy "\"¡No!\""


translate english c7122_6f5f2109:


    "Siento que mi voz empieza a quebrarse."


translate english c7122_87e078ff:


    "Pero... este es mi destino."


translate english c7122_f6d5d738:


    "Tengo que decirlo."


translate english c7122_2b821be4:


    xy "\"Sin guardar, sin cargar.\""


translate english c7122_fec895c7:


    xy "\"Solo tenemos una vida. Esto es todo.\""


translate english c7122_75421ddc:


    xy "\"Pero...\""


translate english c7122_cbb630c3:


    xy "\"Por eso nos enamoramos con tanta pasión.\""


translate english c7122_0a357aa5:



    voice "voice/c71/2200400a02.opus"
    aoi "\"¿Así es...?\""


translate english c7122_7d5a719e:


    xy "\"No puedes sobrescribir tus errores en la vida real como en un videojuego...\""


translate english c7122_795d5797:


    xy "\"Pero a cambio, la vida real dura muchísimo más.\""


translate english c7122_220ed1dc:


    xy "\"Puedes empezar de nuevo cuantas veces quieras.\""


translate english c7122_d1a1571e:



    voice "voice/c71/2200410a02.opus"
    aoi "\"¿Eso es verdad...?\""


translate english c7122_1ed6e377:



    voice "voice/c71/2200420a02.opus"
    aoi "\"¿Aoi puede de verdad... empezar de nuevo...?\""


translate english c7122_820e142e:


    "Tengo una decisión que tomar."


translate english c7122_89c9a6ba:


    "Significará dejar de lado toda mi dignidad."


translate english c7122_46eafd52:


    "Y cambiar quien soy como persona."


translate english c7122_ceb781b9:


    "Pero lo haré por ella. Por amor."


translate english c7122_0f992b51:


    "Sin importar cuántas veces la cague o salga herido..."


translate english c7122_a8cc7867:


    xy "\"Quedémonos juntos.\""


translate english c7122_43de92ab:


    "Y así, saco mi celular en silencio."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
