

translate english c7122_ba8b0768:


    xy "\"It was all lies, wasn't it?\""


translate english c7122_cce15bd8:


    "Mi boca se mueve por voluntad propia."


translate english c7122_f57760b9:


    xy "\"You never loved me.\""


translate english c7122_40000775:


    xy "\"You just wanted CGs.\""


translate english c7122_895fbb0c:


    xy "\"So you cheated on me without a second thought...\""


translate english c7122_3bfb3544:



    voice "voice/c71/2200010a02.opus"
    aoi "\"......\""


translate english c7122_4a1b59a6:


    "Justo entonces—"


translate english c7122_7ea4ad25:


    "El rostro de Aoi se retuerce de angustia."


translate english c7122_4917bef6:


    "Pura emoción brota en sus ojos."


translate english c7122_8628869c:



    voice "voice/c71/2200020a02.opus"
    aoi "\"Shinichi...\""



translate english c7122_081c5a72:



    voice "voice/c71/2200030a02.opus"
    aoi "\"Aoi betrayed you.\""


translate english c7122_e1b39d6a:



    voice "voice/c71/2200040a02.opus"
    aoi "\"And did all sorts of awful things.\""


translate english c7122_2e4f3b8c:



    voice "voice/c71/2200050a02.opus"
    aoi "\"Lied... Kept secrets...\""


translate english c7122_15af0f50:



    voice "voice/c71/2200060a02.opus"
    aoi "\"But... but... but—!\""


translate english c7122_0c2c8f6b:



    voice "voice/c71/2200070a02.opus"
    aoi "\"Please believe me about this one thing.\""


translate english c7122_3fe31612:



    voice "voice/c71/2200080a02.opus"
    aoi "\"Shinichi, you're...\""


translate english c7122_a56baf5e:



    voice "voice/c71/2200090a02.opus"
    aoi "\"You're the first person Aoi ever truly fell for!\""


translate english c7122_d3eb2bdb:



    voice "voice/c71/2200100a02.opus"
    aoi "\"So Aoi was desperate not to lose our memories together!\""


translate english c7122_278fd9aa:



    voice "voice/c71/2200110a02.opus"
    aoi "\"Aoi didn't want to have to start over...!\""


translate english c7122_0accd139:


    xy "\"\"......\"\""


translate english c7122_92458fa3:


    "¿Cómo puedo distinguir la verdad de la mentira?"


translate english c7122_b2c3ce8a:


    "¿Cómo puedo separar el hecho de la ficción?"


translate english c7122_b25225b4:


    "No lo sé."


translate english c7122_39e7c143:


    "\"But... but... but—!\""


translate english c7122_7d59df42:


    "Si se supone que debo creer que sus lágrimas eran falsas, bueno, preferiría matarme."


translate english c7122_fea67470:


    xy "\"So that's the reason you cheated on me, huh?\""


translate english c7122_ffd16219:



    voice "voice/c71/2200120a02.opus"
    aoi "\"Except... Aoi couldn't go through with it.\""


translate english c7122_e3176e67:



    voice "voice/c71/2200130a02.opus"
    aoi "\"Aoi loved you too much.\""


translate english c7122_5678cede:


    xy "\"Why did you hide it?\""


translate english c7122_9e24e764:


    xy "\"Why didn't you just tell me?\""


translate english c7122_264b3286:



    voice "voice/c71/2200140a02.opus"
    aoi "\"Because... you'd hate me for it.\""


translate english c7122_cd28d581:


    xy "\"No I wouldn't!\""


translate english c7122_0e5e57c0:



    voice "voice/c71/2200150a02.opus"
    aoi "\"Yes you would!\""


translate english c7122_e5fb26cc:


    "Aoi sonríe con tristeza."


translate english c7122_e508cb5b:


    "Casi como si me viera a través."


translate english c7122_5bfe6a7f:



    voice "voice/c71/2200160a02.opus"
    aoi "\"Aoi is an avatar of God.\""


translate english c7122_d060bc68:



    voice "voice/c71/2200170a02.opus"
    aoi "\"My memories are synced to it.\""


translate english c7122_e13f1b2b:



    voice "voice/c71/2200180a02.opus"
    aoi "\"So...\""


translate english c7122_525eb11d:



    voice "voice/c71/2200190a02.opus"
    aoi "\"Aoi has memories from other worlds... from other physical forms.\""


translate english c7122_fe6774c1:


    xy "\"Other worlds...?\""


translate english c7122_2964342e:



    voice "voice/c71/2200200a02.opus"
    aoi "\"Aoi's been turned into countless different girls...\""


translate english c7122_1262a869:



    voice "voice/c71/2200210a02.opus"
    aoi "\"And collected bunches and bunches of CGs.\""


translate english c7122_b3dfb51a:



    voice "voice/c71/2200220a02.opus"
    aoi "\"Aoi loves taking fat cocks.\""


translate english c7122_40b86294:



    voice "voice/c71/2200230a02.opus"
    aoi "\"Dozens of 'em, all at once.\""


translate english c7122_581dfc24:



    voice "voice/c71/2200240a02.opus"
    aoi "\"Aoi's had sex with girls, too.\""


translate english c7122_bd66b5db:



    voice "voice/c71/2200250a02.opus"
    aoi "\"And ugly nerds.\""


translate english c7122_f7662bf5:



    voice "voice/c71/2200260a02.opus"
    aoi "\"And balding old men.\""


translate english c7122_be8cc03e:



    voice "voice/c71/2200270a02.opus"
    aoi "\"And prepubescent boys.\""


translate english c7122_7bd805ab:



    voice "voice/c71/2200280a02.opus"
    aoi "\"And dogs.\""


translate english c7122_44867bc6:



    voice "voice/c71/2200290a02.opus"
    aoi "\"Aoi can deepthroat or take it up the ass.\""


translate english c7122_fcf3cb8e:



    voice "voice/c71/2200300a02.opus"
    aoi "\"And Aoi loves spitroasting.\""


translate english c7122_09b951bf:



    voice "voice/c71/2200310a02.opus"
    aoi "\"Scat's not off the table, either.\""


translate english c7122_84c1e496:



    voice "voice/c71/2200320a02.opus"
    aoi "\"That's just the kind of girl Aoi is.\""


translate english c7122_87b094d5:



    voice "voice/c71/2200330a02.opus"
    aoi "\"Aoi may take different forms, but Aoi doesn't change.\""


translate english c7122_df724bb7:



    voice "voice/c71/2200340a02.opus"
    aoi "\"And you're not into girls like that.\""


translate english c7122_c1cb1e17:



    voice "voice/c71/2200350a02.opus"
    aoi "\"You'd never be okay with me sleeping around.\""


translate english c7122_a223f57d:


    xy "\"That's... not true...\""


translate english c7122_d833c604:



    voice "voice/c71/2200360a02.opus"
    aoi "\"Yes it is.\""


translate english c7122_15f72289:



    voice "voice/c71/2200380a02.opus"
    aoi "\"There are other routes like that.\""


translate english c7122_8c1e24a8:


    xy "\"No!\""


translate english c7122_6f5f2109:


    "Siento que mi voz empieza a quebrarse."


translate english c7122_87e078ff:


    "Pero... este es mi destino."


translate english c7122_f6d5d738:


    "Tengo que decirlo."


translate english c7122_2b821be4:


    xy "\"No saving, no loading.\""


translate english c7122_fec895c7:


    xy "\"We only get one life. This is it.\""


translate english c7122_75421ddc:


    xy "\"But...\""


translate english c7122_cbb630c3:


    xy "\"That's why we fall in love so passionately.\""


translate english c7122_0a357aa5:



    voice "voice/c71/2200400a02.opus"
    aoi "\"It is...?\""


translate english c7122_7d5a719e:


    xy "\"You can't overwrite your mistakes in real life like you can in a video game...\""


translate english c7122_795d5797:


    xy "\"But in exchange, real life lasts way, way longer.\""


translate english c7122_220ed1dc:


    xy "\"You can start over as many times as you want.\""


translate english c7122_d1a1571e:



    voice "voice/c71/2200410a02.opus"
    aoi "\"Is that true...?\""


translate english c7122_1ed6e377:



    voice "voice/c71/2200420a02.opus"
    aoi "\"Can Aoi really... start over...?\""


translate english c7122_820e142e:


    "Tengo una decisión que tomar."


translate english c7122_89c9a6ba:


    "Significará dejar de lado toda mi dignidad."


translate english c7122_46eafd52:


    "Y cambiar quien soy como persona."


translate english c7122_ceb781b9:


    "Pero lo haré por ella. Por amor."


translate english c7122_0f992b51:


    "Sin importar cuántas veces la cague o salga herido..."


translate english c7122_a8cc7867:


    xy "\"Let's stay together.\""


translate english c7122_43de92ab:


    "Y así, saco mi celular en silencio."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
