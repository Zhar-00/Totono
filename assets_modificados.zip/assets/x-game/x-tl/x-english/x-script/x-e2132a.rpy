

translate english e2132a_2c074478:


    xy "\"Tomaré el jugo de tomate.\""


translate english e2132a_50fe2e32:



    voice "voice/e21/32a00010a01.opus"
    mx "\"¡Creí que lo odiabas!\""


translate english e2132a_b9b3111b:


    xy "\"Aun así puedo beberlo. Y probablemente es bueno para la salud.\""


translate english e2132a_a4f09170:



    voice "voice/e21/32a00020a01.opus"
    mx "\"Ya veo... Intentando estar saludable, ¿eh?\""


translate english e2132a_ced753ec:


    xy "\"Ggllpp... ggllpp... ggllpp...\""



translate english e2132a_a90c5d4d:


    xy "\"¡Uf!\""


translate english e2132a_a17c31e2:


    "Hago una mueca por el sabor."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
