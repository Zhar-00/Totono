

translate english a2211_62aab1aa:


    "Allá en la primaria..."


translate english a2211_08a6e979:


    "Esa obra cambió toda la vida de Miyuki."


translate english a2211_e6916aaa:


    "Y yo fui quien la nominó para el papel."


translate english a2211_1ef306ff:


    "Por alguna razón, decidieron que yo debía interpretar el papel de su novio."


translate english a2211_2f241d8c:


    "Miyuki estaba un poco rígida al principio, pero efectivamente mejoró drásticamente con el tiempo."


translate english a2211_93aebbe3:


    "En el escenario brillaba tanto que era prácticamente cegadora."


translate english a2211_1ef45556:


    "De alguna forma de verdad se sentía como si estuviéramos juntos."


translate english a2211_a151331b:


    "Demonios, se sentía como si fuéramos las dos únicas personas en todo el mundo."


translate english a2211_2eff48e1:


    "Pero una vez que caía el telón, la magia se desvanecía."


translate english a2211_940263a1:


    "Era solo un papel en una obra."


translate english a2211_6a622434:


    "Ella era solo... extremadamente convincente, eso es todo."


translate english a2211_1a7f6910:


    "Me, though? I completely lost my composure. My \"acting\"fue un desastre, ni de lejos a la altura de la suya."


translate english a2211_f03fff6b:


    "Luego, durante la función, me equivoqué en mis líneas. Todos se rieron. Solo gracias a la improvisación de Miyuki llegamos al saludo final sin más incidentes."



translate english a2211_c2ca1978:


    "Por fin, el hechizo se rompió."


translate english a2211_fd366714:


    "Lo siguiente que supe fue que Miyuki era la estrella de la clase."


translate english a2211_288ac8f6:


    "Y yo sigo siendo un don nadie."


translate english a2211_e6c9d535:


    "Ya no me necesita."


translate english a2211_85889096:


    "Sus talentos la llevan a un lugar que no puedo seguir. Solo la arrastraría hacia abajo."


translate english a2211_f1105abf:


    "Solo somos amigos. Eso debería bastarme."


translate english a2211_74895e0d:


    "Y sin embargo—"


translate english a2211_5aa6263f:



    voice "voice/a22/1100010a01.opus"
    mx "\"Va a haber..."


translate english a2211_958cd961:


    voice "voice/a22/1100020a01.opus"



translate english a2211_646f0cf4:


    extend "un beso.\""



translate english a2211_0e14a67e:


    "Las palabras de Miyuki, sus labios, están grabados a fuego en mi cerebro."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
