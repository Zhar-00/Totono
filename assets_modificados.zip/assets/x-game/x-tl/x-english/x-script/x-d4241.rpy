

translate english d4241_acdd9690:


    xy "\"...Y fue entonces cuando me di cuenta de que se había ido.\""


translate english d4241_ea98f2cc:



    voice "voice/d42/4100010a01.opus"
    mx "\"¿Ido...?\""


translate english d4241_ccdd7651:


    xy "\"¿Crees que me lo estoy inventando?\""


translate english d4241_0247064f:



    voice "voice/d42/4100020a01.opus"
    mx "\"En cualquier otra circunstancia, sí... Pero, otra vez, estamos hablando de Aoi.\""


translate english d4241_fb8a75e0:



    voice "voice/d42/4100030a01.opus"
    mx "\"Ese lugar es el centro del universo... Además, era plena noche.\""


translate english d4241_3a61020f:



    voice "voice/d42/4100040a01.opus"
    mx "\"El ambiente perfecto para un poco de magia.\""


translate english d4241_f2e5dbc9:


    xy "\"...Huh. Me sorprendes.\""


translate english d4241_82bd53f6:


    xy "\"Esperaba que me llamaras cerebro de gamer o algo así.\""


translate english d4241_6757ea00:



    voice "voice/d42/4100050a01.opus"
    mx "\"He decidido creer...\""


translate english d4241_590d4153:



    voice "voice/d42/4100060a01.opus"
    mx "\"...en un punto medio entre los sueños y la realidad.\""


translate english d4241_6881da28:



    voice "voice/d42/4100070a01.opus"
    mx "\"Supongo que tengo que agradecerle a Aoi por eso.\""


translate english d4241_f62a45f9:


    xy "\"Sí...\""



translate english d4241_39f4d12d:


    "Es gracias a Aoi que estoy aquí."


translate english d4241_a8efe23a:


    "Eso es seguro."


translate english d4241_5c197fd5:



    voice "voice/d42/4100080a01.opus"
    mx "\"Bueno, y con Aoi es todo, ¿sí?\""


translate english d4241_1a66adb3:



    voice "voice/d42/4100090a01.opus"
    mx "\"Ahora, déjame—\""


translate english d4241_c04c025b:


    xy "\"—Espera un segundo.\""


translate english d4241_6e691c45:


    "No sé si la Aoi que vi allá arriba era real o solo una ilusión."


translate english d4241_0bc09fd1:


    "Pero si vino a verme a propósito una última vez..."


translate english d4241_8356a7d3:


    "Si ese momento que compartimos tenía algún significado más profundo..."


translate english d4241_015e70ab:


    "Entonces creo que sé lo que quería que entendiera."


translate english d4241_716ad73b:


    xy "\"¿Puedes dejarme ir primero?\""


translate english d4241_94eb3ed5:



    voice "voice/d42/4100100a01.opus"
    mx "\"¿Qué es...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
