

translate english d4241_acdd9690:


    xy "\"...And that's when I realized she was gone.\""


translate english d4241_ea98f2cc:



    voice "voice/d42/4100010a01.opus"
    mx "\"Gone...?\""


translate english d4241_ccdd7651:


    xy "\"You think I'm making this up?\""


translate english d4241_0247064f:



    voice "voice/d42/4100020a01.opus"
    mx "\"Under any other circumstance, yeah... But then again, this is Aoi we're talking about.\""


translate english d4241_fb8a75e0:



    voice "voice/d42/4100030a01.opus"
    mx "\"That place is the center of the universe... Plus, it was the middle of the night.\""


translate english d4241_3a61020f:



    voice "voice/d42/4100040a01.opus"
    mx "\"The perfect environment for a little magic.\""


translate english d4241_f2e5dbc9:


    xy "\"...Huh. I'm surprised.\""


translate english d4241_82bd53f6:


    xy "\"I was expecting you to call me a gamer brain or something.\""


translate english d4241_6757ea00:



    voice "voice/d42/4100050a01.opus"
    mx "\"I've decided to believe...\""


translate english d4241_590d4153:



    voice "voice/d42/4100060a01.opus"
    mx "\"...in a middle ground between dreams and reality.\""


translate english d4241_6881da28:



    voice "voice/d42/4100070a01.opus"
    mx "\"I guess I have Aoi to thank for that.\""


translate english d4241_f62a45f9:


    xy "\"Yeah...\""



translate english d4241_39f4d12d:


    "Es gracias a Aoi que estoy aquí."


translate english d4241_a8efe23a:


    "Eso es seguro."


translate english d4241_5c197fd5:



    voice "voice/d42/4100080a01.opus"
    mx "\"So, that's it for Aoi, yes?\""


translate english d4241_1a66adb3:



    voice "voice/d42/4100090a01.opus"
    mx "\"Now then, let me—\""


translate english d4241_c04c025b:


    xy "\"—Hang on a sec.\""


translate english d4241_6e691c45:


    "No sé si la Aoi que vi allá arriba era real o solo una ilusión."


translate english d4241_0bc09fd1:


    "Pero si vino a verme a propósito una última vez..."


translate english d4241_8356a7d3:


    "Si ese momento que compartimos tenía algún significado más profundo..."


translate english d4241_015e70ab:


    "Entonces creo que sé lo que quería que entendiera."


translate english d4241_716ad73b:


    xy "\"Can you let me go first?\""


translate english d4241_94eb3ed5:



    voice "voice/d42/4100100a01.opus"
    mx "\"What is it...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
