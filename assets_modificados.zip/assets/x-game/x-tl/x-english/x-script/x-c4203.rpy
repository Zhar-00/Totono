

translate english c4203_ef82b686:


    "No hay garantía de que Eru en realidad me lleve hasta Aoi."


translate english c4203_23c04aa6:


    "No vale la pena abandonar a Miyuki por eso."


translate english c4203_2ffd8e92:


    "No hay absolutamente ninguna razón lógica por la que deba seguir a Eru."


translate english c4203_57b4a733:


    "Lo sé..."


translate english c4203_76dd2e33:


    "Y aun así..."


translate english c4203_60b56590:


    xy "\"Tengo que ir. Tengo que resolver esto de una vez por todas.\""


translate english c4203_92808682:



    voice "voice/c42/0300010a01.opus"
    mx "\"......\""


translate english c4203_3e59a387:


    "Miyuki toma una sola respiración profunda, llenando sus pulmones por completo, luego exhala despacio."


translate english c4203_36d040f4:



    voice "voice/c42/0300020a01.opus"
    mx "\"Está bien.\""


translate english c4203_61598d93:


    "Asiente a regañadientes."


translate english c4203_43bd5225:



    voice "voice/c42/0300030a01.opus"
    mx "\"Pero a cambio, más te vale escucharme después.\""


translate english c4203_06b57047:


    xy "\"De acuerdo. Nos vemos entonces.\""


translate english c4203_04142c84:



    voice "voice/c42/0300040a01.opus"
    mx "\"¡Shinichi!\""


translate english c4203_ae1f053f:


    "Mientras salgo corriendo, Miyuki me llama."


translate english c4203_8aa7e760:



    voice "voice/c42/0300050a01.opus"
    mx "\"¡Te estaré esperando!\""


translate english c4203_b252a7ff:



    voice "voice/c42/0300060a01.opus"
    mx "\"¡Es una promesa, me oyes! ¡Te estaré esperando!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
