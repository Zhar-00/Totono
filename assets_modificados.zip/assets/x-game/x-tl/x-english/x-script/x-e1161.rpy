

translate english e1161_912baea2:


    xy "Sé que esta es probablemente una pregunta rara—\""


translate english e1161_9869ac11:



    voice "voice/e11/6100010b01.opus"
    xtl "\"Créeme, ya estás actuando bastante raro...\""


translate english e1161_197ca8b1:


    xy "\"¿Has visto a Aoi por algún lado?\""


translate english e1161_5900f906:



    voice "voice/e11/6100020b01.opus"
    xtl "\"¿Mukou?\""


translate english e1161_ececd389:


    xy "\"Sí. Mukou Aoi.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
