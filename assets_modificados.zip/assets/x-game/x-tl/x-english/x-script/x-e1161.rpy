

translate english e1161_912baea2:


    xy "Sé que esta es probablemente una pregunta rara—\""


translate english e1161_9869ac11:



    voice "voice/e11/6100010b01.opus"
    xtl "\"Trust me, you're already acting plenty weird...\""


translate english e1161_197ca8b1:


    xy "\"Have you seen Aoi anywhere?\""


translate english e1161_5900f906:



    voice "voice/e11/6100020b01.opus"
    xtl "\"Mukou?\""


translate english e1161_ececd389:


    xy "\"Yeah. Mukou Aoi.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
