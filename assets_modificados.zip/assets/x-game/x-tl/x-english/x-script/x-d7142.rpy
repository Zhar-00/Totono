

translate english d7142_db1a1113:



    voice "voice/d71/4200010a01.opus"
    mx "\"¿Te sientes un poco mejor?\""


translate english d7142_12e64a21:


    xy "\"......\""


translate english d7142_6201c455:


    xy "\"...Duele tanto...\""


translate english d7142_5a35c2bc:


    xy "\"¡No hay forma de que pueda sentirme ni un poco bien con todo esto...!\""


translate english d7142_6eca5b94:



    voice "voice/d71/4200020a01.opus"
    mx "\"Sí... supongo que no.\""


translate english d7142_17298f5e:


    xy "\"Era la única opción que tenía...\""


translate english d7142_4d80d045:


    xy "\"Las cosas nunca iban a salir de otra forma...\""


translate english d7142_b063a213:


    xy "\"¿Verdad, Miyuki? Por favor, dime que tengo razón...\""


translate english d7142_a608509c:



    voice "voice/d71/4200030a01.opus"
    mx "\"Nadie te culpa por lo que pasó.\""


translate english d7142_941fe89f:



    voice "voice/d71/4200040a01.opus"
    mx "\"Esto siempre iba a pasar de una forma u otra.\""


translate english d7142_854db2a4:



    voice "voice/d71/4200050a01.opus"
    mx "\"Es tu destino.\""


translate english d7142_46bc0fb0:


    xy "\"¿Qué?\""


translate english d7142_bc296f1f:



    voice "voice/d71/4200060a01.opus"
    mx "\"Me oíste. Destino.\""


translate english d7142_2e07b326:



    voice "voice/d71/4200070a01.opus"
    mx "\"Y el amor...\""


translate english d7142_be3503cc:



    voice "voice/d71/4200080a01.opus"
    mx "\"...es eterno.\""


translate english d7142_c941f33c:


    "Su susurro ahoga toda la miseria."


translate english d7142_aa2026ed:


    "Su voz se filtra suavemente en mi cerebro, y mi mente queda en blanco."


translate english d7142_7120c114:


    "Su cabello roza contra mí."


translate english d7142_72b3fe64:


    "Me envuelve con sus suaves brazos."


translate english d7142_3ad402d9:


    "Puedo oler su aroma."


translate english d7142_ef84145e:


    "Ahora mismo, solo quiero quedarme aquí en este abrazo y olvidarlo todo..."


translate english d7142_16ad0e4b:


    "Por siempre y para siempre y para siempre..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
