

translate english d7142_db1a1113:



    voice "voice/d71/4200010a01.opus"
    mx "\"Feeling a little better?\""


translate english d7142_12e64a21:


    xy "\"......\""


translate english d7142_6201c455:


    xy "\"...It hurts so much...\""


translate english d7142_5a35c2bc:


    xy "\"There's no way I could feel remotely good about any of this...!\""


translate english d7142_6eca5b94:



    voice "voice/d71/4200020a01.opus"
    mx "\"Yeah... I guess not.\""


translate english d7142_17298f5e:


    xy "\"It was the only choice I had...\""


translate english d7142_4d80d045:


    xy "\"Things were never going to turn out any differently...\""


translate english d7142_b063a213:


    xy "\"Right, Miyuki? Please tell me I'm right...\""


translate english d7142_a608509c:



    voice "voice/d71/4200030a01.opus"
    mx "\"No one blames you for what happened.\""


translate english d7142_941fe89f:



    voice "voice/d71/4200040a01.opus"
    mx "\"This was always going to happen one way or another.\""


translate english d7142_854db2a4:



    voice "voice/d71/4200050a01.opus"
    mx "\"It's your fate.\""


translate english d7142_46bc0fb0:


    xy "\"What?\""


translate english d7142_bc296f1f:



    voice "voice/d71/4200060a01.opus"
    mx "\"You heard me. Fate.\""


translate english d7142_2e07b326:



    voice "voice/d71/4200070a01.opus"
    mx "\"And love...\""


translate english d7142_be3503cc:



    voice "voice/d71/4200080a01.opus"
    mx "\"...is eternal.\""


translate english d7142_c941f33c:


    "Su susurro ahoga toda la miseria."


translate english d7142_aa2026ed:


    "Su voz se filtra suavemente en mi cerebro, y mi mente queda en blanco."


translate english d7142_7120c114:


    "Su cabello roza contra mí."


translate english d7142_72b3fe64:


    "Me envuelve con sus suaves brazos."


translate english d7142_3ad402d9:


    "Puedo oler su aroma."


translate english d7142_ef84145e:


    "Ahora mismo, solo quiero quedarme aquí en este abrazo y olvidarlo todo..."


translate english d7142_16ad0e4b:


    "Por siempre y para siempre y para siempre..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
