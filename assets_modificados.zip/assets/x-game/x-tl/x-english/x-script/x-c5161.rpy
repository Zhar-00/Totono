

translate english c5161_1c13c3c5:



    voice "voice/c51/6100010a02.opus"
    aoi "\"Boop boop...\""


translate english c5161_7711afae:



    voice "voice/c51/6100030a02.opus"
    aoi "\"No, like this.\""


translate english c5161_dcab6b34:



    voice "voice/c51/6100050a02.opus"
    aoi "\"Eru! Do it like Aoi's doing it!\""


translate english c5161_0f74c258:


    "Sentado en la cima del techo, observo a Aoi jugando con Eru en el nivel inferior."


translate english c5161_4a06fa31:


    "Aparentemente Aoi intenta enseñarle a Eru a imitar su pose..."


translate english c5161_13ca0b4f:



    voice "voice/c51/6100060a01.opus"
    mx "\"...What is she doing down there?\""


translate english c5161_482be01f:


    xy "\"I think she's trying to imitate one of those... beckoning cat statues?\""


translate english c5161_ee9973b5:



    voice "voice/c51/6100070a01.opus"
    mx "\"What does she get out of it?\""


translate english c5161_ab217b84:


    xy "\"No idea. But knowing her, there's gotta be something she sees in it.\""


translate english c5161_aa22309d:



    voice "voice/c51/6100080a01.opus"
    mx "\"I feel bad for Eru, having to put up with that nonsense.\""


translate english c5161_040d056a:


    "Suspira."


translate english c5161_64591024:



    voice "voice/c51/6100090a01.opus"
    mx "\"Why does she force it? She should just be herself.\""


translate english c5161_d970ac1b:


    xy "\"Right back at you.\""


translate english c5161_45eec8bd:


    xy "\"Besties, my ass.\""


translate english c5161_1502ceba:



    voice "voice/c51/6100100a01.opus"
    mx "\"......\""


translate english c5161_6c6cd1ec:


    xy "\"Seriously, don't push yourself.\""


translate english c5161_0b7ab083:



    voice "voice/c51/6100110a01.opus"
    mx "\"I'm doing it for my own sake. I WANT to do this.\""


translate english c5161_4388b8c2:


    xy "\"Alright.\""


translate english c5161_caf136e3:


    "Miyuki es tan madura..."


translate english c5161_d89c71b5:


    "De hecho, es tan autodisciplinada que es un poco preocupante..."


translate english c5161_f6df20f8:



    voice "voice/c51/6100120a01.opus"
    mx "\"I'm sorry about earlier.\""


translate english c5161_715ef035:



    voice "voice/c51/6100130a01.opus"
    mx "\"I was confused, and I lashed out, and—\""


translate english c5161_e8c3106a:


    xy "\"It hurt like hell, you know.\""


translate english c5161_1f90c6bb:



    voice "voice/c51/6100140a01.opus"
    mx "\"I'm really sorry.\""


translate english c5161_3a604a36:


    xy "\"And it left a mark, too. I didn't realize until after I got back to the classroom, and now everyone's gossiping about it.\""


translate english c5161_a4c1263c:



    voice "voice/c51/6100150a01.opus"
    mx "\"I'll clear things up with them.\""


translate english c5161_e3efeed9:


    xy "\"Thanks, I'd appreciate it.\""


translate english c5161_387b4f89:


    "Quiero vivir mi vida fuera del centro de atención."


translate english c5161_71d72ec8:


    "Y para eso, necesito la ayuda de Miyuki."


translate english c5161_e81c2003:


    "Así que agradezco que esté dispuesta a cooperar."


translate english c5161_e2d1a6c0:


    "Mucho, en realidad."


translate english c5161_67d2cc21:


    "Y sin embargo, algo al respecto no se siente bien."


translate english c5161_79b09e33:


    "Parece una persona completamente distinta ahora en comparación con esta mañana, cuando me abofeteó."


translate english c5161_0d6202a4:


    "¿Realmente pudo haber aceptado la idea en solo unas pocas horas?"


translate english c5161_8c40782c:



    voice "voice/c51/6100160a01.opus"
    mx "\"Hey, Shinichi?\""


translate english c5161_dbe94659:


    "El cabello oscuro de Miyuki baila con la brisa."


translate english c5161_2b8a374e:



    voice "voice/c51/6100170a01.opus"
    mx "\"Do you believe in fate?\""


translate english c5161_bc95d1f1:


    xy "\"Fate?\""


translate english c5161_739090c9:



    voice "voice/c51/6100180a01.opus"
    mx "\"Yeah.\""


translate english c5161_129be76e:



    voice "voice/c51/6100190a01.opus"
    mx "\"There are so many paths in life. Choose A, choose B.\""


translate english c5161_6b4f2d7a:



    voice "voice/c51/6100200a01.opus"
    mx "\"Is it coincidence that brought you here to this moment?\""


translate english c5161_5bf37e86:



    voice "voice/c51/6100210a01.opus"
    mx "\"Or were you pulled here by the strings of fate?\""


translate english c5161_36a5c487:


    xy "\"I disagree. To me, there are no choices in life.\""


translate english c5161_a47c678e:


    "Ah, mi vieja teoría favorita."


translate english c5161_475f4e2c:


    xy "\"What-ifs don't exist.\""



translate english c5161_8a01ddca:


    xy "\"'Oh, if only I'd done this, if only I'd picked that...' That's just hindsight talking.\""



translate english c5161_07186e00:


    xy "\"In reality, I could never have chosen differently.\""


translate english c5161_fa9379e3:


    xy "\"There's no such thing as free will. It's the synapses in my brain that make the choices for me.\""


translate english c5161_4facb269:


    xy "\"But if you want to call that fate, then sure.\""


translate english c5161_539ca2ee:



    voice "voice/c51/6100220a01.opus"
    mx "\"...Gotcha.\""


translate english c5161_73be6c37:


    "Ahora está sonriendo. La conozco lo suficiente para saberlo."


translate english c5161_01cb1a24:



    voice "voice/c51/6100230a01.opus"
    mx "\"So to you, even if you started your whole life over again, you'd still fall in love and end up with the same person.\""


translate english c5161_0e83502f:



    voice "voice/c51/6100240a01.opus"
    mx "\"Is that right?\""


translate english c5161_1619057a:


    xy "\"Yeah, basically.\""


translate english c5161_8e09967a:



    voice "voice/c51/6100250a01.opus"
    mx "\"Promise me.\""


translate english c5161_a03ab506:


    "De la nada, agarra mi mano."


translate english c5161_63e74891:



    voice "voice/c51/6100260a01.opus"
    mx "\"Promise me you believe in eternal love.\""


translate english c5161_1b7991bc:


    xy "\"Wh-Where did this come from?\""


translate english c5161_e6fa97b4:



    voice "voice/c51/6100270a01.opus"
    mx "\"Promise me.\""


translate english c5161_9ddf245a:


    xy "\"Eternal love? That seems a little extreme—\""


translate english c5161_e77e76c4:



    voice "voice/c51/6100280a01.opus"
    mx "\"Don't try to get out of this!\""


translate english c5161_e3f007bf:


    xy "\"You're hurting me!\""


translate english c5161_69ce91a7:



    voice "voice/c51/6100290a01.opus"
    mx "\"Sorry... but...\""


translate english c5161_072b2740:


    "A pesar de su disculpa, no hace ningún esfuerzo por soltarla."


translate english c5161_83ed6908:



    voice "voice/c51/6100300a01.opus"
    mx "\"Please.\""


translate english c5161_9ee70d81:



    voice "voice/c51/6100310a01.opus"
    mx "\"If you promise me this one thing, it'll be all the strength I need.\""


translate english c5161_242e3842:



    voice "voice/c51/6100320a01.opus"
    mx "\"Just this one thing, and I'll do anything for you, okay?\""


translate english c5161_9fe145e1:



    voice "voice/c51/6100330a01.opus"
    mx "\"So... promise me that love is eternal.\""


translate english c5161_e35a4189:



    voice "voice/c51/6100340a02.opus"
    aoi "\"Business is booming!\""


translate english c5161_90203f46:


    "A lo lejos, puedo oír a Aoi hablando distraídamente consigo misma."


translate english c5161_13a75528:


    "—Si dos personas comparten un beso en el techo, su amor será eterno."


translate english c5161_0f3e73b8:


    "No hay forma de que crea esa leyenda estúpida..."


translate english c5161_1cfe86fd:


    "Pero quiero creer en mi amor por Aoi."


translate english c5161_a3bee710:


    "Esto es incómodo... pero... supongo..."


translate english c5161_01_6c21221e:


    xy "\"I promise.\""



translate english c5161_01_473908bb:



    voice "voice/c51/6100360a01.opus"
    mx "\"Good. Thank you.\""



translate english c5161_01_ef1a192b:



    voice "voice/c51/6100370a01.opus"
    mx "\"No matter what happens, always believe that love is eternal, okay?\""



translate english c5161_01_379c1ac5:


    xy "\"O-Okay...\""



translate english c5161_01_c71ac470:


    "Algo en la forma en que lo dijo me molesta..."



translate english c5161_01_7e60768f:


    "En serio, ¿de dónde salió eso de repente...?"



translate english strings:


    old "Дать ей обещание"
    new "Promesa"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
