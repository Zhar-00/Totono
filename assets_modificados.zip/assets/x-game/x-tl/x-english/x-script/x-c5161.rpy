

translate english c5161_1c13c3c5:



    voice "voice/c51/6100010a02.opus"
    aoi "\"Boop boop...\""


translate english c5161_7711afae:



    voice "voice/c51/6100030a02.opus"
    aoi "\"No, así.\""


translate english c5161_dcab6b34:



    voice "voice/c51/6100050a02.opus"
    aoi "\"¡Eru! ¡Hazlo como lo está haciendo Aoi!\""


translate english c5161_0f74c258:


    "Sentado en la cima del techo, observo a Aoi jugando con Eru en el nivel inferior."


translate english c5161_4a06fa31:


    "Aparentemente Aoi intenta enseñarle a Eru a imitar su pose..."


translate english c5161_13ca0b4f:



    voice "voice/c51/6100060a01.opus"
    mx "\"...¿Qué está haciendo ahí abajo?\""


translate english c5161_482be01f:


    xy "\"Creo que intenta imitar una de esas... ¿estatuas de gato que llaman?\""


translate english c5161_ee9973b5:



    voice "voice/c51/6100070a01.opus"
    mx "\"¿Y qué gana con eso?\""


translate english c5161_ab217b84:


    xy "\"Ni idea. Pero conociéndola, debe haber algo que le ve.\""


translate english c5161_aa22309d:



    voice "voice/c51/6100080a01.opus"
    mx "\"Me da pena Eru, tener que aguantar esas tonterías.\""


translate english c5161_040d056a:


    "Suspira."


translate english c5161_64591024:



    voice "voice/c51/6100090a01.opus"
    mx "\"¿Por qué lo fuerza? Debería ser ella misma.\""


translate english c5161_d970ac1b:


    xy "\"Igual tú.\""


translate english c5161_45eec8bd:


    xy "\"Mejores amigas, mi culo.\""


translate english c5161_1502ceba:



    voice "voice/c51/6100100a01.opus"
    mx "\"......\""


translate english c5161_6c6cd1ec:


    xy "\"En serio, no te fuerces.\""


translate english c5161_0b7ab083:



    voice "voice/c51/6100110a01.opus"
    mx "\"Lo hago por mí misma. QUIERO hacerlo.\""


translate english c5161_4388b8c2:


    xy "\"Está bien.\""


translate english c5161_caf136e3:


    "Miyuki es tan madura..."


translate english c5161_d89c71b5:


    "De hecho, es tan autodisciplinada que es un poco preocupante..."


translate english c5161_f6df20f8:



    voice "voice/c51/6100120a01.opus"
    mx "\"Perdón por lo de antes.\""


translate english c5161_715ef035:



    voice "voice/c51/6100130a01.opus"
    mx "\"Estaba confundido, y exploté, y—\""


translate english c5161_e8c3106a:


    xy "\"Dolió como el demonio, ¿sabes?\""


translate english c5161_1f90c6bb:



    voice "voice/c51/6100140a01.opus"
    mx "\"De verdad lo siento.\""


translate english c5161_3a604a36:


    xy "\"Y también dejó marca. No me di cuenta hasta que volví al salón, y ahora todos están chismeando.\""


translate english c5161_a4c1263c:



    voice "voice/c51/6100150a01.opus"
    mx "\"Voy a aclararlo con ellos.\""


translate english c5161_e3efeed9:


    xy "\"Gracias, te lo agradecería.\""


translate english c5161_387b4f89:


    "Quiero vivir mi vida fuera del centro de atención."


translate english c5161_71d72ec8:


    "Y para eso, necesito la ayuda de Miyuki."


translate english c5161_e81c2003:


    "Así que agradezco que esté dispuesta a cooperar."


translate english c5161_e2d1a6c0:


    "Mucho, en realidad."


translate english c5161_67d2cc21:


    "Y sin embargo, algo al respecto no se siente bien."


translate english c5161_79b09e33:


    "Parece una persona completamente distinta ahora en comparación con esta mañana, cuando me abofeteó."


translate english c5161_0d6202a4:


    "¿Realmente pudo haber aceptado la idea en solo unas pocas horas?"


translate english c5161_8c40782c:



    voice "voice/c51/6100160a01.opus"
    mx "\"Oye, ¿Shinichi?\""


translate english c5161_dbe94659:


    "El cabello oscuro de Miyuki baila con la brisa."


translate english c5161_2b8a374e:



    voice "voice/c51/6100170a01.opus"
    mx "\"¿Crees en el destino?\""


translate english c5161_bc95d1f1:


    xy "\"¿El destino?\""


translate english c5161_739090c9:



    voice "voice/c51/6100180a01.opus"
    mx "\"Sí.\""


translate english c5161_129be76e:



    voice "voice/c51/6100190a01.opus"
    mx "\"Hay tantos caminos en la vida. Elegir A, elegir B.\""


translate english c5161_6b4f2d7a:



    voice "voice/c51/6100200a01.opus"
    mx "\"¿Es la casualidad la que te trajo a este momento?\""


translate english c5161_5bf37e86:



    voice "voice/c51/6100210a01.opus"
    mx "\"¿O te trajeron los hilos del destino?\""


translate english c5161_36a5c487:


    xy "\"No estoy de acuerdo. Para mí, no hay elecciones en la vida.\""


translate english c5161_a47c678e:


    "Ah, mi vieja teoría favorita."


translate english c5161_475f4e2c:


    xy "\"Los \"y si\" no existen.\""



translate english c5161_8a01ddca:


    xy "\"\"Ah, si hubiera hecho esto, si hubiera elegido aquello...\" Eso es solo hablar con el diario del lunes.\""



translate english c5161_07186e00:


    xy "\"En realidad, nunca podría haber elegido diferente.\""


translate english c5161_fa9379e3:


    xy "\"El libre albedrío no existe. Son las sinapsis de mi cerebro las que eligen por mí.\""


translate english c5161_4facb269:


    xy "\"Pero si quieres llamarle destino, entonces sí.\""


translate english c5161_539ca2ee:



    voice "voice/c51/6100220a01.opus"
    mx "\"...Entiendo.\""


translate english c5161_73be6c37:


    "Ahora está sonriendo. La conozco lo suficiente para saberlo."


translate english c5161_01cb1a24:



    voice "voice/c51/6100230a01.opus"
    mx "\"Así que, para ti, aunque empezaras toda tu vida de nuevo, igual te enamorarías y terminarías con la misma persona.\""


translate english c5161_0e83502f:



    voice "voice/c51/6100240a01.opus"
    mx "\"¿Es así?\""


translate english c5161_1619057a:


    xy "\"Sí, básicamente.\""


translate english c5161_8e09967a:



    voice "voice/c51/6100250a01.opus"
    mx "\"Prométemelo.\""


translate english c5161_a03ab506:


    "De la nada, agarra mi mano."


translate english c5161_63e74891:



    voice "voice/c51/6100260a01.opus"
    mx "\"Prométeme que crees en el amor eterno.\""


translate english c5161_1b7991bc:


    xy "\"¿¿D-De dónde salió esto??\""


translate english c5161_e6fa97b4:



    voice "voice/c51/6100270a01.opus"
    mx "\"Prométemelo.\""


translate english c5161_9ddf245a:


    xy "\"¿Amor eterno? Suena un poco extremo—\""


translate english c5161_e77e76c4:



    voice "voice/c51/6100280a01.opus"
    mx "\"¡No trates de zafarte!\""


translate english c5161_e3f007bf:


    xy "\"¡Me estás lastimando!\""


translate english c5161_69ce91a7:



    voice "voice/c51/6100290a01.opus"
    mx "\"Perdón... pero...\""


translate english c5161_072b2740:


    "A pesar de su disculpa, no hace ningún esfuerzo por soltarla."


translate english c5161_83ed6908:



    voice "voice/c51/6100300a01.opus"
    mx "\"Por favor.\""


translate english c5161_9ee70d81:



    voice "voice/c51/6100310a01.opus"
    mx "\"Si me prometes esta sola cosa, será toda la fuerza que necesito.\""


translate english c5161_242e3842:



    voice "voice/c51/6100320a01.opus"
    mx "\"Solo esta cosa, y haré lo que sea por ti, ¿sí?\""


translate english c5161_9fe145e1:



    voice "voice/c51/6100330a01.opus"
    mx "\"Así que... prométeme que el amor es eterno.\""


translate english c5161_e35a4189:



    voice "voice/c51/6100340a02.opus"
    aoi "\"¡El negocio está en auge!\""


translate english c5161_90203f46:


    "A lo lejos, puedo oír a Aoi hablando distraídamente consigo misma."


translate english c5161_13a75528:


    "—Si dos personas comparten un beso en el techo, su amor será eterno."


translate english c5161_0f3e73b8:


    "No hay forma de que crea esa leyenda estúpida..."


translate english c5161_1cfe86fd:


    "Pero quiero creer en mi amor por Aoi."


translate english c5161_a3bee710:


    "Esto es incómodo... pero... supongo..."


translate english c5161_01_6c21221e:


    xy "\"Lo prometo.\""



translate english c5161_01_473908bb:



    voice "voice/c51/6100360a01.opus"
    mx "\"Bien. Gracias.\""



translate english c5161_01_ef1a192b:



    voice "voice/c51/6100370a01.opus"
    mx "\"Pase lo que pase, cree siempre que el amor es eterno, ¿sí?\""



translate english c5161_01_379c1ac5:


    xy "\"E-Está bien...\""



translate english c5161_01_c71ac470:


    "Algo en la forma en que lo dijo me molesta..."



translate english c5161_01_7e60768f:


    "En serio, ¿de dónde salió eso de repente...?"



translate english strings:


    old "Дать ей обещание"
    new "Promesa"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
