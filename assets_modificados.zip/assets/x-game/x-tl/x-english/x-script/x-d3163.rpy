

translate english d3163_c6c1cd53:


    xy "\"Yeah, you're right.\""


translate english d3163_6a35af6c:


    "No importa cuántas veces llame, su teléfono está fuera de servicio."


translate english d3163_16b782f2:


    "Es tarde, y no tenemos ninguna pista."


translate english d3163_1d2f87e4:



    voice "voice/d31/6300010a01.opus"
    mx "\"Let's just call it a day.\""


translate english d3163_b91f0b42:


    "Asiento."


translate english d3163_5f510a25:


    "Me siento tan absolutamente impotente..."


translate english d3163_07e942e7:


    "Estaba tan feliz de por fin ser su amigo, ¿pero al final esto es lo que obtenemos...?"


translate english d3163_76301759:



    voice "voice/d31/6300020a01.opus"
    mx "\"Come on now! Don't let this get you down!\""


translate english d3163_6b4cd289:



    voice "voice/d31/6300030a01.opus"
    mx "\"I'm sure Aoi just went back to her parents' house. That's gotta be where she is.\""


translate english d3163_5bc918bc:


    xy "\"I hope you're right...\""


translate english d3163_ab02697c:


    "A regañadientes, asiento otra vez."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
