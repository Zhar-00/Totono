

translate english e1134c_5f2a2539:



    voice "voice/e11/34b00030a01.opus"
    mx "\"You tricked me.\""


translate english e1134c_48889db3:



    voice "voice/e11/34b00040a01.opus"
    mx "\"I'll change that.\""


translate english e1134c_cf9c427f:



    voice "voice/e11/34b00050a01.opus"
    mx "\"I'll alter this world just like I altered the game...\""


translate english e1134c_8f35b96e:


    "Su pequeño susurro permanece ominosamente en mis oídos."


translate english e1134c_891490fd:



    voice "voice/e11/34b00060b01.opus"
    xtl "\"Haah... haah... nngh... Christ, dude!\""


translate english e1134c_3123c237:



    voice "voice/e11/34b00070b01.opus"
    xtl "\"The hell made you take off like that outta nowhere?!\""


translate english e1134c_17f628ed:


    "Ni yo sé por qué hice eso."


translate english e1134c_c5caadee:


    "No se me ocurre ninguna razón por la que querría huir de Miyuki."


translate english e1134c_15dc78ee:



    voice "voice/e11/34b00080b01.opus"
    xtl "\"Just when I finally got the chance to talk to Sone-san...\""


translate english e1134c_09a38528:


    xy "\"...You still haven't gotten over her?\""


translate english e1134c_b025d45e:


    xy "\"Why not settle for Aoi?\""


translate english e1134c_401662ac:


    "Según recuerdo, Yuutarou empezó a jugar novelas visuales recientemente como forma de superar su aplastante soledad en la vida real..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
