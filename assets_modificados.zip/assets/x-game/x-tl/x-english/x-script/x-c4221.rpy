

translate english c4221_d980328f:


    "Eru se lanza hacia adelante."


translate english c4221_12e64a21:


    xy "\"......\""


translate english c4221_cfd32163:


    "Es la primera vez que veo la azotea de noche."


translate english c4221_c1884da3:


    "Por un momento, el paisaje nocturno me quita el aliento."


translate english c4221_b467c948:


    "A primera vista, la azotea está desierta."


translate english c4221_82569b1e:


    "Pero sé que si me doy la vuelta, encontraré—"


translate english c4221_7fe1cf16:


    xy "\"Huh...?\""


translate english c4221_92e3e343:


    "...Aoi tampoco está sobre la azotea."


translate english c4221_81da4706:


    xy "\"She's not here...?\""


translate english c4221_e5d3a968:


    xy "\"She was... supposed to be here...\""


translate english c4221_5f63a356:


    "Aoi solía pasar cada día ahí arriba, mirando al cielo."


translate english c4221_101c3ea2:


    "Apuntaba su teléfono roto directo al aire y llamaba a Dios."


translate english c4221_49c93663:


    "Pero no se la encuentra por ningún lado."


translate english c4221_4df35ccc:


    "Eru mira la escalera y maúlla, como para empujarme hacia adelante."


translate english c4221_1a0fd8a0:


    "Pero por más que miro, yo—"


translate english c4221_e5978d61:



    voice "voice/c42/2100030a02.opus"
    aoi "\"......\""


translate english c4221_e76bd207:


    xy "\"Hm? Aoi?\""


translate english c4221_77a9bee6:



    voice "voice/c42/2100040a02.opus"
    bm "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c4221_e9c9708d:


    xy "\"Aoi?! Are you there?!\""


translate english c4221_89379c04:


    "Capto su señal, muy débilmente."


translate english c4221_538d30fd:


    "Apresuradamente, subo la escalera de golpe."


translate english c4221_96a7bc28:


    xy "\"Whoa...\""


translate english c4221_5f77942e:


    xy "\"Aoi...?\""


translate english c4221_d99dc724:


    "Ahí está: tendida sobre la cima de la azotea."


translate english c4221_bd93de70:


    xy "\"Aoi?! Hey!\""


translate english c4221_7b8abdee:


    "La atraigo hacia mis brazos."


translate english c4221_1054b3be:


    "Está helada."


translate english c4221_2501a2ee:


    "No... está respirando."


translate english c4221_9cf3a6e9:


    "Sus ojos están cerrados."


translate english c4221_b9ccc9ee:


    "So who was \"dialing\"hace un momento?"


translate english c4221_1b5ba6e7:



    voice "voice/c42/2100050a02.opus"
    aoi "\"My battery is dying.\""


translate english c4221_5eb4c343:


    "El smartphone de Aoi está tirado en el suelo junto a ella."


translate english c4221_ce1dfb89:


    "I can see the game version of \"Aoi\"en la pantalla."


translate english c4221_545bc2b2:


    xy "\"Hey! Aoi! AOI! What's wrong?! Answer me!\""


translate english c4221_78c99462:


    xy "\"Just when I finally found you... Goddamn it!!!\""


translate english c4221_d51d46e4:


    "Tengo que hacer algo."


translate english c4221_a228ca51:


    "¿Pero qué?"


translate english c4221_ec953634:



    voice "voice/c42/2100060a02.opus"
    aoi "\"Need to recharge.\""


translate english c4221_cb9d61e4:



    voice "voice/c42/2100070a02.opus"
    bm "\"Wanna... get zappy?\""


translate english strings:


    old "Сделать искусственное дыхание"
    new "Resucitación boca a boca"


    old "Позвонить в скорую"
    new "Llamar a una ambulancia"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
