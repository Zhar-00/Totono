

translate english e1135_bbc9cdec:



    voice "voice/e11/3500010a01.opus"
    mx "\"I'm not talking to you.\""


translate english e1135_0e3834ed:



    voice "voice/e11/3500020a01.opus"
    mx "\"I'm asking YOU.\""


translate english e1135_a219cf6b:


    xy "\"Who...?\""


translate english e1135_fe9ef23e:



    voice "voice/e11/3500030a01.opus"
    mx "\"You be quiet.\""


translate english e1135_5c2c6321:


    "Ante esto, me quedo en silencio, como se me ordena."


translate english e1135_dba0424d:



    voice "voice/e11/3500040a01.opus"
    mx "\"Do YOU remember?\""


translate english e1135_6490ce01:



    voice "voice/e11/3500050a01.opus"
    mx "\"The night Aoi rescued a kitten in the rain?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
