

translate english e2022_249a34c2:



    voice "voice/e20/2200010a01.opus"
    mx "\"...¿Shinichi?\""


translate english e2022_1c20cfad:


    xy "\"Nn... nnn... nn...\""


translate english e2022_422307a4:


    xy "\"¿Q... Qué...? ¿Miyuki?\""


translate english e2022_afcfb28b:



    voice "voice/e20/2200020a01.opus"
    mx "\"¿No has estado durmiendo lo suficiente? No puedo creer que te hayas quedado dormido así justo después del desayuno.\""


translate english e2022_310b0968:


    xy "\"¿Eh...? ¿Eso fue... todo un sueño...?\""


translate english e2022_1cbbe19e:


    mx "\"¿Tuviste un sueño erótico conmigo o algo?\""


translate english e2022_5a889794:


    xy "\"¿Eh? ¡N-No, claro que no!\""


translate english e2022_b91a824f:



    voice "voice/e20/2200040a01.opus"
    mx "\"Ah, ¿en serio...?\""


translate english e2022_fee156c8:


    "Mira hacia abajo a mi entrepierna y sonríe."


translate english e2022_e90e1430:


    "Naturalmente, estoy duro como un diamante."


translate english e2022_465d8d0a:



    voice "voice/e20/2200050a01.opus"
    mx "\"Muy bien. Vamos.\""


translate english e2022_da9e9efc:



    voice "voice/e20/2200060a01.opus"
    mx "\"Es hora de nuestra actividad del día.\""


translate english e2022_67ce4487:


    xy "\"V-Vale...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
