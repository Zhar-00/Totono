

translate english e2022_249a34c2:



    voice "voice/e20/2200010a01.opus"
    mx "\"...Shinichi?\""


translate english e2022_1c20cfad:


    xy "\"Nn... nnn... nn...\""


translate english e2022_422307a4:


    xy "\"Wh... What the...? Miyuki?\""


translate english e2022_afcfb28b:



    voice "voice/e20/2200020a01.opus"
    mx "\"Have you not been getting enough sleep? I can't believe you conked out right after breakfast like that.\""


translate english e2022_310b0968:


    xy "\"Huh...? Was that... all a dream...?\""


translate english e2022_1cbbe19e:


    mx "\"Did you have a sexy dream about me or something?\""


translate english e2022_5a889794:


    xy "\"Huh? N-No, of course not!\""


translate english e2022_b91a824f:



    voice "voice/e20/2200040a01.opus"
    mx "\"Oh really...\""


translate english e2022_fee156c8:


    "Mira hacia abajo a mi entrepierna y sonríe."


translate english e2022_e90e1430:


    "Naturalmente, estoy duro como un diamante."


translate english e2022_465d8d0a:



    voice "voice/e20/2200050a01.opus"
    mx "\"Alright then. C'mon.\""


translate english e2022_da9e9efc:



    voice "voice/e20/2200060a01.opus"
    mx "\"It's time for our activity of the day.\""


translate english e2022_67ce4487:


    xy "\"O-Okay...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
