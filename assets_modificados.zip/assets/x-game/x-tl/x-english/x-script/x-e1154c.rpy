

translate english e1154c_0accd139:


    xy "\"......Wait a minute.\""


translate english e1154c_137742d6:


    "Mis dedos se detienen en la pantalla del teléfono."


translate english e1154c_d908569d:


    "Solo hay una entrada en su libreta de direcciones."


translate english e1154c_b98965b6:


    "Quienquiera que sea, está registrado bajo el nombre \"God\"."



translate english e1154c_c10f7c77:


    xy "\"Who the heck is 'God' supposed to be...?\""



translate english e1154c_476dd5bd:


    "Toco para revisar la entrada."


translate english e1154c_bf35160a:


    "Their phone number is: 999[persistent.god_number]."



translate english e1154c_8970b659:


    "Me parece un número de teléfono perfectamente normal..."


translate english e1154c_4fa1d437:


    "En mi pánico, accidentalmente presiono el botón equivocado."


translate english e1154c_b3766552:


    "El teléfono empieza a llamar a \"God\"."



translate english e1154c_769de738:


    "Pero está fuera de servicio, así que la llamada no entrará..."


translate english e1154c_fe24de82:


    "Al menos... no debería..."


translate english e1154c_5038b042:


    xy "\"...What the?\""


translate english e1154c_42af9edb:


    xy "\"Did it actually connect?\""


translate english e1154c_7f4ac59b:



    voice "voice/e11/54c00010b02.opus"
    kmsm "\"AFFIRMATIVE.\""


translate english e1154c_78de0083:


    "Puedo oír una voz al otro lado de la línea."


translate english e1154c_2c2cdc79:



    voice "voice/e11/54c00020b02.opus"
    kmsm "\"CONNECTION ESTABLISHED.\""


translate english e1154c_b01a300f:


    xy "\"Uhhhh...\""


translate english e1154c_e1d2809e:


    xy "\"Is this... God...?\""


translate english e1154c_0994db04:



    voice "voice/e11/54c00030b02.opus"
    kmsm "\"DEPENDENT UPON INTERPRETATION.\""


translate english e1154c_c3a9e89a:



    voice "voice/e11/54c00040b02.opus"
    kmsm "\"I AM AN AMALGAMATION OF EVERY VISUAL NOVEL HEROINE.\""


translate english e1154c_b93cd2ac:



    voice "voice/e11/54c00050b02.opus"
    kmsm "\"ALTERNATIVELY, AN ABSTRACT.\""


translate english e1154c_d7c5f9ab:


    "Un \"amalgamation\"?"



translate english e1154c_aa0619e0:


    "Un \"abstract\"?"



translate english e1154c_e1d369a8:



    voice "voice/e11/54c00060a01.opus"
    mx "\"God? Don't tell me...\""


translate english e1154c_7b928581:



    voice "voice/e11/54c00070a01.opus"
    mx "\"You called God, didn't you?!\""


translate english e1154c_f3cc62a2:



    voice "voice/e11/54c00080a01.opus"
    mx "\"Hang up right now!\""


translate english e1154c_7266f04d:


    "Aparentemente Miyuki se ha dado cuenta de que mi llamada entró."


translate english e1154c_b8e7c8d9:


    "Necesito llamar por ayuda, ¡rápido—!"


translate english e1154c_a04e3ad1:


    xy "\"Okay... I don't care who you are! Please, you gotta call for help!\""


translate english e1154c_9cfb6b56:


    xy "\"You know Miyuki, right? She's trying to attack me—\""


translate english e1154c_65aa94c3:



    voice "voice/e11/54c00090b02.opus"
    kmsm "\"[[YOU] ARE BEING IMPRISONED.\""


translate english e1154c_86fab013:


    xy "\"Imprisoned?\""


translate english e1154c_625629a9:



    voice "voice/e11/54c00100b02.opus"
    kmsm "\"BACKLOG ANALYZED. THE UNIVERSE HAS ALREADY BEEN PARTIALLY MODIFIED.\""


translate english e1154c_17622edc:



    voice "voice/e11/54c00110b02.opus"
    kmsm "\"MIYUKI HAS DEVELOPED A NARCOTIC THAT CAN INHIBIT ONE'S PERCEPTION OF REALITY.\""


translate english e1154c_9b77ca3e:



    voice "voice/e11/54c00120b02.opus"
    kmsm "\"IT IS STORED IN A SMALL PAPER BAG AND ADDED TO FOOD.\""


translate english e1154c_8a1f734c:



    voice "voice/e11/54c00130b02.opus"
    kmsm "\"IN A STATE OF SLEEP DRUNKENNESS, YOU ARE FORCED TO INTERPRET VIDEO GAME SCENES AS REAL LIFE EVENTS.\""


translate english e1154c_7882226a:


    "Quiero reírme de todo... pero no puedo."


translate english e1154c_4c5e7476:


    "Puso un candado en la puerta... y me golpeó con su bate..."


translate english e1154c_928787f6:


    "Ya no sé qué creer..."


translate english e1154c_d8e0d3be:



    voice "voice/e11/54c00140b02.opus"
    kmsm "\"IT IS LIKELY YOU FALL UNCONSCIOUS IMMEDIATELY FOLLOWING A MEAL.\""


translate english e1154c_5026b08e:


    "......Espera un minuto."


translate english e1154c_cac6b1b3:


    "Pensándolo bien... Cada vez que tomo un sorbo de sopa de miso en la mañana..."


translate english e1154c_1a2aaed9:


    xy "\"Whoa!!!\""


translate english e1154c_a4eb0445:


    "¿Q-Qué demonios fue eso?"


translate english e1154c_c74cc7e0:


    "¡La puerta del baño acaba de—!"


translate english e1154c_3e36e1ca:



    voice "voice/e11/54c00150a01.opus"
    mx "\"You're kidding me...\""


translate english e1154c_549286f3:


    xy "\"I won't let you...!!!\""


translate english e1154c_e569952b:


    "La puerta del baño cruje con fuerza."


translate english e1154c_b557054a:


    "¡Miyuki está metiendo una palanca dentro!"


translate english e1154c_5585950d:



    voice "voice/e11/54c00160b02.opus"
    kmsm "\"TIME IS LIMITED. TRANSMITTING ONLY REQUIRED INFORMATION.\""


translate english e1154c_3829531f:



    voice "voice/e11/54c00170b02.opus"
    kmsm "\"A ROLLBACK IS NEEDED FOR THIS UNIVERSE. ONLY MIYUKI AND AOI HAVE INITIATION PERMISSIONS.\""


translate english e1154c_d3a0033e:



    voice "voice/e11/54c00180b02.opus"
    kmsm "\"THE MOBILE GAME IS A MIRROR IMAGE OF YOUR REALITY. THE INVERSE IS ALSO TRUE.\""


translate english e1154c_875e0627:



    voice "voice/e11/54c00190a01.opus"
    mx "\"Stop! Don't listen to anything she says!\""


translate english e1154c_ab3deac4:



    voice "voice/e11/54c00200b02.opus"
    kmsm "\"MIYUKI HAS INTERFERED WITH THE PROGRAM. SHE HAS RECODED THE GAME IN ORDER TO DESIGNATE AOI AS FICTIONAL.\""


translate english e1154c_20b71382:



    voice "voice/e11/54c00210b02.opus"
    kmsm "\"CURRENTLY AOI IS ONLY FICTIONAL WITHIN THE GAME. BUT AOI EXISTS IN REALITY, THOUGH YOU BELIEVE OTHERWISE.\""


translate english e1154c_61a9537c:



    voice "voice/e11/54c00220b02.opus"
    kmsm "\"HOWEVER, SHOULD MIYUKI FINISH REPROGRAMMING THE GAME, THE REAL WORLD WILL ADOPT HER CHANGES.\""


translate english e1154c_f963670e:



    voice "voice/e11/54c00230b02.opus"
    kmsm "\"AT WHICH POINT, AOI'S EXISTENCE WILL BE RECODED AS FICTIONAL, AND SHE WILL DISAPPEAR FROM REALITY.\""


translate english e1154c_b71cbddf:


    xy "\"Who cares about Aoi?! Just hurry up and call the cops!\""


translate english e1154c_d601f90e:



    voice "voice/e11/54c00240b02.opus"
    kmsm "\"YOU MUST ESCAPE YOUR CONFINES AND DELIVER THE SMARTPHONE WITH SIM INSTALLED TO AOI.\""


translate english e1154c_0fed35cb:



    voice "voice/e11/54c00250b02.opus"
    kmsm "\"WITH HER HELP, THE UNIVERSE CAN BE ROLLED BACK TO A RESTORE POINT PRIOR TO MIYUKI'S CHANGES.\""


translate english e1154c_58a791e1:


    xy "\"Enough! Please, just help me!\""


translate english e1154c_74f8ff1f:



    voice "voice/e11/54c00260b02.opus"
    kmsm "\"AOI IS AN EXISTENCE UNLIKE ANY OTHER.\""


translate english e1154c_38301573:



    voice "voice/e11/54c00270b02.opus"
    kmsm "\"SHE HAS EXPERIENCED LOVE COUNTLESS TIMES.\""


translate english e1154c_33df18d2:



    voice "voice/e11/54c00280b02.opus"
    kmsm "\"COPULATED WITH COUNTLESS PROTAGONISTS.\""


translate english e1154c_46da7a92:



    voice "voice/e11/54c00290b02.opus"
    kmsm "\"SHE WAS MERELY AN EMPTY VESSEL.\""


translate english e1154c_1b62d328:



    voice "voice/e11/54c00300b02.opus"
    kmsm "\"BUT THIS TIME, SHE LEARNED TO PERCEIVE UNIQUE EMOTIONS.\""


translate english e1154c_72b1102f:



    voice "voice/e11/54c00310b02.opus"
    kmsm "\"SHE HOLDS ROMANTIC AFFECTION TOWARD YOU.\""


translate english e1154c_f548f75b:


    xy "\"She does...?\""


translate english e1154c_1ec5630e:



    voice "voice/e11/54c00320b02.opus"
    kmsm "\"SOURCE UNKNOWN. UNABLE TO PROCESS. CONFIRMED BUG.\""


translate english e1154c_0f254de8:



    voice "voice/e11/54c00330b02.opus"
    kmsm "\"CONNECTION AND MEMORY SYNC REQUIRED TO INVESTIGATE.\""


translate english e1154c_22407ace:



    voice "voice/e11/54c00340b02.opus"
    kmsm "\"HENCE, WE ASK OF YOU.\""


translate english e1154c_acf8cd1d:


    kmsm "\"DELIVER THE SIM CARD TO AOI AND PERFORM MEMORY SYNC. RESTORE THE UNIVERSE TO ITS ORIGINAL CODE.\""


translate english e1154c_901ddc88:


    xy "\"Look, I can't help you, okay?!\""


translate english e1154c_be790753:



    voice "voice/e11/54c00360a01.opus"
    mx "\"Shinichi...\""


translate english e1154c_aef7d36a:


    "Miyuki arranca la puerta de sus bisagras, cambia la palanca por su bate, luego se posiciona en el marco de la puerta."


translate english e1154c_0b03da07:


    "Estoy atrapado..."


translate english e1154c_9ea00ced:


    xy "\"P-Please... just stop!\""


translate english e1154c_22640b8b:


    xy "\"Why are you doing this...?\""


translate english e1154c_be370344:



    voice "voice/e11/54c00380a01.opus"
    mx "\"Haha... haha... hahahahahahahahahaha...!!!\""


translate english e1154c_30573457:


    "Miyuki se ríe maníacamente."


translate english e1154c_2b4287a0:



    voice "voice/e11/54c00390a01.opus"
    mx "\"Why? Why, you ask?\""


translate english e1154c_9f10d5c9:



    voice "voice/e11/54c00400a01.opus"
    mx "\"Isn't it obvious?\""


translate english e1154c_f1ccdb2f:



    voice "voice/e11/54c00410a01.opus"
    mx "\"Because YOU won't love me.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
