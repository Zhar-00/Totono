

translate english e1154c_0accd139:


    xy "\"......Espera un momento.\""


translate english e1154c_137742d6:


    "Mis dedos se detienen en la pantalla del teléfono."


translate english e1154c_d908569d:


    "Solo hay una entrada en su libreta de direcciones."


translate english e1154c_b98965b6:


    "Quienquiera que sea, está registrado bajo el nombre \"God\"."



translate english e1154c_c10f7c77:


    xy "\"¿Y quién demonios se supone que es \"Dios\"...?\""



translate english e1154c_476dd5bd:


    "Toco para revisar la entrada."


translate english e1154c_bf35160a:


    "Their phone number is: 999[persistent.god_number]."



translate english e1154c_8970b659:


    "Me parece un número de teléfono perfectamente normal..."


translate english e1154c_4fa1d437:


    "En mi pánico, accidentalmente presiono el botón equivocado."


translate english e1154c_b3766552:


    "El teléfono empieza a llamar a \"God\"."



translate english e1154c_769de738:


    "Pero está fuera de servicio, así que la llamada no entrará..."


translate english e1154c_fe24de82:


    "Al menos... no debería..."


translate english e1154c_5038b042:


    xy "\"...¿Qué rayos?\""


translate english e1154c_42af9edb:


    xy "\"¿De verdad se conectó?\""


translate english e1154c_7f4ac59b:



    voice "voice/e11/54c00010b02.opus"
    kmsm "\"AFIRMATIVO.\""


translate english e1154c_78de0083:


    "Puedo oír una voz al otro lado de la línea."


translate english e1154c_2c2cdc79:



    voice "voice/e11/54c00020b02.opus"
    kmsm "\"CONEXIÓN ESTABLECIDA.\""


translate english e1154c_b01a300f:


    xy "\"Uhhhh...\""


translate english e1154c_e1d2809e:


    xy "\"¿Esto es... Dios...?\""


translate english e1154c_0994db04:



    voice "voice/e11/54c00030b02.opus"
    kmsm "\"DEPENDE DE LA INTERPRETACIÓN.\""


translate english e1154c_c3a9e89a:



    voice "voice/e11/54c00040b02.opus"
    kmsm "\"SOY UNA AMALGAMA DE TODAS LAS HEROÍNAS DE NOVELAS VISUALES.\""


translate english e1154c_b93cd2ac:



    voice "voice/e11/54c00050b02.opus"
    kmsm "\"O BIEN, UNA ABSTRACCIÓN.\""


translate english e1154c_d7c5f9ab:


    "Un \"amalgamation\"?"



translate english e1154c_aa0619e0:


    "Un \"abstract\"?"



translate english e1154c_e1d369a8:



    voice "voice/e11/54c00060a01.opus"
    mx "\"¿Dios? No me digas...\""


translate english e1154c_7b928581:



    voice "voice/e11/54c00070a01.opus"
    mx "\"¡Llamaste a Dios, ¿verdad?!\""


translate english e1154c_f3cc62a2:



    voice "voice/e11/54c00080a01.opus"
    mx "\"¡Cuelga ahora mismo!\""


translate english e1154c_7266f04d:


    "Aparentemente Miyuki se ha dado cuenta de que mi llamada entró."


translate english e1154c_b8e7c8d9:


    "Necesito llamar por ayuda, ¡rápido—!"


translate english e1154c_a04e3ad1:


    xy "\"Oye... ¡No me importa quién seas! ¡Por favor, tienes que pedir ayuda!\""


translate english e1154c_9cfb6b56:


    xy "\"Conoces a Miyuki, ¿verdad? Está tratando de atacarme—\""


translate english e1154c_65aa94c3:



    voice "voice/e11/54c00090b02.opus"
    kmsm "\"[[YOU] ARE BEING IMPRISONED.\""


translate english e1154c_86fab013:


    xy "\"¿Encarcelado?\""


translate english e1154c_625629a9:



    voice "voice/e11/54c00100b02.opus"
    kmsm "\"REGISTRO ANALIZADO. EL UNIVERSO YA HA SIDO MODIFICADO PARCIALMENTE.\""


translate english e1154c_17622edc:



    voice "voice/e11/54c00110b02.opus"
    kmsm "\"MIYUKI HA DESARROLLADO UN NARCÓTICO QUE INHIBE LA PERCEPCIÓN DE LA REALIDAD.\""


translate english e1154c_9b77ca3e:



    voice "voice/e11/54c00120b02.opus"
    kmsm "\"SE GUARDA EN UNA PEQUEÑA BOLSA DE PAPEL Y SE AÑADE A LA COMIDA.\""


translate english e1154c_8a1f734c:



    voice "voice/e11/54c00130b02.opus"
    kmsm "\"EN UN ESTADO DE EMBRIAGUEZ DE SUEÑO, SE TE FUERZA A INTERPRETAR ESCENAS DE VIDEOJUEGO COMO EVENTOS DE LA VIDA REAL.\""


translate english e1154c_7882226a:


    "Quiero reírme de todo... pero no puedo."


translate english e1154c_4c5e7476:


    "Puso un candado en la puerta... y me golpeó con su bate..."


translate english e1154c_928787f6:


    "Ya no sé qué creer..."


translate english e1154c_d8e0d3be:



    voice "voice/e11/54c00140b02.opus"
    kmsm "\"ES PROBABLE QUE PIERDAS EL CONOCIMIENTO INMEDIATAMENTE DESPUÉS DE COMER.\""


translate english e1154c_5026b08e:


    "......Espera un minuto."


translate english e1154c_cac6b1b3:


    "Pensándolo bien... Cada vez que tomo un sorbo de sopa de miso en la mañana..."


translate english e1154c_1a2aaed9:


    xy "\"¡¡¡Guau!!!\""


translate english e1154c_a4eb0445:


    "¿Q-Qué demonios fue eso?"


translate english e1154c_c74cc7e0:


    "¡La puerta del baño acaba de—!"


translate english e1154c_3e36e1ca:



    voice "voice/e11/54c00150a01.opus"
    mx "\"Estás bromeando...\""


translate english e1154c_549286f3:


    xy "\"¡¡¡No te lo permitiré...!!!\""


translate english e1154c_e569952b:


    "La puerta del baño cruje con fuerza."


translate english e1154c_b557054a:


    "¡Miyuki está metiendo una palanca dentro!"


translate english e1154c_5585950d:



    voice "voice/e11/54c00160b02.opus"
    kmsm "\"EL TIEMPO ES LIMITADO. TRANSMITIENDO SOLO LA INFORMACIÓN NECESARIA.\""


translate english e1154c_3829531f:



    voice "voice/e11/54c00170b02.opus"
    kmsm "\"SE NECESITA UNA REVERSIÓN EN ESTE UNIVERSO. SOLO MIYUKI Y AOI TIENEN PERMISOS DE INICIACIÓN.\""


translate english e1154c_d3a0033e:



    voice "voice/e11/54c00180b02.opus"
    kmsm "\"EL JUEGO MÓVIL ES UN REFLEJO DE TU REALIDAD. LO INVERSO TAMBIÉN ES CIERTO.\""


translate english e1154c_875e0627:



    voice "voice/e11/54c00190a01.opus"
    mx "\"¡Basta! ¡No escuches nada de lo que dice!\""


translate english e1154c_ab3deac4:



    voice "voice/e11/54c00200b02.opus"
    kmsm "\"MIYUKI HA INTERFERIDO CON EL PROGRAMA. HA RECODIFICADO EL JUEGO PARA DESIGNAR A AOI COMO FICTICIA.\""


translate english e1154c_20b71382:



    voice "voice/e11/54c00210b02.opus"
    kmsm "\"ACTUALMENTE AOI ES SOLO FICTICIA DENTRO DEL JUEGO. PERO AOI EXISTE EN LA REALIDAD, AUNQUE TÚ CREAS LO CONTRARIO.\""


translate english e1154c_61a9537c:



    voice "voice/e11/54c00220b02.opus"
    kmsm "\"SIN EMBARGO, SI MIYUKI TERMINA DE REPROGRAMAR EL JUEGO, EL MUNDO REAL ADOPTARÁ SUS CAMBIOS.\""


translate english e1154c_f963670e:



    voice "voice/e11/54c00230b02.opus"
    kmsm "\"EN ESE MOMENTO, LA EXISTENCIA DE AOI SERÁ RECODIFICADA COMO FICTICIA Y DESAPARECERÁ DE LA REALIDAD.\""


translate english e1154c_b71cbddf:


    xy "\"¡¿A quién le importa Aoi?! ¡Apúrate y llama a la policía!\""


translate english e1154c_d601f90e:



    voice "voice/e11/54c00240b02.opus"
    kmsm "\"DEBES ESCAPAR DE TU ENCIERRO Y ENTREGARLE A AOI EL TELÉFONO CON LA TARJETA SIM INSTALADA.\""


translate english e1154c_0fed35cb:



    voice "voice/e11/54c00250b02.opus"
    kmsm "\"CON SU AYUDA, EL UNIVERSO PUEDE REVERTIRSE A UN PUNTO DE RESTAURACIÓN ANTERIOR A LOS CAMBIOS DE MIYUKI.\""


translate english e1154c_58a791e1:


    xy "\"¡Basta! ¡Por favor, solo ayúdame!\""


translate english e1154c_74f8ff1f:



    voice "voice/e11/54c00260b02.opus"
    kmsm "\"AOI ES UNA EXISTENCIA COMO NINGUNA OTRA.\""


translate english e1154c_38301573:



    voice "voice/e11/54c00270b02.opus"
    kmsm "\"HA EXPERIMENTADO EL AMOR INCONTABLES VECES.\""


translate english e1154c_33df18d2:



    voice "voice/e11/54c00280b02.opus"
    kmsm "\"HA COPULADO CON INCONTABLES PROTAGONISTAS.\""


translate english e1154c_46da7a92:



    voice "voice/e11/54c00290b02.opus"
    kmsm "\"ERA MERAMENTE UN RECIPIENTE VACÍO.\""


translate english e1154c_1b62d328:



    voice "voice/e11/54c00300b02.opus"
    kmsm "\"PERO ESTA VEZ, APRENDIÓ A PERCIBIR EMOCIONES ÚNICAS.\""


translate english e1154c_72b1102f:



    voice "voice/e11/54c00310b02.opus"
    kmsm "\"SIENTE AFECTO ROMÁNTICO HACIA TI.\""


translate english e1154c_f548f75b:


    xy "\"¿De verdad...?\""


translate english e1154c_1ec5630e:



    voice "voice/e11/54c00320b02.opus"
    kmsm "\"FUENTE DESCONOCIDA. IMPOSIBLE PROCESAR. ERROR CONFIRMADO.\""


translate english e1154c_0f254de8:



    voice "voice/e11/54c00330b02.opus"
    kmsm "\"SE REQUIERE CONEXIÓN Y SINCRONIZACIÓN DE MEMORIA PARA INVESTIGAR.\""


translate english e1154c_22407ace:



    voice "voice/e11/54c00340b02.opus"
    kmsm "\"POR ELLO, TE LO PEDIMOS.\""


translate english e1154c_acf8cd1d:


    kmsm "\"ENTREGA LA TARJETA SIM A AOI Y REALIZA LA SINCRONIZACIÓN DE MEMORIA. RESTAURA EL UNIVERSO A SU CÓDIGO ORIGINAL.\""


translate english e1154c_901ddc88:


    xy "\"Mira, no puedo ayudarte, ¿sí?!\""


translate english e1154c_be790753:



    voice "voice/e11/54c00360a01.opus"
    mx "\"Shinichi...\""


translate english e1154c_aef7d36a:


    "Miyuki arranca la puerta de sus bisagras, cambia la palanca por su bate, luego se posiciona en el marco de la puerta."


translate english e1154c_0b03da07:


    "Estoy atrapado..."


translate english e1154c_9ea00ced:


    xy "\"¡P-Por favor... basta ya!\""


translate english e1154c_22640b8b:


    xy "\"¿Por qué haces esto...?\""


translate english e1154c_be370344:



    voice "voice/e11/54c00380a01.opus"
    mx "\"Jaja... jaja... ¡¡¡jajajajajajajajajaja...!!!\""


translate english e1154c_30573457:


    "Miyuki se ríe maníacamente."


translate english e1154c_2b4287a0:



    voice "voice/e11/54c00390a01.opus"
    mx "\"¿Por qué? ¿Por qué, preguntas?\""


translate english e1154c_9f10d5c9:



    voice "voice/e11/54c00400a01.opus"
    mx "\"¿No es obvio?\""


translate english e1154c_f1ccdb2f:



    voice "voice/e11/54c00410a01.opus"
    mx "\"Porque TÚ no me amarás.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
