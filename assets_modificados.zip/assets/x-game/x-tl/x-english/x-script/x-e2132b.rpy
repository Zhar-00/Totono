

translate english e2132b_e8e1f543:


    xy "\"Tea, definitely.\""


translate english e2132b_41b10661:



    voice "voice/e21/32b00010a01.opus"
    mx "\"Thought so. I know you can't stand tomato juice.\""


translate english e2132b_5a0ac8c9:


    xy "\"Eh, I could still drink it, though.\""


translate english e2132b_8ee1d1fa:



    voice "voice/e21/32b00020a01.opus"
    "\"Ggllpp... ggllpp... ggllpp...\""



translate english e2132b_93b4c111:



    voice "voice/e21/32b00030a01.opus"
    mx "\"Yep... It sure tastes like tomato, alright...\""


translate english e2132b_27e843bb:


    "Miyuki hace una mueca de disgusto."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
