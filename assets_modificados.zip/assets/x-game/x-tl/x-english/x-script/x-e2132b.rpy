

translate english e2132b_e8e1f543:


    xy "\"Té, definitivamente.\""


translate english e2132b_41b10661:



    voice "voice/e21/32b00010a01.opus"
    mx "\"Lo suponía. Sé que no soportas el jugo de tomate.\""


translate english e2132b_5a0ac8c9:


    xy "\"Eh, aun así podría beberlo.\""


translate english e2132b_8ee1d1fa:



    voice "voice/e21/32b00020a01.opus"
    "\"Ggllpp... ggllpp... ggllpp...\""



translate english e2132b_93b4c111:



    voice "voice/e21/32b00030a01.opus"
    mx "\"Sí... Sin duda sabe a tomate...\""


translate english e2132b_27e843bb:


    "Miyuki hace una mueca de disgusto."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
