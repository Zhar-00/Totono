

translate english e2021_921e53de:



    voice "voice/e20/2100010a01.opus"
    mx "\"Shinichi...\""



translate english e2021_9850aab6:



    voice "voice/e20/2100020a01.opus"
    mx "\"Ya ha pasado un mes entero.\""


translate english e2021_d13fca29:



    voice "voice/e20/2100030a01.opus"
    mx "\"¿Lo sabías? Dios, el tiempo vuela...\""


translate english e2021_290446fb:



    voice "voice/e20/2100040a01.opus"
    mx "\"Sobre todo si TÚ presionas el botón de Saltar.\""


translate english e2021_bffe4a7d:


    xy "\"¿Qué botón de Saltar...?\""


translate english e2021_74922b3f:



    voice "voice/e20/2100050a01.opus"
    mx "\"Oye, ¿Shinichi?\""


translate english e2021_bf8d3e5f:



    voice "voice/e20/2100060a01.opus"
    mx "\"¿Recuerdas... la primera vez que tuvimos sexo?\""


translate english e2021_46bc0fb0:


    xy "\"¿Eh...?\""



translate english e2021_5ce47e2c:



    voice "voice/e20/2100070a01.opus"
    mx "\"¿Recuerdas dónde estábamos, o en qué posición estábamos?\""


translate english e2021_d0f0c239:



    voice "voice/e20/2100080a01.opus"
    mx "\"Supongo que no, ¿eh...?\""


translate english e2021_90a3cef5:


    xy "\"B-Bueno...\""


translate english e2021_5f8e3b34:


    "No puedo exactamente negarlo..."


translate english e2021_cc65c92e:


    "Por alguna razón, mis recuerdos están todos borrosos..."


translate english e2021_60afc632:


    "No puedo recordar..."


translate english e2021_7cf8a04b:



    voice "voice/e20/2100090a01.opus"
    mx "\"No tienes que ocultarlo.\""


translate english e2021_e7547030:



    voice "voice/e20/2100100a01.opus"
    mx "\"¡Ya sé! Para celebrar nuestro primer mes juntos...\""


translate english e2021_29e885fa:



    voice "voice/e20/2100110a01.opus"
    mx "\"...te dejaré revivirlo todo otra vez.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
