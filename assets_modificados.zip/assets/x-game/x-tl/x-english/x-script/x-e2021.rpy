

translate english e2021_921e53de:



    voice "voice/e20/2100010a01.opus"
    mx "\"Shinichi...\""



translate english e2021_9850aab6:



    voice "voice/e20/2100020a01.opus"
    mx "\"It's been a whole month now.\""


translate english e2021_d13fca29:



    voice "voice/e20/2100030a01.opus"
    mx "\"Did you know that? Gosh, time flies...\""


translate english e2021_290446fb:



    voice "voice/e20/2100040a01.opus"
    mx "\"Especially if YOU hit the Skip button.\""


translate english e2021_bffe4a7d:


    xy "\"What Skip button...?\""


translate english e2021_74922b3f:



    voice "voice/e20/2100050a01.opus"
    mx "\"Hey, Shinichi?\""


translate english e2021_bf8d3e5f:



    voice "voice/e20/2100060a01.opus"
    mx "\"Do you remember... the first time we had sex?\""


translate english e2021_46bc0fb0:


    xy "\"Huh...?\""



translate english e2021_5ce47e2c:



    voice "voice/e20/2100070a01.opus"
    mx "\"Do you remember where we were, or what position we were in?\""


translate english e2021_d0f0c239:



    voice "voice/e20/2100080a01.opus"
    mx "\"I guess you wouldn't, huh...\""


translate english e2021_90a3cef5:


    xy "\"W-Well...\""


translate english e2021_5f8e3b34:


    "No puedo exactamente negarlo..."


translate english e2021_cc65c92e:


    "Por alguna razón, mis recuerdos están todos borrosos..."


translate english e2021_60afc632:


    "No puedo recordar..."


translate english e2021_7cf8a04b:



    voice "voice/e20/2100090a01.opus"
    mx "\"You don't have to hide it.\""


translate english e2021_e7547030:



    voice "voice/e20/2100100a01.opus"
    mx "\"I know! To celebrate our first month together...\""


translate english e2021_29e885fa:



    voice "voice/e20/2100110a01.opus"
    mx "\"...I'll let you relive it all over again.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
