

translate english c3211_c70fb191:


    "Apenas entro, miro hacia el mostrador."


translate english c3211_b731a3ad:


    "Alguien atiende la caja, pero no es Yuutarou."


translate english c3211_834a7c72:



    voice "voice/c32/1100010b03.opus"
    c "\"W-Welco—\""


translate english c3211_35ae1e03:



    voice "voice/c32/1100020b03.opus"
    c "\"AAAAAAAAAAHHHHHHH!!!\""


translate english c3211_694e4de9:


    "Deja escapar un chillido e intenta esconderse detrás del mostrador."


translate english c3211_3a6ff83e:


    "Luego choca contra los estantes de cajetillas de cigarrillos detrás de ella."


translate english c3211_9509ddd8:


    "Las cajas caen sobre ella en avalancha, sepultándola."


translate english c3211_5c6ad2be:



    voice "voice/c32/1100030a02.opus"
    aoi "\"Is that the klutz?\""


translate english c3211_4e919375:


    xy "\"Yeah... The one from the theatre club.\""


translate english c3211_2ea2ba77:


    "No hay forma de que confunda ese grito escalofriante."


translate english c3211_5fa9e5fb:


    xy "\"Um... Are you okay back there?\""


translate english c3211_c56085f1:



    voice "voice/c32/1100040b03.opus"
    c "\"Y-Yeah... I'm fine... Owww...\""


translate english c3211_90a1e8e0:


    xy "\"I can help you put the cigarettes back—\""


translate english c3211_ec77da68:



    voice "voice/c32/1100050b03.opus"
    c "\"No thank you! I can handle it! Don't worry about it!\""


translate english c3211_3709d40a:



    voice "voice/c32/1100060b03.opus"
    c "\"I'm used to it by now, anyway.\""


translate english c3211_34fc1333:



    voice "voice/c32/1100070a02.opus"
    aoi "\"Did you catch a glimpse of something naughty? Her panties, maybe?\""


translate english c3211_d881e353:



    voice "voice/c32/1100080b03.opus"
    c "\"What? Oh my god! Shut up! No way—!\""


translate english c3211_098152e4:


    xy "\"I saw nothing.\""


translate english c3211_5881bd87:


    "¡Lleva pantalones, genio!"


translate english c3211_17385b05:


    xy "\"Anyway, we need to prioritize the kitten here.\""


translate english c3211_7fff9e8e:



    voice "voice/c32/1100090a02.opus"
    aoi "\"Good point.\""


translate english c3211_af157343:


    xy "\"Oh, wait—!\""


translate english c3211_b681ea58:


    "Intento detenerla, pero es demasiado tarde."


translate english c3211_f7ad9cf1:


    "Aoi saca a Eru de su bolsillo, y este salta a un estante sobre el mostrador."


translate english c3211_2d3795c8:



    voice "voice/c32/1100110b03.opus"
    c "\"AAAH! Senpai, no!\""


translate english c3211_bec27875:



    voice "voice/c32/1100120b03.opus"
    c "\"Our store doesn't allow pets!!!\""


translate english c3211_1ee9efaa:



    voice "voice/c32/1100130b03.opus"
    c "\"Aaagghh! Get down from there, kitty—!\""


translate english c3211_3c4ab577:


    "El gatito todavía es un poco torpe en sus movimientos—"


translate english c3211_47353277:


    "—y aun así esta chica de teatro es de algún modo aún peor."


translate english c3211_62c3b3b9:



    voice "voice/c32/1100140b03.opus"
    c "\"If they found out I let you in the store—AAAHH!\""


translate english c3211_5abb0450:



    voice "voice/c32/1100150b03.opus"
    c "\"They're gonna—lower my wages—AAAAAAAHHH!!!\""


translate english c3211_7790215c:


    "Intenta jalar un estante hacia adelante para alcanzar al gatito, y este se desploma de inmediato."


translate english c3211_88348830:


    "Una vez más, queda sepultada bajo una montaña de cajetillas de cigarrillos."


translate english c3211_cd290cd9:



    voice "voice/c32/1100160a02.opus"
    aoi "\"Are you a fan of the clumsy type?\""


translate english c3211_8eb87649:


    xy "\"Just shut up and help me dig her out of there.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
