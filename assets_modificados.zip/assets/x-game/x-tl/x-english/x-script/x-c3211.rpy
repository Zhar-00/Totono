

translate english c3211_c70fb191:


    "Apenas entro, miro hacia el mostrador."


translate english c3211_b731a3ad:


    "Alguien atiende la caja, pero no es Yuutarou."


translate english c3211_834a7c72:



    voice "voice/c32/1100010b03.opus"
    c "\"B-Bienveni—\""


translate english c3211_35ae1e03:



    voice "voice/c32/1100020b03.opus"
    c "\"¡¡¡AAAAAAAAAAHHHHHH!!!\""


translate english c3211_694e4de9:


    "Deja escapar un chillido e intenta esconderse detrás del mostrador."


translate english c3211_3a6ff83e:


    "Luego choca contra los estantes de cajetillas de cigarrillos detrás de ella."


translate english c3211_9509ddd8:


    "Las cajas caen sobre ella en avalancha, sepultándola."


translate english c3211_5c6ad2be:



    voice "voice/c32/1100030a02.opus"
    aoi "\"¿Esa es la torpe?\""


translate english c3211_4e919375:


    xy "\"Sí... La del club de teatro.\""


translate english c3211_2ea2ba77:


    "No hay forma de que confunda ese grito escalofriante."


translate english c3211_5fa9e5fb:


    xy "\"Em... ¿Estás bien ahí atrás?\""


translate english c3211_c56085f1:



    voice "voice/c32/1100040b03.opus"
    c "\"S-Sí... estoy bien... Ayyy...\""


translate english c3211_90a1e8e0:


    xy "\"Puedo ayudarte a poner los cigarros de vuelta—\""


translate english c3211_ec77da68:



    voice "voice/c32/1100050b03.opus"
    c "\"¡No, gracias! ¡Puedo con eso! ¡No te preocupes!\""


translate english c3211_3709d40a:



    voice "voice/c32/1100060b03.opus"
    c "\"De todos modos ya estoy acostumbrada.\""


translate english c3211_34fc1333:



    voice "voice/c32/1100070a02.opus"
    aoi "\"¿Vislumbraste algo picante? ¿Sus bragas, tal vez?\""


translate english c3211_d881e353:



    voice "voice/c32/1100080b03.opus"
    c "\"¿Qué? ¡Dios mío! ¡Cállate! ¿¡No es cierto!?\""


translate english c3211_098152e4:


    xy "\"No vi nada.\""


translate english c3211_5881bd87:


    "¡Lleva pantalones, genio!"


translate english c3211_17385b05:


    xy "\"En fin, tenemos que priorizar al gatito.\""


translate english c3211_7fff9e8e:



    voice "voice/c32/1100090a02.opus"
    aoi "\"Buen punto.\""


translate english c3211_af157343:


    xy "\"¡Oh, espera—!\""


translate english c3211_b681ea58:


    "Intento detenerla, pero es demasiado tarde."


translate english c3211_f7ad9cf1:


    "Aoi saca a Eru de su bolsillo, y este salta a un estante sobre el mostrador."


translate english c3211_2d3795c8:



    voice "voice/c32/1100110b03.opus"
    c "\"¡AAH! ¡Senpai, no!\""


translate english c3211_bec27875:



    voice "voice/c32/1100120b03.opus"
    c "\"¡¡¡Nuestra tienda no permite mascotas!!!\""


translate english c3211_1ee9efaa:



    voice "voice/c32/1100130b03.opus"
    c "\"¡Aaagghh! ¡Bájate de ahí, gatito—!\""


translate english c3211_3c4ab577:


    "El gatito todavía es un poco torpe en sus movimientos—"


translate english c3211_47353277:


    "—y aun así esta chica de teatro es de algún modo aún peor."


translate english c3211_62c3b3b9:



    voice "voice/c32/1100140b03.opus"
    c "\"¡Si se enteran de que te dejé entrar a la tienda—AAAHH!\""


translate english c3211_5abb0450:



    voice "voice/c32/1100150b03.opus"
    c "\"¡Me van a—bajar el sueldo—AAAAAAAHHH!\""


translate english c3211_7790215c:


    "Intenta jalar un estante hacia adelante para alcanzar al gatito, y este se desploma de inmediato."


translate english c3211_88348830:


    "Una vez más, queda sepultada bajo una montaña de cajetillas de cigarrillos."


translate english c3211_cd290cd9:



    voice "voice/c32/1100160a02.opus"
    aoi "\"¿Eres fan del tipo torpe?\""


translate english c3211_8eb87649:


    xy "\"Cállate y ayúdame a sacarla de ahí.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
