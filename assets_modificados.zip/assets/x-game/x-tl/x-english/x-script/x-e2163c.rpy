

translate english e2163c_51b32d2b:



    voice "voice/e21/63c00010a01.opus"
    mx "\"......\""


translate english e2163c_b59c727d:


    "Miyuki lo mira, completamente embelesada."


translate english e2163c_4ea9788a:


    "Puedo ver por qué, también. Definitivamente tiene ese aspecto clásico hecho a mano, y el artista realmente clavó su expresión."


translate english strings:


    old "Сколько она стоит?"
    new "¿Cuánto cuesta?"


    old "Их две?"
    new "¿Hay dos?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
