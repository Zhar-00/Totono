

translate english a0114a_2f23b19b:


    "Algo recorre su cuerpo y cruza mi piel, calcinando todo atisbo de razón."


translate english a0114a_f83c5820:


    "Atraídos como un imán, mis labios se sienten arrastrados hacia los suyos."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
