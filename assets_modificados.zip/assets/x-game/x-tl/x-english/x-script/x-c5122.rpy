

translate english c5122_d876549e:



    voice "voice/c51/2200010a01.opus"
    mx "\"Sabes de qué se trata, ¿verdad?\""


translate english c5122_fcaf85c3:


    xy "\"Eh... ¿Debería...?\""


translate english c5122_8e51aebd:



    voice "voice/c51/2200020a01.opus"
    mx "\"Ayer te dije que te esperaría.\""


translate english c5122_78b55abe:


    xy "\"Ah, sí...\""


translate english c5122_e2ce6fd9:


    "Todo sucedió tan de repente esa noche que lo olvidé por completo..."


translate english c5122_1f43967c:


    "Antes de dejar atrás a Miyuki en las jaulas de bateo, ella dijo—"


translate english c5122_6bb32b94:



    voice "voice/c51/2200030a01.opus"
    mx "\"¡Eso es una promesa, ¿me oyes?! ¡Te estaré esperando!\""


translate english c5122_cf3289e4:


    "Ahora lo recuerdo."


translate english c5122_ddf24efd:



    voice "voice/c51/2200040a01.opus"
    mx "\"Esperé toda la noche. Durante HORAS.\""


translate english c5122_f4b093ad:


    xy "\"Lo siento...\""


translate english c5122_4201c297:



    voice "voice/c51/2200050a01.opus"
    mx "\"¿Qué pasó?\""


translate english c5122_a33c5036:


    "Miyuki aprieta su agarre en su bate de béisbol..."


translate english c5122_b0b396e7:


    "...que apunta directamente a mi cara."


translate english c5122_80158de9:


    xy "\"Jaja... jajaja... Este, ¿Miyuki...?\""


translate english c5122_3dde4acf:


    "Le ofrezco una sonrisa."


translate english c5122_446faaf3:


    "Ella no la devuelve. Ni siquiera un poco."


translate english c5122_967dff36:


    "El bate tiembla con su mano."


translate english c5122_34030e5c:


    "Entonces un recuerdo cruza por mi mente—\n—el rumor de un estudiante al que supuestamente Miyuki molió a golpes hasta dejarlo ensangrentado."



translate english c5122_14e4a749:


    mx "\"¿Shiiiniiichiii...?\""


translate english c5122_d4b72fec:


    xy "\"Bien, bien. Veamos. Primero, encontré a Aoi en el techo de la escuela.\""


translate english c5122_4e289348:



    voice "voice/c51/2200070a01.opus"
    mx "\"¿En el techo...?\""


translate english c5122_29bb7310:


    "Su expresión se endurece."


translate english c5122_d88d19eb:



    voice "voice/c51/2200080a01.opus"
    mx "\"¿¿Y luego?\""


translate english c5122_d27eeafa:


    xy "\"¿Huh?\""


translate english c5122_0baf304e:



    voice "voice/c51/2200090a01.opus"
    mx "\"¿Eso es todo?\""


translate english c5122_3f2edee1:


    xy "\"Pues no, eh...\""


translate english c5122_403ef9fd:



    voice "voice/c51/2200100a01.opus"
    mx "\"Me lo prometiste, ¿recuerdas?\""


translate english c5122_be409859:



    voice "voice/c51/2200110a01.opus"
    mx "\"Me prometiste que me escucharías.\""


translate english c5122_0d485a3e:



    voice "voice/c51/2200120a01.opus"
    mx "\"¿O no?\""


translate english c5122_6642e857:


    "Tiene razón. Lo hice."


translate english c5122_885de77c:


    "Y tendré que contarle todo de todos modos si quiero que arreglen su amistad."


translate english c5122_df5a7bc0:


    "Así que más vale contárselo antes que después."


translate english c5122_12e64a21:


    xy "\"......\""


translate english c5122_6cac97d9:


    "Tomo una respiración profunda."


translate english c5122_09ae30d8:


    "Aquí voy. Voy a contarle toda la verdad."


translate english c5122_15ff72f1:


    xy "\"Le confesé mis sentimientos a Aoi.\""


translate english c5122_8324fd7e:



    voice "voice/c51/2200130a01.opus"
    mx "\"\"......\"\""


translate english c5122_c02a4879:



    voice "voice/c51/2200140a01.opus"
    mx "\"...¿Y luego?\""


translate english c5122_46bc0fb0:


    xy "\"¿Qué?\""


translate english c5122_7be7f438:



    voice "voice/c51/2200150a01.opus"
    mx "\"¿Qué quería decir con 'nos electrizamos'?\""


translate english c5122_625b8324:



    voice "voice/c51/2200160a01.opus"
    mx "\"¿Era otra de sus tonterías? ¿O...?\""


translate english c5122_da01d6d2:


    "¿Estaba escuchando a escondidas?"


translate english c5122_241a1906:


    "Muy bien entonces. De perdidos al río."


translate english c5122_a44dfc36:


    xy "\"Tuvimos sexo.\""


translate english c5122_395ebb0c:



    voice "voice/c51/2200170a01.opus"
    mx "\"—!!!\""


translate english c5122_6b2baaf3:


    "Chispas vuelan detrás de mis párpados."


translate english c5122_9ff0c9ca:


    "Por un segundo, no tengo idea de qué acaba de pasar."


translate english c5122_97195b8d:


    "Luego, con retraso, el dolor del golpe aparece."


translate english c5122_db48ef37:


    "Ah. Ya entiendo."


translate english c5122_9ae030de:


    "Miyuki me abofeteó."


translate english c5122_323631d3:


    "—Espera, ¿qué?"


translate english c5122_d1a7a35c:


    "¿Por qué me abofeteó?"


translate english c5122_877b31d0:


    "Solo le dije que me enamoré de Aoi."


translate english c5122_a5b25f9c:


    "Bueno, eso, y el hecho de que tuvimos sexo."


translate english c5122_288d0266:


    "Solo esas dos cosas, nada más."


translate english c5122_bb336537:


    "Entonces, ¿por qué demonios está enojada?"


translate english c5122_ea26b3af:


    xy "\"¡Hey! ¡Espera!\""


translate english c5122_04e858ac:


    "Antes de que pueda procesarlo, Miyuki empieza a marcharse."


translate english c5122_4b4d7206:


    xy "\"¡De verdad siento haberte olvidado, ¿sí?! ¡Pero nada de lo que hice te da derecho a pegarme!\""


translate english c5122_edbede51:


    xy "\"¡Primero me arrastras hasta aquí, luego me pegas sin motivo, y ahora crees que puedes irte así, sin explicación—!\""


translate english c5122_9f24cf1c:



    voice "voice/c51/2200180a01.opus"
    mx "\"—!!!\""



translate english c5122_9e1d9b39:


    "Se da la vuelta, con la ira clara en su rostro..."


translate english c5122_ec2f32e4:


    "Y sin embargo, por alguna razón, sus ojos están anegados en lágrimas—"


translate english c5122_1b54f2ed:



    voice "voice/c51/2200190a01.opus"
    mx "\"—¡Te odio!\""


translate english c5122_625a76d3:


    "Se marcha furiosa como un niño de primaria haciendo una pataleta."


translate english c5122_60a498b7:


    "Sus apresurados pasos se desvanecen del gimnasio."


translate english c5122_0accd139:


    xy "\"\"......\"\""


translate english c5122_c6d26ef4:


    "Mientras tanto, todo lo que puedo hacer es verla irse."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
