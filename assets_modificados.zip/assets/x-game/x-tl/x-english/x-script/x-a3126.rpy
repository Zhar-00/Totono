

translate english a3126_f3666c50:


    xy "\"¿Hmm...?\""


translate english a3126_7d4a7215:


    "De camino al gimnasio, noto un correo sin leer en mi bandeja de entrada."



translate english a3126_959fb338:


    "Lo abro y encuentro—"


translate english a3126_5b9862b6:


    xy "\"Ah, oye, ¡es esa foto grupal de antes!\""


translate english a3126_47bae151:


    xy "\"¿Recuerdas? ¿La de ti, yo y Miyuki?\""


translate english a3126_abaf3701:


    "Aoi afirmó que me lo había enviado hace muchísimo, pero por alguna razón apenas lo recibí."



translate english a3126_84b4a6d8:


    "Ha pasado tanto tiempo que lo olvidé por completo."


translate english a3126_e1fdd1c7:



    voice "voice/a31/2600010a02.opus"
    aoi "\"Debió enviarse antes, cuando mi señal llegó.\""


translate english a3126_3443fc05:


    xy "\"Ah, cierto.\""


translate english a3126_7b7fa841:


    "Supongo que su teléfono SÍ funciona de vez en cuando."


translate english a3126_ffaaada3:


    "Aunque no lo suficiente para ser útil..."


translate english a3126_3cc59334:



    voice "voice/a31/2600020a02.opus"
    aoi "\"Aoi también hizo un archivo de guardado nuevo.\""


translate english a3126_57b04e96:



    voice "voice/a31/2600030a02.opus"
    aoi "\"Ahora no hay que preocuparse por ningún final malo.\""


translate english a3126_0f8ce698:


    xy "\"Em... Cierto...\""


translate english a3126_f7804405:


    "Suspiro para mí mismo."


translate english a3126_4d265b04:


    "Al parecer su cerebro gamer no se va a ir pronto."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
