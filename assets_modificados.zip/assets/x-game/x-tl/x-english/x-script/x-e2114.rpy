

translate english e2114_bf3f1e19:



    voice "voice/e21/1400010a01.opus"
    mx "\"Ya hemos hecho esto como unas cinco veces, así que acostúmbrate, ¿sí?\""


translate english e2114_50b0b3e1:



    voice "voice/e21/1400020a01.opus"
    mx "\"...¿Está bien?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
