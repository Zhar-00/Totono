

translate english e2114_bf3f1e19:



    voice "voice/e21/1400010a01.opus"
    mx "\"We've done this, like, at least five times by now, so just get used to it, would you?\""


translate english e2114_50b0b3e1:



    voice "voice/e21/1400020a01.opus"
    mx "\"...Okay?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
