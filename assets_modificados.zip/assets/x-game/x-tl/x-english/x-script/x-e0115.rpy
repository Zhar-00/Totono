

translate english e0115_969d7db8:


    "El teléfono gira por el aire."


translate english e0115_994c9a98:


    "Vuela en una línea perfectamente recta que desafía la gravedad, hasta que finalmente se desvanece de la vista."


translate english e0115_d9fb116e:



    voice "voice/e01/1500010a01.opus"
    mx "\"That was a pretty good throw, huh?\""


translate english e0115_80b7ccbc:


    xy "\"Yeah...\""


translate english e0115_3fd5e1ec:


    "A esa velocidad, casi pensé que podría destrozar el tejido del universo..."


translate english e0115_014ec4e1:



    voice "voice/e01/1500020a01.opus"
    mx "\"Shall we head home, then?\""


translate english e0115_86d9546b:


    xy "\"But Yuutarou said—\""


translate english e0115_d860e9df:



    voice "voice/e01/1500030a01.opus"
    mx "\"I'll have to turn him down.\""


translate english e0115_36434dbc:



    voice "voice/e01/1500040a01.opus"
    mx "\"I'm the one he invited up here, after all.\""


translate english e0115_d8f30276:


    xy "\"Oh... I see...\""


translate english e0115_5fd1fc1b:



    voice "voice/e01/1500050a01.opus"
    mx "\"And we haven't told the rest of the class we're dating.\""


translate english e0115_bbcfbcbb:


    "Miyuki mira el suelo con timidez."


translate english e0115_4f1edcd5:



    voice "voice/e01/1500060a01.opus"
    mx "\"Or that we're living together.\""


translate english e0115_bf0d87ad:



    voice "voice/e01/1500070a01.opus"
    mx "\"And it's already been a whole week.\""


translate english e0115_041d6bf2:



    voice "voice/e01/1500080a01.opus"
    mx "\"And it's already been two whole weeks.\""


translate english e0115_890ec252:



    voice "voice/e01/1500090a01.opus"
    mx "\"And it's already been three whole weeks.\""


translate english e0115_4a30f349:


    xy "\"We'll have to tell them eventually, I guess...\""


translate english e0115_c06c1701:



    voice "voice/e01/1500100a01.opus"
    mx "\"I just hope I'm good enough for you...\""


translate english strings:


    old "Конечно"
    new "Lo eres"


    old "Вовсе нет"
    new "No lo eres"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
