

translate english e2235a_d0d443dd:


    xy "\"Ah, cierto... Eso.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
