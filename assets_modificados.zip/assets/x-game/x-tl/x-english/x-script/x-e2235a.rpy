

translate english e2235a_d0d443dd:


    xy "\"Oh, right... That.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
