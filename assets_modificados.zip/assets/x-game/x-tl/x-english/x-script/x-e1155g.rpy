

translate english e1155g_d4af525d:



    voice "voice/e11/55g00010a01.opus"
    mx "\"Vamos... No seas así... Te lo suplico...\""


translate english e1155g_becb1c2c:



    voice "voice/e11/55g00020a01.opus"
    mx "¡¡¡Solo... BÉSAME YA!!! ¡¡¡POR FAVOR!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
