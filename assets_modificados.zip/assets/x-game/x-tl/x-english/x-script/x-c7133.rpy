

translate english c7133_4f78b781:



    voice "voice/c71/3300010a02.opus"
    aoi "\"Hnnggh... nnn... nnnn! Nngh! Aah! NnhaaaAAAAHH!\""


translate english c7133_6686bcbc:


    "Puedo ver la cara de Aoi a través de la rendija de la puerta."


translate english c7133_4cc23233:


    "Está... llorando."


translate english c7133_22d47f99:



    voice "voice/c71/3300020a02.opus"
    aoi "\"Why?! Nnn... nn... nnnn...!\""


translate english c7133_a5d7eaf3:



    voice "voice/c71/3300030a02.opus"
    aoi "\"Why... does it... hurt so bad...?\""


translate english c7133_69a55946:



    voice "voice/c71/3300040a02.opus"
    aoi "\"Why... is Aoi... crying...?\""


translate english c7133_dc125c6e:


    "Llora como si tuviera el peso del mundo entero sobre sus hombros."


translate english c7133_37f02847:


    "Intentó reunirse con Ryuujirou a mis espaldas."


translate english c7133_4066fc63:


    "Pensé que me había traicionado."


translate english c7133_624c580b:


    "Pero en realidad, era prueba de su amor."


translate english c7133_4887d17d:


    "Aoi me amaba tanto que estaba dispuesta a forzarse a estar con otros chicos y cargar con la culpa ella sola."


translate english c7133_bcb9b923:


    "Me amaba tanto que rechazó a Ryuujirou en el último minuto."


translate english c7133_e035bbd5:


    "Un recuerdo cruza por mi mente—un recuerdo de Aoi rezando a Dios justo antes de salir de casa el día de la función."


translate english c7133_3e91c09a:



    voice "voice/c71/3300050b03.opus"
    c "\"It's okay, Aoi-senpai!\""


translate english c7133_7ee85741:



    voice "voice/c71/3300060b03.opus"
    c "\"All your sadness... All your pain... I'll help you forget all of it!\""


translate english c7133_432f603c:



    voice "voice/c71/3300070b03.opus"
    c "\"Right now, please, just focus on me! P-Please...!\""


translate english c7133_1283f1a6:



    voice "voice/c71/3300080a02.opus"
    aoi "\"Haah! Aah! Aaah! Aah! Oh god! Yes! Right there! Right there!\""


translate english c7133_aad02f21:



    voice "voice/c71/3300090a02.opus"
    aoi "\"Haaah! Aah! Nnhaah! Aah, aah, aah!!! Yes! Harder! Nnnngg!\""


translate english c7133_213b55a8:



    voice "voice/c71/3300100a02.opus"
    aoi "\"It feels so good... but... it hurts...\""


translate english c7133_dbaed9a2:



    voice "voice/c71/3300110a02.opus"
    aoi "\"Or... does it hurt... because it feels good...?\""


translate english c7133_c7d09344:


    "Los ojos de Aoi están llenos de lágrimas—y de lujuria."


translate english c7133_974da4e0:


    "Su boca cuelga abierta."


translate english c7133_c55f6e8b:


    "Está disfrutando con la polla de otro chico dentro de ella."


translate english c7133_fe2aa1ea:


    "Ha tomado diversas formas distintas y hecho esto docenas, o cientos, o incluso miles de veces antes."


translate english c7133_291f9554:


    "Su verdadera naturaleza es tan excitante que no puedo evitar sentir mi polla hincharse en los pantalones."


translate english c7133_aa287614:


    "Estoy tan superado por el amor, la desesperación y la miseria—que ya no lo soporto."


translate english c7133_8f0ca206:


    xy "\"Aoi—!\""


translate english c7133_477e4216:



    voice "voice/c71/3300120a02.opus"
    aoi "\"Oh—no—\""


translate english c7133_9f7eee1f:


    "Apenas susurro su nombre."


translate english c7133_4a45c735:


    "Y sin embargo, de alguna manera me oye y mira hacia la puerta, justo en medio del acto."


translate english c7133_8e438cbb:



    voice "voice/c71/3300130a02.opus"
    aoi "\"Why are you watching?!\""


translate english c7133_42d17cd5:


    "En el instante en que me doy cuenta de que estoy atrapado, mi racionalidad se evapora."


translate english c7133_f99ed06e:


    "Lo siguiente que sé es que estoy pegado contra la puerta, con la polla en la mano, masturbándome furiosamente."


translate english c7133_9564f0f7:



    voice "voice/c71/3300140a02.opus"
    aoi "\"Haah! Oh god! Shinichi! Don't—look—!\""


translate english c7133_4046e27e:



    voice "voice/c71/3300150b03.opus"
    c "\"Aoi-senpai!\""


translate english c7133_53295331:


    "Tan pronto como ella grita mi nombre, Ryuujirou empieza a embestir aún más fuerte en protesta."


translate english c7133_077cb2b9:



    voice "voice/c71/3300160b03.opus"
    c "\"It's me! I'm the one you're fucking! And right now, I love you more than anyone else in the whole world!\""


translate english c7133_d272a317:



    voice "voice/c71/3300170a02.opus"
    aoi "\"No! Oh god, no! Shinichi! The zappy's coming—The zappy—!\""


translate english c7133_1d55ce71:



    voice "voice/c71/3300180a02.opus"
    aoi "\"Shinichi's watching... and it hurts... But the pleasure—won't stop—!\""


translate english c7133_475606af:



    voice "voice/c71/3300190a02.opus"
    aoi "\"Even though he's watching—No, BECAUSE he's watching—AAAH! Oh god! Aoi... can't... hold... back... OH GOD!\""


translate english c7133_ad0e7044:



    voice "voice/c71/3300200b03.opus"
    c "\"I'm cumming! Senpai, I'm cumming inside you—!\""


translate english c7133_e046a692:



    voice "voice/c71/3300220a02.opus"
    aoi "\"Shin...ichi...! Oh god! Shinichi! Aoi's gonna cum! Shinichi! Shinichi! Nnngghh! Nnnnnggg!!!\""


translate english c7133_32ce7c5b:



    voice "voice/c71/3300230a02.opus"
    aoi "\"Aoi's... cuuuummmmmiiiiiinnnnnggggg!!!\""


translate english c7133_a1dd4aff:



    voice "voice/c71/3300240a02.opus"
    aoi "\"A-Aoi... got... zappy... right... in front... of...\""


translate english c7133_242c405d:



    voice "voice/c71/3300250a02.opus"
    aoi "\"...the love... of... my life...!\""


translate english c7133_b4ccb084:



    voice "voice/c71/3300260a02.opus"
    aoi "\"Aoi... got off on... hnng... being... another guy's... cum dumpster...?\""


translate english c7133_99ed7ec7:



    voice "voice/c71/3300270b03.opus"
    c "\"Aoi-senpai...\""


translate english c7133_667cc8db:



    voice "voice/c71/3300280a02.opus"
    aoi "\"Aoi's... such a slut...! And now... Shinichi's... gonna hate... me... Hnng... nnn!!!\""


translate english c7133_1b2807e5:



    voice "voice/c71/3300290a02.opus"
    aoi "\"Hnngg! Nnn... nnnnn... Nnnn... nnn... Waaaahh.... Nnn!\""


translate english c7133_f6011ba7:



    voice "voice/c71/3300300b03.opus"
    c "\"......\""


translate english c7133_9f9eafe5:


    "Aoi empieza a berrear como un bebé."


translate english c7133_c186fa46:


    "Ryuujirou no se mueve."


translate english c7133_c6005fbf:


    "Ni siquiera se sale... Solo yace ahí satisfecho..."


translate english c7133_25b38d57:



    voice "voice/c71/3300310b03.opus"
    c "\"Aah! Susuki-senpai?! What're you—?!\""


translate english c7133_62944381:


    xy "\"Move.\""


translate english c7133_e913bf88:



    voice "voice/c71/3300320b03.opus"
    c "\"Aaah!\""


translate english c7133_1aec1298:


    xy "\"Slrrp...\""


translate english c7133_03385ecd:



    voice "voice/c71/3300330a02.opus"
    aoi "\"Huh? What the... Shinichi? Aaah!\""


translate english c7133_066ab8a6:


    "Empujo a Ryuujirou a un lado y meto la cara en el coño de Aoi."


translate english c7133_4b8177ce:


    xy "\"SSSLLLLRRRRPPPPP!!!\""


translate english c7133_3b50004e:



    voice "voice/c71/3300340a02.opus"
    aoi "\"Aah! Stop! You're gonna suck up the... Wait! Nnn... nnn! Aah, aah, aah!!!\""


translate english c7133_22a304f7:


    xy "\"SSSLLRRRPPP...!\""


translate english c7133_0500ba1e:



    voice "voice/c71/3300350b03.opus"
    c "\"No way... I can't believe it... Susuki-senpai...\""


translate english c7133_6007e39b:


    "El sabor del semen se extiende en mi boca."


translate english c7133_e102f2ee:


    "Es la carga fresca de Ryuujirou."


translate english c7133_afae0ba8:


    "Es amargo y cálido."


translate english c7133_8f5afdc2:


    "Lo raspo con mi lengua."


translate english c7133_e066670e:



    voice "voice/c71/3300360a02.opus"
    aoi "\"Aaah! Are you sucking out the cum? Aoi can feel it—trickling out—!\""


translate english c7133_2e124e8d:


    xy "\"...Pthooo!!!\""


translate english c7133_d37a77bf:


    "Escupo de inmediato todo lo que he recogido en mi boca."


translate english c7133_0d66787a:


    xy "\"I love you, Aoi, no matter what kind of slut you are.\""


translate english c7133_6132369f:


    xy "\"Isn't this proof enough for you?\""


translate english c7133_b61fcee8:



    voice "voice/c71/3300370a02.opus"
    aoi "\"But Aoi's... so slutty...\""


translate english c7133_8f75d891:



    voice "voice/c71/3300380a02.opus"
    aoi "\"Are you sure... that's what you want...?\""


translate english c7133_80976fd0:


    xy "\"I love you for who you are, no matter what.\""


translate english c7133_bb07960d:



    voice "voice/c71/3300390a02.opus"
    aoi "\"Shinichi...\""


translate english c7133_ae170eb1:



    voice "voice/c71/3300400a02.opus"
    aoi "\"Uh... uh... umm... well...\""


translate english c7133_0a81ad5a:



    voice "voice/c71/3300410a02.opus"
    aoi "\"Thank... you...\""


translate english c7133_954c6185:


    "Cubierta de diversos fluidos corporales de pies a cabeza, Aoi empieza a llorar."


translate english c7133_9cb0bb8d:


    "Paso mi lengua por los jugos que escurren por sus piernas."


translate english c7133_c8a0e2c0:



    voice "voice/c71/3300420a02.opus"
    aoi "\"Haahhh! Nn... nnnn! Wow... Shinichi... You feel... so good...!\""


translate english c7133_e59967f1:



    voice "voice/c71/3300430a02.opus"
    aoi "\"Aoi... loves you... too...\""


translate english c7133_6eb441d0:



    voice "voice/c71/3300440a02.opus"
    aoi "\"Aoi's... so happy... Hnng... nnnn! Oh god... It's... so intense...!\""


translate english c7133_a6a97f27:



    voice "voice/c71/3300450a02.opus"
    aoi "\"Nnngh! Aah! It's still—sensitive—! Your tongue's—so hot—and rough—AAAAHH!!!\""


translate english c7133_09bb8029:



    voice "voice/c71/3300460a02.opus"
    aoi "\"It's sliding in so deep—HAAAHHH! Licking deep inside—my pussy—!\""


translate english c7133_d97a6c50:



    voice "voice/c71/3300470a02.opus"
    aoi "\"You feel... so good...! Oh god—! Zappy—Haah! Aah—nnn—nnn—nnn—!\""


translate english c7133_6c56e605:


    "Aoi se retuerce encima de mí."


translate english c7133_bc69b2c2:


    "Pero necesita un empujón más para llegar al clímax."


translate english c7133_8a4b6dd2:


    "Voy a llevar esto hasta el final."


translate english c7133_2eba245e:



    voice "voice/c71/3300510a02.opus"
    aoi "\"Nnn... nn... nnhaah... nnnng...! Haah... haah...!\""


translate english c7133_7a1aa847:



    voice "voice/c71/3300520a02.opus"
    aoi "\"Nnhaah! Aah! Nnn... God... It all... feels so good...\""


translate english c7133_abf4b8a8:



    voice "voice/c71/3300530a02.opus"
    aoi "\"Nn... nnn! Nnnngg...! Nnn! Nnnnngggggg...!\""


translate english c7133_b2b7d3a2:


    "Aoi se retuerce sin parar."


translate english c7133_6ddc85d2:


    "Sus ojos están llenos de lágrimas amargas."


translate english c7133_35efdf64:



    voice "voice/c71/3300540a02.opus"
    aoi "\"P-Please... Nnhaah... nnn... Let Aoi... nnn... L-Let Aoi cum...!\""


translate english c7133_0b84a33c:


    "Bueno, si insistes..."


translate english c7133_d8339574:


    "Conozco todos sus puntos débiles."


translate english c7133_a1ae8ed1:


    "Hurgo su clítoris con mi lengua."


translate english c7133_d74088c6:



    voice "voice/c71/3300550a02.opus"
    aoi "\"Haaah! Aah! Aaaah! Oh god!\""


translate english c7133_39466607:



    voice "voice/c71/3300560a02.opus"
    aoi "\"Not my clit! That's too intense! It feels... so good... Aoi...!\""


translate english c7133_796a16a8:



    voice "voice/c71/3300570a02.opus"
    aoi "\"Haaah! Aah! Can't... tell... what's going on... anymore...! Nnhaah! Aaah!\""


translate english c7133_20bee891:



    voice "voice/c71/3300580a02.opus"
    aoi "\"HaaAAAaaaAAAaaaAAAH! The zappy... Nnhaah! It's... coming...!\""


translate english c7133_ec1b9462:



    voice "voice/c71/3300590a02.opus"
    aoi "\"HAAAAHH! NNNNGGGGHHHH!!! Nngh! Aoi's cumming—cumming—cumming—\""


translate english c7133_5c944e81:



    voice "voice/c71/3300600a02.opus"
    aoi "\"Haah... nn... nnggh... nnn... nnng! Nnhaah... aah... aaahh... aah...!\""


translate english c7133_81859e85:



    voice "voice/c71/3300610a02.opus"
    aoi "\"CUUUUUMMMMMMMMIIIINNNNGGGGG!!!\""


translate english c7133_f20eb12a:



    voice "voice/c71/3300620a02.opus"
    aoi "\"Hnn... nnn... nnng... nnn... A-Aoi... came...\""


translate english c7133_d3c24902:



    voice "voice/c71/3300630a02.opus"
    aoi "\"Aoi got off... on you... sucking out... the cum... and licking... my clit... Nnng!\""


translate english c7133_2918c37b:



    voice "voice/c71/3300640a02.opus"
    aoi "\"It felt... super good...\""


translate english c7133_c4939c71:


    "Me mira con ojos brumosos mientras su cuerpo se convulsiona una y otra vez."


translate english c7133_257828da:


    "Puedo sentir su ojete contrayéndose también."


translate english c7133_5fd5de65:


    "Es tan sexy que ya no puedo contenerme más."


translate english c7133_a48323b3:



    voice "voice/c71/3300650a02.opus"
    aoi "\"Shini...chi... My body... still wants... more...\""


translate english c7133_d7fd7173:



    voice "voice/c71/3300660a02.opus"
    aoi "\"This is what we're doing next...\""


translate english c7133_395d7e11:


    "Aoi yace boca arriba, con la mirada aún borrosa."


translate english c7133_c6a86900:


    "Ya ha llegado al clímax varias veces."


translate english c7133_59d5e960:


    "Su coño se contrae como si rogara por mi polla..."


translate english c7133_6471c219:



    voice "voice/c71/3300670a02.opus"
    aoi "\"Give me... your fat cock...\""


translate english c7133_8e269533:



    voice "voice/c71/3300680a02.opus"
    aoi "\"Aoi wants it bad...\""


translate english c7133_dc5513b3:


    "Mientras desciende de su orgasmo más reciente, parece a punto de desmayarse."


translate english c7133_f2545f4e:


    "Pero entonces presiono la punta de mi hinchada longitud contra su entrada."


translate english c7133_5e4d4da5:



    voice "voice/c71/3300690a02.opus"
    aoi "\"Hnnn!!!\""


translate english c7133_561c1ecf:


    "Su coño hace un sonido húmedo y pegajoso mientras se contrae."


translate english c7133_84115bc7:



    voice "voice/c71/3300710a02.opus"
    aoi "\"Hnn... Shinichi... Don't tease me...\""


translate english c7133_889a4dd9:



    voice "voice/c71/3300720a02.opus"
    aoi "\"Aoi's pussy... wants your cock...\""


translate english c7133_b3db986e:


    aoi "\"Hurry up... and put it... in me... Nn... nn... nnn...\""


translate english c7133_12ef651d:


    "Toca sus partes bajas como si no pudiera esperar ni un segundo más."


translate english c7133_88b0da2d:


    "Las palabras sucias brotan de su lengua."


translate english c7133_e7ed149e:


    "Después de tantos orgasmos, su coño es un desastre de semen, saliva y otros fluidos."


translate english c7133_9919a012:


    "Me mira suplicante, con las lágrimas brotando en sus ojos."


translate english c7133_d99f87b5:


    "A primera vista, parece tan linda e inocente..."


translate english c7133_50e24242:


    "...pero existe para ser follada."


translate english c7133_b21599ee:


    "Y eso me parece bien."


translate english c7133_a265c7aa:


    "No me hace amarla menos."


translate english c7133_851fdc79:


    xy "\"...Aoi.\""


translate english c7133_df0d66b1:



    voice "voice/c71/3300730a02.opus"
    aoi "\"Shinichi...\""


translate english c7133_197bf701:


    "Nos llamamos por nuestros nombres... y con eso, nos volvemos uno."


translate english c7133_f097dad6:



    voice "voice/c71/3300740a02.opus"
    aoi "\"...!!!\""


translate english c7133_8e8f5bd3:



    voice "voice/c71/3300750a02.opus"
    aoi "\"Nn... nnn... nnn... nn...! Aah... aaah... aahah... aah...!\""


translate english c7133_a7a9228a:



    voice "voice/c71/3300760a02.opus"
    aoi "\"It's inside... And it feels so... zappy...!\""


translate english c7133_44fed379:



    voice "voice/c71/3300770a02.opus"
    aoi "\"Aoi loves... your cock... It's the best cock... in the whole world...!\""


translate english c7133_ff2539dd:


    "A diferencia de nuestra primera vez, mi longitud la penetra fácilmente."


translate english c7133_19fafdcc:


    "La suave sensación me anima, provocándome con un dejo de todo el placer aún por venir."


translate english c7133_3d5cee05:



    voice "voice/c71/3300780a02.opus"
    aoi "\"Just the... feeling of... you inside me... makes me... so happy...\""


translate english c7133_9507d521:



    voice "voice/c71/3300790a02.opus"
    aoi "\"How will it feel... if you start thrusting?\""


translate english c7133_d503c28e:


    "Está rogando por ello."


translate english c7133_1d71b0be:


    "Su coño me aprieta un poco más fuerte."


translate english c7133_02aa38a9:


    "Ya no puedo contenerme."


translate english c7133_606c8434:



    voice "voice/c71/3300800a02.opus"
    aoi "\"—!!!\""


translate english c7133_0834d288:


    "Empiezo lentamente a entrar y salir de ella."


translate english c7133_db45f608:



    voice "voice/c71/3300810a02.opus"
    aoi "\"Hnnn! Aah! Nnnn! Nnngggh! Nnn! Nnnn! Nnngh! Nnn—nnn—nnn—!\""


translate english c7133_273ea675:



    voice "voice/c71/3300820a02.opus"
    aoi "\"It's... nnnn... so weird...! You're... barely... moving... but...\""


translate english c7133_656bd583:



    voice "voice/c71/3300830a02.opus"
    aoi "\"It feels... really... really good...! It's so... hot...!\""


translate english c7133_d4bfb46a:


    "Todavía queda un poco del semen de Ryuujirou dentro de ella."


translate english c7133_7e019636:


    "f<I></I>unciona como lubricante, ayudándome a sacárselo a la fuerza."


translate english c7133_7a7143a4:



    voice "voice/c71/3300840a02.opus"
    aoi "\"It's so weird—so bizarre— Aoi's got warm fuzzies—right down to my core—!\""


translate english c7133_42a37ea7:



    voice "voice/c71/3300850a02.opus"
    aoi "\"It keeps building... and building... and building...! My body's... so zappy... it's practically electric...!\""


translate english c7133_7f488ce7:


    "Aoi murmura extasiada."


translate english c7133_9958ca64:



    voice "voice/c71/3300860a02.opus"
    aoi "\"It's just sex... but it's more than just sex...! Why... Why is Aoi so happy...?\""


translate english c7133_b1e482c6:



    voice "voice/c71/3300870a02.opus"
    aoi "\"Is it... because Aoi loves you?\""


translate english c7133_7e3f60f0:


    "Con eso, siento que pierdo el control."


translate english c7133_d5034829:


    "Sin alargarlo, sin saborearlo."


translate english c7133_d94d46ee:


    "Me someto al placer y la embisto con todo lo que tengo."


translate english c7133_b6a06eb4:



    voice "voice/c71/3300880a02.opus"
    aoi "\"Hnnn! Aah! Oh god! Slow down! It's so rough! Haaah! Aaah! Aah! Aah!\""


translate english c7133_ce7f9db9:



    voice "voice/c71/3300890a02.opus"
    aoi "\"Oh god! Wait! You're so rough! Feels like I'm floating! Nnnn! Aaaahh!\""


translate english c7133_238ccd0a:



    voice "voice/c71/3300900a02.opus"
    aoi "\"Haah! Oh god! Aaah! Aoi's gonna cum! Aoi's cumming... cumming... Aaaahh!!!\""


translate english c7133_bfe814f1:



    voice "voice/c71/3300910a02.opus"
    aoi "\"Aoi's cccuuuummmmmiiiiinnnnnggggg!!!\""


translate english c7133_b4e83a4c:


    "Su cuerpo se convulsiona con fuerza."


translate english c7133_4d4ab9ae:


    "Puedo sentir su coño apretándose con fuerza—pero lo ignoro y sigo embistiendo aún más rápido y profundo que nunca."


translate english c7133_ca8c7632:



    voice "voice/c71/3300920a02.opus"
    aoi "\"Nn... nngghh!!! Hnnn! Nnn! Nnngh! Nn... nnnn... nnn...!\""


translate english c7133_164117d2:



    voice "voice/c71/3300930a02.opus"
    aoi "\"Nnnggh! Hnnn! Shinichi... why...? Aoi... already came...! Aaaahh!\""


translate english c7133_54a8f6b4:



    voice "voice/c71/3300940a02.opus"
    aoi "\"Why... aren't you stopping...? Hnnnggghhh!!! Why is your cock... still going...? Nnngg!!!\""


translate english c7133_fd754629:



    voice "voice/c71/3300950a02.opus"
    aoi "\"If you... keep... f-fucking me... that hard... AAAAHHH! You're... gonna... b-break my... pussyyyyy...!!!\""


translate english c7133_885c085c:



    voice "voice/c71/3300960a02.opus"
    aoi "\"Haha... hahaha... Your cock... is rock hard... Hnngh! Shinichi... Are you... nnngh... gonna cum...?!\""


translate english c7133_8b0cd882:



    voice "voice/c71/3300970a02.opus"
    aoi "\"Is... my pussy... gonna... nnnn... wring... your cum... from... your cock...?\""


translate english c7133_4d8bf71b:



    voice "voice/c71/3300980a02.opus"
    aoi "\"Hehe... Good... Go ahead... Shoot your load... in my pussy... Nnhaahaahaah!!!\""


translate english c7133_8a94b1eb:



    voice "voice/c71/3300990a02.opus"
    aoi "\"Nnnggh! Hnnggghhh! Nngh! Nnn! Hnnnn! Shinichi! Aaahh! Shinichi!\""


translate english c7133_9bc1ea52:



    voice "voice/c71/3301000a02.opus"
    aoi "\"Shinichi...! Aoi loves you! So much! Haah! Aah! Aah! Aah! Aah! Aaaahh...!\""


translate english c7133_c983619e:



    voice "voice/c71/3301010a02.opus"
    aoi "\"AAAAAAAAAAAAAHHHH...!!!\""


translate english c7133_6ea5dcb4:



    voice "voice/c71/3301020a02.opus"
    aoi "\"Aah... aah... aaahh... aah, aah, aah... You're... cumming... Your cum is... filling me...\""


translate english c7133_c3fb959b:



    voice "voice/c71/3301030a02.opus"
    aoi "\"Hehe... Aoi loves it... Nngh... Aoi loves... being full... of cum...\""


translate english c7133_4df9c131:



    voice "voice/c71/3301040a02.opus"
    aoi "\"It's still... throbbing... over and over... filling me up... with every drop...\""


translate english c7133_9ce29284:



    voice "voice/c71/3301050a02.opus"
    aoi "\"Haah... nnn... It feels... so good... Aoi's... so happy...\""


translate english c7133_79cbaa6d:


    "Murmura dulcemente."


translate english c7133_20918a3b:


    "Una vez que disparo mi última gota, me retiro lentamente de su interior."


translate english c7133_2c09d2b2:


    "Un torrente de semen fluye de su coño."



translate english c7133_2b021955:


    "Mi pecho se hincha de contento."


translate english c7133_2c0feb2a:


    "Ahora sabe cuánto la amo—"


translate english c7133_0584a896:



    voice "voice/c71/3301060a02.opus"
    aoi "\"Shinichi...?\""


translate english c7133_b2c96225:


    "Su ojete se contrae a raíz de su orgasmo."


translate english c7133_725e9966:


    "Se abre ampliamente mientras grita mi nombre, recibiendo el semen mientras escurre de su coño."


translate english c7133_f22a7cb2:



    voice "voice/c71/3301070a02.opus"
    aoi "\"Don't you want to fuck my ass?\""


translate english c7133_60bdf53e:


    "Aoi está tan agotada que ni siquiera puede sentarse erguida—y sin embargo su cuerpo todavía ansía más."


translate english c7133_324c5097:


    "Mi erección marchita rápidamente vuelve a palpitar con vida."


translate english c7133_05e86b32:


    "Pero justo entonces—"


translate english c7133_525d1676:



    voice "voice/c71/3301080a02.opus"
    aoi "\"Got it!\""


translate english c7133_370a4caa:



    voice "voice/c71/3301090a02.opus"
    aoi "\"We can't leave Haru-chan out...\""


translate english c7133_d1caad0e:


    "Aoi mira hacia Ryuujirou, todavía sentado en el rincón del cuarto después de que le dije que se moviera."


translate english c7133_15ef5cc8:



    voice "voice/c71/3301100a02.opus"
    aoi "\"Shinichi, you take my ass, and Haru-chan can go in front.\""


translate english c7133_84169d3b:



    voice "voice/c71/3301110a02.opus"
    aoi "\"Okay?\""


translate english c7133_5f4de1e0:



    voice "voice/c71/3301120b03.opus"
    c "\"W-Wait a minute! I—\""


translate english c7133_ab332984:



    voice "voice/c71/3301130a02.opus"
    aoi "\"But you're already hard...\""


translate english c7133_e635d603:



    voice "voice/c71/3301140b03.opus"
    c "\"Whoa! Stop—AAAH! S-Stop that—!!!\""


translate english c7133_d901ea8c:



    voice "voice/c71/3301150a02.opus"
    aoi "\"Ryuujirou?\""


translate english c7133_3089d4d0:


    "Lo llama por su nombre real."


translate english c7133_413d76f4:



    voice "voice/c71/3301160a02.opus"
    aoi "\"Aoi really appreciated how you let me vent at the store, back when Aoi couldn't go to school anymore.\""


translate english c7133_b2eee0a9:



    voice "voice/c71/3301170a02.opus"
    aoi "\"So now... Aoi wants to make it up to you.\""


translate english c7133_98ad4451:



    voice "voice/c71/3301180a02.opus"
    aoi "\"Aoi wants to make you feel good again.\""


translate english c7133_e07b3d36:



    voice "voice/c71/3301190b03.opus"
    c "\"B-But—but then Susuki-senpai—\""


translate english c7133_2d91b743:



    voice "voice/c71/3301200a02.opus"
    aoi "\"Are you okay with this, Shinichi?\""


translate english c7133_339484ee:


    "Claro que no."


translate english c7133_a2126ae1:


    "¿Mi novia teniendo sexo con otro hombre?"


translate english c7133_92281c21:


    "El mero pensamiento me hierve la sangre."


translate english c7133_39e7c143:


    "Pero..."


translate english c7133_9f178b56:


    xy "\"You need to do this, right?\""


translate english c7133_34b5b760:



    voice "voice/c71/3301210a02.opus"
    aoi "\"Yeah.\""


translate english c7133_b8635afd:


    "Este infierno nunca terminará."


translate english c7133_259f260a:


    "Mientras Aoi siga siendo la misma..."


translate english c7133_c4945ed3:


    "Mientras yo elija mantenerla en este mundo..."


translate english c7133_6a2f6d0b:


    "...seguirá follando con otros chicos."


translate english c7133_83484595:


    "Y decidí que tenía que aceptarlo."


translate english c7133_e8deab0f:


    "Así que..."


translate english c7133_c75d1f8c:


    xy "\"Do whatever you want.\""


translate english c7133_5ce98990:



    voice "voice/c71/3301220a02.opus"
    aoi "\"Thank you.\""


translate english c7133_3c1c5c36:


    "Mientras ella sea feliz, lo aguantaré."


translate english c7133_206571e0:



    voice "voice/c71/3301230a02.opus"
    aoi "\"Boop boop... Ryuujirou...\""


translate english c7133_3b517286:



    voice "voice/c71/3301240b03.opus"
    c "\"Senpai... We can't...\""


translate english c7133_a0642ee7:


    "Pero Aoi ignora sus deseos y se sube encima de él de todos modos."


translate english c7133_a9b7cfb1:


    "Él aparta la mirada, con conflicto."


translate english c7133_fc04f7f7:



    voice "voice/c71/3301250b03.opus"
    c "\"We can't do this... Not while Susuki-senpai's watching...\""


translate english c7133_0b460229:



    voice "voice/c71/3301260a02.opus"
    aoi "\"Aah! AAAAAAAHHH!!!\""


translate english c7133_c11e784a:



    voice "voice/c71/3301270a02.opus"
    aoi "\"Haah! Nn... nnnn... nnn... nnnn... Hehehe... You're still so hard...\""


translate english c7133_49d9b207:



    voice "voice/c71/3301280b03.opus"
    c "\"Aaahh! Aah! Stop— Don't say that— It's embarrassing!!!\""


translate english c7133_c86a1036:



    voice "voice/c71/3301290a02.opus"
    aoi "\"Mm-hmm. Most 'girls' don't have one of these, do they? Weirdo... Look at you, getting all hard... Shame on you...\""



translate english c7133_3eb353bf:



    voice "voice/c71/3301300b03.opus"
    c "\"I-It's not what you thi—Aaaahh!\""


translate english c7133_6063d17b:


    "Ryuujirou protesta, pero ella lo interrumpe rebotando sobre su polla como si estuviera haciendo mochi."


translate english c7133_c9be7d6a:



    voice "voice/c71/3301310a02.opus"
    aoi "\"Nnngh! Nnn... nn... nnnn... nnn...! Boop boop... Can you hear it?\""


translate english c7133_159b44f0:



    voice "voice/c71/3301320a02.opus"
    aoi "\"All the sticky stuff... mixing together... squishing around... making wet noises...\""


translate english c7133_23ad45e2:



    voice "voice/c71/3301330b03.opus"
    c "\"No! Aah! Stop! Don't say that! No! Stop, stop, stop!\""


translate english c7133_328ad634:



    voice "voice/c71/3301340a02.opus"
    aoi "\"How dirty.\""


translate english c7133_98143799:



    voice "voice/c71/3301350b03.opus"
    c "\"—!!!\""


translate english c7133_41ad2419:


    "Ryuujirou suelta un grito apenas contenido."


translate english c7133_d467c176:



    voice "voice/c71/3301360b03.opus"
    c "\"Wh-What's the matter with you? Why are you being—such a bully today—?!\""


translate english c7133_3b0524b6:



    voice "voice/c71/3301370a02.opus"
    aoi "\"This is... the real me... so... nnn...\""


translate english c7133_7d1d8a1b:



    voice "voice/c71/3301380a02.opus"
    aoi "\"Show me... the real you...!\""


translate english c7133_222b7e6e:



    voice "voice/c71/3301390b03.opus"
    c "\"The real... me...? Nnhaaaahhh!!!\""


translate english c7133_05f818b3:


    "Aoi mueve sus caderas de lado a lado, con su polla aún enterrada hasta el fondo dentro de ella."


translate english c7133_69b9eb87:



    voice "voice/c71/3301400a02.opus"
    aoi "\"Does my pussy feel good?\""


translate english c7133_b801c3ab:



    voice "voice/c71/3301410b03.opus"
    c "\"Y-Yes... Your... lady parts... feel great... Aaah! I'm so embarrassed... I'm gonna die...\""


translate english c7133_7999bb16:


    "Ryuujirou se retuerce en la cama mientras ella lo folla contra su voluntad."


translate english c7133_3629184f:


    "La forma en que actúa, es difícil verlo como un hombre..."


translate english c7133_8a89b2f5:



    voice "voice/c71/3301420a02.opus"
    aoi "\"You really are such a girl... Your little nipples are hard and everything.\""


translate english c7133_c01469e0:



    voice "voice/c71/3301430a02.opus"
    aoi "\"You probably jerk off in your girl clothes, don't you?\""


translate english c7133_0da3e7ff:



    voice "voice/c71/3301440b03.opus"
    c "\"N-No I d—\""


translate english c7133_a444c307:



    voice "voice/c71/3301450a02.opus"
    aoi "\"Can you see Shinichi's cock?\""


translate english c7133_bb2b73d4:



    voice "voice/c71/3301460b03.opus"
    c "\"Huh...? Nn... nnnn...!\""


translate english c7133_4e8ab14f:


    "Ver el encuentro de Aoi con Ryuujirou ha hecho que mi erección vuelva con toda su fuerza."


translate english c7133_8d8ace36:



    voice "voice/c71/3301470a02.opus"
    aoi "\"Do you think about touching it...? Licking it...? Putting it in you...? Getting his cum all over you...?\""


translate english c7133_fa4246ea:



    voice "voice/c71/3301480b03.opus"
    c "\"Aah... No... Stop...!\""


translate english c7133_ade4ee2d:



    voice "voice/c71/3301490a02.opus"
    aoi "\"Does it turn you on to imagine it?\""


translate english c7133_3a516e48:



    voice "voice/c71/3301500b03.opus"
    c "\"Aah! I... I... umm...!\""


translate english c7133_d352f3e6:



    voice "voice/c71/3301510a02.opus"
    aoi "\"That's not allowed.\""


translate english c7133_b3e1f6c0:



    voice "voice/c71/3301520a02.opus"
    aoi "\"That cock... belongs to Aoi.\""


translate english c7133_679b3580:



    voice "voice/c71/3301530a02.opus"
    aoi "\"So you'll have to—Hnnn!!!\""


translate english c7133_ebcd1bdb:



    voice "voice/c71/3301540a02.opus"
    aoi "\"Huh...? Shinichi? What are you—AAAAAAAAAHHH!!!\""


translate english c7133_ea6e7ecb:



    voice "voice/c71/3301550a02.opus"
    aoi "\"Aah! Aah! Aah! Nnnnggghhh!!!\""


translate english c7133_1ed5786d:



    voice "voice/c71/3301560a02.opus"
    aoi "\"Hnnn... nnn... ggghh...!!! It's in my ass... AAAAAHHH!!!\""


translate english c7133_85cd38b6:


    "A estas alturas, ya no soporto ver más."


translate english c7133_45c29074:


    "Meto lentamente mi polla dura dentro de ella..."


translate english c7133_45058e32:



    voice "voice/c71/3301570a02.opus"
    aoi "\"Nnhaah! Aah! Aaahh! Aah! Oh god! It's so big— It's filling me up!\""


translate english c7133_03553a4c:



    voice "voice/c71/3301580a02.opus"
    aoi "\"Shinichi... Nnngh...! Your cock's... even bigger than last time...!\""


translate english c7133_e91fcace:


    "Aoi ha perdido toda compostura ahora."


translate english c7133_cb49e1c4:


    "Pero entonces, yo también."


translate english c7133_33f69dbb:


    "Su culo es considerablemente más apretado que su coño."


translate english c7133_08fffa5d:


    "Envuelve suavemente mi punta."


translate english c7133_37ebd674:


    "Ansioso por más, empiezo a embestir."


translate english c7133_7e2d1d6d:



    voice "voice/c71/3301590a02.opus"
    aoi "\"Hnngh... nnn... aah...! Shinichi... you're moving... so fast...!\""


translate english c7133_40e0e696:



    voice "voice/c71/3301600b03.opus"
    c "\"Aaahh! Oh wow! Oh my gosh! Aoi-senpai! This feels so different from last time!\""


translate english c7133_dfcbf9c0:



    voice "voice/c71/3301610a02.opus"
    aoi "\"Aaahh! Aah! Aah, aah, aah! It feels so good... so... good...!\""


translate english c7133_049185b5:



    voice "voice/c71/3301620a02.opus"
    aoi "\"Hnnn! Nnnggh! Nnn! Nnhaah! Aah! Aah! Aah! Aah! Aah! AAAAHH!!!\""


translate english c7133_ad6f69a8:



    voice "voice/c71/3301630b03.opus"
    c "\"Oh god! I can't take it! It's too... intense... You're gonna make me cu—Nnngghh!!!\""


translate english c7133_a70fbdef:



    voice "voice/c71/3301640a02.opus"
    aoi "\"Nnggh! Nnn! Shinichi! Harder! Fuck my ass... Harder! Harder!!!\""


translate english c7133_8ab17e38:



    voice "voice/c71/3301650b03.opus"
    c "\"Oh my god... Oh no... I can't! Aah! Aaahh! I'm gonna cu—Nnnnggh! Nnnggghhh!!!\""


translate english c7133_05a771d5:



    voice "voice/c71/3301660b03.opus"
    c "\"AaaAAAH! Aah...! Aah...! Aaahh...! Aaahh...! Aah! Aah... AAAAAHHHH!!!\""


translate english c7133_f56c6b1e:



    voice "voice/c71/3301670b03.opus"
    c "\"Hnnn! Oh god... Aoi...senpai...! Stop... I... I'm cumming... NnhaaaaAAAAHHH!!!\""


translate english c7133_22146298:


    "Ryuujirou ruega y ruega, pero Aoi está demasiado absorta rebotando sobre nuestras pollas para notarlo."


translate english c7133_106797a7:



    voice "voice/c71/3301680a02.opus"
    aoi "\"Hnnn! Oh god! It won't stop!!! My ass feels so good! It feels so good!!!\""


translate english c7133_fd501c19:



    voice "voice/c71/3301690a02.opus"
    aoi "\"Aoi's... such a mess... Nnggh! Aoi can't... tell up from down anymore...!\""


translate english c7133_6cdcd54a:



    voice "voice/c71/3301700a02.opus"
    aoi "\"It all feels so good! Hnngghh! Nnnn!!! Aoi's LOSING IT—!!!\""


translate english c7133_4b8ecdf3:



    voice "voice/c71/3301710b03.opus"
    c "\"Nnnn...! Nnn... nnnnng! Aaahh... hnnn! Aaah... hnnggh... nnn...!\""


translate english c7133_47a184a1:


    "Aoi no muestra señales de ir más despacio—y Ryuujirou está atrapado bajo ella, sin poder hablar por el placer."


translate english c7133_1a3431a4:


    "Lo siento, amigo, pero yo tampoco me detengo."


translate english c7133_e978c71c:


    "A diferencia de su coño, su culo se siente infinito, y no me canso de él."


translate english c7133_cde87c6d:



    voice "voice/c71/3301720a02.opus"
    aoi "\"Boop... boop boop... Shin...ichi...?\""


translate english c7133_f751c55f:



    voice "voice/c71/3301730a02.opus"
    aoi "\"Aaahh... Can you feel it...? Can you feel... the other cock... next door...?\""


translate english c7133_ccc88a30:



    voice "voice/c71/3301740a02.opus"
    aoi "\"Grinding against each other... inside me... Nnnnngg!!! It's... so naughty...!\""


translate english c7133_e1f6b036:



    voice "voice/c71/3301750a02.opus"
    aoi "\"Will it be naughty enough... to keep me from disappearing...?\""


translate english c7133_ffb11b81:



    voice "voice/c71/3301760a02.opus"
    aoi "\"Even if my signal won't reach... Even if I'm out of service... Even if Aoi can't pray to God anymore...\""


translate english c7133_8bf55bce:



    voice "voice/c71/3301770a02.opus"
    aoi "\"Can we still... stay together forever...?\""


translate english c7133_b91f0b42:


    "Asiento."


translate english c7133_8d2d764a:



    voice "voice/c71/3301780a02.opus"
    aoi "\"Haah... aah! Whoa... Aoi can feel... the happiness... the zappy-ness... rising up... from deep inside... Nnnnn!!!\""


translate english c7133_3a573d49:



    voice "voice/c71/3301790a02.opus"
    aoi "\"There! Right there! Just like that! Haaahh! Aaah! Aah, aah, aah, aah!!!\""


translate english c7133_8d248fe8:



    voice "voice/c71/3301800b03.opus"
    c "\"Aah... aah! Aaahh! AAAAAHH!!! Aoi...senpai... I'm getting... hard again...!\""


translate english c7133_d7087de6:



    voice "voice/c71/3301810b03.opus"
    c "\"AAAAAAHHH! It feels so good... Hnnngg!!! I think I'm... going crazy...!\""


translate english c7133_4907a8c4:



    voice "voice/c71/3301820a02.opus"
    aoi "\"Boop boop... Are we all glitching? Glitching into sex perverts? Aaahh!\""


translate english c7133_869cd6bd:


    "Arquea la espalda."


translate english c7133_8a83c3e5:


    "Esta es la recta final."


translate english c7133_6c5f8ddf:



    voice "voice/c71/3301830a02.opus"
    aoi "\"Shinichi! Shinichi! AAAAHH!!! Your... your cock is filling me up... Nnnnnngg!!!\""


translate english c7133_0934b303:



    voice "voice/c71/3301840a02.opus"
    aoi "\"Hnnn! Nnn! Aah! AAAAH! Aah! Aah! Aah! Aah! Aah! Aah!!!\""


translate english c7133_8aa0592b:



    voice "voice/c71/3301850a02.opus"
    aoi "\"Hnn! Nnn! Nnggh! Shinichi... Aaah! Aah! Aah! Aah, aah, aaaaaaAAAAAAAAAAHHHH!\""


translate english c7133_45564320:



    voice "voice/c71/3301860a02.opus"
    aoi "\"NNNNNGGGGGGGHHHHH!!!\""


translate english c7133_3e81981d:



    voice "voice/c71/3301870a02.opus"
    aoi "\"Nnnn...! Nnn! Nnhaah! Nngghh! Nnhaah! Aah! Aah... aaahh... aah...!\""


translate english c7133_b64ae5d5:



    voice "voice/c71/3301880a02.opus"
    aoi "\"Hnn... nnn... nnnn... nnn... nn... nngh... nnn... nnnn... nn...\""


translate english c7133_80317688:



    voice "voice/c71/3301890b03.opus"
    c "\"Aaah... aah... aaahh... aaaaahh... aaahh...\""


translate english c7133_1de056a5:



    voice "voice/c71/3301900b03.opus"
    c "\"I can't... believe this...\""


translate english c7133_4dfe6641:



    voice "voice/c71/3301910a02.opus"
    aoi "\"Hnn... nngghh... nn... nnn... haah... whew... nngh... nn... nnnn...!\""


translate english c7133_87730572:



    voice "voice/c71/3301920a02.opus"
    aoi "\"Boop boop... Both of... my holes... are so... full of cum...\""


translate english c7133_8cd3dbcc:



    voice "voice/c71/3301930a02.opus"
    aoi "\"Boop boop... boop boop boop boop boop boop...\""


translate english c7133_d9a5a449:


    "Aoi sonríe satisfecha."


translate english c7133_e2ff0fda:



    voice "voice/c71/3301940a02.opus"
    aoi "\"Shinichi... Aoi loves you...\""


translate english c7133_c4f80e95:


    xy "\"I love you too, Aoi...\""


translate english c7133_1b7f0700:


    "Ya no tengo que preocuparme de que me la quiten."


translate english c7133_8c0c3249:


    "No importa quién se interponga en nuestro camino, seguiré amándola, y sé que ella también me seguirá amando."


translate english c7133_9f96f4cd:


    "Incluso si nuestra relación es un poco retorcida..."


translate english c7133_ed9452db:


    "Sigue siendo el camino que elegí."


translate english c7133_735eeb63:


    "Con el pecho pesado de amor por ella, exprimo mi última gota, luego me retiro lentamente—"


translate english c7133_96689f94:



    voice "voice/c71/3301950a02.opus"
    aoi "\"...Not allowed.\""


translate english c7133_69657135:


    xy "\"—!!!\""


translate english c7133_3849488c:


    "Su ojete se aprieta sobre mí, impidiendo mi escape."


translate english c7133_dd7df35f:



    voice "voice/c71/3301960a02.opus"
    aoi "\"We're not... done yet.\""


translate english c7133_f1b62580:


    xy "\"Huh...? Wait—Aoi—?!\""


translate english c7133_3bffe683:



    voice "voice/c71/3301970b03.opus"
    c "\"AAAAAAAAAAAAAAAHHHHH!!!\""


translate english c7133_3a251ea0:



    voice "voice/c71/3301980a02.opus"
    aoi "\"Give me more... More...! We're only just getting started...!\""


translate english c7133_3e7fb4c7:


    "Aoi susurra diabólicamente."


translate english c7133_f3a6af0b:


    "Parece tan feliz... que no puedo escapar..."


translate english c7133_e734a10d:



    voice "voice/c71/3301990a02.opus"
    aoi "\"Haaah! Aah! Aaahh...! Oh god... It's getting big again... AAAAHH!!!\""


translate english c7133_5c7e856f:


    "Una cálida y difusa felicidad envuelve mi mente..."


translate english c7133_db6f85ad:


    "Mi conciencia se desvanece..."


translate english c7133_7bee345a:



    voice "voice/c71/3302000a02.opus"
    aoi "\"Shinichi... Aoi loves you...\""


translate english c7133_8e8d593f:


    "Yo también te amo..."


translate english c7133_dbc942c6:


    "Estoy tan feliz... que casi da miedo..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
