

translate english a1111_ddb16de8:


    xy "\"Hwaaah…\""


translate english a1111_499e326a:


    "El inicio de un nuevo día."


translate english a1111_f94a4ee0:


    "Vaya, ese sueño que tuve anoche fue bastante raro..."


translate english a1111_cf343fad:


    "Pero sé que hoy será igual que siempre."


translate english a1111_fd7d9c84:


    "Otro día común y corriente—"


translate english a1111_a7ded73a:


    xy "\"...Huh?\""


translate english a1111_ebc485e7:


    "Una carta cae de mi casillero de zapatos."


translate english a1111_0508a675:


    "La llevo a mi pupitre y la abro con cuidado, medio aterrado de descubrir lo que me espera dentro."


translate english a1111_f3dce250:


    "—Encuéntrame en la azotea a la hora del almuerzo."


translate english a1111_4c5953ec:



    voice "voice/a11/1100010b01.opus"
    xtl "\"DIE!\""


translate english a1111_9e82ce78:


    xy "\"AAAH!\""


translate english a1111_1c47813d:


    xy "\"Yuutarou?! Were you peeking?!\""


translate english a1111_74883c7e:



    voice "voice/a11/1100020b01.opus"
    xtl "\"First I find out you're old friends with Sone-san... and then I find out that not only did you try to cheat on her with Mukou...\""


translate english a1111_959a5616:



    voice "voice/a11/1100030b01.opus"
    xtl "\"But on top of that, you also got this old-fashioned love letter?!\""


translate english a1111_7e2c8988:



    voice "voice/a11/1100040b01.opus"
    xtl "\"You're a normie, aren't you? You ARE! You're a goddamn NORMIE!\""


translate english a1111_39fbb446:



    voice "voice/a11/1100050b01.opus"
    xtl "\"Your god may forgive you, but as the captain of the Boys and Dreams Club, I, Akebono Yuutarou NEVER WILL!!!\""


translate english a1111_0efaea52:


    xy "\"Keep your nose out of other people's letters.\""


translate english a1111_2632f40c:



    voice "voice/a11/1100060b01.opus"
    xtl "\"Sorry!\""


translate english a1111_c801aca7:



    voice "voice/a11/1100070b01.opus"
    xtl "\"But you know stuff like this will affect whether the BD Club lives to see another day!\""


translate english a1111_72eaaadd:


    "Ah, sí. El \"Boys and Dreams Club.\""


translate english a1111_bd414b57:


    "No te preocupes, a mí tampoco me tiene mucho sentido."


translate english a1111_4332c9ca:


    "Yuutarou describe su club como \"for boys who want to pursue their dreams.\""


translate english a1111_29b8c971:


    "En lo personal, no tengo idea de qué significa eso."


translate english a1111_cf8fd7bf:


    "El club existe desde hace bastante tiempo, en realidad, pero con un nombre así, no me imagino a mucha gente esforzándose por unirse."


translate english a1111_b3f2cf06:


    "Como era de esperarse, cuando llegó la primavera, Yuutarou era el único miembro que quedaba, y el Club BD estaba a punto de disolverse."


translate english a1111_e6435dd1:


    "In the end, he convinced me to \"join\"(solo de nombre) puramente para mantener vivo el club."


translate english a1111_8c3e6122:


    xy "\"It doesn't matter what I do as long as I stay in the club, right?\""


translate english a1111_ec0f64ed:



    voice "voice/a11/1100080b01.opus"
    xtl "\"Heh heh heh... My friend, you can't pursue a dream you're already living.\""


translate english a1111_01cc762b:



    voice "voice/a11/1100090b01.opus"
    xtl "\"The moment you achieve romantic fulfillment and become a normie, your membership is null and void! This is the oath sworn by the BD Boys!!!\""


translate english a1111_01bc2b8d:


    xy "\"Maybe disbanding is for the best...?\""


translate english a1111_7237b66b:



    voice "voice/a11/1100100b01.opus"
    xtl "\"I'm starting to think so, too.\""


translate english a1111_e1138969:


    "Yuutarou may seem like a goofball, but he takes this 100%% seriously."


translate english a1111_216c31d6:



    voice "voice/a11/1100110b01.opus"
    xtl "\"No sense in sabotaging a relationship just to keep my club alive, you know?\""


translate english a1111_4d39cea5:



    voice "voice/a11/1100120b01.opus"
    xtl "\"Here.\""


translate english a1111_43520a5f:


    "Pone algo sobre mi pupitre."


translate english a1111_102e4726:


    xy "\"That's the game I saw yesterday!\""


translate english a1111_9f0f2905:


    "Después de que Mukou se fuera, Yuutarou exigió saber hasta el último detalle de lo que pasó."


translate english a1111_a9c6156d:


    "Obviamente no podía contarle todo eso que dijo Miyuki, pero sí le conté sobre la novela visual en su teléfono."


translate english a1111_39eef41a:


    xy "\"I barely gave you anything to go on... How'd you find it?\""


translate english a1111_d80ac36a:



    voice "voice/a11/1100130b01.opus"
    xtl "\"Oh, Ryuujirou knows a lot about these games.\""


translate english a1111_db136ee6:


    xy "\"Who's Ryuujirou?\""


translate english a1111_8fad3b1c:



    voice "voice/a11/1100140b01.opus"
    xtl "\"My kid brother.\""


translate english a1111_01f49b96:



    voice "voice/a11/1100150b01.opus"
    xtl "\"You said the heroine looks dead on like Mukou, so I showed him a pic of her. That was all it took.\""


translate english a1111_90ef2934:


    "Miro a la chica en la pantalla."


translate english a1111_d2a13012:



    voice "voice/a11/1100160a02.opus"
    aoi "\"\"......\"\""


translate english a1111_d5b15515:


    "Luego miro a la chica sentada a unos pupitres de distancia."


translate english a1111_394da810:



    voice "voice/a11/1100170a02.opus"
    aoi "\"\"......\"\""


translate english a1111_748cec0b:


    "Son absolutamente idénticas."


translate english a1111_49af4d4f:


    "Una recreación 2D perfecta."


translate english a1111_05349fec:


    "Si me dijeras que los desarrolladores basaron su personaje en ella, no lo dudaría ni un segundo."


translate english a1111_03876858:


    "Mukou se sienta en silencio en su pupitre. No intenta hablar con nadie ni jugar con su teléfono; solo mira al vacío."


translate english a1111_41261b98:


    "Mientras todos los demás charlan sobre su mañana con sus amigos, el espacio a su alrededor está perfectamente silencioso, como un vacío."


translate english a1111_6dd717e3:


    "Casi como si estuviera concentrando todo su ser en captar las ondas de radio más tenues desde los confines más lejanos del espacio..."


translate english a1111_38a968bf:



    voice "voice/a11/1100180a02.opus"
    aoi "\"Got it!\""


translate english a1111_fef689d6:


    "Justo entonces, lanza la mano hacia el aire."


translate english a1111_6dd76e58:



    voice "voice/a11/1100190a02.opus"
    aoi "\"Transmission received.\""


translate english a1111_7e0c10e1:



    voice "voice/a11/1100200a02.opus"
    aoi "\"Development schedule confirmed.\""


translate english a1111_dee0258e:



    voice "voice/a11/1100210a02.opus"
    aoi "\"Route in progress.\""


translate english a1111_067f5a93:


    "Balbucea sin dirigirse a nadie en particular."


translate english a1111_a81d134b:


    "Pero nuestra clase ya está acostumbrada a sus excentricidades."


translate english a1111_cb83da42:


    "A nadie le sorprende su comportamiento."


translate english a1111_e2400738:


    "Al menos, esa es la impresión que tengo."


translate english a1111_b59ea486:


    xy "\"What a weirdo.\""


translate english a1111_e2db755f:



    voice "voice/a11/1100220b01.opus"
    xtl "\"Nothing against her, but... I suggest you set your sights elsewhere.\""


translate english a1111_a1f91b17:



    voice "voice/a11/1100230b01.opus"
    xtl "\"She's one giant headache waiting to happen.\""


translate english a1111_d5205aa3:


    xy "\"Huh? I never said I was interested in her like that.\""


translate english a1111_55c8bee5:



    voice "voice/a11/1100240b01.opus"
    xtl "\"Then why are you asking about her?\""


translate english a1111_0543e012:


    xy "\"She tried to kiss me on the roof! Obviously I'm gonna be at least a little curious, you know?\""


translate english a1111_220a69ef:


    xy "\"But that's all it is.\""


translate english a1111_b996d4fc:



    voice "voice/a11/1100250b01.opus"
    xtl "\"For your sake, I sure hope so.\""


translate english a1111_8098d48f:



    voice "voice/a11/1100260b01.opus"
    xtl "\"I've heard some pretty bad rumors, dude.\""


translate english a1111_f9486b91:


    xy "\"Such as?\""


translate english a1111_1aeba34a:



    voice "voice/a11/1100270b01.opus"
    xtl "\"They say she's a total slut.\""


translate english a1111_bea89d5b:



    voice "voice/a11/1100280b01.opus"
    xtl "\"Not that I buy it, obviously!\""


translate english a1111_ba3766c2:



    voice "voice/a11/1100290b01.opus"
    xtl "\"I mean, she's impossible to talk to, much less anything else.\""


translate english a1111_52548510:


    "Después de presenciar sus locuras de cerebro gamer ayer, estoy de acuerdo."


translate english a1111_b37e634f:


    "Parece estar en su propio mundito... o, cuando menos, totalmente ajena a la gente a su alrededor."


translate english a1111_e5a74400:


    "No puede mantener una conversación ni aunque le fuera la vida en ello."


translate english a1111_d72d08ff:


    xy "\"Hey, Yuutarou?\""


translate english a1111_7d816649:


    xy "\"Is this game available on the app store?\""


translate english a1111_4ed7a1f6:



    voice "voice/a11/1100300b01.opus"
    xtl "\"You can keep it.\""


translate english a1111_1bd1985e:


    xy "\"What? The phone?\""


translate english a1111_adb359af:



    voice "voice/a11/1100310b01.opus"
    xtl "\"Yeah. Ryuujirou got himself a new one recently.\""


translate english a1111_06105597:



    voice "voice/a11/1100320b01.opus"
    xtl "\"There's no SIM card, so you can't make calls with it, but you can download games no problem.\""


translate english a1111_f892ac9f:



    voice "voice/a11/1100330b01.opus"
    xtl "\"According to him, this is a cult classic NTR game.\""


translate english a1111_412d561d:


    xy "\"NTR? What's that?\""


translate english a1111_c01526ba:



    voice "voice/a11/1100340b01.opus"
    xtl "\"Hell if I know! It's visual novel terminology, I guess.\""


translate english a1111_b73e2502:



    voice "voice/a11/1100350b01.opus"
    xtl "\"But I'm getting some BD vibes from it!\""


translate english a1111_1b34a29e:


    xy "\"I... see...\""


translate english a1111_32d4876e:



    voice "voice/a11/1100360a01.opus"
    mx "\"Good morning!\""


translate english a1111_8a24335d:


    "La voz de Miyuki resuena por todo el salón."


translate english a1111_b5873f26:


    "Y así, todas las chicas empiezan a reunirse a su alrededor en un gran círculo."


translate english a1111_6a02a364:


    "Empiezan a hacerle preguntas, como si vio el estreno de anoche, o si se enteró de la nueva tienda que acaban de abrir en el pueblo."


translate english a1111_3c52df7c:


    "Sin importar el tema, Miyuki responde cada una con gracia, sofisticación y una sonrisa."


translate english a1111_cf581b4f:


    "Y así, ilumina el salón, atrayendo la atención de bastantes chicos de nuestra clase."


translate english a1111_2c058dd4:


    "Esto pasa cada mañana, y cada vez me hace dolorosamente consciente de la distancia entre nosotros."


translate english a1111_18c90964:


    "Sone Miyuki es la reina, y yo no soy nadie."


translate english a1111_b3250e71:



    voice "voice/a11/1100370b01.opus"
    xtl "\"A lone flower, blossoming in the vast desert of this campus...!\""


translate english a1111_7a90fc70:



    voice "voice/a11/1100380b01.opus"
    xtl "\"Man... She's just so beautiful...\""


translate english a1111_fad64552:


    xy "\"Yeah...\""


translate english a1111_10f44cca:


    "Aquí en el salón, ella es la estrella del espectáculo."


translate english a1111_a64fd880:


    "Pero sé que solo está interpretando el papel."


translate english a1111_af9d063c:


    "Como su viejo amigo, sé cómo es en realidad: exigente y directa."


translate english a1111_35409708:



    voice "voice/a11/1100390b01.opus"
    xtl "\"D-Dude! Did you see that?!\""


translate english a1111_f0f916ef:


    xy "\"Hmm?\""


translate english a1111_fcf6ac64:



    voice "voice/a11/1100400b01.opus"
    xtl "\"Sone-san just glanced over at us!\""


translate english a1111_a57361a7:



    voice "voice/a11/1100410b01.opus"
    xtl "\"Haah, I can't help it. I'm crazy about her! And if I wanna pursue this dream, I gotta confess my love. It's destiny!\""


translate english a1111_c31fc586:


    xy "\"Good luck. I'm rooting for you, man.\""


translate english a1111_4f51a200:


    "Y aun así, incluso mientras hablo..."


translate english a1111_09276b9e:



    voice "voice/a11/1100420a02.opus"
    aoi "\"Boop boop...\""


translate english a1111_bf14066f:


    "...no puedo evitar mirar a Mukou de reojo."


translate english a1111_9c820ae5:


    "En medio de la charla alegre, ella permanece perfectamente quieta, la viva imagen de la soledad."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
