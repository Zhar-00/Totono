

translate english e3424d_45f657e5:


    "El número que Miyuki prefiere más que ningún otro."


translate english e3424d_2adca805:


    "¿Cuál podría ser?"


translate english e3424d_4b93bfe6:


    "Repaso mis recuerdos desesperadamente."


translate english e3424d_23699952:


    "...Aunque no es que tenga mucho de qué hablar..."


translate english e3424d_f4621665:



    voice "voice/e34/24d00010b02.opus"
    kmsm "\"NO CAUSE FOR CONCERN.\""


translate english e3424d_009d74ea:



    voice "voice/e34/24d00020b02.opus"
    kmsm "\"MIYUKI HAS RECORDED THIS NUMBER.\""


translate english e3424d_c194dac0:



    voice "voice/e34/24d00030b02.opus"
    kmsm "\"VIEW THE CONTENTS OF THE PHOTOS FOLDER ON HER SMARTPHONE.\""


translate english e3424d_df598f95:


    "Como se pidió, abro la aplicación de Fotos."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
