

translate english a6171_0accd139:


    xy "\"......\""


translate english a6171_c80690cf:


    "Como de costumbre, las jaulas de bateo están vacías."


translate english a6171_0940b21c:


    "Me siento en la banca, con el bate en la mano, mirando al vacío."


translate english a6171_1230fde9:


    "Mis emociones se hinchan en mi pecho hasta estar a punto de estallar, luego se hunden en una vaga falta de forma que da vueltas en mi estómago."


translate english a6171_51ecb45b:


    "Sin posibilidad de liberarse, se acumula como lodo."


translate english a6171_2d16e079:


    "El tiempo avanza."


translate english a6171_1feeb280:


    "En secreto, me había hecho ilusiones."


translate english a6171_5168d0cf:


    "Aquí estoy, en nuestro viejo lugar de reunión de la infancia."


translate english a6171_60b9dc7e:


    "El lugar donde una vez cambié su destino."


translate english a6171_4f840486:


    "Y de algún modo me convencí de que quizá venir aquí cambiaría el mío."


translate english a6171_2295242b:


    "Pero no logré golpear ni una sola pelota."


translate english a6171_1aa03e49:


    "Ni siquiera pude dar un solo swing."


translate english a6171_1f957e05:


    xy "\"Jajaja...\""


translate english a6171_504ef27c:


    "Me río con desgana de mi propia y lamentable situación."


translate english a6171_729afb2a:


    "Nunca me he odiado más en toda mi vida."


translate english a6171_24991a54:


    "Oigo un sonido familiar."


translate english a6171_84f0eafb:


    "Un pequeño gatito negro sale tambaleándose de debajo de la banca."


translate english a6171_01885899:


    xy "\"¿Eru, eres tú?\""


translate english a6171_82413a58:


    "El gato transceptor maúlla dulcemente en respuesta."


translate english a6171_738bd552:


    "Si Eru está aquí... entonces..."


translate english a6171_20761675:



    voice "voice/a61/7100030a02.opus"
    aoi "\"Shinichi.\""


translate english a6171_98bc522c:


    xy "\"¿Dónde has estado?\""


translate english a6171_9eda51a7:



    voice "voice/a61/7100040a02.opus"
    aoi "\"Bueno...\""


translate english a6171_727f4604:


    xy "\"¿Por qué molestarte en volver ahora?\""


translate english a6171_a55145ea:


    xy "\"¿Vienes a señalar y reírte?\""


translate english a6171_0d4c3a30:



    voice "voice/a61/7100050a02.opus"
    aoi "\"No.\""


translate english a6171_d897690b:


    xy "\"¿¡Entonces por qué SÍ estás aquí!?\""


translate english a6171_5b90fe76:


    xy "\"Ah, ya entiendo. Vienes a arreglar las cosas.\""


translate english a6171_771c60bc:


    xy "\"Crees que Miyuki y yo tenemos que estar juntos, ¿verdad?\""


translate english a6171_d28fef19:


    xy "\"¿Así que intentas ponerme en la 'ruta' correcta o lo que sea?\""


translate english a6171_7c3bf8c9:



    voice "voice/a61/7100060a02.opus"
    aoi "\"Aoi te extrañó.\""


translate english a6171_270ef6bb:



    voice "voice/a61/7100070a02.opus"
    aoi "\"Una vez que estás en una ruta, todas las demás chicas se desvanecen en el fondo.\""


translate english a6171_3f01c530:



    voice "voice/a61/7100080a02.opus"
    aoi "\"Así que se suponía que Aoi ya no te vería.\""


translate english a6171_68179754:



    voice "voice/a61/7100090a02.opus"
    aoi "\"Pero...\""


translate english a6171_4fd87c84:



    voice "voice/a61/7100100a02.opus"
    aoi "\"Aoi te extrañó tanto...\""


translate english a6171_22503ae1:


    "Esta conversación es demasiado poca y demasiado tarde."


translate english a6171_68f88086:


    "Y aun así, de repente, me lleno de autodesprecio."


translate english a6171_ab64d668:



    voice "voice/a61/7100110a02.opus"
    aoi "\"¿Por qué no vas a la obra?\""


translate english a6171_00e0c9c7:



    voice "voice/a61/7100120a02.opus"
    aoi "\"¿Las cosas no funcionan con Miyuki?\""


translate english a6171_8bf2a40e:



    voice "voice/a61/7100130a02.opus"
    aoi "\"¿La besaste?\""


translate english a6171_3c1a3166:


    xy "\"...No.\""


translate english a6171_9de1bba9:


    xy "\"Ella va a besar a alguien, pero no seré yo.\""


translate english a6171_f256e890:



    voice "voice/a61/7100140a02.opus"
    aoi "\"¿No quieres?\""


translate english a6171_9d15d44c:


    xy "\"...Ya terminé de hablar de esto.\""


translate english a6171_577f2db2:



    voice "voice/a61/7100150a02.opus"
    aoi "\"Así que SÍ quieres.\""


translate english a6171_cf31d9a0:


    xy "\"¡Dije que ya terminé!\""


translate english a6171_fecacdb4:



    voice "voice/a61/7100160a02.opus"
    aoi "\"Quieres besarla.\""


translate english a6171_7390c4da:


    xy "\"¡Cállate!\""


translate english a6171_3d87b7a1:



    voice "voice/a61/7100170a02.opus"
    aoi "\"Boop boop...\""


translate english a6171_93e66854:


    xy "\"...No me lo merezco.\""


translate english a6171_7a1605de:


    xy "\"Ella está muy claramente fuera de mi liga.\""


translate english a6171_f96d8ea6:


    xy "\"Ni yo soy TAN tonto.\""


translate english a6171_4e481604:



    voice "voice/a61/7100180a02.opus"
    aoi "\"Eso no lo sabes.\""


translate english a6171_93d04cdf:


    xy "\"Claro que sí.\""


translate english a6171_3585a1c5:



    voice "voice/a61/7100190a02.opus"
    aoi "\"¿Boop boop...?\""


translate english a6171_1058a0dc:


    xy "\"¿Hasta cuándo vas a seguir viviendo en tu mundo de fantasía? Esto no es un juego. Esto es la vida real.\""


translate english a6171_bda4dea5:


    xy "\"No puedo cambiar quién soy. Lo he intentado.\""


translate english a6171_988e9de2:


    xy "\"Dios no es real. Los milagros no son reales.\""


translate english a6171_494132e7:


    "Mi boca se mueve por su cuenta, soltando todas las cosas que nunca pude decir antes."


translate english a6171_966288c3:


    xy "\"Y tu dios tampoco es real.\""


translate english a6171_f0546899:


    "De repente, Aoi agarra un bate de béisbol."


translate english a6171_76a78b01:



    voice "voice/a61/7100200a02.opus"
    aoi "\"Hagamos una apuesta.\""


translate english a6171_d9315e90:


    xy "\"¿Qué?\""


translate english a6171_a2021b35:



    voice "voice/a61/7100210a02.opus"
    aoi "\"Aoi va a batear un jonrón.\""


translate english a6171_706e602c:


    "Se coloca en el área de bateo."


translate english a6171_a5b75134:


    "Luego adopta una postura de bateo, tal como le enseñamos."


translate english a6171_bab4578b:



    voice "voice/a61/7100220a02.opus"
    aoi "\"Y si Aoi batea un jonrón...\""


translate english a6171_eb7f461c:



    voice "voice/a61/7100230a02.opus"
    aoi "\"Tienes que decirle a Miyuki lo que sientes.\""


translate english a6171_6baf9016:


    xy "\"¿Perdón? No seas ridícula.\""


translate english a6171_232e2122:



    voice "voice/a61/7100240a02.opus"
    aoi "\"¡Boop boop!\""


translate english a6171_446df16b:


    "No responde."


translate english a6171_c7e0b082:


    "La pelota silba hacia ella, y ella batea."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
