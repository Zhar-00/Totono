

translate english a6171_0accd139:


    xy "\"......\""


translate english a6171_c80690cf:


    "Como de costumbre, las jaulas de bateo están vacías."


translate english a6171_0940b21c:


    "Me siento en la banca, con el bate en la mano, mirando al vacío."


translate english a6171_1230fde9:


    "Mis emociones se hinchan en mi pecho hasta estar a punto de estallar, luego se hunden en una vaga falta de forma que da vueltas en mi estómago."


translate english a6171_51ecb45b:


    "Sin posibilidad de liberarse, se acumula como lodo."


translate english a6171_2d16e079:


    "El tiempo avanza."


translate english a6171_1feeb280:


    "En secreto, me había hecho ilusiones."


translate english a6171_5168d0cf:


    "Aquí estoy, en nuestro viejo lugar de reunión de la infancia."


translate english a6171_60b9dc7e:


    "El lugar donde una vez cambié su destino."


translate english a6171_4f840486:


    "Y de algún modo me convencí de que quizá venir aquí cambiaría el mío."


translate english a6171_2295242b:


    "Pero no logré golpear ni una sola pelota."


translate english a6171_1aa03e49:


    "Ni siquiera pude dar un solo swing."


translate english a6171_1f957e05:


    xy "\"Hahaha...\""


translate english a6171_504ef27c:


    "Me río con desgana de mi propia y lamentable situación."


translate english a6171_729afb2a:


    "Nunca me he odiado más en toda mi vida."


translate english a6171_24991a54:


    "Oigo un sonido familiar."


translate english a6171_84f0eafb:


    "Un pequeño gatito negro sale tambaleándose de debajo de la banca."


translate english a6171_01885899:


    xy "\"Eru, is that you?\""


translate english a6171_82413a58:


    "El gato transceptor maúlla dulcemente en respuesta."


translate english a6171_738bd552:


    "Si Eru está aquí... entonces..."


translate english a6171_20761675:



    voice "voice/a61/7100030a02.opus"
    aoi "\"Shinichi.\""


translate english a6171_98bc522c:


    xy "\"Where have you been?\""


translate english a6171_9eda51a7:



    voice "voice/a61/7100040a02.opus"
    aoi "\"Well...\""


translate english a6171_727f4604:


    xy "\"Why bother coming back now?\""


translate english a6171_a55145ea:


    xy "\"Are you here to point and laugh?\""


translate english a6171_0d4c3a30:



    voice "voice/a61/7100050a02.opus"
    aoi "\"No.\""


translate english a6171_d897690b:


    xy "\"Then why ARE you here?\""


translate english a6171_5b90fe76:


    xy "\"Oh, I get it. You're here to patch things up.\""


translate english a6171_771c60bc:


    xy "\"You think Miyuki and I have to get together, right?\""


translate english a6171_d28fef19:


    xy "\"So you're trying to set me on the right 'route' or whatever?\""


translate english a6171_7c3bf8c9:



    voice "voice/a61/7100060a02.opus"
    aoi "\"Aoi missed you.\""


translate english a6171_270ef6bb:



    voice "voice/a61/7100070a02.opus"
    aoi "\"Once you're on a route, the other girls are supposed to fade into the background.\""


translate english a6171_3f01c530:



    voice "voice/a61/7100080a02.opus"
    aoi "\"So Aoi wasn't supposed to see you anymore.\""


translate english a6171_68179754:



    voice "voice/a61/7100090a02.opus"
    aoi "\"But...\""


translate english a6171_4fd87c84:



    voice "voice/a61/7100100a02.opus"
    aoi "\"Aoi missed you so much...\""


translate english a6171_22503ae1:


    "Esta conversación es demasiado poca y demasiado tarde."


translate english a6171_68f88086:


    "Y aun así, de repente, me lleno de autodesprecio."


translate english a6171_ab64d668:



    voice "voice/a61/7100110a02.opus"
    aoi "\"Why aren't you going to the play?\""


translate english a6171_00e0c9c7:



    voice "voice/a61/7100120a02.opus"
    aoi "\"Are things not working out with Miyuki?\""


translate english a6171_8bf2a40e:



    voice "voice/a61/7100130a02.opus"
    aoi "\"Did you kiss her?\""


translate english a6171_3c1a3166:


    xy "\"...No.\""


translate english a6171_9de1bba9:


    xy "\"She'll be kissing someone, but it won't be me.\""


translate english a6171_f256e890:



    voice "voice/a61/7100140a02.opus"
    aoi "\"Don't you want to?\""


translate english a6171_9d15d44c:


    xy "\"...I'm done talking about this.\""


translate english a6171_577f2db2:



    voice "voice/a61/7100150a02.opus"
    aoi "\"So you DO want to.\""


translate english a6171_cf31d9a0:


    xy "\"I said I'm done!\""


translate english a6171_fecacdb4:



    voice "voice/a61/7100160a02.opus"
    aoi "\"You want to kiss her.\""


translate english a6171_7390c4da:


    xy "\"Shut up!\""


translate english a6171_3d87b7a1:



    voice "voice/a61/7100170a02.opus"
    aoi "\"Boop boop...\""


translate english a6171_93e66854:


    xy "\"...I don't deserve to.\""


translate english a6171_7a1605de:


    xy "\"She's very clearly out of my league.\""


translate english a6171_f96d8ea6:


    xy "\"Even I'm not THAT stupid.\""


translate english a6171_4e481604:



    voice "voice/a61/7100180a02.opus"
    aoi "\"You don't know that.\""


translate english a6171_93d04cdf:


    xy "\"Sure I do.\""


translate english a6171_3585a1c5:



    voice "voice/a61/7100190a02.opus"
    aoi "\"Boop boop...?\""


translate english a6171_1058a0dc:


    xy "\"How long are you going to keep living in your fantasy world? This isn't a game. This is real life.\""


translate english a6171_bda4dea5:


    xy "\"I can't change who I am. I've tried.\""


translate english a6171_988e9de2:


    xy "\"God isn't real. Miracles aren't real.\""


translate english a6171_494132e7:


    "Mi boca se mueve por su cuenta, soltando todas las cosas que nunca pude decir antes."


translate english a6171_966288c3:


    xy "\"And your god isn't real, either.\""


translate english a6171_f0546899:


    "De repente, Aoi agarra un bate de béisbol."


translate english a6171_76a78b01:



    voice "voice/a61/7100200a02.opus"
    aoi "\"Let's make a bet.\""


translate english a6171_d9315e90:


    xy "\"What?\""


translate english a6171_a2021b35:



    voice "voice/a61/7100210a02.opus"
    aoi "\"Aoi's gonna hit a home run.\""


translate english a6171_706e602c:


    "Se coloca en el área de bateo."


translate english a6171_a5b75134:


    "Luego adopta una postura de bateo, tal como le enseñamos."


translate english a6171_bab4578b:



    voice "voice/a61/7100220a02.opus"
    aoi "\"And if Aoi does hit a home run...\""


translate english a6171_eb7f461c:



    voice "voice/a61/7100230a02.opus"
    aoi "\"You have to tell Miyuki how you feel.\""


translate english a6171_6baf9016:


    xy "\"Excuse me? Don't be ridiculous.\""


translate english a6171_232e2122:



    voice "voice/a61/7100240a02.opus"
    aoi "\"Boop boop!\""


translate english a6171_446df16b:


    "No responde."


translate english a6171_c7e0b082:


    "La pelota silba hacia ella, y ella batea."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
