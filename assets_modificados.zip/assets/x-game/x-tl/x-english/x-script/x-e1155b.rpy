

translate english e1155b_ef8b3c92:



    voice "voice/e11/55b00010a01.opus"
    mx "\"Come on, don't be like that...\""


translate english e1155b_684f90d7:



    voice "voice/e11/55b00020a01.opus"
    mx "Solo... ¡bésame...!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
