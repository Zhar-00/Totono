

translate english e2172f_da494787:


    "\"Cocina para principiantes.\""



translate english e2172f_ee125b69:



    voice "voice/e21/72f00010a01.opus"
    mx "\"...Ja, ja, muy gracioso. La quinta es la vencida, ¿eh?\""


translate english e2172f_235fa9c6:



    voice "voice/e21/72f00020a01.opus"
    mx "\"Mira, ¿ya vas a dejar de hacer tonterías?\""


translate english e2172f_e61f662d:


    xy "\"No estoy haciendo tonterías...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
