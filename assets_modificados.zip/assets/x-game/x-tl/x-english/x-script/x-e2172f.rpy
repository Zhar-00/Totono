

translate english e2172f_da494787:


    "\"Cooking 101.\""



translate english e2172f_ee125b69:



    voice "voice/e21/72f00010a01.opus"
    mx "\"...Ha ha, very funny. Fifth time's the charm, huh?\""


translate english e2172f_235fa9c6:



    voice "voice/e21/72f00020a01.opus"
    mx "\"Look, will you quit screwing around already?\""


translate english e2172f_e61f662d:


    xy "\"I'm not screwing around...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
