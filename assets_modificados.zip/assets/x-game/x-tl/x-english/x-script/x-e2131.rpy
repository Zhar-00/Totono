

translate english e2131_5fe89661:


    xy "\"Ñam, ñam, ñam... mmm...\""


translate english e2131_e8d5da02:



    voice "voice/e21/3100010a01.opus"
    mx "\"...¿Qué tal?\""


translate english e2131_0448fcba:


    xy "\"Perfecto.\""


translate english e2131_f0b197ac:


    "Como siempre, no tengo queja del almuerzo que preparó."


translate english e2131_8dcdbacb:


    "Solo el sabor basta para hacerme sonreír..."


translate english e2131_2b379c35:


    xy "\"Hombre, tu cerdo al jengibre está delicioso.\""


translate english e2131_9912db76:


    xy "\"Hombre, tus shumai están deliciosos.\""


translate english e2131_42bd4773:


    xy "\"Hombre, tu arroz takikomi está delicioso.\""


translate english e2131_a4309da8:



    voice "voice/e21/3100020a01.opus"
    mx "\"Bueno, ES mi plato especialidad, después de todo.\""


translate english e2131_b021c6cd:


    xy "\"No puedo creer que mi comida favorita resulte ser justo tu especialidad... Debe ser el destino o algo así.\""


translate english e2131_dd70fdd2:



    voice "voice/e21/3100030a01.opus"
    mx "\"No, la perfeccioné PORQUE es tu favorita.\""


translate english e2131_fcd7b165:


    xy "\"¿En serio...?\""


translate english e2131_1f4d6cba:



    voice "voice/e21/3100040a01.opus"
    mx "\"En serio, en serio. Soy la dueña de mi propio destino.\""


translate english e2131_a12c1d39:


    "Vaya... Supongo que Miyuki puede hacer cualquier cosa que se proponga..."


translate english e2131_16e3712f:


    xy "\"Aun así, me impresiona que supieras que es mi favorita.\""


translate english e2131_158964df:



    voice "voice/e21/3100050a01.opus"
    mx "\"¿Después de todos estos años de conocernos? ¡Claro que lo averiguaría tarde o temprano!\""


translate english e2131_fdaff7eb:



    voice "voice/e21/3100060a01.opus"
    mx "\"Espera... ¿Estás diciendo que no sabes cuál es la mía?\""


translate english e2131_edbe0de5:


    xy "\"¡C-Claro que lo sé! ¡Obviamente!\""


translate english e2131_3c4ebd4a:



    voice "voice/e21/3100070a01.opus"
    mx "\"Está bien entonces, veamos. ¿Cuál es mi comida favorita?\""


translate english e2131_b4fe0f80:


    xy "\"Tu comida favorita... es...\""


translate english e2131_9437d695:



    voice "voice/e21/3100080a01.opus"
    mx "\"¿Sí...?\""


translate english e2131_1f3542f5:


    xy "\"¡...Dulces!\""


translate english e2131_c06f7d63:



    voice "voice/e21/3100090a01.opus"
    mx "\"¡...Tienes que ser más específica!\""


translate english e2131_f4b093ad:


    xy "\"Perdón...\""


translate english e2131_62fabb7a:


    xy "\"¿Cuál ES tu postre favorito, de todos modos?\""


translate english e2131_7c5c9ed7:



    voice "voice/e21/3100100a01.opus"
    mx "\"Mmm... Veamos...\""


translate english e2131_ce4f4668:



    voice "voice/e21/3100110a01.opus"
    mx "\"Pastel de fresas, supongo.\""


translate english e2131_6f1f9492:



    voice "voice/e21/3100120a01.opus"
    mx "\"¡Manzanas caramelizadas! Me encantan.\""


translate english e2131_80dcdc4c:



    voice "voice/e21/3100130a01.opus"
    mx "\"Bueno, siempre ha sido mi sueño comerme un balde entero de pudín...\""


translate english e2131_042b11df:


    xy "\"Es una respuesta muy de niña.\""


translate english e2131_7e5179cf:



    voice "voice/e21/3100140a01.opus"
    mx "\"Métete en tus asuntos.\""


translate english e2131_7ad95a72:


    xy "\"Está bien entonces, ¿qué comidas odias?\""


translate english e2131_c658811a:



    voice "voice/e21/3100150a01.opus"
    mx "\"No soy una NIÑA. Puedo comer casi cualquier cosa.\""


translate english e2131_4365b57b:


    xy "\"Seguro, PUEDES comerlo, pero debe haber al menos una cosa que preferirías no comer si puedes evitarlo.\""


translate english e2131_4c52e2a9:



    voice "voice/e21/3100160a01.opus"
    mx "\"Bueno...\""


translate english e2131_ed4ca619:


    "Miyuki hace una pausa para pensar un rato, luego levanta la vista hacia mí."


translate english e2131_96380629:



    voice "voice/e21/3100170a01.opus"
    mx "\"Panceta de cerdo estofada. Es demasiado grasosa.\""


translate english e2131_02afcbd9:



    voice "voice/e21/3100180a01.opus"
    mx "\"Huevas de salmón. La textura es súper asquerosa.\""


translate english e2131_752e3f49:



    voice "voice/e21/3100190a01.opus"
    mx "\"Toronja. No soporto el sabor.\""


translate english e2131_d1d64dcc:


    xy "\"Ah, ya veo.\""


translate english e2131_5a2feb1e:



    voice "voice/e21/3100200a01.opus"
    mx "\"...¿¡De qué te ríes!?\""


translate english e2131_741065e8:



    voice "voice/e21/3100210a01.opus"
    mx "\"¡Tú también tienes aversiones alimentarias, ¿sabes! ¡Como ESTO, por ejemplo!\""


translate english e2131_14a8d71d:


    xy "\"¡Gah...!\""


translate english e2131_1dd83322:


    "Sostiene en alto una lata de jugo de tomate de Yabaley."


translate english e2131_4174b269:



    voice "voice/e21/3100220a01.opus"
    mx "\"¿Qué preferirías beber, esto o té?\""


translate english strings:


    old "Томатный сок Ябалея"
    new "Jugo de tomate de Yabaley"


    old "Чай"
    new "Té"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
