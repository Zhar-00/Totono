

translate english e2131_5fe89661:


    xy "\"Nom, nom, nom... mmm...\""


translate english e2131_e8d5da02:



    voice "voice/e21/3100010a01.opus"
    mx "\"...How is it?\""


translate english e2131_0448fcba:


    xy "\"Perfect.\""


translate english e2131_f0b197ac:


    "Como siempre, no tengo queja del almuerzo que preparó."


translate english e2131_8dcdbacb:


    "Solo el sabor basta para hacerme sonreír..."


translate english e2131_2b379c35:


    xy "\"Man, your ginger‐fried pork is delicious.\""


translate english e2131_9912db76:


    xy "\"Man, your Shaomai dumplings are delicious.\""


translate english e2131_42bd4773:


    xy "\"Man, your takikomi rice is delicious.\""


translate english e2131_a4309da8:



    voice "voice/e21/3100020a01.opus"
    mx "\"Well, it IS my specialty dish, after all.\""


translate english e2131_b021c6cd:


    xy "\"I can't believe my favorite food just happens to be your specialty... It must be fate or something.\""


translate english e2131_dd70fdd2:



    voice "voice/e21/3100030a01.opus"
    mx "\"No, I perfected it BECAUSE it's your favorite.\""


translate english e2131_fcd7b165:


    xy "\"Really...?\""


translate english e2131_1f4d6cba:



    voice "voice/e21/3100040a01.opus"
    mx "\"Really really. I am the master of my own fate.\""


translate english e2131_a12c1d39:


    "Vaya... Supongo que Miyuki puede hacer cualquier cosa que se proponga..."


translate english e2131_16e3712f:


    xy "\"Still, I'm impressed you knew it was my favorite.\""


translate english e2131_158964df:



    voice "voice/e21/3100050a01.opus"
    mx "\"After all these years we've known each other? Of course I'd find out sooner or later!\""


translate english e2131_fdaff7eb:



    voice "voice/e21/3100060a01.opus"
    mx "\"Wait... Are you saying you don't know what mine is?\""


translate english e2131_edbe0de5:


    xy "\"O-Of course I know! Obviously!\""


translate english e2131_3c4ebd4a:



    voice "voice/e21/3100070a01.opus"
    mx "\"Okay then, let's hear it. What's my favorite food?\""


translate english e2131_b4fe0f80:


    xy "\"Your favorite food... is...\""


translate english e2131_9437d695:



    voice "voice/e21/3100080a01.opus"
    mx "\"Yes...?\""


translate english e2131_1f3542f5:


    xy "\"...Sweets!\""


translate english e2131_c06f7d63:



    voice "voice/e21/3100090a01.opus"
    mx "\"...You have to be more specific!\""


translate english e2131_f4b093ad:


    xy "\"Sorry...\""


translate english e2131_62fabb7a:


    xy "\"What IS your favorite dessert, anyway?\""


translate english e2131_7c5c9ed7:



    voice "voice/e21/3100100a01.opus"
    mx "\"Hmm... Let's see...\""


translate english e2131_ce4f4668:



    voice "voice/e21/3100110a01.opus"
    mx "\"Shortcake, I guess?\""


translate english e2131_6f1f9492:



    voice "voice/e21/3100120a01.opus"
    mx "\"Candy apples! I love them.\""


translate english e2131_80dcdc4c:



    voice "voice/e21/3100130a01.opus"
    mx "\"Well, it's always been my dream to eat a whole bucket full of pudding...\""


translate english e2131_042b11df:


    xy "\"That's such a kid answer.\""


translate english e2131_7e5179cf:



    voice "voice/e21/3100140a01.opus"
    mx "\"Mind your own business.\""


translate english e2131_7ad95a72:


    xy "\"Okay then, what foods do you hate?\""


translate english e2131_c658811a:



    voice "voice/e21/3100150a01.opus"
    mx "\"I'm not a CHILD. I can eat just about anything.\""


translate english e2131_4365b57b:


    xy "\"Sure, you CAN eat it, but surely there's gotta be at least one thing you'd rather not eat if you can avoid it.\""


translate english e2131_4c52e2a9:



    voice "voice/e21/3100160a01.opus"
    mx "\"Well...\""


translate english e2131_ed4ca619:


    "Miyuki hace una pausa para pensar un rato, luego levanta la vista hacia mí."


translate english e2131_96380629:



    voice "voice/e21/3100170a01.opus"
    mx "\"Braised pork belly. It's too fatty.\""


translate english e2131_02afcbd9:



    voice "voice/e21/3100180a01.opus"
    mx "\"Salmon roe. The texture is super gross.\""


translate english e2131_752e3f49:



    voice "voice/e21/3100190a01.opus"
    mx "\"Grapefruit. I just can't stand the flavor.\""


translate english e2131_d1d64dcc:


    xy "\"Ah, I see.\""


translate english e2131_5a2feb1e:



    voice "voice/e21/3100200a01.opus"
    mx "\"...What are you grinning about?!\""


translate english e2131_741065e8:



    voice "voice/e21/3100210a01.opus"
    mx "\"You have food aversions too, you know! Like THIS, for example!\""


translate english e2131_14a8d71d:


    xy "\"Gah...!\""


translate english e2131_1dd83322:


    "Sostiene en alto una lata de jugo de tomate de Yabaley."


translate english e2131_4174b269:



    voice "voice/e21/3100220a01.opus"
    mx "\"Which would you rather drink, this or tea?\""


translate english strings:


    old "Томатный сок Ябалея"
    new "Jugo de tomate de Yabaley"


    old "Чай"
    new "Té"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
