


translate english e2201_30634c65:


    "Miyuki y yo nos sentamos uno frente al otro."


translate english e2201_cd7c397b:


    "Entre nosotros, nuestros cuadernos están abiertos."


translate english e2201_74ce7317:


    "Estamos ocupados trabajando en nuestra tarea."


translate english e2201_f75f2233:



    voice "voice/e22/0100020a01.opus"
    mx "\"Hey, Shinichi? About this question—\""


translate english e2201_4bdff2ba:


    xy "\"Hmm? Oh, that one?\""


translate english e2201_552e3179:


    "A primera vista, Miyuki parece haber dominado todas las materias escolares—"


translate english e2201_fd49f764:


    "—pero en verdad, tiene una debilidad: biología."


translate english e2201_1b81dccb:


    "—pero en verdad, tiene una debilidad: física."


translate english e2201_1f8b5812:


    "—pero en verdad, tiene una debilidad: química."


translate english e2201_3937fb3d:


    "Así que la estoy ayudando."


translate english e2201_7a1959c9:


    xy "\"For this one, THIS goes in HERE, and then you substitute THAT—\""


translate english e2201_fa5bcc24:



    voice "voice/e22/0100030a01.opus"
    mx "\"Huh...? Ohhh, I get it!\""


translate english e2201_5e894d97:


    "Siempre he sido un maestro bastante bueno."


translate english e2201_6b625912:


    "Con mi guía, Miyuki resuelve el problema en un instante."


translate english e2201_80935eb2:


    "Scritch, scritch, scritch..."


translate english e2201_31dde6cb:


    "Nuestras plumas vuelan sobre el papel."


translate english e2201_c7d66381:


    "Puedo sentir su aliento desde el otro lado de la mesa."


translate english e2201_f1dc1b1b:



    voice "voice/e22/0100040a01.opus"
    mx "\"I wish this moment would last forever...\""


translate english e2201_67dff208:


    xy "\"Hmm?\""


translate english e2201_a82b31b0:



    voice "voice/e22/0100050a01.opus"
    mx "\"Oh, nothing.\""


translate english e2201_568762a7:



    voice "voice/e22/0100060a01.opus"
    mx "\"Just felt like saying it.\""


translate english e2201_8d1bcc7d:


    xy "\"Try to focus, alright?\""


translate english e2201_51567b57:



    voice "voice/e22/0100070a01.opus"
    mx "\"I know, I know.\""


translate english e2201_63ae7d8d:


    "Me lanza una sonrisa culpable mientras su pluma se detiene."


translate english e2201_43ff1a0e:



    voice "voice/e22/0100080a01.opus"
    mx "\"I need to concentrate a bit harder...\""


translate english e2201_fcbed1c7:



    voice "voice/e22/0100090a01.opus"
    mx "\"Time for something sugary!\""


translate english e2201_590058a1:


    "Así que ESO es lo que busca..."


translate english e2201_f1f97bc3:


    "Mientras salta a sus pies—"


translate english e2201_95150941:


    xy "\"Hmm...?\""


translate english e2201_07cd38a7:


    "—su teléfono se cae de su bolsillo."


translate english e2201_0accd139:


    xy "\"\"......\"\""


translate english e2201_912e2723:


    "Miro en silencio hacia el comedor."


translate english e2201_9cc7778a:


    "Aparentemente se detuvo en el baño de camino a la cocina."


translate english e2201_4c2a89f6:


    "Parece que estará fuera un rato..."


translate english strings:


    old "Оставить её телефон в покое"
    new "Dejar su teléfono en paz"


    old "Начать играться с ним"
    new "Hurgar en él"




translate english e2201_12e64a21:


    xy "\"......\""


translate english e2201_9cdb5716:



    voice "voice/e22/0100010a01.opus"
    mx "\"......\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
