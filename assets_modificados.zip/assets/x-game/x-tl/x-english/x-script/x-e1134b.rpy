

translate english e1134b_a05ecfde:


    xy "\"¡Perdón, Miyuki! ¡Hasta luego!\""


translate english e1134b_2fffc713:


    "Agarro la mano de Yuutarou y empiezo a correr."


translate english e1134b_c9eb3e9e:



    voice "voice/e11/34b00010a01.opus"
    mx "\"¡¿Qué demonios, Shinichi?!\""


translate english e1134b_829159b1:



    voice "voice/e11/34b00020b01.opus"
    xtl "\"¡Guau! ¡No me arrastres, amigo!\""


translate english e1134b_46129a36:


    xy "\"¡Solo ven conmigo!\""


translate english e1134b_59cf37d3:


    "Los dos salimos disparados como alma que lleva el diablo."


translate english e1134b_c62c4019:


    "Pero Miyuki no nos persigue."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
