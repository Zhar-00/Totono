

translate english c4181_19db7d3f:



    voice "voice/c41/8100010b01.opus"
    xtl "\"¡Vamos a encontrar esos sueños!\""


translate english c4181_b130439c:


    "...Aparentemente Yuutarou decidió cambiarse de ropa para esto."


translate english c4181_b16428c0:


    "Supongo que quiere llevar su entusiasmo en la manga... literalmente."


translate english c4181_214edba8:


    xy "\"Entonces, ¿cuál es el plan? Deberíamos idear algo—\""


translate english c4181_a135263e:



    voice "voice/c41/8100020b01.opus"
    xtl "\"¡O podemos improvisar!\""


translate english c4181_5a23c62a:


    "Akebono Yuutarou, el campeón de improvisar."


translate english c4181_7bb85c16:


    "Y vaya que improvisamos."


translate english c4181_afd3793c:


    "En algún punto durante la búsqueda, se distrae con una chica bonita en la calle y decide seguirla..."


translate english c4181_0cdcb4fc:


    "Luego tomamos un descanso y pasamos el rato en las jaulas de bateo..."


translate english c4181_e9b3114d:


    "Luego nos persigue un perro callejero al azar..."


translate english c4181_db68ebba:


    "Luego, cuando intentamos preguntar por Aoi, la gente cree que estamos coqueteando con ellos..."


translate english c4181_a48101bd:


    "Luego la señora mayor de la tienda de tabaco nos coquetea con las pestañas..."


translate english c4181_8a8053fd:


    "Luego seguimos nuestros sueños hasta la tienda para adultos..."


translate english c4181_94592252:


    xy "\"¿De verdad algo de esto nos va a ayudar a encontrarla...?\""


translate english c4181_13d54e15:



    voice "voice/c41/8100030b01.opus"
    xtl "\"De todos modos, no es como si de verdad quisieras encontrarla.\""


translate english c4181_545367b3:


    xy "\"...¿Qué?\""


translate english c4181_0cccd35f:



    voice "voice/c41/8100040b01.opus"
    xtl "\"Te alegra que Mukou se haya ido, ¿verdad?\""


translate english c4181_3e5295ad:


    xy "\"...¡Claro que no!\""


translate english c4181_1e1e3e88:



    voice "voice/c41/8100050b01.opus"
    xtl "\"¿Preferirías aclarar las cosas arriesgándote a herir a alguien...\""


translate english c4181_14ddaf7f:



    voice "voice/c41/8100060b01.opus"
    xtl "\"...o dejar las cosas vagas y salir corriendo?\""


translate english c4181_e383b516:



    voice "voice/c41/8100070b01.opus"
    xtl "\"¿Cuál es tu respuesta típica?\""


translate english c4181_0accd139:


    xy "\"......\""


translate english c4181_2d71cfbb:


    "Pasamos cada día después de eso deambulando por el pueblo."


translate english c4181_92d8e303:


    "Cada día, pensábamos en lugares a los que Aoi podría ir."


translate english c4181_03b93188:


    "Cada día, me preguntaba... ¿Dónde estás ahora? ¿Qué estás haciendo? ¿En qué estás pensando?"


translate english c4181_5d5268fc:


    "Pasaba sus noches en un café de manga..."


translate english c4181_aaed3eed:


    "...pero nunca explicó por qué se negaba a ir a casa."


translate english c4181_c7f84b7e:


    "Evitaba a sus padres..."


translate english c4181_c2d09000:


    "...pero nunca me dijo por qué le hacían la vida tan difícil."


translate english c4181_d5ab5270:


    "Normalmente nunca dejaba mostrar sus emociones..."


translate english c4181_5cd663e1:


    "...pero nunca supe qué la hacía ocultarlas."


translate english c4181_6bc30fa1:


    "A menudo mezclaba la ficción con la realidad..."


translate english c4181_6743ded0:


    "...pero nunca podía estar seguro de si hablaba en serio."


translate english c4181_e4a3dff6:


    "She believed that \"God\"hizo nuestro mundo como un videojuego..."


translate english c4181_c89cc705:


    "...pero no sé qué la llevó a esa conclusión, para empezar."


translate english c4181_0f7effef:


    "Y ahora que se ha ido..."


translate english c4181_686f4fd7:


    "...por fin me doy cuenta de lo poco que realmente sabía de ella."


translate english c4181_79d01174:


    xy "\"Oye, Eru.\""


translate english c4181_65a5697d:


    xy "\"Eres un gato transceptor, ¿verdad?\""


translate english c4181_3ec798a3:


    xy "\"Lo que significa que puedes detectar la señal de Aoi, ¿verdad?\""


translate english c4181_07c138e1:


    xy "\"¿Podrías llevarme con ella?\""


translate english c4181_faefae3b:


    "Pero Eru me ignora."


translate english c4181_fd2da598:


    "No puedo captar señales por mi cuenta."


translate english c4181_ceca69da:


    "Y no puedo comunicarme con ella por teléfono."


translate english c4181_8a1634aa:


    "Lo único que puedo hacer es buscarla de la única forma que sé."


translate english c4181_11515aa0:


    "Mientras miro al cielo nocturno, recuerdo."


translate english c4181_5f4f4d70:


    "Las cosas en las que se fijó cuando visitamos Catnip..."


translate english c4181_48e38869:


    "La forma en que lamió su helado de Kurakami Electronics..."


translate english c4181_16251349:


    "Cómo solía abrir sus bolsas de papas fritas..."


translate english c4181_27a5954c:


    "Los sabores que más le gustaban..."


translate english c4181_cf9b42f0:


    "El camino que eligió de camino a la tienda de la esquina..."


translate english c4181_93701275:


    "Cómo actuaba cada vez que veíamos un perro..."


translate english c4181_a46fe6d6:


    "De qué lado de la acera elegía caminar..."


translate english c4181_2d34599e:


    "Cómo bajaba las escaleras..."


translate english c4181_9993c12e:


    "Cómo cargaba su mochila..."


translate english c4181_6f2440ea:


    "Qué zapato se ponía primero..."


translate english c4181_4ebe11b8:


    "Cómo parpadeaba hacia mí..."


translate english c4181_2e89371b:


    "Cómo nos miraba a Miyuki y a mí..."


translate english c4181_7c096900:


    "Cada leve movimiento..."


translate english c4181_8d2af9a9:


    "Cada respiración..."


translate english c4181_5e4b4fc2:


    "Todos se agolpan vívidamente al frente de mi mente."


translate english c4181_367beac6:


    "Estos recuerdos son tan importantes para mí... y me niego a dejarlos ir."


translate english c4181_87cbfb17:



    voice "voice/c41/8100090b01.opus"
    xtl "\"Siempre pensé que Mukou era algo así como un maniquí.\""


translate english c4181_cc361ab8:



    voice "voice/c41/8100100b01.opus"
    xtl "\"Pero... en algún momento...\""


translate english c4181_c07384d5:



    voice "voice/c41/8100110b01.opus"
    xtl "\"En algún momento, empecé a pensar...\""


translate english c4181_15871e5d:



    voice "voice/c41/8100120b01.opus"
    xtl "\"...que tal vez siente dolor como el resto de nosotros.\""


translate english c4181_bdb58cfb:


    "Yuutarou se recuesta contra la máquina expendedora mientras habla."


translate english c4181_1f2ad44c:


    "A pesar de todo su comportamiento insoportable, en el fondo, de verdad le importa."


translate english c4181_6e639b34:


    xy "\"Gracias por pasar tu fin de semana ayudándome con esto.\""


translate english c4181_6c772cef:


    xy "\"Después de tanto caminar, creo que ya entendí cómo me siento.\""


translate english c4181_9bb2cbfe:



    voice "voice/c41/8100130b01.opus"
    xtl "\"¡Jajaja! ¡Pero por supuesto, mi buen señor!\""


translate english c4181_64d96632:



    voice "voice/c41/8100140b01.opus"
    xtl "\"¡Solo llámame el Evangelista de los Sueños!!!\""


translate english c4181_0bae7c48:


    "...Sí, no te voy a llamar así."


translate english c4181_ec971081:


    xy "\"Oh, perdón. Un segundo.\""


translate english c4181_0ecf3163:


    "Saco mi teléfono."


translate english c4181_2eb7028b:


    "Hay un correo de Miyuki en mi bandeja de entrada."


translate english c4181_30db2cfd:


    "Dice..."


translate english c4181_2a2909be:


    "—¿Estás ocupado más tarde?"


translate english c4181_ba461e0b:


    "—Necesito hablar contigo."


translate english c4181_61265481:


    "—Por favor pasa por las jaulas de bateo esta noche."


translate english c4181_99c01cae:


    "—Es importante."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
