

translate english e1155f_e7486e67:



    voice "voice/e11/55f00010a01.opus"
    mx "\"Come on... Don't be like that...\""


translate english e1155f_5524762d:



    voice "voice/e11/55f00020a01.opus"
    mx "Solo... ¡BÉSAME DE UNA VEZ...!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
