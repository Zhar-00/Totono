

translate english e1132b_2e320a4c:


    xy "\"Ah hade hoo...\""


translate english e1132b_8b488efc:



    voice "voice/e11/32b00010a01.opus"
    mx "\"Perdón, ¿qué dijiste?\""


translate english e1132b_adf3a1b2:


    "El metal frío presiona contra mi piel."


translate english e1132b_951ed467:


    "Algo gotea por mi cuello..."


translate english e1132b_13de3b32:



    voice "voice/e11/32b00020a01.opus"
    mx "\"Te lo preguntaré otra vez.\""


translate english e1132b_2e4cc852:



    voice "voice/e11/32b00030a01.opus"
    mx "\"¿Me amas?\""


translate english e1132b_45cba4d6:


    xy "\"¡S-Sí! ¡Claro!\""


translate english e1132b_8c37032c:


    "Mi grito hace ondear la toalla."


translate english e1132b_5a2c2fc5:


    xy "\"Solo estaba bromeando sobre—\""


translate english e1132b_ddbc5b57:



    voice "voice/e11/32b00040a01.opus"
    mx "\"Lo sé.\""


translate english e1132b_1d148ea6:



    voice "voice/e11/32b00050a01.opus"
    mx "\"Sin importar cómo se sientan los demás, mientras estés en este mundo conmigo, me amarás.\""


translate english e1132b_cc6e3cda:



    voice "voice/e11/32b00060a01.opus"
    mx "\"Así se supone que es. Sería raro si no.\""


translate english e1132b_881573e5:



    voice "voice/e11/32b00070a01.opus"
    mx "\"Suponiendo que no reprograme el juego, claro.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
