

translate english e1132b_2e320a4c:


    xy "\"Ah hade hoo...\""


translate english e1132b_8b488efc:



    voice "voice/e11/32b00010a01.opus"
    mx "\"Sorry, what was that?\""


translate english e1132b_adf3a1b2:


    "El metal frío presiona contra mi piel."


translate english e1132b_951ed467:


    "Algo gotea por mi cuello..."


translate english e1132b_13de3b32:



    voice "voice/e11/32b00020a01.opus"
    mx "\"I'll ask you again.\""


translate english e1132b_2e4cc852:



    voice "voice/e11/32b00030a01.opus"
    mx "\"Do you love me?\""


translate english e1132b_45cba4d6:


    xy "\"Y-Yes! Of course!\""


translate english e1132b_8c37032c:


    "Mi grito hace ondear la toalla."


translate english e1132b_5a2c2fc5:


    xy "\"I was just joking about—\""


translate english e1132b_ddbc5b57:



    voice "voice/e11/32b00040a01.opus"
    mx "\"I know.\""


translate english e1132b_1d148ea6:



    voice "voice/e11/32b00050a01.opus"
    mx "\"No matter how anyone else feels, as long as you're in this world with me, you will love me.\""


translate english e1132b_cc6e3cda:



    voice "voice/e11/32b00060a01.opus"
    mx "\"That's how it's supposed to be. It would be strange otherwise.\""


translate english e1132b_881573e5:



    voice "voice/e11/32b00070a01.opus"
    mx "\"Assuming I don't reprogram the game, of course.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
