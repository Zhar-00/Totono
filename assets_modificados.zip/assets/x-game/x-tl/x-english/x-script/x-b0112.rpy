

translate english b0112_6f373657:


    xy "\"Hmmm?\""


translate english b0112_af76426d:


    "Miro hacia abajo."


translate english b0112_ab3a5f8d:


    "Hay un teléfono celular tirado boca abajo en el suelo junto a la puerta."


translate english b0112_bf09c9d9:


    "¿De quién es esto?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
