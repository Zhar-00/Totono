

translate english a1171_f3a93c14:


    xy "\"Ay, hombre, ¿está lloviendo?\""


translate english a1171_ea15be6d:


    "Estaba ocupado haciendo la tarea en la biblioteca, para variar, así que no lo había notado hasta ahora."


translate english a1171_ba1ed975:


    "No hay luces encendidas en el viejo edificio del gimnasio donde se realizan los ensayos del club de teatro."


translate english a1171_ca415305:


    "Seguro que todos ya se fueron a casa por hoy."


translate english a1171_743d5d6b:


    "Bajo mi fiel paraguas, salgo a la fría lluvia otoñal y me dirijo a las rejas de la escuela."


translate english a1171_ac881a5e:



    voice "voice/a11/7100010a02.opus"
    aoi "\"\"\"\"......\"\"\"\""


translate english a1171_1653e129:


    "Justo entonces, diviso una figura solitaria cerca de la reja del campus, sin paraguas a la vista."


translate english a1171_d53d7abc:


    xy "\"¿Aoi...?\""


translate english a1171_b46c2b71:



    voice "voice/a11/7100020a02.opus"
    aoi "\"\"\"\"......\"\"\"\""


translate english a1171_60c53295:


    "Aoi permanece perfectamente quieta mientras la lluvia la empapa de pies a cabeza."


translate english a1171_e6a2bdd4:


    "Mira al vacío, igual que siempre lo hace en clase."


translate english a1171_6634b686:


    "Ni siquiera parpadea."


translate english a1171_293521d4:


    xy "\"¡Aoi! ¡HEY! ¡AOI!\""


translate english a1171_9343803a:



    voice "voice/a11/7100030a02.opus"
    aoi "\"¿Bip bip...?\""


translate english a1171_0119782c:



    voice "voice/a11/7100040a02.opus"
    aoi "\"¿Shinichi?\""


translate english a1171_f49ee071:


    "Aoi voltea a mirarme mientras sostengo mi paraguas sobre su cabeza."


translate english a1171_2a888d18:


    xy "\"¡Vas a resfriarte aquí afuera!\""


translate english a1171_18c9ed6e:



    voice "voice/a11/7100050a02.opus"
    aoi "\"¿Un resfriado?\""


translate english a1171_19a4610e:


    xy "\"No puedes simplemente quedarte parada bajo la lluvia así—\""


translate english a1171_9e960b84:



    voice "voice/a11/7100060a02.opus"
    aoi "\"¡Oh!\""


translate english a1171_43f29cad:



    voice "voice/a11/7100070a02.opus"
    aoi "\"Tienes razón. Está lloviendo.\""


translate english a1171_84a14f7b:


    "Al parecer no se había dado cuenta."


translate english a1171_359d3816:


    xy "\"En fin, tenemos que meterte antes de que—\""


translate english a1171_0eb351c8:



    voice "voice/a11/7100080a02.opus"
    aoi "\"No te preocupes.\""


translate english a1171_88a5dd4a:



    voice "voice/a11/7100090a02.opus"
    aoi "\"No hay CG de evento para que Aoi se enferme.\""


translate english a1171_0f8ce698:


    xy "\"Eh... Cierto...\""


translate english a1171_7b39d626:


    "Ahí está de nuevo ese cerebro gamer."


translate english a1171_83fa2d46:


    xy "\"Ten. Solo toma el paraguas.\""


translate english a1171_bb6de2d1:



    voice "voice/a11/7100100a02.opus"
    aoi "\"¿Estás tratando de jugar la ruta de Aoi?\""


translate english a1171_2129d286:


    xy "\"¡No, ok? ¡Solo tómalo!\""


translate english a1171_be045480:


    "Soy demasiado cobarde para compartir un paraguas con una chica."


translate english a1171_361bdac0:


    "En vez de eso, saco un paraguas plegable de mi mochila."


translate english a1171_a03212ef:


    xy "\"¿Ves? Tengo uno de repuesto.\""


translate english a1171_578dfd75:



    voice "voice/a11/7100110a02.opus"
    aoi "\"No deberías perder el tiempo subiendo mis puntos de afecto—\""


translate english a1171_87724d55:


    xy "\"¡Dije que no!\""


translate english a1171_16806582:


    xy "\"Te estoy ayudando porque eres mi AMIGO.\""


translate english a1171_c109e804:



    voice "voice/a11/7100120a02.opus"
    aoi "\"Amigo...\""


translate english a1171_a5b1754e:


    "Aoi reflexiona sobre la palabra por un momento."


translate english a1171_dfeef33f:


    "Luego, por fin, toma el paraguas."


translate english a1171_8fd33d82:



    voice "voice/a11/7100130a02.opus"
    aoi "\"Oh...\""


translate english a1171_5f7a5a5c:



    voice "voice/a11/7100140a02.opus"
    aoi "\"Está seco aquí abajo.\""


translate english a1171_006a9ffa:


    xy "\"Así funcionan los paraguas, genio.\""


translate english a1171_ef7c36cb:


    "Vamos, no es como si NUNCA hubieras usado un paraguas an—"


translate english a1171_6c152e53:


    "........"



translate english a1171_05e922a1:


    "Dios, en serio que nunca lo ha hecho, ¿verdad?"


translate english a1171_f85d65d8:



    voice "voice/a11/7100150a02.opus"
    aoi "\"Bip bip... bip bip bip...\""


translate english a1171_5227fe45:



    voice "voice/a11/7100160a02.opus"
    aoi "\"¡Oh! ¡Entendido!\""


translate english a1171_f5f957b4:


    xy "\"¿Hmm? ¿Qué pasa?\""


translate english a1171_d2b23743:



    voice "voice/a11/7100170a02.opus"
    aoi "\"En momentos como estos, dices...\""


translate english a1171_b447839b:



    voice "voice/a11/7100180a02.opus"
    aoi "\"¡Gracias!\""


translate english a1171_14ea5d4a:


    xy "\"¿Eh...?\""


translate english a1171_caa76896:



    voice "voice/a11/7100190a02.opus"
    aoi "\"Bip bip... bip bip bip...\""


translate english a1171_dbd6e905:



    voice "voice/a11/7100200a02.opus"
    aoi "\"¿Aoi se equivocó?\""


translate english a1171_89bf7f58:


    xy "\"No, no, tienes razón.\""


translate english a1171_21091835:


    "No esperaba que de verdad me diera las gracias."


translate english a1171_4f60cde9:


    "Aunque, también se disculpó con Miyuki por lo de ayer, así que quizá la estoy subestimando."


translate english a1171_2b3df490:


    "Me volteo para encararla."


translate english a1171_61cdc7f1:


    xy "\"De nada.\""


translate english a1171_69bc340a:



    voice "voice/a11/7100210a02.opus"
    aoi "\"Shinichi, si eres mi amigo...\""


translate english a1171_5fb09665:



    voice "voice/a11/7100220a02.opus"
    aoi "\"Entonces los amigos deberían caminar a casa juntos.\""


translate english a1171_0fbd010b:



    voice "voice/a11/7100230a02.opus"
    aoi "\"¿Podemos?\""


translate english a1171_da597577:


    "Si me hubieras dicho hace una semana que estaría caminando a casa con una chica de mi clase, la infame excéntrica Aoi, para ser exactos, me habría reído en tu cara."


translate english a1171_2a9ee311:


    "Y sin embargo aquí estoy, haciendo exactamente eso."


translate english a1171_11059719:


    xy "\"Sabes, los amigos también deberían responder sus correos. Solo digo.\""


translate english a1171_fd8754f4:



    voice "voice/a11/7100240a02.opus"
    aoi "\"¿Me escribiste?\""


translate english a1171_42b71b08:


    xy "\"También te llamé.\""


translate english a1171_e50d4dd0:



    voice "voice/a11/7100250a02.opus"
    aoi "\"\"\"\"......\"\"\"\""


translate english a1171_79f82823:


    "Aoi saca silenciosamente su teléfono del bolsillo."


translate english a1171_2cc46d2a:



    voice "voice/a11/7100260a02.opus"
    aoi "\"Sin señal.\""


translate english a1171_6d56d3a8:


    xy "\"¿Quizás tu teléfono está roto?\""


translate english a1171_bac6055d:



    voice "voice/a11/7100270a02.opus"
    aoi "\"La señal de Dios no funciona como las demás.\""


translate english a1171_6a1ccb4e:



    voice "voice/a11/7100280a02.opus"
    aoi "\"No la recibe sin suficiente batería.\""


translate english a1171_9f19c1a5:


    "Apparently that's her explanation for why \"God\"no contesta sus llamadas."


translate english a1171_12fa1984:


    xy "\"Tiene que estar roto. Deberías comprar uno nuevo—\""


translate english a1171_bb7c35da:



    voice "voice/a11/7100290a02.opus"
    aoi "\"¡No!\""


translate english a1171_ff78950a:


    xy "\"¿Por qué no? ¿Este tiene valor sentimental o algo así?\""


translate english a1171_f9b4667b:



    voice "voice/a11/7100300a02.opus"
    aoi "\"Sí.\""


translate english a1171_d67fd474:



    voice "voice/a11/7100310a02.opus"
    aoi "\"Es mi única forma de contactar a Dios.\""


translate english a1171_8cac0905:


    "There she goes about \"God\"otra vez..."


translate english a1171_68941e0a:


    xy "\"Entonces, ¿quién es este \"Dios\"? ¿Un amigo tuyo?\""


translate english a1171_0fb00de8:



    voice "voice/a11/7100320a02.opus"
    aoi "\"Dios es solo... Dios.\""


translate english a1171_2e97468e:



    voice "voice/a11/7100330a02.opus"
    aoi "\"Muy poderoso.\""


translate english a1171_dab04d77:



    voice "voice/a11/7100340a02.opus"
    aoi "\"Dios es la persona que hizo a Aoi.\""


translate english a1171_ee6188a8:


    xy "\"Oh, ya veo.\""


translate english a1171_feddc038:


    "Mmmm..."


translate english a1171_653d114c:


    "¿Podría estar refiriéndose a uno de sus padres?"


translate english a1171_25291ca4:


    "De alguna forma lo dudo..."


translate english a1171_15a9297a:



    voice "voice/a11/7100350a02.opus"
    aoi "\"Pero... sí intercambiamos correos.\""


translate english a1171_3d8eabf9:



    voice "voice/a11/7100360a02.opus"
    aoi "\"¿Eso... nos hace amigos?\""


translate english a1171_093d499b:


    xy "\"Sí, yo diría que sí.\""


translate english a1171_4b9cc4a2:


    "Recuerdo que tuvimos esta misma conversación el otro día."


translate english a1171_8776e7e8:



    voice "voice/a11/7100370a02.opus"
    aoi "\"¿Y Miyuki?\""


translate english a1171_91d75ea4:



    voice "voice/a11/7100380a02.opus"
    aoi "\"Aún no hemos intercambiado.\""


translate english a1171_9d3d4e82:



    voice "voice/a11/7100390a02.opus"
    aoi "\"Entonces no somos... ¿amigas?\""


translate english a1171_4ed51bde:


    "Aoi sigue mirando al vacío sin ver nada mientras la lluvia cae a cántaros."


translate english a1171_399d16ba:


    "Miyuki sabía que Aoi la estaría esperando después del ensayo."


translate english a1171_3576a4cf:


    "¿Se habrán cruzado sin darse cuenta?"


translate english a1171_3f0867c5:


    "¿O... Miyuki...?"


translate english a1171_2ee67072:



    voice "voice/a11/7100400a02.opus"
    aoi "\"Aoi quiere intercambiar con ella.\""


translate english a1171_8e03b61e:



    voice "voice/a11/7100410a02.opus"
    aoi "\"Aoi quiere ser su amiga.\""


translate english a1171_0accd139:


    xy "\"\"\"\"......\"\"\"\""


translate english a1171_722d172c:


    "Si al menos supiera la dirección de correo de Miyuki... Entonces podría dársela yo mismo a Aoi."


translate english a1171_b17ef61e:


    "Pero no he sido tan cercano a Miyuki desde hace mucho, mucho tiempo."


translate english a1171_810a2c80:


    "Y a estas alturas, nunca puedo esperar volver a serlo."


translate english a1171_e516be7a:


    "All we can do now is pray. To \"God,\"supongo."


translate english a1171_1f430024:


    xy "\"¿Vives por aquí?\""


translate english a1171_9d9b9f3a:



    voice "voice/a11/7100420a02.opus"
    aoi "\"Aoi no vive en ningún lado.\""


translate english a1171_d9315e90:


    xy "\"¿Qué?\""


translate english a1171_0b226193:



    voice "voice/a11/7100430a02.opus"
    aoi "\"Aoi duerme ahí.\""


translate english a1171_7494b0d7:


    "Señala un edificio en las afueras de la zona comercial: el único manga café de la ciudad."


translate english a1171_2647330a:


    xy "\"¿No te llevas bien con tu familia?\""


translate english a1171_b3f3399b:



    voice "voice/a11/7100440a02.opus"
    aoi "\"Nop.\""


translate english a1171_e96bf3d2:


    xy "\"No es seguro andar sola por las calles, ¿sabes?\""


translate english a1171_169bd951:



    voice "voice/a11/7100450a02.opus"
    aoi "\"Aoi está acostumbrada.\""


translate english a1171_513e67f1:


    xy "\"¿Y qué? Eso no quita que—\""


translate english a1171_a4709682:



    voice "voice/a11/7100460a02.opus"
    aoi "\"Además, ahí tienen computadoras y juegos.\""


translate english a1171_5a77638c:



    voice "voice/a11/7100470a02.opus"
    aoi "\"Y botanas deliciosas.\""


translate english a1171_22abcfa2:



    voice "voice/a11/7100480a02.opus"
    aoi "\"Y toda la soda que Aoi quiera.\""


translate english a1171_5391c022:



    voice "voice/a11/7100490a02.opus"
    aoi "\"Y sin toque de queda.\""


translate english a1171_d8dbc755:



    voice "voice/a11/7100500a02.opus"
    aoi "\"Es el paraíso.\""


translate english a1171_0accd139_1:


    xy "\"\"\"\"......\"\"\"\""


translate english a1171_5dae25dd:


    "Me quedo totalmente sin palabras."


translate english a1171_1be689df:



    voice "voice/a11/7100510a02.opus"
    aoi "\"Gracias por el paraguas.\""


translate english a1171_de45f305:



    voice "voice/a11/7100520a02.opus"
    aoi "\"Adiós.\""


translate english a1171_d858a638:


    xy "\"D-De nada... Cuídate, ¿está bien?\""


translate english a1171_ea043994:


    "Aoi entra tambaleándose al manga café y desaparece de la vista."


translate english a1171_e1c23081:


    "En cuanto a mí, me quedo mirando distraídamente tras ella hasta que el repiqueteo de la lluvia ahoga todo a mi alrededor."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
