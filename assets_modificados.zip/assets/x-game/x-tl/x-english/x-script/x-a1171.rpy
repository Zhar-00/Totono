

translate english a1171_f3a93c14:


    xy "\"Aw, man, it's raining?\""


translate english a1171_ea15be6d:


    "Estaba ocupado haciendo la tarea en la biblioteca, para variar, así que no lo había notado hasta ahora."


translate english a1171_ba1ed975:


    "No hay luces encendidas en el viejo edificio del gimnasio donde se realizan los ensayos del club de teatro."


translate english a1171_ca415305:


    "Seguro que todos ya se fueron a casa por hoy."


translate english a1171_743d5d6b:


    "Bajo mi fiel paraguas, salgo a la fría lluvia otoñal y me dirijo a las rejas de la escuela."


translate english a1171_ac881a5e:



    voice "voice/a11/7100010a02.opus"
    aoi "\"\"\"\"......\"\"\"\""


translate english a1171_1653e129:


    "Justo entonces, diviso una figura solitaria cerca de la reja del campus, sin paraguas a la vista."


translate english a1171_d53d7abc:


    xy "\"Aoi...?\""


translate english a1171_b46c2b71:



    voice "voice/a11/7100020a02.opus"
    aoi "\"\"\"\"......\"\"\"\""


translate english a1171_60c53295:


    "Aoi permanece perfectamente quieta mientras la lluvia la empapa de pies a cabeza."


translate english a1171_e6a2bdd4:


    "Mira al vacío, igual que siempre lo hace en clase."


translate english a1171_6634b686:


    "Ni siquiera parpadea."


translate english a1171_293521d4:


    xy "\"Aoi! HEY! AOI!\""


translate english a1171_9343803a:



    voice "voice/a11/7100030a02.opus"
    aoi "\"Boop boop...?\""


translate english a1171_0119782c:



    voice "voice/a11/7100040a02.opus"
    aoi "\"Shinichi?\""


translate english a1171_f49ee071:


    "Aoi voltea a mirarme mientras sostengo mi paraguas sobre su cabeza."


translate english a1171_2a888d18:


    xy "\"You're gonna catch a cold out here!\""


translate english a1171_18c9ed6e:



    voice "voice/a11/7100050a02.opus"
    aoi "\"A cold?\""


translate english a1171_19a4610e:


    xy "\"You can't just stand out in the rain like th—\""


translate english a1171_9e960b84:



    voice "voice/a11/7100060a02.opus"
    aoi "\"Oh!\""


translate english a1171_43f29cad:



    voice "voice/a11/7100070a02.opus"
    aoi "\"You're right. It's raining.\""


translate english a1171_84a14f7b:


    "Al parecer no se había dado cuenta."


translate english a1171_359d3816:


    xy "\"Anyway, we need to get you inside before—\""


translate english a1171_0eb351c8:



    voice "voice/a11/7100080a02.opus"
    aoi "\"Don't worry.\""


translate english a1171_88a5dd4a:



    voice "voice/a11/7100090a02.opus"
    aoi "\"There's no event CG for Aoi getting sick.\""


translate english a1171_0f8ce698:


    xy "\"Uh... Right...\""


translate english a1171_7b39d626:


    "Ahí está de nuevo ese cerebro gamer."


translate english a1171_83fa2d46:


    xy "\"Here. Just take the umbrella.\""


translate english a1171_bb6de2d1:



    voice "voice/a11/7100100a02.opus"
    aoi "\"Are you trying to play Aoi's route?\""


translate english a1171_2129d286:


    xy "\"No, okay? Just take it!\""


translate english a1171_be045480:


    "Soy demasiado cobarde para compartir un paraguas con una chica."


translate english a1171_361bdac0:


    "En vez de eso, saco un paraguas plegable de mi mochila."


translate english a1171_a03212ef:


    xy "\"See? I have a backup.\""


translate english a1171_578dfd75:



    voice "voice/a11/7100110a02.opus"
    aoi "\"You shouldn't waste time raising my affection points—\""


translate english a1171_87724d55:


    xy "\"I said I'm not!\""


translate english a1171_16806582:


    xy "\"I'm helping you because you're my FRIEND.\""


translate english a1171_c109e804:



    voice "voice/a11/7100120a02.opus"
    aoi "\"Friend...\""


translate english a1171_a5b1754e:


    "Aoi reflexiona sobre la palabra por un momento."


translate english a1171_dfeef33f:


    "Luego, por fin, toma el paraguas."


translate english a1171_8fd33d82:



    voice "voice/a11/7100130a02.opus"
    aoi "\"Oh...\""


translate english a1171_5f7a5a5c:



    voice "voice/a11/7100140a02.opus"
    aoi "\"It's dry under here.\""


translate english a1171_006a9ffa:


    xy "\"That's how umbrellas work, genius.\""


translate english a1171_ef7c36cb:


    "Vamos, no es como si NUNCA hubieras usado un paraguas an—"


translate english a1171_6c152e53:


    "........"



translate english a1171_05e922a1:


    "Dios, en serio que nunca lo ha hecho, ¿verdad?"


translate english a1171_f85d65d8:



    voice "voice/a11/7100150a02.opus"
    aoi "\"Boop boop... boop boop boop...\""


translate english a1171_5227fe45:



    voice "voice/a11/7100160a02.opus"
    aoi "\"Oh! Got it!\""


translate english a1171_f5f957b4:


    xy "\"Hmm? What's up?\""


translate english a1171_d2b23743:



    voice "voice/a11/7100170a02.opus"
    aoi "\"In times like these, you say...\""


translate english a1171_b447839b:



    voice "voice/a11/7100180a02.opus"
    aoi "\"Thank you!\""


translate english a1171_14ea5d4a:


    xy "\"Huh...?\""


translate english a1171_caa76896:



    voice "voice/a11/7100190a02.opus"
    aoi "\"Boop boop... boop boop boop...\""


translate english a1171_dbd6e905:



    voice "voice/a11/7100200a02.opus"
    aoi "\"Did Aoi get it wrong?\""


translate english a1171_89bf7f58:


    xy "\"No, no, you're right.\""


translate english a1171_21091835:


    "No esperaba que de verdad me diera las gracias."


translate english a1171_4f60cde9:


    "Aunque, también se disculpó con Miyuki por lo de ayer, así que quizá la estoy subestimando."


translate english a1171_2b3df490:


    "Me volteo para encararla."


translate english a1171_61cdc7f1:


    xy "\"You're very welcome.\""


translate english a1171_69bc340a:



    voice "voice/a11/7100210a02.opus"
    aoi "\"Shinichi, if you're my friend...\""


translate english a1171_5fb09665:



    voice "voice/a11/7100220a02.opus"
    aoi "\"Then friends should walk home together.\""


translate english a1171_0fbd010b:



    voice "voice/a11/7100230a02.opus"
    aoi "\"Can we?\""


translate english a1171_da597577:


    "Si me hubieras dicho hace una semana que estaría caminando a casa con una chica de mi clase, la infame excéntrica Aoi, para ser exactos, me habría reído en tu cara."


translate english a1171_2a9ee311:


    "Y sin embargo aquí estoy, haciendo exactamente eso."


translate english a1171_11059719:


    xy "\"Y'know, friends ought to reply to their emails, too. Just saying.\""


translate english a1171_fd8754f4:



    voice "voice/a11/7100240a02.opus"
    aoi "\"You wrote me?\""


translate english a1171_42b71b08:


    xy "\"Called you, too.\""


translate english a1171_e50d4dd0:



    voice "voice/a11/7100250a02.opus"
    aoi "\"\"\"\"......\"\"\"\""


translate english a1171_79f82823:


    "Aoi saca silenciosamente su teléfono del bolsillo."


translate english a1171_2cc46d2a:



    voice "voice/a11/7100260a02.opus"
    aoi "\"No service.\""


translate english a1171_6d56d3a8:


    xy "\"Maybe your phone's broken?\""


translate english a1171_bac6055d:



    voice "voice/a11/7100270a02.opus"
    aoi "\"God's signal doesn't work like the others.\""


translate english a1171_6a1ccb4e:



    voice "voice/a11/7100280a02.opus"
    aoi "\"It won't pick up without enough battery.\""


translate english a1171_9f19c1a5:


    "Apparently that's her explanation for why \"God\"no contesta sus llamadas."


translate english a1171_12fa1984:


    xy "\"It's gotta be broken. You should just buy a new—\""


translate english a1171_bb7c35da:



    voice "voice/a11/7100290a02.opus"
    aoi "\"No!\""


translate english a1171_ff78950a:


    xy "\"Why not? Does this one have sentimental value or something?\""


translate english a1171_f9b4667b:



    voice "voice/a11/7100300a02.opus"
    aoi "\"Yes.\""


translate english a1171_d67fd474:



    voice "voice/a11/7100310a02.opus"
    aoi "\"This is my only way of contacting God.\""


translate english a1171_8cac0905:


    "There she goes about \"God\"otra vez..."


translate english a1171_68941e0a:


    xy "\"So, who is this 'God,' anyway? A friend of yours?\""


translate english a1171_0fb00de8:



    voice "voice/a11/7100320a02.opus"
    aoi "\"God is just... God.\""


translate english a1171_2e97468e:



    voice "voice/a11/7100330a02.opus"
    aoi "\"Very powerful.\""


translate english a1171_dab04d77:



    voice "voice/a11/7100340a02.opus"
    aoi "\"God's the person who made Aoi.\""


translate english a1171_ee6188a8:


    xy "\"Oh, I see.\""


translate english a1171_feddc038:


    "Mmmm..."


translate english a1171_653d114c:


    "¿Podría estar refiriéndose a uno de sus padres?"


translate english a1171_25291ca4:


    "De alguna forma lo dudo..."


translate english a1171_15a9297a:



    voice "voice/a11/7100350a02.opus"
    aoi "\"But... we did trade email addresses.\""


translate english a1171_3d8eabf9:



    voice "voice/a11/7100360a02.opus"
    aoi "\"Does that... make us friends?\""


translate english a1171_093d499b:


    xy "\"Yeah, I'd say so.\""


translate english a1171_4b9cc4a2:


    "Recuerdo que tuvimos esta misma conversación el otro día."


translate english a1171_8776e7e8:



    voice "voice/a11/7100370a02.opus"
    aoi "\"What about Miyuki?\""


translate english a1171_91d75ea4:



    voice "voice/a11/7100380a02.opus"
    aoi "\"We haven't traded yet.\""


translate english a1171_9d3d4e82:



    voice "voice/a11/7100390a02.opus"
    aoi "\"So we're... not friends?\""


translate english a1171_4ed51bde:


    "Aoi sigue mirando al vacío sin ver nada mientras la lluvia cae a cántaros."


translate english a1171_399d16ba:


    "Miyuki sabía que Aoi la estaría esperando después del ensayo."


translate english a1171_3576a4cf:


    "¿Se habrán cruzado sin darse cuenta?"


translate english a1171_3f0867c5:


    "¿O... Miyuki...?"


translate english a1171_2ee67072:



    voice "voice/a11/7100400a02.opus"
    aoi "\"Aoi wants to trade with her.\""


translate english a1171_8e03b61e:



    voice "voice/a11/7100410a02.opus"
    aoi "\"Aoi wants to be friends with her.\""


translate english a1171_0accd139:


    xy "\"\"\"\"......\"\"\"\""


translate english a1171_722d172c:


    "Si al menos supiera la dirección de correo de Miyuki... Entonces podría dársela yo mismo a Aoi."


translate english a1171_b17ef61e:


    "Pero no he sido tan cercano a Miyuki desde hace mucho, mucho tiempo."


translate english a1171_810a2c80:


    "Y a estas alturas, nunca puedo esperar volver a serlo."


translate english a1171_e516be7a:


    "All we can do now is pray. To \"God,\"supongo."


translate english a1171_1f430024:


    xy "\"Do you live around here?\""


translate english a1171_9d9b9f3a:



    voice "voice/a11/7100420a02.opus"
    aoi "\"Aoi doesn't live anywhere.\""


translate english a1171_d9315e90:


    xy "\"What?\""


translate english a1171_0b226193:



    voice "voice/a11/7100430a02.opus"
    aoi "\"Aoi sleeps in there.\""


translate english a1171_7494b0d7:


    "Señala un edificio en las afueras de la zona comercial: el único manga café de la ciudad."


translate english a1171_2647330a:


    xy "\"Do you not get along with your family?\""


translate english a1171_b3f3399b:



    voice "voice/a11/7100440a02.opus"
    aoi "\"Nope.\""


translate english a1171_e96bf3d2:


    xy "\"It's not safe to roam the streets alone, you know.\""


translate english a1171_169bd951:



    voice "voice/a11/7100450a02.opus"
    aoi "\"Aoi is used to it.\""


translate english a1171_513e67f1:


    xy "\"So what? That still doesn't—\""


translate english a1171_a4709682:



    voice "voice/a11/7100460a02.opus"
    aoi "\"Besides, they have computers and games in there.\""


translate english a1171_5a77638c:



    voice "voice/a11/7100470a02.opus"
    aoi "\"And yummy snacks.\""


translate english a1171_22abcfa2:



    voice "voice/a11/7100480a02.opus"
    aoi "\"And as much soda as Aoi wants.\""


translate english a1171_5391c022:



    voice "voice/a11/7100490a02.opus"
    aoi "\"And no curfew.\""


translate english a1171_d8dbc755:



    voice "voice/a11/7100500a02.opus"
    aoi "\"It's heaven.\""


translate english a1171_0accd139_1:


    xy "\"\"\"\"......\"\"\"\""


translate english a1171_5dae25dd:


    "Me quedo totalmente sin palabras."


translate english a1171_1be689df:



    voice "voice/a11/7100510a02.opus"
    aoi "\"Thank you for the umbrella.\""


translate english a1171_de45f305:



    voice "voice/a11/7100520a02.opus"
    aoi "\"Bye-bye.\""


translate english a1171_d858a638:


    xy "\"N-No problem... Take care of yourself, alright?\""


translate english a1171_ea043994:


    "Aoi entra tambaleándose al manga café y desaparece de la vista."


translate english a1171_e1c23081:


    "En cuanto a mí, me quedo mirando distraídamente tras ella hasta que el repiqueteo de la lluvia ahoga todo a mi alrededor."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
