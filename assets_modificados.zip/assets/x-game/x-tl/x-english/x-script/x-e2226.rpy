

translate english e2226_f738c22d:


    xy "\"Let's go back to the way things were.\""


translate english e2226_96b83b8b:



    voice "voice/e22/2600010a01.opus"
    mx "\"What's that supposed to mean?\""


translate english e2226_545825eb:


    "En un parpadeo, la voz de Miyuki vuelve a la normalidad."


translate english e2226_c986b27d:


    xy "\"It's just... I want us to go back to our regular lives. It's better that way.\""


translate english e2226_dc8f7715:


    xy "\"I mean, I know you find that maid outfit degrading. So I'm cool with you wearing your normal cl—\""


translate english e2226_c01ff1b8:



    voice "voice/e22/2600020a01.opus"
    mx "\"I see.\""


translate english e2226_7fe1cf16:


    xy "\"Huh...?\""


translate english e2226_8f375939:


    xy "\"You didn't put it on after all...?\""


translate english e2226_ac339ea0:



    voice "voice/e22/2600030a01.opus"
    mx "\"If that's how you feel, then I won't force you.\""


translate english e2226_8eb44851:



    voice "voice/e22/2600040a01.opus"
    mx "\"You want to be stubborn? Knock yourself out.\""


translate english e2226_81b46fe6:


    xy "\"I'm not being stubborn—\""


translate english e2226_e48b4b63:



    voice "voice/e22/2600050a01.opus"
    mx "\"But you'll regret it. I promise you that.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
