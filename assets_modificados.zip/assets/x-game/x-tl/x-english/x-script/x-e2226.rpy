

translate english e2226_f738c22d:


    xy "\"Volvamos a como eran las cosas.\""


translate english e2226_96b83b8b:



    voice "voice/e22/2600010a01.opus"
    mx "\"¿Y eso qué significa?\""


translate english e2226_545825eb:


    "En un parpadeo, la voz de Miyuki vuelve a la normalidad."


translate english e2226_c986b27d:


    xy "\"Es que... quiero que volvamos a nuestras vidas normales. Es mejor así.\""


translate english e2226_dc8f7715:


    xy "\"Digo, sé que ese atuendo de sirvienta te parece degradante. Así que no me molesta que uses tu ropa nor—\""


translate english e2226_c01ff1b8:



    voice "voice/e22/2600020a01.opus"
    mx "\"Ya veo.\""


translate english e2226_7fe1cf16:


    xy "\"¿Eh...?\""


translate english e2226_8f375939:


    xy "\"¿Al final no te lo pusiste...?\""


translate english e2226_ac339ea0:



    voice "voice/e22/2600030a01.opus"
    mx "\"Si así lo sientes, entonces no te obligaré.\""


translate english e2226_8eb44851:



    voice "voice/e22/2600040a01.opus"
    mx "\"¿Quieres ponerte terco? Adelante.\""


translate english e2226_81b46fe6:


    xy "\"No me estoy poniendo terco—\""


translate english e2226_e48b4b63:



    voice "voice/e22/2600050a01.opus"
    mx "\"Pero te arrepentirás. Te lo prometo.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
