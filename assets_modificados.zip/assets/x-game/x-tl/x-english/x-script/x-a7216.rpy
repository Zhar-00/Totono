

translate english a7216_f5f32b14:



    voice "voice/a72/1600010a01.opus"
    mx "\"Oye, ¿Shinichi? Yo...\""


translate english a7216_955e0966:



    voice "voice/a72/1600020a01.opus"
    mx "\"De verdad estoy deseando pasar el resto de mi vida contigo.\""


translate english a7216_8c5a2927:


    "Su sonrisa es pura, como cuando éramos niños."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
