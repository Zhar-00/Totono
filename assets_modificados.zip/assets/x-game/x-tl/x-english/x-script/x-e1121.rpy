

translate english e1121_4d8a910d:



    voice "voice/e11/2100010a01.opus"
    mx "\"...Veamos.\""


translate english e1121_7f0f448e:



    voice "voice/e11/2100020a01.opus"
    mx "\"Primero, me gustaría ponerte a prueba.\""


translate english e1121_4853da55:


    xy "\"¿Ponerme a prueba cómo...?\""


translate english e1121_63b0d909:



    voice "voice/e11/2100030a01.opus"
    mx "\"Lo que pasa conmigo es que no me gustan los mentirosos. Así que...\""


translate english e1121_ff7a04f8:



    voice "voice/e11/2100040a01.opus"
    mx "\"Quiero que me digas lo que de verdad sientes.\""


translate english e1121_6e53b1ea:



    voice "voice/e11/2100050a01.opus"
    mx "\"Así que dime, Shinichi. Me amas, ¿verdad?\""


translate english e1121_2a1c47da:



    voice "voice/e11/2100060a01.opus"
    mx "\"¿Podrías declararme tu amor por toda la eternidad?\""


translate english strings:


    old "Да"
    new "Sí"


    old "Нет"
    new "No"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
