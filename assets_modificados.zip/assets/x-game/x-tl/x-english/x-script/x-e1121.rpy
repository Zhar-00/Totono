

translate english e1121_4d8a910d:



    voice "voice/e11/2100010a01.opus"
    mx "\"...Let's see.\""


translate english e1121_7f0f448e:



    voice "voice/e11/2100020a01.opus"
    mx "\"First, I'd like to test you.\""


translate english e1121_4853da55:


    xy "\"Test me how...?\""


translate english e1121_63b0d909:



    voice "voice/e11/2100030a01.opus"
    mx "\"The thing about me is, I don't like liars. So...\""


translate english e1121_ff7a04f8:



    voice "voice/e11/2100040a01.opus"
    mx "\"I want you to tell me how you truly feel.\""


translate english e1121_6e53b1ea:



    voice "voice/e11/2100050a01.opus"
    mx "\"So tell me, Shinichi. You love me, don't you?\""


translate english e1121_2a1c47da:



    voice "voice/e11/2100060a01.opus"
    mx "\"Could you profess your love to me for all eternity?\""


translate english strings:


    old "Да"
    new "Sí"


    old "Нет"
    new "No"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
