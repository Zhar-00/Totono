

translate english e2208a_82b7e44f:


    xy "\"Yeah.\""


translate english e2208a_c6fbee1d:


    xy "\"I saw the entry in the address book and got curious.\""


translate english e2208a_5561977b:



    voice "voice/e22/08a00010a01.opus"
    mx "\"...Hmmm...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
