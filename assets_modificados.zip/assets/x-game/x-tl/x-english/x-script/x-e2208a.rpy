

translate english e2208a_82b7e44f:


    xy "\"Sí.\""


translate english e2208a_c6fbee1d:


    xy "\"Vi la entrada en la agenda y me dio curiosidad.\""


translate english e2208a_5561977b:



    voice "voice/e22/08a00010a01.opus"
    mx "\"...Hmmm...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
