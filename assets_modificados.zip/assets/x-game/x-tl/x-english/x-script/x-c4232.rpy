

translate english c4232_a9818be4:


    xy "\"Aoi, hay algo que quiero decirte.\""


translate english c4232_6ca59fca:



    voice "voice/c42/3200010a02.opus"
    aoi "\"¿Bip bip...?\""


translate english c4232_1b2cafdd:


    "Me recuesto hacia atrás."


translate english c4232_cf714b8e:


    "El cielo estrellado llena mi visión."


translate english c4232_6c5c02d1:


    "Y con las luces del pueblo allá abajo, es difícil distinguir arriba de abajo."


translate english c4232_dab4dfeb:


    "Es casi como si estuviéramos suspendidos, sin peso, en el espacio."


translate english c4232_57717301:


    xy "\"De verdad me gustó el tiempo que pasamos juntos los tres.\""


translate english c4232_7c9546ae:


    xy "\"Luego, la noche que te quedaste en mi casa, de repente todo se volvió muy íntimo... y entré en pánico.\""


translate english c4232_c21cca71:


    xy "\"Tenía miedo de que fuera a destruir nuestra amistad.\""


translate english c4232_79ba7cdc:


    xy "\"Por eso dije que nunca serías nada más que una amiga para mí. En retrospectiva, fue algo realmente tonto de decir.\""


translate english c4232_9bd284bf:


    xy "\"¡De verdad, de verdad lo siento!\""


translate english c4232_44591afc:



    voice "voice/c42/3200020a02.opus"
    aoi "\"Shinichi...\""


translate english c4232_6b8432dc:


    xy "\"De todos modos todo era pura mierda.\""


translate english c4232_7a493060:


    xy "\"He pensado mucho, y...\""


translate english c4232_7fc743d6:


    xy "\"Aoi... No eres \"solo una amiga\" para—\""


translate english c4232_6f9d232c:



    voice "voice/c42/3200030a02.opus"
    aoi "\"¡Basta!\""


translate english c4232_df316181:


    "La palabra atraviesa mi corazón."


translate english c4232_1df000a4:



    voice "voice/c42/3200040a02.opus"
    aoi "\"Mi ruta es solo un error.\""


translate english c4232_c2a91765:



    voice "voice/c42/3200050a02.opus"
    aoi "\"Esa bandera de evento no se supone que se active.\""


translate english c4232_ee9a9190:


    xy "\"¿Tu sonrisa también fue un error?\""


translate english c4232_0fc11746:



    voice "voice/c42/3200060a02.opus"
    aoi "\"¿Mi sonrisa...?\""


translate english c4232_16ebb1a9:


    xy "\"¿Y tu felicidad? ¿También fue otro error?\""


translate english c4232_f7e0ec86:


    xy "\"¿Y tu tristeza? ¿Y tus lágrimas?\""


translate english c4232_eae6e3d8:


    xy "\"Te enamoraste, nos alejaste, y sufriste en soledad.\""


translate english c4232_bcb00824:


    xy "\"¿Esas emociones son todas solo errores y fallos también?\""


translate english c4232_74575cd6:


    xy "\"No soy un dios. No soy perfecto. A la mierda eso.\""


translate english c4232_1e2fcf11:


    xy "\"Risas, lágrimas, tristeza, alegría... Amor y odio...\""


translate english c4232_7edc6bc4:


    xy "\"Quiero sentir todas estas cosas, y quiero tenerte justo ahí conmigo.\""


translate english c4232_35354b68:


    "En el transcurso de buscar a Aoi, finalmente descubrí cómo me siento realmente."


translate english c4232_5170d695:


    "He estado muriendo por decírselo, todo este tiempo."


translate english c4232_7db1dd6c:


    "Esta es la razón por la que vine a buscarla."


translate english c4232_24d76ecf:


    xy "\"No me importa si no puedo estar con Miyuki... Solo quiero estar con—\""


translate english c4232_047991a8:



    voice "voice/c42/3200070a02.opus"
    aoi "\"Aoi tiene... un favor que pedirte.\""


translate english c4232_f0999f34:


    "Me interrumpe a mitad de la frase."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
