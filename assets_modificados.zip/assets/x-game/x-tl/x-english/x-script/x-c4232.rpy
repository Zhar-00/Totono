

translate english c4232_a9818be4:


    xy "\"Aoi, there's something I want to tell you.\""


translate english c4232_6ca59fca:



    voice "voice/c42/3200010a02.opus"
    aoi "\"Boop boop...?\""


translate english c4232_1b2cafdd:


    "Me recuesto hacia atrás."


translate english c4232_cf714b8e:


    "El cielo estrellado llena mi visión."


translate english c4232_6c5c02d1:


    "Y con las luces del pueblo allá abajo, es difícil distinguir arriba de abajo."


translate english c4232_dab4dfeb:


    "Es casi como si estuviéramos suspendidos, sin peso, en el espacio."


translate english c4232_57717301:


    xy "\"I really liked the time we spent together as a trio.\""


translate english c4232_7c9546ae:


    xy "\"Then, the night you crashed at my place, suddenly everything was up close and personal... and I panicked.\""


translate english c4232_c21cca71:


    xy "\"I was scared it was going to destroy our friendship.\""


translate english c4232_79ba7cdc:


    xy "\"Which is why I said you'd never be anything more than a friend to me. In hindsight, that was a really dumb thing to say.\""


translate english c4232_9bd284bf:


    xy "\"I'm really, really sorry!\""


translate english c4232_44591afc:



    voice "voice/c42/3200020a02.opus"
    aoi "\"Shinichi...\""


translate english c4232_6b8432dc:


    xy "\"It was total bullshit anyway.\""


translate english c4232_7a493060:


    xy "\"I've done a lot of thinking, and...\""


translate english c4232_7fc743d6:


    xy "\"Aoi... You're not 'just a friend' to—\""


translate english c4232_6f9d232c:



    voice "voice/c42/3200030a02.opus"
    aoi "\"Stop!\""


translate english c4232_df316181:


    "La palabra atraviesa mi corazón."


translate english c4232_1df000a4:



    voice "voice/c42/3200040a02.opus"
    aoi "\"My route is just a glitch.\""


translate english c4232_c2a91765:



    voice "voice/c42/3200050a02.opus"
    aoi "\"That event flag isn't supposed to trigger.\""


translate english c4232_ee9a9190:


    xy "\"Was your smile a glitch, too?\""


translate english c4232_0fc11746:



    voice "voice/c42/3200060a02.opus"
    aoi "\"My smile...?\""


translate english c4232_16ebb1a9:


    xy "\"What about your happiness? Was that all just another glitch?\""


translate english c4232_f7e0ec86:


    xy "\"And your sadness? And your tears?\""


translate english c4232_eae6e3d8:


    xy "\"You fell in love, pushed us away, and suffered in solitude.\""


translate english c4232_bcb00824:


    xy "\"Are those emotions all just errors and glitches, too?\""


translate english c4232_74575cd6:


    xy "\"I'm not a god. I'm not perfect. Fuck that.\""


translate english c4232_1e2fcf11:


    xy "\"Laughter, tears, sadness, joy... Love and hate...\""


translate english c4232_7edc6bc4:


    xy "\"I want to feel all of these things, and I want you right there with me.\""


translate english c4232_35354b68:


    "En el transcurso de buscar a Aoi, finalmente descubrí cómo me siento realmente."


translate english c4232_5170d695:


    "He estado muriendo por decírselo, todo este tiempo."


translate english c4232_7db1dd6c:


    "Esta es la razón por la que vine a buscarla."


translate english c4232_24d76ecf:


    xy "\"I don't care if I can't be with Miyuki... I just want to be with—\""


translate english c4232_047991a8:



    voice "voice/c42/3200070a02.opus"
    aoi "\"Aoi has... a favor to ask.\""


translate english c4232_f0999f34:


    "Me interrumpe a mitad de la frase."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
