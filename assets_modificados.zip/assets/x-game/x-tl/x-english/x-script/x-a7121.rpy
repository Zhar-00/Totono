

translate english a7121_3ba96436:


    xy "\"...Whew...\""


translate english a7121_23bb3d83:


    "Salgo del baño."


translate english a7121_39e7755f:


    "Me parece que eso fue demasiada emoción para una sola mañana."


translate english a7121_f29e0954:


    "Ciertamente no esperaba que Miyuki exigiera un beso apenas me desperté..."


translate english a7121_60c8662e:


    "Vaya, ese beso..."


translate english a7121_0accd139:


    xy "\"......\""


translate english a7121_6c110e94:


    "El recuerdo basta para hacerme sonrojar de nuevo."


translate english a7121_fd7656d8:


    "Su cara estaba roja brillante todo el tiempo, por supuesto."


translate english a7121_145a23e8:


    "Estaba tan jodidamente linda..."


translate english a7121_3a2c7160:


    "Y luego me sorprendí deseando que el momento durara para siempre..."


translate english a7121_ba80314b:


    "Y otras cosas vergonzosas por el estilo..."


translate english a7121_2fb1b7cb:



    voice "voice/a71/2100010a01.opus"
    mx "\"Shinichi!\""


translate english a7121_af70241c:


    xy "\"Oh, right. Coming!\""


translate english a7121_f061ccea:


    "Me encuentro parado en medio del pasillo sin razón alguna."


translate english a7121_5e581b1d:


    "¡Si sigo distraído así, Miyuki habrá cocinado en esa estufa caliente para nada!"


translate english a7121_f2faeec6:


    "Vaya, qué suerte tengo de poder comer su comida apenas me levanto—"


translate english a7121_cc074210:


    "...Espera."


translate english a7121_ef2efecc:


    "Aguanta un segundo..."


translate english a7121_e751533a:


    "¿Qué demonios hace ella aquí tan temprano, para empezar?"


translate english a7121_210b5f2d:



    voice "voice/a71/2100020a01.opus"
    mx "\"Shinichi, you don't have a proper morning routine, do you?\""


translate english a7121_2b6ff96f:



    voice "voice/a71/2100030a01.opus"
    mx "\"If you don't form good habits while you're young, it's gonna come back to bite you when you're older, you know.\""


translate english a7121_ad4a1334:


    xy "\"No sense in worrying about it now, though.\""


translate english a7121_d6001d1b:



    voice "voice/a71/2100040a01.opus"
    mx "\"Why shouldn't I worry?! I mean—\""


translate english a7121_ee24f835:



    voice "voice/a71/2100050a01.opus"
    mx "\"We kissed on the roof, didn't we?\""


translate english a7121_f9e43db3:


    xy "\"Uh... yeah...?\""


translate english a7121_70724915:



    voice "voice/a71/2100060a01.opus"
    mx "\"So...?\""


translate english a7121_9f08f87d:


    xy "\"...So what?\""


translate english a7121_13a75528:


    "—Si dos personas comparten un beso en la azotea, su amor será eterno."


translate english a7121_837fedfb:


    xy "\"You seriously believe that dumb rumor?\""


translate english a7121_a11d296b:



    voice "voice/a71/2100070a01.opus"
    mx "\"What, don't you?\""


translate english a7121_9fe1af75:


    "Dios mío, ¿de verdad se lo cree?"


translate english a7121_21a6423c:


    "...Supongo que no debería sorprenderme tanto, sabiendo cómo es."


translate english a7121_aac06462:



    voice "voice/a71/2100080a01.opus"
    mx "\"Now eat up before your breakfast gets cold.\""


translate english a7121_ea4fc683:



    voice "voice/a71/2100090a01.opus"
    mx "\"I lied to my parents and said I had morning rehearsal, so you better clean your plate, got it?\""


translate english a7121_2aa3cc5e:


    xy "\"Thanks.\""


translate english a7121_606b28d4:


    "La mesa está llena de pescado a la parrilla, sopa de miso, ciruelas encurtidas y ensalada de espinacas con ajonjolí: un desayuno japonés puro y sin adulterar."


translate english a7121_569e4423:


    "A primera vista parece sencillo y f<I></I>uncional, pero—"


translate english a7121_296540dc:


    xy "\"Holy shit.\""


translate english a7121_83147c88:



    voice "voice/a71/2100100a01.opus"
    mx "\"What?\""


translate english a7121_c05c36fa:


    xy "\"This is delicious! I don't know how you do it, but you knock it out of the park every single time!\""


translate english a7121_7929797c:


    xy "\"This feels more like a feast than a regular old breakfast!\""


translate english a7121_8f2df5b6:



    voice "voice/a71/2100110a01.opus"
    mx "\"Oh, please. It's nothing so special as that.\""


translate english a7121_832a9290:



    voice "voice/a71/2100120a01.opus"
    mx "\"I was only able to bring a handful of ingredients, after all...\""


translate english a7121_fd87ecb4:


    "Miyuki es tan linda cuando intenta ser humilde... Sobre todo cuando se sonroja..."


translate english a7121_592db245:


    "No puedo evitar querer molestarla más."


translate english a7121_1e2a2780:


    xy "\"What's this? Do I detect a hint of your famous secret ingredient?\""


translate english a7121_b3ae7e20:



    voice "voice/a71/2100130a01.opus"
    mx "\"What? I don't have a secret ingredient.\""


translate english a7121_400bf601:


    xy "\"Sure you do.\""


translate english a7121_ed4f432e:


    "Pongo mi sonrisa premiada."


translate english a7121_3a309803:


    xy "\"It's seasoned with your love.\""


translate english a7121_b489c0e2:



    voice "voice/a71/2100140a01.opus"
    mx "\"You... you—!\""


translate english a7121_aa2e055d:



    voice "voice/a71/2100150a01.opus"
    mx "\"You CLOD! Don't get so full of yourself!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
