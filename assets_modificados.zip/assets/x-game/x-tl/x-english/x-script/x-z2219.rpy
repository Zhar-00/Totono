

translate english z2219_0e16a954:



    voice "voice/z22/1900010a01.opus"
    mx "Es el Día de las Niñas... Dime, ¿has comido hishi mochi alguna vez?"


translate english z2219_a4ff833d:



    voice "voice/z22/1900020a01.opus"
    mx "Personalmente, no puedo decir que sí."


translate english z2219_8a38ed09:



    voice "voice/z22/1900030a01.opus"
    mx "Me pregunto a qué sabrá..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
