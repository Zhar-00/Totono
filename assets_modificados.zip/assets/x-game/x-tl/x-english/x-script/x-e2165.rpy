

translate english e2165_c9fea237:


    xy "\"Which one do you like better?\""


translate english e2165_f4bd0d1f:



    voice "voice/e21/6500010a01.opus"
    mx "\"This one.\""


translate english e2165_c22f001a:



    voice "voice/e21/6500020a01.opus"
    mx "\"That one sucks.\""


translate english e2165_1efcf94c:


    xy "\"Oh... Okay.\""


translate english e2165_7e900816:


    "No veo qué hace que ese sea mucho peor, pero claramente debe tener una razón para sentirse tan fuerte al respecto."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
