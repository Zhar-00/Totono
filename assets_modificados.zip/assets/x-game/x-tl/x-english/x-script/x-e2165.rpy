

translate english e2165_c9fea237:


    xy "\"¿Cuál te gusta más?\""


translate english e2165_f4bd0d1f:



    voice "voice/e21/6500010a01.opus"
    mx "\"Este.\""


translate english e2165_c22f001a:



    voice "voice/e21/6500020a01.opus"
    mx "\"Ese apesta.\""


translate english e2165_1efcf94c:


    xy "\"Oh... Está bien.\""


translate english e2165_7e900816:


    "No veo qué hace que ese sea mucho peor, pero claramente debe tener una razón para sentirse tan fuerte al respecto."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
