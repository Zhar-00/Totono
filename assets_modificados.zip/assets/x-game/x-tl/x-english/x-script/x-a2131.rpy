

translate english a2131_a912c507:


    "Después de terminar nuestra comida, decidimos pasar el resto del almuerzo juntos en la azotea."


translate english a2131_33319945:



    voice "voice/a21/3100010a01.opus"
    mx "\"I'm completely stuffed.\""


translate english a2131_f3c3673c:


    xy "\"Me too.\""


translate english a2131_a771e02a:



    voice "voice/a21/3100020a01.opus"
    mx "\"Now then, let's get started on our English homew—\""


translate english a2131_45edf55a:



    voice "voice/a21/3100030a02.opus"
    aoi "\"Boop boop... boop boop boop...\""


translate english a2131_60990c85:



    voice "voice/a21/3100040a01.opus"
    mx "\"Mukou-san?\""


translate english a2131_31508a05:



    voice "voice/a21/3100050a02.opus"
    aoi "\"Power... running... low...\""


translate english a2131_363c7b75:


    xy "\"Uh oh. Is your battery dying?\""


translate english a2131_89c9d68f:



    voice "voice/a21/3100060a01.opus"
    mx "\"Knock it off! You haven't studied for the homework, have you?\""


translate english a2131_682f9d68:



    voice "voice/a21/3100070a02.opus"
    aoi "\"...Boop boop?\""


translate english a2131_303f326f:



    voice "voice/a21/3100080a02.opus"
    aoi "\"Studying takes a lot of battery power.\""


translate english a2131_056aa068:



    voice "voice/a21/3100090a02.opus"
    aoi "\"It's too hard...\""



translate english a2131_9023937c:



    voice "voice/a21/3100100a01.opus"
    mx "\"Don't be ridiculous—HEY!\""


translate english a2131_f1cbbe0b:



    voice "voice/a21/3100110a02.opus"
    aoi "\"Boop boop boop...\""


translate english a2131_a0754972:



    voice "voice/a21/3100120a01.opus"
    mx "\"Don't you fall asleep, missy!\""


translate english a2131_4c7eab26:


    xy "\"Maybe you should drink some coffee to help you wake up?\""


translate english a2131_a57356ce:



    voice "voice/a21/3100130a02.opus"
    aoi "\"Coffee makes me pee...\""


translate english a2131_d7bf38e5:


    "¿Qué tienes, cinco años?"


translate english a2131_1f8cbe19:



    voice "voice/a21/3100140a01.opus"
    mx "\"Okay, what other options are there?\""


translate english a2131_e5bc98db:


    xy "\"Hmm... I dunno...\""


translate english a2131_d923ce17:



    voice "voice/a21/3100150a02.opus"
    aoi "\"This.\""


translate english a2131_05777826:


    "Aoi saca algo de su bolsillo."


translate english a2131_1a8e791d:


    xy "\"Is that a hairpin?\""


translate english a2131_9892fc0b:



    voice "voice/a21/3100160a01.opus"
    mx "\"It looks a little melted...\""


translate english a2131_27455163:



    voice "voice/a21/3100170a02.opus"
    aoi "\"Aoi used it to recharge.\""


translate english a2131_bdfff28d:



    voice "voice/a21/3100180a02.opus"
    aoi "\"Stuck it into the wall socket and ZAP!\""


translate english a2131_69288da7:



    voice "voice/a21/3100190a01.opus"
    mx "\"Don't you EVER do that again.\""


translate english a2131_2ccee167:



    voice "voice/a21/3100200a02.opus"
    aoi "\"But it charged me right up and—\""


translate english a2131_b4a675b1:


    xy "\"No, really. Don't.\""


translate english a2131_61bb661d:



    voice "voice/a21/3100210a02.opus"
    aoi "\"...Boop boop...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
