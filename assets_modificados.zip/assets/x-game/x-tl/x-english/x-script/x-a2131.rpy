

translate english a2131_a912c507:


    "Después de terminar nuestra comida, decidimos pasar el resto del almuerzo juntos en la azotea."


translate english a2131_33319945:



    voice "voice/a21/3100010a01.opus"
    mx "\"Estoy completamente lleno.\""


translate english a2131_f3c3673c:


    xy "\"Yo también.\""


translate english a2131_a771e02a:



    voice "voice/a21/3100020a01.opus"
    mx "\"Ahora entonces, empecemos con nuestra tarea de in—\""


translate english a2131_45edf55a:



    voice "voice/a21/3100030a02.opus"
    aoi "\"Bip bip... bip bip bip...\""


translate english a2131_60990c85:



    voice "voice/a21/3100040a01.opus"
    mx "\"¿Mukou-san?\""


translate english a2131_31508a05:



    voice "voice/a21/3100050a02.opus"
    aoi "\"Energía... agotándose...\""


translate english a2131_363c7b75:


    xy "\"Uh oh. ¿Se está muriendo tu batería?\""


translate english a2131_89c9d68f:



    voice "voice/a21/3100060a01.opus"
    mx "\"¡Ya basta! No estudiaste para la tarea, ¿verdad?\""


translate english a2131_682f9d68:



    voice "voice/a21/3100070a02.opus"
    aoi "\"...¿Bip bip?\""


translate english a2131_303f326f:



    voice "voice/a21/3100080a02.opus"
    aoi "\"Estudiar consume mucha batería.\""


translate english a2131_056aa068:



    voice "voice/a21/3100090a02.opus"
    aoi "\"Es muy difícil...\""



translate english a2131_9023937c:



    voice "voice/a21/3100100a01.opus"
    mx "\"No digas tonterías— ¡HEY!\""


translate english a2131_f1cbbe0b:



    voice "voice/a21/3100110a02.opus"
    aoi "\"Bip bip bip...\""


translate english a2131_a0754972:



    voice "voice/a21/3100120a01.opus"
    mx "\"¡No te duermas, señorita!\""


translate english a2131_4c7eab26:


    xy "\"¿Quizás deberías tomar café para ayudarte a despertar?\""


translate english a2131_a57356ce:



    voice "voice/a21/3100130a02.opus"
    aoi "\"El café me hace orinar...\""


translate english a2131_d7bf38e5:


    "¿Qué tienes, cinco años?"


translate english a2131_1f8cbe19:



    voice "voice/a21/3100140a01.opus"
    mx "\"Ok, ¿qué otras opciones hay?\""


translate english a2131_e5bc98db:


    xy "\"Hmm... No sé...\""


translate english a2131_d923ce17:



    voice "voice/a21/3100150a02.opus"
    aoi "\"Esto.\""


translate english a2131_05777826:


    "Aoi saca algo de su bolsillo."


translate english a2131_1a8e791d:


    xy "\"¿Es una horquilla?\""


translate english a2131_9892fc0b:



    voice "voice/a21/3100160a01.opus"
    mx "\"Se ve un poco derretida...\""


translate english a2131_27455163:



    voice "voice/a21/3100170a02.opus"
    aoi "\"Aoi la usó para recargarse.\""


translate english a2131_bdfff28d:



    voice "voice/a21/3100180a02.opus"
    aoi "\"La metí en el enchufe y ¡ZAS!\""


translate english a2131_69288da7:



    voice "voice/a21/3100190a01.opus"
    mx "\"No vuelvas a hacer eso NUNCA.\""


translate english a2131_2ccee167:



    voice "voice/a21/3100200a02.opus"
    aoi "\"Pero me cargó al instante y—\""


translate english a2131_b4a675b1:


    xy "\"No, en serio. No lo hagas.\""


translate english a2131_61bb661d:



    voice "voice/a21/3100210a02.opus"
    aoi "\"...Bip bip...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
