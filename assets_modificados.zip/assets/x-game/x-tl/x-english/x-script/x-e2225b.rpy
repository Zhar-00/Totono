

translate english e2225b_80dd48d4:


    xy "\"Miyuki... I'm gonna cum in you...!\""


translate english e2225b_a9576d4c:



    voice "voice/e22/25b00010a01.opus"
    mx "\"Haaah! Nnn... Okay... Sure... Aaah! Cum wherever you want—AAAH! AAH!\""


translate english e2225b_ca380521:



    voice "voice/e22/25b00020a01.opus"
    mx "\"Wow... I can feel it swelling inside me— Haaahh! Aah! Aah! AAAAHHH!!!\""


translate english e2225b_c0dceacd:



    voice "voice/e22/25b00030a01.opus"
    mx "\"NnhaaAAHH! Aah! Aaahh! Oh fuck! I love you! I love you! It feels so good— AAAH!\""


translate english e2225b_f9125345:



    voice "voice/e22/25b00040a01.opus"
    mx "\"I'm gonna—I'm gonna cum again—! Please—cum with me—!\""


translate english e2225b_35d05695:



    voice "voice/e22/25b00050a01.opus"
    mx "\"Just lose control—and flood my pussy with your cum—! NnhaaaAAAAH—!\""


translate english e2225b_4dcb9c1c:



    voice "voice/e22/25b00060a01.opus"
    mx "\"Haah! Aah! Aah! Aah! Aah! Aaahh! Aah! Aah, aah, aah! Aaaaahhh—\""


translate english e2225b_9913f509:



    voice "voice/e22/25b00070a01.opus"
    mx "\"NnhaaaaaaaaAAAAAAAAAAAAAAHHHHHHH—!!!\""


translate english e2225b_344422a1:



    voice "voice/e22/25b00080a01.opus"
    mx "\"Aaahh... aah... nngh... nn... nnn... nnnng...! Nnnnggh...!!!\""



translate english e2225b_89a56c61:



    voice "voice/e22/25b00090a01.opus"
    mx "\"I can... feel it... nn... nnn... So much... flowing into me... Haah!\""



translate english e2225b_e03c32ce:



    voice "voice/e22/25b00100a01.opus"
    mx "\"Nngghh! Nnn... nnngg... nn... Haah! Haah! Haah... nn... nnn... nn...\""



translate english e2225b_7299c72a:


    "Hace rato que dejé de embestir, pero el cuerpo de Miyuki sigue temblando ligeramente."



translate english e2225b_4f674623:


    "Su coño se contrae, como si exprimiera hasta la última gota de semen de mi polla."



translate english e2225b_5e9407db:


    "Agotado, me derrumbo encima de ella..."



translate english e2225b_6fe4052a:


    "...y mi conciencia se desvanece."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
