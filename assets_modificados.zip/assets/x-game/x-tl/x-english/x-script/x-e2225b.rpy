

translate english e2225b_80dd48d4:


    xy "\"¡Miyuki... voy a venirme dentro de ti...!\""


translate english e2225b_a9576d4c:



    voice "voice/e22/25b00010a01.opus"
    mx "\"¡Haaah! Nnn... Vale... Claro... ¡Aaah! Vente donde quieras—¡AAAH! ¡AAH!\""


translate english e2225b_ca380521:



    voice "voice/e22/25b00020a01.opus"
    mx "\"Guau... Lo siento hincharse dentro de mí— ¡Haaahh! ¡Aah! ¡Aah! ¡AAAHHH!!!\""


translate english e2225b_c0dceacd:



    voice "voice/e22/25b00030a01.opus"
    mx "\"¡NnhaaAAHH! ¡Aah! ¡Aaahh! ¡Ay, joder! ¡Te amo! ¡Te amo! ¡Se siente tan bien— AAAH!\""


translate english e2225b_f9125345:



    voice "voice/e22/25b00040a01.opus"
    mx "\"¡Voy a—voy a venirme otra vez—! ¡Por favor—vente conmigo—!\""


translate english e2225b_35d05695:



    voice "voice/e22/25b00050a01.opus"
    mx "\"¡Solo pierde el control—e inunda mi coño con tu semen—! ¡NnhaaaAAAAH—!\""


translate english e2225b_4dcb9c1c:



    voice "voice/e22/25b00060a01.opus"
    mx "\"¡Haah! ¡Aah! ¡Aah! ¡Aah! ¡Aah! ¡Aaahh! ¡Aah! ¡Aah, aah, aah! ¡Aaaaahhh—\""


translate english e2225b_9913f509:



    voice "voice/e22/25b00070a01.opus"
    mx "\"¡NnhaaaaaaaaAAAAAAAAAAAAAAHHHHHHH—!!!\""


translate english e2225b_344422a1:



    voice "voice/e22/25b00080a01.opus"
    mx "\"¡Aaahh... aah... nngh... nn... nnn... nnnng...! ¡Nnnnggh...!!!\""



translate english e2225b_89a56c61:



    voice "voice/e22/25b00090a01.opus"
    mx "\"Puedo... sentirlo... nn... nnn... Tanto... fluyendo dentro de mí... ¡Haah!\""



translate english e2225b_e03c32ce:



    voice "voice/e22/25b00100a01.opus"
    mx "\"¡Nngghh! ¡Nnn... nnngg... nn...! ¡Haah! ¡Haah! ¡Haah... nn... nnn... nn...\""



translate english e2225b_7299c72a:


    "Hace rato que dejé de embestir, pero el cuerpo de Miyuki sigue temblando ligeramente."



translate english e2225b_4f674623:


    "Su coño se contrae, como si exprimiera hasta la última gota de semen de mi polla."



translate english e2225b_5e9407db:


    "Agotado, me derrumbo encima de ella..."



translate english e2225b_6fe4052a:


    "...y mi conciencia se desvanece."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
