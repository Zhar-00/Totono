

translate english d4122_df652c1c:



    voice "voice/d41/2200010a01.opus"
    mx "\"¡Buenos días!\""


translate english d4122_2b909e01:


    "Miyuki entra al salón, y al instante toda la clase se anima."


translate english d4122_587e2985:


    "Como de costumbre, rápidamente atrae a una multitud."


translate english d4122_2ba6cccf:


    "Escudriña el salón—y su mirada se detiene en el pupitre vacío de Aoi."


translate english d4122_f4e7b0f5:



    voice "voice/d41/2200020a01.opus"
    mx "\"......\""


translate english d4122_c349ed5f:


    "Me lanza una mirada interrogante."


translate english d4122_9f1e6075:


    "Pero no tengo una respuesta para ella."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
