

translate english e2142a_d9602061:


    "A su petición, presiono mis labios contra los suyos—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
