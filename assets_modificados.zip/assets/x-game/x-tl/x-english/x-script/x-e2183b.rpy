

translate english e2183b_d74e48e0:



    voice "voice/e21/83b00010a01.opus"
    mx "\"Digo, me halaga, pero...\""


translate english e2183b_f2e686b2:



    voice "voice/e21/83b00020a01.opus"
    mx "\"Solo... necesito un poco más de tiempo antes de poder confiar en ti.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
