

translate english e2183b_d74e48e0:



    voice "voice/e21/83b00010a01.opus"
    mx "\"I mean, I'm flattered, but...\""


translate english e2183b_f2e686b2:



    voice "voice/e21/83b00020a01.opus"
    mx "\"I just... I need a little more time before I can trust you.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
