

translate english e2111_24c84a2d:



    voice "voice/e21/1100010a01.opus"
    mx "\"Good morning!\""


translate english e2111_a5c7159c:


    xy "\"Morning!\""


translate english e2111_fff2df0f:


    "Los estudiantes se saludan con la mano camino a la escuela."


translate english e2111_98f85e59:


    "Como Miyuki y yo vivimos en la misma casa..."


translate english e2111_0d2e0405:


    "...naturalmente, tomamos la misma ruta a la escuela."


translate english e2111_ad85edd9:


    "Caminamos directo hacia allá, sin desvíos."


translate english e2111_28e0cdc3:


    "...Aunque a veces hacemos un pequeño desvío a un santuario, si vemos un gato en la entrada."


translate english e2111_5cd08b0a:


    "...Aunque a veces hacemos un pequeño desvío al río, si hace buen tiempo."


translate english e2111_9ac0ced4:



    voice "voice/e21/1100020a01.opus"
    mx "\"Shinichi.\""


translate english e2111_c8a2dc6b:


    xy "\"Hmm? What's up?\""


translate english e2111_6127260d:



    voice "voice/e21/1100030a01.opus"
    mx "\"L-Listen, um...\""


translate english e2111_e7c8663b:


    "Miyuki camina a mi lado."


translate english e2111_0c82e51a:



    voice "voice/e21/1100040a01.opus"
    mx "\"How do you feel about... holding hands in public?\""


translate english e2111_321cf6bd:


    "Bajo la mirada."


translate english e2111_e324597d:



    voice "voice/e21/1100050a01.opus"
    mx "\"Personally, I'm not crazy about it, to tell the truth.\""


translate english e2111_22e37f3b:



    voice "voice/e21/1100060a01.opus"
    mx "\"It's too embarrassing.\""


translate english e2111_365b98cb:



    voice "voice/e21/1100070a01.opus"
    mx "\"It feels like we're trying to show off or something.\""


translate english e2111_ca0fb5a1:



    voice "voice/e21/1100080a01.opus"
    mx "\"I prefer to keep private things private.\""


translate english e2111_11f6d12b:



    voice "voice/e21/1100090a01.opus"
    mx "\"But...\""


translate english e2111_d16e405b:


    "Ella extiende torpemente su mano izquierda hacia mí."


translate english strings:


    old "Подойти поближе"
    new "Acercarme"


    old "Отойти подальше"
    new "Alejarme"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
