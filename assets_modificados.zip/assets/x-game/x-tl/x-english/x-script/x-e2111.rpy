

translate english e2111_24c84a2d:



    voice "voice/e21/1100010a01.opus"
    mx "\"¡Buenos días!\""


translate english e2111_a5c7159c:


    xy "\"¡Buenos días!\""


translate english e2111_fff2df0f:


    "Los estudiantes se saludan con la mano camino a la escuela."


translate english e2111_98f85e59:


    "Como Miyuki y yo vivimos en la misma casa..."


translate english e2111_0d2e0405:


    "...naturalmente, tomamos la misma ruta a la escuela."


translate english e2111_ad85edd9:


    "Caminamos directo hacia allá, sin desvíos."


translate english e2111_28e0cdc3:


    "...Aunque a veces hacemos un pequeño desvío a un santuario, si vemos un gato en la entrada."


translate english e2111_5cd08b0a:


    "...Aunque a veces hacemos un pequeño desvío al río, si hace buen tiempo."


translate english e2111_9ac0ced4:



    voice "voice/e21/1100020a01.opus"
    mx "\"Shinichi.\""


translate english e2111_c8a2dc6b:


    xy "\"¿Hmm? ¿Qué pasa?\""


translate english e2111_6127260d:



    voice "voice/e21/1100030a01.opus"
    mx "\"E-Escucha, em...\""


translate english e2111_e7c8663b:


    "Miyuki camina a mi lado."


translate english e2111_0c82e51a:



    voice "voice/e21/1100040a01.opus"
    mx "\"¿Qué opinas de... tomarnos de la mano en público?\""


translate english e2111_321cf6bd:


    "Bajo la mirada."


translate english e2111_e324597d:



    voice "voice/e21/1100050a01.opus"
    mx "\"En lo personal, no me encanta, a decir verdad.\""


translate english e2111_22e37f3b:



    voice "voice/e21/1100060a01.opus"
    mx "\"Es demasiado vergonzoso.\""


translate english e2111_365b98cb:



    voice "voice/e21/1100070a01.opus"
    mx "\"Se siente como si quisiéramos presumir o algo así.\""


translate english e2111_ca0fb5a1:



    voice "voice/e21/1100080a01.opus"
    mx "\"Prefiero mantener las cosas privadas en privado.\""


translate english e2111_11f6d12b:



    voice "voice/e21/1100090a01.opus"
    mx "\"Pero...\""


translate english e2111_d16e405b:


    "Ella extiende torpemente su mano izquierda hacia mí."


translate english strings:


    old "Подойти поближе"
    new "Acercarme"


    old "Отойти подальше"
    new "Alejarme"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
