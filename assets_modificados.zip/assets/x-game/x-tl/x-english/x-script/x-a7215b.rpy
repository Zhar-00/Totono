

translate english a7215b_39e98921:



    voice "voice/a72/15b00010a01.opus"
    mx "\"¡Hnn! ¡Nnn! ¡Nnnnn! ¡Nnn! ¡Nnjaah... aah... aaahh...\""


translate english a7215b_b4424be8:



    voice "voice/a72/15b00020a01.opus"
    mx "\"¡Aah... nn... nnn... nnggghh...! Jaah... jaah... jaah... nnn...\""


translate english a7215b_0bef0716:



    voice "voice/a72/15b00030a01.opus"
    mx "\"Te estás viniendo... tanto... Tu verga sigue y sigue... ¡Nnnn!\""


translate english a7215b_cb46657f:


    "Apenas salgo, el semen brota de mi punta como una erupción volcánica."


translate english a7215b_c213d995:


    "Cada vez que mi semilla lechosa toca su piel, todo su cuerpo se sacude."


translate english a7215b_36aa178f:



    voice "voice/a72/15b00040a01.opus"
    mx "\"Jaah... aah... nnn... Por todo mi pecho... y mi cara... Hay tanto... Me sorprende...\""


translate english a7215b_5bb22db5:


    "Con los dedos temblorosos, se agacha y recoge algo de mis fluidos."


translate english a7215b_b4ed7550:


    "Luego, con una expresión extasiada, se lo lleva a la boca."


translate english a7215b_b017d89a:



    voice "voice/a72/15b00050a01.opus"
    mx "\"Mm... slrrp... slrrpphh... mmm... Mmmm... sllrrpp... mm... mmmm... mmm...\""


translate english a7215b_0fc6aa8e:



    voice "voice/a72/15b00060a01.opus"
    mx "\"¡Mmm... nngllp...! Mm... ¡Jeje! Guau...\""


translate english a7215b_2c56aaba:



    voice "voice/a72/15b00070a01.opus"
    mx "\"Es como si me hubieras marcado con tu aroma... por dentro y por fuera...\""


translate english a7215b_d8552bae:


    "Me sonríe radiante, perfectamente satisfecha—"


translate english a7215b_0f4bee63:


    "—y no puedo evitar devolverle la sonrisa."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
