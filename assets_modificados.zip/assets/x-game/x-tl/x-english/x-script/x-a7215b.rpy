

translate english a7215b_39e98921:



    voice "voice/a72/15b00010a01.opus"
    mx "\"Hnn! Nnn! Nnnnn! Nnn! Nnhaah... aah... aaahh...\""


translate english a7215b_b4424be8:



    voice "voice/a72/15b00020a01.opus"
    mx "\"Aah... nn... nnn... nnggghh...! Haah... haah... haah... nnn...\""


translate english a7215b_0bef0716:



    voice "voice/a72/15b00030a01.opus"
    mx "\"You're cumming... so much... Your cock is still going... Nnnn!\""


translate english a7215b_cb46657f:


    "Apenas salgo, el semen brota de mi punta como una erupción volcánica."


translate english a7215b_c213d995:


    "Cada vez que mi semilla lechosa toca su piel, todo su cuerpo se sacude."


translate english a7215b_36aa178f:



    voice "voice/a72/15b00040a01.opus"
    mx "\"Haah... aah... nnn... All over my chest... and my face... There's so much... I'm surprised...\""


translate english a7215b_5bb22db5:


    "Con los dedos temblorosos, se agacha y recoge algo de mis fluidos."


translate english a7215b_b4ed7550:


    "Luego, con una expresión extasiada, se lo lleva a la boca."


translate english a7215b_b017d89a:



    voice "voice/a72/15b00050a01.opus"
    mx "\"Mm... slrrp... slrrpphh... mmm... Mmmm... sllrrpp... mm... mmmm... mmm...\""


translate english a7215b_0fc6aa8e:



    voice "voice/a72/15b00060a01.opus"
    mx "\"Mmm... nngllp...! Mm... Hehe! Wow...\""


translate english a7215b_2c56aaba:



    voice "voice/a72/15b00070a01.opus"
    mx "\"It's like you marked me with your scent... inside and out...\""


translate english a7215b_d8552bae:


    "Me sonríe radiante, perfectamente satisfecha—"


translate english a7215b_0f4bee63:


    "—y no puedo evitar devolverle la sonrisa."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
