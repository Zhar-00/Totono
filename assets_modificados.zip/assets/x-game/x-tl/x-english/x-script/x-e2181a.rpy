

translate english e2181a_a1fc3dca:


    "En efecto."


translate english e2181a_4686d56f:


    "La pelota de béisbol choca con mi bate y vuela, brillando de un blanco pálido mientras traza un arco por el cielo nocturno."


translate english e2181a_3abcb7de:


    xy "\"Hell yeah!\""


translate english e2181a_c6f592ac:



    voice "voice/e21/81a00010a01.opus"
    mx "\"Home run...?\""


translate english e2181a_a3d349e0:


    "Golpea el blanco justo en el centro."


translate english e2181a_9326f10f:



    voice "voice/e21/81a00020a01.opus"
    mx "\"How did you know what I was planning for the last ball?\""


translate english e2181a_8b2d5359:


    xy "\"I taught you that pitch way back when, remember?\""


translate english e2181a_f3a54608:


    xy "\"I figured you'd go that route to make me strike out.\""


translate english e2181a_cbda1a8b:



    voice "voice/e21/81a00030a01.opus"
    mx "\"You remembered...\""


translate english e2181a_5ec4cdab:



    voice "voice/e21/81a00040a01.opus"
    mx "\"...Well, alright.\""


translate english e2181a_3d286647:



    voice "voice/e21/81a00050a01.opus"
    mx "\"You won, fair and square. I'll do whatever you ask.\""


translate english e2181a_c2b209dd:



    voice "voice/e21/81a00060a01.opus"
    mx "\"So what do you want from me?\""


translate english e2181a_56649083:


    "Lo que yo pida, ¿eh?"


translate english e2181a_7e33d4cc:


    "Bueno, FUE una victoria ajustada..."


translate english e2181a_3f363704:


    "Seguramente puedo salirme con la mía pidiendo algo un poco atrevido..."


translate english e2181a_317e2fc2:


    "Y en ese caso, solo una cosa me viene a la mente..."


translate english strings:


    old "Я хочу Миюки"
    new "Quiero a Miyuki"


    old "Я хочу Аой"
    new "Quiero a Aoi"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
