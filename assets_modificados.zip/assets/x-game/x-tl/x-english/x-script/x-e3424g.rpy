

translate english e3424g_0f2382bf:


    xy "\"Oye, eh...\""


translate english e3424g_598a7841:


    "Saco su teléfono del bolsillo."


translate english e3424g_2cc82fa3:


    xy "\"Sorry for running off with this. I'm honestly not sure what I was thinking.\"\n\"That's okay.\""



translate english e3424g_6a61ff5b:



    voice "voice/e34/24g00010a01.opus"
    mx "\"Solo me alegra que TÚ decidieras quedarte. Es todo lo que necesito.\""


translate english e3424g_411943ba:



    voice "voice/e34/24g00020a01.opus"
    mx "Ya. Dije. Que. Está. Bien."



translate english e3424g_3c051d47:


    xy "Parece que no tengo voz ni voto en el asunto."


translate english e3424g_f84c0829:



    voice "voice/e34/24g00030a01.opus"
    mx "\"Ahora entonces, vamos a ca—\""


translate english e3424g_8f6358f0:


    "\"¡ACHÍS!\""


translate english e3424g_2e4ee6fb:



    voice "voice/e34/24g00040a01.opus"
    mx "\"¿Hmm? ¿Son tus alergias otra vez?\""


translate english e3424g_60279288:



    voice "voice/e34/24g00050a01.opus"
    mx "\"¡ACHÍS!\""


translate english e3424g_63e61a4d:


    xy "\"¿Hmm? ¿Son tus alergias otra vez?\""


translate english e3424g_5e8817d6:



    voice "voice/e34/24g00060a01.opus"
    mx "\"No, probablemente es porque mi pelo sigue mojado.\""


translate english e3424g_c5299b08:


    xy "\"Pero juraría que había un gato aquí... ¿Qué rayos?\""


translate english e3424g_124e62e1:


    xy "\"¿Se fue...?\""


translate english e3424g_b2b16c2a:



    voice "voice/e34/24g00070a01.opus"
    mx "\"¿Tu cerebro sigue dormido o qué?\""


translate english e3424g_a772a0f7:


    "No estoy del todo convencido, pero... pensándolo bien, no es como si el gatito pudiera haber salido del techo por su cuenta."


translate english e3424g_c87253df:


    "Recordándolo, tampoco parecía para nada un gato normal."


translate english e3424g_43510ca1:


    "Casi... de otro mundo..."


translate english e3424g_ff1eece2:


    xy "\"...Vaya, hoy ha sido un día raro.\""


translate english e3424g_4cd5ee6d:



    voice "voice/e34/24g00080a01.opus"
    mx "\"Debes estar cansado.\""


translate english e3424g_9af5a825:



    voice "voice/e34/24g00090a01.opus"
    mx "\"Ahora, vamos a casa a dormir un poco.\""


translate english e3424g_06672002:


    xy "\"Sí, supongo...\""


translate english e3424g_ef4d1980:


    "Y así, ante la insistencia de Miyuki, dejamos el centro del universo..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
