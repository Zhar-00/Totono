

translate english e1155i_cb7178f3:


    "Espera, ¿qué?"


translate english e1155i_4e1b56ea:


    "¿Qué estaba haciendo hace un momento...?"


translate english e1155i_0fd4d656:


    "......"


translate english e1155i_a528f536:


    "¡Ah, es verdad!"


translate english e1155i_76b509aa:


    "Iba a salir para—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
