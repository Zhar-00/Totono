

translate english a7214a_80105e4a:



    voice "voice/a72/14a00010a01.opus"
    mx "\"Estoy hecha un desastre... ¡AAAH! ¡Dios! ¡Me siento tan destrozada...!\""


translate english a7214a_42d6b069:



    voice "voice/a72/14a00020a01.opus"
    mx "\"Aaahh... aah... Dios... mío... Soy tan feliz... hasta el fondo de mi ser...\""


translate english a7214a_18e121ac:



    voice "voice/a72/14a00030a01.opus"
    mx "\"Me llenas por completo, Shinichi... Estoy tan enamorada, que... no puedo...\""


translate english a7214a_5b034527:



    voice "voice/a72/14a00040a01.opus"
    mx "\"Ajá... ¿Estoy... viniéndome otra vez...? ¿Y tú? ¿Estás cerca?\""


translate english a7214a_f49592d9:



    voice "voice/a72/14a00050a01.opus"
    mx "\"Adelante—¡puedo aguantarlo! ¡Solo... dámelo! ¡Jaah! ¡Aah!\""


translate english a7214a_c1233b7e:



    voice "voice/a72/14a00060a01.opus"
    mx "\"¡Aaah! ¡Estoy tan llena de verga—Nngghh! Me voy a venir... Ven conmigo... ¡Me vengo... me vengo—!\""


translate english a7214a_b1b02d8b:



    voice "voice/a72/14a00070a01.opus"
    mx "¡AaaaaaaaAAAAAAAAAAAAAAAAAAHHHHHHHHH!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
