

translate english a7214a_80105e4a:



    voice "voice/a72/14a00010a01.opus"
    mx "\"I'm such a mess... AAAH! Oh god! I feel so ravaged...!\""


translate english a7214a_42d6b069:



    voice "voice/a72/14a00020a01.opus"
    mx "\"Aaahh... aah... Oh... my god... I'm so happy... right down to my core...\""


translate english a7214a_18e121ac:



    voice "voice/a72/14a00030a01.opus"
    mx "\"You fill me completely, Shinichi... I'm so in love, I... I can't...\""


translate english a7214a_5b034527:



    voice "voice/a72/14a00040a01.opus"
    mx "\"Ahah... Am I... cumming again...? What about you? Are you close?\""


translate english a7214a_f49592d9:



    voice "voice/a72/14a00050a01.opus"
    mx "\"Go ahead—I can take it! Just... Just give it to me! Haah! Aah!\""


translate english a7214a_c1233b7e:



    voice "voice/a72/14a00060a01.opus"
    mx "\"Aaah! I'm so full of cock—Nngghh! I'm gonna cum... Cum with me... I'm cumming... I'm cumming—!\""


translate english a7214a_b1b02d8b:



    voice "voice/a72/14a00070a01.opus"
    mx "¡AaaaaaaaAAAAAAAAAAAAAAAAAAHHHHHHHHH!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
