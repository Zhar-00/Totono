

translate english a3161_ba380d23:


    "Pero entonces empiezo a pensar..."


translate english a3161_d3627ff3:


    "¿Y si Aoi estuviera sola?"


translate english a3161_2b13fec8:


    "¿Y si no hubiéramos estado ahí para ella?"


translate english a3161_49400b3f:


    "¿Y si Miyuki no hubiera estado para regañarla?"


translate english a3161_a40b71bb:


    "Obviamente Aoi habría adoptado al gatito."


translate english a3161_eeb4e738:


    "Habría intentado, y fallado, colar al gatito en el manga café. Luego el gerente la habría echado. Y entonces..."


translate english a3161_2c0f35b1:


    "Entonces habría pasado la noche en las calles."


translate english a3161_a7e49fdb:


    "Puedo imaginarlo todo con total claridad."


translate english a3161_a8ae2432:


    "Aoi no habría tenido a nadie a quien recurrir."


translate english a3161_d0818f96:


    "Y el gatito se habría muerto de frío."


translate english a3161_9dd553c8:


    xy "\"God, are you out there...?\""


translate english a3161_7acf188b:


    "Para Aoi, Dios tiene que existir. Es la única forma en que puede sentirse validada en la manera en que elige vivir su vida."


translate english a3161_f6c143e7:


    "Después de todo, un Dios justo seguramente mostraría favor a la gente buena que hace cosas buenas."


translate english a3161_c501e883:


    "Si Dios de verdad tuviera un celular..."


translate english a3161_1e3695d1:


    "Si de verdad estuviera a una simple llamada de distancia..."


translate english a3161_28f52f88:


    "¿Contestaría sus plegarias?"


translate english a3161_79449f29:


    "¿Está esperando allá afuera, en algún lugar más allá del cielo...?"


translate english a3161_420a2bf2:


    xy "\"Wait... The sky...?\""


translate english a3161_8f1d2300:


    xy "\"Oh crap... It's raining!\""


translate english a3161_7c1584d4:


    "Las noches se ponen bastante frías en otoño."


translate english a3161_9066a0e7:


    "Una mísera caja de cartón no basta para mantenerse caliente."


translate english a3161_d151ce6e:


    "Ese gatito debe de estar congelándose allá afuera, indefenso y confundido, llamando a una madre que nunca regresará..."


translate english a3161_0e272517:


    "Ni yo soy tan desalmado como para hacer la vista gorda."


translate english a3161_1b2a466f:


    "Y en el segundo en que Aoi ate cabos, sé que irá corriendo directo hacia allá."


translate english a3161_cc871af3:


    "Encuentro la caja de cartón deshaciéndose bajo la lluvia."


translate english a3161_2da284ad:


    "La abro y me asomo con vacilación..."


translate english a3161_fd65b7dc:


    "El gatito no está."


translate english a3161_aac362b8:


    "Con suerte solo significa que alguien más pasó y adoptó a la pobre criatura, pero..."


translate english a3161_af8199cd:


    "¿Debería pasarme por el manga café, por si acaso...?"


translate english a3161_c30265d9:


    "Justo entonces, mis pensamientos son interrumpidos por mi tono de llamada."


translate english a3161_7fbbdd4a:


    xy "\"Hello?\""


translate english a3161_0614e658:



    voice "voice/a31/6100010a01.opus"
    mx "\"Shinichi?! I'm at the manga cafe right now—\""


translate english a3161_d03e12a0:


    xy "\"What? You are?!\""


translate english a3161_ca43515d:


    "Claro. Miyuki también debe de estar buscando a Aoi."


translate english a3161_6a9cab81:


    "Eso es algo reconfortante, en realidad."


translate english a3161_6a716b27:


    "Debió de llegar a la misma conclusión que yo."


translate english a3161_cf22a1b5:


    xy "\"Where's Aoi?\""


translate english a3161_16350562:



    voice "voice/a31/6100020a01.opus"
    mx "\"The staff said she bolted outside just a few minutes ago.\""


translate english a3161_102d00b4:



    voice "voice/a31/6100030a01.opus"
    mx "\"And on her way out, she asked them if they allow pets.\""


translate english a3161_f57daf0e:


    xy "\"I knew it...\""


translate english a3161_fdc9693f:


    xy "\"I'm at the cardboard box. The cat's gone.\""


translate english a3161_6e30b2d2:



    voice "voice/a31/6100040a01.opus"
    mx "\"Damn it, Aoi!\""


translate english a3161_f7163e62:


    xy "\"H-Hey, c'mon, don't get mad at her for this! Nobody in their right mind would leave a kitten to die out here in the rain!\""


translate english a3161_dba60313:



    voice "voice/a31/6100050a01.opus"
    mx "\"I know that!\""


translate english a3161_e58dc913:


    xy "\"Just... stop shouting, okay? Take a breath.\""


translate english a3161_d09e50a0:



    voice "voice/a31/6100060a01.opus"
    mx "\"Do you really think Aoi's fit to look after a cat all by herself?\""


translate english a3161_f77bfb5c:


    "Para ser justos, Aoi apenas es una niña."


translate english a3161_57d1883d:


    "Probablemente podría cuidar de sí misma y de un gatito, suponiendo que—"


translate english a3161_0accd139:


    xy "\"......\""


translate english a3161_e47bb2a3:


    "Entonces recuerdo la imagen de ella parada distraídamente afuera de las rejas de la escuela, sin paraguas, esperando a Miyuki bajo la lluvia torrencial."



translate english a3161_d5749331:



    voice "voice/a31/6100070a01.opus"
    mx "\"We need to find her!\""


translate english a3161_66189257:


    xy "\"But where do we look?\""


translate english a3161_e66957b7:



    voice "voice/a31/6100080a01.opus"
    mx "\"Not sure. Any ideas?\""


translate english a3161_13317f24:


    xy "\"Uhhh... Her parents' house, maybe?\""


translate english a3161_bfdf3bf2:



    voice "voice/a31/6100090a01.opus"
    mx "\"I mean, I certainly HOPE that's where she went, but...\""



translate english a3161_f94ae500:


    "La implicación es clara, y no puedo negarlo."



translate english a3161_80d22344:


    "¿A dónde más podría ir Aoi?"


translate english a3161_649a1114:


    "El primer lugar que se me ocurre es lo alto de la azotea de la escuela, arriba sobre las escaleras."


translate english a3161_98cd42b0:


    "Pero no hay forma de que Aoi quiera estar afuera ahora, no con el gatito a cuestas."


translate english a3161_333912cc:


    "En ese caso, ¿qué nos queda?"


translate english a3161_7343ad56:


    "¿A dónde más iría...?"


translate english a3161_6c152e53:


    "........"



translate english a3161_b7eb1e2f:


    "...Es inútil."


translate english a3161_4727d2fd:


    "No se me ocurre ningún otro lugar."


translate english a3161_b53da66c:


    "No sé ni por dónde empezar..."


translate english a3161_529c4c73:


    "No tengo la menor pista..."


translate english a3161_60aee40a:


    "Dios, ¡soy tan jodidamente inútil...!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
