

translate english e1133_4abf640d:


    "Abre la puerta con llave y sale."


translate english e1133_726c8a86:


    "Empiezo a hacer lo mismo—"


translate english e1133_0b7a8462:


    xy "\"Espera... ¿Dónde están mis zapatos?\""


translate english e1133_7bc1c0f9:



    voice "voice/e11/3300010a01.opus"
    mx "\"Oh, lo siento. Los guardé.\""


translate english e1133_7f81a631:


    "Vuelve a entrar a toda prisa y saca mis zapatos del armario."


translate english e1133_9959d90d:


    "Muy típico de Miyuki... Le encanta mantener todo en su lugar adecuado..."


translate english e1133_a41204da:


    xy "\"Se siente algo nostálgico, caminar por las calles contigo así.\""


translate english e1133_7972f6a3:



    voice "voice/e11/3300020a01.opus"
    mx "\"Sí, supongo.\""


translate english e1133_5672a39c:


    "No sé por qué se siente así, pero así es..."


translate english e1133_ce6b84ec:


    "Mi cuerpo también está extrañamente pesado."


translate english e1133_6bcb7308:


    "Quizás necesito hacer más ejercicio..."


translate english e1133_4e37915a:



    voice "voice/e11/3300030b01.opus"
    xtl "\"¿Hmm?\""


translate english e1133_f3b938b9:



    voice "voice/e11/3300040b01.opus"
    xtl "\"¡Oh, oye, Shinichi! ¡De verdad eres tú!\""


translate english e1133_c91f21fa:


    "Yuutarou me llama desde la multitud."


translate english e1133_bc0f317f:



    voice "voice/e11/3300050b01.opus"
    xtl "\"Hombre... ¡Cuánto tiempo sin verte! ¡No has cambiado nada!\""


translate english e1133_14951534:


    xy "\"...¿Cuánto tiempo sin verte...?\""


translate english e1133_fbf9032f:



    voice "voice/e11/3300060b01.opus"
    xtl "\"¿Ya te sientes mejor estos días?\""


translate english e1133_4071a8d2:


    xy "\"¿De qué hablas?\""


translate english e1133_301c0b7d:



    voice "voice/e11/3300070b01.opus"
    xtl "\"¿Eh? Estuviste en el hospital, ¿no?\""


translate english e1133_c6c46999:



    voice "voice/e11/3300080b01.opus"
    xtl "\"¿Después del accidente de auto?\""


translate english e1133_1632c2b7:


    "...¿Qué accidente automovilístico?"


translate english e1133_8d64d656:



    voice "voice/e11/3300090a01.opus"
    mx "\"Oye, Akebono-kun.\""


translate english e1133_8782f996:



    voice "voice/e11/3300100b01.opus"
    xtl "\"¡¿Sí?! ¿En qué te puedo ayudar, Sone-san?\""


translate english e1133_05c0c947:



    voice "voice/e11/3300110a01.opus"
    mx "\"Estamos un poco apurados ahora mismo.\""


translate english e1133_f3cc9b0f:



    voice "voice/e11/3300120a01.opus"
    mx "\"Sé que probablemente están deseando ponerse al día, pero ¿puede esperar para después?\""


translate english e1133_9576361e:



    voice "voice/e11/3300130b01.opus"
    xtl "\"Oh, eh... claro.\""


translate english e1133_aef03bb9:



    voice "voice/e11/3300140b01.opus"
    xtl "\"Escucha... ¿Estás bien, Sone-san? No has ido a la escuela en—\""


translate english e1133_81f70289:



    voice "voice/e11/3300150a01.opus"
    mx "\"¡Shinichi! ¡Nos vamos!\""


translate english e1133_b497c73f:


    xy "\"Espera, pero—\""


translate english e1133_9ca89804:



    voice "voice/e11/3300160a01.opus"
    mx "\"¡Vamos! ¡Apúrate!\""


translate english e1133_f65da85f:


    "Miyuki empieza a arrastrarme lejos."


translate english e1133_eccdfe30:


    "Decido—"


translate english strings:


    old "Бежать с Миюки"
    new "Escaparme con Miyuki"


    old "Бежать с Ютаро"
    new "Escaparme con Yuutarou"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
