

translate english c6112_f6f8d697:


    "Mientras me pongo los zapatos junto a la puerta principal, oigo el tintineo de un cascabel, y lo siguiente que sé es que Eru está parado en mi camino."


translate english c6112_2576db78:


    xy "\"Hey, c'mon. Settle down, furball.\""


translate english c6112_afb9ae98:


    xy "\"What? You don't want me to go, is that it?\""


translate english c6112_510fd936:


    xy "\"Just relax. I'm not abandoning Aoi or anything, okay?\""


translate english c6112_3837fea5:


    "Eru me ignora."


translate english c6112_afa934cb:


    "El pequeño está completamente furioso."


translate english c6112_321fcde2:


    "Normalmente es tan bien portado, también..."


translate english strings:


    old "Принять это как знак"
    new "Toma esto como una señal"


    old "Всё равно пойти смотреть спектакль"
    new "Ve a ver la obra de todos modos"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
