

translate english a0122_c6c07529:


    xy "\"Hey, tú.\""


translate english a0122_0fbd1d2b:



    voice "voice/a01/2200010a02.opus"
    bm "\"¿Bip bip?\""


translate english a0122_507b91a0:


    "Su expresión sigue totalmente vacía."


translate english a0122_a820c3ae:


    "No tengo la menor idea de qué está pensando."


translate english a0122_68fbc31c:


    xy "\"¿Eso de... \"recargarse\" de antes? ¿De qué se trataba?\""


translate english a0122_19c3ae8e:



    voice "voice/a01/2200020a02.opus"
    bm "\"Recargando mi chispa.\""


translate english a0122_66ebc5f9:


    xy "\"Ok, bueno, ¿y qué es \"chispa\"?\""


translate english a0122_a5c4f284:



    voice "voice/a01/2200030a02.opus"
    bm "\"Sexo.\""


translate english a0122_0addfac6:



    voice "voice/a01/2200040b01.opus"
    xtl "\"¡¿SEEEXO?!\""


translate english a0122_2fada488:



    voice "voice/a01/2200050b01.opus"
    xtl "\"¡¿Estaban tirando aquí arriba?!\""


translate english a0122_25974e06:


    xy "\"¡No!\""


translate english a0122_0ada4e26:



    voice "voice/a01/2200060a02.opus"
    bm "\"Casi.\""


translate english a0122_1276f844:



    voice "voice/a01/2200070b01.opus"
    xtl "\"¡¿Qué demonios es \"casi\"?!\""


translate english a0122_cc9bd9a0:



    voice "voice/a01/2200080b01.opus"
    xtl "\"¡¿Cómo funciona eso?! ¡¿Dónde trazas la línea?! ¡¿No cuenta si es solo la puntita?! ¡¿Está bien si solo entra hasta la mitad?!\""


translate english a0122_0df5af4b:


    xy "\"¡No, no está bien!\""


translate english a0122_237c797b:



    voice "voice/a01/2200090b01.opus"
    xtl "\"¿No?\""


translate english a0122_b05bea8f:



    voice "voice/a01/2200100a02.opus"
    bm "\"¿No?\""


translate english a0122_ac352380:


    "No puedo creer que tenga que explicar esto..."


translate english a0122_3f651305:



    voice "voice/a01/2200110a02.opus"
    bm "\"¿Bip bip...?\""


translate english a0122_dc4e79c9:



    voice "voice/a01/2200120a02.opus"
    bm "\"Tienes que activar la bandera de evento.\""


translate english a0122_1ed91548:



    voice "voice/a01/2200130a02.opus"
    bm "\"Necesitas subir tus puntos de afecto o fallarás.\""


translate english a0122_630878df:


    xy "\"Esto no es un videojuego.\""


translate english a0122_3258faec:



    voice "voice/a01/2200140a02.opus"
    bm "\"¡Entendido!\""


translate english a0122_ca297501:


    "Alza la mano recta hacia el aire como una antena buscando ondas de radio."


translate english a0122_441e2994:



    voice "voice/a01/2200150a02.opus"
    bm "Aoi es una opción romántica."



translate english a0122_e6fcc1cd:



    voice "voice/a01/2200160a02.opus"
    bm "\"Y este mundo es un videojuego.\""


translate english a0122_e617295d:


    "Hay un término para gente así: \"gamer brain.\""


translate english a0122_908423d7:


    "No estoy seguro de cuál era la definición original, pero hoy en día lo usamos para referirnos a alguien que no distingue entre los juegos y la realidad."


translate english a0122_a639627e:



    voice "voice/a01/2200170a02.opus"
    bm "\"Pero...\""


translate english a0122_35eb978b:



    voice "voice/a01/2200180a02.opus"
    bm "\"Tu amiga de la infancia del pelo largo y oscuro es la heroína principal.\""


translate english a0122_0b6eda6f:



    voice "voice/a01/2200190a02.opus"
    bm "\"La ruta de Aoi tendrá que esperar.\""


translate english a0122_5237f7cb:



    voice "voice/a01/2200200a02.opus"
    bm "\"Adiós.\""


translate english a0122_b23101a8:


    xy "\"¿Qué? ¡Hey, espera—!\""


translate english a0122_ee4ba67e:


    "Pero me ignora y baja corriendo las escaleras."


translate english a0122_dfcd2f32:



    voice "voice/a01/2200210b01.opus"
    xtl "\"Haah...\""


translate english a0122_81bc5101:



    voice "voice/a01/2200220b01.opus"
    xtl "\"Esa chica siempre es todo un enigma.\""


translate english a0122_349ab82b:


    xy "\"¿Cómo que \"siempre\"?\""


translate english a0122_f47b02cc:



    voice "voice/a01/2200230b01.opus"
    xtl "\"Más importante, ¡necesito que me expliques! ¿Por qué demonios salió Sone-san hecha una furia?\""


translate english a0122_c95fe62e:



    voice "voice/a01/2200240b01.opus"
    xtl "\"¡Y ahora también tienes a Mukou! ¡Maldito! ¿Eres un normie? ¡¿Eres un maldito normie?!\""


translate english a0122_1016ffd2:


    xy "\"Espera un segundo...\""


translate english a0122_75ae16ec:


    xy "\"¿Tú... Tú la CONOCES?\""


translate english a0122_ea0aeaeb:



    voice "voice/a01/2200250b01.opus"
    xtl "\"¿Qué? ¿En serio?\""


translate english a0122_c71b4dd9:



    voice "voice/a01/2200260b01.opus"
    xtl "\"¿Esa despistada? Esa era Mukou Aoi.\""


translate english a0122_f20a710b:



    voice "voice/a01/2200270b01.opus"
    xtl "\"¡Está en nuestra clase, amigo!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
