

translate english a0122_c6c07529:


    xy "\"Hey, you.\""


translate english a0122_0fbd1d2b:



    voice "voice/a01/2200010a02.opus"
    bm "\"Boop boop?\""


translate english a0122_507b91a0:


    "Su expresión sigue totalmente vacía."


translate english a0122_a820c3ae:


    "No tengo la menor idea de qué está pensando."


translate english a0122_68fbc31c:


    xy "\"That whole... 'recharging' thing from earlier? What was that about?\""


translate english a0122_19c3ae8e:



    voice "voice/a01/2200020a02.opus"
    bm "\"Recharging my zappy.\""


translate english a0122_66ebc5f9:


    xy "\"Okay, well, what's 'zappy'?\""


translate english a0122_a5c4f284:



    voice "voice/a01/2200030a02.opus"
    bm "\"Sex.\""


translate english a0122_0addfac6:



    voice "voice/a01/2200040b01.opus"
    xtl "\"SEEEEX?!\""


translate english a0122_2fada488:



    voice "voice/a01/2200050b01.opus"
    xtl "\"You guys were screwing up here?!\""


translate english a0122_25974e06:


    xy "\"No!\""


translate english a0122_0ada4e26:



    voice "voice/a01/2200060a02.opus"
    bm "\"Almost.\""


translate english a0122_1276f844:



    voice "voice/a01/2200070b01.opus"
    xtl "\"What the hell is 'almost'?!\""


translate english a0122_cc9bd9a0:



    voice "voice/a01/2200080b01.opus"
    xtl "\"How does that work?! Where do you draw the line?! Does it not count if it's just the tip?! Is it cool if you only get like halfway in?!\""


translate english a0122_0df5af4b:


    xy "\"No, it's not cool!\""


translate english a0122_237c797b:



    voice "voice/a01/2200090b01.opus"
    xtl "\"It's not?\""


translate english a0122_b05bea8f:



    voice "voice/a01/2200100a02.opus"
    bm "\"It's not?\""


translate english a0122_ac352380:


    "No puedo creer que tenga que explicar esto..."


translate english a0122_3f651305:



    voice "voice/a01/2200110a02.opus"
    bm "\"Boop boop...?\""


translate english a0122_dc4e79c9:



    voice "voice/a01/2200120a02.opus"
    bm "\"You have to trigger the event flag.\""


translate english a0122_1ed91548:



    voice "voice/a01/2200130a02.opus"
    bm "\"You need to raise your affection points or you'll fail.\""


translate english a0122_630878df:


    xy "\"This isn't a video game.\""


translate english a0122_3258faec:



    voice "voice/a01/2200140a02.opus"
    bm "\"Got it!\""


translate english a0122_ca297501:


    "Alza la mano recta hacia el aire como una antena buscando ondas de radio."


translate english a0122_441e2994:



    voice "voice/a01/2200150a02.opus"
    bm "Aoi es una opción romántica."



translate english a0122_e6fcc1cd:



    voice "voice/a01/2200160a02.opus"
    bm "\"And this world is a video game.\""


translate english a0122_e617295d:


    "Hay un término para gente así: \"gamer brain.\""


translate english a0122_908423d7:


    "No estoy seguro de cuál era la definición original, pero hoy en día lo usamos para referirnos a alguien que no distingue entre los juegos y la realidad."


translate english a0122_a639627e:



    voice "voice/a01/2200170a02.opus"
    bm "\"But...\""


translate english a0122_35eb978b:



    voice "voice/a01/2200180a02.opus"
    bm "\"Your childhood friend with the long, dark hair is the main heroine.\""


translate english a0122_0b6eda6f:



    voice "voice/a01/2200190a02.opus"
    bm "\"Aoi's route will have to wait.\""


translate english a0122_5237f7cb:



    voice "voice/a01/2200200a02.opus"
    bm "\"Bye-bye.\""


translate english a0122_b23101a8:


    xy "\"What? Hey, wait—!\""


translate english a0122_ee4ba67e:


    "Pero me ignora y baja corriendo las escaleras."


translate english a0122_dfcd2f32:



    voice "voice/a01/2200210b01.opus"
    xtl "\"Haah...\""


translate english a0122_81bc5101:



    voice "voice/a01/2200220b01.opus"
    xtl "\"That girl's always such an enigma.\""


translate english a0122_349ab82b:


    xy "\"What do you mean, always?\""


translate english a0122_f47b02cc:



    voice "voice/a01/2200230b01.opus"
    xtl "\"More importantly, I need you to explain! Why the heck did Sone-san storm off like that?\""


translate english a0122_c95fe62e:



    voice "voice/a01/2200240b01.opus"
    xtl "\"And now you've got Mukou, to boot? You punk! Are you a normie? Are you a goddamn normie?!\""


translate english a0122_1016ffd2:


    xy "\"Wait a second...\""


translate english a0122_75ae16ec:


    xy "\"Do... Do you KNOW her?\""


translate english a0122_ea0aeaeb:



    voice "voice/a01/2200250b01.opus"
    xtl "\"What? Are you serious?\""


translate english a0122_c71b4dd9:



    voice "voice/a01/2200260b01.opus"
    xtl "\"That ditz? That was Mukou Aoi.\""


translate english a0122_f20a710b:



    voice "voice/a01/2200270b01.opus"
    xtl "\"She's in our class, dude!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
