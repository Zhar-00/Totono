

translate english b5162_206b769c:


    "Por más que buscamos..."


translate english b5162_5c2f2809:


    "...el teléfono de Aoi no aparece por ningún lado."


translate english b5162_4aa88fa7:


    xy "\"Empiezo a pensar que debes haberlo tirado en otro lado.\""


translate english b5162_61ceec8f:



    voice "voice/b51/6200020a02.opus"
    aoi "\"Pero Aoi... ya buscó en todos los demás lugares...\""


translate english b5162_4973281d:


    xy "\"¡Eru, cállate un segundo!\""


translate english b5162_f3d9dcac:


    xy "\"Acabas de cenar, ¿no?\""


translate english b5162_54cebff3:



    voice "voice/b51/6200050a02.opus"
    aoi "\"No... No es eso.\""


translate english b5162_d0b47ae2:


    "De repente, Eru sale disparado de la sala."


translate english b5162_d9a807fc:


    "Alarmado, sigo al gatito hasta la puerta principal, donde empieza a arañar como loco para salir."


translate english b5162_12c5de83:


    aoi "\"¿Está... allá afuera?\""


translate english b5162_0a8c2459:


    "Abro la puerta con cuidado."


translate english b5162_8bbf560a:


    "Al instante siguiente, Eru se lanza directo a los arbustos."


translate english b5162_0db88afa:


    "De inmediato lo sigo."


translate english b5162_34cdc864:


    xy "\"¡Oh! ¡Ahí está!\""


translate english b5162_2a3a7700:


    "El teléfono de Aoi está justo ahí, bajo los arbustos."


translate english b5162_c3634ea2:


    "Ahora que lo pienso..."


translate english b5162_f54fd051:


    "Creo que este es el lugar donde Aoi casi se cayó anoche..."


translate english b5162_fa834d55:


    xy "\"¡Oye, Aoi! ¿No es este tu teléfono?\""


translate english b5162_ec30aa32:



    voice "voice/b51/6200080a02.opus"
    aoi "\"¡Sí! Sin duda, ese es mío...\""


translate english b5162_b887c4ce:



    voice "voice/b51/6200090a02.opus"
    aoi "\"Buen trabajo, Eru.\""


translate english b5162_d364255f:



    voice "voice/b51/6200100a02.opus"
    aoi "\"Gra... cias...\""


translate english b5162_3b7abc32:


    xy "\"¿Uah...? ¿Aoi?\""


translate english b5162_6eca16de:


    xy "\"¿Aoi, estás bien? ¡Estás blanca como hoja de papel!\""


translate english b5162_c937d8e9:



    voice "voice/b51/6200110a02.opus"
    aoi "\"Aoi está bien...\""


translate english b5162_110ec41e:



    voice "voice/b51/6200120a02.opus"
    aoi "\"Mientras... Aoi tenga este teléfono...\""


translate english b5162_8c41f18b:



    voice "voice/b51/6200130a02.opus"
    aoi "\"Aoi puede... recibir transmisiones... de Dios.\""


translate english b5162_3eb08202:



    voice "voice/b51/6200140a02.opus"
    aoi "\"Aoi no va... a olvidar.\""


translate english b5162_40700f38:



    voice "voice/b51/6200150a02.opus"
    aoi "\"Ahora Dios... vendrá al teléfono...\""


translate english b5162_36cf489d:


    "Empieza a hacer una llamada."


translate english b5162_6dd5acbd:



    voice "voice/b51/6200160a02.opus"
    aoi "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english b5162_d95837b3:



    voice "voice/b51/6200170a02.opus"
    aoi "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english b5162_1cb5bb01:


    "But it doesn't seem like \"God\"vaya a contestar."


translate english b5162_35275caa:


    "Su teléfono sigue sin servicio."


translate english b5162_a213e664:


    "Su señal no pasa."


translate english b5162_dc885c9e:



    voice "voice/b51/6200180a02.opus"
    aoi "\"Contesta...\""


translate english b5162_50fbf8c8:



    voice "voice/b51/6200190a02.opus"
    aoi "\"¡Contesta el teléfono, Dios...!\""


translate english b5162_56d5617d:


    "Me alegra que hayamos encontrado su teléfono."


translate english b5162_43a30ad5:


    "Pero, como comentamos ayer de camino a casa, no le servirá de nada a menos que Dios conteste su llamada."


translate english b5162_8c0b1997:


    "Al menos, eso es lo que ella cree, de todos modos."


translate english b5162_9c0b0c1c:


    "¿Qué puedo hacer para ayudarla?"


translate english b5162_9601a136:


    "¿Cómo puedo ayudarla a vivir feliz para siempre?"


translate english b5162_9c195528:


    "...Espera... ¿Feliz para siempre...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
