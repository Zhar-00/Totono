

translate english a6161_2920a8be:


    "Intento jugar videojuegos, pero no puedo concentrarme."


translate english a6161_bb15e7ec:


    "Intento ver televisión, pero me raspa los oídos."


translate english a6161_b596470a:


    "Me recuesto en el sofá de la sala."


translate english a6161_e43d1196:


    "Puedo oír el tictac del reloj."


translate english a6161_085182dc:


    "El tiempo pasa, un segundo a la vez."


translate english a6161_c072ec21:


    "Sería mucho más fácil si pudiera desmayarme."


translate english a6161_08b6ef2f:


    "Pero el sueño me elude."


translate english a6161_6b27dda1:


    "Lo único que siento es ira, acumulándose sin parar."


translate english a6161_0d34575d:


    "Cuanto más tiempo paso aquí tirado sin hacer nada, más siento que voy a perder la cabeza."


translate english a6161_816835b6:


    "Tomo mi teléfono y me pongo de pie."


translate english a6161_febbec1a:


    "Luego me dirijo a la puerta y—"


translate english a6161_0accd139:


    xy "\"......\""


translate english a6161_1babec08:


    "Antes de poder salir de casa, me detengo en seco."


translate english a6161_29add96c:


    "El boleto sigue tirado en la mesita de centro donde lo dejé."


translate english a6161_06d96eac:


    "Solo faltan dos horas para que empiece la función."


translate english a6161_837daa6b:


    "Decido no volver a recogerlo."


translate english a6161_e5ffbe05:


    "En cambio, salgo al pueblo."


translate english a6161_6ae0bdd1:


    xy "\"Hey, Yuutarou? You busy?\""


translate english a6161_0282aecc:


    xy "\"Wanna hang out?\""


translate english a6161_97d73408:



    voice "voice/a61/6100010b01.opus"
    xtl "\"I gotta work tonight. I'm covering Ryuujirou's shift.\""


translate english a6161_7876db23:



    voice "voice/a61/6100020b01.opus"
    xtl "\"Sorry!\""


translate english a6161_11f98605:


    xy "\"Nah, it's cool. Just thought I'd ask.\""


translate english a6161_d6969110:



    voice "voice/a61/6100030b01.opus"
    xtl "\"Wait... Isn't Sone-san's performance—\""


translate english a6161_c52b50c8:


    xy "\"Anyway, talk to you later!\""


translate english a6161_64eb418d:


    xy "\"...Fuck.\""



translate english a6161_0ef1a27d:


    "No es culpa de Yuutarou."


translate english a6161_01ac69fd:


    "Lo sé."


translate english a6161_104777a7:


    "Deambulo por las calles sin rumbo."


translate english a6161_909f9b6e:


    "Pero sin importar a dónde vaya..."


translate english a6161_53c3e76a:


    "Cada calle..."


translate english a6161_8006d0f1:


    "Cada esquina..."


translate english a6161_4b438245:


    "Cada tienda..."


translate english a6161_862f78f9:


    "Todo está manchado con mis recuerdos de Miyuki y Aoi."


translate english a6161_5ded9e9d:


    "No puedo sacarlos de mi cabeza."


translate english a6161_733dc76d:


    "Mientras tanto, mi frustración crece."


translate english a6161_083a28a0:


    "Necesito desahogarme... pero ¿cómo...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
