

translate english e2191b_b67e6c9d:


    xy "\"...No, espera.\""


translate english e2191b_0baa1ab7:


    xy "\"¿Había un gato aquí justo ahora...?\""


translate english e2191b_28b5e00e:



    voice "voice/e21/91b00010a01.opus"
    mx "\"¿Un gato? ¿Aquí?\""


translate english e2191b_59ac931e:


    xy "\"Sí, uno negrito pequeño.\""


translate english e2191b_cc74a245:



    voice "voice/e21/91b00020a01.opus"
    mx "\"Debes estar imaginando cosas.\""


translate english e2191b_2e6ee42f:


    xy "\"No, estoy bastante seguro—\""


translate english e2191b_bad0f203:



    voice "voice/e21/91b00030a01.opus"
    mx "\"¡Ah, eso me recuerda!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
