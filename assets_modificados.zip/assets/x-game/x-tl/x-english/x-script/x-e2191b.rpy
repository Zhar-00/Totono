

translate english e2191b_b67e6c9d:


    xy "\"...No, hold on.\""


translate english e2191b_0baa1ab7:


    xy "\"Was there a cat here just now...?\""


translate english e2191b_28b5e00e:



    voice "voice/e21/91b00010a01.opus"
    mx "\"A cat? Here?\""


translate english e2191b_59ac931e:


    xy "\"Yeah, a little black one.\""


translate english e2191b_cc74a245:



    voice "voice/e21/91b00020a01.opus"
    mx "\"You must be imagining things.\""


translate english e2191b_2e6ee42f:


    xy "\"No, I'm pretty sure—\""


translate english e2191b_bad0f203:



    voice "voice/e21/91b00030a01.opus"
    mx "\"Oh, that reminds me!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
