

translate english c5172_e3ab0908:


    "Una vez que pasamos todas las calles concurridas, nuestro paso se ralentiza."


translate english c5172_612283d5:



    voice "voice/c51/7200010a02.opus"
    aoi "\"Boop boop... boop boop... boop... boop boop boop...\""


translate english c5172_e9b0f5d2:


    xy "\"Eso es diferente.\""


translate english c5172_7480bb45:



    voice "voice/c51/7200020a02.opus"
    aoi "\"¿Boop boop? ¿Qué es diferente?\""


translate english c5172_6f58bcaf:


    "Aoi ladea la cabeza hacia mí."


translate english c5172_d81bc7b9:


    "Aparentemente no se dio cuenta de que había estado tarareando."


translate english c5172_474ae8ff:


    xy "\"Oh, nada.\""


translate english c5172_3a95aba7:



    voice "voice/c51/7200030a02.opus"
    aoi "\"¡¿Nada?!\""


translate english c5172_6c52563c:



    voice "voice/c51/7200040a02.opus"
    aoi "\"¡Aoi quiere saberlo!\""


translate english c5172_0236092c:


    xy "\"No pasa nada. No te preocupes.\""


translate english c5172_ea30802f:



    voice "voice/c51/7200050a02.opus"
    aoi "\"¡No es nada!\""


translate english c5172_17528c14:


    xy "\"¡No es nada serio!\""


translate english c5172_d6920168:



    voice "voice/c51/7200060a02.opus"
    aoi "\"Boop boop boop...\""


translate english c5172_d298d143:


    "Se ve bastante disgustada."


translate english c5172_cd97d2e5:


    "Hombre, sus expresiones son todas tan vivaces y lindas..."


translate english c5172_95b098ef:



    voice "voice/c51/7200070a02.opus"
    aoi "\"¿De qué te ríes?\""


translate english c5172_ea8ce668:


    xy "\"¿Huh? Oh, nada. ¡Perdón!\""


translate english c5172_19ddaaf4:



    voice "voice/c51/7200080a02.opus"
    aoi "\"...Estás raro hoy, Shinichi.\""


translate english c5172_e0f5e1c3:


    xy "\"Solo estaba pensando... Te has vuelto mucho más normal últimamente.\""


translate english c5172_fc23831c:



    voice "voice/c51/7200090a02.opus"
    aoi "\"¿Normal...?\""


translate english c5172_dd030af7:


    xy "\"Ya sabes. Te enojas cuando algo te molesta... Canturreas cuando estás feliz... Cosas así.\""


translate english c5172_a34f26a3:



    voice "voice/c51/7200100a02.opus"
    aoi "\"¿Canturrear...?\""


translate english c5172_70ab0010:


    xy "\"Sí, estabas canturreando hace un momento. Ni siquiera te diste cuenta, ¿verdad?\""


translate english c5172_54503ebc:



    voice "voice/c51/7200110a02.opus"
    aoi "\"¡Boop boop...!\""


translate english c5172_a90a050f:


    "De repente, Aoi se sonroja."


translate english c5172_f3ac5330:



    voice "voice/c51/7200120a02.opus"
    aoi "\"¡A-Aoi no estaba canturreando...!\""


translate english c5172_d867342c:


    xy "\"Sí lo estabas.\""


translate english c5172_1c32397c:



    voice "voice/c51/7200130a02.opus"
    aoi "\"¡Boop boop...!\""


translate english c5172_d14b4cc8:


    "Lucha por pensar en un contraargumento."


translate english c5172_20d6c6ab:



    voice "voice/c51/7200140a02.opus"
    aoi "\"¿Está... está Aoi...\""


translate english c5172_7e0437b4:



    voice "voice/c51/7200150a02.opus"
    aoi "\"...teniendo más glitches?\""


translate english c5172_4b028de1:


    xy "\"Eh, no creo que sea algo malo.\""


translate english c5172_88a17a9c:


    xy "\"Si acaso, es normal.\""


translate english c5172_dbac5e69:



    voice "voice/c51/7200160a02.opus"
    aoi "\"¿Lo es...?\""


translate english c5172_ac829a69:


    xy "\"Además... ya sabes...\""


translate english c5172_0a000810:


    xy "\"Tuvimos toda esa conversación en el techo esa noche.\""


translate english c5172_ebc66892:


    xy "\"Puedes tener tantos glitches como quieras.\""


translate english c5172_6f90cdb3:



    voice "voice/c51/7200170a02.opus"
    aoi "\"¿Tú también estás teniendo glitches?\""


translate english c5172_2f9a3bbd:


    xy "\"¿Qué? No—\""


translate english c5172_5559704d:



    voice "voice/c51/7200180a02.opus"
    aoi "\"Pero Shinichi... estás sonrojado.\""


translate english c5172_3fd7e7c4:



    voice "voice/c51/7200190a02.opus"
    aoi "\"¡Es un glitch!\""


translate english c5172_f4a833b5:


    xy "\"¡M-Métete en lo tuyo!\""


translate english c5172_109c0f8f:


    "Aoi sonríe, y no puedo evitar sonreír también."


translate english c5172_c025c733:


    xy "\"Vámonos.\""


translate english c5172_39a7f537:



    voice "voice/c51/7200200a02.opus"
    aoi "\"Shinichi...\""


translate english c5172_67dff208:


    xy "\"¿Hm?\""


translate english c5172_c41a417e:



    voice "voice/c51/7200210a02.opus"
    aoi "\"Este...\""


translate english c5172_b42e08b0:


    "Extiende una mano en silencio."


translate english c5172_ecf30723:


    "Sin siquiera detenerme a pensar, extiendo la mano y entrelazo mis dedos con los suyos."


translate english c5172_2a60d606:


    "Olvídalo. No me importa cómo nos vea el mundo."


translate english c5172_94b9ce72:


    "Quizás los glitches de Aoi se me han contagiado después de todo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
