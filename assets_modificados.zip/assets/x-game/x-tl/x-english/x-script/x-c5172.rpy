

translate english c5172_e3ab0908:


    "Una vez que pasamos todas las calles concurridas, nuestro paso se ralentiza."


translate english c5172_612283d5:



    voice "voice/c51/7200010a02.opus"
    aoi "\"Boop boop... boop boop... boop... boop boop boop...\""


translate english c5172_e9b0f5d2:


    xy "\"That's different.\""


translate english c5172_7480bb45:



    voice "voice/c51/7200020a02.opus"
    aoi "\"Boop boop? What's different?\""


translate english c5172_6f58bcaf:


    "Aoi ladea la cabeza hacia mí."


translate english c5172_d81bc7b9:


    "Aparentemente no se dio cuenta de que había estado tarareando."


translate english c5172_474ae8ff:


    xy "\"Oh, nothing.\""


translate english c5172_3a95aba7:



    voice "voice/c51/7200030a02.opus"
    aoi "\"Nothing?!\""


translate english c5172_6c52563c:



    voice "voice/c51/7200040a02.opus"
    aoi "\"Aoi wants to know!\""


translate english c5172_0236092c:


    xy "\"It's fine. Don't worry about it.\""


translate english c5172_ea30802f:



    voice "voice/c51/7200050a02.opus"
    aoi "\"It's not fine!\""


translate english c5172_17528c14:


    xy "\"It's nothing serious!\""


translate english c5172_d6920168:



    voice "voice/c51/7200060a02.opus"
    aoi "\"Boop boop boop...\""


translate english c5172_d298d143:


    "Se ve bastante disgustada."


translate english c5172_cd97d2e5:


    "Hombre, sus expresiones son todas tan vivaces y lindas..."


translate english c5172_95b098ef:



    voice "voice/c51/7200070a02.opus"
    aoi "\"What are you grinning at?\""


translate english c5172_ea8ce668:


    xy "\"Huh? Oh, nothing. Sorry!\""


translate english c5172_19ddaaf4:



    voice "voice/c51/7200080a02.opus"
    aoi "\"...You're acting weird today, Shinichi.\""


translate english c5172_e0f5e1c3:


    xy "\"I was just thinking... You've gotten a lot more normal lately.\""


translate english c5172_fc23831c:



    voice "voice/c51/7200090a02.opus"
    aoi "\"Normal...?\""


translate english c5172_dd030af7:


    xy "\"Oh, you know. You get mad when something upsets you... You hum when you're happy... Stuff like that.\""


translate english c5172_a34f26a3:



    voice "voice/c51/7200100a02.opus"
    aoi "\"Hum...?\""


translate english c5172_70ab0010:


    xy "\"Yeah, you were humming just now. You didn't even realize it, did you?\""


translate english c5172_54503ebc:



    voice "voice/c51/7200110a02.opus"
    aoi "\"Boop boop...!\""


translate english c5172_a90a050f:


    "De repente, Aoi se sonroja."


translate english c5172_f3ac5330:



    voice "voice/c51/7200120a02.opus"
    aoi "\"A-Aoi wasn't humming...!\""


translate english c5172_d867342c:


    xy "\"Yes you were.\""


translate english c5172_1c32397c:



    voice "voice/c51/7200130a02.opus"
    aoi "\"Boop boop...!\""


translate english c5172_d14b4cc8:


    "Lucha por pensar en un contraargumento."


translate english c5172_20d6c6ab:



    voice "voice/c51/7200140a02.opus"
    aoi "\"Is... Is Aoi...\""


translate english c5172_7e0437b4:



    voice "voice/c51/7200150a02.opus"
    aoi "\"...getting more glitchy?\""


translate english c5172_4b028de1:


    xy "\"Eh, I don't think it's a bad thing.\""


translate english c5172_88a17a9c:


    xy "\"If anything, it's normal.\""


translate english c5172_dbac5e69:



    voice "voice/c51/7200160a02.opus"
    aoi "\"It is...?\""


translate english c5172_ac829a69:


    xy "\"Besides... y'know...\""


translate english c5172_0a000810:


    xy "\"We had that whole conversation on the roof that night.\""


translate english c5172_ebc66892:


    xy "\"You're allowed to get as glitchy as you want.\""


translate english c5172_6f90cdb3:



    voice "voice/c51/7200170a02.opus"
    aoi "\"Are you glitching out too?\""


translate english c5172_2f9a3bbd:


    xy "\"What? No—\""


translate english c5172_5559704d:



    voice "voice/c51/7200180a02.opus"
    aoi "\"But Shinichi... you're blushing.\""


translate english c5172_3fd7e7c4:



    voice "voice/c51/7200190a02.opus"
    aoi "\"It's a glitch!\""


translate english c5172_f4a833b5:


    xy "\"M-Mind your own business!\""


translate english c5172_109c0f8f:


    "Aoi sonríe, y no puedo evitar sonreír también."


translate english c5172_c025c733:


    xy "\"Let's go.\""


translate english c5172_39a7f537:



    voice "voice/c51/7200200a02.opus"
    aoi "\"Shinichi...\""


translate english c5172_67dff208:


    xy "\"Hm?\""


translate english c5172_c41a417e:



    voice "voice/c51/7200210a02.opus"
    aoi "\"Umm...\""


translate english c5172_b42e08b0:


    "Extiende una mano en silencio."


translate english c5172_ecf30723:


    "Sin siquiera detenerme a pensar, extiendo la mano y entrelazo mis dedos con los suyos."


translate english c5172_2a60d606:


    "Olvídalo. No me importa cómo nos vea el mundo."


translate english c5172_94b9ce72:


    "Quizás los glitches de Aoi se me han contagiado después de todo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
