

translate english b6142_fdf45a11:


    "Si cierro los ojos, puedo imaginarlo..."


translate english b6142_66653e24:


    "Recuerdos de una amistad que nunca podré recuperar."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
