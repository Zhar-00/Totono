

translate english a5172_26c2f118:



    voice "voice/a51/7200010a01.opus"
    mx "\"Entonces supongo que no vamos a necesitar esto.\""


translate english a5172_aff7641f:


    xy "\"¿¡Ese es el teléfono de Aoi!?\""


translate english a5172_149958ce:



    voice "voice/a51/7200020a02.opus"
    aoi "\"¿¡Eh!?\""


translate english a5172_7e713084:


    "Aoi deja escapar un jadeo audible desde debajo de mi cama."


translate english a5172_7f77933a:


    "Mi estómago se congela."


translate english a5172_ad677408:


    "Pero Miyuki continúa."


translate english a5172_90ae7710:



    voice "voice/a51/7200030a01.opus"
    mx "\"Presentí que era de ella.\""


translate english a5172_b01e8a7f:


    xy "\"¿Dónde lo encontraste?\""


translate english a5172_5c0bfba2:



    voice "voice/a51/7200040a01.opus"
    mx "\"Estaba tirado justo afuera del béisbol.\""


translate english a5172_d8bcdaba:



    voice "voice/a51/7200050a01.opus"
    mx "\"Vine a devolverlo, pero... Si no está aquí, supongo que me iré a casa...\""


translate english a5172_91461390:



    voice "voice/a51/7200060a02.opus"
    aoi "\"¡No!\""


translate english a5172_92c1d66e:


    xy "\"¡Yo se lo guardo!\""


translate english a5172_3ecacd53:


    "Subo un poco la voz para ahogar el susurro de Aoi."


translate english a5172_53f571ba:


    xy "\"¡De todos modos, probablemente volverá por sus zapatos tarde o temprano!\""


translate english a5172_b610adff:



    voice "voice/a51/7200070a01.opus"
    mx "\"Mmmm... Supongo que tiene sentido.\""


translate english a5172_5870656b:



    voice "voice/a51/7200080a01.opus"
    mx "\"Toma.\""


translate english a5172_76f15459:


    xy "\"Gracias...\""


translate english a5172_e002a7dc:



    voice "voice/a51/7200090a01.opus"
    mx "\"¡Ups! Qué tonta, ¡se me cayó!\""


translate english a5172_e50c1093:


    "El teléfono cae al suelo, se desliza por el piso y queda debajo de la cama."



translate english a5172_74fbc23d:



    voice "voice/a51/7200100a01.opus"
    mx "\"¿Estás aquí abajo, me pregunto?\""


translate english a5172_d95aeefa:


    "Miyuki se agacha lentamente hasta el suelo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
