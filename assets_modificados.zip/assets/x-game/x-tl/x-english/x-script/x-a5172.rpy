

translate english a5172_26c2f118:



    voice "voice/a51/7200010a01.opus"
    mx "\"Then I guess we won't be needing this.\""


translate english a5172_aff7641f:


    xy "\"Is that Aoi's phone?!\""


translate english a5172_149958ce:



    voice "voice/a51/7200020a02.opus"
    aoi "\"Huh?!\""


translate english a5172_7e713084:


    "Aoi deja escapar un jadeo audible desde debajo de mi cama."


translate english a5172_7f77933a:


    "Mi estómago se congela."


translate english a5172_ad677408:


    "Pero Miyuki continúa."


translate english a5172_90ae7710:



    voice "voice/a51/7200030a01.opus"
    mx "\"I had a feeling this was hers.\""


translate english a5172_b01e8a7f:


    xy "\"Where did you find it?\""


translate english a5172_5c0bfba2:



    voice "voice/a51/7200040a01.opus"
    mx "\"It was lying just outside the batting cages.\""


translate english a5172_d8bcdaba:



    voice "voice/a51/7200050a01.opus"
    mx "\"I came here to give it back, but... If she's not here, I guess I'll just go home—\""


translate english a5172_91461390:



    voice "voice/a51/7200060a02.opus"
    aoi "\"Don't!\""


translate english a5172_92c1d66e:


    xy "\"I'll hold onto it for her!\""


translate english a5172_3ecacd53:


    "Subo un poco la voz para ahogar el susurro de Aoi."


translate english a5172_53f571ba:


    xy "\"She'll probably be back for her shoes sooner or later anyway!\""


translate english a5172_b610adff:



    voice "voice/a51/7200070a01.opus"
    mx "\"Hmmm... I guess that makes sense.\""


translate english a5172_5870656b:



    voice "voice/a51/7200080a01.opus"
    mx "\"Here you go.\""


translate english a5172_76f15459:


    xy "\"Thank you—\""


translate english a5172_e002a7dc:



    voice "voice/a51/7200090a01.opus"
    mx "\"Whoopsie daisy! Silly me, I dropped it!\""


translate english a5172_e50c1093:


    "El teléfono cae al suelo, se desliza por el piso y queda debajo de la cama."



translate english a5172_74fbc23d:



    voice "voice/a51/7200100a01.opus"
    mx "\"Are you under here, I wonder?\""


translate english a5172_d95aeefa:


    "Miyuki se agacha lentamente hasta el suelo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
