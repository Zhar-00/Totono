

translate english e2233a_df0532f1:



    voice "voice/e22/33a00010a01.opus"
    mx "\"Nngh...\""


translate english e2233a_57b9d590:


    "Miyuki se sube para sentarse encima del pupitre y cruza las piernas."


translate english e2233a_3a2ae287:


    "Es, eh... una vista muy sexy, por decirlo así."


translate english e2233a_2a28200f:


    "Su falda ondea con la brisa, y siento que mi mirada se siente atraída magnéticamente hacia sus piernas..."


translate english e2233a_9faefeb6:



    voice "voice/e22/33a00020a01.opus"
    mx "\"Nice view, huh?\""


translate english e2233a_3d82f992:


    xy "\"I wasn't looking!\""


translate english e2233a_65db4b15:



    voice "voice/e22/33a00030a01.opus"
    mx "\"...What 'view' did you think I meant?\""



translate english e2233a_d9fb81d2:


    xy "\"Huh? Oh, uh... Hahahahaha...\""


translate english e2233a_8fd7aec8:



    voice "voice/e22/33a00040a01.opus"
    mx "\"Well, whatever.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
