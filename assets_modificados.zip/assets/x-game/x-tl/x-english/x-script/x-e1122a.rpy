

translate english e1122a_df1ff6b7:


    xy "\"Claro que podría.\""


translate english e1122a_ae39402e:


    xy "\"Siempre te amaré.\""


translate english e1122a_8f500d25:



    voice "voice/e11/22a00010a01.opus"
    mx "\"Gracias... Eso significa mucho...\""


translate english e1122a_c0577011:



    voice "voice/e11/22a00020a01.opus"
    mx "\"¿Podrías decirlo otra vez?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
