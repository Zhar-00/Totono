

translate english e1122a_df1ff6b7:


    xy "\"Sure I could.\""


translate english e1122a_ae39402e:


    xy "\"I'll always love you.\""


translate english e1122a_8f500d25:



    voice "voice/e11/22a00010a01.opus"
    mx "\"Thanks... That means a lot...\""


translate english e1122a_c0577011:



    voice "voice/e11/22a00020a01.opus"
    mx "\"Could you say it again?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
