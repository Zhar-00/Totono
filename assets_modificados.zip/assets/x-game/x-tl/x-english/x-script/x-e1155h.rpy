

translate english e1155h_f0cb48cb:



    voice "voice/e11/55h00010a01.opus"
    mx "\"Te lo suplico...\""


translate english e1155h_860bbe62:



    voice "voice/e11/55h00020a01.opus"
    mx "\"¿No ves lo desesperada que estoy?\""


translate english e1155h_f9056ff2:



    voice "voice/e11/55h00030a01.opus"
    mx "\"Y aun así... ¿todavía te niegas...?\""


translate english e1155h_cc64f251:



    voice "voice/e11/55h00040a01.opus"
    mx "\"¿De verdad... quieres estar con Aoi tanto así...?\""


translate english e1155h_2c6ea4bc:



    voice "voice/e11/55h00050a01.opus"
    mx "\"Bueno, en ese caso...\""


translate english e1155h_fc918289:



    voice "voice/e11/55h00060a01.opus"
    mx "\"Si así es como te sientes, entonces dos pueden jugar a ese juego.\""


translate english e1155h_2d73457f:



    voice "voice/e11/55h00070a01.opus"
    mx "\"¡Voy a cambiar eso!\""


translate english e1155h_61c284fb:



    voice "voice/e11/55h00080a01.opus"
    mx "\"¡Alteraré este mundo tal como alteré el juego!\""


translate english e1155h_220b7008:



    voice "voice/e11/55h00090a01.opus"
    mx "\"¡¡¡Borraré a Aoi!!! ¡¡¡Por completo!!!\""


translate english e1155h_59df28eb:


    xy "\"Eh... ¿Miyuki...?\""


translate english e1155h_4f5d89e4:


    "Miyuki me ignora y sale corriendo de la casa."


translate english e1155h_14f3821d:


    "¿Qué le pasa? ¿Por qué se echó a llorar?"


translate english e1155h_40c7077f:


    "Nada de lo que dijo tenía sentido..."


translate english e1155h_eccdfe30:


    "Decido—"


translate english strings:


    old "Пойти искать Миюки"
    new "Buscar a Miyuki"


    old "Пойти искать Аой"
    new "Buscar a Aoi"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
