

translate english a3122a_e3bf2a29:



    voice "voice/a31/22a00010a02.opus"
    aoi "\"Todavía no... pero...\""


translate english a3122a_a4d78d52:



    voice "voice/a31/22a00020a02.opus"
    aoi "\"Hoy se siente como un buen día.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
