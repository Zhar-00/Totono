

translate english a6191_dd7ce4a3:


    "No tengo talento."


translate english a6191_16929fc9:


    "Soy un perdedor sin agallas. Un cobarde. Un don nadie."


translate english a6191_43d6e460:


    "No soy un príncipe. No puedo conectar un jonrón."


translate english a6191_b857f04f:


    "Y Miyuki está totalmente fuera de mi liga."


translate english a6191_432044c0:


    "Todo es un hecho, simple y llanamente."


translate english a6191_76dd2e33:


    "Y aun así..."


translate english a6191_cd0d0819:


    "Pienso en Aoi, bateando hasta que apenas podía mantenerse en pie."


translate english a6191_dbda343d:


    "¿Era patética?"


translate english a6191_10e419b1:


    "¿Fueron sus lágrimas en vano?"


translate english a6191_22dde288:


    "No."


translate english a6191_cc98c10a:


    "Con su ayuda, por fin encontré la fuerza para dar un swing."


translate english a6191_57f89c1e:


    "Jonrón o strike, no importa."


translate english a6191_18a354cc:


    "Lo único que tengo que hacer es seguir intentándolo."


translate english a6191_d4eae3cf:


    "Eso lo entiendo ahora."


translate english a6191_24907c23:


    "Sin importar cuántas veces me dije que lo dejara ir..."


translate english a6191_eb2ac04b:


    "Sin importar cuántas veces fingí que no era real..."


translate english a6191_9b66bb0c:


    "Mis sentimientos siempre estuvieron ahí, desde el mismísimo principio."


translate english a6191_5c6915e3:


    "Siempre la he amado."


translate english a6191_9c76fb7c:


    "Ella era mi todo."


translate english a6191_0bd816bd:


    "¿Y qué si no me transformé en un príncipe para mi final feliz? ¿Y qué si la vida real no funciona así?"


translate english a6191_a91347ee:


    "Se acabó mentirme a mí mismo sobre lo que siento."


translate english a6191_e902e00e:


    "Agarro el boleto de la mesa."


translate english a6191_f0a0cb70:


    "Faltan quince minutos para que empiece la función."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
