

translate english e1141b_ecf6a46c:



    voice "voice/e11/41b00010a01.opus"
    mx "\"The world has been modified.\""


translate english e1141b_a3d5db6c:



    voice "voice/e11/41b00020a01.opus"
    mx "\"Your desires don't matter.\""


translate english e1141b_05f66cc5:



    voice "voice/e11/41b00030a01.opus"
    mx "\"You will live right here in my world...\""


translate english e1141b_b07f1de6:



    voice "voice/e11/41b00040a01.opus"
    mx "\"...forever and ever and ever.\""


translate english e1141b_c69d0f33:



    voice "voice/e11/41b00050a01.opus"
    mx "\"Yes... For all eternity...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
