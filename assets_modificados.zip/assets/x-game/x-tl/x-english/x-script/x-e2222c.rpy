

translate english e2222c_9eeac4a2:


    xy "\"Feels like I'll wake up and it'll be gone—\""


translate english e2222c_3d093400:



    voice "voice/e22/22c00010a01.opus"
    mx "\"That won't happen.\""


translate english e2222c_1535707e:


    "Los labios de Miyuki se curvan en una sonrisa pícara."


translate english e2222c_73bf47ff:



    voice "voice/e22/22c00020a01.opus"
    mx "\"This isn't a dream. It's reality, whether you like it or not.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
