

translate english e2222c_9eeac4a2:


    xy "\"Siento que voy a despertar y todo se habrá ido—\""


translate english e2222c_3d093400:



    voice "voice/e22/22c00010a01.opus"
    mx "\"Eso no pasará.\""


translate english e2222c_1535707e:


    "Los labios de Miyuki se curvan en una sonrisa pícara."


translate english e2222c_73bf47ff:



    voice "voice/e22/22c00020a01.opus"
    mx "\"Esto no es un sueño. Es la realidad, te guste o no.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
