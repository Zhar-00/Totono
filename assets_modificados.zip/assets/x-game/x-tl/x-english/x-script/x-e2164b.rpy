

translate english e2164b_2ef72112:


    xy "\"Wait, there's two?\""


translate english e2164b_8617f9e3:



    voice "voice/e21/64b00010a01.opus"
    mx "\"Yeah? So what if there's two of them?\""


translate english e2164b_ad98c45e:


    xy "\"Huh...? No, I mean, it's fine, but...\""


translate english e2164b_fc12b417:



    voice "voice/e21/64b00020a01.opus"
    mx "\"But what?\""


translate english e2164b_90a974bd:


    "No tengo respuesta."


translate english e2164b_b0711ff3:


    "Ni siquiera yo estoy seguro de por qué me importa cuántos hay..."


translate english e2164b_3ae5a2aa:


    xy "\"Uhh... well...\""


translate english e2164b_685a9354:



    voice "voice/e21/64b00030a01.opus"
    mx "\"Well, what?\""


translate english e2164b_c6e882e0:


    xy "\"Well... They're not exactly the same, see?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
