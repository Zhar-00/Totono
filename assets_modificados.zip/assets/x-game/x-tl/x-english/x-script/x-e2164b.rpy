

translate english e2164b_2ef72112:


    xy "\"Espera, ¿hay dos?\""


translate english e2164b_8617f9e3:



    voice "voice/e21/64b00010a01.opus"
    mx "\"¿Sí? ¿Y qué si hay dos?\""


translate english e2164b_ad98c45e:


    xy "\"¿Eh...? No, digo, está bien, pero...\""


translate english e2164b_fc12b417:



    voice "voice/e21/64b00020a01.opus"
    mx "\"¿Pero qué?\""


translate english e2164b_90a974bd:


    "No tengo respuesta."


translate english e2164b_b0711ff3:


    "Ni siquiera yo estoy seguro de por qué me importa cuántos hay..."


translate english e2164b_3ae5a2aa:


    xy "\"Emm... bueno...\""


translate english e2164b_685a9354:



    voice "voice/e21/64b00030a01.opus"
    mx "\"¿Pues qué?\""


translate english e2164b_c6e882e0:


    xy "\"Pues... No son exactamente iguales, ¿ves?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
