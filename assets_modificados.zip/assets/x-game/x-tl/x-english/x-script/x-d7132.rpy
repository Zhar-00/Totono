

translate english d7132_ba29d522:


    xy "\"Otra vez no...\""


translate english d7132_6fd5d00f:


    "Reconozco el papel."


translate english d7132_665dc2dc:


    "—CARTA DE EXPULSIÓN."


translate english d7132_1b1581ab:


    "I thought I was already \"expelled\"antes, aunque..."



translate english d7132_21fa31ca:


    "Aun así, sé perfectamente cómo se siente respecto a Miyuki."


translate english d7132_a6e823eb:


    "Debería armarme de valor y explicarme."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
