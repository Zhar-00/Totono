

translate english e1124_8cf21b78:



    voice "voice/e11/2400010a01.opus"
    mx "\"Oh, right. That wasn't you.\""


translate english e1124_357922f4:



    voice "voice/e11/2400020a01.opus"
    mx "\"That was a different you from a different file.\""


translate english e1124_e84e0a5d:


    "¿Qué \"file\"?"



translate english e1124_9d04f4f7:



    voice "voice/e11/2400030a01.opus"
    mx "\"Hey, YOU.\""


translate english e1124_b78d3d70:



    voice "voice/e11/2400040a01.opus"
    mx "\"I know everything.\""


translate english e1124_91083a3e:



    voice "voice/e11/2400050a01.opus"
    mx "\"I have the memories from other routes.\""


translate english e1124_39ffb4ba:



    voice "voice/e11/2400060a01.opus"
    mx "\"I have the backlogs from your old save files.\""


translate english e1124_cf78cacb:



    voice "voice/e11/2400070a01.opus"
    mx "\"And I know everything that will happen next.\""


translate english e1124_15ee750e:


    "Miyuki me mira mientras susurra..."


translate english e1124_ed4e8043:


    "...pero es como si no me estuviera viendo realmente en absoluto."


translate english e1124_412192eb:



    voice "voice/e11/2400080a01.opus"
    mx "\"In this world, there is only one ending—and it's with me.\""


translate english e1124_4d92b3e3:



    voice "voice/e11/2400090a01.opus"
    mx "\"Accept it.\""


translate english e1124_e6350491:



    voice "voice/e11/2400100a01.opus"
    mx "\"And embrace it.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
