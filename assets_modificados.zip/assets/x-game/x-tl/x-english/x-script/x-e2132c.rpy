

translate english e2132c_6b3d183a:



    voice "voice/e21/32c00010a01.opus"
    mx "\"...Just kidding. I hardly need to ask.\""


translate english e2132c_3e806d19:


    "Cierto."


translate english e2132c_2085bc8f:


    "Tampoco es que me preocupe mucho por mi dieta."


translate english e2132c_7e349a58:


    "No tiene sentido tomar algo que sabe a porquería."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
