

translate english c3221_20339cae:


    xy "\"Haah... haah... haah...\""


translate english c3221_33154994:


    "No puedo respirar."


translate english c3221_88418170:


    "Mi corazón late como loco."


translate english c3221_ecafc7c1:


    "...Probablemente sea solo por haber subido corriendo las escaleras."


translate english c3221_e760b0be:


    "Solo somos amigos..."


translate english c3221_1beb543c:


    "...al menos, eso creo..."


translate english c3221_fecb5416:


    "...¿verdad?"


translate english c3221_21243e3b:


    "Entonces, ¿por qué todavía puedo sentir su aliento en mi piel?"


translate english c3221_cedfa1ee:


    "Cada vez que cierro los ojos, veo sus mejillas sonrojadas..."


translate english c3221_4367fb39:


    "El recuerdo hace que mi pulso se acelere de nuevo."


translate english c3221_2cbfc7aa:


    "Nada ha cambiado entre nosotros..."


translate english c3221_37b8cf5e:


    "...y aun así todo se siente completamente distinto."


translate english c3221_1f4e96ee:


    "¿Eso significa que...?"


translate english c3221_db314047:


    xy "\"...Calm down, buddy.\""


translate english c3221_506fc022:


    "Si sigo pensándolo demasiado, solo voy a complicarlo todo más."


translate english c3221_ccc50d61:


    "Ahora mismo, tengo un problema más apremiante entre manos: la ruptura entre Miyuki y Aoi."


translate english c3221_be0f89a8:


    "Imagino que se verán mañana en la escuela."


translate english c3221_b7b3b9f0:


    "¿Cómo debería explicarle a Miyuki los acontecimientos de hoy?"


translate english c3221_bcb05ab1:


    "Necesito pensar en alguna forma de ayudarlas a reparar su amistad..."


translate english c3221_5ca03065:


    "Con eso, reencamino apresuradamente mi tren de pensamiento antes de que descarrile por completo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
