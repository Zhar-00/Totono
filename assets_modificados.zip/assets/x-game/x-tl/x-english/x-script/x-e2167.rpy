

translate english e2167_ac260324:



    voice "voice/e21/6700010a01.opus"
    mx "\"I'll treasure it.\""


translate english e2167_cd089815:


    xy "\"Aren't you gonna wear it?\""


translate english e2167_a962cd33:



    voice "voice/e21/6700020a01.opus"
    mx "\"No, it wouldn't really suit me. Besides...\""


translate english e2167_8aeca9ff:



    voice "voice/e21/6700030a01.opus"
    mx "\"I'm just happy you thought to get me something at all.\""


translate english e2167_bcafc249:


    "Su sonrisa es embrujadoramente linda..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
