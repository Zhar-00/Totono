

translate english e2167_ac260324:



    voice "voice/e21/6700010a01.opus"
    mx "\"Lo atesoraré.\""


translate english e2167_cd089815:


    xy "\"¿No te lo vas a poner?\""


translate english e2167_a962cd33:



    voice "voice/e21/6700020a01.opus"
    mx "\"No, no me quedaría bien. Además...\""


translate english e2167_8aeca9ff:



    voice "voice/e21/6700030a01.opus"
    mx "\"Solo me alegra que se te ocurriera comprarme algo.\""


translate english e2167_bcafc249:


    "Su sonrisa es embrujadoramente linda..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
