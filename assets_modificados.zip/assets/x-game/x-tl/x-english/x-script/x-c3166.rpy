

translate english c3166_6efaabe5:



    voice "voice/c31/6600010a01.opus"
    mx "\"See you tomorrow at school.\""


translate english c3166_14288c67:


    xy "\"Right. See you tomorrow.\""


translate english c3166_b28cf428:


    "Entro a mi casa."


translate english c3166_e8a09480:


    "Qué día tan largo..."


translate english c3166_e69d53a3:


    "Al final, sigo sin tener idea de dónde está Aoi ni qué hace."


translate english c3166_57a8283c:


    "De hecho, ni siquiera tengo prueba concreta de que salió del café de manga para rescatar al gato."


translate english c3166_60db4e9c:


    "Lo único que puedo hacer es preguntarle mañana cuando la vea en la escuela."


translate english c3166_2cdc593c:


    "Me meto en la cama y cierro los ojos con calma—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
