

translate english c3162_df1f97df:


    "Miyuki también se queda callada."


translate english c3162_dbc8b726:


    "Por un momento, ninguno de los dos dice palabra."


translate english c3162_58224224:


    xy "\"Got any idea where she could be...?\""


translate english c3162_80216cae:



    voice "voice/c31/6200010a01.opus"
    mx "\"How would I know?\""


translate english c3162_70d83f4d:



    voice "voice/c31/6200020a01.opus"
    mx "\"There's no way she's up on the school roof, not when it's pouring down rain outside. She shouldn't even be able to get through the gates.\""


translate english c3162_d6e9ea16:


    xy "\"Guess we'll just have to search everywhere.\""


translate english c3162_1fc522ee:



    voice "voice/c31/6200030a01.opus"
    mx "\"Probably.\""


translate english c3162_9e5da195:



    voice "voice/c31/6200040a01.opus"
    mx "\"You work your way south. I'll head north.\""


translate english c3162_d4997334:


    xy "\"In that case, we can meet up at my house.\""


translate english c3162_7ea1c53f:



    voice "voice/c31/6200050a01.opus"
    mx "\"Sure. Sounds like a plan.\""


translate english c3162_df77149f:


    "Y así, Miyuki y yo nos separamos para registrar la oscura ciudad."


translate english c3162_42fb5f0d:


    "¿A dónde podría llevar a un animalito tan tarde en la noche?"


translate english c3162_6ed8ce49:


    "No se me ocurre nada."


translate english c3162_e94e06a2:


    "La plaza de la estación—"


translate english c3162_2c95ad12:


    "El distrito comercial—"


translate english c3162_24fdae0d:


    "El parque—"


translate english c3162_357b871a:


    "Los caminos que llevan a la escuela—"


translate english c3162_9048d3a7:


    "La tienda de la esquina—"


translate english c3162_726e85a1:


    "Varios restaurantes de comida rápida—"


translate english c3162_3343b847:


    "Sin pistas en las que basarnos, buscamos y buscamos y buscamos—"


translate english c3162_08a4da13:


    "Pasa una hora."


translate english c3162_ce90c0f6:


    "En algún punto durante la búsqueda de Aoi, la lluvia amaina."


translate english c3162_84a2f3c1:


    xy "\"Did you find her?\""


translate english c3162_aa9a7d92:



    voice "voice/c31/6200060a01.opus"
    mx "\"I take it you didn't, then.\""


translate english c3162_e1c9477b:


    "Encuentro a Miyuki esperándome afuera de mi casa."


translate english c3162_a7c92e9a:


    "Puedo notar por su cara que se ha rendido por completo."


translate english c3162_bf7d043d:



    voice "voice/c31/6200070a01.opus"
    mx "\"At this point, there's nothing else we can do.\""


translate english c3162_1a77c956:


    xy "\"But—\""


translate english c3162_f617b1f7:



    voice "voice/c31/6200080a01.opus"
    mx "\"She probably went home to her parents' house.\""


translate english c3162_3089b7e4:



    voice "voice/c31/6200090a01.opus"
    mx "\"Now that it's stopped raining, let's call it a night.\""


translate english strings:


    old "Сдаться"
    new "Rendirse"


    old "Не сдаваться"
    new "No rendirse"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
