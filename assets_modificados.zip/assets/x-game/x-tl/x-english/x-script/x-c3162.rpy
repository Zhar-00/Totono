

translate english c3162_df1f97df:


    "Miyuki también se queda callada."


translate english c3162_dbc8b726:


    "Por un momento, ninguno de los dos dice palabra."


translate english c3162_58224224:


    xy "\"¿Tienes alguna idea de dónde pueda estar...?\""


translate english c3162_80216cae:



    voice "voice/c31/6200010a01.opus"
    mx "\"¿Cómo voy a saberlo?\""


translate english c3162_70d83f4d:



    voice "voice/c31/6200020a01.opus"
    mx "\"No hay forma de que esté en la azotea de la escuela, no con la lluvia que está cayendo. Ni siquiera debería poder pasar las rejas.\""


translate english c3162_d6e9ea16:


    xy "\"Supongo que tendremos que buscar por todas partes.\""


translate english c3162_1fc522ee:



    voice "voice/c31/6200030a01.opus"
    mx "\"Probablemente.\""


translate english c3162_9e5da195:



    voice "voice/c31/6200040a01.opus"
    mx "\"Tú avanza hacia el sur. Yo iré al norte.\""


translate english c3162_d4997334:


    xy "\"En ese caso, nos reunimos en mi casa.\""


translate english c3162_7ea1c53f:



    voice "voice/c31/6200050a01.opus"
    mx "\"Claro. Suena bien.\""


translate english c3162_df77149f:


    "Y así, Miyuki y yo nos separamos para registrar la oscura ciudad."


translate english c3162_42fb5f0d:


    "¿A dónde podría llevar a un animalito tan tarde en la noche?"


translate english c3162_6ed8ce49:


    "No se me ocurre nada."


translate english c3162_e94e06a2:


    "La plaza de la estación—"


translate english c3162_2c95ad12:


    "El distrito comercial—"


translate english c3162_24fdae0d:


    "El parque—"


translate english c3162_357b871a:


    "Los caminos que llevan a la escuela—"


translate english c3162_9048d3a7:


    "La tienda de la esquina—"


translate english c3162_726e85a1:


    "Varios restaurantes de comida rápida—"


translate english c3162_3343b847:


    "Sin pistas en las que basarnos, buscamos y buscamos y buscamos—"


translate english c3162_08a4da13:


    "Pasa una hora."


translate english c3162_ce90c0f6:


    "En algún punto durante la búsqueda de Aoi, la lluvia amaina."


translate english c3162_84a2f3c1:


    xy "\"¿La encontraste?\""


translate english c3162_aa9a7d92:



    voice "voice/c31/6200060a01.opus"
    mx "\"Entonces deduzco que no.\""


translate english c3162_e1c9477b:


    "Encuentro a Miyuki esperándome afuera de mi casa."


translate english c3162_a7c92e9a:


    "Puedo notar por su cara que se ha rendido por completo."


translate english c3162_bf7d043d:



    voice "voice/c31/6200070a01.opus"
    mx "\"A estas alturas, no hay nada más que podamos hacer.\""


translate english c3162_1a77c956:


    xy "\"Pero—\""


translate english c3162_f617b1f7:



    voice "voice/c31/6200080a01.opus"
    mx "\"Probablemente se fue a casa de sus padres.\""


translate english c3162_3089b7e4:



    voice "voice/c31/6200090a01.opus"
    mx "\"Ahora que dejó de llover, demos por terminado el día.\""


translate english strings:


    old "Сдаться"
    new "Rendirse"


    old "Не сдаваться"
    new "No rendirse"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
