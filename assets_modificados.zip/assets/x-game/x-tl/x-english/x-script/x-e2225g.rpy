

translate english e2225g_2dd79a08:



    voice "voice/e22/25g00010a01.opus"
    mx "Me dejaste toda sucia otra vez... ¿una vez no te bastó?"



translate english e2225g_a9fee559:



    voice "voice/e22/25g00020a01.opus"
    mx "...Bueno, está bien."


translate english e2225g_d2ff155e:



    voice "voice/e22/25g00030a01.opus"
    mx "Si así te gusta... entonces puedes correrte sobre mí cuantas veces quieras..."



translate english e2225g_15285717:



    voice "voice/e22/25g00040a01.opus"
    mx "Solo hazme un desastre... ¿sí?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
