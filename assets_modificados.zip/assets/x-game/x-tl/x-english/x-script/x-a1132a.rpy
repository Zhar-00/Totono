

translate english a1132a_10daf709:


    xy "\"Sure, that sounds nice.\""


translate english a1132a_0a54f36b:



    voice "voice/a11/32a00010a02.opus"
    aoi "\"Really?\""


translate english a1132a_c4328559:


    "Quizá si tuviera un par de amigos decentes con quienes pasar el rato, no se comportaría así."


translate english a1132a_4e4954eb:


    xy "\"You'll have to count me out, though.\""


translate english a1132a_60b7866b:


    xy "\"They say men and women can't be friends.\""


translate english a1132a_8ead321c:


    xy "\"But maybe you and Miyuki could—\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
