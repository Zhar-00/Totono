

translate english a1132a_10daf709:


    xy "\"Claro, suena bien.\""


translate english a1132a_0a54f36b:



    voice "voice/a11/32a00010a02.opus"
    aoi "\"¿En serio?\""


translate english a1132a_c4328559:


    "Quizá si tuviera un par de amigos decentes con quienes pasar el rato, no se comportaría así."


translate english a1132a_4e4954eb:


    xy "\"Pero tendrás que contar sin mí.\""


translate english a1132a_60b7866b:


    xy "\"Dicen que hombres y mujeres no pueden ser amigos.\""


translate english a1132a_8ead321c:


    xy "\"Pero quizás tú y Miyuki podrían—\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
