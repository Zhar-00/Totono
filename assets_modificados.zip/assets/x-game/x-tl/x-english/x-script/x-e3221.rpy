

translate english e3221_6e27827e:



    voice "voice/e32/2100010a01.opus"
    mx "Oye, TÚ."


translate english e3221_f1edde15:



    voice "voice/e32/2100020a01.opus"
    mx "¿Por qué me preguntaste por qué había dos horquillas?"


translate english e3221_9e4f957b:



    voice "voice/e32/2100030a01.opus"
    mx "De todas las elecciones raras... ¡El pobre Shinichi la pasó fatal siguiendo la conversación después de eso!"


translate english e3221_44f44a3a:



    voice "voice/e32/2100040a01.opus"
    mx "...Sí, lo sé. La verdadera pregunta que querías hacer es..."


translate english e3221_85290a0b:



    voice "voice/e32/2100050a01.opus"
    mx " "



translate english e3221_99adee9f:



    voice "voice/e32/2100060a01.opus"
    mx "Después de todo, originalmente había dos..."


translate english e3221_0dbd3a57:



    voice "voice/e32/2100070a01.opus"
    mx "Aunque mi ruta fue hace tanto tiempo que quizás ya lo hayas olvidado..."


translate english e3221_567effcb:



    voice "voice/e32/2100080a01.opus"
    mx "Dime, ¿por qué crees que una de ellas desapareció?"


translate english e3221_c0ea6e69:



    voice "voice/e32/2100090a01.opus"
    mx "En el fondo, sabes la respuesta, ¿no?"


translate english e3221_8238ea7a:



    voice "voice/e32/2100100a01.opus"
    mx "...Porque la escondí."


translate english e3221_b4d0c0cf:



    voice "voice/e32/2100110a01.opus"
    mx "Pensé que podría ser útil más adelante."


translate english e3221_bb8c8288:



    voice "voice/e32/2100120a01.opus"
    mx "Y aquella vez que irrumpimos en ese departamento... si no hubiera plantado esa horquilla ahí como 'prueba'..."



translate english e3221_6b792c6b:



    voice "voice/e32/2100130a01.opus"
    mx "probablemente nunca habrías cuestionado tu fe en Aoi."


translate english e3221_0601293b:



    voice "voice/e32/2100140a01.opus"
    mx "Pero supongo que todo eso es cosa del pasado..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
