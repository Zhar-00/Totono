

translate english e2319d_36e154c3:


    "La agenda no está bloqueada, así que puedo revisar su contenido fácilmente."


translate english e2319d_17949526:


    "Pero solo hay una entrada—\"God\"."



translate english e2319d_7519cb44:


    "Ningún otro nombre."


translate english e2319d_b9a94462:


    "Por lo tanto, no tengo un objetivo real aquí."


translate english strings:


    old "Позвонить Богу"
    new "Llamar a Dios"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
