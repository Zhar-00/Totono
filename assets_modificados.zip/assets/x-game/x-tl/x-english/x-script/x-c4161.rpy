

translate english c4161_7928b4c1:



    voice "voice/c41/6100010b01.opus"
    xtl "\"—!!!\""


translate english c4161_5e6751d7:


    xy "\"What am I looking at here?\""


translate english c4161_9d0bbac7:


    "Apenas Yuutarou entra al salón, se acerca y azota un trozo de papel sobre mi escritorio."


translate english c4161_8434c417:


    "Un formulario de renuncia al club."


translate english c4161_ba26fd82:


    "Espera... Hay algo escrito encima."


translate english c4161_cdb835eb:


    xy "\"A... letter of expulsion...?\""


translate english c4161_ccd70bde:



    voice "voice/c41/6100020b01.opus"
    xtl "\"It seems I made a mistake in inviting you to the BD Club.\""


translate english c4161_a6ffa9cd:



    voice "voice/c41/6100030b01.opus"
    xtl "\"As of today, you're OUT!!!\""


translate english c4161_4388b8c2:


    xy "\"Okay.\""


translate english c4161_48a1ff1d:



    voice "voice/c41/6100040b01.opus"
    xtl "\"How are you okay with this?!\""


translate english c4161_31ee5901:


    xy "\"I mean, I didn't want to join in the first place.\""


translate english c4161_e3563f47:



    voice "voice/c41/6100050b01.opus"
    xtl "\"I didn't realize you were such a coward!\""


translate english c4161_347a8305:



    voice "voice/c41/6100060b01.opus"
    xtl "\"You call yourself a man?! Don't you feel the weight of loneliness upon your shoulders?! Find your dreams! That's how a real man lives!\""


translate english c4161_d56309cd:


    xy "\"You have fun without me, buddy.\""


translate english c4161_59a293df:


    "Yuutarou puede seguir gritando todo lo que quiera, pero yo—"


translate english c4161_fa7025f6:



    voice "voice/c41/6100070b01.opus"
    xtl "\"—!!!\""


translate english c4161_7fe1cf16:


    xy "\"Huh...?!\""



translate english c4161_4e67af4a:


    "De la nada, Yuutarou me agarra del cuello."


translate english c4161_407daa6f:


    "He glares at me with an intensity about 50%% more obnoxious than usual."


translate english c4161_46416516:


    xy "\"Yuutarou...?\""


translate english c4161_68227945:



    voice "voice/c41/6100080b01.opus"
    xtl "\"I'm cutting ties with you.\""


translate english c4161_7fe1cf16_1:


    xy "\"What...?\""



translate english c4161_6a9cd3a8:



    voice "voice/c41/6100090b01.opus"
    xtl "\"I can't be friends with you if you won't even go looking for Mukou.\""


translate english c4161_686b8a3f:



    voice "voice/c41/6100100b01.opus"
    xtl "\"Never speak to me ever again!!!\""


translate english c4161_00224a0f:


    "Cortar lazos..."


translate english c4161_907bc7b2:


    "La palabra familiar atraviesa mi corazón."


translate english c4161_9633095b:


    xy "\"C'mon, that's not funny.\""


translate english c4161_62ce41ad:



    voice "voice/c41/6100110b01.opus"
    xtl "\"I'm not messing around. I'm serious!\""


translate english c4161_21c2a6f5:



    voice "voice/c41/6100120b01.opus"
    xtl "\"Shinichi, I know you know. If you let your dreams slip away, you'll ruin your life.\""


translate english c4161_31e6af3e:



    voice "voice/c41/6100130b01.opus"
    xtl "\"And I know you know what you need to do.\""


translate english strings:


    old "Искать свои мечты"
    new "Buscar mis sueños"


    old "Забыть об этом"
    new "Dejarlo ir"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
