

translate english c4161_7928b4c1:



    voice "voice/c41/6100010b01.opus"
    xtl "\"—!!!\""


translate english c4161_5e6751d7:


    xy "\"¿Qué estoy viendo aquí?\""


translate english c4161_9d0bbac7:


    "Apenas Yuutarou entra al salón, se acerca y azota un trozo de papel sobre mi escritorio."


translate english c4161_8434c417:


    "Un formulario de renuncia al club."


translate english c4161_ba26fd82:


    "Espera... Hay algo escrito encima."


translate english c4161_cdb835eb:


    xy "\"¿Una... carta de expulsión...?\""


translate english c4161_ccd70bde:



    voice "voice/c41/6100020b01.opus"
    xtl "\"Parece que me equivoqué al invitarte al Club BD.\""


translate english c4161_a6ffa9cd:



    voice "voice/c41/6100030b01.opus"
    xtl "\"¡¡¡A partir de hoy, estás FUERA!!!\""


translate english c4161_4388b8c2:


    xy "\"Okay.\""


translate english c4161_48a1ff1d:



    voice "voice/c41/6100040b01.opus"
    xtl "\"¿¡Cómo que okay!?\""


translate english c4161_31ee5901:


    xy "\"O sea, no quería unirme en primer lugar.\""


translate english c4161_e3563f47:



    voice "voice/c41/6100050b01.opus"
    xtl "\"¡No sabía que eras tan cobarde!\""


translate english c4161_347a8305:



    voice "voice/c41/6100060b01.opus"
    xtl "\"¿¡Te llamas hombre!? ¿¡No sientes el peso de la soledad sobre tus hombros!? ¡Encuentra tus sueños! ¡Así vive un hombre de verdad!\""


translate english c4161_d56309cd:


    xy "\"Diviértete sin mí, amigo.\""


translate english c4161_59a293df:


    "Yuutarou puede seguir gritando todo lo que quiera, pero yo—"


translate english c4161_fa7025f6:



    voice "voice/c41/6100070b01.opus"
    xtl "\"—!!!\""


translate english c4161_7fe1cf16:


    xy "\"¿¡Eh...!?\""



translate english c4161_4e67af4a:


    "De la nada, Yuutarou me agarra del cuello."


translate english c4161_407daa6f:


    "He glares at me with an intensity about 50%% more obnoxious than usual."


translate english c4161_46416516:


    xy "\"¿Yuutarou...?\""


translate english c4161_68227945:



    voice "voice/c41/6100080b01.opus"
    xtl "\"Estoy cortando lazos contigo.\""


translate english c4161_7fe1cf16_1:


    xy "\"¿Qué...?\""



translate english c4161_6a9cd3a8:



    voice "voice/c41/6100090b01.opus"
    xtl "\"No puedo ser tu amigo si ni siquiera vas a buscar a Mukou.\""


translate english c4161_686b8a3f:



    voice "voice/c41/6100100b01.opus"
    xtl "\"¡¡¡No me vuelvas a hablar nunca más!!!\""


translate english c4161_00224a0f:


    "Cortar lazos..."


translate english c4161_907bc7b2:


    "La palabra familiar atraviesa mi corazón."


translate english c4161_9633095b:


    xy "\"Vamos, no es gracioso.\""


translate english c4161_62ce41ad:



    voice "voice/c41/6100110b01.opus"
    xtl "\"No estoy bromeando. ¡Hablo en serio!\""


translate english c4161_21c2a6f5:



    voice "voice/c41/6100120b01.opus"
    xtl "\"Shinichi, sé que lo sabes. Si dejas que tus sueños se te escapen, arruinarás tu vida.\""


translate english c4161_31e6af3e:



    voice "voice/c41/6100130b01.opus"
    xtl "\"Y sé que sabes lo que tienes que hacer.\""


translate english strings:


    old "Искать свои мечты"
    new "Buscar mis sueños"


    old "Забыть об этом"
    new "Dejarlo ir"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
