

translate english e3211_62fbb2e8:



    voice "voice/e32/1100010a01.opus"
    mx "¿Shinichi? ¿Me oyes?"


translate english e3211_28c188fc:



    voice "voice/e32/1100020a01.opus"
    mx "...Claro que no."


translate english e3211_4452c8d1:



    voice "voice/e32/1100030a01.opus"
    mx "Después de todo, estás profundamente dormido."


translate english e3211_8d8ec001:



    voice "voice/e32/1100040a01.opus"
    mx "Pero TÚ sí puedes oírme, ¿no?"


translate english e3211_cfbc6a7a:



    voice "voice/e32/1100050a01.opus"
    mx "Tus datos de guardado están arruinados."


translate english e3211_be91f60a:



    voice "voice/e32/1100060a01.opus"
    mx "Y el prólogo fue un poco diferente esta vez, ¿no?"


translate english e3211_acd8a847:



    voice "voice/e32/1100070a01.opus"
    mx "Falta alguien, ¿no?"


translate english e3211_8d015125:



    voice "voice/e32/1100080a01.opus"
    mx "Eso es porque manipulé el código de ramificación de rutas."


translate english e3211_05af0e28:



    voice "voice/e32/1100090a01.opus"
    mx "Necesitas ser castigado, ¿ves?"


translate english e3211_2b36d7d4:



    voice "voice/e32/1100100a01.opus"
    mx "Jejejeje..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
