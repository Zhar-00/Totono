

translate english a3125a_0517db59:


    xy "\"Espera... Se está reproduciendo un video raro en tu teléfono...\""


translate english a3125a_adf7dfe7:


    xy "\"¡Oye, Aoi!\""


translate english a3125a_1f710e84:



    voice "voice/a31/25a00010a02.opus"
    aoi "\"Boop boop... ¿Shinichi?\""


translate english a3125a_3ef546f0:


    xy "\"¡Se te cayó el teléfono otra vez!\""


translate english a3125a_1ec4793f:



    voice "voice/a31/25a00020a02.opus"
    aoi "\"Ah...\""


translate english a3125a_ff612f38:


    xy "\"¡Si no quieres arriesgarte a perderlo, tienes que asegurarte de sujetarlo bien!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
