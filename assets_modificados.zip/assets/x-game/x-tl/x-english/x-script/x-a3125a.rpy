

translate english a3125a_0517db59:


    xy "\"Wait... Some weird video's playing on your phone...\""


translate english a3125a_adf7dfe7:


    xy "\"Hey, Aoi!\""


translate english a3125a_1f710e84:



    voice "voice/a31/25a00010a02.opus"
    aoi "\"Boop boop... Shinichi?\""


translate english a3125a_3ef546f0:


    xy "\"You dropped your phone again!\""


translate english a3125a_1ec4793f:



    voice "voice/a31/25a00020a02.opus"
    aoi "\"Oh...\""


translate english a3125a_ff612f38:


    xy "\"If you don't want to risk losing it, you need to make sure you hold onto it!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
