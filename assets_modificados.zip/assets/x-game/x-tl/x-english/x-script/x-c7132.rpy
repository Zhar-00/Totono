

translate english c7132_8d795ba8:


    "Dios es real."


translate english c7132_b608187e:


    "No puedo creerlo."


translate english c7132_a5ff27b4:


    "...Pero le creo."


translate english c7132_ed77d974:


    "Debo tener un caso grave de cerebro de gamer."


translate english c7132_5a5134e4:


    "Amo a Aoi."


translate english c7132_957ce5a2:


    "Pero Aoi es una opción romántica en un videojuego."


translate english c7132_3559794e:


    "Necesita tener sexo o desaparecerá."


translate english c7132_2a1b46ad:


    "Así que llamé a Ryuujirou."


translate english c7132_3f136745:


    "Y le dije a Aoi que se acostara con él."


translate english c7132_d72bcba2:


    "Era mi única opción."


translate english c7132_f6665569:


    "No tengo otra elección."


translate english c7132_1973ce30:


    "Hora de desmayarme."


translate english c7132_65a5523d:


    "Quizás pueda dormirme y olvidarlo todo..."


translate english c7132_d28c8f4b:



    voice "voice/c71/3200010a02.opus"
    aoi "\"¡Aaah!\""


translate english c7132_a14efee3:


    xy "\"......!\""


translate english c7132_bbed1616:



    voice "voice/c71/3200020a02.opus"
    aoi "\"¡Aah! ¡Aah! ¡Aah! ¡Aaahh!\""


translate english c7132_cf7e1078:



    voice "voice/c71/3200030a02.opus"
    aoi "\"¡Aah! ¡Aah! ¡Aah! ¡Dios!\""


translate english c7132_282d4b03:



    voice "voice/c71/3200040a02.opus"
    aoi "\"¡Ahí viene la descarga...!\""


translate english c7132_0accd139:


    xy "\"\"......\"!\""


translate english c7132_2681f75e:


    "Puedo oírlo desde la sala."


translate english c7132_0ae96c6e:


    "Se desliza más allá de mi mente racional y me atraviesa el corazón."


translate english c7132_020fdb74:


    "En un instante, mi determinación empieza a desmoronarse."


translate english c7132_1fb72b2f:


    "Me levanto del sofá."


translate english c7132_d8c670a3:


    "Luego, como atraído hacia la fuente de los gemidos, salgo de la sala."


translate english c7132_9fdf805a:


    "Tengo que hacer esto para quedarme con Aoi."


translate english c7132_607693eb:


    "Tengo que hacer esto por mi futuro."


translate english c7132_f1291e10:


    "En mi cabeza, lo entiendo."


translate english c7132_39e7c143:


    "Pero..."


translate english c7132_0ea1ce29:


    "No es tan simple."


translate english c7132_cf5cb58f:


    "O sea, Aoi está teniendo sexo con otro hombre, en este preciso momento."


translate english c7132_9cd26bcd:


    "Su coño está mojado. Está gimiendo y lamiendo su polla."


translate english c7132_cb9227b3:


    "Ya no lo soporto."


translate english c7132_5027069f:


    "El mero pensamiento hace que mi sentido de la razón se vaya por la ventana."


translate english c7132_8b7b770b:


    "Un oscuro celo se arremolina en mi pecho."


translate english c7132_6b021e51:


    "Nunca debí haber aceptado esto."


translate english c7132_7840de65:


    "Sé que es patético, pero no puedo cambiar quien soy."


translate english c7132_ec923798:



    voice "voice/c71/3200100a02.opus"
    aoi "\"¡Nnhaah! ¡Dios! ¡Está tan profundo! ¡Nnnngggghhhhhh!\""


translate english c7132_7f82175b:



    voice "voice/c71/3200110a02.opus"
    aoi "\"¡AAAH! ¡Se siente... tan bien...!\""


translate english c7132_61b7e207:



    voice "voice/c71/3200120a02.opus"
    aoi "\"Dios... Más... Justo ahí... ¡AAAH!\""


translate english c7132_aa8dc57a:


    "Impulsado por algún latente impulso, subo las escaleras."


translate english c7132_b5e04981:


    "A medida que me acerco, los sonidos se hacen más fuertes, y mis emociones empiezan a desbordarse."


translate english c7132_e11cfcde:


    "Lenta y silenciosamente, giro la perilla—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
