

translate english e1152a_bad16949:



    voice "voice/e11/52a00010a01.opus"
    mx "\"...Thank you.\""


translate english e1152a_3db6f440:



    voice "voice/e11/52a00020a01.opus"
    mx "\"I take it YOU do remember...\""


translate english e1152a_aafea4ab:



    voice "voice/e11/52a00030a01.opus"
    mx "\"Our first kiss, up on the roof...\""


translate english e1152a_039af023:



    voice "voice/e11/52a00040a01.opus"
    mx "\"That eternal kiss we shared...\""


translate english e1152a_ecc3e900:


    "Miyuki se acerca, con los ojos nadando en afecto."


translate english e1152a_1c8f973c:


    "No puedo escapar, pero no necesito hacerlo."


translate english e1152a_5f4c2d9a:


    "Simplemente cierro los ojos en silencio..."


translate english e1152a_2441bb75:


    "...y la beso."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
