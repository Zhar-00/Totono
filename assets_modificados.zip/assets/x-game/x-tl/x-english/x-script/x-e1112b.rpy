

translate english e1112b_d63b006c:



    voice "voice/e11/12b00010a01.opus"
    mx "\"Too bad.\""


translate english e1112b_9dc2513b:



    voice "voice/e11/12b00020a01.opus"
    mx "\"I'm the one who gets to pick.\""


translate english e1112b_a1c3baf0:



    voice "voice/e11/12b00030a01.opus"
    mx "\"Buuut... Hmm...\""


translate english e1112b_519fb653:



    voice "voice/e11/12b00040a01.opus"
    mx "\"To be fair, it seems like YOU'VE started to fall for me...\""


translate english e1112b_8846994a:



    voice "voice/e11/12b00050a01.opus"
    mx "\"Maybe I'll consider letting you pick sometime...\""


translate english e1112b_e86375f5:



    voice "voice/e11/12b00060a01.opus"
    mx "\"Now then, come on.\""


translate english e1112b_3871c67b:



    voice "voice/e11/12b00070a01.opus"
    mx "\"Drink your miso soup and let's go.\""


translate english e1112b_cca4acf9:


    "El sabor de su caldo se derrite en mi boca."


translate english e1112b_c2b39920:


    "Es tan delicioso y reconfortante que creo que podría desmayarme..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
