

translate english e1112b_d63b006c:



    voice "voice/e11/12b00010a01.opus"
    mx "\"Qué pena.\""


translate english e1112b_9dc2513b:



    voice "voice/e11/12b00020a01.opus"
    mx "\"Soy yo quien elige.\""


translate english e1112b_a1c3baf0:



    voice "voice/e11/12b00030a01.opus"
    mx "\"Pero... Hmm...\""


translate english e1112b_519fb653:



    voice "voice/e11/12b00040a01.opus"
    mx "\"Siendo justos, parece que TÚ has empezado a enamorarte de mí...\""


translate english e1112b_8846994a:



    voice "voice/e11/12b00050a01.opus"
    mx "\"Quizá considere dejarte elegir en algún momento...\""


translate english e1112b_e86375f5:



    voice "voice/e11/12b00060a01.opus"
    mx "\"Ahora, vamos.\""


translate english e1112b_3871c67b:



    voice "voice/e11/12b00070a01.opus"
    mx "\"Tómate tu sopa de miso y vámonos.\""


translate english e1112b_cca4acf9:


    "El sabor de su caldo se derrite en mi boca."


translate english e1112b_c2b39920:


    "Es tan delicioso y reconfortante que creo que podría desmayarme..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
