

translate english c3172_f51f4685:


    "Quizá Miyuki tenga razón."


translate english c3172_afde10ad:


    "Quizá solo esté confundiendo los videojuegos con la realidad. O sea, no hay forma de que Aoi se tomara la molestia de conseguir un gato para esto."


translate english c3172_503c40ab:


    "Pero no dejo de pensar en aquel día que la vi parada bajo la lluvia..."


translate english c3172_4147c318:


    "Puedo imaginarla deambulando sin rumbo por las calles oscurecidas, con el gatito en brazos..."


translate english c3172_e8ee32af:


    "A la mierda."


translate english c3172_8c2d2740:


    "Llámalo un caso grave de cerebro de gamer. Me da igual."


translate english c3172_c1b84816:


    "A estas alturas, haré lo que sea para despejar estas dudas persistentes."


translate english c3172_abc5e773:


    xy "\"Hagámoslo.\""


translate english c3172_b893354a:


    "Salto de la cama y agarro el teléfono prestado."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
