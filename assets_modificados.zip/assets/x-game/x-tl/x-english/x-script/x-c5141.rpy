

translate english c5141_1ad491ce:



    voice "voice/c51/4100010a02.opus"
    aoi "\"Ggllpp... ggllpp... mmm...\""


translate english c5141_319d072f:



    voice "voice/c51/4100020a02.opus"
    aoi "\"Whew...\""


translate english c5141_8e264461:


    xy "\"Is it good?\""


translate english c5141_7c64acfe:



    voice "voice/c51/4100030a02.opus"
    aoi "\"Not really.\""


translate english c5141_f94c5dc3:


    "Deja su lata vacía en el suelo."


translate english c5141_de03063e:


    xy "\"No surprise there...\""


translate english c5141_152cd057:


    "Eru maúlla en señal de acuerdo mientras golpea una pequeña pelota de goma."


translate english c5141_6edc57dc:


    "Este es nuestro primer almuerzo sin Miyuki."


translate english c5141_e1c966f1:


    "Naturalmente, eso significa que tampoco hay un almuerzo casero elegante."


translate english c5141_2066d11c:


    "Juntamos la comida chatarra que conseguimos de la tienda de la esquina y la cafetería, y empezamos a devorarla."


translate english c5141_b8140e38:


    "...Apesta."


translate english c5141_ae052c88:



    voice "voice/c51/4100050a02.opus"
    aoi "\"How's your cheek?\""


translate english c5141_30f9e2d8:


    xy "\"Mm? Oh... Yeah, it's fine.\""


translate english c5141_32e0a3ae:


    "No me di cuenta hasta después de que Miyuki dejó una gran marca roja de mano en mi cara para que todos la vieran."


translate english c5141_a699b867:


    "La teoría popular actual entre nuestros compañeros es que debí intentar manosearla y por consiguiente me dieron una paliza."


translate english c5141_2801d404:


    "Por mucho que quiera aclarar el asunto, Miyuki no ha vuelto a clase desde entonces."


translate english c5141_18e6f39b:


    "Así que, sin oportunidad de defenderme, salí disparado del salón en cuanto sonó la campana del almuerzo."


translate english c5141_6529b8f6:


    xy "\"Wonder where Miyuki ran off to.\""


translate english c5141_f2a7ad0a:


    "Aoi se levanta en silencio."


translate english c5141_6d3d0e5b:


    "Levanta su teléfono celular en el aire—"


translate english c5141_75f01a43:



    voice "voice/c51/4100060a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c5141_768bd6b9:



    voice "voice/c51/4100070a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c5141_d77b7fb3:



    voice "voice/c51/4100080a02.opus"
    aoi "\"...Boop boop.\""


translate english c5141_f9e793cf:


    xy "\"Still no service?\""


translate english c5141_4fee33f6:



    voice "voice/c51/4100090a02.opus"
    aoi "\"Maybe...\""


translate english c5141_f47e5c11:



    voice "voice/c51/4100100a02.opus"
    aoi "\"Maybe God's just... gone.\""


translate english c5141_039141b2:


    "Empieza a transmitir una vez más."


translate english c5141_072d1676:


    "Quizás es solo su forma de rezar."


translate english c5141_daf2c37e:


    "Siempre fue marginada por nuestra clase."


translate english c5141_0547d9c3:


    "Pasaba cada noche durmiendo en un café de manga."


translate english c5141_b5db44ac:


    "No encajaba en el mundo real, así que necesitaba un mundo propio."


translate english c5141_97d1f1d5:


    "Necesitaba un dios que convirtiera su realidad en un videojuego."


translate english c5141_ea84458b:


    "¿Puede su dios salvarla todavía?"


translate english c5141_a5584fd1:


    "¿O sus plegarias quedarán sin respuesta?"


translate english c5141_f7589170:



    voice "voice/c51/4100110a01.opus"
    mx "\"Oh, hello.\""


translate english c5141_d27eeafa:


    xy "\"Huh?\""


translate english c5141_5fa79d2a:



    voice "voice/c51/4100120a02.opus"
    aoi "\"Miyuki?!\""


translate english c5141_3dc44613:


    xy "\"We're not just seeing things, are we...?\""


translate english c5141_6ba9b89c:



    voice "voice/c51/4100130a01.opus"
    mx "\"...Am I interrupting?\""


translate english c5141_7d166ce2:


    xy "\"No, of course not! We were waiting for you!\""


translate english c5141_204bb40c:



    voice "voice/c51/4100140a01.opus"
    mx "\"I brought a boxed lunch. Want some?\""


translate english c5141_8df66550:


    xy "\"Yes, please! How about you, Aoi?\""


translate english c5141_4c99cbc1:



    voice "voice/c51/4100150a02.opus"
    aoi "\"...Aoi can't.\""


translate english c5141_ce09946c:


    xy "\"Aren't you hungry?\""


translate english c5141_f5509409:



    voice "voice/c51/4100160a02.opus"
    aoi "\"Aoi... can't eat it...!\""


translate english c5141_f2f38acf:


    xy "\"Aoi! Hey!\""


translate english c5141_6bbc35ce:



    voice "voice/c51/4100170a01.opus"
    mx "\"Hold it right there!\""


translate english c5141_51181a23:



    voice "voice/c51/4100180a02.opus"
    aoi "\"...Boop boop...\""


translate english c5141_be43f097:


    "Aoi intenta correr, pero Miyuki la detiene."


translate english c5141_7d6f7101:



    voice "voice/c51/4100190a01.opus"
    mx "\"Where do you think you're going?\""


translate english c5141_e4549db3:



    voice "voice/c51/4100200a01.opus"
    mx "\"I know you're hungry.\""


translate english c5141_e027cb3c:



    voice "voice/c51/4100210a02.opus"
    aoi "\"Aoi's glitched.\""


translate english c5141_3a0ff620:



    voice "voice/c51/4100220a02.opus"
    aoi "\"The glitch made me fall in love with Shinichi.\""


translate english c5141_70e24550:



    voice "voice/c51/4100230a02.opus"
    aoi "\"But Shinichi belongs with you.\""


translate english c5141_b3487277:



    voice "voice/c51/4100240a02.opus"
    aoi "\"And Aoi was supposed to be your friend.\""


translate english c5141_8591349a:



    voice "voice/c51/4100250a02.opus"
    aoi "\"Which means... Aoi betrayed you.\""


translate english c5141_02c01903:



    voice "voice/c51/4100260a02.opus"
    aoi "\"So Aoi can't be friends with you anym—\""


translate english c5141_2ff76498:



    voice "voice/c51/4100270a01.opus"
    mx "\"We aren't friends.\""


translate english c5141_bbefafcb:


    xy "\"Miyuki!\""



translate english c5141_86f02921:



    voice "voice/c51/4100280a01.opus"
    mx "\"We're besties.\""


translate english c5141_f12f558b:



    voice "voice/c51/4100290a02.opus"
    aoi "\"Besties...?\""


translate english c5141_de345a8f:



    voice "voice/c51/4100300a01.opus"
    mx "\"Best friends. Way closer than regular friends.\""


translate english c5141_5759c86f:



    voice "voice/c51/4100310a01.opus"
    mx "\"You and Shinichi are both so important to me.\""


translate english c5141_8ff96a72:



    voice "voice/c51/4100320a01.opus"
    mx "\"How could I not want the two of you to be happy?\""


translate english c5141_709c6654:



    voice "voice/c51/4100330a02.opus"
    aoi "\"But... you...\""


translate english c5141_cb481385:



    voice "voice/c51/4100340a01.opus"
    mx "\"You think I'm lying?\""


translate english c5141_80902841:



    voice "voice/c51/4100350a01.opus"
    mx "\"Alright then, I'll prove it to you.\""


translate english c5141_cfc0b1d6:


    xy "\"Prove it how?\""


translate english c5141_4bc99858:



    voice "voice/c51/4100360a01.opus"
    mx "\"With this!\""


translate english c5141_6ff765cb:



    voice "voice/c51/4100370a01.opus"
    mx "\"After I heard you two hooked up, I went home to make all my best dishes!\""


translate english c5141_593d3b19:


    xy "\"You went home for THIS?\""


translate english c5141_024ef157:



    voice "voice/c51/4100380a01.opus"
    mx "\"Don't report me to the teachers, mmkay?\""


translate english c5141_857519ae:


    "Sonríe con malicia—el tipo de sonrisa que normalmente nunca dejaría ver en clase."


translate english c5141_01a7b010:



    voice "voice/c51/4100390a02.opus"
    aoi "\"Miyuki...\""


translate english c5141_6dcb2a30:



    voice "voice/c51/4100400a02.opus"
    aoi "\"Can you really forgive everything Aoi's done?\""


translate english c5141_ebb9c273:



    voice "voice/c51/4100410a01.opus"
    mx "\"You can't help who you fall in love with.\""


translate english c5141_e8b2d3b9:



    voice "voice/c51/4100420a01.opus"
    mx "\"Isn't that right, Shinichi?\""


translate english c5141_ecef3903:


    xy "\"Yeah... Sure is.\""


translate english c5141_e19c600f:



    voice "voice/c51/4100430a02.opus"
    aoi "\"Miyuki...\""


translate english c5141_f4f413e2:



    voice "voice/c51/4100440a02.opus"
    aoi "\"Th... Thank...\""


translate english c5141_8f90818b:



    voice "voice/c51/4100450a02.opus"
    aoi "\"Thank you so much!!!\""


translate english c5141_e46d9ee6:



    voice "voice/c51/4100460a02.opus"
    aoi "\"Miyuki... You're the best! Aoi loves you so much!\""


translate english c5141_df3a4bf4:


    "Aoi lanza sus brazos alrededor de Miyuki y empieza a sollozar."


translate english c5141_304b2212:



    voice "voice/c51/4100470a01.opus"
    mx "\"Hey now, c'mon. Don't cry.\""


translate english c5141_9ba66f68:



    voice "voice/c51/4100480a02.opus"
    aoi "\"No, you don't understand.\""


translate english c5141_fd472ccc:



    voice "voice/c51/4100490a02.opus"
    aoi "\"These are happy tears!\""


translate english c5141_961dcefb:



    voice "voice/c51/4100500a01.opus"
    mx "\"Trust me, I know.\""


translate english c5141_e239c9c7:


    "Miyuki acaricia el cabello de Aoi mientras ella tiembla."


translate english c5141_fefc7129:


    "Pero su mirada está en algún lugar distante—"


translate english c5141_6e7751bf:


    "En algún lugar mucho más allá de los confines más lejanos del cielo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
