

translate english c5141_1ad491ce:



    voice "voice/c51/4100010a02.opus"
    aoi "\"Ggllpp... ggllpp... mmm...\""


translate english c5141_319d072f:



    voice "voice/c51/4100020a02.opus"
    aoi "\"Uf...\""


translate english c5141_8e264461:


    xy "\"¿Está bueno?\""


translate english c5141_7c64acfe:



    voice "voice/c51/4100030a02.opus"
    aoi "\"No mucho.\""


translate english c5141_f94c5dc3:


    "Deja su lata vacía en el suelo."


translate english c5141_de03063e:


    xy "\"No me sorprende...\""


translate english c5141_152cd057:


    "Eru maúlla en señal de acuerdo mientras golpea una pequeña pelota de goma."


translate english c5141_6edc57dc:


    "Este es nuestro primer almuerzo sin Miyuki."


translate english c5141_e1c966f1:


    "Naturalmente, eso significa que tampoco hay un almuerzo casero elegante."


translate english c5141_2066d11c:


    "Juntamos la comida chatarra que conseguimos de la tienda de la esquina y la cafetería, y empezamos a devorarla."


translate english c5141_b8140e38:


    "...Apesta."


translate english c5141_ae052c88:



    voice "voice/c51/4100050a02.opus"
    aoi "\"¿Cómo está tu mejilla?\""


translate english c5141_30f9e2d8:


    xy "\"¿Mm? Oh... Sí, está bien.\""


translate english c5141_32e0a3ae:


    "No me di cuenta hasta después de que Miyuki dejó una gran marca roja de mano en mi cara para que todos la vieran."


translate english c5141_a699b867:


    "La teoría popular actual entre nuestros compañeros es que debí intentar manosearla y por consiguiente me dieron una paliza."


translate english c5141_2801d404:


    "Por mucho que quiera aclarar el asunto, Miyuki no ha vuelto a clase desde entonces."


translate english c5141_18e6f39b:


    "Así que, sin oportunidad de defenderme, salí disparado del salón en cuanto sonó la campana del almuerzo."


translate english c5141_6529b8f6:


    xy "\"Me pregunto a dónde se fue Miyuki.\""


translate english c5141_f2a7ad0a:


    "Aoi se levanta en silencio."


translate english c5141_6d3d0e5b:


    "Levanta su teléfono celular en el aire—"


translate english c5141_75f01a43:



    voice "voice/c51/4100060a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c5141_768bd6b9:



    voice "voice/c51/4100070a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...\""


translate english c5141_d77b7fb3:



    voice "voice/c51/4100080a02.opus"
    aoi "\"...Boop boop.\""


translate english c5141_f9e793cf:


    xy "\"¿Todavía sin servicio?\""


translate english c5141_4fee33f6:



    voice "voice/c51/4100090a02.opus"
    aoi "\"Quizá...\""


translate english c5141_f47e5c11:



    voice "voice/c51/4100100a02.opus"
    aoi "\"Quizá Dios simplemente... se fue.\""


translate english c5141_039141b2:


    "Empieza a transmitir una vez más."


translate english c5141_072d1676:


    "Quizás es solo su forma de rezar."


translate english c5141_daf2c37e:


    "Siempre fue marginada por nuestra clase."


translate english c5141_0547d9c3:


    "Pasaba cada noche durmiendo en un café de manga."


translate english c5141_b5db44ac:


    "No encajaba en el mundo real, así que necesitaba un mundo propio."


translate english c5141_97d1f1d5:


    "Necesitaba un dios que convirtiera su realidad en un videojuego."


translate english c5141_ea84458b:


    "¿Puede su dios salvarla todavía?"


translate english c5141_a5584fd1:


    "¿O sus plegarias quedarán sin respuesta?"


translate english c5141_f7589170:



    voice "voice/c51/4100110a01.opus"
    mx "\"Oh, hola.\""


translate english c5141_d27eeafa:


    xy "\"¿Huh?\""


translate english c5141_5fa79d2a:



    voice "voice/c51/4100120a02.opus"
    aoi "\"¡¿Miyuki?!\""


translate english c5141_3dc44613:


    xy "\"No estamos imaginando cosas, ¿verdad...?\""


translate english c5141_6ba9b89c:



    voice "voice/c51/4100130a01.opus"
    mx "\"...¿Interrumpo?\""


translate english c5141_7d166ce2:


    xy "\"¡No, claro que no! ¡Te estábamos esperando!\""


translate english c5141_204bb40c:



    voice "voice/c51/4100140a01.opus"
    mx "\"Traje un almuerzo. ¿Quieren?\""


translate english c5141_8df66550:


    xy "\"¡Sí, por favor! ¿Y tú, Aoi?\""


translate english c5141_4c99cbc1:



    voice "voice/c51/4100150a02.opus"
    aoi "\"...Aoi no puede.\""


translate english c5141_ce09946c:


    xy "\"¿No tienes hambre?\""


translate english c5141_f5509409:



    voice "voice/c51/4100160a02.opus"
    aoi "\"¡Aoi... no puede comerlo...!\""


translate english c5141_f2f38acf:


    xy "\"¡Aoi! ¡Hey!\""


translate english c5141_6bbc35ce:



    voice "voice/c51/4100170a01.opus"
    mx "\"¡Alto ahí!\""


translate english c5141_51181a23:



    voice "voice/c51/4100180a02.opus"
    aoi "\"...Boop boop...\""


translate english c5141_be43f097:


    "Aoi intenta correr, pero Miyuki la detiene."


translate english c5141_7d6f7101:



    voice "voice/c51/4100190a01.opus"
    mx "\"¿A dónde crees que vas?\""


translate english c5141_e4549db3:



    voice "voice/c51/4100200a01.opus"
    mx "\"Sé que tienes hambre.\""


translate english c5141_e027cb3c:



    voice "voice/c51/4100210a02.opus"
    aoi "\"Aoi tiene un glitch.\""


translate english c5141_3a0ff620:



    voice "voice/c51/4100220a02.opus"
    aoi "\"El glitch hizo que Aoi se enamorara de Shinichi.\""


translate english c5141_70e24550:



    voice "voice/c51/4100230a02.opus"
    aoi "\"Pero Shinichi es tuyo.\""


translate english c5141_b3487277:



    voice "voice/c51/4100240a02.opus"
    aoi "\"Y se suponía que Aoi era tu amiga.\""


translate english c5141_8591349a:



    voice "voice/c51/4100250a02.opus"
    aoi "\"Lo que significa... que Aoi te traicionó.\""


translate english c5141_02c01903:



    voice "voice/c51/4100260a02.opus"
    aoi "\"Así que Aoi ya no puede ser tu ami—\""


translate english c5141_2ff76498:



    voice "voice/c51/4100270a01.opus"
    mx "\"No somos amigas.\""


translate english c5141_bbefafcb:


    xy "\"¡Miyuki!\""



translate english c5141_86f02921:



    voice "voice/c51/4100280a01.opus"
    mx "\"Somos mejores amigas.\""


translate english c5141_f12f558b:



    voice "voice/c51/4100290a02.opus"
    aoi "\"¿Mejores amigas...?\""


translate english c5141_de345a8f:



    voice "voice/c51/4100300a01.opus"
    mx "\"Mejores amigas. Mucho más cercanas que amigas normales.\""


translate english c5141_5759c86f:



    voice "voice/c51/4100310a01.opus"
    mx "\"Tú y Shinichi son muy importantes para mí.\""


translate english c5141_8ff96a72:



    voice "voice/c51/4100320a01.opus"
    mx "\"¿Cómo no iba a querer que ustedes dos sean felices?\""


translate english c5141_709c6654:



    voice "voice/c51/4100330a02.opus"
    aoi "\"Pero... tú...\""


translate english c5141_cb481385:



    voice "voice/c51/4100340a01.opus"
    mx "\"¿Crees que estoy mintiendo?\""


translate english c5141_80902841:



    voice "voice/c51/4100350a01.opus"
    mx "\"Muy bien, entonces te lo voy a demostrar.\""


translate english c5141_cfc0b1d6:


    xy "\"¿Cómo lo vas a demostrar?\""


translate english c5141_4bc99858:



    voice "voice/c51/4100360a01.opus"
    mx "\"¡Con esto!\""


translate english c5141_6ff765cb:



    voice "voice/c51/4100370a01.opus"
    mx "\"¡Después de enterarme de que ustedes dos estaban juntos, fui a casa a preparar todos mis mejores platillos!\""


translate english c5141_593d3b19:


    xy "\"¿¿Fuiste a casa por ESTO??\""


translate english c5141_024ef157:



    voice "voice/c51/4100380a01.opus"
    mx "\"No me delates con los profesores, ¿va?\""


translate english c5141_857519ae:


    "Sonríe con malicia—el tipo de sonrisa que normalmente nunca dejaría ver en clase."


translate english c5141_01a7b010:



    voice "voice/c51/4100390a02.opus"
    aoi "\"Miyuki...\""


translate english c5141_6dcb2a30:



    voice "voice/c51/4100400a02.opus"
    aoi "\"¿De verdad puedes perdonar todo lo que ha hecho Aoi?\""


translate english c5141_ebb9c273:



    voice "voice/c51/4100410a01.opus"
    mx "\"Uno no elige de quién se enamora.\""


translate english c5141_e8b2d3b9:



    voice "voice/c51/4100420a01.opus"
    mx "\"¿O no, Shinichi?\""


translate english c5141_ecef3903:


    xy "\"Sí... Así es.\""


translate english c5141_e19c600f:



    voice "voice/c51/4100430a02.opus"
    aoi "\"Miyuki...\""


translate english c5141_f4f413e2:



    voice "voice/c51/4100440a02.opus"
    aoi "\"Gra... Gra...\""


translate english c5141_8f90818b:



    voice "voice/c51/4100450a02.opus"
    aoi "\"¡¡¡Muchas gracias!!!\""


translate english c5141_e46d9ee6:



    voice "voice/c51/4100460a02.opus"
    aoi "\"Miyuki... ¡Eres la mejor! ¡Aoi te ama tanto!\""


translate english c5141_df3a4bf4:


    "Aoi lanza sus brazos alrededor de Miyuki y empieza a sollozar."


translate english c5141_304b2212:



    voice "voice/c51/4100470a01.opus"
    mx "\"Hey, vamos. No llores.\""


translate english c5141_9ba66f68:



    voice "voice/c51/4100480a02.opus"
    aoi "\"No, no entiendes.\""


translate english c5141_fd472ccc:



    voice "voice/c51/4100490a02.opus"
    aoi "\"¡Son lágrimas de felicidad!\""


translate english c5141_961dcefb:



    voice "voice/c51/4100500a01.opus"
    mx "\"Créeme, lo sé.\""


translate english c5141_e239c9c7:


    "Miyuki acaricia el cabello de Aoi mientras ella tiembla."


translate english c5141_fefc7129:


    "Pero su mirada está en algún lugar distante—"


translate english c5141_6e7751bf:


    "En algún lugar mucho más allá de los confines más lejanos del cielo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
