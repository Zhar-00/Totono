

translate english f1112b_2731622d:



    voice "voice/f11/12b00010a02.opus"
    aoi "Eso no es verdad."


translate english f1112b_660fbd71:



    voice "voice/f11/12b00020a02.opus"
    aoi "Podemos enviarles esta foto."


translate english f1112b_fde6f216:



    voice "voice/f11/12b00030a02.opus"
    aoi "Sí."


translate english f1112b_43bb6b1c:



    voice "voice/f11/12b00040a02.opus"
    aoi "Un recuerdo de cuando éramos todos amigos."


translate english f1112b_6b91c6dd:



    voice "voice/f11/12b00050a02.opus"
    aoi "Lo hará."


translate english f1112b_6b35e7c4:



    voice "voice/f11/12b00060a02.opus"
    aoi "Shinichi y Miyuki..."


translate english f1112b_2053be09:



    voice "voice/f11/12b00070a02.opus"
    aoi "Ambos esperan algo que les ayude a dar ese último paso."


translate english f1112b_54394150:



    voice "voice/f11/12b00080a02.opus"
    aoi "\"...Cierto.\""



translate english f1112b_3c9b2b4c:



    voice "voice/f11/12b00090a02.opus"
    aoi "Envíala."


translate english f1112b_d00c8d6f:



    voice "voice/f11/12b00110a02.opus"
    aoi "Gracias por venir hasta aquí."


translate english f1112b_81b5e742:



    voice "voice/f11/12b00120a02.opus"
    aoi "Pero esta vez, es adiós de verdad..."


translate english f1112b_a8f76e80:



    voice "voice/f11/12b00130a02.opus"
    aoi "¿Por ahora...?"


translate english f1112b_e9ebc0e5:



    voice "voice/f11/12b00140a02.opus"
    aoi "......"


translate english f1112b_20129bd1:



    voice "voice/f11/12b00150a02.opus"
    aoi "Pero... no podemos."


translate english f1112b_2a32329f:



    voice "voice/f11/12b00160a02.opus"
    aoi "Mis recuerdos se sincronizarán con Dios, y Aoi desaparecerá—"


translate english f1112b_3dc62ee2:



    voice "voice/f11/12b00170a02.opus"
    aoi "¡Aoi tiene que hacerlo!"


translate english f1112b_4eec1bc3:



    voice "voice/f11/12b00180a02.opus"
    aoi "Aoi será enviada a otro mundo de nuevo."


translate english f1112b_78a445f9:



    voice "voice/f11/12b00190a02.opus"
    aoi "A otro cuerpo, y otro, y otro."


translate english f1112b_88025371:



    voice "voice/f11/12b00200a02.opus"
    aoi "Una asesina de voz suave..."


translate english f1112b_39f1d574:



    voice "voice/f11/12b00210a02.opus"
    aoi "Un grimorio en forma humana..."


translate english f1112b_bcbd67c7:



    voice "voice/f11/12b00220a02.opus"
    aoi "Un ángel con una pistola..."


translate english f1112b_d0a68691:



    voice "voice/f11/12b00240a02.opus"
    aoi "Una muñeca con amnesia..."


translate english f1112b_d691b274:



    voice "voice/f11/12b00250a02.opus"
    aoi "Una bruja que protege el mundo..."


translate english f1112b_a3e2a108:



    voice "voice/f11/12b00260a02.opus"
    aoi "Una bajista en una banda de chicas..."


translate english f1112b_4cad7c9b:



    voice "voice/f11/12b00270a02.opus"
    aoi "Aoi será optimizada para el nuevo mundo..."


translate english f1112b_c2212436:



    voice "voice/f11/12b00280a02.opus"
    aoi "Y luego Aoi enamorará a un protagonista diferente, y—"


translate english f1112b_28fad400:



    voice "voice/f11/12b00290a02.opus"
    aoi "Bip bip...?"


translate english f1112b_c48974c1:



    voice "voice/f11/12b00300a02.opus"
    aoi "Sí..."


translate english f1112b_f1f5a58f:



    voice "voice/f11/12b00320a02.opus"
    aoi "Escucha, emm..."


translate english f1112b_ab56b294:



    voice "voice/f11/12b00360a02.opus"
    aoi "Si nos volvemos a encontrar, cumplamos la promesa que hicimos."


translate english f1112b_0517c32c:



    voice "voice/f11/12b00370a02.opus"
    aoi "Vamos a una cita."


translate english f1112b_3323d531:



    voice "voice/f11/12b00380a02.opus"
    aoi "Aoi estará esperando."


translate english f1112b_f67482a4:



    voice "voice/f11/12b00390a02.opus"
    aoi "Aoi nunca te olvidará."


translate english f1112b_cf337e37:



    voice "voice/f11/12b00400a02.opus"
    aoi "Aoi enviará la señal desde más allá de tu mundo..."


translate english f1112b_d16f22a0:



    voice "voice/f11/12b00410a02.opus"
    aoi "Así que..."


translate english f1112b_2167e273:



    voice "voice/f11/12b00420a02.opus"
    aoi "Ven a buscarme."


translate english f1112b_69a71b3e:



    voice "voice/f11/12b00430a02.opus"
    aoi "\"Sí.\""



translate english f1112b_d881cde9:



    voice "voice/f11/12b00440a02.opus"
    aoi "Aoi esperará por siempre jamás..."


translate english f1112b_93db8df5:



    voice "voice/f11/12b00450a02.opus"
    aoi "Así que esto es un adiós hasta entonces."


translate english f1112b_15010357:



    voice "voice/f11/12b00470a02.opus"
    aoi "Bueno, entonces..."


translate english f1112b_b1adc203:



    voice "voice/f11/12b00480a02.opus"
    aoi "Esto es adiós."


translate english strings:


    old "После того, как мы с Аой отправили передачу..."
    new "Después de que Aoi y yo enviamos la transmisión..."


    old "Мне оставалось только наблюдать за этим."
    new "Todo lo que pude hacer fue mirar."


    old "Между мирами образовалась дыра."
    new "Esta es la brecha entre mundos."


    old "Мы покинули игровой мир..."
    new "Hemos dejado el mundo del juego..."


    old "И теперь мы в пути."
    new "Y ahora estamos en tránsito."


    old "Аой возвращается к Богу..."
    new "Aoi vuelve con Dios..."


    old "А я возвращаюсь в реальный мир."
    new "Y yo vuelvo al mundo real."


    old "Делать больше нечего."
    new "No queda nada por hacer."


    old "Без Аой..."
    new "Sin Aoi..."


    old "И без выборов..."
    new "Sin elecciones..."


    old "Мир будет существовать так же, как и всегда."
    new "El mundo seguirá como siempre."


    old "Они двое никогда не придут к взаимопониманию."
    new "Las dos nunca llegarán a un entendimiento."


    old "А я могу лишь наблюдать за этим."
    new "Y todo lo que puedo hacer es observar."


    old "Да?"
    new "¿No lo es?"


    old "Это..."
    new "Eso es..."


    old "...та фотография, где мы вместе?.."
    new "...¿la foto que tomamos juntos...?"


    old "...Точно."
    new "...Cierto."


    old "Шиничи был уверен в том, что он не сможет дружить с Миюки."
    new "Shinichi estaba convencido de que no podía ser amigo de Miyuki."


    old "Так что если он увидит эту фотографию..."
    new "Así que si viera esta foto..."


    old "То, наверное, это всё изменит."
    new "Quizás cambiaría las cosas."


    old "Последний шаг, хм..."
    new "El último paso, ¿eh...?"


    old "Моя история заканчивается здесь."
    new "Mi historia termina aquí."


    old "Это электронное письмо даст им ту фору, в которой они нуждаются?"
    new "¿Este correo les dará la ayuda que necesitan?"


    old "Если честно, я не уверен."
    new "Sinceramente, no estoy seguro."


    old "С любовью в сердцах, мы нажали на кнопку отправки."
    new "Con amor en nuestros corazones, presionamos el botón de Enviar."


    old "Отныне это их история."
    new "De aquí en adelante, es su historia."


    old "История в другом мире... История, которой тут не место."
    new "Una historia en otro mundo... Una historia que no pertenece aquí."


    old "И я решил верить в них."
    new "Y elijo creer en ellos."


    old "Я надеюсь,"
    new "Rezo"


    old "что Шиничи и Миюки найдут счастье"
    new "para que Shinichi y Miyuki encuentren la felicidad"


    old "в другом мире—"
    new "en otro mundo—"


    old "...Стоп... В другом мире..."
    new "...Espera... Otro mundo..."


    old "Точно!"
    new "¡Eso es!"


    old "Да..."
    new "Sí..."


    old "Пока что."
    new "Por ahora."


    old "Давай как-нибудь сходим на свидание."
    new "Vamos a una cita pronto."


    old "Всё-таки я обещал тебе."
    new "Después de todo, te lo debo."


    old "Нет, ты не исчезнешь."
    new "No, no lo harás."


    old "Аой коснулась моей руки."
    new "Aoi toca mi mano."


    old "Поток воспоминаний тут же начал течь."
    new "De golpe, un torrente de recuerdos fluye."


    old "Воспоминания из других миров..."
    new "Recuerdos de otros mundos..."


    old "Воспоминания героинь, которых я никогда не встречал."
    new "Recuerdos de heroínas que nunca conocí."


    old "И им буду я."
    new "Y seré yo."


    old "Парень, которого ты там встретишь? Им буду я."
    new "¿El chico que conozcas allí? Seré yo."


    old "Ты ведь слияние, верно? Абстракция?"
    new "Eres una amalgama, ¿verdad? ¿Un ente abstracto?"


    old "Когда ты синхронизируешь свои воспоминания с Богом..."
    new "Cuando sincronices tus recuerdos con Dios..."


    old "Твои воспоминания связываются с каждой героиней."
    new "Tus recuerdos estarán conectados con todas las demás heroínas."


    old "Возможно, ты будешь выглядеть совершенно иначе..."
    new "Quizás te veas totalmente diferente..."


    old "Но в каждой визуальной новелле, в которую я играл после этой..."
    new "Pero en cada otra novela visual que juegue después de esta..."


    old "У каждой из героинь..."
    new "En cada una de las heroínas..."


    old "Часть тебя оказывается где-то там, в глубине души."
    new "Una parte de ti estará ahí, en el fondo."


    old "Твой глюк продолжает жить и дальше."
    new "Tu glitch seguirá vivo."


    old "Так что нам надо только встретиться вновь в другом мире."
    new "Así que todo lo que tenemos que hacer es reencontrarnos en otro mundo."


    old "Да. Буду ждать с нетерпением."
    new "Sí. Lo esperaré con ganas."


    old "Обязательно."
    new "Lo haré."


    old "Насколько далеко ты не была бы..."
    new "No importa lo lejos que puedas estar..."


    old "Я найду малейший след твоего сигнала..."
    new "Encontraré el rastro más tenue de tu señal..."


    old "И я буду идти по нему, пока не найду тебя, Аой."
    new "Y la seguiré hasta encontrarte, Aoi."


    old "Я найду тебя снова, обещаю."
    new "Lo prometo, te encontraré de nuevo."


    old "А потом опять."
    new "Y otra vez."


    old "Мы сдержим наше обещание, будучи совсем другими персонажами."
    new "Cumpliremos nuestra promesa como personajes totalmente distintos."


    old "И опять, и опять..."
    new "Y otra vez, y otra vez..."


    old "Пока не найдём нашу счастливую концовку."
    new "Hasta que encontremos nuestro final feliz."


    old "Это ненадолго."
    new "No tardará mucho."


    old "После того, как эта игра закончится..."
    new "Después de que este juego termine..."


    old "Я перейду к другим играм с различными романтическими выборами."
    new "Pasaré a otros juegos con otras opciones románticas."


    old "Меня ждут десятки новых возможностей."
    new "Docenas de nuevas posibilidades me esperan."


    old "Десятки выборов, которые можно сделать."
    new "Docenas de decisiones por tomar."


    old "Десятки концовок, которые можно получить."
    new "Docenas de finales por alcanzar."


    old "Возможно, я не влюблюсь в них по-настоящему."
    new "Quizás no me enamore de ellas de verdad."


    old "Возможно, я буду таким же безэмоциональным, как и Аой до момента потери своего телефона."
    new "Quizás esté emocionalmente ausente, como lo estaba Aoi antes de perder su teléfono."


    old "Я просто буду сохраняться и загружаться из раза в раз..."
    new "Solo guardaré y recargaré una y otra vez..."


    old "Не придавая этому никакого значения, помимо сверки с прохождением."
    new "Sin darle más vueltas que seguir una guía."


    old "Но я знаю..."
    new "Pero sé..."


    old "Аой всегда будет со мной."
    new "Aoi siempre estará conmigo."


    old "И пока я её помню..."
    new "Y mientras la recuerde..."


    old "Героини в тех играх..."
    new "Las heroínas de esos juegos..."


    old "Будут служить мне сосудами для любви Аой."
    new "Todas servirán como vasijas para el amor de Aoi."


    old "А это придаст их концовкам ещё больше глубины."
    new "Y eso les dará a sus finales aún más profundidad."


    old "А потом, вскоре, пойдут титры."
    new "Pronto pasarán los créditos."


    old "И игра закончится."
    new "Y el juego terminará."


    old "Но наши воспоминания всё ещё будут здесь."
    new "Pero nuestros recuerdos seguirán aquí."


    old "И я знаю, что однажды встречу её снова."
    new "Y sé que la volveré a encontrar algún día."


    old "Я уверен в этом."
    new "Estoy seguro de ello."


    old "И после этого мы оставили мир позади."
    new "Y así dejamos el mundo atrás."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
