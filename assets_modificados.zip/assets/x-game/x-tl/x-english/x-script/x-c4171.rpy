

translate english c4171_d42b2ffc:


    "Yuutarou está dispuesto a cortar lazos conmigo por esto."


translate english c4171_8140fd32:


    "He estado haciendo la vista gorda al respecto desde hace un tiempo, pero..."


translate english c4171_e77cb5eb:


    "...sé que no puedo quedarme sentado sin hacer nada."


translate english c4171_a0ed569b:


    xy "\"Voy a buscar a Aoi.\""


translate english c4171_8c745715:



    voice "voice/c41/7100010b01.opus"
    xtl "\"¡¡¡ESO ES, CAMPEÓN!!!\""


translate english c4171_a18c1a11:



    voice "voice/c41/7100020b01.opus"
    xtl "\"¡Eso sí es un verdadero Chico BD como nunca vi otro!\""


translate english c4171_ce097127:


    "Yuutarou rompe la carta de expulsión."


translate english c4171_93446b66:



    voice "voice/c41/7100030b01.opus"
    xtl "\"¡La búsqueda empieza hoy después de clases!\""


translate english c4171_7edacde7:


    xy "\"¿Eh? ¿Vas a venir conmigo?\""


translate english c4171_1cf08ba5:



    voice "voice/c41/7100040b01.opus"
    xtl "\"¡Pues claro! ¡Después de todo, soy tu capitán!\""


translate english c4171_16463778:


    xy "\"Jajaja... Está bien. Nos vemos entonces.\""


translate english c4171_c27a7758:



    voice "voice/c41/7100050b01.opus"
    xtl "\"¡Sin duda alguna!\""


translate english c4171_64b1ab64:


    "Intercambiamos un apretón de manos firme. Mientras tanto..."


translate english c4171_b8c2d097:



    voice "voice/c41/7100060a01.opus"
    mx "\"......\""


translate english c4171_6c36e7af:


    "...Miyuki nos fulmina en silencio desde el otro lado del salón."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
