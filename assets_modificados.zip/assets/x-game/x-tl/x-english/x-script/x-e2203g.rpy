

translate english e2203g_0464cbb6:


    xy "\"¿Qué es esto...?\""


translate english e2203g_84eb6517:



    voice "voice/e22/03g00010a01.opus"
    mx "\"¿Qué estás mirando?\""


translate english e2203g_69657135:


    xy "\"—!!!\""


translate english e2203g_3e0e13e4:


    xy "\"Emm... esteee... emmm...\""


translate english e2203g_84089cd7:



    voice "voice/e22/03g00020a01.opus"
    mx "\"¿Oh, mis fotos?\""


translate english e2203g_608ad721:


    xy "\"¡No, escucha! ¡No las revisé!\""


translate english e2203g_1ba2521b:



    voice "voice/e22/03g00030a01.opus"
    mx "\"Está bien. No me importa si lo hiciste.\""


translate english e2203g_8dfb11b0:



    voice "voice/e22/03g00040a01.opus"
    mx "\"De todos modos no tiene sentido para ti, ¿verdad?\""


translate english e2203g_4c7d337e:


    "Tiene razón."


translate english e2203g_b80be7bc:


    "Sus entradas del diario no tenían ningún sentido para mí."


translate english e2203g_026d78a0:



    voice "voice/e22/03g00050a01.opus"
    mx "\"Aun así... puedo notarlo...\""


translate english e2203g_2c0d46c6:



    voice "voice/e22/03g00060a01.opus"
    mx "\"Todo lo que escribí tuvo el efecto deseado.\""


translate english e2203g_b080c1fe:



    voice "voice/e22/03g00070a01.opus"
    mx "\"...¿No es así?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
