

translate english e2203g_0464cbb6:


    xy "\"What's this...?\""


translate english e2203g_84eb6517:



    voice "voice/e22/03g00010a01.opus"
    mx "\"What are you looking at?\""


translate english e2203g_69657135:


    xy "\"—!!!\""


translate english e2203g_3e0e13e4:


    xy "\"Uhh... er... uhhh...\""


translate english e2203g_84089cd7:



    voice "voice/e22/03g00020a01.opus"
    mx "\"Oh, my photos?\""


translate english e2203g_608ad721:


    xy "\"No, listen! I didn't look through it!\""


translate english e2203g_1ba2521b:



    voice "voice/e22/03g00030a01.opus"
    mx "\"It's okay. I don't care if you did.\""


translate english e2203g_8dfb11b0:



    voice "voice/e22/03g00040a01.opus"
    mx "\"It doesn't make any sense to you anyway, does it?\""


translate english e2203g_4c7d337e:


    "Tiene razón."


translate english e2203g_b80be7bc:


    "Sus entradas del diario no tenían ningún sentido para mí."


translate english e2203g_026d78a0:



    voice "voice/e22/03g00050a01.opus"
    mx "\"Still... I can tell...\""


translate english e2203g_2c0d46c6:



    voice "voice/e22/03g00060a01.opus"
    mx "\"Everything I wrote had the intended effect.\""


translate english e2203g_b080c1fe:



    voice "voice/e22/03g00070a01.opus"
    mx "\"...Isn't that right?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
