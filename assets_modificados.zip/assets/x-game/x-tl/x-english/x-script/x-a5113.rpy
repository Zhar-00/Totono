

translate english a5113_e5bcdd9c:



    voice "voice/a51/1300010b01.opus"
    xtl "\"Ah...! Speak of the angel, and she appears—\""


translate english a5113_5abed5b1:



    voice "voice/a51/1300020a01.opus"
    mx "\"Shinichi!\""


translate english a5113_89891df7:



    voice "voice/a51/1300030b01.opus"
    xtl "\"...Huh?\""


translate english a5113_634e1af5:



    voice "voice/a51/1300040a01.opus"
    mx "\"Hello? Shinichi? Can you hear me?\""


translate english a5113_ab14a3a8:


    xy "\"......What do you want?\""


translate english a5113_4bbcd0aa:


    "Normalmente Miyuki está toda sonrisas cuando entra al salón, pero hoy su expresión es pétrea..."


translate english a5113_2cfffe4d:


    "...y acaba de hablarme a mí, el don nadie supremo."


translate english a5113_bd86c7e9:


    "De golpe, todo el salón se queda extrañamente silencioso."


translate english a5113_b9a7e3bd:



    voice "voice/a51/1300050a01.opus"
    mx "\"I need to borrow you.\""


translate english a5113_40daf03e:


    xy "\"What? And go where?\""


translate english a5113_e85d7518:



    voice "voice/a51/1300060a01.opus"
    mx "\"Just come with me!\""


translate english a5113_ea78423d:


    "Sin querer aceptar un no por respuesta, Miyuki empieza a arrastrarme a la fuerza."


translate english a5113_01b12050:


    "La sigo a regañadientes fuera del salón, intentando ignorar todas las miradas curiosas que recibimos."


translate english a5113_ee40edb5:



    voice "voice/a51/1300070b01.opus"
    xtl "\"Backstabber... Backstabber... Backstabber blues...\""


translate english a5113_b72cc779:



    voice "voice/a51/1300080b01.opus"
    xtl "\"Doo doo doo... doo doo doo doo... doo doo doo doo...\""


translate english a5113_426c3870:


    "La lastimera canción de Yuutarou resuena en el pasillo."


translate english a5113_7fa9a2ec:


    "Dios, ahora toda la clase seguro va a esparcir rumores sobre mí..."


translate english a5113_1282ba5e:


    "Esto es lo peor..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
