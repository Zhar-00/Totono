

translate english e2322b_42088161:


    "Uf... la cagué..."


translate english e2322b_53c61612:


    "Respiro hondo y me preparo para intentarlo de nuevo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
