

translate english d6153_6e4f9e7e:


    xy "\"...¿Qué?\""


translate english d6153_4a5b7f9a:


    "Aoi debería estar en casa ahora mismo, y sin embargo no contesta."


translate english d6153_5ff1e8fd:


    "El teléfono no deja de sonar y sonar y sonar."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
