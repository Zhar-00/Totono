

translate english a2111_47e8b5d7:



    voice "voice/a21/1100010b01.opus"
    xtl "\"I need to talk to you about my dreams!\""


translate english a2111_084396a8:


    "Yuutarou me suelta esto en el segundo en que entro por la puerta."


translate english a2111_964be701:


    xy "\"What? I thought your dreams died or something.\""


translate english a2111_16639a1c:



    voice "voice/a21/1100020b01.opus"
    xtl "Ahí es cuando sabes que es lo genuino.\""


translate english a2111_1648a643:


    xy "\"Uh, right. I'll take your word for it.\""


translate english a2111_adc33c0d:



    voice "voice/a21/1100030b01.opus"
    xtl "\"Look inside your heart!\""


translate english a2111_50366c12:


    xy "\"No can do. So, what's up?\""


translate english a2111_d032fc7d:



    voice "voice/a21/1100040b01.opus"
    xtl "\"It's about the... dream I found outside.\""


translate english a2111_05bba846:


    "Los calzones azules a rayas de su hermano. Claro."


translate english a2111_015cfa83:



    voice "voice/a21/1100050b01.opus"
    xtl "Y resulta que...\""


translate english a2111_024583d5:



    voice "voice/a21/1100060b01.opus"
    xtl "\"He's a 'crossplayer,' whatever that means.\""


translate english a2111_4f3fa208:


    xy "\"So he likes to cosplay in women's clothes?\""


translate english a2111_76bd2982:



    voice "voice/a21/1100070b01.opus"
    xtl "\"Yeah. Apparently they call it 'otokonoko'? Or 'femboy'? Something like that.\""


translate english a2111_8ec17ca4:



    voice "voice/a21/1100080b01.opus"
    xtl "\"Look inside your heart!\""


translate english a2111_d0d6f516:



    voice "voice/a21/1100090b01.opus"
    xtl "\"...Real talk, I don't really get it.\""


translate english a2111_c3382385:



    voice "voice/a21/1100100b01.opus"
    xtl "\"Anyway, what should I do?\""


translate english a2111_d63c6ec7:


    xy "\"Do? About what part?\""


translate english a2111_fcdd807b:


    "Nunca había visto a Yuutarou verse tan conflictuado por algo. Suelto un suspiro."


translate english a2111_f91a0640:


    xy "\"What is it that you WANT to do?\""


translate english a2111_467fdb41:



    voice "voice/a21/1100110b01.opus"
    xtl "\"He's got a job as a magazine model, and he actually really pulls off the look. Though he's not so much 'sexy' as 'cutesy'...\""


translate english a2111_275418a7:



    voice "voice/a21/1100120b01.opus"
    xtl "\"It's just... kinda weird, don't you think?\""


translate english a2111_84996782:


    xy "\"I mean... It's definitely uncommon...\""


translate english a2111_fc4342f3:



    voice "voice/a21/1100130b01.opus"
    xtl "\"Like, I wanna support his life choices and all... I try to stay woke, y'know?\""


translate english a2111_60bc3b17:



    voice "voice/a21/1100140b01.opus"
    xtl "\"But when it's your family, it's just... It's hard to accept it right away.\""


translate english a2111_f82de2fd:



    voice "voice/a21/1100150b01.opus"
    xtl "\"Man, I feel so stupid. I don't understand the first thing about him...\""


translate english a2111_3263a0d9:


    "Yuutarou lucha por encontrar las palabras."


translate english a2111_edad6af6:


    "Antes de que preguntes, sí, siempre es así de intenso. Es simplemente como es."


translate english a2111_579f3b29:


    xy "\"Eh, I wouldn't tear your hair out about it if I were you, personally.\""


translate english a2111_6b30f410:


    xy "\"He's kept it to himself for over 10 years now, right? You've had, like, a day. Of course you're not going to understand right away.\""


translate english a2111_930fa55b:


    xy "\"Put it another way—all you need is a little time.\""


translate english a2111_74e65128:



    voice "voice/a21/1100160b01.opus"
    xtl "\"You... You think so?\""


translate english a2111_5d10b845:



    voice "voice/a21/1100170a01.opus"
    mx "\"Good morning!\""


translate english a2111_2b36d4f5:



    voice "voice/a21/1100180a02.opus"
    aoi "\"Morning, Miyuki.\""


translate english a2111_00e06a52:



    voice "voice/a21/1100190a02.opus"
    aoi "\"Nice weather today.\""


translate english a2111_975d86d5:



    voice "voice/a21/1100200b01.opus"
    xtl "\"Poor Mukou... Sone-san won't give her the time of day. At this point it's getting kinda hard to watch...\""


translate english a2111_dc132059:


    xy "\"You never know. Today might be different.\""


translate english a2111_555aef5f:



    voice "voice/a21/1100210b01.opus"
    xtl "\"Different how...?\""


translate english a2111_22189404:



    voice "voice/a21/1100220a01.opus"
    mx "\"Say, Mukou-san... Did you happen to finish your math homework?\""


translate english a2111_5afa8431:



    voice "voice/a21/1100230a02.opus"
    aoi "\"Homework?\""


translate english a2111_7f996ded:



    voice "voice/a21/1100240a01.opus"
    mx "\"From math class, yes.\""


translate english a2111_a8279965:



    voice "voice/a21/1100250a02.opus"
    aoi "\"Not yet.\""


translate english a2111_a1219fcd:



    voice "voice/a21/1100260a01.opus"
    mx "\"You're not busy at lunch, right? Why don't we go over it together?\""


translate english a2111_e641af99:



    voice "voice/a21/1100270a02.opus"
    aoi "\"Boop boop...?\""


translate english a2111_c0fcd76f:


    "Aoi se queda helada en su lugar como si el tiempo mismo se hubiera detenido."


translate english a2111_5139c954:



    voice "voice/a21/1100280a01.opus"
    mx "\"Yes or no?\""


translate english a2111_dcc39baa:



    voice "voice/a21/1100290a02.opus"
    aoi "\"G-Got it! Let's do it!\""


translate english a2111_5da48bdb:



    voice "voice/a21/1100300a02.opus"
    aoi "\"Please tutor me!\""


translate english a2111_ec6b6ded:



    voice "voice/a21/1100310a01.opus"
    mx "\"Just FYI, I won't let you copy my answers.\""


translate english a2111_17594924:



    voice "voice/a21/1100320a02.opus"
    aoi "\"Got it!\""


translate english a2111_1d80c403:


    "Y así, siento que el ambiente del salón cambia."


translate english a2111_d3a153d7:


    "Hasta ahora, Miyuki ha estado ignorando a Aoi a diestra y siniestra, y todos los demás simplemente lo aceptaban."


translate english a2111_c6665c2b:


    "Pero ahora que Miyuki cambió de actitud, es posible que el resto de la clase también lo haga."


translate english a2111_dbfaf984:



    voice "voice/a21/1100330b01.opus"
    xtl "\"That's it! The answer was right in front of me all along!\""


translate english a2111_36f4c8f3:


    xy "\"What's up, Yuutarou?\""


translate english a2111_b08cb193:



    voice "voice/a21/1100340b01.opus"
    xtl "\"People can reach an understanding as long as they try!\""


translate english a2111_4b926203:



    voice "voice/a21/1100350b01.opus"
    xtl "\"Isn't that right, Shinichi?!\""


translate english a2111_13ff8223:


    xy "\"S-Sure... That's one way to look at it... I think...\""


translate english a2111_2f88a50f:



    voice "voice/a21/1100360b01.opus"
    xtl "\"I just need to give it 110%%!\""


translate english a2111_da154a24:



    voice "voice/a21/1100370b01.opus"
    xtl "\"If I'm going to understand how Ryuujirou feels, then that means I, too, need to start crossdr—\""


translate english a2111_bc81ca43:


    xy "\"Yeahhh, good luck with that.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
