

translate english a2111_47e8b5d7:



    voice "voice/a21/1100010b01.opus"
    xtl "\"¡Necesito hablar contigo sobre mis sueños!\""


translate english a2111_084396a8:


    "Yuutarou me suelta esto en el segundo en que entro por la puerta."


translate english a2111_964be701:


    xy "\"¿Qué? Pensé que tus sueños estaban muertos o algo así.\""


translate english a2111_16639a1c:



    voice "voice/a21/1100020b01.opus"
    xtl "Ahí es cuando sabes que es lo genuino.\""


translate english a2111_1648a643:


    xy "\"Eh, cierto. Te tomaré la palabra.\""


translate english a2111_adc33c0d:



    voice "voice/a21/1100030b01.opus"
    xtl "\"¡Mira dentro de tu corazón!\""


translate english a2111_50366c12:


    xy "\"No puedo. Entonces, ¿qué pasa?\""


translate english a2111_d032fc7d:



    voice "voice/a21/1100040b01.opus"
    xtl "\"Es sobre el... sueño que encontré afuera.\""


translate english a2111_05bba846:


    "Los calzones azules a rayas de su hermano. Claro."


translate english a2111_015cfa83:



    voice "voice/a21/1100050b01.opus"
    xtl "Y resulta que...\""


translate english a2111_024583d5:



    voice "voice/a21/1100060b01.opus"
    xtl "\"Él es un \"crossplayer\", lo que sea que signifique.\""


translate english a2111_4f3fa208:


    xy "\"¿Así que le gusta el cosplay con ropa de mujer?\""


translate english a2111_76bd2982:



    voice "voice/a21/1100070b01.opus"
    xtl "\"Sí. Aparentemente le llaman \"otokonoko\"? ¿O \"femboy\"? Algo así.\""


translate english a2111_8ec17ca4:



    voice "voice/a21/1100080b01.opus"
    xtl "\"¡Mira dentro de tu corazón!\""


translate english a2111_d0d6f516:



    voice "voice/a21/1100090b01.opus"
    xtl "\"...Hablando en serio, no lo entiendo muy bien.\""


translate english a2111_c3382385:



    voice "voice/a21/1100100b01.opus"
    xtl "\"En fin, ¿qué debería hacer?\""


translate english a2111_d63c6ec7:


    xy "\"¿Hacer? ¿En qué parte?\""


translate english a2111_fcdd807b:


    "Nunca había visto a Yuutarou verse tan conflictuado por algo. Suelto un suspiro."


translate english a2111_f91a0640:


    xy "\"¿Qué es lo que QUIERES hacer?\""


translate english a2111_467fdb41:



    voice "voice/a21/1100110b01.opus"
    xtl "\"Tiene un trabajo como modelo de revista, y de hecho le queda muy bien el look. Aunque no es tanto \"sexy\" como \"tierno\"...\""


translate english a2111_275418a7:



    voice "voice/a21/1100120b01.opus"
    xtl "\"Es solo que... es un poco raro, ¿no crees?\""


translate english a2111_84996782:


    xy "\"Digo... Definitivamente es poco común...\""


translate english a2111_fc4342f3:



    voice "voice/a21/1100130b01.opus"
    xtl "\"O sea, quiero apoyar sus decisiones de vida y todo... Trato de estar al día, ¿sabes?\""


translate english a2111_60bc3b17:



    voice "voice/a21/1100140b01.opus"
    xtl "\"Pero cuando es tu familia, es solo que... Es difícil aceptarlo de inmediato.\""


translate english a2111_f82de2fd:



    voice "voice/a21/1100150b01.opus"
    xtl "\"Hombre, me siento tan estúpido. No entiendo lo primero sobre él...\""


translate english a2111_3263a0d9:


    "Yuutarou lucha por encontrar las palabras."


translate english a2111_edad6af6:


    "Antes de que preguntes, sí, siempre es así de intenso. Es simplemente como es."


translate english a2111_579f3b29:


    xy "\"Eh, yo no me arrancaría los pelos por eso si fuera tú, personalmente.\""


translate english a2111_6b30f410:


    xy "\"Lo ha mantenido en secreto por más de 10 años, ¿verdad? Tú has tenido, como, un día. Claro que no lo vas a entender de inmediato.\""


translate english a2111_930fa55b:


    xy "\"Dicho de otra forma— todo lo que necesitas es un poco de tiempo.\""


translate english a2111_74e65128:



    voice "voice/a21/1100160b01.opus"
    xtl "\"¿Tú... Tú crees?\""


translate english a2111_5d10b845:



    voice "voice/a21/1100170a01.opus"
    mx "\"¡Buenos días!\""


translate english a2111_2b36d4f5:



    voice "voice/a21/1100180a02.opus"
    aoi "\"Buenos días, Miyuki.\""


translate english a2111_00e06a52:



    voice "voice/a21/1100190a02.opus"
    aoi "\"Bonito clima hoy.\""


translate english a2111_975d86d5:



    voice "voice/a21/1100200b01.opus"
    xtl "\"Pobre Mukou... Sone-san no le da ni la hora. A estas alturas ya es un poco difícil de ver...\""


translate english a2111_dc132059:


    xy "\"Nunca se sabe. Hoy podría ser diferente.\""


translate english a2111_555aef5f:



    voice "voice/a21/1100210b01.opus"
    xtl "\"¿Diferente cómo...?\""


translate english a2111_22189404:



    voice "voice/a21/1100220a01.opus"
    mx "\"Dime, Mukou-san... ¿Por casualidad terminaste la tarea de mate?\""


translate english a2111_5afa8431:



    voice "voice/a21/1100230a02.opus"
    aoi "\"¿Tarea?\""


translate english a2111_7f996ded:



    voice "voice/a21/1100240a01.opus"
    mx "\"De la clase de mate, sí.\""


translate english a2111_a8279965:



    voice "voice/a21/1100250a02.opus"
    aoi "\"Todavía no.\""


translate english a2111_a1219fcd:



    voice "voice/a21/1100260a01.opus"
    mx "\"No estás ocupada al almuerzo, ¿verdad? ¿Por qué no la repasamos juntas?\""


translate english a2111_e641af99:



    voice "voice/a21/1100270a02.opus"
    aoi "\"¿Bip bip...?\""


translate english a2111_c0fcd76f:


    "Aoi se queda helada en su lugar como si el tiempo mismo se hubiera detenido."


translate english a2111_5139c954:



    voice "voice/a21/1100280a01.opus"
    mx "\"¿Sí o no?\""


translate english a2111_dcc39baa:



    voice "voice/a21/1100290a02.opus"
    aoi "\"¡E-Entendido! ¡Hagámoslo!\""


translate english a2111_5da48bdb:



    voice "voice/a21/1100300a02.opus"
    aoi "\"¡Por favor, dame clases!\""


translate english a2111_ec6b6ded:



    voice "voice/a21/1100310a01.opus"
    mx "\"Solo para que sepas, no te dejaré copiar mis respuestas.\""


translate english a2111_17594924:



    voice "voice/a21/1100320a02.opus"
    aoi "\"¡Entendido!\""


translate english a2111_1d80c403:


    "Y así, siento que el ambiente del salón cambia."


translate english a2111_d3a153d7:


    "Hasta ahora, Miyuki ha estado ignorando a Aoi a diestra y siniestra, y todos los demás simplemente lo aceptaban."


translate english a2111_c6665c2b:


    "Pero ahora que Miyuki cambió de actitud, es posible que el resto de la clase también lo haga."


translate english a2111_dbfaf984:



    voice "voice/a21/1100330b01.opus"
    xtl "\"¡Eso es! ¡La respuesta estaba justo frente a mí todo el tiempo!\""


translate english a2111_36f4c8f3:


    xy "\"¿Qué pasa, Yuutarou?\""


translate english a2111_b08cb193:



    voice "voice/a21/1100340b01.opus"
    xtl "\"¡La gente puede llegar a un entendimiento mientras lo intente!\""


translate english a2111_4b926203:



    voice "voice/a21/1100350b01.opus"
    xtl "\"¿¡No es así, Shinichi!?\""


translate english a2111_13ff8223:


    xy "\"C-Claro... Es una forma de verlo... Creo...\""


translate english a2111_2f88a50f:



    voice "voice/a21/1100360b01.opus"
    xtl "\"I just need to give it 110%%!\""


translate english a2111_da154a24:



    voice "voice/a21/1100370b01.opus"
    xtl "\"Si voy a entender cómo se siente Ryuujirou, entonces eso significa que yo también tengo que empezar a hacer crossdr—\""


translate english a2111_bc81ca43:


    xy "\"Síp, buena suerte con eso.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
