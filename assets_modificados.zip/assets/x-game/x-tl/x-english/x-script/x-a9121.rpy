

translate english a9121_08691ccf:


    "El sol se pone sobre el pueblo."


translate english a9121_3a4ff640:


    "Lenta pero seguramente, se hunde más allá del horizonte."


translate english a9121_9033fce7:


    "El cielo carmesí quita el aliento..."


translate english a9121_c91db35f:


    "Casi como un telón de fondo."


translate english a9121_10ef895a:


    "En cuanto a mí, solo puedo ser yo mismo."


translate english a9121_d66375da:


    "Atrapado dentro de los confines de mi pequeño mundo, viviré una vida normal, y luego la historia llegará a su fin antes de que me dé cuenta."


translate english a9121_d92ca203:


    "Sin acción ascendente, sin clímax, sin acción descendente, sin una pequeña y ordenada resolución."


translate english a9121_1964bec0:


    "Aquí me encuentro, estancado, con todas las demás rutas cerradas para mí."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
