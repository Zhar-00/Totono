

translate english a3171_9c1c250d:


    xy "\"Gracias por venir conmigo.\""


translate english a3171_8ac827b2:



    voice "voice/a31/7100010a01.opus"
    mx "\"¡Como si no fuera a hacerlo!\""


translate english a3171_d22cfa22:



    voice "voice/a31/7100020a01.opus"
    mx "\"O sea, Aoi es súper predecible, ¿sabes?\""


translate english a3171_07391eab:



    voice "voice/a31/7100030a01.opus"
    mx "\"Así que, obvio, ¡tenía que hacer ALGO!\""


translate english a3171_dbf883a1:



    voice "voice/a31/7100040a01.opus"
    mx "\"En fin, SÍ sabes a dónde fue, ¿no?\""


translate english a3171_460d494b:


    xy "\"Sí... Al menos, estoy bastante seguro.\""


translate english a3171_7d7b1459:



    voice "voice/a31/7100050a01.opus"
    mx "\"¿La escuela...?\""


translate english a3171_e296565f:


    "No la culpo por ser escéptica."


translate english a3171_06d1aa0e:


    "A pesar del cariño de Aoi por la azotea, me había dicho que no había forma de que se hubiera colado en el predio de la escuela de noche."


translate english a3171_6f668ab9:


    xy "\"¿Ves? Mira.\""


translate english a3171_21da24e0:



    voice "voice/a31/7100060a01.opus"
    mx "\"¡Oh!\""


translate english a3171_f0e56abf:


    "Alguien ha dejado la reja peatonal abierta."


translate english a3171_9bac642e:



    voice "voice/a31/7100070a01.opus"
    mx "\"Ni siquiera me di cuenta...\""


translate english a3171_2a46b778:


    xy "\"Vamos.\""


translate english a3171_99db0e2a:


    "Efectivamente, las puertas de la entrada principal también han quedado entreabiertas."


translate english a3171_28a9de78:



    voice "voice/a31/7100080a01.opus"
    mx "\"De alguna forma dudo que los conserjes simplemente hayan olvidado cerrar las puertas...\""


translate english a3171_a51a916d:


    "El edificio escolar está completamente desierto."


translate english a3171_40090515:


    "Mientras nos cambiamos a los zapatos de interior, el más leve golpeteo de nuestras suelas sobre el linóleo parece retumbar como un disparo."


translate english a3171_1941b64c:


    xy "\"Por aquí.\""


translate english a3171_ec7269f0:



    voice "voice/a31/7100090a01.opus"
    mx "\"¿No está en el salón?\""


translate english a3171_43a55c07:


    xy "\"Mira abajo.\""


translate english a3171_3fd30928:


    "Hay un rastro de gotas de agua que lleva en la dirección opuesta: hacia el gimnasio."



translate english a3171_a9a5106c:



    voice "voice/a31/7100100a01.opus"
    mx "\"¿Cómo lo supiste?\""


translate english a3171_bb58c512:


    xy "\"¿Eh?\""


translate english a3171_b50754e9:



    voice "voice/a31/7100110a01.opus"
    mx "\"Bueno, dijiste que tenías una idea y volviste a tu casa. ¿Pero para qué?\""


translate english a3171_9e3d89f2:


    xy "\"Oh... bueno, em...\""


translate english a3171_eb314f51:


    "Sinceramente... no estoy seguro de cómo explicárselo."


translate english a3171_e2109f71:


    "The whole reason we're here is because there's a scene in the game where a soaking-wet \"Aoi\"empapada se refugia en el gimnasio."


translate english a3171_3367757c:


    "Pero sé que Miyuki odia confundir los videojuegos con la realidad, y eso hace que sea aún más complicado de explicar..."


translate english a3171_f038d699:



    voice "voice/a31/7100120a01.opus"
    mx "\"...Está bien. No te preocupes por eso ahora.\""


translate english a3171_212acc44:


    "Miyuki suspira. Debe de haber percibido mi vacilación."


translate english a3171_d2799e3d:



    voice "voice/a31/7100130a01.opus"
    mx "\"Solo dime después, ¿sí?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
