

translate english e3423c_f1a1f2c4:



    voice "voice/e34/23c00010b02.opus"
    kmsm "\"ENTENDIDO.\""


translate english e3423c_0a535628:



    voice "voice/e34/23c00020b02.opus"
    kmsm "\"WE CANNOT FORCE [[YOU].\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
