

translate english e2182a_e0455701:


    xy "\"I want you, Miyuki.\""


translate english e2182a_9e3917ac:



    voice "voice/e21/82a00010a01.opus"
    mx "\"Huh...?\""



translate english e2182a_e9da7558:



    voice "voice/e21/82a00020a01.opus"
    mx "\"M-Me...?\""


translate english e2182a_ecb717ff:


    "Su cara entera se sonroja de rojo, y se tambalea."


translate english e2182a_882d408b:


    xy "\"Wh-Whoa there... You okay?\""


translate english e2182a_c51fe91f:



    voice "voice/e21/82a00030a01.opus"
    mx "\"S-Sorry... You just kinda caught me off-guard, that's all.\""


translate english e2182a_c632c1e5:


    xy "\"Oh... Sorry about that. I take it back—\""


translate english e2182a_a02a08dd:



    voice "voice/e21/82a00040a01.opus"
    mx "\"N-No!\""


translate english e2182a_32b0a383:



    voice "voice/e21/82a00050a01.opus"
    mx "\"I... I was maybe thinking the same thing, so...\""


translate english e2182a_e82399b0:


    xy "\"O-Oh...\""


translate english e2182a_9214696e:


    "Su admisión apenas audible me hace inhalar bruscamente."


translate english e2182a_fbd76575:


    "Sé que debe estar nerviosa, pero créeme, yo estoy igual de nervioso."


translate english e2182a_af96cbd9:


    xy "\"Miyuki...\""



translate english e2182a_e121d508:



    voice "voice/e21/82a00060a01.opus"
    mx "\"Shinichi...?\""


translate english e2182a_5867799d:


    "Me acerco—"


translate english e2182a_72f31ee4:



    voice "voice/e21/82a00070a01.opus"
    mx "\"W-We can't! Not here!\""


translate english e2182a_b5c72919:



    voice "voice/e21/82a00080a01.opus"
    mx "\"I need time to prepare myself emotionally... and besides, I'm all sweaty, and—\""


translate english e2182a_20477946:



    voice "voice/e21/82a00090a01.opus"
    mx "\"—and the owner's right there!\""


translate english e2182a_e48cddb1:


    xy "\"O-Oh yeah... Right...\""


translate english e2182a_bfdc913c:


    "Es tan linda que casi pierdo el control... pero tiene razón. Realmente no podemos hacer esto aquí."


translate english e2182a_5234d086:


    "...Ah, bueno."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
