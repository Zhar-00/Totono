

translate english c6111_2ff657ed:


    xy "\"37.5 grados...\""


translate english c6111_d12d2946:


    xy "\"Eso es fiebre, sin duda.\""


translate english c6111_1baed854:



    voice "voice/c61/1100010a02.opus"
    aoi "\"Boop boop...\""


translate english c6111_f6a4586b:


    "Su cara ya está completamente demacrada."


translate english c6111_b2c73bec:


    "Ha estado enferma mucho últimamente, pero pensar que empeoraría así el día de la función..."


translate english c6111_2c9c7abf:



    voice "voice/c61/1100020a02.opus"
    aoi "\"Tengo que alistarme para... la cita...\""


translate english c6111_3a41f746:


    "Se retuerce en el sofá, con el pasador aferrado en la mano."


translate english c6111_75b10c33:


    xy "\"Solo duerme un poco.\""


translate english c6111_6a527da4:



    voice "voice/c61/1100030a02.opus"
    aoi "\"Pero...\""


translate english c6111_6ab2fe8d:


    xy "\"Es mi cumpleaños la próxima semana, ¿sabes?\""


translate english c6111_2841892f:


    xy "\"Y has estado enferma mucho últimamente. Tienes que recuperarte del todo para entonces, ¿me oyes?\""


translate english c6111_4b89c0e9:



    voice "voice/c61/1100040a02.opus"
    aoi "\"Tu cumpleaños...\""


translate english c6111_aca31809:


    xy "\"Exacto. Y no estaré muy feliz si no mejoras.\""


translate english c6111_ef9aa7a2:


    xy "\"Así que necesitas descansar y recuperarte.\""


translate english c6111_474f45e3:



    voice "voice/c61/1100050a02.opus"
    aoi "\"¿Te... pones triste... cuando Aoi está enferma...?\""


translate english c6111_ad692f36:


    xy "\"¡Claro!\""


translate english c6111_704d124d:



    voice "voice/c61/1100060a02.opus"
    aoi "\"Boop boop...\""


translate english c6111_59cab165:


    "Aoi aprieta los labios y vacila un momento."


translate english c6111_80ed4b24:



    voice "voice/c61/1100070a02.opus"
    aoi "\"Bien. Aoi se enfocará en mejorar.\""


translate english c6111_c817f21b:



    voice "voice/c61/1100080a02.opus"
    aoi "\"En cambio, más te vale ir a divertirte esta noche en la obra.\""


translate english c6111_f57678a7:


    xy "\"Me quedo aquí.\""


translate english c6111_4b50a5ec:



    voice "voice/c61/1100090a02.opus"
    aoi "\"¡No! ¡Para nada!\""


translate english c6111_28c8cf92:



    voice "voice/c61/1100100a02.opus"
    aoi "\"¡Miyuki te está esperando!\""


translate english c6111_c8610394:


    xy "\"Nah. Dejó el papel protagónico—\""


translate english c6111_35caf6a8:



    voice "voice/c61/1100110a02.opus"
    aoi "\"Eso no importa.\""


translate english c6111_f9452b2f:



    voice "voice/c61/1100120a02.opus"
    aoi "\"Ella te dio los boletos, así que deberías ir.\""


translate english c6111_0accd139:


    xy "\"......\""


translate english c6111_4733ae74:


    "Su voz es inusualmente firme, y me quedo en silencio."


translate english c6111_64ade062:


    xy "\"¿Seguro que puedes dormirte sin mí aquí?\""


translate english c6111_f66bbc8f:



    voice "voice/c61/1100130a02.opus"
    aoi "\"Sí.\""


translate english c6111_75c8b797:


    xy "\"No juegues con Eru, ¿me oyes?\""


translate english c6111_d233c791:



    voice "voice/c61/1100140a02.opus"
    aoi "\"Bien.\""



translate english c6111_2ac3f81e:


    "No me siento bien con esto, pero sé lo obstinada que puede ser con estas cosas."


translate english c6111_f722fbce:


    "SÍ le debo a Miyuki por conseguirnos los boletos, así que supongo que debería ceder e ir a ver la obra."


translate english c6111_5e47eaef:


    xy "\"Bien, vuelvo más tarde.\""


translate english c6111_0cfbebcb:



    voice "voice/c61/1100150a02.opus"
    aoi "\"¡Shinichi!\""


translate english c6111_43a7afaa:


    "Justo entonces, Aoi se sienta erguida en el sofá."


translate english c6111_ffd0a44d:



    voice "voice/c61/1100160a02.opus"
    aoi "\"Escucha, Shinichi.\""


translate english c6111_dd400ad9:



    voice "voice/c61/1100170a02.opus"
    aoi "\"¿Sabes...\""


translate english c6111_ba01f729:



    voice "voice/c61/1100180a02.opus"
    aoi "\"...cuándo es mi cumpleaños?\""


translate english c6111_93dcd96b:


    xy "\"Ehhhh... No creo que alguna vez me lo hayas dicho...\""


translate english c6111_c59a471c:



    voice "voice/c61/1100190a02.opus"
    aoi "\"Es el 23 de mayo.\""


translate english c6111_1c6b7736:


    "23 de mayo..."


translate english c6111_71048021:


    xy "\"Así que naciste antes que yo, ¿eh?\""


translate english c6111_19a2e5f5:



    voice "voice/c61/1100200a02.opus"
    aoi "\"Aoi te va a enseñar mi número de código.\""


translate english c6111_21cafa1b:


    xy "\"¿Qué es un número de código?\""


translate english c6111_25bf68ce:


    "Asumo que esto es solo otro de los tics verbales de Aoi..."


translate english c6111_0defd4a5:


    "...y sin embargo su expresión es de acero."


translate english c6111_5791e5d7:



    voice "voice/c61/1100210a02.opus"
    aoi "\"Dios me dio este número de teléfono especial para emergencias.\""


translate english c6111_dcd2c236:



    voice "voice/c61/1100220a02.opus"
    aoi "\"Si me pasa algo, puedes marcar este número para traerme de vuelta.\""


translate english c6111_1d5a9738:


    xy "\"¿Traerte de vuelta... de dónde...?\""


translate english c6111_f989ba1d:



    voice "voice/c61/1100230a02.opus"
    aoi "\"Solo memorízalo, ¿sí?\""


translate english c6111_efe1212c:


    xy "\"¡No, espera! ¿A dónde vas?\""


translate english c6111_12b3149d:



    voice "voice/c61/1100240a02.opus"
    aoi "\"A ningún lado. Está bien.\""


translate english c6111_42191684:



    voice "voice/c61/1100250a02.opus"
    aoi "\"Esto es solo una medida de seguridad. Ahora memoriza este número de código.\""


translate english c6111_9c644e03:



    voice "voice/c61/1100270a02.opus"
    aoi "\"Primero, marca 999. Fácil. Luego marca mi cumpleaños, 0523, dos veces.\""


translate english c6111_28874e15:



    voice "voice/c61/1100280a02.opus"
    aoi "\"Ese es mi número de código, ¿sí?\""


translate english c6111_c79b63dc:


    "Primero, marca 999..."


translate english c6111_7d535040:


    "Luego teclea el cumpleaños de Aoi dos veces."


translate english c6111_c17bc059:


    "999-0523-0523."



translate english c6111_22bb6994:


    "Lo repito una y otra vez en mi mente."


translate english c6111_c4a5d78f:



    voice "voice/c61/1100290a02.opus"
    aoi "\"Si puedes recordar mi cumpleaños, no lo olvidarás.\""


translate english c6111_27711e4c:



    voice "voice/c61/1100300a02.opus"
    aoi "\"Así que asegúrate de memorizarlo.\""


translate english c6111_8c7a1388:



    voice "voice/c61/1100310a02.opus"
    aoi "\"Prométemelo... ¿sí?\""


translate english c6111_3c568a45:


    xy "\"Bien. Lo prometo.\""


translate english c6111_e504a458:


    "No estoy seguro de dónde diablos salió eso..."


translate english c6111_5d5b2134:


    "Quizás debería anotar este número en algún lugar."


translate english c6111_c39cefd6:



    voice "voice/c61/1100320a02.opus"
    aoi "\"Shinichi...\""



translate english c6111_a352a2bd:



    voice "voice/c61/1100330a02.opus"
    aoi "\"Aoi quiere que sepas...\""


translate english c6111_0069694e:



    voice "voice/c61/1100340a02.opus"
    aoi "\"...que Aoi está enamorada de ti.\""


translate english c6111_79ec2342:


    xy "\"Cierto... Gracias.\""


translate english c6111_600799c8:


    "Su cara está sonrojada de un rojo brillante."


translate english c6111_9c87f2e0:


    "Nadie me había dicho eso antes..."


translate english c6111_2cf9aa1e:


    "Parte de mí está encantada..."


translate english c6111_74adc74d:


    "...y sin embargo, de alguna manera, algo parece estar mal con ella."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
