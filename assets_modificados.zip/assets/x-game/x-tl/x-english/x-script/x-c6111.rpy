

translate english c6111_2ff657ed:


    xy "\"37.5 degrees...\""


translate english c6111_d12d2946:


    xy "\"That's a fever, alright.\""


translate english c6111_1baed854:



    voice "voice/c61/1100010a02.opus"
    aoi "\"Boop boop...\""


translate english c6111_f6a4586b:


    "Su cara ya está completamente demacrada."


translate english c6111_b2c73bec:


    "Ha estado enferma mucho últimamente, pero pensar que empeoraría así el día de la función..."


translate english c6111_2c9c7abf:



    voice "voice/c61/1100020a02.opus"
    aoi "\"Gotta get ready for... the date...\""


translate english c6111_3a41f746:


    "Se retuerce en el sofá, con el pasador aferrado en la mano."


translate english c6111_75b10c33:


    xy "\"Just get some sleep.\""


translate english c6111_6a527da4:



    voice "voice/c61/1100030a02.opus"
    aoi "\"But...\""


translate english c6111_6ab2fe8d:


    xy "\"It's my birthday next week, you know.\""


translate english c6111_2841892f:


    xy "\"And you've been sick a lot lately. You gotta make a full recovery by then, you hear me?\""


translate english c6111_4b89c0e9:



    voice "voice/c61/1100040a02.opus"
    aoi "\"Your birthday...\""


translate english c6111_aca31809:


    xy "\"That's right. And I won't be very happy if you don't get better.\""


translate english c6111_ef9aa7a2:


    xy "\"So you need to rest up and recover.\""


translate english c6111_474f45e3:



    voice "voice/c61/1100050a02.opus"
    aoi "\"You're... sad... when Aoi's sick...?\""


translate english c6111_ad692f36:


    xy "\"Of course!\""


translate english c6111_704d124d:



    voice "voice/c61/1100060a02.opus"
    aoi "\"Boop boop...\""


translate english c6111_59cab165:


    "Aoi aprieta los labios y vacila un momento."


translate english c6111_80ed4b24:



    voice "voice/c61/1100070a02.opus"
    aoi "\"Okay. Aoi will focus on getting better.\""


translate english c6111_c817f21b:



    voice "voice/c61/1100080a02.opus"
    aoi "\"In exchange, you better go have fun tonight at the play.\""


translate english c6111_f57678a7:


    xy "\"I'm staying here.\""


translate english c6111_4b50a5ec:



    voice "voice/c61/1100090a02.opus"
    aoi "\"No! Absolutely not!\""


translate english c6111_28c8cf92:



    voice "voice/c61/1100100a02.opus"
    aoi "\"Miyuki is waiting for you!\""


translate english c6111_c8610394:


    xy "\"Nah. She dropped out of the lead role—\""


translate english c6111_35caf6a8:



    voice "voice/c61/1100110a02.opus"
    aoi "\"That doesn't matter.\""


translate english c6111_f9452b2f:



    voice "voice/c61/1100120a02.opus"
    aoi "\"She gave you the tickets, so you should go.\""


translate english c6111_0accd139:


    xy "\"......\""


translate english c6111_4733ae74:


    "Su voz es inusualmente firme, y me quedo en silencio."


translate english c6111_64ade062:


    xy "\"You sure you can fall asleep without me here?\""


translate english c6111_f66bbc8f:



    voice "voice/c61/1100130a02.opus"
    aoi "\"Yeah.\""


translate english c6111_75c8b797:


    xy "\"No playing with Eru, you hear me?\""


translate english c6111_d233c791:



    voice "voice/c61/1100140a02.opus"
    aoi "\"Okay.\""



translate english c6111_2ac3f81e:


    "No me siento bien con esto, pero sé lo obstinada que puede ser con estas cosas."


translate english c6111_f722fbce:


    "SÍ le debo a Miyuki por conseguirnos los boletos, así que supongo que debería ceder e ir a ver la obra."


translate english c6111_5e47eaef:


    xy "\"Alright, I'll be back later.\""


translate english c6111_0cfbebcb:



    voice "voice/c61/1100150a02.opus"
    aoi "\"Shinichi!\""


translate english c6111_43a7afaa:


    "Justo entonces, Aoi se sienta erguida en el sofá."


translate english c6111_ffd0a44d:



    voice "voice/c61/1100160a02.opus"
    aoi "\"Listen, Shinichi.\""


translate english c6111_dd400ad9:



    voice "voice/c61/1100170a02.opus"
    aoi "\"Do you know...\""


translate english c6111_ba01f729:



    voice "voice/c61/1100180a02.opus"
    aoi "\"...when my birthday is?\""


translate english c6111_93dcd96b:


    xy "\"Uhhhh... Not sure you ever told me...\""


translate english c6111_c59a471c:



    voice "voice/c61/1100190a02.opus"
    aoi "\"It's May 23rd.\""


translate english c6111_1c6b7736:


    "23 de mayo..."


translate english c6111_71048021:


    xy "\"So you were born before me, huh?\""


translate english c6111_19a2e5f5:



    voice "voice/c61/1100200a02.opus"
    aoi "\"Aoi will teach you my code number.\""


translate english c6111_21cafa1b:


    xy "\"What's a code number?\""


translate english c6111_25bf68ce:


    "Asumo que esto es solo otro de los tics verbales de Aoi..."


translate english c6111_0defd4a5:


    "...y sin embargo su expresión es de acero."


translate english c6111_5791e5d7:



    voice "voice/c61/1100210a02.opus"
    aoi "\"God gave me this special phone number for emergencies.\""


translate english c6111_dcd2c236:



    voice "voice/c61/1100220a02.opus"
    aoi "\"If anything happens to me, you can dial this number to bring me back.\""


translate english c6111_1d5a9738:


    xy "\"Bring you back... from where...?\""


translate english c6111_f989ba1d:



    voice "voice/c61/1100230a02.opus"
    aoi "\"Just memorize it, okay?\""


translate english c6111_efe1212c:


    xy "\"No, hang on! Where are you going?\""


translate english c6111_12b3149d:



    voice "voice/c61/1100240a02.opus"
    aoi "\"Nowhere. It's okay.\""


translate english c6111_42191684:



    voice "voice/c61/1100250a02.opus"
    aoi "\"This is just a safety measure. Now memorize this code number.\""


translate english c6111_9c644e03:



    voice "voice/c61/1100270a02.opus"
    aoi "\"First, dial 999. Easy. Then dial my birthday, 0523, two times.\""


translate english c6111_28874e15:



    voice "voice/c61/1100280a02.opus"
    aoi "\"That's my code number, okay?\""


translate english c6111_c79b63dc:


    "Primero, marca 999..."


translate english c6111_7d535040:


    "Luego teclea el cumpleaños de Aoi dos veces."


translate english c6111_c17bc059:


    "999-0523-0523."



translate english c6111_22bb6994:


    "Lo repito una y otra vez en mi mente."


translate english c6111_c4a5d78f:



    voice "voice/c61/1100290a02.opus"
    aoi "\"If you can remember my birthday, you won't forget.\""


translate english c6111_27711e4c:



    voice "voice/c61/1100300a02.opus"
    aoi "\"So make sure to memorize it.\""


translate english c6111_8c7a1388:



    voice "voice/c61/1100310a02.opus"
    aoi "\"Promise me... okay?\""


translate english c6111_3c568a45:


    xy "\"Okay. I promise.\""


translate english c6111_e504a458:


    "No estoy seguro de dónde diablos salió eso..."


translate english c6111_5d5b2134:


    "Quizás debería anotar este número en algún lugar."


translate english c6111_c39cefd6:



    voice "voice/c61/1100320a02.opus"
    aoi "\"Shinichi...\""



translate english c6111_a352a2bd:



    voice "voice/c61/1100330a02.opus"
    aoi "\"Aoi wants you to know...\""


translate english c6111_0069694e:



    voice "voice/c61/1100340a02.opus"
    aoi "\"...Aoi is in love with you.\""


translate english c6111_79ec2342:


    xy "\"Right... Thanks.\""


translate english c6111_600799c8:


    "Su cara está sonrojada de un rojo brillante."


translate english c6111_9c87f2e0:


    "Nadie me había dicho eso antes..."


translate english c6111_2cf9aa1e:


    "Parte de mí está encantada..."


translate english c6111_74adc74d:


    "...y sin embargo, de alguna manera, algo parece estar mal con ella."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
