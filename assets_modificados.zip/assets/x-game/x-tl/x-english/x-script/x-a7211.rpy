

translate english a7211_9d0c4c9e:


    xy "\"Miyuki...\""


translate english a7211_67435be9:



    voice "voice/a72/1100010a01.opus"
    mx "\"Shinichi...\""


translate english a7211_025f41f5:


    "Nos besamos."


translate english a7211_81d29ae2:



    voice "voice/a72/1100020a01.opus"
    mx "\"Mmph... mm... mmm... mmph...\""


translate english a7211_8d7abdfe:


    "Nuestros labios se entrelazan, luego nuestras lenguas."


translate english a7211_6d3be0a7:


    "Poco a poco, nuestros movimientos se sincronizan."


translate english a7211_dc0b5230:



    voice "voice/a72/1100030a01.opus"
    mx "\"Mmph... Shinichi... Oh my god... I can't believe... we're really... kissing... Mm...\""


translate english a7211_98eb6c9c:


    "Puedo sentir su aliento, caliente contra mi piel."


translate english a7211_da140bd7:


    "Me mira, extasiada."


translate english a7211_ed4248c1:


    "Luego me atrae para otro beso profundo."


translate english a7211_76e3fbe3:



    voice "voice/a72/1100040a01.opus"
    mx "\"Mmmph... mm... mmm... mm... Mmph... mmph... mmm...!\""


translate english a7211_5dfa672d:


    "La torpeza inicial empieza a desvanecerse."


translate english a7211_63dd1bc6:


    "Nuestras lenguas danzan."


translate english a7211_5a168dd7:


    "Apasionado, empiezo a desabotonar su blusa."


translate english a7211_41544bb8:



    voice "voice/a72/1100050a01.opus"
    mx "\"You have to strip too, okay? Mm...\""


translate english a7211_7c6244be:


    "Mientras nos besamos, Miyuki empieza a desvestirme."


translate english a7211_59c5ce6e:


    "Ambos estamos distraídos con las lenguas del otro, pero hacemos lo mejor que podemos."


translate english a7211_8885c6eb:


    "Aunque tengo que admitir que su torpeza es realmente linda..."


translate english a7211_c3c41bdd:



    voice "voice/a72/1100060a01.opus"
    mx "\"Arms up!\""


translate english a7211_2debbddc:


    "A su petición, alzo los brazos sobre la cabeza."


translate english a7211_a8df453f:


    "Admito que suena un poco como mi mamá..."


translate english a7211_28035b9b:



    voice "voice/a72/1100070a01.opus"
    mx "\"What?\""



translate english a7211_ddcdf50e:


    xy "\"It's nothing.\""


translate english a7211_9ea973b4:



    voice "voice/a72/1100080a01.opus"
    mx "\"What's nothing?\""


translate english a7211_d30bd832:


    xy "\"It's your face.\""


translate english a7211_3f5d480b:


    xy "\"The way you look when you're pouting.\""


translate english a7211_d4241eb0:



    voice "voice/a72/1100090a01.opus"
    mx "\"......!!!\""



translate english a7211_f3789195:


    xy "\"You're blushing again.\""


translate english a7211_88b52f77:



    voice "voice/a72/1100100a01.opus"
    mx "\"So what?! You got a problem with that?\""


translate english a7211_78155c29:


    xy "\"Nope. It's really cute, actually.\""


translate english a7211_bd5b8edb:



    voice "voice/a72/1100110a01.opus"
    mx "\"Wh...\""


translate english a7211_884f1e4e:


    xy "\"I wish you'd blush like that all the time.\""


translate english a7211_cb0320bc:



    voice "voice/a72/1100120a01.opus"
    mx "\"Don't be ridiculous!\""


translate english a7211_cb3c5824:



    voice "voice/a72/1100130a01.opus"
    mx "\"That's the dumbest thing I've ever heard!\""


translate english a7211_9ada1550:


    xy "\"C'mon, let me see you.\""


translate english a7211_c3b91713:



    voice "voice/a72/1100140a01.opus"
    mx "\"...Okay...\""


translate english a7211_cace91e7:


    "En la escuela, siempre está protegida por un personaje impenetrable."


translate english a7211_1a3a7527:


    "Pero debajo de él, sigue siendo la misma chica tímida que era antes."


translate english a7211_43d657cf:



    voice "voice/a72/1100150a01.opus"
    mx "\"Mmm... mmph... mm... mmm...\""


translate english a7211_945a0a26:


    "Rodeo con mis brazos su espalda desnuda."


translate english a7211_b70649d5:


    "Es mucho más pequeña y suave de lo que imaginé."


translate english a7211_1aef170b:


    "Me dan ganas de abrazarla fuerte y protegerla."


translate english a7211_a8a2a90d:


    "Y cuanto más fuerte la abrazo..."


translate english a7211_de95b7f3:


    "...más puedo sentir la curva de sus pechos."


translate english a7211_080cc9c6:


    "Sus abundantes montes amenazan con salirse del sostén."


translate english a7211_f5be0d0f:


    "Con nuestros labios aún unidos, llevo la mano alrededor para tratar de desabrocharlo—"


translate english a7211_3de65d7f:


    xy "\"Mm... mmm... mm...?\""


translate english a7211_2c5648af:



    voice "voice/a72/1100160a01.opus"
    mx "\"Shinichi...\""



translate english a7211_a98780af:



    voice "voice/a72/1100170a01.opus"
    mx "\"Just take your time.\""


translate english a7211_51544998:



    voice "voice/a72/1100180a01.opus"
    mx "\"I'm not going anywhere, you know.\""


translate english a7211_bb8073ab:


    xy "\"I... I know...\""


translate english a7211_a6f65414:


    "Genial, ahora me está provocando..."


translate english a7211_d3a8699c:


    "Suprimiendo el impulso de apresurarme, me obligo a calmarme mientras desabrocho su sostén con firmeza."


translate english a7211_b2abaf3b:



    voice "voice/a72/1100190a01.opus"
    mx "\"Shinichi... I'm flattered, but you're embarrassing me...\""


translate english a7211_286fd05c:



    voice "voice/a72/1100200a01.opus"
    mx "\"Don't just ogle me... Look at me...\""


translate english a7211_f8708163:



    voice "voice/a72/1100210a01.opus"
    mx "\"Mmph... mmm...\""


translate english a7211_d3ff1f7f:


    "As \"punishment\"por mirarle los pechos, Miyuki me besa."


translate english a7211_9d3ced7e:


    "Vuelvo a rodearla con mis brazos, presionando nuestros pechos desnudos juntos por primera vez."


translate english a7211_76e91850:


    "Es más suave que cualquier cosa que haya sentido en mi vida..."


translate english a7211_bf0f4178:


    "Y en las puntas mismas—"


translate english a7211_19920bba:


    xy "\"Your nipples are hard.\""


translate english a7211_1011c99c:


    xy "\"Did that kiss turn you on?\""


translate english a7211_0367786f:



    voice "voice/a72/1100220a01.opus"
    mx "\"Y-Yeah...\""


translate english a7211_1d3ac8b1:



    voice "voice/a72/1100230a01.opus"
    mx "\"I guess it did...\""


translate english a7211_88c1135a:


    "Inclina la cabeza, desconcertada. Dios, es tan jodidamente linda que no puedo soportarlo."


translate english a7211_432688af:



    voice "voice/a72/1100240a01.opus"
    mx "\"Aaah!\""


translate english a7211_e2b7359c:


    "La empujo hacia abajo, sobre el sofá."


translate english a7211_7113a84a:



    voice "voice/a72/1100250a01.opus"
    mx "\"Shinichi... Mmmph... mm... mm...\""


translate english a7211_587f1757:


    "Sus mejillas están sonrojadas de anticipación... y tensión."


translate english a7211_90760bf2:


    xy "\"Are you scared?\""


translate english a7211_db882688:



    voice "voice/a72/1100260a01.opus"
    mx "\"...I've never let anyone see me like this before...\""


translate english a7211_97b49380:


    "Lo que significa que soy la primera persona que la hace sentir así."


translate english a7211_a4b1ba5a:


    "No puedo contenerme ni un segundo más."


translate english a7211_9d0c4c9e_1:


    xy "\"Miyuki...\""


translate english a7211_fd4349cd:



    voice "voice/a72/1100270a01.opus"
    mx "\"Nnhaah... nnn... aah! Oh god... Don't slurp on them so loud...!\""


translate english a7211_13568465:



    voice "voice/a72/1100280a01.opus"
    mx "\"This is so awkward—AAAH! Your tongue is—touching my nipple—AAH!\""


translate english a7211_f7b2d2cc:


    "Cada vez que mi lengua toca su pecho, su cuerpo se sacude y tiembla."


translate english a7211_09ad3c22:


    "Empiezo a deslizar mis labios hacia el sur."



translate english a7211_ce478ac5:


    "A regañadientes, me alejo de sus pechos, deslizando mi lengua por la suave pendiente de su estómago, pasando por su lindo ombliguito—"


translate english a7211_0753ee99:



    voice "voice/a72/1100290a01.opus"
    mx "\"Aah!\""


translate english a7211_a941ebae:


    "—hasta llegar a sus bragas."


translate english a7211_86b1f5f3:


    "Luego sigo la curva de sus muslos hasta que mi cabeza queda directamente entre sus piernas—"


translate english a7211_7be21e51:



    voice "voice/a72/1100300a01.opus"
    mx "\"Aah! No! Don't!\""


translate english a7211_d1662cbb:


    xy "\"Oh, you're soaked—\""


translate english a7211_7c43cb30:



    voice "voice/a72/1100310a01.opus"
    mx "\"Shut up!\""


translate english a7211_53561e9f:



    voice "voice/a72/1100320a01.opus"
    mx "\"I know I'm wet, okay?!\""


translate english a7211_834a2d0c:



    voice "voice/a72/1100330a01.opus"
    mx "\"I mean, can you blame me? I just love you so much...\""


translate english a7211_c8133d53:


    xy "\"...Miyuki...\""


translate english a7211_903e49a7:



    voice "voice/a72/1100340a01.opus"
    mx "\"\"\"......\"\"!!!\""


translate english a7211_795275de:



    voice "voice/a72/1100350a01.opus"
    mx "\"You want to see it, don't you...\""


translate english a7211_119074b3:


    "Muerto por verlo, en realidad..."


translate english a7211_f7c8c141:



    voice "voice/a72/1100360a01.opus"
    mx "\"...Figures...\""


translate english a7211_4852f3ef:



    voice "voice/a72/1100370a01.opus"
    mx "\"...Okay...\""


translate english a7211_6d5b123a:


    "Suspira ligeramente."


translate english a7211_81322a8c:



    voice "voice/a72/1100380a01.opus"
    mx "\"...Go ahead.\""


translate english a7211_f52b031e:


    "Bajo sus bragas con cuidado."


translate english a7211_c8d6c19d:



    voice "voice/a72/1100390a01.opus"
    mx "\"Aah... nnn...\""


translate english a7211_dd81ff4a:



    voice "voice/a72/1100400a01.opus"
    mx "\"\"\"......\"\"!!!\""


translate english a7211_2a206f12:


    "Miyuki se queda callada y aparta la mirada."


translate english a7211_3d2dde54:


    "Cuanto más espero, más roja se pone su cara."


translate english a7211_6292e4a9:



    voice "voice/a72/1100410a01.opus"
    mx "\"...Say something already!\""


translate english a7211_8d645717:


    xy "\"You're beautiful.\""


translate english a7211_fd994118:



    voice "voice/a72/1100420a01.opus"
    mx "\"Shut up!\""


translate english a7211_ba71e117:



    voice "voice/a72/1100430a01.opus"
    mx "\"Nnhaah! Nnn...!\""


translate english a7211_20d42c2e:


    "Incapaz de contenerme, extiendo la mano y toco su concha."


translate english a7211_d90f7ffa:


    "Sus labios están resbalosos con fluidos."


translate english a7211_4263a7a1:



    voice "voice/a72/1100440a01.opus"
    mx "\"Aaah! Aah... aah... nnnn! Haah... nnn... haah... nnn... nnhaaahh!\""


translate english a7211_2f6b7ca1:


    "El más leve toque hace que Miyuki se retuerza."


translate english a7211_e1d1418b:


    "Lo que significa—"


translate english a7211_d172589b:



    voice "voice/a72/1100450a01.opus"
    mx "\"Aaahh!\""


translate english a7211_d8e9cb16:



    voice "voice/a72/1100460a01.opus"
    mx "\"Aah! Hey! Stop that! That's really sensitive— Nnhaaahh!\""


translate english a7211_dcaa05d6:


    "Y, en efecto, cuando presiono contra su clítoris, empieza a retorcerse aún más fuerte."


translate english a7211_ac2b6b31:



    voice "voice/a72/1100470a01.opus"
    mx "\"Aah! Nnhaah! Hey! Don't... Don't be so rough—\""


translate english a7211_bcdc66e5:



    voice "voice/a72/1100480a01.opus"
    mx "\"...Huh?\""


translate english a7211_d066366e:



    voice "voice/a72/1100490a01.opus"
    mx "\"Wh-What are you doing? Get your face out of there! Haah! Hey! Your breath tickles—!\""


translate english a7211_8ec0e4c3:


    "Miyuki intenta apartarse, pero agarro sus piernas con ambas manos y llevo mis labios justo hasta su concha empapada."


translate english a7211_5c72c398:



    voice "voice/a72/1100500a01.opus"
    mx "\"Nnhaaaaaaaaaaahhhh!!!\""


translate english a7211_a311d64c:



    voice "voice/a72/1100510a01.opus"
    mx "\"HEY! You jerk! S-Stop that right now! Don't put your mouth down there! That's nasty—AAAH!\""


translate english a7211_3804d368:



    voice "voice/a72/1100520a01.opus"
    mx "\"Oh god... Stop! I can feel your tongue... wriggling around... Why does it feel so—?!\""


translate english a7211_d8d4851f:



    voice "voice/a72/1100530a01.opus"
    mx "\"AAAAHH! Don't suck on it! It's too intense—AAH! It feels so good—!\""


translate english a7211_e59cf3b1:


    "Sin embargo, conforme pasa el tiempo, Miyuki se siente más cómoda consigo misma."


translate english a7211_ee8abfa2:


    "Sus gemidos se vuelven más fuertes, y cuanto más ruido hago, más parece excitarla."


translate english a7211_a231e6de:



    voice "voice/a72/1100540a01.opus"
    mx "\"Haah... aah... aah...! Oh god! Aaah... I can hear you slurping—!\""


translate english a7211_6b4fd7bd:



    voice "voice/a72/1100550a01.opus"
    mx "\"It feels so good... It's driving me crazy... I'm losing it—! Shinichi... Can I... Can I let loose?\""


translate english a7211_89e0157c:


    "En respuesta, presiono la punta de mi lengua contra su clítoris hinchado."


translate english a7211_405d41d0:



    voice "voice/a72/1100560a01.opus"
    mx "\"AAAAH! Oh god! Right there! I'm scared—it feels so good—aaahh!\""


translate english a7211_f9075d1f:



    voice "voice/a72/1100570a01.opus"
    mx "\"I'm gonna... I'm gonna cum, Shinichi... I'm gonna cum! Nnggh... nnhaah... I'm cumming, I'm cumming, I'm cumming!\""


translate english a7211_67c52511:



    voice "voice/a72/1100580a01.opus"
    mx "\"I'M CUMMIIIIIING—!!!\""


translate english a7211_cc7e96a6:



    voice "voice/a72/1100590a01.opus"
    mx "\"Aah... aah... aah... nngg... nnn... nnnn... nn... nnn... nn...\""


translate english a7211_39b017d0:



    voice "voice/a72/1100600a01.opus"
    mx "\"Aah... nn... nnn... nnnn... Shinichi... What... happened to me...?\""


translate english a7211_5ac1d7e3:


    xy "\"I think you had an orgasm...?\""


translate english a7211_eb93e3b6:



    voice "voice/a72/1100610a01.opus"
    mx "\"I... guess so... I'm not sure... It felt so good... my mind... went blank...\""


translate english a7211_1d9a9b5d:



    voice "voice/a72/1100620a01.opus"
    mx "\"Your tongue... made me cum...\""


translate english a7211_e7fb6c8d:


    "Me mira con ojos vidriosos y desenfocados."


translate english a7211_49c338c7:


    "Ahora mismo, está completamente indefensa."


translate english a7211_f6242df9:


    "Quiero abrazarla..."


translate english a7211_02d746d5:


    "Quiero hacerla mía..."


translate english a7211_c8fb8ff4:


    xy "\"Miyuki, I...\""


translate english a7211_152d6f3d:



    voice "voice/a72/1100630a01.opus"
    mx "\"Aah... nnn...\""


translate english a7211_e7703930:


    "Me inclino y presiono mi verga hinchada contra su entrada goteante."


translate english a7211_62af4863:



    voice "voice/a72/1100640a01.opus"
    mx "\"No way... It's so big...!\""


translate english a7211_e648fa40:



    voice "voice/a72/1100650a01.opus"
    mx "\"It feels so firm... and burning hot... like it's going to explode...\""


translate english a7211_cc7d56d7:


    "En eso al menos tiene razón."


translate english a7211_218623a4:


    "Incluso sin estimulación directa, llevo bastante rato con una carpa en los pantalones."


translate english a7211_453369db:


    "Al más leve roce de piel, al más mínimo intercambio de calor corporal, puedo sentir el líquido preseminal empezar a gotear de mi punta con anticipación."


translate english a7211_3d081812:


    xy "\"Miyuki.\""



translate english a7211_0076213f:



    voice "voice/a72/1100660a01.opus"
    mx "\"Y-Yeah... I know... I'm ready.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
