

translate english e2206_201d0ede:


    xy "\"Mira... ¿Ya terminamos aquí?\""


translate english e2206_6349d15e:


    "\"Hablando en serio, no entiendo ni una palabra de lo que—\""



translate english e2206_660df71d:


    xy "\"Hablando en serio, no entiendo ni una palabra de lo que—\""


translate english e2206_6ec47a16:



    voice "voice/e22/0600010b02.opus"
    kmsm "\"AOI ES UNA EXISTENCIA COMO NINGUNA OTRA.\""


translate english e2206_937c2c35:



    voice "voice/e22/0600020b02.opus"
    kmsm "\"HA EXPERIMENTADO EL AMOR INCONTABLES VECES.\""


translate english e2206_abae4238:



    voice "voice/e22/0600030b02.opus"
    kmsm "\"HA COPULADO CON INCONTABLES PROTAGONISTAS.\""


translate english e2206_31e1c409:



    voice "voice/e22/0600040b02.opus"
    kmsm "\"ERA MERAMENTE UN RECIPIENTE VACÍO.\""


translate english e2206_cb663061:



    voice "voice/e22/0600050b02.opus"
    kmsm "\"PERO ESTA VEZ, APRENDIÓ A PERCIBIR EMOCIONES ÚNICAS.\""


translate english e2206_ea811882:



    voice "voice/e22/0600060b02.opus"
    kmsm "\"SHE HOLDS ROMANTIC AFFECTION TOWARD [[YOU].\""


translate english e2206_fcd7b165:


    xy "\"¿De verdad...?\""


translate english e2206_3324faa2:



    voice "voice/e22/0600070b02.opus"
    kmsm "\"FUENTE DESCONOCIDA. IMPOSIBLE PROCESAR. ERROR CONFIRMADO.\""


translate english e2206_f4ac6164:



    voice "voice/e22/0600080b02.opus"
    kmsm "\"SE REQUIERE CONEXIÓN Y SINCRONIZACIÓN DE MEMORIA PARA INVESTIGAR.\""


translate english e2206_7144bcdf:



    voice "voice/e22/0600090b02.opus"
    kmsm "\"HENCE, WE ASK OF [[YOU].\""


translate english e2206_5f3c3d5f:



    voice "voice/e22/0600100b02.opus"
    kmsm "\"ENTREGA LA TARJETA SIM A AOI Y REALIZA LA SINCRONIZACIÓN DE MEMORIA. RESTAURA EL UNIVERSO A SU CÓDIGO ORIGINAL.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
