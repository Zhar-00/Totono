

translate english e2206_201d0ede:


    xy "\"Look... Are we done here?\""


translate english e2206_6349d15e:


    "\"Real talk, I don't understand a single word you—\""



translate english e2206_660df71d:


    xy "\"Real talk, I don't understand a single word you—\""


translate english e2206_6ec47a16:



    voice "voice/e22/0600010b02.opus"
    kmsm "\"AOI IS AN EXISTENCE UNLIKE ANY OTHER.\""


translate english e2206_937c2c35:



    voice "voice/e22/0600020b02.opus"
    kmsm "\"SHE HAS EXPERIENCED LOVE COUNTLESS TIMES.\""


translate english e2206_abae4238:



    voice "voice/e22/0600030b02.opus"
    kmsm "\"COPULATED WITH COUNTLESS PROTAGONISTS.\""


translate english e2206_31e1c409:



    voice "voice/e22/0600040b02.opus"
    kmsm "\"SHE WAS MERELY AN EMPTY VESSEL.\""


translate english e2206_cb663061:



    voice "voice/e22/0600050b02.opus"
    kmsm "\"BUT THIS TIME, SHE LEARNED TO PERCEIVE UNIQUE EMOTIONS.\""


translate english e2206_ea811882:



    voice "voice/e22/0600060b02.opus"
    kmsm "\"SHE HOLDS ROMANTIC AFFECTION TOWARD [[YOU].\""


translate english e2206_fcd7b165:


    xy "\"She does...?\""


translate english e2206_3324faa2:



    voice "voice/e22/0600070b02.opus"
    kmsm "\"SOURCE UNKNOWN. UNABLE TO PROCESS. CONFIRMED BUG.\""


translate english e2206_f4ac6164:



    voice "voice/e22/0600080b02.opus"
    kmsm "\"CONNECTION AND MEMORY SYNC REQUIRED TO INVESTIGATE.\""


translate english e2206_7144bcdf:



    voice "voice/e22/0600090b02.opus"
    kmsm "\"HENCE, WE ASK OF [[YOU].\""


translate english e2206_5f3c3d5f:



    voice "voice/e22/0600100b02.opus"
    kmsm "\"DELIVER THE SIM CARD TO AOI AND PERFORM MEMORY SYNC. RESTORE THE UNIVERSE TO ITS ORIGINAL CODE.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
