

translate english e2155_9f8e4f78:



    voice "voice/e21/5500010a01.opus"
    mx "\"That said...\""


translate english e2155_6845dffe:



    voice "voice/e21/5500020a01.opus"
    mx "\"We don't HAVE any other friends anymore.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
