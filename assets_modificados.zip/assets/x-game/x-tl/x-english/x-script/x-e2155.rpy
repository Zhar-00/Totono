

translate english e2155_9f8e4f78:



    voice "voice/e21/5500010a01.opus"
    mx "\"Dicho eso...\""


translate english e2155_6845dffe:



    voice "voice/e21/5500020a01.opus"
    mx "\"Ya no TENEMOS otros amigos.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
