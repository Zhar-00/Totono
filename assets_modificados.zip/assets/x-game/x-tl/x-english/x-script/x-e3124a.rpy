

translate english e3124a_9f3d596e:



    voice "voice/e31/24a00010a01.opus"
    mx "\"Sí, si tan solo esa fuera la ruta que elegiste.\""


translate english e3124a_271d897c:



    voice "voice/e31/24a00020a01.opus"
    mx "\"Pero no lo fue, ¿verdad?\""


translate english e3124a_1a923788:



    voice "voice/e31/24a00030a01.opus"
    mx "\"La maldición fue provocada por...\""


translate english e3124a_0f7c6717:



    voice "voice/e31/24a00040a01.opus"
    mx "\"...esta elección justo aquí.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
