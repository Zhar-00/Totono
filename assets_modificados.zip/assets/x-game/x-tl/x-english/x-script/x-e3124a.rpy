

translate english e3124a_9f3d596e:



    voice "voice/e31/24a00010a01.opus"
    mx "\"Yes, if only that was the route you chose.\""


translate english e3124a_271d897c:



    voice "voice/e31/24a00020a01.opus"
    mx "\"But it wasn't, was it?\""


translate english e3124a_1a923788:



    voice "voice/e31/24a00030a01.opus"
    mx "\"The curse was brought on by...\""


translate english e3124a_0f7c6717:



    voice "voice/e31/24a00040a01.opus"
    mx "\"...this choice right here.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
