

translate english e2152b_407be7cc:


    xy "\"Wanna go halfsies?\""


translate english e2152b_367dca67:



    voice "voice/e21/52b00010a01.opus"
    mx "\"How would that work?\""


translate english e2152b_7e865336:


    xy "\"We trade off taking a bite of each.\""


translate english e2152b_3092219f:



    voice "voice/e21/52b00020a01.opus"
    mx "\"Interesting...\""


translate english e2152b_a38ad743:



    voice "voice/e21/52b00030a01.opus"
    mx "\"O-Okay. I DO like ice cream sandwiches...\""


translate english e2152b_86208817:


    "Y así nos turnamos para dar mordiscos a los helados del otro además de los nuestros."


translate english e2152b_fa548d26:


    xy "\"Nom... mmm. Delicious.\""


translate english e2152b_dad7a7c4:


    xy "\"What about you?\""


translate english e2152b_3063ea3f:



    voice "voice/e21/52b00040a01.opus"
    mx "\"I'm happy.\""


translate english e2152b_8f78837d:


    xy "\"Happy?\""


translate english e2152b_12cefc21:



    voice "voice/e21/52b00050a01.opus"
    mx "\"Yeah. Really happy.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
