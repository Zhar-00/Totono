

translate english e2152b_407be7cc:


    xy "\"¿Quieres ir a medias?\""


translate english e2152b_367dca67:



    voice "voice/e21/52b00010a01.opus"
    mx "\"¿Cómo funcionaría eso?\""


translate english e2152b_7e865336:


    xy "\"Nos turnamos para darle una mordida a cada uno.\""


translate english e2152b_3092219f:



    voice "voice/e21/52b00020a01.opus"
    mx "\"Interesante...\""


translate english e2152b_a38ad743:



    voice "voice/e21/52b00030a01.opus"
    mx "\"E-Está bien. Sí me gustan los sándwiches de helado...\""


translate english e2152b_86208817:


    "Y así nos turnamos para dar mordiscos a los helados del otro además de los nuestros."


translate english e2152b_fa548d26:


    xy "\"Ñam... mmm. Delicioso.\""


translate english e2152b_dad7a7c4:


    xy "\"¿Y tú?\""


translate english e2152b_3063ea3f:



    voice "voice/e21/52b00040a01.opus"
    mx "\"Soy feliz.\""


translate english e2152b_8f78837d:


    xy "\"¿Feliz?\""


translate english e2152b_12cefc21:



    voice "voice/e21/52b00050a01.opus"
    mx "\"Sí. Muy feliz.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
