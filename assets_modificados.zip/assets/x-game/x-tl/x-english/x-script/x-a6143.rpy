

translate english a6143_171dfb02:


    "No logro animarme a volver a subir a la azotea."


translate english a6143_d6273ba0:


    "Ese lugar está grabado con todos los recuerdos de nuestra amistad."


translate english a6143_a9a2c0f1:


    "Es el lugar que Aoi llamaba el centro del universo."


translate english a6143_d3644aed:


    "Mientras tanto, no tengo planes de buscarla."


translate english a6143_9dde722e:


    "Probablemente ella tampoco querría que lo hiciera."


translate english a6143_aefb39b5:


    "Tiró nuestra amistad por la borda."


translate english a6143_a40f0a3a:


    "No es que la culpe realmente por ello."


translate english a6143_31f33a18:


    "Pero no hay puntos de guardado en la vida real."


translate english a6143_84f627ee:


    "No hay forma de recargar e intentarlo de nuevo."


translate english a6143_53b6260c:


    "Aun así, voy a seguir adelante."


translate english a6143_e2298a37:


    "Viviré una vida tranquila."


translate english a6143_15f10123:


    "Una vida sin problemas."


translate english a6143_de7427d6:


    "Sin expectativas irrazonables."


translate english a6143_07d96a15:


    "Solo una vida normal y corriente."


translate english a6143_215b021f:


    "Una vida honesta."


translate english a6143_8ccd0e19:


    "No necesito estar en la cima del mundo."


translate english a6143_4da68cf8:


    "No necesito estar en el centro del universo."


translate english a6143_c785ef47:


    "No todos tienen que ser especiales, ¿verdad?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
