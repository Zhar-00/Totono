

translate english a5141_b30b9ea8:


    xy "\"Ggllpp... ggllpp... Mm...\""


translate english a5141_3de73a0c:


    xy "\"Whew!\""


translate english a5141_79b6d426:


    xy "\"......Disgusting.\""


translate english a5141_f44a4b68:


    "La lata vacía tintinea cuando la dejo en el suelo."


translate english a5141_a288b525:


    "Ha pasado un tiempo desde la última vez que almorcé solo aquí arriba."


translate english a5141_da8934ac:


    "Croquetas y un sándwich de yakisoba: el delicioso sabor de la basura."



translate english a5141_9fba2406:


    "Días como estos me hacen darme cuenta de lo mucho que he dado por sentada la comida casera de Miyuki."


translate english a5141_3183f97d:


    "Vagamente había esperado que esos días duraran para siempre..."


translate english a5141_4fab6717:


    "Pero nuestra amistad está toda jodida."



translate english a5141_5a382c16:


    "Desde aquel día..."


translate english a5141_105c6cb8:


    "El día en que me confesó su amor justo aquí, en la azotea, bajo el sol poniente. Ese fue el momento en que todo comenzó."


translate english a5141_385e414d:


    "Lo había dicho en serio, cada palabra."


translate english a5141_911e2ab1:


    "Había mantenido esos sentimientos encerrados en su corazón todo este tiempo."


translate english a5141_248bff77:


    "En algún lugar, en el fondo, lo sabía."


translate english a5141_4076bff7:


    "Y sin embargo me dejé acercar a ella de todos modos."


translate english a5141_f9c9d151:


    "Aunque sabía que solo terminaría en miseria."


translate english a5141_005a2113:


    "Justo entonces, mi bolsillo vibra."


translate english a5141_e86edcbf:


    "Saco mi teléfono rápidamente, aunque sé que no hay posibilidad de que el teléfono de Aoi tenga señal."


translate english a5141_852fe78e:


    "El correo es de Miyuki."


translate english a5141_ba461e0b:


    "—Necesito hablar contigo."


translate english a5141_61265481:


    "—Por favor, pasa por las jaulas de bateo esta noche."


translate english a5141_99c01cae:


    "—Es importante."


translate english a5141_a10ff458:



    voice "voice/a22/1100010a01.opus"
    mx "\"There's going to be... {nw}"



translate english a5141_958cd961:


    voice "voice/a22/1100020a01.opus"



translate english a5141_4a23294e:


    extend "un beso.\""


translate english a5141_0accd139:


    xy "\"\"......\"Disgusting.\""


translate english a5141_958b3f6e:


    "No puedo sacarme sus labios de la cabeza."


translate english a5141_f833d3b5:


    "¿Debería simplemente... besarla, como Aoi quiere que lo haga?"


translate english a5141_ee2aedff:


    "¿Debería de verdad intentar hacerla mía?"


translate english a5141_0e2907cd:


    "La noche de la obra..."


translate english a5141_9250d802:


    "Todas esas noches de ensayo hasta tarde han dado fruto. Miyuki prácticamente baila por el escenario, con el bate en mano, presumiendo sus habilidades."


translate english a5141_fd5fc32e:


    "Su asombroso talento la hace más que digna del papel principal. Todas las miradas están pegadas a ella."


translate english a5141_d1ffd01d:


    "Apenas necesita mover un dedo y el público ríe, llora y jadea junto con ella."


translate english a5141_9e4c276a:


    "Con Miyuki bajo el reflector, la tensión crece, atrayendo a todo el auditorio hacia su magnetismo."


translate english a5141_cf4a362e:


    "Entonces, por fin, el momento culminante."


translate english a5141_2b781366:


    "Miyuki batea y da un home run."


translate english a5141_99067792:


    "La multitud ruge de deleite."


translate english a5141_7a578ff6:


    "Con todos sus problemas ya dejados atrás, abraza al galán romántico."


translate english a5141_b06a6bda:


    "Sus labios se acercan."


translate english a5141_45571a10:


    "Pero yo sé la verdad."


translate english a5141_8b3616fd:


    "Justo cuando está a punto de sacrificar su primer beso para que la obra sea un éxito rotundo..."


translate english a5141_5d52e193:


    "...estará temblando de miedo."


translate english a5141_ea1e3b23:


    xy "\"HOLD IT!!!\""


translate english a5141_0aed8c18:



    voice "voice/a51/4100070a01.opus"
    mx "\"What?! Is that... Shinichi?!\""


translate english a5141_ff243e44:



    voice "voice/a51/4100080a01.opus"
    mx "\"No way! We're in the middle of a performance—!\""


translate english a5141_4c53cf01:


    xy "\"Who cares? Come on!\""


translate english a5141_dd21940f:



    voice "voice/a51/4100090a01.opus"
    mx "\"Huh...?\""


translate english a5141_bf650ec8:


    xy "\"Sorry for ruining the play.\""


translate english a5141_56ce84d8:


    xy "\"But—\""


translate english a5141_39482a50:


    xy "\"I'm done lying about how I feel!\""


translate english a5141_85304f7b:


    xy "\"God, I'm so full of myself... Pathetic.\""


translate english a5141_2291d71d:


    "Me maldigo por mi estúpida fantasía."


translate english a5141_8660ec84:


    "Arruinaría toda la obra."


translate english a5141_b1aaa9c5:


    "Solo le causaría problemas a Miyuki con mi egoísta deseo de impedir que bese a otros chicos."


translate english a5141_5f50e2e4:


    "Sería el peso muerto que la mantiene hundida."


translate english a5141_31e430c4:


    "Después de todo... solo soy un don nadie."


translate english a5141_ea15fac6:


    "No soy ningún Príncipe Azul que pueda despertarla con un beso."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
