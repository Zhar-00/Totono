

translate english c4131_278748bd:


    "A la hora del almuerzo—"


translate english c4131_fa3ba335:



    voice "voice/c41/3100010a01.opus"
    mx "\"Aah... aah...\""


translate english c4131_4647b766:



    voice "voice/c41/3100020a01.opus"
    mx "\"AACHOO!!!\""


translate english c4131_4df6002e:



    voice "voice/c41/3100030a01.opus"
    mx "\"Snnnfff...\""


translate english c4131_949efac9:


    xy "\"You okay?\""


translate english c4131_34994f8a:



    voice "voice/c41/3100040a01.opus"
    mx "\"...It's just my allergies.\""


translate english c4131_75a82f2e:


    "Estamos en la azotea."


translate english c4131_0b7ea6a7:


    "Tengo una conversación privada con Miyuki."


translate english c4131_ca64ff9a:



    voice "voice/c41/3100050a01.opus"
    mx "\"Alright, I understand.\""


translate english c4131_5dbd459c:



    voice "voice/c41/3100060a01.opus"
    mx "\"I didn't realize you had a bad case of gamer brain, too.\""


translate english c4131_8d4a1bb5:


    xy "\"I don't!\""


translate english c4131_3e9e8306:


    xy "\"C'mon, look at them.\""


translate english c4131_a4354c89:



    voice "voice/c41/3100070a02.opus"
    aoi "\"Come here, Eru!\""


translate english c4131_6f8c626c:



    voice "voice/c41/3100090a02.opus"
    aoi "\"Boop boop? Where are you going?\""


translate english c4131_f650c477:


    "Señalo a Aoi, que en este momento juega con Eru."


translate english c4131_5ebb67cb:


    "Una imagen vale más que mil palabras, después de todo."


translate english c4131_5a753e3b:


    "Y esto puede o no ser exactamente la razón por la que me tomé la molestia de traer a Eru a la escuela con nosotros."


translate english c4131_fcd6c5cd:


    xy "\"How does it make you feel to see them playing?\""


translate english c4131_bf265575:



    voice "voice/c41/3100110a01.opus"
    mx "\"......\""


translate english c4131_e72942ab:


    xy "\"...Miyuki?\""


translate english c4131_9f12c29a:



    voice "voice/c41/3100120a01.opus"
    mx "\"\"\"\"......!\"!\"\"\""


translate english c4131_f56e12af:


    xy "\"Uh... you're drooling.\""


translate english c4131_dc7dfbbf:



    voice "voice/c41/3100130a01.opus"
    mx "\"AH!\""


translate english c4131_949efac9_1:


    xy "\"You okay?\""


translate english c4131_b781556d:



    voice "voice/c41/3100140a01.opus"
    mx "\"A-Are you blind?! Of course I'm not okay!\""


translate english c4131_55f1be03:


    xy "\"Aoi and Eru seem pretty happy together, don't you think?\""


translate english c4131_b761dfdc:



    voice "voice/c41/3100150a01.opus"
    mx "\"Mm... I guess so.\""


translate english c4131_4a53a07f:


    xy "\"This never would have happened if Aoi hadn't rescued the little thing last night.\""


translate english c4131_b513a00c:


    xy "\"And I think she was right to do it.\""


translate english c4131_b825920b:



    voice "voice/c41/3100160a01.opus"
    mx "\"Sure, they're happy, but that's hardly the problem here.\""


translate english c4131_53036897:



    voice "voice/c41/3100170a01.opus"
    mx "\"Things may be fine for right now, but sooner or later there's gonna be trouble.\""


translate english c4131_41e7855f:


    "Miyuki sigue siendo tan terca como siempre, veo..."


translate english c4131_dd95cd47:


    "Por suerte, lo vi venir."


translate english c4131_6d2ccffe:


    "Y tengo un as bajo la manga."


translate english c4131_a3d1745a:


    xy "\"Say, Miyuki?\""


translate english c4131_4de83bad:



    voice "voice/c41/3100180a01.opus"
    mx "\"Hm?\""



translate english c4131_bd82cf7f:


    "Le muestro la pantalla de mi teléfono... pero solo por un momento."


translate english c4131_81a0d8f1:


    "Luego lo guardo."


translate english c4131_e7367821:



    voice "voice/c41/3100190a01.opus"
    mx "\"What the?! What was THAT about?\""


translate english c4131_c31add03:


    xy "\"You wanna see it?\""


translate english c4131_5cee8ffd:



    voice "voice/c41/3100200a01.opus"
    mx "\"Of course I do! Show me! Was that—?!\""


translate english c4131_bf5ebd44:


    xy "\"A super-rare photo of Eru sleeping? Sure is.\""


translate english c4131_69f360ce:


    xy "\"If you want to see it...\""


translate english c4131_390b964a:


    xy "\"...then let's see you mend things with Aoi.\""


translate english c4131_edb94251:



    voice "voice/c41/3100210a01.opus"
    mx "\"Y-You seriously think you can bribe me with THAT?\""


translate english c4131_395156cf:


    xy "\"Oh, and Aoi's wearing the kitty onesie in the photo, too.\""


translate english c4131_b77c0872:



    voice "voice/c41/3100220a01.opus"
    mx "\"I can't be bought... I can't be bought...!\""


translate english c4131_e610a126:


    xy "\"C'mooon, you know you want toooo...\""


translate english c4131_b9e3545a:



    voice "voice/c41/3100230a01.opus"
    mx "\"......!\""


translate english c4131_f62d2cef:



    voice "voice/c41/3100240a01.opus"
    mx "\"Y-You CHEAT!!!\""


translate english c4131_1f7dfe59:


    xy "\"Cheat, gamer brain, whatever. You can call me names all you want.\""


translate english c4131_2ef85acc:


    xy "\"I just wanna hang out with my two good friends again.\""


translate english c4131_02826976:



    voice "voice/c41/3100250a01.opus"
    mx "\"You think I buy a second of that little suave act?\""


translate english c4131_bdeb9fd8:


    xy "\"Sorry. Just messing around.\""


translate english c4131_95499b8d:


    xy "\"But I'm serious about that last part.\""


translate english c4131_5f747d95:


    "Miro directo a los ojos de Miyuki."


translate english c4131_ba89b094:


    xy "\"Please, I'm begging you!\""


translate english c4131_dff770a4:


    xy "\"Aoi needs you! Please keep being there for her!\""


translate english c4131_80770e59:


    "Me inclino humildemente ante ella."


translate english c4131_f6641e29:


    "Y espero."


translate english c4131_4f4b7572:


    "Y espero... y espero..."


translate english c4131_401a8611:


    "...Sin respuesta."


translate english c4131_4a942642:



    voice "voice/c41/3100260a01.opus"
    mx "\"Listen...\""


translate english c4131_beadc524:



    voice "voice/c41/3100270a01.opus"
    mx "\"...Why are you going to all this effort?\""


translate english c4131_d042823d:


    xy "\"What do you mean, why?\""


translate english c4131_2b570fdd:


    "Levanto la vista y encuentro a Miyuki mirándome con recelo."


translate english c4131_7bea4f35:



    voice "voice/c41/3100280a01.opus"
    mx "\"Do you have feelings for her?\""


translate english c4131_4c10e4bd:


    xy "\"Of course not!\""


translate english c4131_a0549e89:


    "De repente, recuerdo la sensación de su aliento en mi piel—"


translate english c4131_fbacfee6:


    xy "\"She'll never be anything more than a friend to me!!!\""


translate english c4131_01d7a8e9:



    voice "voice/c41/3100290a01.opus"
    mx "\"Shinichi.\""


translate english c4131_1c966ec4:



    voice "voice/c41/3100300a01.opus"
    mx "\"She can hear you, you know.\""


translate english c4131_50596c6d:


    xy "\"Oh...\""


translate english c4131_d65ebc71:


    "Mi sangre se hiela."


translate english c4131_3d40ed02:


    "Rápidamente miro hacia abajo, a Aoi—"


translate english c4131_b21f96f3:



    voice "voice/c41/3100310a02.opus"
    aoi "\"Look! Kitty ears!\""


translate english c4131_b24fb86a:



    voice "voice/c41/3100320a02.opus"
    aoi "\"So cute!\""


translate english c4131_6d07bb22:



    voice "voice/c41/3100340a01.opus"
    mx "\"Are you glad to know she didn't hear you after all?\""


translate english c4131_202e6dc8:


    xy "\"N-No, that's not—\""


translate english c4131_ed6ec7da:



    voice "voice/c41/3100350a01.opus"
    mx "\"Well, whatever. In light of your sincerity, I'll extend an olive branch.\""


translate english c4131_a703da51:


    xy "\"You mean it?!\""


translate english c4131_5076fc25:



    voice "voice/c41/3100360a01.opus"
    mx "\"I've been meaning to reach out to her anyway.\""


translate english c4131_fe9c01ef:


    xy "\"Thank you!\""


translate english c4131_3f94ded6:



    voice "voice/c41/3100370a01.opus"
    mx "\"On one condition!\""


translate english c4131_fe5b2bd1:



    voice "voice/c41/3100380a01.opus"
    mx "\"I want you to send me all your Eru pics.\""


translate english c4131_828eb4e0:


    xy "\"You got it.\""


translate english c4131_539835f2:



    voice "voice/c41/3100390a01.opus"
    mx "\"Promise me!\""


translate english c4131_72191990:


    xy "\"I promise!\""


translate english c4131_eb8c7cc9:



    voice "voice/c41/3100400a01.opus"
    mx "\"Send them right now!\""


translate english c4131_211c0170:


    "Vaya, está loca por las fotos de gatos..."


translate english c4131_3c8249b0:


    "De inmediato le mando por correo todas mis fotos de Eru y Aoi."


translate english c4131_cd116d4d:


    xy "\"Sent.\""


translate english c4131_c5236604:



    voice "voice/c41/3100410a01.opus"
    mx "\"Thank you!\""


translate english c4131_df5b414d:



    voice "voice/c41/3100420a01.opus"
    mx "\"Oh... oh... oh...!\""


translate english c4131_9b5cab18:



    voice "voice/c41/3100430a01.opus"
    mx "\"Oh my god, so CUTE...!\""


translate english c4131_917bff78:



    voice "voice/c41/3100440a01.opus"
    mx "\"I can't believe such a perfect little creature exists on this earth...\""


translate english c4131_769932cd:


    "Y, en efecto, Miyuki mira las fotos extasiada—"


translate english c4131_9a857b61:



    voice "voice/c41/3100450a01.opus"
    mx "\"Oh...\""


translate english c4131_8a974df1:


    "—pero entonces—"


translate english c4131_7e2aef03:



    voice "voice/c41/3100460a01.opus"
    mx "\"Wait, huh?\""


translate english c4131_879cdfea:


    "—inclina la cabeza."


translate english c4131_c2652297:



    voice "voice/c41/3100470a01.opus"
    mx "\"I feel like I recognize this background—\""


translate english c4131_8cd3ec85:


    "Ay, mierda."


translate english c4131_ed809050:


    xy "\"Huh? Oh, that's, er... It's probably too dark to tell, but it's... I think it's a storage closet at school...?\""


translate english c4131_6f058f29:



    voice "voice/c41/3100480a01.opus"
    mx "\"Aoi!\""


translate english c4131_5e7db8a9:


    "Miyuki me ignora y le llama a Aoi."


translate english c4131_4809b1b1:



    voice "voice/c41/3100490a01.opus"
    mx "\"Where was this photo taken?\""


translate english c4131_fb553f16:



    voice "voice/c41/3100500a02.opus"
    aoi "\"At Shinichi's house.\""


translate english c4131_077ad8a6:


    xy "\"Hey!\""


translate english c4131_55e8dde1:


    "¡No se lo digas así nomás!"


translate english c4131_d780d63a:



    voice "voice/c41/3100510a01.opus"
    mx "\"You were at his house yesterday?\""


translate english c4131_ec06723a:



    voice "voice/c41/3100520a02.opus"
    aoi "\"Uh huh. Spent the night.\""


translate english c4131_975bb305:



    voice "voice/c41/3100530a01.opus"
    mx "\"—?!\""


translate english c4131_7e065c20:



    voice "voice/c41/3100540a01.opus"
    mx "\"Wh-What do you mean, you spent the night?!\""


translate english c4131_a7fec77e:



    voice "voice/c41/3100550a02.opus"
    aoi "\"We slept in the same house last night.\""


translate english c4131_2a0ee736:



    voice "voice/c41/3100560a01.opus"
    mx "\"......!\""


translate english c4131_83395910:


    xy "\"Don't get it twisted. She slept on the couch, okay? I mean, what was I supposed to do, let her sleep on the street?\""


translate english c4131_c6756907:



    voice "voice/c41/3100570a01.opus"
    mx "\"...Okay, fair point...\""


translate english c4131_97f9034f:



    voice "voice/c41/3100580a01.opus"
    mx "\"How'd it go, Aoi? Did he try anything? Did you get enough sleep?\""


translate english c4131_477503eb:



    voice "voice/c41/3100590a02.opus"
    aoi "\"Couldn't sleep at all...\""


translate english c4131_52b8c8e2:



    voice "voice/c41/3100600a01.opus"
    mx "\"You couldn't?\""


translate english c4131_081d438e:



    voice "voice/c41/3100610a02.opus"
    aoi "\"Shinichi's house smells like him.\""


translate english c4131_02cb6d24:



    voice "voice/c41/3100620a02.opus"
    aoi "\"Makes me restless.\""


translate english c4131_8dad9578:



    voice "voice/c41/3100630a02.opus"
    aoi "\"Makes my heart pound.\""


translate english c4131_e2fba6fe:



    voice "voice/c41/3100640a01.opus"
    mx "\"And that kept you up all night?\""


translate english c4131_4dcbffc5:



    voice "voice/c41/3100650a02.opus"
    aoi "\"It's weird...\""


translate english c4131_dd9699c9:



    voice "voice/c41/3100660a02.opus"
    aoi "\"My body was all zappy...\""


translate english c4131_dc5dbda1:



    voice "voice/c41/3100670a02.opus"
    aoi "\"Is... Is Aoi sick?\""


translate english c4131_8df2608d:



    voice "voice/c41/3100680a01.opus"
    mx "\"Haah...\""


translate english c4131_e0d378f4:


    "Miyuki suspira fuerte."


translate english c4131_cfa82e53:



    voice "voice/c41/3100690a01.opus"
    mx "\"Allow me to fill you in, Aoi.\""


translate english c4131_da097153:



    voice "voice/c41/3100700a02.opus"
    aoi "\"Boop boop?\""


translate english c4131_830a1474:



    voice "voice/c41/3100710a01.opus"
    mx "\"Those feelings you have? Those aren't friendship feelings.\""


translate english c4131_9d2f7c15:



    voice "voice/c41/3100720a01.opus"
    mx "\"...It's love.\""


translate english c4131_4ada539a:



    voice "voice/c41/3100730a01.opus"
    mx "\"You're in love with Shinichi.\""


translate english c4131_2563101c:



    voice "voice/c41/3100740a02.opus"
    aoi "\"Love...?\""


translate english c4131_9bbd4f03:


    "Aoi mira al vacío."


translate english c4131_044e0fa9:



    voice "voice/c41/3100750a02.opus"
    aoi "\"Aoi's... in love... with Shinichi...\""


translate english c4131_012ea25f:



    voice "voice/c41/3100760a02.opus"
    aoi "\"Aoi's... in love... with Shinichi...?\""


translate english c4131_b466175d:



    voice "voice/c41/3100770a02.opus"
    aoi "\"Wh... What the?\""


translate english c4131_2ed120d4:



    voice "voice/c41/3100780a02.opus"
    aoi "\"Is Aoi glitched?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
