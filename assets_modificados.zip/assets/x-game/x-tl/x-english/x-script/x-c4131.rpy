

translate english c4131_278748bd:


    "A la hora del almuerzo—"


translate english c4131_fa3ba335:



    voice "voice/c41/3100010a01.opus"
    mx "\"Aah... aah...\""


translate english c4131_4647b766:



    voice "voice/c41/3100020a01.opus"
    mx "\"¡¡¡AACHÚ!!!\""


translate english c4131_4df6002e:



    voice "voice/c41/3100030a01.opus"
    mx "\"Snnnfff...\""


translate english c4131_949efac9:


    xy "\"¿Estás bien?\""


translate english c4131_34994f8a:



    voice "voice/c41/3100040a01.opus"
    mx "\"...Son solo mis alergias.\""


translate english c4131_75a82f2e:


    "Estamos en la azotea."


translate english c4131_0b7ea6a7:


    "Tengo una conversación privada con Miyuki."


translate english c4131_ca64ff9a:



    voice "voice/c41/3100050a01.opus"
    mx "\"Muy bien, entiendo.\""


translate english c4131_5dbd459c:



    voice "voice/c41/3100060a01.opus"
    mx "\"No sabía que tú también tenías un caso grave de cerebro gamer.\""


translate english c4131_8d4a1bb5:


    xy "\"¡No es cierto!\""


translate english c4131_3e9e8306:


    xy "\"Vamos, míralos.\""


translate english c4131_a4354c89:



    voice "voice/c41/3100070a02.opus"
    aoi "\"¡Ven aquí, Eru!\""


translate english c4131_6f8c626c:



    voice "voice/c41/3100090a02.opus"
    aoi "\"¿Bip bip? ¿A dónde vas?\""


translate english c4131_f650c477:


    "Señalo a Aoi, que en este momento juega con Eru."


translate english c4131_5ebb67cb:


    "Una imagen vale más que mil palabras, después de todo."


translate english c4131_5a753e3b:


    "Y esto puede o no ser exactamente la razón por la que me tomé la molestia de traer a Eru a la escuela con nosotros."


translate english c4131_fcd6c5cd:


    xy "\"¿Cómo te hace sentir verlos jugar?\""


translate english c4131_bf265575:



    voice "voice/c41/3100110a01.opus"
    mx "\"......\""


translate english c4131_e72942ab:


    xy "\"...¿Miyuki?\""


translate english c4131_9f12c29a:



    voice "voice/c41/3100120a01.opus"
    mx "\"\"\"\"......!\"!\"\"\""


translate english c4131_f56e12af:


    xy "\"Eh... estás babeando.\""


translate english c4131_dc7dfbbf:



    voice "voice/c41/3100130a01.opus"
    mx "\"¡AH!\""


translate english c4131_949efac9_1:


    xy "\"¿Estás bien?\""


translate english c4131_b781556d:



    voice "voice/c41/3100140a01.opus"
    mx "\"¿¡E-Estás ciega!? ¡Claro que no estoy bien!\""


translate english c4131_55f1be03:


    xy "\"Aoi y Eru parecen bastante felices juntos, ¿no crees?\""


translate english c4131_b761dfdc:



    voice "voice/c41/3100150a01.opus"
    mx "\"Mm... Supongo.\""


translate english c4131_4a53a07f:


    xy "\"Esto nunca habría pasado si Aoi no hubiera rescatado a la cosita anoche.\""


translate english c4131_b513a00c:


    xy "\"Y creo que hizo bien en hacerlo.\""


translate english c4131_b825920b:



    voice "voice/c41/3100160a01.opus"
    mx "\"Claro, están felices, pero ese no es el problema aquí.\""


translate english c4131_53036897:



    voice "voice/c41/3100170a01.opus"
    mx "\"Las cosas pueden estar bien por ahora, pero tarde o temprano habrá problemas.\""


translate english c4131_41e7855f:


    "Miyuki sigue siendo tan terca como siempre, veo..."


translate english c4131_dd95cd47:


    "Por suerte, lo vi venir."


translate english c4131_6d2ccffe:


    "Y tengo un as bajo la manga."


translate english c4131_a3d1745a:


    xy "\"Dime, Miyuki.\""


translate english c4131_4de83bad:



    voice "voice/c41/3100180a01.opus"
    mx "\"¿Hm?\""



translate english c4131_bd82cf7f:


    "Le muestro la pantalla de mi teléfono... pero solo por un momento."


translate english c4131_81a0d8f1:


    "Luego lo guardo."


translate english c4131_e7367821:



    voice "voice/c41/3100190a01.opus"
    mx "\"¿¡Qué demonios!? ¿A qué vino ESO?\""


translate english c4131_c31add03:


    xy "\"¿Quieres verlo?\""


translate english c4131_5cee8ffd:



    voice "voice/c41/3100200a01.opus"
    mx "\"¡Claro que sí! ¡Muéstramelo! ¿¡Eso era—!?\""


translate english c4131_bf5ebd44:


    xy "\"¿Una foto súper rara de Eru durmiendo? Sí lo es.\""


translate english c4131_69f360ce:


    xy "\"Si quieres verla...\""


translate english c4131_390b964a:


    xy "\"...entonces a ver si arreglas las cosas con Aoi.\""


translate english c4131_edb94251:



    voice "voice/c41/3100210a01.opus"
    mx "\"¿D-De verdad crees que puedes sobornarme con ESO?\""


translate english c4131_395156cf:


    xy "\"Oh, y Aoi también lleva el enterizo de gatito en la foto.\""


translate english c4131_b77c0872:



    voice "voice/c41/3100220a01.opus"
    mx "\"No se me puede comprar... ¡No se me puede comprar...!\""


translate english c4131_e610a126:


    xy "\"Vamooos, sabes que quieres...\""


translate english c4131_b9e3545a:



    voice "voice/c41/3100230a01.opus"
    mx "\"......!\""


translate english c4131_f62d2cef:



    voice "voice/c41/3100240a01.opus"
    mx "\"¡¡¡E-ERES UN TRAMPOSO!!!\""


translate english c4131_1f7dfe59:


    xy "\"Tramposo, cerebro gamer, lo que sea. Puedes insultarme todo lo que quieras.\""


translate english c4131_2ef85acc:


    xy "\"Solo quiero volver a pasar el rato con mis dos buenos amigos.\""


translate english c4131_02826976:



    voice "voice/c41/3100250a01.opus"
    mx "\"¿Crees que me trago un segundo de esa pequeña actuación de tipo cool?\""


translate english c4131_bdeb9fd8:


    xy "\"Perdón. Solo estaba bromeando.\""


translate english c4131_95499b8d:


    xy "\"Pero hablo en serio sobre lo último.\""


translate english c4131_5f747d95:


    "Miro directo a los ojos de Miyuki."


translate english c4131_ba89b094:


    xy "\"¡Por favor, te lo ruego!\""


translate english c4131_dff770a4:


    xy "\"¡Aoi te necesita! ¡Por favor, sigue estando ahí para ella!\""


translate english c4131_80770e59:


    "Me inclino humildemente ante ella."


translate english c4131_f6641e29:


    "Y espero."


translate english c4131_4f4b7572:


    "Y espero... y espero..."


translate english c4131_401a8611:


    "...Sin respuesta."


translate english c4131_4a942642:



    voice "voice/c41/3100260a01.opus"
    mx "\"Escucha...\""


translate english c4131_beadc524:



    voice "voice/c41/3100270a01.opus"
    mx "\"...¿Por qué te esfuerzas tanto?\""


translate english c4131_d042823d:


    xy "\"¿Cómo que por qué?\""


translate english c4131_2b570fdd:


    "Levanto la vista y encuentro a Miyuki mirándome con recelo."


translate english c4131_7bea4f35:



    voice "voice/c41/3100280a01.opus"
    mx "\"¿Sientes algo por ella?\""


translate english c4131_4c10e4bd:


    xy "\"¡Claro que no!\""


translate english c4131_a0549e89:


    "De repente, recuerdo la sensación de su aliento en mi piel—"


translate english c4131_fbacfee6:


    xy "\"¡Nunca será nada más que una amiga para mí!\""


translate english c4131_01d7a8e9:



    voice "voice/c41/3100290a01.opus"
    mx "\"Shinichi.\""


translate english c4131_1c966ec4:



    voice "voice/c41/3100300a01.opus"
    mx "\"Puede oírte, sabes.\""


translate english c4131_50596c6d:


    xy "\"Oh...\""


translate english c4131_d65ebc71:


    "Mi sangre se hiela."


translate english c4131_3d40ed02:


    "Rápidamente miro hacia abajo, a Aoi—"


translate english c4131_b21f96f3:



    voice "voice/c41/3100310a02.opus"
    aoi "\"¡Mira! ¡Orejitas de gatito!\""


translate english c4131_b24fb86a:



    voice "voice/c41/3100320a02.opus"
    aoi "\"¡Qué lindo!\""


translate english c4131_6d07bb22:



    voice "voice/c41/3100340a01.opus"
    mx "\"¿Te alegra saber que al final no te oyó?\""


translate english c4131_202e6dc8:


    xy "\"N-No, no es—\""


translate english c4131_ed6ec7da:



    voice "voice/c41/3100350a01.opus"
    mx "\"Bueno, lo que sea. En vista de tu sinceridad, extenderé una rama de olivo.\""


translate english c4131_a703da51:


    xy "\"¿¡Lo dices en serio!?\""


translate english c4131_5076fc25:



    voice "voice/c41/3100360a01.opus"
    mx "\"De todos modos tenía la intención de acercarme a ella.\""


translate english c4131_fe9c01ef:


    xy "\"¡Gracias!\""


translate english c4131_3f94ded6:



    voice "voice/c41/3100370a01.opus"
    mx "\"¡Con una condición!\""


translate english c4131_fe5b2bd1:



    voice "voice/c41/3100380a01.opus"
    mx "\"Quiero que me envíes todas tus fotos de Eru.\""


translate english c4131_828eb4e0:


    xy "\"Entendido.\""


translate english c4131_539835f2:



    voice "voice/c41/3100390a01.opus"
    mx "\"¡Prométemelo!\""


translate english c4131_72191990:


    xy "\"¡Lo prometo!\""


translate english c4131_eb8c7cc9:



    voice "voice/c41/3100400a01.opus"
    mx "\"¡Envíamelas ahora mismo!\""


translate english c4131_211c0170:


    "Vaya, está loca por las fotos de gatos..."


translate english c4131_3c8249b0:


    "De inmediato le mando por correo todas mis fotos de Eru y Aoi."


translate english c4131_cd116d4d:


    xy "\"Enviadas.\""


translate english c4131_c5236604:



    voice "voice/c41/3100410a01.opus"
    mx "\"¡Gracias!\""


translate english c4131_df5b414d:



    voice "voice/c41/3100420a01.opus"
    mx "\"¡Oh... oh... oh...!\""


translate english c4131_9b5cab18:



    voice "voice/c41/3100430a01.opus"
    mx "\"¡Dios mío, qué LINDO...!\""


translate english c4131_917bff78:



    voice "voice/c41/3100440a01.opus"
    mx "\"No puedo creer que exista una criaturita tan perfecta en esta tierra...\""


translate english c4131_769932cd:


    "Y, en efecto, Miyuki mira las fotos extasiada—"


translate english c4131_9a857b61:



    voice "voice/c41/3100450a01.opus"
    mx "\"Oh...\""


translate english c4131_8a974df1:


    "—pero entonces—"


translate english c4131_7e2aef03:



    voice "voice/c41/3100460a01.opus"
    mx "\"Espera, ¿eh?\""


translate english c4131_879cdfea:


    "—inclina la cabeza."


translate english c4131_c2652297:



    voice "voice/c41/3100470a01.opus"
    mx "\"Siento que reconozco este fondo—\""


translate english c4131_8cd3ec85:


    "Ay, mierda."


translate english c4131_ed809050:


    xy "\"¿Eh? Oh, eso es, er... Probablemente está demasiado oscuro para saberlo, pero es... creo que es un cuarto de almacenamiento de la escuela...?\""


translate english c4131_6f058f29:



    voice "voice/c41/3100480a01.opus"
    mx "\"¡Aoi!\""


translate english c4131_5e7db8a9:


    "Miyuki me ignora y le llama a Aoi."


translate english c4131_4809b1b1:



    voice "voice/c41/3100490a01.opus"
    mx "\"¿Dónde se tomó esta foto?\""


translate english c4131_fb553f16:



    voice "voice/c41/3100500a02.opus"
    aoi "\"En la casa de Shinichi.\""


translate english c4131_077ad8a6:


    xy "\"¡Oye!\""


translate english c4131_55e8dde1:


    "¡No se lo digas así nomás!"


translate english c4131_d780d63a:



    voice "voice/c41/3100510a01.opus"
    mx "\"¿Estuviste en su casa ayer?\""


translate english c4131_ec06723a:



    voice "voice/c41/3100520a02.opus"
    aoi "\"Ajá. Pasé la noche.\""


translate english c4131_975bb305:



    voice "voice/c41/3100530a01.opus"
    mx "\"—?!\""


translate english c4131_7e065c20:



    voice "voice/c41/3100540a01.opus"
    mx "\"¿¡Q-Qué quieres decir con que pasaste la noche!?\""


translate english c4131_a7fec77e:



    voice "voice/c41/3100550a02.opus"
    aoi "\"Dormimos en la misma casa anoche.\""


translate english c4131_2a0ee736:



    voice "voice/c41/3100560a01.opus"
    mx "\"......!\""


translate english c4131_83395910:


    xy "\"No te confundas. Ella durmió en el sofá, ¿okay? O sea, ¿qué se suponía que hiciera, dejarla dormir en la calle?\""


translate english c4131_c6756907:



    voice "voice/c41/3100570a01.opus"
    mx "\"...Okay, buen punto...\""


translate english c4131_97f9034f:



    voice "voice/c41/3100580a01.opus"
    mx "\"¿Cómo te fue, Aoi? ¿Intentó algo? ¿Dormiste lo suficiente?\""


translate english c4131_477503eb:



    voice "voice/c41/3100590a02.opus"
    aoi "\"No pude dormir nada...\""


translate english c4131_52b8c8e2:



    voice "voice/c41/3100600a01.opus"
    mx "\"¿No pudiste?\""


translate english c4131_081d438e:



    voice "voice/c41/3100610a02.opus"
    aoi "\"La casa de Shinichi huele a él.\""


translate english c4131_02cb6d24:



    voice "voice/c41/3100620a02.opus"
    aoi "\"Me pone inquieta.\""


translate english c4131_8dad9578:



    voice "voice/c41/3100630a02.opus"
    aoi "\"Me hace latir el corazón fuerte.\""


translate english c4131_e2fba6fe:



    voice "voice/c41/3100640a01.opus"
    mx "\"¿Y eso te mantuvo despierta toda la noche?\""


translate english c4131_4dcbffc5:



    voice "voice/c41/3100650a02.opus"
    aoi "\"Es raro...\""


translate english c4131_dd9699c9:



    voice "voice/c41/3100660a02.opus"
    aoi "\"Mi cuerpo estaba todo chispeante...\""


translate english c4131_dc5dbda1:



    voice "voice/c41/3100670a02.opus"
    aoi "\"¿Está... está Aoi enferma?\""


translate english c4131_8df2608d:



    voice "voice/c41/3100680a01.opus"
    mx "\"Jaah...\""


translate english c4131_e0d378f4:


    "Miyuki suspira fuerte."


translate english c4131_cfa82e53:



    voice "voice/c41/3100690a01.opus"
    mx "\"Permíteme ilustrarte, Aoi.\""


translate english c4131_da097153:



    voice "voice/c41/3100700a02.opus"
    aoi "\"¿Bip bip?\""


translate english c4131_830a1474:



    voice "voice/c41/3100710a01.opus"
    mx "\"Esos sentimientos que tienes. No son sentimientos de amistad.\""


translate english c4131_9d2f7c15:



    voice "voice/c41/3100720a01.opus"
    mx "\"...Es amor.\""


translate english c4131_4ada539a:



    voice "voice/c41/3100730a01.opus"
    mx "\"Estás enamorada de Shinichi.\""


translate english c4131_2563101c:



    voice "voice/c41/3100740a02.opus"
    aoi "\"¿Amor...?\""


translate english c4131_9bbd4f03:


    "Aoi mira al vacío."


translate english c4131_044e0fa9:



    voice "voice/c41/3100750a02.opus"
    aoi "\"Aoi está... enamorada... de Shinichi...\""


translate english c4131_012ea25f:



    voice "voice/c41/3100760a02.opus"
    aoi "\"¿Aoi está... enamorada... de Shinichi...?\""


translate english c4131_b466175d:



    voice "voice/c41/3100770a02.opus"
    aoi "\"¿Qu... Qué demonios?\""


translate english c4131_2ed120d4:



    voice "voice/c41/3100780a02.opus"
    aoi "\"¿Aoi se bugueó?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
