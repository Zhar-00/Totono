

translate english e2153_f9489625:



    voice "voice/e21/5300010a01.opus"
    mx "\"You know... it's really nice, walking home just the two of us.\""


translate english e2153_9dcedf11:



    voice "voice/e21/5300020a01.opus"
    mx "\"Can you imagine if someone tried to interrupt this? Wouldn't that just piss you off?\""


translate english strings:


    old "Определённо"
    new "Definitivamente"


    old "Не совсем"
    new "No realmente"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
