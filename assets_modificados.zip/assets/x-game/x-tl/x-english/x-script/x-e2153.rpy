

translate english e2153_f9489625:



    voice "voice/e21/5300010a01.opus"
    mx "\"Sabes... es muy agradable, volver a casa solo nosotros dos.\""


translate english e2153_9dcedf11:



    voice "voice/e21/5300020a01.opus"
    mx "\"¿Puedes imaginar si alguien intentara interrumpir esto? ¿No te daría rabia?\""


translate english strings:


    old "Определённо"
    new "Definitivamente"


    old "Не совсем"
    new "No realmente"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
