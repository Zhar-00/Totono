

translate english d4233_024b238b:


    "Marco 911 rápidamente."


translate english d4233_e209aab5:


    xy "\"Hello?\""


translate english d4233_5e19265e:


    xy "\"I need an ambulance. We're located—\""


translate english d4233_1819b22f:


    "...¿Les digo que estamos en el techo de la escuela?"


translate english d4233_b149814f:


    "¿O hago que Aoi baje conmigo a las rejas?"


translate english d4233_b1b7427d:


    xy "\"Eru, hold on a second—\""


translate english d4233_0e671413:


    xy "\"......What the?\""


translate english d4233_c26f6fd9:


    "Las fuerzas drenan de mis dedos."


translate english d4233_34d45a73:


    "Mi cerebro lucha por procesar lo que ve."


translate english d4233_95e32262:


    "El maullido de Eru me devuelve a la realidad—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
