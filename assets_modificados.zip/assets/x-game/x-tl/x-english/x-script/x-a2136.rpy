

translate english a2136_3031092d:



    voice "voice/a21/3600010a02.opus"
    aoi "\"Ggllpp... ggllpp... ggllpp...\""


translate english a2136_2d0f2cd9:



    voice "voice/a21/3600020a02.opus"
    aoi "\"All done!\""


translate english a2136_a83a9916:


    "Una vez más, el almuerzo de Aoi es precisamente una lata de Yabaley's."


translate english a2136_66fddd7e:



    voice "voice/a21/3600030a02.opus"
    aoi "\"That hit the spot...\""


translate english a2136_a2914e24:



    voice "voice/a21/3600040a02.opus"
    aoi "\"But...\""


translate english a2136_24f57f38:


    "La mirada de Aoi vaga hacia el almuerzo de Miyuki. No es que la culpe."


translate english a2136_1b08decc:



    voice "voice/a21/3600050a01.opus"
    mx "\"Care to split it with me, Mukou-san?\""


translate english a2136_e0c8fb68:



    voice "voice/a21/3600060a02.opus"
    aoi "\"Boop boop...?\""


translate english a2136_b411c569:


    "Miyuki empuja el recipiente hacia Aoi."


translate english a2136_9c956ef1:



    voice "voice/a21/3600070a01.opus"
    mx "\"You're still hungry, aren't you?\""


translate english a2136_a360c7ce:



    voice "voice/a21/3600080a02.opus"
    aoi "\"But it's yours.\""


translate english a2136_bebe0618:



    voice "voice/a21/3600090a01.opus"
    mx "\"I need to watch my calories. The play's right around the corner, after all. Help me out, would you?\""



translate english a2136_c995f4ed:



    voice "voice/a21/3600100a02.opus"
    aoi "\"But...\""


translate english a2136_8dbc71da:



    voice "voice/a21/3600110a01.opus"
    mx "\"Say ahhh!\""


translate english a2136_0cfddeda:



    voice "voice/a21/3600120a02.opus"
    aoi "\"Aah...\""


translate english a2136_6cbfc5da:


    "Miyuki agita un hot dog de pulpo bajo la nariz de Aoi."


translate english a2136_4141463d:



    voice "voice/a21/3600130a02.opus"
    aoi "\"Aah... aaahh... aaaahhh...!\""


translate english a2136_0f4719c9:


    "Los labios de Aoi se separan como si estuviera embelesada."


translate english a2136_88a508a7:



    voice "voice/a21/3600140a02.opus"
    aoi "\"Nom.\""


translate english a2136_31352f64:


    "Yyy ya no está."


translate english a2136_a4673e8f:



    voice "voice/a21/3600150a02.opus"
    aoi "\"Nom nom... nom nom...\""


translate english a2136_6af40acb:



    voice "voice/a21/3600160a02.opus"
    aoi "\"Mmm... What IS this...?!\""


translate english a2136_08ee1552:



    voice "voice/a21/3600170a01.opus"
    mx "\"How is it?\""


translate english a2136_44c7e36d:



    voice "voice/a21/3600180a02.opus"
    aoi "\"This is CHEATING!\""


translate english a2136_b63967de:


    xy "\"How is it cheating?\""


translate english a2136_4efdb6b3:



    voice "voice/a21/3600190a01.opus"
    mx "\"I didn't even trick you or anything.\""


translate english a2136_5e72b899:



    voice "voice/a21/3600200a02.opus"
    aoi "\"No... That's how tasty it is!\""


translate english a2136_8b0a77cb:



    voice "voice/a21/3600210a01.opus"
    mx "\"Oh, right. Thanks.\""


translate english a2136_9739489d:



    voice "voice/a21/3600220a02.opus"
    aoi "\"As tasty as Yabaley's!\""


translate english a2136_f9557790:



    voice "voice/a21/3600230a01.opus"
    mx "\"...Are you sure I can take that as a compliment?\""


translate english a2136_a85edbc2:


    xy "\"P-Probably...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
