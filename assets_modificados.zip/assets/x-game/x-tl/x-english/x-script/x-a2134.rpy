

translate english a2134_3fcaf41d:



    voice "voice/a21/3400010a02.opus"
    aoi "\"Aoi tiene un montón de pastel hoy.\""


translate english a2134_3688cecc:


    xy "\"¿Para qué compraste todo eso?\""


translate english a2134_b76aac36:



    voice "voice/a21/3400020a02.opus"
    aoi "\"No tenían sándwiches.\""


translate english a2134_d3bc6d46:


    xy "\"Sigue hablando así y Miyuki te va a poner en tu lugar. ¿Verdad, Miyuki?\""


translate english a2134_d1a746c5:



    voice "voice/a21/3400030a01.opus"
    mx "\"\"......\"\""


translate english a2134_1883235e:


    xy "\"¡Eeep!\""


translate english a2134_70d7ab21:


    "La mirada de Miyuki sugiere que está a punto de arrastrarme a la guillotina."


translate english a2134_acbcb409:



    voice "voice/a21/3400040a01.opus"
    mx "\"\"......\"\""


translate english a2134_534fa9b3:


    "Y va totalmente en serio."


translate english a2134_18c8215e:



    voice "voice/a21/3400050a02.opus"
    aoi "\"Miyuki, tus ojos están todos chispeantes.\""


translate english a2134_44204899:


    xy "\"¿Estás enojada con nosotros otra vez?\""


translate english a2134_c980eef6:



    voice "voice/a21/3400060a01.opus"
    mx "\"¡NO estoy enojada!\""


translate english a2134_3362028c:


    "Vaya déjà vu... Siento que esto también pasó el otro día..."


translate english a2134_54d52933:


    "Ah, es cierto. Se molestó ese día que Aoi la invitó a comer helado."


translate english a2134_6c152e53:


    "........"



translate english a2134_0640a426:


    xy "\"Hey, eh...\""


translate english a2134_9c62f93e:


    xy "\"Por casualidad, ¿estás... a dieta?\""


translate english a2134_f6fd2c06:



    voice "voice/a21/3400070a01.opus"
    mx "\"Oh, perdón, ¿hay algún PROBLEMA con cómo elijo manejar mi peso?\""


translate english a2134_fbcf52a6:


    "Da aún más miedo cuando habla con ese tono de voz tan ecuánime..."


translate english a2134_57f911f2:



    voice "voice/a21/3400080a01.opus"
    mx "\"En fin, no es que quiera ser cortante al respecto.\""


translate english a2134_485d6838:



    voice "voice/a21/3400090a01.opus"
    mx "Obviamente voy a querer cuidar mi reputa—\""


translate english a2134_6520e659:



    voice "voice/a21/3400100a02.opus"
    aoi "\"Miyuki, ¿no te permiten comer dulces?\""


translate english a2134_44eec2f6:



    voice "voice/a21/3400110a01.opus"
    mx "\"No me llames a—\""


translate english a2134_0bfce443:



    voice "voice/a21/3400120a02.opus"
    aoi "\"¡Entendido!\""


translate english a2134_15b17721:


    "Aoi se pone de pie de un salto, con la mano en el aire."


translate english a2134_89fae16b:



    voice "voice/a21/3400130a02.opus"
    aoi "\"¡Hyah!\""


translate english a2134_77d9c04f:



    voice "voice/a21/3400140a01.opus"
    mx "\"¿Qh...? ¿¡Qué demonios estás haciendo!?\""


translate english a2134_0a9f911a:


    "¡Acaba de tirar todo su pastel desde la azotea!"


translate english a2134_6347451b:


    "La bolsa traza un arco perfecto por el cielo mientras desaparece de la vista."


translate english a2134_e52d8af7:



    voice "voice/a21/3400150a01.opus"
    mx "\"¿¡T-Te das cuenta de lo DESPILFARRADOR—!?\""


translate english a2134_2c7f8d45:



    voice "voice/a21/3400160a02.opus"
    aoi "\"Aoi no lo va a comer.\""


translate english a2134_1ff3ce0d:



    voice "voice/a21/3400170a02.opus"
    aoi "\"Aoi compartirá tu dolor. Para eso son los amigos.\""


translate english a2134_2ecf3af8:



    voice "voice/a21/3400180a01.opus"
    mx "\"Como dije, no somos... Haah.\""


translate english a2134_aaec6f08:


    "Miyuki suspira y niega con la cabeza, pero está sonriendo."


translate english a2134_36e3bff7:



    voice "voice/a21/3400190a01.opus"
    mx "\"Bien, como sea.\""


translate english a2134_f8b43d0e:



    voice "voice/a21/3400200a01.opus"
    mx "\"Pero si te vuelvo a ver desperdiciando comida así, NO estaré feliz, ¿me oyes?\""


translate english a2134_40189ab2:



    voice "voice/a21/3400210a02.opus"
    aoi "\"Bip bip...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
