

translate english a2151_4e754902:



    voice "voice/a21/5100010a01.opus"
    mx "\"Shinichi! You keep your eyes shut, got it?!\""


translate english a2151_17dcd6fc:


    xy "\"I know, I know...\""


translate english a2151_de372687:


    xy "\"This wouldn't be an issue if I climbed up first, you know...\""


translate english a2151_309edb21:



    voice "voice/a21/5100020a01.opus"
    mx "\"O-Obviously I realize that. It's a matter of courtesy! Ladies first!\""


translate english a2151_7a4e8330:



    voice "voice/a21/5100030a02.opus"
    aoi "\"Showing off your ditzy side?\""


translate english a2151_b2987220:



    voice "voice/a21/5100040a01.opus"
    mx "\"No!\""


translate english a2151_c86d1e94:


    "Incluso con los ojos cerrados, puedo notar que Miyuki se sonroja."


translate english a2151_2a276af6:



    voice "voice/a21/5100050a02.opus"
    aoi "\"Okay, Miyuki made it.\""


translate english a2151_be764df6:



    voice "voice/a21/5100060a02.opus"
    aoi "\"Shinichi, it's your turn.\""


translate english a2151_7ec7fbaf:


    xy "\"Cool.\""


translate english a2151_0d8df812:


    "Con los ojos aún cerrados, pongo la mano en el primer peldaño y subo lentamente."


translate english a2151_6de47610:


    "Luego, al llegar arriba, abro los ojos."


translate english a2151_0accd139:


    xy "\"\"\"......\"\"\""


translate english a2151_a0ea4afd:


    "La vista es realmente impresionante."


translate english a2151_5a67d871:


    "Ya sé qué esperar, y aun así me cautiva."


translate english a2151_9d1e4241:


    "Y en cuanto a Miyuki..."


translate english a2151_1d29471c:



    voice "voice/a21/5100070a01.opus"
    mx "\"\"\"......\"\"\""


translate english a2151_6daaac8c:


    "Parece que ella siente lo mismo."


translate english a2151_959e362b:



    voice "voice/a21/5100080a01.opus"
    mx "\"It's so beautiful...\""


translate english a2151_e7c25357:



    voice "voice/a21/5100090a01.opus"
    mx "\"I feel a little dumb for stating the obvious, but I can't help it.\""


translate english a2151_24f5f2a2:


    xy "\"We really ought to thank Aoi for bringing us up here.\""


translate english a2151_8b240ee1:



    voice "voice/a21/5100100a02.opus"
    aoi "\"Got it!\""


translate english a2151_e4cd3396:



    voice "voice/a21/5100110a02.opus"
    aoi "\"Aoi will take a photo.\""


translate english a2151_b413463b:


    xy "\"A photo?\""


translate english a2151_62645d95:



    voice "voice/a21/5100120a01.opus"
    mx "\"Oh, that sounds nice. Let's take a selfie, all three of us.\""


translate english a2151_2f2469e4:


    xy "\"Nah, I'll pass. I'll be the cameraman.\""


translate english a2151_0b97055b:


    voice "voice/a21/5100130a01.opus"



translate english a2151_204571f3:


    bm "\"No.\" \"No.\""


translate english a2151_076699c1:



    voice "voice/a21/5100150a02.opus"
    aoi "\"...Boop boop?\""


translate english a2151_afdc372f:



    voice "voice/a21/5100160a01.opus"
    mx "\"Looks like we're on the same page.\""


translate english a2151_8025f15c:


    xy "\"Haah... Fine, whatever.\""


translate english a2151_c01c9ba7:


    "Si ambas están decididas a esto, entonces no hay forma de discutirlo."


translate english a2151_05b29209:



    voice "voice/a21/5100170a01.opus"
    mx "\"Oh, you've got a front-facing camera?\""


translate english a2151_e5d7ec4a:



    voice "voice/a21/5100180a02.opus"
    aoi "\"Yup.\""


translate english a2151_5953614a:



    voice "voice/a21/5100190a01.opus"
    mx "\"Bit of a tight fit, huh?\""


translate english a2151_2257d560:



    voice "voice/a21/5100200a02.opus"
    aoi "\"My arm's too short...\""


translate english a2151_b3268e36:



    voice "voice/a21/5100210a01.opus"
    mx "\"Shinichi, get closer!\""


translate english a2151_efe8ac39:


    xy "\"I don't know if I can...\""


translate english a2151_9f8ef240:


    "Miyuki se aprieta contra mí para salir en la foto, y vaya que es suave..."


translate english a2151_b5ced884:


    "Extremadamente... suave..."


translate english a2151_489136a9:



    voice "voice/a21/5100220a02.opus"
    aoi "\"Shinichi, you're too stiff.\""


translate english a2151_4c087e33:


    "Dímelo a mí."


translate english a2151_d22af78f:



    voice "voice/a21/5100230a01.opus"
    mx "\"Hmm... This should work, yeah?\""


translate english a2151_ca4938fd:


    xy "\"Please hurry it up...\""


translate english a2151_ef357777:



    voice "voice/a21/5100240a02.opus"
    aoi "\"Okay.\""


translate english a2151_422c88b6:



    voice "voice/a21/5100250a02.opus"
    aoi "\"Three...\""


translate english a2151_1adb76fe:



    voice "voice/a21/5100260a02.opus"
    aoi "\"Two...\""


translate english a2151_d605b4b9:



    voice "voice/a21/5100270a02.opus"
    aoi "\"One...\""


translate english a2151_eb50119f:



    voice "voice/a21/5100280a02.opus"
    aoi "\"Got it.\""


translate english a2151_89977bed:



    voice "voice/a21/5100290a01.opus"
    mx "\"Let me see...\""


translate english a2151_7e86d218:



    voice "voice/a21/5100300a01.opus"
    mx "\"Nice! Not bad at all.\""


translate english a2151_cd1444a1:


    xy "\"You can tell I got squashed between you, though...\""


translate english a2151_5c6d76cb:


    xy "\"...Wait, what the?\""


translate english a2151_5ca80aa6:


    xy "\"Is Aoi actually SMILING in this picture?\""


translate english a2151_da7f5d7e:



    voice "voice/a21/5100310a01.opus"
    mx "\"Oh... You're totally right. She is.\""


translate english a2151_7223355e:



    voice "voice/a21/5100320a02.opus"
    aoi "\"Smiling...?\""


translate english a2151_c1851795:


    xy "\"See? Look at your mouth here. That's gotta be a smile.\""


translate english a2151_0a5c1df7:



    voice "voice/a21/5100330a02.opus"
    aoi "\"How'd that happen?\""


translate english a2151_af262680:



    voice "voice/a21/5100340a01.opus"
    mx "\"Probably because you felt happy?\""


translate english a2151_9c993e37:



    voice "voice/a21/5100350a02.opus"
    aoi "\"...Happy?\""


translate english a2151_64bcdee0:



    voice "voice/a21/5100360a02.opus"
    aoi "\"Aoi... felt happy...?\""


translate english a2151_f4600426:


    "Aoi murmura para sí misma, contemplando el concepto."


translate english a2151_b24238d5:


    "Mirando esta foto, se siente como si por fin empezara a salir de su mundo y entrar al nuestro... y su sonrisa es contagiosa."


translate english a2151_b20f2293:



    voice "voice/a21/5100370a01.opus"
    mx "\"Hey, Aoi? Would you send this picture to my phone?\""


translate english a2151_fdc8f115:



    voice "voice/a21/5100380a01.opus"
    mx "\"Oh, wait, I haven't told you my email address yet, have I? Well, while we're at it, I'll give you my number and—\""


translate english a2151_bb768f2e:



    voice "voice/a21/5100390a02.opus"
    aoi "\"Email address?!\""


translate english a2151_d5d4f750:



    voice "voice/a21/5100400a02.opus"
    aoi "\"Let's trade!\""


translate english a2151_11e8cbfd:



    voice "voice/a21/5100410a01.opus"
    mx "\"Sure.\""


translate english a2151_dca00d48:



    voice "voice/a21/5100420a01.opus"
    mx "\"Okay, now you give me yours.\""


translate english a2151_c6e41fe5:



    voice "voice/a21/5100430a01.opus"
    mx "\"There, all done.\""


translate english a2151_f2e0da5e:



    voice "voice/a21/5100440a02.opus"
    aoi "\"Got it!\""


translate english a2151_14ac8361:



    voice "voice/a21/5100450a02.opus"
    aoi "\"Miyuki?\""


translate english a2151_5521538d:



    voice "voice/a21/5100460a02.opus"
    aoi "\"Does this make us... friends?\""


translate english a2151_ef328f16:



    voice "voice/a21/5100470a01.opus"
    mx "\"Hm?\""


translate english a2151_2dd691e2:


    xy "\"Oh yeah, about that...\""


translate english a2151_58e98898:


    xy "\"To Aoi, exchanging email addresses is a sort of... symbol of friendship, as it were...\""


translate english a2151_972cbc4b:



    voice "voice/a21/5100480a01.opus"
    mx "\"Ohhh... So that's why she's been so eager to do it.\""


translate english a2151_36d0e34b:


    xy "\"Exactly.\""


translate english a2151_0d9b7980:


    "Los dos compartimos una risita."


translate english a2151_a749a057:



    voice "voice/a21/5100490a02.opus"
    aoi "\"Are we... not friends?\""


translate english a2151_6c429052:


    "Aoi pregunta con voz queda."


translate english a2151_1bb6db1b:


    "Miyuki se inclina."


translate english a2151_9bb2f14f:



    voice "voice/a21/5100500a01.opus"
    mx "\"We've been friends this whole time, silly.\""


translate english a2151_d09383d4:



    voice "voice/a21/5100510a02.opus"
    aoi "\"Oh!\""


translate english a2151_82e25f58:


    "Y así, el rostro de Aoi se ilumina con otra de esas sonrisas contagiosas."


translate english a2151_2b664261:



    voice "voice/a21/5100520a01.opus"
    mx "\"Now then, give me a test call.\""


translate english a2151_e95a820b:



    voice "voice/a21/5100530a02.opus"
    aoi "\"Boop boop...\""


translate english a2151_913a62a7:



    voice "voice/a21/5100540a02.opus"
    aoi "\"Calling now.\""


translate english a2151_bcb5091c:


    "Pasa un momento de silencio."


translate english a2151_158f5d07:



    voice "voice/a21/5100550a01.opus"
    mx "\"\"\"......\"\"\""


translate english a2151_84a89075:



    voice "voice/a21/5100560a01.opus"
    mx "\"I'm... not getting the call, apparently.\""


translate english a2151_c5a7287d:



    voice "voice/a21/5100570a02.opus"
    aoi "\"Boop boop...?\""


translate english a2151_2323b4f9:



    voice "voice/a21/5100580a01.opus"
    mx "\"I have full bars, though... Shinichi, could you try calling me?\""


translate english a2151_616d966b:


    xy "\"What? I don't even have your number.\""


translate english a2151_b75fc209:



    voice "voice/a21/5100590a01.opus"
    mx "\"What, really?\""


translate english a2151_fa98f95a:



    voice "voice/a21/5100600a01.opus"
    mx "\"Okay then, while we're at it, here you go.\""


translate english a2151_14ea5d4a:


    xy "\"Huh...?\""


translate english a2151_7a18f72d:


    "Miyuki me empuja su teléfono, sin que se lo pida."


translate english a2151_7db59252:


    xy "\"Uhh... What am I supposed to do with this?\""


translate english a2151_e27a690f:



    voice "voice/a21/5100610a01.opus"
    mx "\"You don't have my email address, right? Let's trade.\""


translate english a2151_edb7bf9e:


    xy "\"What? It's cool... We don't have to...\""


translate english a2151_c154a167:



    voice "voice/a21/5100620a02.opus"
    aoi "\"But...\""


translate english a2151_39bab604:



    voice "voice/a21/5100630a02.opus"
    aoi "\"Shinichi and Miyuki and Aoi... We're all friends.\""


translate english a2151_8a0298d6:



    voice "voice/a21/5100640a02.opus"
    aoi "\"Right?\""


translate english a2151_280ef53d:



    voice "voice/a21/5100650a01.opus"
    mx "\"...You heard the woman.\""


translate english a2151_220d51b5:


    xy "\"Haah... Fine, whatever.\""


translate english a2151_4d40fb26:


    "Suspirando fuerte, abro mi agenda."


translate english a2151_6f307614:


    "Y así, su número queda grabado en la memoria de mi teléfono."


translate english a2151_785b5183:


    "Como prueba, le hago una llamada rápida."


translate english a2151_9c783a1b:


    xy "\"...That's quite the girly ringtone you have.\""


translate english a2151_cc39c30d:



    voice "voice/a21/5100660a01.opus"
    mx "\"S-So what if it is?!\""


translate english a2151_665e9158:


    "Miyuki se pone roja como un tomate."


translate english a2151_e9b9b18e:



    voice "voice/a21/5100670a01.opus"
    mx "\"Anyway, moving on! With this, we've confirmed my number does in fact work.\""


translate english a2151_6bf7ac27:


    xy "\"In which case, it's probably—\""


translate english a2151_cfed4e7c:



    voice "voice/a21/5100680a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...!\""


translate english a2151_626346bc:



    voice "voice/a21/5100690a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop... Boop boop...\""


translate english a2151_9ae50849:


    "Aoi niega con la cabeza con tristeza."


translate english a2151_d01ab1ff:



    voice "voice/a21/5100700a02.opus"
    aoi "\"Still no service...\""


translate english a2151_4869887c:


    xy "\"...Yeah, I had a feeling that was it.\""


translate english a2151_3df0e9c6:



    voice "voice/a21/5100710a02.opus"
    aoi "\"Just when we finally became friends for real...\""


translate english a2151_8c3a39b3:



    voice "voice/a21/5100720a02.opus"
    aoi "\"If God won't answer the phone, then Aoi can't save...\""



translate english a2151_28ea4d75:



    voice "voice/a21/5100730a01.opus"
    mx "\"Save what?\""


translate english a2151_7d642bf7:


    "...Ahí va otra vez su cerebro gamer."


translate english a2151_a0537f40:


    "Aunque, si esto de verdad fuera un juego, no la culparía por querer guardar la partida aquí e inmortalizar el nacimiento de nuestra amistad."


translate english a2151_805ec022:



    voice "voice/a21/5100740a01.opus"
    mx "\"Your calls never do seem to go through... Maybe the signal's weak up here?\""


translate english a2151_18978567:



    voice "voice/a21/5100750a02.opus"
    aoi "\"That's definitely not it.\""


translate english a2151_ce7b6461:



    voice "voice/a21/5100760a02.opus"
    aoi "\"The school is the starting point for the universe.\""


translate english a2151_e2d188a6:



    voice "voice/a21/5100770a02.opus"
    aoi "\"And this is the central point of the school.\""


translate english a2151_008582a2:



    voice "voice/a21/5100780a02.opus"
    aoi "\"So this is the center of the universe.\""


translate english a2151_8a7e0383:


    xy "\"Hmm... This should work, yeah?\""


translate english a2151_08613a9f:


    "La mayoría probablemente se reiría y lo tomaría como locura."


translate english a2151_02a9bd99:


    "Demonios, yo era uno de ellos hasta hace poco."


translate english a2151_469c5919:


    "Pero ahora... he empezado a pensar que quizá tiene razón."


translate english a2151_64a40a2f:


    "Y al parecer Miyuki ha estado pensando lo mismo."


translate english a2151_e8f7cb59:



    voice "voice/a21/5100790a01.opus"
    mx "\"...Well, it certainly feels that way.\""


translate english a2151_fdedc8d8:



    voice "voice/a21/5100800a02.opus"
    aoi "\"It's true.\""


translate english a2151_aa46e297:



    voice "voice/a21/5100810a02.opus"
    aoi "\"It all starts here.\""


translate english a2151_1e69937b:



    voice "voice/a21/5100820a02.opus"
    aoi "\"Then, eventually, it ends here.\""


translate english a2151_93272044:



    voice "voice/a21/5100830a01.opus"
    mx "\"More video game nonsense?\""


translate english a2151_ded171f3:



    voice "voice/a21/5100840a02.opus"
    aoi "\"No, this is about God.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
