

translate english a2151_4e754902:



    voice "voice/a21/5100010a01.opus"
    mx "\"¡Shinichi! ¡Mantén los ojos cerrados, ¿entendido?!\""


translate english a2151_17dcd6fc:


    xy "\"Lo sé, lo sé...\""


translate english a2151_de372687:


    xy "\"Esto no sería un problema si yo subiera primero, ¿sabes...?\""


translate english a2151_309edb21:



    voice "voice/a21/5100020a01.opus"
    mx "\"¡O-Obviamente me doy cuenta de eso! ¡Es cuestión de cortesía! ¡Las damas primero!\""


translate english a2151_7a4e8330:



    voice "voice/a21/5100030a02.opus"
    aoi "\"¿Presumiendo tu lado despistado?\""


translate english a2151_b2987220:



    voice "voice/a21/5100040a01.opus"
    mx "\"¡No!\""


translate english a2151_c86d1e94:


    "Incluso con los ojos cerrados, puedo notar que Miyuki se sonroja."


translate english a2151_2a276af6:



    voice "voice/a21/5100050a02.opus"
    aoi "\"Ok, Miyuki lo logró.\""


translate english a2151_be764df6:



    voice "voice/a21/5100060a02.opus"
    aoi "\"Shinichi, es tu turno.\""


translate english a2151_7ec7fbaf:


    xy "\"Bien.\""


translate english a2151_0d8df812:


    "Con los ojos aún cerrados, pongo la mano en el primer peldaño y subo lentamente."


translate english a2151_6de47610:


    "Luego, al llegar arriba, abro los ojos."


translate english a2151_0accd139:


    xy "\"\"\"......\"\"\""


translate english a2151_a0ea4afd:


    "La vista es realmente impresionante."


translate english a2151_5a67d871:


    "Ya sé qué esperar, y aun así me cautiva."


translate english a2151_9d1e4241:


    "Y en cuanto a Miyuki..."


translate english a2151_1d29471c:



    voice "voice/a21/5100070a01.opus"
    mx "\"\"\"......\"\"\""


translate english a2151_6daaac8c:


    "Parece que ella siente lo mismo."


translate english a2151_959e362b:



    voice "voice/a21/5100080a01.opus"
    mx "\"Es tan hermoso...\""


translate english a2151_e7c25357:



    voice "voice/a21/5100090a01.opus"
    mx "\"Me siento un poco tonto por señalar lo obvio, pero no puedo evitarlo.\""


translate english a2151_24f5f2a2:


    xy "\"De verdad deberíamos agradecerle a Aoi por traernos aquí.\""


translate english a2151_8b240ee1:



    voice "voice/a21/5100100a02.opus"
    aoi "\"¡Entendido!\""


translate english a2151_e4cd3396:



    voice "voice/a21/5100110a02.opus"
    aoi "\"Aoi tomará una foto.\""


translate english a2151_b413463b:


    xy "\"¿Una foto?\""


translate english a2151_62645d95:



    voice "voice/a21/5100120a01.opus"
    mx "\"Oh, suena bien. Tomemos una selfie, los tres.\""


translate english a2151_2f2469e4:


    xy "\"Nah, paso. Yo seré el camarógrafo.\""


translate english a2151_0b97055b:


    voice "voice/a21/5100130a01.opus"



translate english a2151_204571f3:


    bm "\"No.\" \"No.\""


translate english a2151_076699c1:



    voice "voice/a21/5100150a02.opus"
    aoi "\"...¿Bip bip?\""


translate english a2151_afdc372f:



    voice "voice/a21/5100160a01.opus"
    mx "\"Parece que estamos de acuerdo.\""


translate english a2151_8025f15c:


    xy "\"Haah... Bien, como sea.\""


translate english a2151_c01c9ba7:


    "Si ambas están decididas a esto, entonces no hay forma de discutirlo."


translate english a2151_05b29209:



    voice "voice/a21/5100170a01.opus"
    mx "\"Oh, ¿tienes cámara frontal?\""


translate english a2151_e5d7ec4a:



    voice "voice/a21/5100180a02.opus"
    aoi "\"Sí.\""


translate english a2151_5953614a:



    voice "voice/a21/5100190a01.opus"
    mx "\"Un poco apretado, ¿eh?\""


translate english a2151_2257d560:



    voice "voice/a21/5100200a02.opus"
    aoi "\"Mi brazo es muy corto...\""


translate english a2151_b3268e36:



    voice "voice/a21/5100210a01.opus"
    mx "\"¡Shinichi, acércate!\""


translate english a2151_efe8ac39:


    xy "\"No sé si puedo...\""


translate english a2151_9f8ef240:


    "Miyuki se aprieta contra mí para salir en la foto, y vaya que es suave..."


translate english a2151_b5ced884:


    "Extremadamente... suave..."


translate english a2151_489136a9:



    voice "voice/a21/5100220a02.opus"
    aoi "\"Shinichi, estás muy rígido.\""


translate english a2151_4c087e33:


    "Dímelo a mí."


translate english a2151_d22af78f:



    voice "voice/a21/5100230a01.opus"
    mx "\"Hmm... Esto debería funcionar, ¿sí?\""


translate english a2151_ca4938fd:


    xy "\"Por favor, apúrate...\""


translate english a2151_ef357777:



    voice "voice/a21/5100240a02.opus"
    aoi "\"Ok.\""


translate english a2151_422c88b6:



    voice "voice/a21/5100250a02.opus"
    aoi "\"Tres...\""


translate english a2151_1adb76fe:



    voice "voice/a21/5100260a02.opus"
    aoi "\"Dos...\""


translate english a2151_d605b4b9:



    voice "voice/a21/5100270a02.opus"
    aoi "\"Uno...\""


translate english a2151_eb50119f:



    voice "voice/a21/5100280a02.opus"
    aoi "\"Listo.\""


translate english a2151_89977bed:



    voice "voice/a21/5100290a01.opus"
    mx "\"Déjame ver...\""


translate english a2151_7e86d218:



    voice "voice/a21/5100300a01.opus"
    mx "\"¡Bien! Nada mal.\""


translate english a2151_cd1444a1:


    xy "\"Aunque se nota que me aplastaron entre ustedes dos...\""


translate english a2151_5c6d76cb:


    xy "\"...Espera, ¿qué demonios?\""


translate english a2151_5ca80aa6:


    xy "\"¿Aoi está de verdad SONRIENDO en esta foto?\""


translate english a2151_da7f5d7e:



    voice "voice/a21/5100310a01.opus"
    mx "\"Oh... Tienes toda la razón. Lo está.\""


translate english a2151_7223355e:



    voice "voice/a21/5100320a02.opus"
    aoi "\"¿Sonriendo...?\""


translate english a2151_c1851795:


    xy "\"¿Ves? Mira tu boca aquí. Eso tiene que ser una sonrisa.\""


translate english a2151_0a5c1df7:



    voice "voice/a21/5100330a02.opus"
    aoi "\"¿Cómo pasó eso?\""


translate english a2151_af262680:



    voice "voice/a21/5100340a01.opus"
    mx "\"¿Probablemente porque te sentiste feliz?\""


translate english a2151_9c993e37:



    voice "voice/a21/5100350a02.opus"
    aoi "\"...¿Feliz?\""


translate english a2151_64bcdee0:



    voice "voice/a21/5100360a02.opus"
    aoi "\"¿Aoi... se sintió feliz...?\""


translate english a2151_f4600426:


    "Aoi murmura para sí misma, contemplando el concepto."


translate english a2151_b24238d5:


    "Mirando esta foto, se siente como si por fin empezara a salir de su mundo y entrar al nuestro... y su sonrisa es contagiosa."


translate english a2151_b20f2293:



    voice "voice/a21/5100370a01.opus"
    mx "\"Hey, ¿Aoi? ¿Podrías enviarle esta foto a mi teléfono?\""


translate english a2151_fdc8f115:



    voice "voice/a21/5100380a01.opus"
    mx "\"Oh, espera, todavía no te he dicho mi correo, ¿verdad? Bueno, ya que estamos, te daré mi número y—\""


translate english a2151_bb768f2e:



    voice "voice/a21/5100390a02.opus"
    aoi "\"¿¡Correo!?\""


translate english a2151_d5d4f750:



    voice "voice/a21/5100400a02.opus"
    aoi "\"¡Intercambiemos!\""


translate english a2151_11e8cbfd:



    voice "voice/a21/5100410a01.opus"
    mx "\"Claro.\""


translate english a2151_dca00d48:



    voice "voice/a21/5100420a01.opus"
    mx "\"Ok, ahora tú dame el tuyo.\""


translate english a2151_c6e41fe5:



    voice "voice/a21/5100430a01.opus"
    mx "\"Ahí, listo.\""


translate english a2151_f2e0da5e:



    voice "voice/a21/5100440a02.opus"
    aoi "\"¡Entendido!\""


translate english a2151_14ac8361:



    voice "voice/a21/5100450a02.opus"
    aoi "\"¿Miyuki?\""


translate english a2151_5521538d:



    voice "voice/a21/5100460a02.opus"
    aoi "\"¿Esto nos hace... amigas?\""


translate english a2151_ef328f16:



    voice "voice/a21/5100470a01.opus"
    mx "\"¿Hm?\""


translate english a2151_2dd691e2:


    xy "\"Ah, sí, sobre eso...\""


translate english a2151_58e98898:


    xy "\"Para Aoi, intercambiar correos es una especie de... símbolo de amistad, por así decirlo...\""


translate english a2151_972cbc4b:



    voice "voice/a21/5100480a01.opus"
    mx "\"Ohhh... Así que por eso estaba tan ansiosa por hacerlo.\""


translate english a2151_36d0e34b:


    xy "\"Exacto.\""


translate english a2151_0d9b7980:


    "Los dos compartimos una risita."


translate english a2151_a749a057:



    voice "voice/a21/5100490a02.opus"
    aoi "\"¿No somos... amigas?\""


translate english a2151_6c429052:


    "Aoi pregunta con voz queda."


translate english a2151_1bb6db1b:


    "Miyuki se inclina."


translate english a2151_9bb2f14f:



    voice "voice/a21/5100500a01.opus"
    mx "\"Hemos sido amigas todo este tiempo, tonta.\""


translate english a2151_d09383d4:



    voice "voice/a21/5100510a02.opus"
    aoi "\"¡Oh!\""


translate english a2151_82e25f58:


    "Y así, el rostro de Aoi se ilumina con otra de esas sonrisas contagiosas."


translate english a2151_2b664261:



    voice "voice/a21/5100520a01.opus"
    mx "\"Ahora entonces, hazme una llamada de prueba.\""


translate english a2151_e95a820b:



    voice "voice/a21/5100530a02.opus"
    aoi "\"Bip bip...\""


translate english a2151_913a62a7:



    voice "voice/a21/5100540a02.opus"
    aoi "\"Llamando ahora.\""


translate english a2151_bcb5091c:


    "Pasa un momento de silencio."


translate english a2151_158f5d07:



    voice "voice/a21/5100550a01.opus"
    mx "\"\"\"......\"\"\""


translate english a2151_84a89075:



    voice "voice/a21/5100560a01.opus"
    mx "\"Aparentemente... no me está llegando la llamada.\""


translate english a2151_c5a7287d:



    voice "voice/a21/5100570a02.opus"
    aoi "\"¿Bip bip...?\""


translate english a2151_2323b4f9:



    voice "voice/a21/5100580a01.opus"
    mx "\"Pero tengo todas las barras... Shinichi, ¿podrías intentar llamarme?\""


translate english a2151_616d966b:


    xy "\"¿Qué? Si ni siquiera tengo tu número.\""


translate english a2151_b75fc209:



    voice "voice/a21/5100590a01.opus"
    mx "\"¿Qué, en serio?\""


translate english a2151_fa98f95a:



    voice "voice/a21/5100600a01.opus"
    mx "\"Ok entonces, ya que estamos, aquí tienes.\""


translate english a2151_14ea5d4a:


    xy "\"¿Eh...?\""


translate english a2151_7a18f72d:


    "Miyuki me empuja su teléfono, sin que se lo pida."


translate english a2151_7db59252:


    xy "\"Ehh... ¿Qué se supone que haga con esto?\""


translate english a2151_e27a690f:



    voice "voice/a21/5100610a01.opus"
    mx "\"No tienes mi correo, ¿verdad? Intercambiemos.\""


translate english a2151_edb7bf9e:


    xy "\"¿Qué? Está bien... No tenemos que...\""


translate english a2151_c154a167:



    voice "voice/a21/5100620a02.opus"
    aoi "\"Pero...\""


translate english a2151_39bab604:



    voice "voice/a21/5100630a02.opus"
    aoi "\"Shinichi y Miyuki y Aoi... Todos somos amigos.\""


translate english a2151_8a0298d6:



    voice "voice/a21/5100640a02.opus"
    aoi "\"¿Verdad?\""


translate english a2151_280ef53d:



    voice "voice/a21/5100650a01.opus"
    mx "\"...Ya oíste a la mujer.\""


translate english a2151_220d51b5:


    xy "\"Haah... Bien, como sea.\""


translate english a2151_4d40fb26:


    "Suspirando fuerte, abro mi agenda."


translate english a2151_6f307614:


    "Y así, su número queda grabado en la memoria de mi teléfono."


translate english a2151_785b5183:


    "Como prueba, le hago una llamada rápida."


translate english a2151_9c783a1b:


    xy "\"...Es un tono de llamada bastante femenino.\""


translate english a2151_cc39c30d:



    voice "voice/a21/5100660a01.opus"
    mx "\"¡¿Y-Y qué si lo es?!\""


translate english a2151_665e9158:


    "Miyuki se pone roja como un tomate."


translate english a2151_e9b9b18e:



    voice "voice/a21/5100670a01.opus"
    mx "\"¡En fin, sigamos! Con esto, hemos confirmado que mi número sí funciona.\""


translate english a2151_6bf7ac27:


    xy "\"En cuyo caso, probablemente sea—\""


translate english a2151_cfed4e7c:



    voice "voice/a21/5100680a02.opus"
    aoi "\"¡Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...!\""


translate english a2151_626346bc:



    voice "voice/a21/5100690a02.opus"
    aoi "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip... ¡Bip bip...!\""


translate english a2151_9ae50849:


    "Aoi niega con la cabeza con tristeza."


translate english a2151_d01ab1ff:



    voice "voice/a21/5100700a02.opus"
    aoi "\"Aún sin señal...\""


translate english a2151_4869887c:


    xy "\"...Sí, me imaginaba que era eso.\""


translate english a2151_3df0e9c6:



    voice "voice/a21/5100710a02.opus"
    aoi "\"Justo cuando por fin nos hicimos amigas de verdad...\""


translate english a2151_8c3a39b3:



    voice "voice/a21/5100720a02.opus"
    aoi "\"Si Dios no contesta el teléfono, entonces Aoi no puede guardar...\""



translate english a2151_28ea4d75:



    voice "voice/a21/5100730a01.opus"
    mx "\"¿Guardar qué?\""


translate english a2151_7d642bf7:


    "...Ahí va otra vez su cerebro gamer."


translate english a2151_a0537f40:


    "Aunque, si esto de verdad fuera un juego, no la culparía por querer guardar la partida aquí e inmortalizar el nacimiento de nuestra amistad."


translate english a2151_805ec022:



    voice "voice/a21/5100740a01.opus"
    mx "\"Tus llamadas nunca parecen entrar... ¿Quizás la señal es débil aquí arriba?\""


translate english a2151_18978567:



    voice "voice/a21/5100750a02.opus"
    aoi "\"Definitivamente no es eso.\""


translate english a2151_ce7b6461:



    voice "voice/a21/5100760a02.opus"
    aoi "\"La escuela es el punto de partida del universo.\""


translate english a2151_e2d188a6:



    voice "voice/a21/5100770a02.opus"
    aoi "\"Y este es el punto central de la escuela.\""


translate english a2151_008582a2:



    voice "voice/a21/5100780a02.opus"
    aoi "\"Así que este es el centro del universo.\""


translate english a2151_8a7e0383:


    xy "\"Hmm... Esto debería funcionar, ¿sí?\""


translate english a2151_08613a9f:


    "La mayoría probablemente se reiría y lo tomaría como locura."


translate english a2151_02a9bd99:


    "Demonios, yo era uno de ellos hasta hace poco."


translate english a2151_469c5919:


    "Pero ahora... he empezado a pensar que quizá tiene razón."


translate english a2151_64a40a2f:


    "Y al parecer Miyuki ha estado pensando lo mismo."


translate english a2151_e8f7cb59:



    voice "voice/a21/5100790a01.opus"
    mx "\"...Bueno, ciertamente lo parece.\""


translate english a2151_fdedc8d8:



    voice "voice/a21/5100800a02.opus"
    aoi "\"Es verdad.\""


translate english a2151_aa46e297:



    voice "voice/a21/5100810a02.opus"
    aoi "\"Todo empieza aquí.\""


translate english a2151_1e69937b:



    voice "voice/a21/5100820a02.opus"
    aoi "\"Y luego, eventualmente, termina aquí.\""


translate english a2151_93272044:



    voice "voice/a21/5100830a01.opus"
    mx "\"¿Más tonterías de videojuego?\""


translate english a2151_ded171f3:



    voice "voice/a21/5100840a02.opus"
    aoi "\"No, esto es sobre Dios.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
