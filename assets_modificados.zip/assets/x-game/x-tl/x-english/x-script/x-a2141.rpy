

translate english a2141_9cd44544:



    voice "voice/a21/4100010a02.opus"
    aoi "\"Buenos días, Miyuki.\""


translate english a2141_a3509cfd:



    voice "voice/a21/4100020a01.opus"
    mx "\"Buenos días, emm... A—\""


translate english a2141_fdcf2179:



    voice "voice/a21/4100030a01.opus"
    mx "\"—¡Aoi!\""


translate english a2141_86a2b17b:



    voice "voice/a21/4100040b01.opus"
    xtl "\"Parece que esas dos se llevan de maravilla, ¿eh?\""


translate english a2141_2d3f8315:


    xy "\"Síp.\""


translate english a2141_42ebe8fe:


    "Desde que Miyuki y Aoi empezaron a almorzar juntas, el ambiente del salón empezó a cambiar."


translate english a2141_f4ba6972:


    "Sus conversaciones ya no llaman la atención. Además, Aoi ha logrado tener algunas conversaciones con otras personas también."


translate english a2141_e53aff91:


    "Todo gracias a la benevolente Reina Miyuki."


translate english a2141_4444540e:


    xy "\"Eso me recuerda. ¿Cómo te fue con tu herma—{nw}"



translate english a2141_15db43c2:


    extend "¡Vaya!\""



translate english a2141_1d88138a:


    "Miro hacia Yuutarou y retrocedo de inmediato."


translate english a2141_6cabf2cc:


    "¡Está cubierto de golpes y moretones!"


translate english a2141_7be12260:


    xy "\"¡¿Qué te pasó?!\""


translate english a2141_45819f46:



    voice "voice/a21/4100050b01.opus"
    xtl "\"Es una larga historia, pero...\""


translate english a2141_1ad46e0e:



    voice "voice/a21/4100060b01.opus"
    xtl "\"Nuestros padres se enteraron del pasatiempo secreto de Ryuujirou.\""


translate english a2141_1b39db70:


    xy "\"¡No puede ser! ¿En serio?\""


translate english a2141_56e73139:



    voice "voice/a21/4100070b01.opus"
    xtl "\"Tenía permiso de los viejos para conseguir su propio lugar... Dijo que necesitaba un vestidor para su trabajo de modelo...\""


translate english a2141_5a9c5518:



    voice "voice/a21/4100080b01.opus"
    xtl "\"Pero estaba escondiendo una puta tonelada de cosas nerd ahí.\""


translate english a2141_5495d4cc:


    xy "\"¿Qué? Pero tu papá es—\""


translate english a2141_0bc069f8:



    voice "voice/a21/4100090b01.opus"
    xtl "\"Síp, es un autoritario de mierda. Así que naturalmente se volvió loco.\""


translate english a2141_7bedf721:



    voice "voice/a21/4100100b01.opus"
    xtl "\"En serio, prácticamente estaba listo para prenderle fuego al lugar.\""


translate english a2141_702c1118:


    xy "\"Y totalmente puedo imaginarlo haciéndolo.\""


translate english a2141_46552b97:



    voice "voice/a21/4100110b01.opus"
    xtl "\"Pero por alguna razón, su actitud de verdad me hizo enojar. Y ese fue el momento en que me di cuenta.\""


translate english a2141_2f96fcf1:



    voice "voice/a21/4100120b01.opus"
    xtl "\"El pasatiempo de crossplay de mi hermano significa el mundo para él— de la misma forma que yo siento por el Club BD.\""


translate english a2141_54abd554:



    voice "voice/a21/4100130b01.opus"
    xtl "\"Así que salté a defenderlo. Pensé que era lo correcto.\""


translate english a2141_2cb730fe:



    voice "voice/a21/4100140b01.opus"
    xtl "\"Me dije que no me importa si el mundo entero lo juzga por eso. Si este es su sueño, entonces quiero apoyarlo.\""


translate english a2141_24ab2266:



    voice "voice/a21/4100150b01.opus"
    xtl "\"Y luego la pelea se volvió física.\""


translate english a2141_c20dcadb:


    xy "\"Demonios... Eso suena como el infierno.\""


translate english a2141_903ed6f2:



    voice "voice/a21/4100160b01.opus"
    xtl "\"Pero gracias a eso, finalmente entiendo de dónde viene Ryuujirou.\""


translate english a2141_27bb046a:



    voice "voice/a21/4100170b01.opus"
    xtl "\"¡La lluvia se fue y puedo ver con claridad, o como sea la canción!\""


translate english a2141_7448b269:


    "Yuutarou sonríe radiante a pesar de la hinchazón."


translate english a2141_6325460d:


    "El tipo normalmente es un completo idiota, pero hoy me parece que es algo rudo..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
