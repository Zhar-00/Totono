

translate english a2141_9cd44544:



    voice "voice/a21/4100010a02.opus"
    aoi "\"Morning, Miyuki.\""


translate english a2141_a3509cfd:



    voice "voice/a21/4100020a01.opus"
    mx "\"Good morning, um... A—\""


translate english a2141_fdcf2179:



    voice "voice/a21/4100030a01.opus"
    mx "\"—Aoi!\""


translate english a2141_86a2b17b:



    voice "voice/a21/4100040b01.opus"
    xtl "\"Seems like those two have totally hit it off, huh?\""


translate english a2141_2d3f8315:


    xy "\"Yep.\""


translate english a2141_42ebe8fe:


    "Desde que Miyuki y Aoi empezaron a almorzar juntas, el ambiente del salón empezó a cambiar."


translate english a2141_f4ba6972:


    "Sus conversaciones ya no llaman la atención. Además, Aoi ha logrado tener algunas conversaciones con otras personas también."


translate english a2141_e53aff91:


    "Todo gracias a la benevolente Reina Miyuki."


translate english a2141_4444540e:


    xy "\"That reminds me. How'd it go with your broth—{nw}"



translate english a2141_15db43c2:


    extend "¡Vaya!\""



translate english a2141_1d88138a:


    "Miro hacia Yuutarou y retrocedo de inmediato."


translate english a2141_6cabf2cc:


    "¡Está cubierto de golpes y moretones!"


translate english a2141_7be12260:


    xy "\"What happened to you?!\""


translate english a2141_45819f46:



    voice "voice/a21/4100050b01.opus"
    xtl "\"It's a long story, but...\""


translate english a2141_1ad46e0e:



    voice "voice/a21/4100060b01.opus"
    xtl "\"Our parents found out about Ryuujirou's secret hobby.\""


translate english a2141_1b39db70:


    xy "\"No way! For real?\""


translate english a2141_56e73139:



    voice "voice/a21/4100070b01.opus"
    xtl "\"He had permission from the folks to get his own place... Said he needed a dressing room for his modeling gig...\""


translate english a2141_5a9c5518:



    voice "voice/a21/4100080b01.opus"
    xtl "\"But he was hiding a metric fuckton of nerdy shit there.\""


translate english a2141_5495d4cc:


    xy "\"What? But your dad's—\""


translate english a2141_0bc069f8:



    voice "voice/a21/4100090b01.opus"
    xtl "\"Yep, he's an authoritarian hardass. So naturally he flipped his shit.\""


translate english a2141_7bedf721:



    voice "voice/a21/4100100b01.opus"
    xtl "\"Seriously, he was practically ready to set fire to the place.\""


translate english a2141_702c1118:


    xy "\"I can totally see him doing it, too.\""


translate english a2141_46552b97:



    voice "voice/a21/4100110b01.opus"
    xtl "\"But for some reason, his attitude really set me off. And that was the moment I realized.\""


translate english a2141_2f96fcf1:



    voice "voice/a21/4100120b01.opus"
    xtl "\"My brother's crossplay hobby means the world to him—the same way I feel about the BD Club.\""


translate english a2141_54abd554:



    voice "voice/a21/4100130b01.opus"
    xtl "\"So I jumped to his defense. Figured it was the right thing to do.\""


translate english a2141_2cb730fe:



    voice "voice/a21/4100140b01.opus"
    xtl "\"Told myself I don't care if the whole world judges him for it. If this is his dream, then I want to support that.\""


translate english a2141_24ab2266:



    voice "voice/a21/4100150b01.opus"
    xtl "\"And then the fight got physical.\""


translate english a2141_c20dcadb:


    xy "\"Damn... That sounds like hell.\""


translate english a2141_903ed6f2:



    voice "voice/a21/4100160b01.opus"
    xtl "\"But thanks to that, I finally get where Ryuujirou's coming from.\""


translate english a2141_27bb046a:



    voice "voice/a21/4100170b01.opus"
    xtl "\"The rain's gone and I can see clearly, or however the song goes!\""


translate english a2141_7448b269:


    "Yuutarou sonríe radiante a pesar de la hinchazón."


translate english a2141_6325460d:


    "El tipo normalmente es un completo idiota, pero hoy me parece que es algo rudo..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
