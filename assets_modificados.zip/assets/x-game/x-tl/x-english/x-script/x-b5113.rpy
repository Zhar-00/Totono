

translate english b5113_989e04cf:



    voice "voice/b51/1300010b01.opus"
    xtl "\"Ah...! Speak of the angel, and she appears!\""


translate english b5113_9317a01b:



    voice "voice/b51/1300020a01.opus"
    mx "\"Good morning!\""


translate english b5113_11c35584:



    voice "voice/b51/1300030b01.opus"
    xtl "\"Good morning indeed!\""


translate english b5113_65f5b6cb:


    "Como de costumbre, Yuutarou saluda a Miyuki con entusiasmo."


translate english b5113_63d700ae:



    voice "voice/b51/1300040a01.opus"
    mx "\"......\""


translate english b5113_a51e3129:


    "Debe sentirse muy incómoda."


translate english b5113_defc4b76:


    "Yo sé que definitivamente lo estoy."


translate english b5113_b77994c1:


    "Los dos tomamos nuestros asientos sin hacer contacto visual."


translate english b5113_466d4ba7:


    "Desvío la mirada y encuentro—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
