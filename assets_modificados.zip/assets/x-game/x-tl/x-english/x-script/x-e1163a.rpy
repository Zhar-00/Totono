

translate english e1163a_5ad95c29:


    "Miyuki y yo hemos estado viviendo juntos, pero definitivamente no recuerdo haber ido nunca al hospital."


translate english e1163a_e1117db3:


    "Y Yuutarou tiende a contar historias locas en la escuela..."


translate english e1163a_0558da0f:


    "¿Quizá sus recuerdos están todos revueltos ahora mismo?"


translate english e1163a_d9f2f70d:


    "Estoy empezando a pensar que lo de "Aoi está en mi casa" también es un montón de tonterías..."



translate english e1163a_41492168:


    "O sea, Aoi es un personaje ficticio..."


translate english e1163a_8cd14497:



    voice "voice/e11/63a00010b01.opus"
    xtl "\"¿Qué pasa, Shinichi?\""


translate english e1163a_a8050306:


    xy "\"¿Eh? Oh... No es nada.\""


translate english e1163a_cf35fd8b:


    "Perplejo, lo sigo a regañadientes."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
