

translate english e1155c_b4704e91:



    voice "voice/e11/55c00010a01.opus"
    mx "\"Come on, don't be like that...\""


translate english e1155c_fec89ecc:



    voice "voice/e11/55c00020a01.opus"
    mx "Solo... ¡BÉSAME...!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
