

translate english a1121_8ae7334d:


    "Durante la clase..."


translate english a1121_5301a3ff:


    "Usando mi libro de texto como cobertura, saco sigilosamente el teléfono del hermano de Yuutarou y abro el juego."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
