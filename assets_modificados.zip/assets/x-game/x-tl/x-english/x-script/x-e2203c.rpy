

translate english e2203c_e561312c:


    "Por curiosidad, abro su agenda."


translate english e2203c_0e671413:


    xy "\"......What the?\""


translate english e2203c_fe53d6ee:


    "Debí tocar lo que no era... Déjame intentarlo otra vez..."


translate english e2203c_79444ad6:


    "No. No importa cuántas veces la vuelva a abrir, solo hay una entrada:"


translate english e2203c_447f93cb:


    "\"God.\""



translate english e2203c_df652c0f:


    xy "\"What is this, a burner phone for God...?\""


translate english e2203c_f59318e9:


    "O sea, sé que Miyuki tiene dos teléfonos, así que tiene sentido que reserve uno exclusivamente para juegos móviles o para llamadas, pero..."


translate english strings:


    old "Сделать телефонный звонок"
    new "Hacer una llamada"


    old "Не важно"
    new "Déjalo"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
