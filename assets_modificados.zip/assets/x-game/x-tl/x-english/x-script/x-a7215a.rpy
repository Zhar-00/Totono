

translate english a7215a_9c380dc6:



    voice "voice/a72/15a00010a01.opus"
    mx "\"¡Aah... nn... nnn... nnggghh...! Jaah... jaah... jaah... nnn...\""


translate english a7215a_6e2e5366:



    voice "voice/a72/15a00020a01.opus"
    mx "\"Te estás viniendo... tanto... Te puedo sentir... palpitando...\""


translate english a7215a_863b10af:


    "La concha de Miyuki se aprieta fuerte alrededor de mi miembro, exprimiendo hasta la última gota de semen."


translate english a7215a_2c69d151:


    "Mi verga empieza a ablandarse, y lentamente salgo de ella."


translate english a7215a_6e2473c4:



    voice "voice/a72/15a00030a01.opus"
    mx "\"¡Aah! ¡No! Se va a derramar... ¡Aaahh!\""


translate english a7215a_cb2f78d5:


    xy "\"...De verdad disfrutas estar llena de mi esperma, ¿eh?\""


translate english a7215a_350f2590:



    voice "voice/a72/15a00040a01.opus"
    mx "\"¿Qu...? ¡Aah!\""


translate english a7215a_1a0c297c:



    voice "voice/a72/15a00050a01.opus"
    mx "\"No... No es que lo \"disfrute\" ni nada de eso...\""


translate english a7215a_20d3c81f:



    voice "voice/a72/15a00060a01.opus"
    mx "\"Es solo... un recuerdo de nuestro acto de amor.\""


translate english a7215a_f5e80134:


    xy "\"Oh... C-Cierto.\""


translate english a7215a_d03c0171:


    "Eso es muy dulce... estoy sonrojado..."


translate english a7215a_5c108518:


    "Es cierto: Miyuki y yo por fin consumamos nuestro amor."


translate english a7215a_d04d7461:


    "El semen teñido de escarlata que fluye de ella es prueba suficiente."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
