

translate english e1123c_76e45841:



    voice "voice/e11/23c00010a01.opus"
    mx "\"...That was the question I posed to you.\""


translate english e1123c_59dadc62:



    voice "voice/e11/23c00020a01.opus"
    mx "\"But you gave me a completely contradictory answer.\""


translate english e1123c_2bcf294a:



    voice "voice/e11/23c00030a01.opus"
    mx "\"You remember that, don't you?\""


translate english e1123c_81f7404d:


    xy "\"Do I...?\""


translate english e1123c_9fcc92a5:


    "¿De qué demonios está hablando?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
