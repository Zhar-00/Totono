

translate english e1123c_76e45841:



    voice "voice/e11/23c00010a01.opus"
    mx "\"...Esa fue la pregunta que te planteé.\""


translate english e1123c_59dadc62:



    voice "voice/e11/23c00020a01.opus"
    mx "\"Pero me diste una respuesta completamente contradictoria.\""


translate english e1123c_2bcf294a:



    voice "voice/e11/23c00030a01.opus"
    mx "\"Lo recuerdas, ¿verdad?\""


translate english e1123c_81f7404d:


    xy "\"¿Yo...?\""


translate english e1123c_9fcc92a5:


    "¿De qué demonios está hablando?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
