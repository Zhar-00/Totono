

translate english e2154b_e1b362d5:


    xy "\"If it was a friend or something, nah, not really.\""


translate english e2154b_c9c1a633:



    voice "voice/e21/54b00010a01.opus"
    mx "\"Well, I wouldn't like it.\""


translate english e2154b_2b447425:


    "Declara Miyuki con tono plano."


translate english e2154b_7a89d86a:



    voice "voice/e21/54b00020a01.opus"
    mx "\"I prefer it when it's just us.\""


translate english e2154b_4bc8df50:



    voice "voice/e21/54b00030a01.opus"
    mx "\"And I won't let anyone else ruin that.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
