

translate english e2154b_e1b362d5:


    xy "\"Si fuera un amigo o algo así, no, no tanto.\""


translate english e2154b_c9c1a633:



    voice "voice/e21/54b00010a01.opus"
    mx "\"Bueno, a mí no me gustaría.\""


translate english e2154b_2b447425:


    "Declara Miyuki con tono plano."


translate english e2154b_7a89d86a:



    voice "voice/e21/54b00020a01.opus"
    mx "\"Prefiero cuando somos solo nosotros.\""


translate english e2154b_4bc8df50:



    voice "voice/e21/54b00030a01.opus"
    mx "\"Y no dejaré que nadie más arruine eso.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
