

translate english e2224a_027560b0:



    voice "voice/e22/24a00010a01.opus"
    mx "\"¡Aquí tienes!\""


translate english e2224a_420f666a:


    xy "\"...¿Eh?\""


translate english e2224a_77528578:


    "Me entrega un mini póster plastificado."


translate english e2224a_a3386ab4:


    "Y en efecto, la muestra con un atuendo de sirvienta... Es tan surrealista que no puedo dejar de mirarlo..."


translate english e2224a_6e8d1075:



    voice "voice/e22/24a00020a01.opus"
    mx "\"¿Y bien...? ¿Qué opinas?\""


translate english e2224a_a120d407:


    xy "\"Te ves adorable.\""


translate english e2224a_1868f09e:



    voice "voice/e22/24a00030a01.opus"
    mx "\"Oh... Genial. Gracias.\""


translate english e2224a_46ffe097:


    xy "\"Muy, muy adorable... pero...\""


translate english e2224a_2f6a0cdc:


    xy "\"¿Qué quieres que haga con esto, exactamente?\""


translate english e2224a_09f431b9:



    voice "voice/e22/24a00040a01.opus"
    mx "\"¡Es tu regalo, tonto!\""


translate english e2224a_94dc01d6:


    xy "\"Digo, lo agradezco... de verdad... ¡¿Pero dónde está el disfraz en sí?!\""


translate english e2224a_d4881119:



    voice "voice/e22/24a00050a01.opus"
    mx "\"En el clóset de allá.\""


translate english e2224a_4388b8c2:


    xy "\"Vale.\""


translate english e2224a_e4c8ed10:


    xy "\"Ve a ponértelo.\""


translate english e2224a_e0d2f5db:



    voice "voice/e22/24a00060a01.opus"
    mx "\"¿Qué? ¡No!\""


translate english e2224a_7439ae7d:


    xy "\"¡¿Cómo que no?!\""


translate english e2224a_6fcd34ed:



    voice "voice/e22/24a00070a01.opus"
    mx "\"Pues... ¡Es demasiado degradante!\""


translate english e2224a_53b55084:


    xy "\"¡¿Entonces por qué lo compraste?! ¡¿Y por qué te tomaste esta foto?!\""


translate english e2224a_798cabcc:



    voice "voice/e22/24a00080a01.opus"
    mx "\"Porque el dueño de la tienda me rogó que lo hiciera... Incluso me dieron un descuento en el disfraz...\""


translate english e2224a_7212cfeb:


    xy "\"¿Se... Se quedaron con una copia de esta foto...?\""


translate english e2224a_bcaa0223:


    "Miyuki asiente, sonrojada hasta las orejas."


translate english e2224a_66b803a7:



    voice "voice/e22/24a00100a01.opus"
    mx "\"¡M-Mira, ¿sí?!\""


translate english e2224a_47bc3979:



    voice "voice/e22/24a00110a01.opus"
    mx "\"S-Si de verdad te va a hacer feliz... Te advierto, no me veo tan bien con él y es muy vergonzoso, ¡pero estoy dispuesto a intentarlo!\""


translate english e2224a_63db30c1:



    voice "voice/e22/24a00120a01.opus"
    mx "\"Así que... si TÚ demuestras que me amas... si TÚ me convences de que TUS sentimientos son de verdad... lo usaré para TI.\""


translate english e2224a_dee7aafa:


    xy "\"¿D-De verdad?\""


translate english e2224a_04434161:



    voice "voice/e22/24a00130a01.opus"
    mx "\"En tu próximo cumpleaños, lo prometo—\""


translate english e2224a_ea1aaa09:


    xy "\"...¿Mi próximo cumpleaños?\""


translate english e2224a_871f5ab9:


    xy "\"¡Eso está demasiado lejos!\""


translate english e2224a_3c52409b:



    voice "voice/e22/24a00140a01.opus"
    mx "\"No, no lo está. Llegará antes de que te des cuenta.\""


translate english e2224a_17622773:


    "Ehh... que yo sepa, solo tenemos un cumpleaños por año..."


translate english e2224a_999816b0:



    voice "voice/e22/24a00150a01.opus"
    mx "\"Hasta entonces, solo haz tu mejor esfuerzo para convencerme, ¿sí?\""


translate english e2224a_6cd8f303:


    "Una vez que pone su sonrisa de profesional, no sirve de nada discutir..."



translate english e2224a_5bdbd9cf:



    voice "voice/e22/24a00090a01.opus"
    mx "\"......\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
