

translate english e2224a_027560b0:



    voice "voice/e22/24a00010a01.opus"
    mx "\"Here you go!\""


translate english e2224a_420f666a:


    xy "\"...Huh?\""


translate english e2224a_77528578:


    "Me entrega un mini póster plastificado."


translate english e2224a_a3386ab4:


    "Y en efecto, la muestra con un atuendo de sirvienta... Es tan surrealista que no puedo dejar de mirarlo..."


translate english e2224a_6e8d1075:



    voice "voice/e22/24a00020a01.opus"
    mx "\"Well...? What do you think?\""


translate english e2224a_a120d407:


    xy "\"You look adorable.\""


translate english e2224a_1868f09e:



    voice "voice/e22/24a00030a01.opus"
    mx "\"Oh... Cool. Thanks.\""


translate english e2224a_46ffe097:


    xy "\"Really, really adorable... but...\""


translate english e2224a_2f6a0cdc:


    xy "\"What do you want me to do with this, exactly?\""


translate english e2224a_09f431b9:



    voice "voice/e22/24a00040a01.opus"
    mx "\"It's your present, silly!\""


translate english e2224a_94dc01d6:


    xy "\"I mean, I appreciate it... I really do... But where's the actual costume?!\""


translate english e2224a_d4881119:



    voice "voice/e22/24a00050a01.opus"
    mx "\"In the closet over there.\""


translate english e2224a_4388b8c2:


    xy "\"Okay.\""


translate english e2224a_e4c8ed10:


    xy "\"Go put it on.\""


translate english e2224a_e0d2f5db:



    voice "voice/e22/24a00060a01.opus"
    mx "\"What? No!\""


translate english e2224a_7439ae7d:


    xy "\"What do you mean, no?!\""


translate english e2224a_6fcd34ed:



    voice "voice/e22/24a00070a01.opus"
    mx "\"Well... It's too degrading!\""


translate english e2224a_53b55084:


    xy "\"Then why did you buy it?! And why did you have this photo taken?!\""


translate english e2224a_798cabcc:



    voice "voice/e22/24a00080a01.opus"
    mx "\"Because the shop owner begged me to do it... They even gave me a discount on the costume...\""


translate english e2224a_7212cfeb:


    xy "\"Did... Did they keep a copy of this photo...?\""


translate english e2224a_bcaa0223:


    "Miyuki asiente, sonrojada hasta las orejas."


translate english e2224a_66b803a7:



    voice "voice/e22/24a00100a01.opus"
    mx "\"L-Look, okay?!\""


translate english e2224a_47bc3979:



    voice "voice/e22/24a00110a01.opus"
    mx "\"I-If it'll really make you happy... Fair warning, I don't look that good in it, and it's really embarrassing, but I'm willing to try!\""


translate english e2224a_63db30c1:



    voice "voice/e22/24a00120a01.opus"
    mx "\"So... if YOU prove YOU love me... if YOU convince me YOUR feelings are the real deal... I'll wear it for YOU.\""


translate english e2224a_dee7aafa:


    xy "\"R-Really?\""


translate english e2224a_04434161:



    voice "voice/e22/24a00130a01.opus"
    mx "\"On your next birthday, I promise—\""


translate english e2224a_ea1aaa09:


    xy "\"...My next birthday?\""


translate english e2224a_871f5ab9:


    xy "\"That's too far away!\""


translate english e2224a_3c52409b:



    voice "voice/e22/24a00140a01.opus"
    mx "\"No it isn't. It'll be here before you know it.\""


translate english e2224a_17622773:


    "Ehh... que yo sepa, solo tenemos un cumpleaños por año..."


translate english e2224a_999816b0:



    voice "voice/e22/24a00150a01.opus"
    mx "\"Until then, just do your best to convince me, okay?\""


translate english e2224a_6cd8f303:


    "Una vez que pone su sonrisa de profesional, no sirve de nada discutir..."



translate english e2224a_5bdbd9cf:



    voice "voice/e22/24a00090a01.opus"
    mx "\"......\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
