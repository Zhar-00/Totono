

translate english c5173_051c52fa:


    "Son casi las diez."


translate english c5173_f19efaeb:


    "Normalmente estaría preparándome para dormir a esta hora, pero..."


translate english c5173_79d01174:


    xy "\"Oye, Eru.\""


translate english c5173_6ffbb926:


    xy "\"Lo sé, amigo. Yo también tengo hambre.\""


translate english c5173_c0556800:


    "At this point, I've already read Aoi's \"Cat Owner's Manual\"de Aoi de principio a fin. Dos veces."



translate english c5173_32a6b72e:


    "Aburridos, Eru y yo nos sentamos por ahí, esperándola."


translate english c5173_e695083e:


    "Entonces, por decimotercera vez hoy, la oigo subir corriendo las escaleras."


translate english c5173_41b52718:



    voice "voice/c51/7300030a02.opus"
    aoi "\"¿Shinichi?\""


translate english c5173_778131d1:


    "Me llama desde el otro lado de la puerta."


translate english c5173_c5abee38:



    voice "voice/c51/7300040a02.opus"
    aoi "\"¿Qué significa esta palabra? ¿C-U-M-I-N?\""


translate english c5173_9cadefb0:


    xy "\"...Mira, quizá debería simplemente leerte el recetario—\""


translate english c5173_2530022d:



    voice "voice/c51/7300050a02.opus"
    aoi "\"¡No!\""


translate english c5173_283131ad:



    voice "voice/c51/7300060a02.opus"
    aoi "\"¡Aoi no está leyendo un recetario! ¡Es para el examen de vocabulario!\""


translate english c5173_700f3ecf:


    xy "\"...Cierto.\""


translate english c5173_f8ea3152:


    "Suelto un suspiro."


translate english c5173_fb677385:


    "Tiene que estar leyendo ese libro de cocina que compró en la librería."


translate english c5173_1d435a08:


    "Y es un libro realmente básico, de nivel principiante..."


translate english c5173_20a67f04:


    "No tengo idea de cómo se mantiene al día en clase si es tan analfabeta..."


translate english c5173_2074ce27:


    "Pero claramente intenta cocinar para mí... mientras simultáneamente intenta ocultar el hecho de que no sabe leer..."


translate english c5173_77ca36c7:



    voice "voice/c51/7300070a02.opus"
    aoi "\"¿Shinichi?\""


translate english c5173_7132a734:


    xy "\"La palabra que buscas es 'comino'. Es una especia.\""



translate english c5173_cb584df8:



    voice "voice/c51/7300080a02.opus"
    aoi "\"Boop boop... Entendido.\""


translate english c5173_2e4c6d0a:



    voice "voice/c51/7300090a02.opus"
    aoi "\"Una cucharadita de comino... ¡Y una cucharada llena de aceite de oliva!\""


translate english c5173_1a4ab130:


    xy "\"¡CuchaRADA! ¡Siempre lee la receta con cuidado!\""


translate english c5173_9f8382e1:


    "La corrijo rápidamente."


translate english c5173_62e4b19e:


    "De ninguna manera voy a dejar que cometa un error tan básico... No si puedo evitarlo, en todo caso..."


translate english c5173_1668b1d1:


    "Por lo que puedo ver, ya intentó hacer hamburguesas, curry y okonomiyaki, solo para que cada intento terminara en un miserable fracaso."


translate english c5173_ec137309:


    xy "\"¡No lo quemes esta vez, ¿me oyes?! ¡Una vez que prendas el quemador, NI SE TE OCURRA salir de la cocina!\""


translate english c5173_c7f51f4f:



    voice "voice/c51/7300100a02.opus"
    aoi "\"Bien. Esta vez, Aoi no va a salir de la...\""


translate english c5173_c52a5b39:



    voice "voice/c51/7300110a02.opus"
    aoi "\"Salir de la...\""


translate english c5173_b104836d:



    voice "voice/c51/7300120a02.opus"
    aoi "\"¡¡¡AAHHH!!!\""


translate english c5173_0bf455be:


    "Eru se sienta junto a la puerta y gruñe."


translate english c5173_c0d7eadd:


    "Momentos después, huelo algo... quemado."


translate english c5173_72cdd575:



    voice "voice/c51/7300140a02.opus"
    aoi "\"¡¡¡AAAAAAAOHHHHH!!!\""


translate english c5173_49db35f8:


    "Demasiado tarde."


translate english c5173_4aa4d55c:


    xy "\"Dios, estaba en medio de cocinarlo...\""


translate english c5173_9c0fae21:


    xy "\"¿Qué vamos a hacer, Eru?\""


translate english c5173_95b6a6de:


    "Eru mira al suelo."


translate english c5173_15c7859b:


    "Tengo tanta hambre que ya no lo soporto..."


translate english c5173_4e043a72:


    "Recojo a Eru y bajo a la sala de estar."


translate english c5173_58b1aacb:


    "Mientras Eru devora su cena—"


translate english c5173_aa5c174f:



    voice "voice/c51/7300170a02.opus"
    aoi "\"Boop boop...\""


translate english c5173_0accd139:


    xy "\"\"\"Boop\"......\"\"¿Estás llorando?\"\""


translate english c5173_90cf1992:


    "Juntos, miramos en silencio el salteado completamente carbonizado."


translate english c5173_8e790e2d:


    "Está muy, muy quemado—más de la mitad, al menos."


translate english c5173_124f5a14:


    "Quizás pueda aguantar y comerme la otra mitad."


translate english c5173_d75d0ea5:


    "...Que Dios me ayude."


translate english c5173_3f3d950a:



    voice "voice/c51/7300180a02.opus"
    aoi "\"Shinichi...\""



translate english c5173_0432f201:



    voice "voice/c51/7300190a02.opus"
    aoi "\"Esto no se ve muy bien, ¿verda—\""


translate english c5173_984f57ba:


    xy "\"Gracias por la cena.\""


translate english c5173_564df447:



    voice "voice/c51/7300200a02.opus"
    aoi "\"¡Boop boop!\""


translate english c5173_2db6c5e3:


    xy "\"¡Ñam, ñam, ñam!\""


translate english c5173_b188af8e:



    voice "voice/c51/7300210a02.opus"
    aoi "\"Shinichi...\""


translate english c5173_62f0d272:


    xy "\"Nn... nngglp... mmm... ¡Ñam ñam!\""


translate english c5173_164ff7ae:


    xy "\"¡Está genial!\""


translate english c5173_dd1a7ee0:


    xy "\"¿Cómo lo describo? ¡Tiene este sabor tan refinado y amargo que combina bien con todo el aceite de oliva...!\""


translate english c5173_db2627d9:



    voice "voice/c51/7300220a02.opus"
    aoi "\"......¿Estás llorando?\""


translate english c5173_a02f90b8:


    xy "\"¡Oh, estas son lágrimas de felicidad, por supuesto! ¡Soy tan bendecido de comer tu comida casera!\""


translate english c5173_bee159f0:



    voice "voice/c51/7300230a02.opus"
    aoi "\"¡Genial!\""


translate english c5173_435ed23a:


    "Aoi agarra su tenedor y se mete un bocado de salteado en la boca—"


translate english c5173_1461d1eb:


    xy "\"¡Aoi, espera!\""


translate english c5173_336710a3:



    voice "voice/c51/7300240a02.opus"
    aoi "\"¿Boop boop...?\""


translate english c5173_09c24c15:



    voice "voice/c51/7300250a02.opus"
    aoi "\"Boop......\""


translate english c5173_31861ac3:



    voice "voice/c51/7300260a02.opus"
    aoi "\"¡Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...!\""


translate english c5173_1fb1afcd:


    "Con la boca llena de salteado, suelta un pequeño grito ahogado y corre al fregadero."


translate english c5173_7ed6bfe8:


    "Identificable."


translate english c5173_e3a9cd95:


    xy "\"¿Aoi? ¿Estás bien?\""


translate english c5173_8613a291:



    voice "voice/c51/7300270a02.opus"
    aoi "\"Está feo...\""


translate english c5173_0b96386f:


    xy "\"¡N-No es cierto...!\""


translate english c5173_5c7f9d64:



    voice "voice/c51/7300280a02.opus"
    aoi "\"......\""


translate english c5173_bf5d16bd:


    xy "\"O sea, bueno... Quizá no está BUENO...\""


translate english c5173_9de6e593:



    voice "voice/c51/7300290a02.opus"
    aoi "\"Sí...\""


translate english c5173_17ecca66:


    xy "\"Pero créeme cuando digo esto.\""


translate english c5173_e4146366:


    xy "\"De verdad, de verdad me conmueve que te hayas esforzado tanto en prepararlo para mí.\""


translate english c5173_d7a8ed2c:



    voice "voice/c51/7300300a02.opus"
    aoi "\"¿Huh...?\""


translate english c5173_789b1a50:



    voice "voice/c51/7300310a02.opus"
    aoi "\"¿Te... conmovió...?\""


translate english c5173_82b0451f:


    xy "\"Sí. Lo que cuenta es la intención, ¿sabes?\""


translate english c5173_2bdc62f7:


    xy "\"...Aunque igual tendremos que comer algo eventualmente...\""


translate english c5173_71966566:



    voice "voice/c51/7300320a02.opus"
    aoi "\"Sí...\""


translate english c5173_ccefea86:


    xy "\"Bueno, preparemos algo rápido con lo que nos que—\""


translate english c5173_c7d73322:


    "Abro el refrigerador para encontrar—"


translate english c5173_66530e0f:


    "—nada."


translate english c5173_fa185a84:


    "Lo único que hay es nuestra reserva de jugo de tomate de Yabaley."


translate english c5173_6a016a57:



    voice "voice/c51/7300330a02.opus"
    aoi "\"Aoi usó todo...\""


translate english c5173_d8f30276:


    xy "\"Ah... ya veo...\""


translate english c5173_98e8d844:


    "¿Deberíamos ir al supermercado...?"


translate english c5173_47092ec2:


    "No, ya deben estar todos cerrados..."


translate english c5173_b73c3748:


    "Bien, ¿cuáles son nuestras opciones aquí...?"


translate english c5173_918c0f29:



    voice "voice/c51/7300340a02.opus"
    aoi "\"Boop boop...\""


translate english c5173_0bc5b0d3:


    xy "\"Ehh... Espera un segundo.\""


translate english c5173_7363ba9f:


    "Podríamos ir a la tienda de la esquina, pero eso se siente un poco como hacer trampa..."


translate english c5173_8000f46b:


    "Así que en cambio agarro mi teléfono y envío un correo rápido."


translate english c5173_2bfc8255:



    voice "voice/c51/7300350a02.opus"
    aoi "\"¡Gracias por la cena!\""


translate english c5173_0e0e8c21:


    "Aoi se mete un tenedor lleno de pasta en la boca."


translate english c5173_4ed173ad:



    voice "voice/c51/7300360a02.opus"
    aoi "\"Slrrpp... ¡Boop... boop boop!\""


translate english c5173_1e743db0:


    xy "\"¿Qué tal?\""


translate english c5173_c12b99f1:



    voice "voice/c51/7300370a02.opus"
    aoi "\"¡Está increíble!\""


translate english c5173_30c94010:



    voice "voice/c51/7300380a02.opus"
    aoi "\"¡¡¡Es divino!!!\""


translate english c5173_eb4eaf29:


    "Aoi grita emocionada."


translate english c5173_9303e9bc:


    "No es sorpresa. Hice la salsa de pasta con Yabaley's, así que seguro le gustaría."


translate english c5173_2dab61e6:



    voice "voice/c51/7300390a02.opus"
    aoi "\"¿Es una de las recetas de Miyuki?\""


translate english c5173_f84fb05c:


    xy "\"Podrías decirlo.\""


translate english c5173_bbe12ac0:


    "Escribí una lista de todo lo que me quedaba en casa."


translate english c5173_3c72cca1:


    "Luego envié esa lista a Miyuki por correo y le pregunté si había algo que pudiera hacer con ello—y este fue el resultado."


translate english c5173_8933db56:


    "Gracias a Dios que todavía teníamos pasta..."


translate english c5173_6755a478:


    "¡Hasta yo estoy disfrutando esto, y ni siquiera me gustan los tomates normalmente!"


translate english c5173_471b60f5:



    voice "voice/c51/7300400a02.opus"
    aoi "\"Nnn... Miyuki es mejor que Aoi en todo...\""


translate english c5173_50bdca1b:


    xy "\"¿Y? No tienes que compararte con ella.\""


translate english c5173_cfbee38f:



    voice "voice/c51/7300410a02.opus"
    aoi "\"¿De verdad...?\""


translate english c5173_80e5860d:


    xy "\"Tú eres tú, y ella es ella.\""


translate english c5173_9f3f972b:



    voice "voice/c51/7300420a02.opus"
    aoi "\"Boop boop...\""


translate english c5173_f87a65bf:


    "Aoi ladea la cabeza."


translate english c5173_b75846f9:



    voice "voice/c51/7300430a02.opus"
    aoi "\"...Pero Aoi quiere prepararte comida rica.\""


translate english c5173_14bf220d:



    voice "voice/c51/7300440a02.opus"
    aoi "\"Si Aoi no puede lograrlo...\""


translate english c5173_e2284542:



    voice "voice/c51/7300450a02.opus"
    aoi "\"...entonces no podemos casarnos.\""


translate english c5173_11cad308:


    xy "\"¡¿Casarnos?!\""


translate english c5173_85d6f72a:


    "Mi voz sube una octava."


translate english c5173_747b64ea:



    voice "voice/c51/7300460a02.opus"
    aoi "\"¿Es malo?\""


translate english c5173_fadcb5a3:


    xy "\"¿Huh? Pues no—\""


translate english c5173_c8b9c209:



    voice "voice/c51/7300470a02.opus"
    aoi "\"¿Aoi es demasiado rara para casarse?\""


translate english c5173_99bf14cc:


    xy "\"¡No, no es eso! Solo creo que es un poco pronto para estar pensando en—\""


translate english c5173_9910c9a1:



    voice "voice/c51/7300480a02.opus"
    aoi "\"Es tan confuso...\""


translate english c5173_9d51829c:



    voice "voice/c51/7300490a02.opus"
    aoi "\"Aoi se... conmovió tanto...\""


translate english c5173_e3872b36:



    voice "voice/c51/7300500a02.opus"
    aoi "\"...cuando dijiste... que mi comida estaba buena...\""


translate english c5173_276f9e3c:



    voice "voice/c51/7300510a02.opus"
    aoi "\"Me hizo tan feliz... Y cuando Aoi es feliz...\""


translate english c5173_264bbaae:



    voice "voice/c51/7300520a02.opus"
    aoi "\"...me dan ganas de besarte...\""


translate english c5173_4b2ff999:



    voice "voice/c51/7300530a02.opus"
    aoi "\"¿Seguro que esto no es un glitch?\""


translate english c5173_03210656:


    "Aoi se acerca y toca los botones de mi camisa."


translate english c5173_78851a09:


    "Todo lo que pasó en el techo esa noche... fue algo así como un impulso del momento."


translate english c5173_12d7dbef:


    "Pero esta noche es diferente."


translate english c5173_75076dd3:


    xy "\"Si tú tienes glitches...\""


translate english c5173_72a5a8b0:


    xy "\"Entonces yo también.\""


translate english c5173_ce69db58:



    voice "voice/c51/7300540a02.opus"
    aoi "\"Shinichi...\""


translate english c5173_d25e3f2c:



    voice "voice/c51/7300550a02.opus"
    aoi "\"Es hora de tu postre...\""


translate english c5173_3d115b19:


    "La envuelvo con mis brazos y la empujo hacia el sofá."


translate english c5173_157e0fb7:


    "Nuestros cuerpos rebotan con el impacto."


translate english c5173_d9e0bc16:


    "Puedo ver sus labios suaves y rosados..."


translate english c5173_3fa49713:


    "Están tan cerca—"


translate english c5173_269edf28:


    "Justo entonces, la pequeña lengua rosa de Eru entra en mi visión."


translate english c5173_f3124cf7:



    voice "voice/c51/7300570a02.opus"
    aoi "\"¿Boop boop?\""


translate english c5173_7859b861:


    xy "\"¡Eru!\""


translate english c5173_87bf19e2:


    "Eru se arrastra y le lame la mejilla."


translate english c5173_889718cf:


    "Luego la pequeña bola de pelo se acurruca en el sofá y se queda dormida."


translate english c5173_90a3cef5:


    xy "\"B-Bueno...\""


translate english c5173_226284f4:



    voice "voice/c51/7300590a02.opus"
    aoi "\"Debe tener sueño, ¿eh?\""


translate english c5173_88e32df9:


    xy "\"Ya es bastante tarde...\""


translate english c5173_e3cbd685:


    "Incluso los gatos transceptores tienen que dormir alguna vez, supongo."


translate english c5173_a6c0c3d7:


    "Me incorporo lentamente, con cuidado de no molestar a Eru."


translate english c5173_42e4d0af:


    "La escena es tan conmovedora que mata al instante el ambiente sexy."


translate english c5173_9f9bbe51:



    voice "voice/c51/7300600a02.opus"
    aoi "\"Jejeje... Eru está muy calentito.\""


translate english c5173_a228bb75:


    "Aparentemente Aoi y yo estamos en la misma página."


translate english c5173_aa5071f1:


    xy "\"Ah, eso me recuerda.\""


translate english c5173_8d34a37e:


    xy "\"Deberíamos conseguirle un collar a Eru en algún momento.\""


translate english c5173_15ea3457:



    voice "voice/c51/7300610a02.opus"
    aoi "\"¿Un collar?\""


translate english c5173_8bd46eda:


    xy "\"Dicen que hay que ponerle collar a un gatito desde pequeño, o si no no querrá usarlo cuando crezca.\""


translate english c5173_32512463:


    xy "\"Y también sería buena idea mandar a hacer una placa de identificación.\""


translate english c5173_3ef5295b:



    voice "voice/c51/7300620a02.opus"
    aoi "\"¡Bien! ¡Podemos hacerlo en Catnip!\""


translate english c5173_1005b71d:


    xy "\"Suena bien.\""


translate english c5173_5a64ca88:



    voice "voice/c51/7300630a02.opus"
    aoi "\"¡Una salida de compras...! ¡Mejor me esfuerzo por verme lo mejor posible!\""


translate english c5173_974530af:


    "Aoi saca el pasador de gatito de su bolsillo y lo mira con una sonrisa."


translate english c5173_2774e9b0:


    "Realmente atesora esa cosa, ¿eh?"


translate english c5173_e4db4762:


    xy "\"Bueno, quizá este fin de semana podamos invitar a Miyuki y—\""


translate english c5173_ea2012bc:



    voice "voice/c51/7300640a02.opus"
    aoi "\"Oh... Bien.\""


translate english c5173_17a1d032:


    xy "\"¿Hmm? ¿Qué pasa?\""


translate english c5173_879f9f4d:



    voice "voice/c51/7300650a02.opus"
    aoi "\"Nada.\""


translate english c5173_ee1c676f:



    voice "voice/c51/7300660a02.opus"
    aoi "\"Podemos ir los tres. Tú, yo y Miyuki.\""


translate english c5173_d892a3f6:



    voice "voice/c51/7300670a02.opus"
    aoi "\"Ha pasado tiempo, ¡así que será divertido!\""


translate english c5173_dac6778d:


    "Sonríe y se acurruca con Eru..."


translate english c5173_39525131:


    "...pero hay un dejo de vacilación en su voz."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
