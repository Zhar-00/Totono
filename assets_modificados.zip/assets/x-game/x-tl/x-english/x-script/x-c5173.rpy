

translate english c5173_051c52fa:


    "Son casi las diez."


translate english c5173_f19efaeb:


    "Normalmente estaría preparándome para dormir a esta hora, pero..."


translate english c5173_79d01174:


    xy "\"Hey, Eru.\""


translate english c5173_6ffbb926:


    xy "\"I know, buddy. I'm hungry too.\""


translate english c5173_c0556800:


    "At this point, I've already read Aoi's \"Cat Owner's Manual\"de Aoi de principio a fin. Dos veces."



translate english c5173_32a6b72e:


    "Aburridos, Eru y yo nos sentamos por ahí, esperándola."


translate english c5173_e695083e:


    "Entonces, por decimotercera vez hoy, la oigo subir corriendo las escaleras."


translate english c5173_41b52718:



    voice "voice/c51/7300030a02.opus"
    aoi "\"Shinichi?\""


translate english c5173_778131d1:


    "Me llama desde el otro lado de la puerta."


translate english c5173_c5abee38:



    voice "voice/c51/7300040a02.opus"
    aoi "\"What's this word mean? C-U-M-I-N?\""


translate english c5173_9cadefb0:


    xy "\"...Look, maybe I should just read the cookbook for you—\""


translate english c5173_2530022d:



    voice "voice/c51/7300050a02.opus"
    aoi "\"No!\""


translate english c5173_283131ad:



    voice "voice/c51/7300060a02.opus"
    aoi "\"Aoi's not reading a cookbook! It's for the vocabulary test!\""


translate english c5173_700f3ecf:


    xy "\"...Riiight.\""


translate english c5173_f8ea3152:


    "Suelto un suspiro."


translate english c5173_fb677385:


    "Tiene que estar leyendo ese libro de cocina que compró en la librería."


translate english c5173_1d435a08:


    "Y es un libro realmente básico, de nivel principiante..."


translate english c5173_20a67f04:


    "No tengo idea de cómo se mantiene al día en clase si es tan analfabeta..."


translate english c5173_2074ce27:


    "Pero claramente intenta cocinar para mí... mientras simultáneamente intenta ocultar el hecho de que no sabe leer..."


translate english c5173_77ca36c7:



    voice "voice/c51/7300070a02.opus"
    aoi "\"Shinichi?\""


translate english c5173_7132a734:


    xy "\"The word you're looking for is 'cumin'. It's a spice.\""



translate english c5173_cb584df8:



    voice "voice/c51/7300080a02.opus"
    aoi "\"Boop boop... Got it.\""


translate english c5173_2e4c6d0a:



    voice "voice/c51/7300090a02.opus"
    aoi "\"One teaspoon of cumin... And one tableful of olive oil!\""


translate english c5173_1a4ab130:


    xy "\"TableSPOON! Always read the recipe carefully!\""


translate english c5173_9f8382e1:


    "La corrijo rápidamente."


translate english c5173_62e4b19e:


    "De ninguna manera voy a dejar que cometa un error tan básico... No si puedo evitarlo, en todo caso..."


translate english c5173_1668b1d1:


    "Por lo que puedo ver, ya intentó hacer hamburguesas, curry y okonomiyaki, solo para que cada intento terminara en un miserable fracaso."


translate english c5173_ec137309:


    xy "\"Don't burn it this time, you hear me?! Once you turn the burner on, don't you DARE leave the room!\""


translate english c5173_c7f51f4f:



    voice "voice/c51/7300100a02.opus"
    aoi "\"Okay. This time, Aoi won't leave the...\""


translate english c5173_c52a5b39:



    voice "voice/c51/7300110a02.opus"
    aoi "\"Leave the...\""


translate english c5173_b104836d:



    voice "voice/c51/7300120a02.opus"
    aoi "\"AAHHH!!!\""


translate english c5173_0bf455be:


    "Eru se sienta junto a la puerta y gruñe."


translate english c5173_c0d7eadd:


    "Momentos después, huelo algo... quemado."


translate english c5173_72cdd575:



    voice "voice/c51/7300140a02.opus"
    aoi "\"AAAAAAAAHHHHHH!!!\""


translate english c5173_49db35f8:


    "Demasiado tarde."


translate english c5173_4aa4d55c:


    xy "\"Oh god, she was in the middle of cooking it...\""


translate english c5173_9c0fae21:


    xy "\"What are we gonna do, Eru?\""


translate english c5173_95b6a6de:


    "Eru mira al suelo."


translate english c5173_15c7859b:


    "Tengo tanta hambre que ya no lo soporto..."


translate english c5173_4e043a72:


    "Recojo a Eru y bajo a la sala de estar."


translate english c5173_58b1aacb:


    "Mientras Eru devora su cena—"


translate english c5173_aa5c174f:



    voice "voice/c51/7300170a02.opus"
    aoi "\"Boop boop...\""


translate english c5173_0accd139:


    xy "\"\"\"Boop\"......\"\"¿Estás llorando?\"\""


translate english c5173_90cf1992:


    "Juntos, miramos en silencio el salteado completamente carbonizado."


translate english c5173_8e790e2d:


    "Está muy, muy quemado—más de la mitad, al menos."


translate english c5173_124f5a14:


    "Quizás pueda aguantar y comerme la otra mitad."


translate english c5173_d75d0ea5:


    "...Que Dios me ayude."


translate english c5173_3f3d950a:



    voice "voice/c51/7300180a02.opus"
    aoi "\"Shinichi...\""



translate english c5173_0432f201:



    voice "voice/c51/7300190a02.opus"
    aoi "\"This doesn't look too good, does i—\""


translate english c5173_984f57ba:


    xy "\"Thanks for dinner.\""


translate english c5173_564df447:



    voice "voice/c51/7300200a02.opus"
    aoi "\"Boop boop!\""


translate english c5173_2db6c5e3:


    xy "\"Nom, nom, nom!!!\""


translate english c5173_b188af8e:



    voice "voice/c51/7300210a02.opus"
    aoi "\"Shinichi...\""


translate english c5173_62f0d272:


    xy "\"Nn... nngglp... mmm... Yum yum!!!\""


translate english c5173_164ff7ae:


    xy "\"It's great!\""


translate english c5173_dd1a7ee0:


    xy "\"How do I describe it? It's got this very refined, bitter flavor to it that pairs well with all the olive oil...!\""


translate english c5173_db2627d9:



    voice "voice/c51/7300220a02.opus"
    aoi "\"......Are you crying?\""


translate english c5173_a02f90b8:


    xy "\"Oh, these are happy tears, of course! I'm so blessed to eat your home cooking!\""


translate english c5173_bee159f0:



    voice "voice/c51/7300230a02.opus"
    aoi "\"Awesome!\""


translate english c5173_435ed23a:


    "Aoi agarra su tenedor y se mete un bocado de salteado en la boca—"


translate english c5173_1461d1eb:


    xy "\"Aoi, wait!\""


translate english c5173_336710a3:



    voice "voice/c51/7300240a02.opus"
    aoi "\"Boop boop...?\""


translate english c5173_09c24c15:



    voice "voice/c51/7300250a02.opus"
    aoi "\"Boop......\""


translate english c5173_31861ac3:



    voice "voice/c51/7300260a02.opus"
    aoi "\"Boop boop boop boop boop boop boop boop boop boop boop boop boop boop boop...!!!\""


translate english c5173_1fb1afcd:


    "Con la boca llena de salteado, suelta un pequeño grito ahogado y corre al fregadero."


translate english c5173_7ed6bfe8:


    "Identificable."


translate english c5173_e3a9cd95:


    xy "\"Aoi? You okay?\""


translate english c5173_8613a291:



    voice "voice/c51/7300270a02.opus"
    aoi "\"It's yucky...\""


translate english c5173_0b96386f:


    xy "\"N-No it isn't...!\""


translate english c5173_5c7f9d64:



    voice "voice/c51/7300280a02.opus"
    aoi "\"......\""


translate english c5173_bf5d16bd:


    xy "\"I mean, okay... Maybe it's not GOOD...\""


translate english c5173_9de6e593:



    voice "voice/c51/7300290a02.opus"
    aoi "\"Yeah...\""


translate english c5173_17ecca66:


    xy "\"But believe me when I say this.\""


translate english c5173_e4146366:


    xy "\"I'm really, really touched that you tried so hard to make this for me.\""


translate english c5173_d7a8ed2c:



    voice "voice/c51/7300300a02.opus"
    aoi "\"Huh...?\""


translate english c5173_789b1a50:



    voice "voice/c51/7300310a02.opus"
    aoi "\"You were... touched...?\""


translate english c5173_82b0451f:


    xy "\"Yeah. It's the thought that counts, y'know?\""


translate english c5173_2bdc62f7:


    xy "\"...Although we still need to eat something eventually...\""


translate english c5173_71966566:



    voice "voice/c51/7300320a02.opus"
    aoi "\"Yeah...\""


translate english c5173_ccefea86:


    xy "\"Well, let's just whip something up with whatever we have lef—\""


translate english c5173_c7d73322:


    "Abro el refrigerador para encontrar—"


translate english c5173_66530e0f:


    "—nada."


translate english c5173_fa185a84:


    "Lo único que hay es nuestra reserva de jugo de tomate de Yabaley."


translate english c5173_6a016a57:



    voice "voice/c51/7300330a02.opus"
    aoi "\"Aoi used everything...\""


translate english c5173_d8f30276:


    xy "\"Ah... I see...\""


translate english c5173_98e8d844:


    "¿Deberíamos ir al supermercado...?"


translate english c5173_47092ec2:


    "No, ya deben estar todos cerrados..."


translate english c5173_b73c3748:


    "Bien, ¿cuáles son nuestras opciones aquí...?"


translate english c5173_918c0f29:



    voice "voice/c51/7300340a02.opus"
    aoi "\"Boop boop...\""


translate english c5173_0bc5b0d3:


    xy "\"Uhhh... Hang on a sec.\""


translate english c5173_7363ba9f:


    "Podríamos ir a la tienda de la esquina, pero eso se siente un poco como hacer trampa..."


translate english c5173_8000f46b:


    "Así que en cambio agarro mi teléfono y envío un correo rápido."


translate english c5173_2bfc8255:



    voice "voice/c51/7300350a02.opus"
    aoi "\"Thank you for dinner!\""


translate english c5173_0e0e8c21:


    "Aoi se mete un tenedor lleno de pasta en la boca."


translate english c5173_4ed173ad:



    voice "voice/c51/7300360a02.opus"
    aoi "\"Slrrpp... Boop... boop boop!!!\""


translate english c5173_1e743db0:


    xy "\"How is it?\""


translate english c5173_c12b99f1:



    voice "voice/c51/7300370a02.opus"
    aoi "\"It's amazing!\""


translate english c5173_30c94010:



    voice "voice/c51/7300380a02.opus"
    aoi "\"It's godlike!!!\""


translate english c5173_eb4eaf29:


    "Aoi grita emocionada."


translate english c5173_9303e9bc:


    "No es sorpresa. Hice la salsa de pasta con Yabaley's, así que seguro le gustaría."


translate english c5173_2dab61e6:



    voice "voice/c51/7300390a02.opus"
    aoi "\"Is this one of Miyuki's recipes?\""


translate english c5173_f84fb05c:


    xy "\"You could say that.\""


translate english c5173_bbe12ac0:


    "Escribí una lista de todo lo que me quedaba en casa."


translate english c5173_3c72cca1:


    "Luego envié esa lista a Miyuki por correo y le pregunté si había algo que pudiera hacer con ello—y este fue el resultado."


translate english c5173_8933db56:


    "Gracias a Dios que todavía teníamos pasta..."


translate english c5173_6755a478:


    "¡Hasta yo estoy disfrutando esto, y ni siquiera me gustan los tomates normalmente!"


translate english c5173_471b60f5:



    voice "voice/c51/7300400a02.opus"
    aoi "\"Nnn... Miyuki's better than me at everything...\""


translate english c5173_50bdca1b:


    xy "\"So? You don't have to compare yourself to her.\""


translate english c5173_cfbee38f:



    voice "voice/c51/7300410a02.opus"
    aoi "\"Really...?\""


translate english c5173_80e5860d:


    xy "\"You're your own person, and so is she.\""


translate english c5173_9f3f972b:



    voice "voice/c51/7300420a02.opus"
    aoi "\"Boop boop...\""


translate english c5173_f87a65bf:


    "Aoi ladea la cabeza."


translate english c5173_b75846f9:



    voice "voice/c51/7300430a02.opus"
    aoi "\"...But Aoi wants to make tasty food for you.\""


translate english c5173_14bf220d:



    voice "voice/c51/7300440a02.opus"
    aoi "\"If Aoi can't manage that...\""


translate english c5173_e2284542:



    voice "voice/c51/7300450a02.opus"
    aoi "\"...then we can't get married.\""


translate english c5173_11cad308:


    xy "\"Married?!\""


translate english c5173_85d6f72a:


    "Mi voz sube una octava."


translate english c5173_747b64ea:



    voice "voice/c51/7300460a02.opus"
    aoi "\"Is that bad?\""


translate english c5173_fadcb5a3:


    xy "\"Huh? Well, no—\""


translate english c5173_c8b9c209:



    voice "voice/c51/7300470a02.opus"
    aoi "\"Is Aoi too weird to marry?\""


translate english c5173_99bf14cc:


    xy "\"No, that's not it! I just think it's a little early to be thinking about—\""


translate english c5173_9910c9a1:



    voice "voice/c51/7300480a02.opus"
    aoi "\"It's so confusing...\""


translate english c5173_9d51829c:



    voice "voice/c51/7300490a02.opus"
    aoi "\"Aoi was... so touched...\""


translate english c5173_e3872b36:



    voice "voice/c51/7300500a02.opus"
    aoi "\"...when you said... my food was good...\""


translate english c5173_276f9e3c:



    voice "voice/c51/7300510a02.opus"
    aoi "\"It made me so happy... And when Aoi's happy...\""


translate english c5173_264bbaae:



    voice "voice/c51/7300520a02.opus"
    aoi "\"...it makes me wants to kiss you...\""


translate english c5173_4b2ff999:



    voice "voice/c51/7300530a02.opus"
    aoi "\"Are you sure this isn't a glitch?\""


translate english c5173_03210656:


    "Aoi se acerca y toca los botones de mi camisa."


translate english c5173_78851a09:


    "Todo lo que pasó en el techo esa noche... fue algo así como un impulso del momento."


translate english c5173_12d7dbef:


    "Pero esta noche es diferente."


translate english c5173_75076dd3:


    xy "\"If you're glitching...\""


translate english c5173_72a5a8b0:


    xy "\"Then so am I.\""


translate english c5173_ce69db58:



    voice "voice/c51/7300540a02.opus"
    aoi "\"Shinichi...\""


translate english c5173_d25e3f2c:



    voice "voice/c51/7300550a02.opus"
    aoi "\"It's time for your dessert...\""


translate english c5173_3d115b19:


    "La envuelvo con mis brazos y la empujo hacia el sofá."


translate english c5173_157e0fb7:


    "Nuestros cuerpos rebotan con el impacto."


translate english c5173_d9e0bc16:


    "Puedo ver sus labios suaves y rosados..."


translate english c5173_3fa49713:


    "Están tan cerca—"


translate english c5173_269edf28:


    "Justo entonces, la pequeña lengua rosa de Eru entra en mi visión."


translate english c5173_f3124cf7:



    voice "voice/c51/7300570a02.opus"
    aoi "\"Boop boop?\""


translate english c5173_7859b861:


    xy "\"Eru!\""


translate english c5173_87bf19e2:


    "Eru se arrastra y le lame la mejilla."


translate english c5173_889718cf:


    "Luego la pequeña bola de pelo se acurruca en el sofá y se queda dormida."


translate english c5173_90a3cef5:


    xy "\"W-Welp...\""


translate english c5173_226284f4:



    voice "voice/c51/7300590a02.opus"
    aoi "\"Must be sleepy, huh?\""


translate english c5173_88e32df9:


    xy "\"It IS pretty late...\""


translate english c5173_e3cbd685:


    "Incluso los gatos transceptores tienen que dormir alguna vez, supongo."


translate english c5173_a6c0c3d7:


    "Me incorporo lentamente, con cuidado de no molestar a Eru."


translate english c5173_42e4d0af:


    "La escena es tan conmovedora que mata al instante el ambiente sexy."


translate english c5173_9f9bbe51:



    voice "voice/c51/7300600a02.opus"
    aoi "\"Hehehe... Eru's so warm.\""


translate english c5173_a228bb75:


    "Aparentemente Aoi y yo estamos en la misma página."


translate english c5173_aa5071f1:


    xy "\"Oh, that reminds me.\""


translate english c5173_8d34a37e:


    xy "\"We should get Eru a collar sometime.\""


translate english c5173_15ea3457:



    voice "voice/c51/7300610a02.opus"
    aoi "\"A collar?\""


translate english c5173_8bd46eda:


    xy "\"They say you need to collar a kitten from an early age or else they won't want to wear 'em when they get older.\""


translate english c5173_32512463:


    xy "\"And it'd be a good idea to get an ID tag made, too.\""


translate english c5173_3ef5295b:



    voice "voice/c51/7300620a02.opus"
    aoi "\"Okay! We can do it at Catnip!\""


translate english c5173_1005b71d:


    xy "\"Sounds good.\""


translate english c5173_5a64ca88:



    voice "voice/c51/7300630a02.opus"
    aoi "\"A shopping trip...! Better try to look my best!\""


translate english c5173_974530af:


    "Aoi saca el pasador de gatito de su bolsillo y lo mira con una sonrisa."


translate english c5173_2774e9b0:


    "Realmente atesora esa cosa, ¿eh?"


translate english c5173_e4db4762:


    xy "\"Alright then, maybe this weekend we can invite Miyuki and—\""


translate english c5173_ea2012bc:



    voice "voice/c51/7300640a02.opus"
    aoi "\"Oh... Okay.\""


translate english c5173_17a1d032:


    xy "\"Hmm? What's wrong?\""


translate english c5173_879f9f4d:



    voice "voice/c51/7300650a02.opus"
    aoi "\"Nothing.\""


translate english c5173_ee1c676f:



    voice "voice/c51/7300660a02.opus"
    aoi "\"We can go as a trio. You, me, and Miyuki.\""


translate english c5173_d892a3f6:



    voice "voice/c51/7300670a02.opus"
    aoi "\"It's been a while, so it'll be fun!\""


translate english c5173_dac6778d:


    "Sonríe y se acurruca con Eru..."


translate english c5173_39525131:


    "...pero hay un dejo de vacilación en su voz."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
