

translate english d4242_3d081812:


    xy "\"Miyuki...\""



translate english d4242_a4043504:



    voice "voice/d42/4200010a01.opus"
    mx "\"¿S-Sí...?\""


translate english d4242_74daa1a7:


    xy "\"He estado negándolo mucho tiempo... Constantemente esquivando el tema...\""


translate english d4242_8292ce25:


    xy "\"Pero con la ayuda de Aoi, por fin me enfrenté a lo que siento.\""


translate english d4242_6cac97d9:


    "Tomo una respiración profunda."


translate english d4242_e82a1d89:


    "Estas son las palabras que nos cambiarán para siempre."


translate english d4242_3fa3ad74:


    xy "\"Te amo.\""


translate english d4242_19ba0cce:


    xy "\"Siempre te he amado.\""


translate english d4242_e8e3a713:


    xy "\"¡Y quiero estar contigo!\""


translate english d4242_c4f50025:


    xy "\"¡Por favor, sé mía!\""


translate english d4242_0469be1e:


    "Inclino la cabeza..."


translate english d4242_99756f08:


    "...y espero."


translate english d4242_31882b43:


    "Espero... y espero... y espero... hasta que ya no lo soporto."


translate english d4242_ba6b8029:



    voice "voice/d42/4200020a01.opus"
    mx "\"......Shinichi.\""


translate english d4242_0ceff370:


    "Miyuki está ahí de pie, sin persona tras la que esconderse, desnudamente vulnerable."


translate english d4242_fd812932:



    voice "voice/d42/4200030a01.opus"
    mx "\"He estado esperando todo este tiempo...\""


translate english d4242_b2f9ad6d:


    "Una sola lágrima surca su mejilla."


translate english d4242_275e1be2:


    "Tanto ella como yo sabemos..."


translate english d4242_980d7ccc:


    "...es una lágrima de felicidad."


translate english d4242_8610448c:



    voice "voice/d42/4200040a01.opus"
    mx "\"...Oye, ¿Shinichi?\""


translate english d4242_12ef9483:



    voice "voice/d42/4200050a01.opus"
    mx "\"Si de verdad me amas...\""


translate english d4242_2987a8eb:



    voice "voice/d42/4200060a01.opus"
    mx "\"...¿me besarás?\""


translate english d4242_c66525d5:


    "Puedo sentir su aliento."


translate english d4242_1ca5bada:


    "Sus ojos están a centímetros de los míos."


translate english d4242_ea116f0c:


    "El recuerdo que una vez me contuvo ahora se dispersa en el viento como ceniza."


translate english d4242_5ed8b2ee:


    "Dicen que la vida es una serie de elecciones."


translate english d4242_1a53b3be:


    "Pero eso es un montón de basura."


translate english d4242_f6b4743b:


    "Dios no está allá arriba tirando los dados."


translate english d4242_56c70616:


    "Los "y si" no existen."



translate english d4242_253cf73f:


    "Son las sinapsis en nuestros cerebros las que toman nuestras decisiones por nosotros."


translate english d4242_5df3dbf0:


    "Eso es todo lo que hay."


translate english d4242_75106b1b:


    "Todo es destino."


translate english d4242_07adbd93:


    "Y estábamos destinados a terminar juntos, desde el mismísimo principio."


translate english d4242_7d734f07:


    xy "\"¡Miyuki—!\""



translate english d4242_a6d17e61:



    voice "voice/d42/4200070a01.opus"
    mx "\"Shinichi...\""


translate english d4242_9a8c2910:


    "La atraigo suavemente a mis brazos..."


translate english d4242_43655192:


    "...y beso sus labios."


translate english d4242_ebcda36d:


    "Y con esto, nuestros corazones finalmente son uno."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
