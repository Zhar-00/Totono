

translate english a7133_83f8728e:


    xy "\"Yuutarou...\""


translate english a7133_bed65f96:


    "Con la carta en mano, me acerco en silencio a su escritorio."


translate english a7133_1b2d7731:


    "Lo encuentro mirando hacia abajo en silencio, con las manos temblando levemente."


translate english a7133_8c8224a5:


    xy "\"I swear, I didn't know things between me and Miyuki were going to turn out like this.\""


translate english a7133_217aace9:


    xy "\"I wasn't trying to hide it from you... but that doesn't change the fact that I hurt you.\""


translate english a7133_4496d90d:


    xy "\"I'm sorry, Yuutarou.\""


translate english a7133_04f2bc73:


    xy "\"I feel really bad about this... And I promise I won't do it again, so...\""


translate english a7133_5df1f21e:


    "Con cuidado, dejo la carta de nuevo sobre su escritorio."


translate english a7133_68a988e7:


    xy "\"Can't we keep goofing around every morning, like always?\""


translate english a7133_254595b0:


    xy "\"Besides... With me gone, the Boys and Dreams Club won't have enough members to avoid being shut down.\""


translate english a7133_19ec3f6c:


    xy "\"So it makes sense to—\""


translate english a7133_dca28a52:



    voice "voice/a71/3300010b01.opus"
    xtl "\"Pff...\""


translate english a7133_397e1b32:



    voice "voice/a71/3300020b01.opus"
    xtl "\"Heheheheh... Hahahahahaha...\""


translate english a7133_635f7aee:



    voice "voice/a71/3300030b01.opus"
    xtl "\"Pfffhaaahahahahahahaha!\""


translate english a7133_2901711a:


    xy "\"Um...?\""


translate english a7133_78231831:



    voice "voice/a71/3300040b01.opus"
    xtl "\"Private Shinichi—no, Former Private Shinichi! You appear to be operating under a grave misunderstanding!\""


translate english a7133_62a5b119:


    xy "\"I am?\""


translate english a7133_1bf6fb9b:



    voice "voice/a71/3300050b01.opus"
    xtl "\"Do you know why it is that the great BD Club chronically suffers from such a dire shortage of members?!\""


translate english a7133_53e01649:


    xy "\"Because you're obnoxious?\""


translate english a7133_6bbaf449:



    voice "voice/a71/3300060b01.opus"
    xtl "\"No! I'm afraid not! I mean, I am, but that's not the reason!\""


translate english a7133_1cf49997:


    "Así que admite que es insoportable..."


translate english a7133_7675f6c1:



    voice "voice/a71/3300070b01.opus"
    xtl "\"So, then, why does the Boys and Dreams Club chronically suffer from a shortage of members, you ask?\""


translate english a7133_908687ed:



    voice "voice/a71/3300080b01.opus"
    xtl "\"The answer lies in the oath sworn by the BD Boys!\""


translate english a7133_12f14894:



    voice "voice/a71/3300090b01.opus"
    xtl "\"As a member of the BD Club, you must always remain in pursuit of your dreams!\""


translate english a7133_5b5ad028:


    "Ah, cierto... Esto me suena familiar..."


translate english a7133_7cc73ca6:



    voice "voice/a71/3300100b01.opus"
    xtl "\"Yes, we call them dreams only because they remain out of our reach!\""


translate english a7133_78e2c42b:



    voice "voice/a71/3300110b01.opus"
    xtl "\"But you have already achieved yours...\""


translate english a7133_cfde7e80:



    voice "voice/a71/3300120b01.opus"
    xtl "\"The lofty dream known as Sone Miyuki...\""


translate english a7133_181a9b80:



    voice "voice/a71/3300130b01.opus"
    xtl "\"As captain of the Boys and Dreams Club, I, Akebono Yuutarou, hereby command—\""


translate english a7133_7da41995:



    voice "voice/a71/3300140b01.opus"
    xtl "\"As of this day—\""


translate english a7133_80d41433:



    voice "voice/a71/3300150b01.opus"
    xtl "\"Susuki Shinichi has officially graduated from the BD Club!!!\""


translate english a7133_150b9dbb:



    voice "voice/a71/3300160b01.opus"
    xtl "\"Congratulations, Shinichi!!!\""


translate english a7133_11cd368b:


    "Yuutarou me mete en las manos la carta de expulsión como si fuera un diploma..."


translate english a7133_5c292b46:


    "...todo el tiempo llorando lágrimas varoniles."


translate english a7133_b41fd282:


    "No entiendo."


translate english a7133_e4cbe5de:


    "Por alguna razón..."


translate english a7133_de526033:


    "Algún tipo de emoción extraña está... brotando en mi pecho...?"


translate english a7133_19a6203f:


    "¿De verdad está pasando esto?"


translate english a7133_95bedd29:


    "Todo este tiempo, solo puse los ojos en blanco ante el concepto del Club BD."


translate english a7133_2c897897:


    "Pensaba que era solo un miembro suplente."


translate english a7133_76dd2e33:


    "Y aun así..."


translate english a7133_4deac560:


    "Tomo la carta, con expresión firme."


translate english a7133_edb9337a:


    xy "\"I can't accept this.\""


translate english a7133_a52d80ac:



    voice "voice/a71/3300170b01.opus"
    xtl "\"Wha?! Wait—Whawhawhawha?!?!\""


translate english a7133_4edad8fd:


    "Destrozo la carta, arrugo los pedazos en una bola y se la devuelvo a las manos."


translate english a7133_f96286d4:



    voice "voice/a71/3300180b01.opus"
    xtl "\"Dude! The hell are you doing, man—?!\""


translate english a7133_e11cc3a1:


    xy "\"You appeared to me in a dream this morning.\""


translate english a7133_bad2a5c8:


    xy "\"And you showed me a new way to search for my dreams.\""


translate english a7133_5aaad9f1:



    voice "voice/a71/3300190b01.opus"
    xtl "\"Wha?! Wait—Whawhawhawha?!?!\""


translate english a7133_7be81f6d:


    xy "\"While I admit I might have attained one dream...\""


translate english a7133_0bd25a5b:


    xy "\"The very moment I did, it transformed into pure joy and took root deep in my heart.\""


translate english a7133_fd3e8200:


    xy "\"Now all that's left is to find a new dream... don't you think?\""


translate english a7133_ff7b25be:



    voice "voice/a71/3300200b01.opus"
    xtl "\"A new dream, you say...?\""


translate english a7133_84320fa3:



    voice "voice/a71/3300210b01.opus"
    xtl "\"You're not making any sense, my guy! Now that you have Sone-san, what more could you possibly wish for?!\""


translate english a7133_9d72e314:


    xy "\"W-Well...\""


translate english a7133_da78f1a2:


    "Buen punto."


translate english a7133_8880a478:


    "¿Cuál es mi próximo gran sueño?"


translate english a7133_533fefea:


    "Piensa, piensa... ¿Hay algún sueño al que haya renunciado en el pasado...?"


translate english a7133_3a1c551f:


    "Espera..."


translate english a7133_32590ff6:


    "Ahora que lo pienso, ¿no fue Yuutarou quien declaró muertos sus sueños tras toda esa situación con su hermano travestido...?"


translate english a7133_c7d87b9b:


    xy "\"How about... cosplay, or something?\""


translate english a7133_1159ce58:



    voice "voice/a71/3300220b01.opus"
    xtl "\"C-C-C-C-C-C-COSPLAAAAAAY?!?!\""


translate english a7133_3f1c94f6:



    voice "voice/a71/3300230b01.opus"
    xtl "\"Nurse! Bunny! Policewoman! Shrine maiden! And f-f-f-finally, m-m-m-maid!!!\""


translate english a7133_761d5dbd:



    voice "voice/a71/3300240b01.opus"
    xtl "\"Sone Miyuki, the queen bee of the school! Sone Miyuki, the picture of sophistication and grace! Sone Miyuki, the closet tsundere!\""


translate english a7133_35c34d09:



    voice "voice/a71/3300250b01.opus"
    xtl "\"If, by any chance, she could wear a maid outfit... and say things like 'Welcome home, master'...!\""


translate english a7133_31f85463:


    xy "\"Oh, yeah, definitely... I think I can see the appeal...\""


translate english a7133_f47785be:



    voice "voice/a71/3300260b01.opus"
    xtl "\"THAT'S THE POWER OF DREAMS!\""


translate english a7133_b7dbfcb7:


    xy "\"The what now?\""


translate english a7133_b7e37284:



    voice "voice/a71/3300270b01.opus"
    xtl "\"Dreams never truly die! They will rise again as many times as it takes!\""


translate english a7133_620f439d:



    voice "voice/a71/3300280b01.opus"
    xtl "\"As many times as we wish them to!\""


translate english a7133_81c5ed0b:



    voice "voice/a71/3300290b01.opus"
    xtl "\"Nn... NNNNRRRRRRRGGGGGGHHHHHHH!!!\""


translate english a7133_73318ef3:



    voice "voice/a71/3300300b01.opus"
    xtl "\"Nom! Om nom nom nom!!!\""


translate english a7133_df422dd3:


    xy "\"Whoa! What are you doing?!\""


translate english a7133_ab54caf0:


    "Yuutarou de repente se mete la bola de papel arrugado en la boca."


translate english a7133_52d1af08:



    voice "voice/a71/3300310b01.opus"
    xtl "\"Nom... ggllpp... I... I... Nn... nngghh! I take back what I said!!!\""


translate english a7133_ac49ace3:


    xy "\"Yuutarou?!\""


translate english a7133_ea3861d0:



    voice "voice/a71/3300320b01.opus"
    xtl "\"As the captain of the Boys and Dreams Club, I am truly ashamed of myself!!!\""


translate english a7133_3a88376a:



    voice "voice/a71/3300330b01.opus"
    xtl "\"Shinichi, you remain a truly exceptional soldier in the BD Army!\""


translate english a7133_a07810d0:


    xy "\"Yuutarou...!\""


translate english a7133_1e83e283:



    voice "voice/a71/3300340b01.opus"
    xtl "\"Shinichi!\""


translate english a7133_0a007927:



    voice "voice/a71/3300350a01.opus"
    mx "\"How stupid are you two?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
