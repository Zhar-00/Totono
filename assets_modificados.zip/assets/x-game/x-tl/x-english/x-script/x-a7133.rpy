

translate english a7133_83f8728e:


    xy "\"Yuutarou...\""


translate english a7133_bed65f96:


    "Con la carta en mano, me acerco en silencio a su escritorio."


translate english a7133_1b2d7731:


    "Lo encuentro mirando hacia abajo en silencio, con las manos temblando levemente."


translate english a7133_8c8224a5:


    xy "\"Lo juro, no sabía que las cosas entre Miyuki y yo iban a terminar así.\""


translate english a7133_217aace9:


    xy "\"No intentaba ocultártelo... pero eso no cambia el hecho de que te herí.\""


translate english a7133_4496d90d:


    xy "\"Lo siento, Yuutarou.\""


translate english a7133_04f2bc73:


    xy "\"Me siento muy mal por esto... Y prometo que no volverá a pasar, así que...\""


translate english a7133_5df1f21e:


    "Con cuidado, dejo la carta de nuevo sobre su escritorio."


translate english a7133_68a988e7:


    xy "\"¿No podemos seguir tonteando todas las mañanas, como siempre?\""


translate english a7133_254595b0:


    xy "\"Además... Conmigo fuera, el Club de Chicos y Sueños no tendrá suficientes miembros para evitar que lo cierren.\""


translate english a7133_19ec3f6c:


    xy "\"Así que tiene sentido que—\""


translate english a7133_dca28a52:



    voice "voice/a71/3300010b01.opus"
    xtl "\"Pff...\""


translate english a7133_397e1b32:



    voice "voice/a71/3300020b01.opus"
    xtl "\"Jejejeje... Jajajajajaja...\""


translate english a7133_635f7aee:



    voice "voice/a71/3300030b01.opus"
    xtl "\"¡Pfffjaaajajajajajajaja!\""


translate english a7133_2901711a:


    xy "\"¿Em...?\""


translate english a7133_78231831:



    voice "voice/a71/3300040b01.opus"
    xtl "\"¡Soldado Shinichi—no, ex soldado Shinichi! ¡Parece que estás operando bajo un grave malentendido!\""


translate english a7133_62a5b119:


    xy "\"¿Ah, sí?\""


translate english a7133_1bf6fb9b:



    voice "voice/a71/3300050b01.opus"
    xtl "\"¿¡Sabes por qué el gran Club BD sufre crónicamente de una escasez tan terrible de miembros!?\""


translate english a7133_53e01649:


    xy "\"¿Porque eres insoportable?\""


translate english a7133_6bbaf449:



    voice "voice/a71/3300060b01.opus"
    xtl "\"¡No! ¡Me temo que no! O sea, sí lo soy, ¡pero esa no es la razón!\""


translate english a7133_1cf49997:


    "Así que admite que es insoportable..."


translate english a7133_7675f6c1:



    voice "voice/a71/3300070b01.opus"
    xtl "\"Entonces, ¿por qué el Club de Chicos y Sueños sufre crónicamente de escasez de miembros, preguntas?\""


translate english a7133_908687ed:



    voice "voice/a71/3300080b01.opus"
    xtl "\"¡La respuesta está en el juramento de los Chicos BD!\""


translate english a7133_12f14894:



    voice "voice/a71/3300090b01.opus"
    xtl "\"¡Como miembro del Club BD, siempre debes estar en busca de tus sueños!\""


translate english a7133_5b5ad028:


    "Ah, cierto... Esto me suena familiar..."


translate english a7133_7cc73ca6:



    voice "voice/a71/3300100b01.opus"
    xtl "\"¡Sí, los llamamos sueños solo porque siguen fuera de nuestro alcance!\""


translate english a7133_78e2c42b:



    voice "voice/a71/3300110b01.opus"
    xtl "\"Pero tú ya alcanzaste el tuyo...\""


translate english a7133_cfde7e80:



    voice "voice/a71/3300120b01.opus"
    xtl "\"El altísimo sueño conocido como Sone Miyuki...\""


translate english a7133_181a9b80:



    voice "voice/a71/3300130b01.opus"
    xtl "\"Como capitán del Club de Chicos y Sueños, yo, Akebono Yuutarou, por la presente ordeno—\""


translate english a7133_7da41995:



    voice "voice/a71/3300140b01.opus"
    xtl "\"A partir de este día—\""


translate english a7133_80d41433:



    voice "voice/a71/3300150b01.opus"
    xtl "\"¡¡¡Susuki Shinichi se ha graduado oficialmente del Club BD!!!\""


translate english a7133_150b9dbb:



    voice "voice/a71/3300160b01.opus"
    xtl "\"¡¡¡Felicidades, Shinichi!!!\""


translate english a7133_11cd368b:


    "Yuutarou me mete en las manos la carta de expulsión como si fuera un diploma..."


translate english a7133_5c292b46:


    "...todo el tiempo llorando lágrimas varoniles."


translate english a7133_b41fd282:


    "No entiendo."


translate english a7133_e4cbe5de:


    "Por alguna razón..."


translate english a7133_de526033:


    "Algún tipo de emoción extraña está... brotando en mi pecho...?"


translate english a7133_19a6203f:


    "¿De verdad está pasando esto?"


translate english a7133_95bedd29:


    "Todo este tiempo, solo puse los ojos en blanco ante el concepto del Club BD."


translate english a7133_2c897897:


    "Pensaba que era solo un miembro suplente."


translate english a7133_76dd2e33:


    "Y aun así..."


translate english a7133_4deac560:


    "Tomo la carta, con expresión firme."


translate english a7133_edb9337a:


    xy "\"No puedo aceptarlo.\""


translate english a7133_a52d80ac:



    voice "voice/a71/3300170b01.opus"
    xtl "\"¿¡Qué!? Espera—¿¡Qué qué qué qué qué!?\""


translate english a7133_4edad8fd:


    "Destrozo la carta, arrugo los pedazos en una bola y se la devuelvo a las manos."


translate english a7133_f96286d4:



    voice "voice/a71/3300180b01.opus"
    xtl "\"¡Amigo! ¿¡Qué demonios estás haciendo, hombre—!?\""


translate english a7133_e11cc3a1:


    xy "\"Se me apareciste en un sueño esta mañana.\""


translate english a7133_bad2a5c8:


    xy "\"Y me mostraste una nueva forma de buscar mis sueños.\""


translate english a7133_5aaad9f1:



    voice "voice/a71/3300190b01.opus"
    xtl "\"¿¡Qué!? Espera—¿¡Qué qué qué qué qué!?\""


translate english a7133_7be81f6d:


    xy "\"Aunque admito que quizá haya alcanzado un sueño...\""


translate english a7133_0bd25a5b:


    xy "\"En el mismo instante en que lo hice, se transformó en pura alegría y echó raíces profundas en mi corazón.\""


translate english a7133_fd3e8200:


    xy "\"Ahora lo único que queda es encontrar un nuevo sueño... ¿no crees?\""


translate english a7133_ff7b25be:



    voice "voice/a71/3300200b01.opus"
    xtl "\"¿Un nuevo sueño, dices...?\""


translate english a7133_84320fa3:



    voice "voice/a71/3300210b01.opus"
    xtl "\"¡No tiene ningún sentido, amigo mío! ¡Ahora que tienes a Sone-san, qué más podrías desear!?\""


translate english a7133_9d72e314:


    xy "\"B-Bueno...\""


translate english a7133_da78f1a2:


    "Buen punto."


translate english a7133_8880a478:


    "¿Cuál es mi próximo gran sueño?"


translate english a7133_533fefea:


    "Piensa, piensa... ¿Hay algún sueño al que haya renunciado en el pasado...?"


translate english a7133_3a1c551f:


    "Espera..."


translate english a7133_32590ff6:


    "Ahora que lo pienso, ¿no fue Yuutarou quien declaró muertos sus sueños tras toda esa situación con su hermano travestido...?"


translate english a7133_c7d87b9b:


    xy "\"¿Qué tal... cosplay, o algo así?\""


translate english a7133_1159ce58:



    voice "voice/a71/3300220b01.opus"
    xtl "\"¿¡C-C-C-C-C-C-COSPLAAAAAAY!?\""


translate english a7133_3f1c94f6:



    voice "voice/a71/3300230b01.opus"
    xtl "\"¡Enfermera! ¡Conejita! ¡Policía! ¡Miko! ¡Y p-p-p-por último, e-e-e-empleada!!!\""


translate english a7133_761d5dbd:



    voice "voice/a71/3300240b01.opus"
    xtl "\"¡Sone Miyuki, la abeja reina de la escuela! ¡Sone Miyuki, la imagen de la sofisticación y la gracia! ¡Sone Miyuki, la tsundere de armario!\""


translate english a7133_35c34d09:



    voice "voice/a71/3300250b01.opus"
    xtl "\"¡Si, por casualidad, pudiera usar un atuendo de empleada... y decir cosas como \"Bienvenido a casa, amo\"...!\""


translate english a7133_31f85463:


    xy "\"Oh, sí, definitivamente... Creo que puedo ver el atractivo...\""


translate english a7133_f47785be:



    voice "voice/a71/3300260b01.opus"
    xtl "\"¡ESO ES EL PODER DE LOS SUEÑOS!\""


translate english a7133_b7dbfcb7:


    xy "\"¿El qué ahora?\""


translate english a7133_b7e37284:



    voice "voice/a71/3300270b01.opus"
    xtl "\"¡Los sueños nunca mueren de verdad! ¡Resurgirán tantas veces como haga falta!\""


translate english a7133_620f439d:



    voice "voice/a71/3300280b01.opus"
    xtl "\"¡Tantas veces como queramos!\""


translate english a7133_81c5ed0b:



    voice "voice/a71/3300290b01.opus"
    xtl "\"¡Nn... NNNRRRRRRGGGGGGHHHHHH!\""


translate english a7133_73318ef3:



    voice "voice/a71/3300300b01.opus"
    xtl "\"¡Ñam! ¡Ñam ñam ñam ñam!\""


translate english a7133_df422dd3:


    xy "\"¡Uah! ¿¡Qué estás haciendo!?\""


translate english a7133_ab54caf0:


    "Yuutarou de repente se mete la bola de papel arrugado en la boca."


translate english a7133_52d1af08:



    voice "voice/a71/3300310b01.opus"
    xtl "\"Ñam... gllpp... Yo... Yo... Nn... ¡ngghh! ¡Retiro lo dicho!\""


translate english a7133_ac49ace3:


    xy "\"¿¡Yuutarou!?\""


translate english a7133_ea3861d0:



    voice "voice/a71/3300320b01.opus"
    xtl "\"¡Como capitán del Club de Chicos y Sueños, de verdad me avergüenzo de mí mismo!\""


translate english a7133_3a88376a:



    voice "voice/a71/3300330b01.opus"
    xtl "\"¡Shinichi, sigues siendo un soldado verdaderamente excepcional del Ejército BD!\""


translate english a7133_a07810d0:


    xy "\"¡Yuutarou...!\""


translate english a7133_1e83e283:



    voice "voice/a71/3300340b01.opus"
    xtl "\"¡Shinichi!\""


translate english a7133_0a007927:



    voice "voice/a71/3300350a01.opus"
    mx "\"¿Qué tan tontos pueden ser ustedes dos?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
