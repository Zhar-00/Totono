

translate english c2193_2dcdac3b:



    voice "voice/c21/9300010a02.opus"
    aoi "\"No. ¡Es un regalo de Shinichi!\""


translate english c2193_9744f4fd:



    voice "voice/c21/9300020a01.opus"
    mx "\"Después le pediré que me consiga otra cosa. Algo que me quede mejor.\""


translate english c2193_a77d2f96:



    voice "voice/c21/9300030a01.opus"
    mx "\"No te importa, ¿verdad, Shinichi?\""


translate english c2193_13508d72:


    xy "\"Jaah... Supongo que no tengo opción, ¿no?\""


translate english c2193_d95b8c88:


    "¿De verdad quiere que le compre algo, o solo lo dice para quitarse a Aoi de encima?"


translate english c2193_fb4c3730:


    "No me entusiasma averiguarlo..."


translate english c2193_0d1dd014:



    voice "voice/c21/9300040a01.opus"
    mx "\"Ahora entonces, aquí tienes.\""


translate english c2193_2d66cfb0:


    "Miyuki mete el paquete en las manos de Aoi."


translate english c2193_da1345e4:



    voice "voice/c21/9300050a02.opus"
    aoi "\"...¿Estás seguro?\""


translate english c2193_dd8d7ac7:



    voice "voice/c21/9300060a01.opus"
    mx "\"¡Extremadamente seguro!\""


translate english c2193_4169238d:



    voice "voice/c21/9300070a02.opus"
    aoi "\"Pero...\""


translate english c2193_9bdbebef:


    xy "\"Tómalo como un regalo de los dos.\""


translate english c2193_0ccbe4dc:



    voice "voice/c21/9300080a01.opus"
    mx "\"¡Póntelo! A ver esa linda sonrisa.\""


translate english c2193_01388960:



    voice "voice/c21/9300090a02.opus"
    aoi "\"Bip bip...\""


translate english c2193_fb2258a9:



    voice "voice/c21/9300100a02.opus"
    aoi "\"Okay.\""


translate english c2193_2beed74d:


    "Aoi acepta el regalo en silencio."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
