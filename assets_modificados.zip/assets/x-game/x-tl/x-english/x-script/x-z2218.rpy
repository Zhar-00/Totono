

translate english z2218_f5e1b31d:



    voice "voice/z22/1800010a01.opus"
    mx "¿Comiste tus gachas de año nuevo?"


translate english z2218_2fa683e3:



    voice "voice/z22/1800020a01.opus"
    mx "¿O quieres que te prepare unas?"


translate english z2218_356115cb:



    voice "voice/z22/1800030a01.opus"
    mx "No te preocupes, las haré con amor."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
