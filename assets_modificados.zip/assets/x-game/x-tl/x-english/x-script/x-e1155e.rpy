

translate english e1155e_8b52ff76:



    voice "voice/e11/55e00010a01.opus"
    mx "\"Vamos, no seas así...\""


translate english e1155e_20f6276c:



    voice "voice/e11/55e00020a01.opus"
    mx "Solo... ¡BÉSAME...!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
