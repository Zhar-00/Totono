

translate english a3121_a518e3bd:


    "Después de clases, me dirijo a la azotea para encontrarme con los demás."


translate english a3121_73c3935d:



    voice "voice/a31/2100010a02.opus"
    aoi "\"Boop boop...\""


translate english a3121_aea39b99:


    "I turn around, and sure enough, Aoi's up there \"transmitting\"otra vez."


translate english a3121_d89701c5:


    "Subo la escalera."



translate english a3121_291eb72c:


    xy "\"Did God ever answer your call?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
