

translate english c5231_a4df1552:



    voice "voice/c52/3100010a01.opus"
    mx "\"¿Sospechas de Akebono-kun?\""


translate english c5231_46bc0fb0:


    xy "\"¿Qué?\""


translate english c5231_fac46706:


    "Esto es lo primero que Miyuki me dice después de que le cuento lo que pasó esta mañana."


translate english c5231_b51761cd:



    voice "voice/c52/3100020a01.opus"
    mx "\"Crees que intenta quedarse con Aoi para él, ¿es eso?\""


translate english c5231_c9506369:


    xy "\"Para nada. Está más interesado en t—\""


translate english c5231_23bac140:



    voice "voice/c52/3100030a01.opus"
    mx "\"Ya lo rechacé. Y hace bastante tiempo, además.\""


translate english c5231_21b27163:


    "Tiene razón. Por atractiva que sea, no hay garantía de que él la espere para siempre."


translate english c5231_93effd6c:


    "La mayoría de la gente probablemente intentaría encontrar a alguien más."


translate english c5231_0ea2df2b:


    xy "\"¿Pero por qué Aoi?\""


translate english c5231_e6d15046:



    voice "voice/c52/3100040a01.opus"
    mx "\"¿Quién sabe? La gente tiene sus razones.\""


translate english c5231_20d4ffe9:


    xy "\"¡Pero él me ayudó a buscarla todo el tiempo!\""


translate english c5231_8eeb166f:



    voice "voice/c52/3100050a01.opus"
    mx "\"¿No es parte de por qué sospechas de él?\""


translate english c5231_e3adb631:


    xy "\"¿Qué...?\""


translate english c5231_b03f3e07:


    "Pensé que era solo prueba de que él se preocupa por mí..."


translate english c5231_2ae89d47:


    "¿Podría tener razón Miyuki? ¿Podría haber tenido un motivo oculto?"


translate english c5231_85cea9f2:


    "No puede ser... No puede ser—"


translate english c5231_e43a61cb:


    xy "\"......Oh.\""


translate english c5231_e06cd379:


    "El día que llegué a casa a una casa vacía, Aoi apareció con leche de la tienda de la esquina."


translate english c5231_683f384f:


    "La tienda familiar de Yuutarou."


translate english c5231_202c5e4d:



    voice "voice/c52/3100060a01.opus"
    mx "\"No te ves muy bien.\""


translate english c5231_d95ea248:


    xy "\"...No, estoy bien.\""


translate english c5231_ee71e799:



    voice "voice/c52/3100070a01.opus"
    mx "\"¿En serio? Porque a mí no me lo pareces.\""


translate english c5231_843c3140:



    voice "voice/c52/3100080a01.opus"
    mx "\"Ten, usa esto.\""


translate english c5231_a78669d8:


    "Me entrega boletos para la obra."


translate english c5231_ace31837:



    voice "voice/c52/3100090a01.opus"
    mx "\"En vez de dejar que te carcoma, bien podrías hacer algo al respecto. Podría resultar ser un simple malentendido.\""


translate english c5231_e6233483:



    voice "voice/c52/3100100a01.opus"
    mx "\"En lugar de quedarte rumiando tus sentimientos, deberías invitarla a una cita.\""


translate english c5231_91b3044d:



    voice "voice/c52/3100110a02.opus"
    aoi "\"¡Ataque de puñetazo gatuno! ¡Miau!\""


translate english c5231_86735374:



    voice "voice/c52/3100130a02.opus"
    aoi "\"¡Miau! ¡Miau! ¡Miau!\""


translate english c5231_630c1b52:


    "Meanwhile, Aoi practices her \"kitty punch attack\"con Eru."



translate english c5231_a2b02fbc:


    "Las cosas están tan incómodas entre nosotros ahora..."


translate english c5231_ba946912:


    "¿Cómo podría invitarla a una cita, de todas las cosas?"


translate english c5231_62e0e7df:



    voice "voice/c52/3100140a01.opus"
    mx "\"¿Quizá deberías guardar la partida?\""


translate english c5231_696246e4:



    voice "voice/c52/3100150a01.opus"
    mx "\"Así, si la riegas, puedes intentarlo otra vez.\""


translate english c5231_8cfa3631:


    "Sé que está bromeando, pero... me hace pausar."


translate english c5231_bdd3abe8:


    "If only I could \"save my progress\"en la vida real... Todo sería mucho más fácil..."



translate english c5231_84329fcc:


    "Podría simplemente recargar mi partida y darle otra oportunidad..."


translate english c5231_5d3d89f3:


    "Con un poder así, nunca necesitaría vacilar."


translate english c5231_bd1335e0:



    voice "voice/c52/3100160a01.opus"
    mx "\"Bueno, me voy.\""


translate english c5231_288fbd5f:


    xy "\"¿Huh? ¡Whoa, espera un segundo!\""


translate english c5231_341dde3b:


    "Antes de que pueda reaccionar, Miyuki se marcha, dejándome con los boletos."


translate english c5231_953990b8:



    voice "voice/c52/3100170a01.opus"
    mx "\"No lo pienses dos veces. Solo hazlo.\""


translate english c5231_0c7168d8:



    voice "voice/c52/3100180a01.opus"
    mx "\"Si la riegas, tendrás otra oportunidad.\""


translate english c5231_49484485:


    "Con eso, baja por la escalera."


translate english c5231_e4568c2c:



    voice "voice/c52/3100190a02.opus"
    aoi "\"Miyuki, ¿a dónde vas?\""


translate english c5231_20e8342a:



    voice "voice/c52/3100200a01.opus"
    mx "\"Perdón... Hoy tengo reunión de comité.\""


translate english c5231_414e6bff:



    voice "voice/c52/3100210a01.opus"
    mx "\"Nos vemos.\""


translate english c5231_acc3260f:



    voice "voice/c52/3100220a02.opus"
    aoi "\"¡Adiós!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
