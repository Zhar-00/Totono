

translate english c5231_a4df1552:



    voice "voice/c52/3100010a01.opus"
    mx "\"Are you suspicious of Akebono-kun?\""


translate english c5231_46bc0fb0:


    xy "\"What?\""


translate english c5231_fac46706:


    "Esto es lo primero que Miyuki me dice después de que le cuento lo que pasó esta mañana."


translate english c5231_b51761cd:



    voice "voice/c52/3100020a01.opus"
    mx "\"You think he's trying to take Aoi for himself, is that it?\""


translate english c5231_c9506369:


    xy "\"No way. He's more interested in y—\""


translate english c5231_23bac140:



    voice "voice/c52/3100030a01.opus"
    mx "\"I already shot him down. And quite some time ago, too.\""


translate english c5231_21b27163:


    "Tiene razón. Por atractiva que sea, no hay garantía de que él la espere para siempre."


translate english c5231_93effd6c:


    "La mayoría de la gente probablemente intentaría encontrar a alguien más."


translate english c5231_0ea2df2b:


    xy "\"But why Aoi?\""


translate english c5231_e6d15046:



    voice "voice/c52/3100040a01.opus"
    mx "\"Who can say? People have their reasons.\""


translate english c5231_20d4ffe9:


    xy "\"But he helped me look for her the whole time!\""


translate english c5231_8eeb166f:



    voice "voice/c52/3100050a01.opus"
    mx "\"Isn't that part of why you suspect him?\""


translate english c5231_e3adb631:


    xy "\"What...?\""


translate english c5231_b03f3e07:


    "Pensé que era solo prueba de que él se preocupa por mí..."


translate english c5231_2ae89d47:


    "¿Podría tener razón Miyuki? ¿Podría haber tenido un motivo oculto?"


translate english c5231_85cea9f2:


    "No puede ser... No puede ser—"


translate english c5231_e43a61cb:


    xy "\"......Oh.\""


translate english c5231_e06cd379:


    "El día que llegué a casa a una casa vacía, Aoi apareció con leche de la tienda de la esquina."


translate english c5231_683f384f:


    "La tienda familiar de Yuutarou."


translate english c5231_202c5e4d:



    voice "voice/c52/3100060a01.opus"
    mx "\"You don't look so good.\""


translate english c5231_d95ea248:


    xy "\"...No, I'm fine.\""


translate english c5231_ee71e799:



    voice "voice/c52/3100070a01.opus"
    mx "\"Really? Because you don't look fine to me.\""


translate english c5231_843c3140:



    voice "voice/c52/3100080a01.opus"
    mx "\"Here, use this.\""


translate english c5231_a78669d8:


    "Me entrega boletos para la obra."


translate english c5231_ace31837:



    voice "voice/c52/3100090a01.opus"
    mx "\"Instead of just letting it eat at you, you might as well do something about it. It might turn out to be a simple misunderstanding.\""


translate english c5231_e6233483:



    voice "voice/c52/3100100a01.opus"
    mx "\"Rather than stewing in your feelings, you should just ask her out on a date.\""


translate english c5231_91b3044d:



    voice "voice/c52/3100110a02.opus"
    aoi "\"Kitty punch attack! Meow!\""


translate english c5231_86735374:



    voice "voice/c52/3100130a02.opus"
    aoi "\"Meow! Meow! Meow!\""


translate english c5231_630c1b52:


    "Meanwhile, Aoi practices her \"kitty punch attack\"con Eru."



translate english c5231_a2b02fbc:


    "Las cosas están tan incómodas entre nosotros ahora..."


translate english c5231_ba946912:


    "¿Cómo podría invitarla a una cita, de todas las cosas?"


translate english c5231_62e0e7df:



    voice "voice/c52/3100140a01.opus"
    mx "\"Maybe you should save the game?\""


translate english c5231_696246e4:



    voice "voice/c52/3100150a01.opus"
    mx "\"That way, if you screw up, you can just try again.\""


translate english c5231_8cfa3631:


    "Sé que está bromeando, pero... me hace pausar."


translate english c5231_bdd3abe8:


    "If only I could \"save my progress\"en la vida real... Todo sería mucho más fácil..."



translate english c5231_84329fcc:


    "Podría simplemente recargar mi partida y darle otra oportunidad..."


translate english c5231_5d3d89f3:


    "Con un poder así, nunca necesitaría vacilar."


translate english c5231_bd1335e0:



    voice "voice/c52/3100160a01.opus"
    mx "\"Well, I'm gonna get going.\""


translate english c5231_288fbd5f:


    xy "\"Huh? Whoa, hold on a sec!\""


translate english c5231_341dde3b:


    "Antes de que pueda reaccionar, Miyuki se marcha, dejándome con los boletos."


translate english c5231_953990b8:



    voice "voice/c52/3100170a01.opus"
    mx "\"Don't think twice. Just do it.\""


translate english c5231_0c7168d8:



    voice "voice/c52/3100180a01.opus"
    mx "\"If you mess up, you'll get another chance.\""


translate english c5231_49484485:


    "Con eso, baja por la escalera."


translate english c5231_e4568c2c:



    voice "voice/c52/3100190a02.opus"
    aoi "\"Miyuki, where are you going?\""


translate english c5231_20e8342a:



    voice "voice/c52/3100200a01.opus"
    mx "\"Sorry... I have a committee meeting today.\""


translate english c5231_414e6bff:



    voice "voice/c52/3100210a01.opus"
    mx "\"See you later.\""


translate english c5231_acc3260f:



    voice "voice/c52/3100220a02.opus"
    aoi "\"Bye-bye!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
