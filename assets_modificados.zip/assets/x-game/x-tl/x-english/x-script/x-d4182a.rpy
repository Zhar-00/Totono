

translate english d4182a_ba0529d7:


    "Y así aparece un testigo—en el lugar más insospechado."


translate english d4182a_a43fd39b:


    "Según Haru-chan, esa noche lluviosa, ella estaba en la caja cuando Aoi apareció, con un gatito."


translate english d4182a_4369a028:


    "El gatito estaba muerto de hambre, y Aoi quería alimentarlo."


translate english d4182a_fa0b8068:


    "Así empezó su amistad, e incluso después de que Aoi dejara de ir a la escuela, Haru-chan se la encontró un puñado de veces."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
