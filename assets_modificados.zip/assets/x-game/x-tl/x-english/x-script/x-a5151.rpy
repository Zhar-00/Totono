

translate english a5151_c5cad617:



    voice "voice/a51/5100010b01.opus"
    xtl "\"¡Shinichi! ¿Quieres pasar por los arcades...?\""


translate english a5151_5aa16271:


    xy "\"Perdón, ya tengo planes.\""


translate english a5151_fb0f326b:



    voice "voice/a51/5100020b01.opus"
    xtl "\"Ah, está bien.\""


translate english a5151_f0329713:


    xy "\"¡Nos vemos!\""


translate english a5151_fe79cea3:


    "En cuanto termina la clase, agarro mis cosas y me pongo de pie de un salto."


translate english a5151_b18390e7:


    "Aoi todavía no ha vuelto a la escuela."


translate english a5151_32425cd9:


    "¿Habré tomado la decisión equivocada anoche...?"


translate english a5151_69e92b24:


    "Recojo a Eru de la azotea y luego me dirijo al manga café."


translate english a5151_f1462624:


    "Cuando pregunto por Aoi, los empleados de inmediato saben exactamente a quién me refiero. Me dicen que salió del café esta mañana temprano y no ha vuelto."


translate english a5151_fd5be70c:


    "Según ellos, no parecía particularmente enferma."


translate english a5151_905ec2a1:


    "Entonces, ¿por qué no ha estado viniendo a la escuela?"


translate english a5151_0ed6961f:


    "¿Volvió a la casa de sus padres?"


translate english a5151_a9b0fc7f:


    "¿O le está pasando algo más?"


translate english a5151_7914d4c2:


    "...Ninguna cantidad de teorías me va a ayudar a encontrar la respuesta."


translate english a5151_74b05114:


    "Simplemente no sé lo suficiente sobre ella, así de simple."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
