

translate english c6172_a21401ae:



    voice "voice/c61/7200010a01.opus"
    mx "\"Aoi tiró a la basura su cita contigo para ir a ver a otro hombre.\""


translate english c6172_4fadd56f:


    "Miyuki me restriega la fría y dura realidad en la cara."


translate english c6172_46462b1f:


    "Por inútil que sea, aún intento esconder la cabeza en la arena."


translate english c6172_c963824d:


    xy "Ya sabes, una pequeña y divertida—\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
