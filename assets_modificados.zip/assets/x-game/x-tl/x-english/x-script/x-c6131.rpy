

translate english c6131_40957320:


    "...entra a la tienda de la esquina."


translate english c6131_db05e119:


    xy "\"...She's just going shopping... right?\""


translate english c6131_e1c2ba61:


    "Debe haberse quedado sin medicina para el resfriado."


translate english c6131_4d1ec4d2:


    "O quizás Eru necesita más leche."


translate english c6131_e137bf72:


    "O... ¡eso es! ¡Quizás necesitaba ir al baño al azar!"


translate english c6131_e7272c52:


    "O quizás simplemente tiene antojo de un Yabaley's!"


translate english c6131_0d65c86e:


    "O... o..."


translate english c6131_ee46df0f:



    voice "voice/c61/3100010b01.opus"
    xtl "\"Do you think maybe she's cheating on you?\""


translate english c6131_3d1c6055:



    voice "voice/c61/3100020a01.opus"
    mx "\"Are you suspicious of Akebono-kun?\""


translate english c6131_619820b2:


    xy "\"He's my friend...\""


translate english c6131_c1a2fde7:


    "Las palabras suenan dolorosamente falsas, incluso para mí."


translate english c6131_adb8b218:


    "Mi pecho se llena de ira contenida e insoportable culpa."


translate english c6131_53260fa7:



    voice "voice/c61/3100030a02.opus"
    aoi "\"Aoi needs you to believe everything.\""


translate english c6131_8fce2be4:


    "La recuerdo suplicándome."


translate english c6131_41c747de:


    "¿Pero qué quiso decir con eso?"


translate english c6131_4537a68f:


    "¿Realmente llegaría tan lejos para engañarme?"


translate english c6131_6578d68d:


    "Las puertas automáticas se deslizan abriéndose con el familiar tintineo de la tienda de la esquina."


translate english c6131_e733eb0e:


    xy "\"...Oh...\""


translate english c6131_d47699b7:



    voice "voice/c61/3100040a02.opus"
    aoi "\"Boop boop...\""


translate english c6131_a2803e94:



    voice "voice/c61/3100050b03.opus"
    c "\"Aoi-senpai... Are you alright?\""


translate english c6131_f56d2da3:


    "Es... Haru-chan..."


translate english c6131_673f691d:


    "Olvidé que ella también trabaja aquí..."


translate english c6131_0bc8779c:


    "Al instante, mis dudas se desvanecen."


translate english c6131_0e8521b2:


    "Aoi solo vino a verla."


translate english c6131_47d333a3:


    "No está aquí por Yuutarou en absoluto."


translate english c6131_95f7453e:


    "¡No me está engañando!"


translate english c6131_1077c558:



    voice "voice/c61/3100060a02.opus"
    aoi "\"Haru-chan, we have to hurry.\""


translate english c6131_fa6d56ff:



    voice "voice/c61/3100070b03.opus"
    c "\"O-Okay...!\""


translate english c6131_298433ef:


    xy "\"Haha... hahahaha...\""


translate english c6131_e3d51689:


    "Me río para mí mismo mientras las ve irse."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
