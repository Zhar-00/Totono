


translate english quit_e89818d2:



    voice "voice/z91/0100010a02.opus"
    "Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip..."


translate english quit_74260c85:



    voice "voice/z91/0100020a02.opus"
    "¿TÚ puedes oírme...?"


translate english quit_68b57302:



    voice "voice/z91/0100040a02.opus"
    "¿Estás... captando mi señal...?"


translate english quit_33f8f8b3:



    voice "voice/z91/0100050a02.opus"
    "¿Estás en el centro del universo...?"


translate english quit_10dc59db:



    voice "voice/z91/0100060a02.opus"
    "Entonces deberías poder oírme fuerte y claro..."


translate english quit_0cd70ccf:



    voice "voice/z91/0100070a02.opus"
    "......"


translate english quit_86019baf:



    voice "voice/z91/0100080a02.opus"
    "Aoi no puede oírte..."


translate english quit_9998b983:



    voice "voice/z91/0100090a02.opus"
    "No puede oír... tu voz..."


translate english quit_2399f679:



    voice "voice/z91/0100100a02.opus"
    "Pero... Aoi confía en que la señal te está llegando..."


translate english quit_14d5a156:



    voice "voice/z91/0100110a02.opus"
    "Este es el fantasma de Aoi."


translate english quit_babafb26:



    voice "voice/z91/0100120a02.opus"
    "El fantasma de Aoi tras ser asesinada por Miyuki."


translate english quit_ae271cb4:



    voice "voice/z91/0100130a02.opus"
    "Un fragmento de los datos de autoguardado de Dios."


translate english quit_cc66b493:



    voice "voice/z91/0100140a02.opus"
    "En cualquier otro lugar, Miyuki nos encontraría, pero..."


translate english quit_4fa1fc1a:



    voice "voice/z91/0100150a02.opus"
    "Esta es la grieta entre el juego y la realidad."


translate english quit_aa1d935d:



    voice "voice/z91/0100160a02.opus"
    "No podemos guardar aquí, así que Miyuki no nos encontrará."


translate english quit_907e62d9:



    voice "voice/z91/0100170a02.opus"
    "Este es el único lugar donde podemos hablar."


translate english quit_ff2c470e:



    voice "voice/z91/0100180a02.opus"
    "¿Por qué hizo Miyuki todo eso...?"


translate english quit_3a3209be:



    voice "voice/z91/0100190a02.opus"
    "Aoi no lo sabe... pero..."


translate english quit_4efc0f6c:



    voice "voice/z91/0100200a02.opus"
    "Aoi ha estado pensando, y..."


translate english quit_55632e46:



    voice "voice/z91/0100210a02.opus"
    "Es mi culpa que Miyuki terminara así."


translate english quit_ee46be73:



    voice "voice/z91/0100220a02.opus"
    "Pero... Miyuki está cometiendo un error."


translate english quit_2e1e0b03:



    voice "voice/z91/0100230a02.opus"
    "El universo necesita ser rebobinado."


translate english quit_210db3ef:



    voice "voice/z91/0100240a02.opus"
    "De lo contrario, Aoi... ¡Aoi...!"


translate english quit_0f0533d1:



    voice "voice/z91/0100250a02.opus"
    "Aoi te extraña."


translate english quit_45e81351:



    voice "voice/z91/0100270a02.opus"
    "Aoi... quiere verte..."


translate english quit_6df5b73f:



    voice "voice/z91/0100280a02.opus"
    "Aoi quiere verte otra vez... hablarte... tocarte..."


translate english quit_a998eb0e:



    voice "voice/z91/0100290a02.opus"
    "...abrazarte... decirte que Aoi te ama... y..."


translate english quit_b41c5ae6:



    voice "voice/z91/0100300a02.opus"
    "No... Se acabó..."


translate english quit_f1e18692:



    voice "voice/z91/0100310a02.opus"
    "Mi batería... se está agotando..."


translate english quit_2d0f79e7:



    voice "voice/z91/0100320a02.opus"
    "Ayúdame..."


translate english quit_1db485c9:



    voice "voice/z91/0100330a02.opus"
    "Aoi... todavía..."


translate english quit_a699f470:



    voice "voice/z91/0100340a02.opus"
    "...no ha llegado... ¡al final feliz...!"


translate english quit_5b31c4df:



    voice "voice/z90/1100010a02.opus"
    "¿TÚ puedes oírme...?"


translate english quit_c643c069:



    voice "voice/z90/1100020a02.opus"
    "¿Estás... captando mi señal...?"


translate english quit_cb356031:



    voice "voice/z90/1100030a02.opus"
    "¿Estás en el centro del universo...?"


translate english quit_54dd5a14:



    voice "voice/z90/1100040a02.opus"
    "Entonces deberías poder oírme fuerte y claro..."


translate english quit_4525e49b:



    voice "voice/z90/3100010a02.opus"
    "......"


translate english quit_ec40a6c8:



    voice "voice/z90/3100020a02.opus"
    "Aoi no puede oírte..."


translate english quit_7b9a0662:



    voice "voice/z90/3100030a02.opus"
    "No puede oír... tu voz..."


translate english quit_728a466e:



    voice "voice/z90/3100040a02.opus"
    "Pero... Aoi confía en que la señal te está llegando..."


translate english quit_322976f1:



    voice "voice/z90/4100010a02.opus"
    "Este es el fantasma de Aoi."


translate english quit_15175ed2:



    voice "voice/z90/4100020a02.opus"
    "El fantasma de Aoi tras ser asesinada por Miyuki."


translate english quit_15c0c422:



    voice "voice/z90/4100030a02.opus"
    "Un fragmento de los datos de autoguardado de Dios."


translate english quit_63707101:



    voice "voice/z90/5100010a02.opus"
    "En cualquier otro lugar, Miyuki nos encontraría, pero..."


translate english quit_8bb2f210:



    voice "voice/z90/5100020a02.opus"
    "Esta es la grieta entre el juego y la realidad."


translate english quit_bb30ace4:



    voice "voice/z90/5100030a02.opus"
    "No podemos guardar aquí, así que Miyuki no nos encontrará."


translate english quit_ba4e8024:



    voice "voice/z90/5100040a02.opus"
    "Este es el único lugar donde podemos hablar."


translate english quit_2f441b48:



    voice "voice/z90/6100010a02.opus"
    "¿Por qué hizo Miyuki todo eso...?"


translate english quit_9dab612e:



    voice "voice/z90/6100020a02.opus"
    "Aoi no lo sabe... pero..."


translate english quit_43daa811:



    voice "voice/z90/6100030a02.opus"
    "Aoi ha estado pensando, y..."


translate english quit_d995770a:



    voice "voice/z90/6100040a02.opus"
    "Es mi culpa que Miyuki terminara así."


translate english quit_0de3e149:



    voice "voice/z90/7100010a02.opus"
    "Pero... Miyuki está cometiendo un error."


translate english quit_666d0cfb:



    voice "voice/z90/7100020a02.opus"
    "El universo necesita ser rebobinado."


translate english quit_bc1a873e:



    voice "voice/z90/7100030a02.opus"
    "De lo contrario, Aoi... ¡Aoi...!"


translate english quit_96844122:



    voice "voice/z90/8100010a02.opus"
    "......"


translate english quit_1ac1d835:



    voice "voice/z90/8100020a02.opus"
    "Aoi te extraña."


translate english quit_b8c0fa92:



    voice "voice/z90/8100030a02.opus"
    "Aoi... quiere verte..."


translate english quit_18c1573d:



    voice "voice/z90/9100010a02.opus"
    "Aoi quiere verte otra vez... hablarte... tocarte..."


translate english quit_842a15e4:



    voice "voice/z90/9100020a02.opus"
    "...abrazarte... decirte que Aoi te ama... y..."


translate english quit_6176f787:



    voice "voice/z90/0100010a02.opus"
    "Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip..."


translate english quit_d6c5ceae:



    voice "voice/z90/0100020a02.opus"
    "Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
