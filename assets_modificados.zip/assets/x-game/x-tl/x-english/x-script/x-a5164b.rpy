

translate english a5164b_54f2bde7:


    "Lo que estoy a punto de decir la va a lastimar."


translate english a5164b_8f9d3bca:


    "Va a alterar nuestra amistad... de forma permanente."


translate english a5164b_01ac69fd:


    "Lo sé."


translate english a5164b_b54a882e:


    "Pero... soy su amigo."


translate english a5164b_15d812b3:


    "Si me importa tanto como digo, entonces debería decirle la verdad."


translate english a5164b_a4978c8c:


    "Your \"god\"no es real, Aoi."


translate english a5164b_0874a850:


    "¿Todo eso de las baterías y las transmisiones? Es solo tu fantasía inventada."


translate english a5164b_904deab0:


    "Los videojuegos no son lo mismo que la vida real."


translate english a5164b_645fb26b:


    "Tú solo—"


translate english a5164b_54441561:


    xy "\"Aoi... All that stuff is—\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
