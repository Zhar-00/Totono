

translate english c4222_6318eca2:


    "No está respirando."


translate english c4222_a28bb405:


    "Nunca tomé ningún curso de primeros auxilios, así que básicamente estoy improvisando, pero—"


translate english c4222_24888556:


    xy "\"¡Jaaaa...!\""


translate english c4222_0ad3bc5d:


    "Tomo una gran bocanada de aire—"


translate english c4222_864ead92:


    xy "\"¡Pfffffff...!\""


translate english c4222_5b1f8644:


    "—y presiono mis labios contra los suyos."


translate english c4222_d91aa278:


    "Una chispa de electricidad me recorre."


translate english c4222_0befc96d:


    "Rezando por un milagro, soplo el aire de mis pulmones dentro de ella."


translate english c4222_cda15acf:


    "¡Despierta, Aoi! ¡Por favor!"


translate english c4222_0aadae0d:


    "¡Hay algo que aún no te he dicho!"


translate english c4222_d972c317:


    "¡No quiero que termine así!"


translate english c4222_04ce3aef:


    xy "\"¿Mmm...? ¿¡Mmmn!? ¡Mmmnnn!\""


translate english c4222_b812f82a:



    voice "voice/c42/2200010a02.opus"
    aoi "\"Mm... mmng... mmm...\""


translate english c4222_1083bb06:


    "Siento algo moverse contra mis labios."


translate english c4222_552f968d:


    "Aoi parpadea."


translate english c4222_8d5915c5:


    "Finalmente, su pecho empieza a subir y bajar una vez más."


translate english c4222_45124b74:



    voice "voice/c42/2200020a02.opus"
    aoi "\"Bip... ¿bip bip...?\""


translate english c4222_162362f0:


    xy "\"¡O-Oye! ¡Aoi! ¡Soy yo! ¿Me puedes oír?\""


translate english c4222_1c43ec5b:



    voice "voice/c42/2200030a02.opus"
    aoi "\"¿Shin...ichi...?\""


translate english c4222_136ff641:


    xy "\"¡Sí! ¡Soy yo, Shinichi!\""


translate english c4222_83ce6b7d:



    voice "voice/c42/2200040a02.opus"
    aoi "\"¿Por qué... estás... aquí...?\""


translate english c4222_2365ac7b:


    xy "\"¡Capté tu transmisión!\""


translate english c4222_4b43e1e6:



    voice "voice/c42/2200050a02.opus"
    aoi "\"¿Mi transmisión...?\""


translate english c4222_42fef590:


    "Eru maúlla en su oído."


translate english c4222_f0136a38:



    voice "voice/c42/2200070a02.opus"
    aoi "\"Oh...\""


translate english c4222_3469eb43:



    voice "voice/c42/2200080a02.opus"
    aoi "\"¿Mi transmisión... te llegó a ti... en lugar de a Dios...?\""


translate english c4222_fefa6114:


    xy "\"Al parecer sí.\""


translate english c4222_1dbd683a:



    voice "voice/c42/2200090a02.opus"
    aoi "\"Mi cuerpo... está todo... chispeante...\""


translate english c4222_61c3957f:



    voice "voice/c42/2200100a02.opus"
    aoi "\"¿Me... recargaste...?\""


translate english c4222_5df275c3:


    xy "\"¿A qué te refieres?\""


translate english c4222_e4ec6428:



    voice "voice/c42/2200110a02.opus"
    aoi "\"La batería de Aoi... se agotó...\""


translate english c4222_d8f30276:


    xy "\"Oh... ya veo...\""


translate english c4222_88e7fb81:


    "Me alegra que esté consciente, pero es demasiado pronto para relajarse."


translate english c4222_5cd83c49:


    "Saco mi teléfono—"


translate english c4222_e58ad9b2:



    voice "voice/c42/2200120a02.opus"
    aoi "\"No tiene caso llamar a una ambulancia.\""


translate english c4222_236a399c:


    xy "\"¿Cómo que no tiene caso?\""


translate english c4222_14c13716:



    voice "voice/c42/2200130a02.opus"
    aoi "\"Solo quédate conmigo.\""


translate english c4222_1728d9b1:



    voice "voice/c42/2200140a02.opus"
    aoi "\"Así Aoi puede recargarse.\""


translate english strings:


    old "Всё равно позвонить в скорую"
    new "Llamar a una ambulancia de todos modos"


    old "Поговорить с Аой"
    new "Hablar con Aoi"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
