

translate english e2225d_b6382c0d:



    voice "voice/e22/25d00010a01.opus"
    mx "Aah... nnn... nngghh... nn... Te corriste dentro de mí otra vez..."



translate english e2225d_3ca79e75:



    voice "voice/e22/25d00020a01.opus"
    mx "Parece que... disfrutas follarme con este atuendo..."


translate english e2225d_0a4b7a21:



    voice "voice/e22/25d00030a01.opus"
    mx "Supongo que te gusta bastante..."


translate english e2225d_7d567fc5:



    voice "voice/e22/25d00040a01.opus"
    mx "Bueno... por mí está bien..."


translate english e2225d_2833df98:



    voice "voice/e22/25d00050a01.opus"
    mx "Podemos hacer esto... cuantas veces quieras..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
