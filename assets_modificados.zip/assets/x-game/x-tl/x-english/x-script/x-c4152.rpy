

translate english c4152_87619034:


    "Intenté preguntarle a mi maestro de grupo sobre Aoi, pero lo único que me dijo fue \"We haven't heard anything from her.\""


translate english c4152_f39b05eb:


    "Nadie sabe nada sobre la situación de su familia, tampoco."


translate english c4152_3f5bc231:


    "Aparentemente nadie más tenía idea de que se estaba quedando en un café de manga, para empezar."


translate english c4152_e96a73ff:


    "Desde entonces..."


translate english c4152_081020ed:


    "I've gone up to the \"center of the universe\"exactamente una vez."


translate english c4152_91f0000a:


    "Pensé que quizá, si la llamaba desde ahí arriba, mi señal podría alcanzarla."


translate english c4152_754249f9:


    "Sé que era solo cerebro de gamer. Básicamente solo esperaba un milagro."


translate english c4152_f46c7124:


    "Pero sin importar cuántas veces lo intenté..."


translate english c4152_47057eb6:


    "...la llamada nunca pasó."


translate english c4152_8163ce7a:


    "All I got were \"out of service\"mensajes de error."


translate english c4152_b7eafb50:


    "Pero así son las cosas, ¿verdad?"


translate english c4152_097d954f:


    "Alguien nuevo entra en tu vida..."


translate english c4152_22d33633:


    "...y luego, antes de que te des cuenta, se ha ido."


translate english c4152_7763590a:


    "Otra persona viene, otra persona se va."


translate english c4152_3a3170dd:


    "Una y otra y otra vez."


translate english c4152_3e2b56f4:


    "¿Y qué si se fue? Nada ha cambiado."


translate english c4152_a988d8e0:


    "Si acaso, las cosas simplemente volvieron a la normalidad."


translate english c4152_d8ab3150:


    "Aoi ya no está en mi vida."


translate english c4152_1bbff5e7:


    "Eso es todo."


translate english c4152_bd44ff76:


    "Seguro me acostumbraré pronto."


translate english c4152_f60225f3:


    "Me acostumbraré pronto..."


translate english c4152_52e0fa68:


    "Me acostumbraré..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
