

translate english e1165c_e09d526f:



    voice "voice/e11/6500590a01.opus"
    mx "\"...Oh dear.\""


translate english e1165c_f043112b:



    voice "voice/e11/6500600a01.opus"
    mx "\"You tricked me.\""


translate english e1165c_78956eae:


    "¡No te engañé por diversión, créeme!"


translate english e1165c_39e7c143:


    "Pero..."


translate english e1165c_9d53f961:



    voice "voice/e11/6500610a02.opus"
    aoi "\"No! NOOO...!\""


translate english e1165c_689456e4:



    voice "voice/e11/6500620a02.opus"
    aoi "\"Don't erase me...!\""


translate english e1165c_06bd3da5:



    voice "voice/e11/6500630a02.opus"
    aoi "\"Aoi doesn't... want to disappear...\""


translate english e1165c_08f62c6d:


    "Miyuki borró a Aoi de la realidad."


translate english e1165c_3ab56e0e:


    "No sé qué pasó... o cómo pudo hacerlo en primer lugar..."


translate english e1165c_0bb14279:


    "...pero no puedo simplemente dejarlo pasar."


translate english e1165c_a50c2693:


    "Miyuki está desquiciada."


translate english e1165c_fbe17397:


    "Pero es una vieja amiga mía... y mi novia."


translate english e1165c_6de7e9eb:


    "Lo cual significa que tengo que ser yo quien arregle esto."


translate english e1165c_710c9e34:



    voice "voice/e11/6500640a01.opus"
    mx "\"Seeing as you tricked me...\""


translate english e1165c_7c35f41e:



    voice "voice/e11/6500650a01.opus"
    mx "\"I guess that means you'll need to be punished.\""


translate english e1165c_fe683a75:


    "¡Paso, gracias!"


translate english e1165c_95452410:


    "Ahora a salir de la escuela—"


translate english e1165c_69657135:


    xy "\"—!!!\""


translate english e1165c_39c93207:


    "Sé que estas puertas estaban abiertas cuando entré..."


translate english e1165c_58491889:


    "Pero ahora están todas cerradas por alguna razón..."


translate english e1165c_94f824f7:



    voice "voice/e11/6500660a01.opus"
    mx "\"Where do you think you're going?\""


translate english e1165c_774b8bd8:



    voice "voice/e11/6500670a01.opus"
    mx "\"Please. There's nowhere to run.\""


translate english e1165c_f14ebbd2:


    "Claro que sí."


translate english e1165c_6b2e82a2:


    "Si no puedo salir por el frente, tendré que—"


translate english e1165c_9113f163:



    voice "voice/e11/6500680a01.opus"
    mx "\"Found you.\""


translate english e1165c_76d897ba:


    xy "\"—?!\""


translate english e1165c_1b97db34:


    "¡Esto no puede estar bien!"


translate english e1165c_2e89cdaf:


    "Corro como si mi vida dependiera de ello..."


translate english e1165c_ce305495:


    "...¡pero ella ni siquiera está sin aliento!"


translate english e1165c_9bc89bb5:


    "¿Cómo...?"


translate english e1165c_d5e589f1:


    "¿Cómo me alcanzó tan fácilmente?"


translate english e1165c_b215f776:


    "Corro a través de mi retorcido mundo."


translate english e1165c_9785d470:


    "Aferrando el teléfono de Miyuki en mi mano."


translate english e1165c_efe93764:


    "Pero no puedo escapar."


translate english e1165c_705cb3ae:


    "La entrada trasera... El gimnasio... El pasillo de conexión..."


translate english e1165c_d501d71f:


    "Están todos bien cerrados."


translate english e1165c_a37e46c6:


    "Y las ventanas tampoco abren."


translate english e1165c_f5b919c9:


    "No hay salida."


translate english e1165c_4d59e024:



    voice "voice/e11/6500690a01.opus"
    mx "\"It's no use.\""


translate english e1165c_73ba1e6a:



    voice "voice/e11/6500700a01.opus"
    mx "\"I've sealed all the exits.\""


translate english e1165c_53463bfc:


    "Eso es imposible."


translate english e1165c_61bb1b54:


    "Y sin embargo... en efecto, estoy atrapado aquí."


translate english e1165c_43724e08:


    "La voz de Miyuki me encuentra sin importar a dónde vaya."


translate english e1165c_410f27b9:


    "Ya no tengo sentido de la distancia."


translate english e1165c_09bfded7:


    "Sin importar a dónde corra, prácticamente puedo ver a Miyuki asomándose más adelante."


translate english e1165c_84453c40:


    "No..."


translate english e1165c_23cb9f5c:



    voice "voice/e11/6500710a01.opus"
    mx "\"I told you, it's no use.\""


translate english e1165c_69657135_1:


    xy "\"—!!!\""


translate english e1165c_0663a527:


    "Retrocedo apresuradamente."


translate english e1165c_01623467:


    "Miyuki no parece tener la más mínima prisa, y sin embargo me gana en cada ocasión."


translate english e1165c_796022bd:


    "¡A este paso, nunca escaparé de ella!"


translate english e1165c_77cb94b5:



    voice "voice/e11/6500720a02.opus"
    aoi "\"My code number.\""


translate english e1165c_ec2b4e6a:



    voice "voice/e11/6500730a02.opus"
    aoi "\"Put it... in Miyuki's phone...\""


translate english e1165c_a2ff92db:



    voice "voice/e11/6500740a02.opus"
    aoi "\"And... bring me... back...\""


translate english e1165c_e80edfbc:


    xy "\"...That's it!\""


translate english e1165c_b0f63bce:


    "¡No NECESITO correr!"


translate english e1165c_560acced:


    "Mi objetivo es traer a Aoi de vuelta a la realidad."


translate english e1165c_9e520c84:


    "¡Así que solo necesito ganar algo de tiempo hasta poder hacer una llamada!"


translate english e1165c_8a68b341:


    "Una puerta entreabierta llama mi atención."


translate english e1165c_c8dc4465:


    "Corro al salón y cierro cuidadosamente la puerta para que no haga ruido."


translate english e1165c_fc194fd0:


    "Este no es nuestro salón."


translate english e1165c_29446173:


    "Es un salón de primer año, en el que nunca he puesto un pie."


translate english e1165c_651b8132:


    "Ahora que estoy aquí, Miyuki no debería poder verme."


translate english e1165c_0115ed9b:


    "Lo cual significa que debería tener tiempo para llamar a Aoi—"


translate english e1165c_ec04b9a7:



    voice "voice/e11/6500750a01.opus"
    mx "\"I know you, Shinichi.\""


translate english e1165c_973a8ae8:



    voice "voice/e11/6500760a01.opus"
    mx "\"And I can predict your every move.\""


translate english e1165c_03f0aef6:


    "Los pasos de Miyuki persisten."


translate english e1165c_8fe25b9a:


    "¿Cómo...?"


translate english e1165c_8e72a050:


    "¿Cómo sabe en qué piso estoy?"


translate english e1165c_977dba7e:


    "Es casi como si supiera de antemano a dónde iré..."


translate english e1165c_95bd476f:


    "Espera, ¿qué estoy haciendo? ¡No tengo tiempo para preocuparme por eso!"


translate english e1165c_e9342e44:


    "Me escondo detrás del atril del profesor y saco el teléfono de Miyuki."


translate english e1165c_7c804e53:


    "Antes de desaparecer, me dijo que usara su número de código."


translate english e1165c_196b41d9:


    "Y ese número es—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
