

translate english c3192_9a6f04fa:


    xy "\"Okay, ahora súbete a mis hombros, y—\""


translate english c3192_2312e807:



    voice "voice/c31/9200010a02.opus"
    aoi "\"Bip bip...? ¿Está cerrado?\""


translate english c3192_b88b62ab:


    xy "\"Claro que está cerrado. Es de noche.\""


translate english c3192_049e0592:



    voice "voice/c31/9200020a02.opus"
    aoi "\"Pero Aoi lo abrió antes.\""


translate english c3192_67dddbfc:


    xy "\"¿Qué? No hay forma de que pudieras abrir—\""


translate english c3192_df0136c3:



    voice "voice/c31/9200030a02.opus"
    aoi "\"Ahí.\""


translate english c3192_545367b3:


    xy "\"...¿Qué?\""


translate english c3192_0d7f0c9d:


    "Y, en efecto, el candado se abre de golpe."


translate english c3192_fe80f342:



    voice "voice/c31/9200040a02.opus"
    aoi "\"Esta cosa es útil.\""


translate english c3192_4d16ac52:


    "Levanta la horquilla de gatito que le di."


translate english c3192_17698b89:


    "Cuando me dijo que la llevaría en el bolsillo para guardarla, ¡no pensé que la usaría para ALGO así!"


translate english c3192_4e52ae70:


    xy "\"¿Así es como abres también la puerta de la azotea?\""


translate english c3192_d637550d:



    voice "voice/c31/9200050a02.opus"
    aoi "\"Sip.\""


translate english c3192_d8f5851f:


    "Su inocencia infantil en realidad da un poco de miedo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
