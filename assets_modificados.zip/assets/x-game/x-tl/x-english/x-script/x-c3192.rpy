

translate english c3192_9a6f04fa:


    xy "\"Okay, now you get on my shoulders, and—\""


translate english c3192_2312e807:



    voice "voice/c31/9200010a02.opus"
    aoi "\"Boop boop...? Is it locked?\""


translate english c3192_b88b62ab:


    xy "\"Of course it's locked. It's nighttime.\""


translate english c3192_049e0592:



    voice "voice/c31/9200020a02.opus"
    aoi "\"But Aoi unlocked it earlier.\""


translate english c3192_67dddbfc:


    xy "\"What? There's no way you could unlock—\""


translate english c3192_df0136c3:



    voice "voice/c31/9200030a02.opus"
    aoi "\"There.\""


translate english c3192_545367b3:


    xy "\"...What?\""


translate english c3192_0d7f0c9d:


    "Y, en efecto, el candado se abre de golpe."


translate english c3192_fe80f342:



    voice "voice/c31/9200040a02.opus"
    aoi "\"This thing comes in handy.\""


translate english c3192_4d16ac52:


    "Levanta la horquilla de gatito que le di."


translate english c3192_17698b89:


    "Cuando me dijo que la llevaría en el bolsillo para guardarla, ¡no pensé que la usaría para ALGO así!"


translate english c3192_4e52ae70:


    xy "\"Is that how you unlock the roof door, too?\""


translate english c3192_d637550d:



    voice "voice/c31/9200050a02.opus"
    aoi "\"Yup.\""


translate english c3192_d8f5851f:


    "Su inocencia infantil en realidad da un poco de miedo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
