

translate english a2171_feb53965:



    voice "voice/a21/7100010a01.opus"
    mx "\"Oh, that reminds me!\""


translate english a2171_9618cd1b:


    "Justo cuando pasamos las rejas de la escuela, Miyuki se detiene en seco."


translate english a2171_c6cdbd08:



    voice "voice/a21/7100020a01.opus"
    mx "\"Sorry, I forgot something. You two wait here.\""


translate english a2171_f881d93e:


    "De inmediato gira sobre sus talones y regresa por donde vinimos."


translate english a2171_39ddd6e8:


    xy "\"Miyuki forgot something? That's unusual.\""


translate english a2171_48f9d118:



    voice "voice/a21/7100030a02.opus"
    aoi "\"Maybe your two-timing traumatized her?\""


translate english a2171_98f2d718:


    xy "\"I told you, Miyuki and I are just friends! It's impossible to 'two-time' someone you aren't dating!\""


translate english a2171_faceb40b:



    voice "voice/a21/7100040a02.opus"
    aoi "\"Got it!\""


translate english a2171_14e70a8b:


    "La mano de Aoi se dispara hacia el cielo del atardecer, recta como una flecha."


translate english a2171_92a83fea:



    voice "voice/a21/7100050a02.opus"
    aoi "\"There's a bug in Miyuki's route.\""


translate english a2171_7257b8f4:



    voice "voice/a21/7100060a02.opus"
    aoi "\"You act like you don't want to get closer to her.\""


translate english a2171_8ff4b9b9:



    voice "voice/a21/7100070a02.opus"
    aoi "\"But that's only because you secretly DO want to.\""


translate english a2171_c4cdb4fe:



    voice "voice/a21/7100080a02.opus"
    aoi "\"Right?\""


translate english a2171_0accd139:


    xy "\"......\""


translate english a2171_3e3f5124:


    "Ahora que todos somos amigos, es fácil olvidar que el verdadero objetivo de Aoi es hacer de Cupido entre Miyuki y yo."


translate english a2171_e26203e8:


    xy "\"It's not cool to treat real-life people like routes in a visual novel.\""


translate english a2171_60d22f41:


    xy "\"People don't exist just so you can date them.\""


translate english a2171_31eaffe2:



    voice "voice/a21/7100090a02.opus"
    aoi "\"Aoi does, though.\""


translate english a2171_cd5e68e3:



    voice "voice/a21/7100100a02.opus"
    aoi "\"Aoi was made to fall in love and have sex.\""


translate english a2171_a2bfc28e:



    voice "voice/a21/7100110a02.opus"
    aoi "\"That's the whole reason God created me.\""


translate english a2171_5148aa96:


    xy "\"No it isn't!\""


translate english a2171_9d7e1cdc:


    "Me niego a creerlo."


translate english a2171_6482b93a:



    voice "voice/a21/7100120a02.opus"
    aoi "\"Too shy to admit it? Or... boop boop!\""


translate english a2171_d58effd4:



    voice "voice/a21/7100130a02.opus"
    aoi "\"Do you want to fuck me?\""


translate english a2171_62d467ed:


    xy "\"Excuse me?\""


translate english a2171_0d48dc9d:



    voice "voice/a21/7100140a02.opus"
    aoi "\"Aoi's a romance option too, you know. Aoi can get you off, no problem.\""


translate english a2171_ac90e74f:



    voice "voice/a21/7100150a02.opus"
    aoi "\"Handjobs are fun. Titjobs feel great. Footjobs, anal, it's all on the table.\""


translate english a2171_0a89fee1:



    voice "voice/a21/7100160a02.opus"
    aoi "\"Aoi's mouth is small, but it can fit a lot. Slurp slurp, up and down!\""


translate english a2171_e4ff5fa2:



    voice "voice/a21/7100170a02.opus"
    aoi "\"You can ram it right down my throat. It'll feel so good, you'll cum instantly—\""


translate english a2171_19a1f95b:


    xy "\"Stop talking like that!\""


translate english a2171_7c5d7d0d:



    voice "voice/a21/7100180a02.opus"
    aoi "\"Are you worried about Miyuki? Don't be.\""


translate english a2171_e8e92858:



    voice "voice/a21/7100190a02.opus"
    aoi "\"Love and lust are two different things.\""


translate english a2171_78e22060:



    voice "voice/a21/7100200a02.opus"
    aoi "\"There's nothing wrong with wanting sex.\""


translate english a2171_07b26ba6:



    voice "voice/a21/7100210a02.opus"
    aoi "\"You can just use me like a sex toy and—\""


translate english a2171_e8913f13:


    xy "\"I said STOP!\""


translate english a2171_5ce4047f:



    voice "voice/a21/7100220a02.opus"
    aoi "\"Boop boop?\""


translate english a2171_59ffafdf:


    "Aoi me mira fijamente sin expresión."


translate english a2171_8822825c:


    xy "\"Listen, I need you to promise me that you'll never talk about that stuff in public ever again. Got it?\""


translate english a2171_c7a063d1:



    voice "voice/a21/7100230a02.opus"
    aoi "\"Why not?\""


translate english a2171_58721472:


    xy "\"Isn't it obvious?! We're friends, and I care about you!\""


translate english a2171_57152676:



    voice "voice/a21/7100240a02.opus"
    aoi "\"Friends...?\""


translate english a2171_12f8dc58:


    xy "\"You're not a stupid sex toy. You're not some tool created by God to fuck!\""


translate english a2171_e071e922:


    xy "\"Seriously, you need to have some self-respe—Wait, what the?\""


translate english a2171_f5fd4901:


    xy "\"Aoi, what's wrong?\""


translate english a2171_5cd9f77a:



    voice "voice/a21/7100250a02.opus"
    aoi "\"What do you mean?\""


translate english a2171_5a6d90c2:


    xy "\"You know what I mean! You're...!\""


translate english a2171_ccbb5300:



    voice "voice/a21/7100260a02.opus"
    aoi "\"Boop boop...?\""


translate english a2171_1436ad83:


    "No puedo creer lo que veo."


translate english a2171_5fccf2b5:



    voice "voice/a21/7100270a02.opus"
    aoi "\"What the...?\""


translate english a2171_50e25355:



    voice "voice/a21/7100280a02.opus"
    aoi "\"What's... happening?\""


translate english a2171_d45f2761:


    "Diminutas gotas corren por su rostro, brillando bajo el atardecer."


translate english a2171_8fde847e:


    "Lágrimas."


translate english a2171_dfa95487:


    "Aoi está llorando en medio de la calle."


translate english a2171_434e9cd7:


    xy "\"What's the matter? Are you—\""


translate english a2171_f941b8c6:



    voice "voice/a21/7100290a01.opus"
    mx "\"STOP RIGHT THERE!\""


translate english a2171_9aea408a:


    xy "\"Whoa!\""


translate english a2171_5cf8b141:


    "¿¡Qué demonios!?"


translate english a2171_f37e40a0:


    "¡¡¡Miyuki acaba de golpearme la cabeza con su maldito bate de béisbol de metal!!!"


translate english a2171_e44981c7:



    voice "voice/a21/7100300a01.opus"
    mx "\"Unbelievable... What in god's name do you think you're doing, Shinichi?! How could you make her cry?!\""


translate english a2171_707be0a3:



    voice "voice/a21/7100310a01.opus"
    mx "\"Aoi, are you okay? Did Shinichi do something to upset you?\""


translate english a2171_e90a55a7:



    voice "voice/a21/7100320a02.opus"
    aoi "\"No... What the...?\""


translate english a2171_2821aecb:



    voice "voice/a21/7100330a02.opus"
    aoi "\"The tears... won't stop falling...\""


translate english a2171_0b11fdc0:



    voice "voice/a21/7100340a01.opus"
    mx "\"Don't fight the pain. Just let it all out.\""


translate english a2171_26d04320:



    voice "voice/a21/7100350a02.opus"
    aoi "\"Pain...?\""


translate english a2171_77b2117c:



    voice "voice/a21/7100360a02.opus"
    aoi "\"No... Aoi's... happy...\""


translate english a2171_1379a3c9:



    voice "voice/a21/7100370a01.opus"
    mx "\"Happy?\""


translate english a2171_98a93a04:



    voice "voice/a21/7100380a02.opus"
    aoi "\"Yeah... Shinichi said something nice... and it made me really happy.\""


translate english a2171_3599b96e:



    voice "voice/a21/7100390a01.opus"
    mx "\"Then... these are, uh... happy tears, I take it?\""


translate english a2171_08c1a850:



    voice "voice/a21/7100400a02.opus"
    aoi "\"Happy tears?\""


translate english a2171_b9fd57da:


    xy "\"Are you proud of yourself? You hit me for no reason.\""


translate english a2171_db2af986:



    voice "voice/a21/7100410a01.opus"
    mx "\"Sh-Shut up! If you'd been in my shoes, I'm sure you would've jumped to the same conclusion and...!\""


translate english a2171_120d7440:



    voice "voice/a21/7100420a01.opus"
    mx "\"I... I'm sorry...\""


translate english a2171_46e45765:


    "La fulmino en silencio hasta que se disculpa."


translate english a2171_ae310eea:


    xy "\"Well, you didn't hit me that hard, and it didn't do any permanent damage, so it's fine. But try to give me the benefit of the doubt next time, alright?\""


translate english a2171_f52889c3:



    voice "voice/a21/7100430a01.opus"
    mx "\"O-Okay... I won't do it again, I promise.\""


translate english a2171_ba29b3cb:


    "Para ser justos, puedo entender su pánico."


translate english a2171_224663c4:


    "Yo mismo tuve problemas para procesar la situación. O sea, ¿Aoi? ¿Llorando?"


translate english a2171_664c8ca1:


    "Hasta ayer, nunca habría imaginado que fuera posible."


translate english a2171_32710f1b:


    "Pero ahora siento que mi esfuerzo por fin empieza a dar frutos."


translate english a2171_89224fa8:



    voice "voice/a21/7100440a01.opus"
    mx "\"Umm... I can't really pretend this is a token of my apology, but...\""


translate english a2171_b3ce9cf8:



    voice "voice/a21/7100450a01.opus"
    mx "\"I bought these for everyone.\""


translate english a2171_82ac7e92:



    voice "voice/a21/7100460a02.opus"
    aoi "\"That's...!\""


translate english a2171_d2550965:



    voice "voice/a21/7100470a02.opus"
    aoi "\"Ice cream from Kurakami Electronics!\""


translate english a2171_b531bdca:



    voice "voice/a21/7100480a02.opus"
    aoi "\"It's so sweet... and cold... and yummy...\""


translate english a2171_cb20ea78:


    xy "\"Yeah, this is delicious.\""


translate english a2171_06b2f4d0:



    voice "voice/a21/7100490a01.opus"
    mx "\"It's heavenly...\""


translate english a2171_f6fbae35:


    "Tenía la sensación de que no era propio de Miyuki olvidar algo. ¡Resulta que solo quería sorprendernos con helado!"


translate english a2171_4c08405a:



    voice "voice/a21/7100500a02.opus"
    aoi "\"Got it!\""


translate english a2171_387c9237:



    voice "voice/a21/7100510a02.opus"
    aoi "\"Miyuki, are you crying?\""


translate english a2171_b77fe8b7:



    voice "voice/a21/7100520a01.opus"
    mx "\"N-No, I'm not CRYING!\""


translate english a2171_a8386075:



    voice "voice/a21/7100530a02.opus"
    aoi "\"Are you sad? Are you in pain?\""


translate english a2171_c611eaba:



    voice "voice/a21/7100540a02.opus"
    aoi "\"Or... are those happy tears?\""


translate english a2171_89304be5:



    voice "voice/a21/7100550a01.opus"
    mx "\"Just shut up and let me enjoy this!\""


translate english a2171_d5d61d7a:



    voice "voice/a21/7100560a01.opus"
    mx "\"You're the one who wanted to get ice cream together, so I added an extra morning workout to my daily routine, all for you!\""


translate english a2171_49873fd6:


    xy "\"You went to all that trouble for this?\""


translate english a2171_94e6699d:


    "De verdad que es una actriz hasta la médula."


translate english a2171_044112be:



    voice "voice/a21/7100570a01.opus"
    mx "\"Of course. I mean, what are friends for?\""


translate english a2171_a04a725c:



    voice "voice/a21/7100580a02.opus"
    aoi "\"Miyuki...\""


translate english a2171_9c54f03f:



    voice "voice/a21/7100590a02.opus"
    aoi "\"Thank you.\""


translate english a2171_7d715cd8:



    voice "voice/a21/7100600a01.opus"
    mx "\"No, thank YOU, Aoi.\""


translate english a2171_e92bb9df:


    "Las dos se sonríen, con la boca llena de helado, sin rastro de miseria a la vista."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
