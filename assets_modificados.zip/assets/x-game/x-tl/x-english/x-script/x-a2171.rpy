

translate english a2171_feb53965:



    voice "voice/a21/7100010a01.opus"
    mx "\"¡Oh, eso me recuerda!\""


translate english a2171_9618cd1b:


    "Justo cuando pasamos las rejas de la escuela, Miyuki se detiene en seco."


translate english a2171_c6cdbd08:



    voice "voice/a21/7100020a01.opus"
    mx "\"Perdón, olvidé algo. Ustedes dos esperen aquí.\""


translate english a2171_f881d93e:


    "De inmediato gira sobre sus talones y regresa por donde vinimos."


translate english a2171_39ddd6e8:


    xy "\"¿Miyuki olvidó algo? Eso es raro.\""


translate english a2171_48f9d118:



    voice "voice/a21/7100030a02.opus"
    aoi "\"¿Quizás tu engaño la traumatizó?\""


translate english a2171_98f2d718:


    xy "\"¡Te dije que Miyuki y yo solo somos amigos! ¡Es imposible \"engañar\" a alguien con quien no estás saliendo!\""


translate english a2171_faceb40b:



    voice "voice/a21/7100040a02.opus"
    aoi "\"¡Entendido!\""


translate english a2171_14e70a8b:


    "La mano de Aoi se dispara hacia el cielo del atardecer, recta como una flecha."


translate english a2171_92a83fea:



    voice "voice/a21/7100050a02.opus"
    aoi "\"Hay un error en la ruta de Miyuki.\""


translate english a2171_7257b8f4:



    voice "voice/a21/7100060a02.opus"
    aoi "\"Actúas como si no quisieras acercarte a ella.\""


translate english a2171_8ff4b9b9:



    voice "voice/a21/7100070a02.opus"
    aoi "\"Pero eso es solo porque en secreto SÍ quieres.\""


translate english a2171_c4cdb4fe:



    voice "voice/a21/7100080a02.opus"
    aoi "\"¿Verdad?\""


translate english a2171_0accd139:


    xy "\"......\""


translate english a2171_3e3f5124:


    "Ahora que todos somos amigos, es fácil olvidar que el verdadero objetivo de Aoi es hacer de Cupido entre Miyuki y yo."


translate english a2171_e26203e8:


    xy "\"No es genial tratar a la gente de la vida real como rutas de una novela visual.\""


translate english a2171_60d22f41:


    xy "\"La gente no existe solo para que puedas salir con ella.\""


translate english a2171_31eaffe2:



    voice "voice/a21/7100090a02.opus"
    aoi "\"Aoi sí, sin embargo.\""


translate english a2171_cd5e68e3:



    voice "voice/a21/7100100a02.opus"
    aoi "\"Aoi fue hecha para enamorarse y tener sexo.\""


translate english a2171_a2bfc28e:



    voice "voice/a21/7100110a02.opus"
    aoi "\"Esa es toda la razón por la que Dios me creó.\""


translate english a2171_5148aa96:


    xy "\"¡No es cierto!\""


translate english a2171_9d7e1cdc:


    "Me niego a creerlo."


translate english a2171_6482b93a:



    voice "voice/a21/7100120a02.opus"
    aoi "\"¿Muy tímido para admitirlo? O... ¡bip bip!\""


translate english a2171_d58effd4:



    voice "voice/a21/7100130a02.opus"
    aoi "\"¿Quieres cogerme?\""


translate english a2171_62d467ed:


    xy "\"¿Perdón?\""


translate english a2171_0d48dc9d:



    voice "voice/a21/7100140a02.opus"
    aoi "\"Aoi también es una opción romántica, ¿sabes? Aoi puede hacer que te corras sin problema.\""


translate english a2171_ac90e74f:



    voice "voice/a21/7100150a02.opus"
    aoi "\"Las pajas son divertidas. Las rusas se sienten genial. Las pajas con los pies, el anal, todo está sobre la mesa.\""


translate english a2171_0a89fee1:



    voice "voice/a21/7100160a02.opus"
    aoi "\"La boca de Aoi es pequeña, pero cabe mucho. Slurp slurp, ¡arriba y abajo!\""


translate english a2171_e4ff5fa2:



    voice "voice/a21/7100170a02.opus"
    aoi "\"Puedes metértela hasta la garganta. Se sentirá tan bien que te vendrás al instante—\""


translate english a2171_19a1f95b:


    xy "\"¡Deja de hablar así!\""


translate english a2171_7c5d7d0d:



    voice "voice/a21/7100180a02.opus"
    aoi "\"¿Estás preocupado por Miyuki? No lo estés.\""


translate english a2171_e8e92858:



    voice "voice/a21/7100190a02.opus"
    aoi "\"El amor y la lujuria son dos cosas diferentes.\""


translate english a2171_78e22060:



    voice "voice/a21/7100200a02.opus"
    aoi "\"No hay nada de malo en querer sexo.\""


translate english a2171_07b26ba6:



    voice "voice/a21/7100210a02.opus"
    aoi "\"Puedes simplemente usarme como un juguete sexual y—\""


translate english a2171_e8913f13:


    xy "\"¡Dije que PARES!\""


translate english a2171_5ce4047f:



    voice "voice/a21/7100220a02.opus"
    aoi "\"¿Bip bip?\""


translate english a2171_59ffafdf:


    "Aoi me mira fijamente sin expresión."


translate english a2171_8822825c:


    xy "\"Escucha, necesito que me prometas que nunca volverás a hablar de esas cosas en público. ¿Entendido?\""


translate english a2171_c7a063d1:



    voice "voice/a21/7100230a02.opus"
    aoi "\"¿Por qué no?\""


translate english a2171_58721472:


    xy "\"¿¡No es obvio!? ¡Somos amigos, y me importas!\""


translate english a2171_57152676:



    voice "voice/a21/7100240a02.opus"
    aoi "\"¿Amigos...?\""


translate english a2171_12f8dc58:


    xy "\"No eres un estúpido juguete sexual. ¡No eres una herramienta creada por Dios para coger!\""


translate english a2171_e071e922:


    xy "\"En serio, necesitas algo de amor propi— Espera, ¿qué demonios?\""


translate english a2171_f5fd4901:


    xy "\"Aoi, ¿qué pasa?\""


translate english a2171_5cd9f77a:



    voice "voice/a21/7100250a02.opus"
    aoi "\"¿A qué te refieres?\""


translate english a2171_5a6d90c2:


    xy "\"¡Sabes a qué me refiero! ¡Tú...!\""


translate english a2171_ccbb5300:



    voice "voice/a21/7100260a02.opus"
    aoi "\"¿Bip bip...?\""


translate english a2171_1436ad83:


    "No puedo creer lo que veo."


translate english a2171_5fccf2b5:



    voice "voice/a21/7100270a02.opus"
    aoi "\"¿Qué demonios...?\""


translate english a2171_50e25355:



    voice "voice/a21/7100280a02.opus"
    aoi "\"¿Qué está... pasando?\""


translate english a2171_d45f2761:


    "Diminutas gotas corren por su rostro, brillando bajo el atardecer."


translate english a2171_8fde847e:


    "Lágrimas."


translate english a2171_dfa95487:


    "Aoi está llorando en medio de la calle."


translate english a2171_434e9cd7:


    xy "\"¿Qué pasa? ¿Estás—\""


translate english a2171_f941b8c6:



    voice "voice/a21/7100290a01.opus"
    mx "\"¡ALTO AHÍ!\""


translate english a2171_9aea408a:


    xy "\"¡Whoa!\""


translate english a2171_5cf8b141:


    "¿¡Qué demonios!?"


translate english a2171_f37e40a0:


    "¡¡¡Miyuki acaba de golpearme la cabeza con su maldito bate de béisbol de metal!!!"


translate english a2171_e44981c7:



    voice "voice/a21/7100300a01.opus"
    mx "\"Increíble... ¿¡Qué demonios crees que estás haciendo, Shinichi!? ¡¿Cómo pudiste hacerla llorar?!\""


translate english a2171_707be0a3:



    voice "voice/a21/7100310a01.opus"
    mx "\"Aoi, ¿estás bien? ¿Shinichi te hizo algo?\""


translate english a2171_e90a55a7:



    voice "voice/a21/7100320a02.opus"
    aoi "\"No... ¿Qué demonios...?\""


translate english a2171_2821aecb:



    voice "voice/a21/7100330a02.opus"
    aoi "\"Las lágrimas... no dejan de caer...\""


translate english a2171_0b11fdc0:



    voice "voice/a21/7100340a01.opus"
    mx "\"No luches contra el dolor. Solo déjalo salir.\""


translate english a2171_26d04320:



    voice "voice/a21/7100350a02.opus"
    aoi "\"¿Dolor...?\""


translate english a2171_77b2117c:



    voice "voice/a21/7100360a02.opus"
    aoi "\"No... Aoi está... feliz...\""


translate english a2171_1379a3c9:



    voice "voice/a21/7100370a01.opus"
    mx "\"¿Feliz?\""


translate english a2171_98a93a04:



    voice "voice/a21/7100380a02.opus"
    aoi "\"Sí... Shinichi dijo algo lindo... y me hizo muy feliz.\""


translate english a2171_3599b96e:



    voice "voice/a21/7100390a01.opus"
    mx "\"Entonces... estas son, eh... lágrimas de felicidad, supongo.\""


translate english a2171_08c1a850:



    voice "voice/a21/7100400a02.opus"
    aoi "\"¿Lágrimas de felicidad?\""


translate english a2171_b9fd57da:


    xy "\"¿Estás orgulloso de ti mismo? Me golpeaste sin razón.\""


translate english a2171_db2af986:



    voice "voice/a21/7100410a01.opus"
    mx "\"¡C-Cállate! ¡Si hubieras estado en mi lugar, seguro habrías llegado a la misma conclusión y...!\""


translate english a2171_120d7440:



    voice "voice/a21/7100420a01.opus"
    mx "\"Yo... Lo siento...\""


translate english a2171_46e45765:


    "La fulmino en silencio hasta que se disculpa."


translate english a2171_ae310eea:


    xy "\"Bueno, no me golpeaste tan fuerte, y no causó daño permanente, así que está bien. Pero trata de darme el beneficio de la duda la próxima vez, ¿sí?\""


translate english a2171_f52889c3:



    voice "voice/a21/7100430a01.opus"
    mx "\"E-Está bien... No lo volveré a hacer, lo prometo.\""


translate english a2171_ba29b3cb:


    "Para ser justos, puedo entender su pánico."


translate english a2171_224663c4:


    "Yo mismo tuve problemas para procesar la situación. O sea, ¿Aoi? ¿Llorando?"


translate english a2171_664c8ca1:


    "Hasta ayer, nunca habría imaginado que fuera posible."


translate english a2171_32710f1b:


    "Pero ahora siento que mi esfuerzo por fin empieza a dar frutos."


translate english a2171_89224fa8:



    voice "voice/a21/7100440a01.opus"
    mx "\"Emm... No puedo realmente fingir que esto es una muestra de mi disculpa, pero...\""


translate english a2171_b3ce9cf8:



    voice "voice/a21/7100450a01.opus"
    mx "\"Compré esto para todos.\""


translate english a2171_82ac7e92:



    voice "voice/a21/7100460a02.opus"
    aoi "\"¡Eso es...!\""


translate english a2171_d2550965:



    voice "voice/a21/7100470a02.opus"
    aoi "\"¡Helado de Kurakami Electronics!\""


translate english a2171_b531bdca:



    voice "voice/a21/7100480a02.opus"
    aoi "\"Es tan dulce... y frío... y rico...\""


translate english a2171_cb20ea78:


    xy "\"Sí, esto está delicioso.\""


translate english a2171_06b2f4d0:



    voice "voice/a21/7100490a01.opus"
    mx "\"Es celestial...\""


translate english a2171_f6fbae35:


    "Tenía la sensación de que no era propio de Miyuki olvidar algo. ¡Resulta que solo quería sorprendernos con helado!"


translate english a2171_4c08405a:



    voice "voice/a21/7100500a02.opus"
    aoi "\"¡Entendido!\""


translate english a2171_387c9237:



    voice "voice/a21/7100510a02.opus"
    aoi "\"¿Miyuki, estás llorando?\""


translate english a2171_b77fe8b7:



    voice "voice/a21/7100520a01.opus"
    mx "\"¡N-No estoy LLORANDO!\""


translate english a2171_a8386075:



    voice "voice/a21/7100530a02.opus"
    aoi "\"¿Estás triste? ¿Tienes dolor?\""


translate english a2171_c611eaba:



    voice "voice/a21/7100540a02.opus"
    aoi "\"¿O... son lágrimas de felicidad?\""


translate english a2171_89304be5:



    voice "voice/a21/7100550a01.opus"
    mx "\"¡Solo cállate y déjame disfrutar esto!\""


translate english a2171_d5d61d7a:



    voice "voice/a21/7100560a01.opus"
    mx "\"¡Tú eres quien quería ir por helado juntos, así que añadí un entrenamiento extra por la mañana a mi rutina diaria, todo por ti!\""


translate english a2171_49873fd6:


    xy "\"¿Pasaste por todo ese problema por esto?\""


translate english a2171_94e6699d:


    "De verdad que es una actriz hasta la médula."


translate english a2171_044112be:



    voice "voice/a21/7100570a01.opus"
    mx "\"Claro. Digo, ¿para qué son los amigos?\""


translate english a2171_a04a725c:



    voice "voice/a21/7100580a02.opus"
    aoi "\"Miyuki...\""


translate english a2171_9c54f03f:



    voice "voice/a21/7100590a02.opus"
    aoi "\"Gracias.\""


translate english a2171_7d715cd8:



    voice "voice/a21/7100600a01.opus"
    mx "\"No, gracias a TI, Aoi.\""


translate english a2171_e92bb9df:


    "Las dos se sonríen, con la boca llena de helado, sin rastro de miseria a la vista."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
