

translate english e1211_4a264bbf:


    xy "\"Please give Aoi back!\""


translate english e1211_b01eaefa:



    voice "voice/e12/1100010a01.opus"
    mx "\"Oho? You want to see Aoi that badly, do you?\""


translate english e1211_1048212b:


    xy "\"Yes! Please! I'm begging you!\""


translate english e1211_0618a968:



    voice "voice/e12/1100020a01.opus"
    mx "\"...I guess if you're that desperate... I'll let you see her later.\""


translate english e1211_d12e3deb:


    xy "\"Really?!\""


translate english e1211_8a2ea988:



    voice "voice/e12/1100030a01.opus"
    mx "\"Would I lie to you? Now finish your breakfast.\""


translate english e1211_200192ee:


    "Ella me reprende con suavidad, y hago lo que sugiere."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
