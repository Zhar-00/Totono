

translate english e1211_4a264bbf:


    xy "\"¡Por favor, devuelve a Aoi!\""


translate english e1211_b01eaefa:



    voice "voice/e12/1100010a01.opus"
    mx "\"¿Oho? ¿Tanto quieres ver a Aoi, eh?\""


translate english e1211_1048212b:


    xy "\"¡Sí! ¡Por favor! ¡Te lo suplico!\""


translate english e1211_0618a968:



    voice "voice/e12/1100020a01.opus"
    mx "\"...Supongo que si estás tan desesperado... te dejaré verla después.\""


translate english e1211_d12e3deb:


    xy "\"¡¿En serio?!\""


translate english e1211_8a2ea988:



    voice "voice/e12/1100030a01.opus"
    mx "\"¿Te mentiría? Ahora termínate el desayuno.\""


translate english e1211_200192ee:


    "Ella me reprende con suavidad, y hago lo que sugiere."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
