

translate english e2123_38114c8a:



    voice "voice/e21/2300010a01.opus"
    mx "\"Why not go apologize?\""


translate english e2123_e5edbb9a:


    xy "\"We were just screwing around.\""


translate english e2123_ed6e0d0c:



    voice "voice/e21/2300020a01.opus"
    mx "\"Hmm... I'll never understand guy friendships.\""


translate english e2123_8ea1949c:


    xy "\"Well, what are girl friendships like?\""


translate english e2123_4692a136:


    "Miyuki hace una pausa para pensar un momento."


translate english e2123_32b86b1c:



    voice "voice/e21/2300030a01.opus"
    mx "\"Kind of like a video game, I guess.\""


translate english e2123_eb6b38df:


    xy "\"How so?\""


translate english e2123_722f8a48:



    voice "voice/e21/2300040a01.opus"
    mx "\"Nobody takes it too seriously.\""


translate english e2123_a0d62ff1:



    voice "voice/e21/2300050a01.opus"
    mx "\"Kind of like a perpetual motion machine, I guess.\""


translate english e2123_e57154c7:



    voice "voice/e21/2300060a01.opus"
    mx "\"It's not real.\""


translate english e2123_41f0cfee:



    voice "voice/e21/2300070a01.opus"
    mx "\"Kind of like a world record, I guess.\""


translate english e2123_26ac1d37:



    voice "voice/e21/2300080a01.opus"
    mx "\"No matter how impressive it looks on the outside, it exists to be broken.\""


translate english e2123_b16824ff:


    xy "\"...Jeez, really?\""


translate english e2123_4398f131:



    voice "voice/e21/2300090a01.opus"
    mx "\"Really really.\""


translate english e2123_a0b31aad:


    "Miyuki parece un poco engreída de alguna manera."


translate english e2123_c4693ce4:


    "Supongo que solo ve la escuela como un lugar para practicar sus habilidades actorales."


translate english e2123_b814f402:


    "Una vez más, me recuerda cuánto me necesita cerca..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
