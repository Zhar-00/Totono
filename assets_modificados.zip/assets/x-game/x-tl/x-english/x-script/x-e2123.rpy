

translate english e2123_38114c8a:



    voice "voice/e21/2300010a01.opus"
    mx "\"¿Por qué no vas a disculparte?\""


translate english e2123_e5edbb9a:


    xy "\"Solo estábamos bromeando.\""


translate english e2123_ed6e0d0c:



    voice "voice/e21/2300020a01.opus"
    mx "\"Hmm... Nunca entenderé las amistades de hombres.\""


translate english e2123_8ea1949c:


    xy "\"Bueno, ¿y cómo son las amistades de mujeres?\""


translate english e2123_4692a136:


    "Miyuki hace una pausa para pensar un momento."


translate english e2123_32b86b1c:



    voice "voice/e21/2300030a01.opus"
    mx "\"Algo así como un videojuego, supongo.\""


translate english e2123_eb6b38df:


    xy "\"¿Cómo es eso?\""


translate english e2123_722f8a48:



    voice "voice/e21/2300040a01.opus"
    mx "\"Nadie se lo toma demasiado en serio.\""


translate english e2123_a0d62ff1:



    voice "voice/e21/2300050a01.opus"
    mx "\"Algo así como una máquina de movimiento perpetuo, supongo.\""


translate english e2123_e57154c7:



    voice "voice/e21/2300060a01.opus"
    mx "\"No es real.\""


translate english e2123_41f0cfee:



    voice "voice/e21/2300070a01.opus"
    mx "\"Algo así como un récord mundial, supongo.\""


translate english e2123_26ac1d37:



    voice "voice/e21/2300080a01.opus"
    mx "\"No importa lo impresionante que se vea por fuera, existe para ser roto.\""


translate english e2123_b16824ff:


    xy "\"...Caramba, ¿en serio?\""


translate english e2123_4398f131:



    voice "voice/e21/2300090a01.opus"
    mx "\"En serio, en serio.\""


translate english e2123_a0b31aad:


    "Miyuki parece un poco engreída de alguna manera."


translate english e2123_c4693ce4:


    "Supongo que solo ve la escuela como un lugar para practicar sus habilidades actorales."


translate english e2123_b814f402:


    "Una vez más, me recuerda cuánto me necesita cerca..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
