

translate english a3223_5187fe16:



    voice "voice/a32/2300010a02.opus"
    aoi "\"No te van a poner los cuernos, Shinichi.\""


translate english a3223_62d467ed:


    xy "\"¿Perdón?\""


translate english a3223_dd299a33:



    voice "voice/a32/2300020a02.opus"
    aoi "\"Aoi ya parcheó el universo para asegurarse.\""


translate english a3223_21af1db5:


    "Allá arriba, en lo alto de la azotea... en el centro del mundo..."


translate english a3223_22e88088:


    "Aoi \"updated\"el universo."


translate english a3223_00a5ca7c:


    "Pero eso fue solo ella actuando una escena del juego..."


translate english a3223_8ecbf859:


    "¿Verdad?"


translate english a3223_b0eafcbd:



    voice "voice/a32/2300030a02.opus"
    aoi "\"Shinichi...\""


translate english a3223_554c303e:



    voice "voice/a32/2300040a02.opus"
    aoi "\"Vas a ser el príncipe de Miyuki.\""


translate english a3223_86421d4d:


    xy "\"¿Su... príncipe...?\""


translate english a3223_05c5a7d1:


    "No puedo creer lo que oigo."


translate english a3223_b47268b7:


    "Of all the words that could be used to describe me, \"prince\"no es una de ellas."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
