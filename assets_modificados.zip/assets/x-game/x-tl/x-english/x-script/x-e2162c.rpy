

translate english e2162c_252b6fad:


    "Supongo que podría regalarle un marco de fotos..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
