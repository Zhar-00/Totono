

translate english a3211_2924a6f2:



    voice "voice/a32/1100010a02.opus"
    aoi "\"¡Eru!\""


translate english a3211_fdaab777:



    voice "voice/a32/1100020a02.opus"
    aoi "\"Bebe.\""


translate english a3211_b27e9591:


    "Aoi presiona suavemente la punta de la jeringa de alimentación contra la boca de Eru."


translate english a3211_f0759977:



    voice "voice/a32/1100050a02.opus"
    aoi "\"......\""


translate english a3211_3b95b516:



    voice "voice/a32/1100060a02.opus"
    aoi "\"¡Parece que a Eru le gusta!\""


translate english a3211_f7de84cf:


    xy "\"Sí, ni qué decirlo.\""


translate english a3211_cfec7522:


    "La pequeña criatura debe de estar muerta de hambre."


translate english a3211_bd25a181:


    "Eru se aferra a la punta de la jeringa."


translate english a3211_9b849635:


    "No pudimos encontrar ningún lugar que venda biberones, pero al menos esto parece funcionar perfectamente."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
