

translate english a3141_ae3430f6:



    voice "voice/a31/4100010a02.opus"
    aoi "\"So this is where the batting cages are?\""


translate english a3141_043fcaa8:



    voice "voice/a31/4100020a01.opus"
    mx "\"Sure is.\""


translate english a3141_5a444192:



    voice "voice/a31/4100030a02.opus"
    aoi "\"It's all run-down.\""


translate english a3141_5c1c5166:


    xy "\"It's been this way ever since we were kids.\""


translate english a3141_6803e136:



    voice "voice/a31/4100040a01.opus"
    mx "\"Actually, that's true, come to think of it.\""


translate english a3141_2cf239df:



    voice "voice/a31/4100050a02.opus"
    aoi "\"Got it!\""


translate english a3141_ef6c5a99:



    voice "voice/a31/4100060a02.opus"
    aoi "\"You two used to come here together as kids?\""


translate english a3141_90d29439:



    voice "voice/a31/4100070a01.opus"
    mx "\"More like Shinichi would drag me here, but yeah.\""


translate english a3141_6f71bfba:


    xy "\"Yeah, I guess you could say that.\""


translate english a3141_e2d786d1:


    "Siempre se nos acababa el dinero de la mesada, pero el encargado nos tomó cariño y nos dejaba jugar gratis de vez en cuando."


translate english a3141_4efa5fb5:


    "A partir de ahí, las jaulas de bateo pronto se volvieron nuestro lugar habitual."


translate english a3141_ed29ac29:



    voice "voice/a31/4100080a01.opus"
    mx "\"Now then, let's get started!\""


translate english a3141_ed485aba:



    voice "voice/a31/4100090a02.opus"
    aoi "\"Okay!\""


translate english a3141_89780390:



    voice "voice/a31/4100100a02.opus"
    aoi "\"Hyah--!\""


translate english a3141_361e36df:



    voice "voice/a31/4100110a02.opus"
    aoi "\"...Boop boop?\""


translate english a3141_d9040845:


    "El bate c<I></I>orta el aire vacío."


translate english a3141_16e61772:


    "Aoi ladea la cabeza, desconcertada."


translate english a3141_d96b0496:



    voice "voice/a31/4100120a02.opus"
    aoi "\"Aoi missed?\""


translate english a3141_6e52216f:



    voice "voice/a31/4100130a01.opus"
    mx "\"Here, watch me. I'll show you how it's done.\""


translate english a3141_c8863011:


    "Miyuki toma el bate de Aoi y entra al cajón de bateo. Después de dos swings de práctica, la pelota sale disparada—"


translate english a3141_ffc02576:



    voice "voice/a31/4100140a02.opus"
    aoi "\"Wow...!\""


translate english a3141_e4d609ed:


    "—y al segundo siguiente, la manda disparada hacia la red de seguridad."


translate english a3141_a67974d3:



    voice "voice/a31/4100150a01.opus"
    mx "\"Can you tell what I'm doing differently?\""


translate english a3141_8c9ff9d1:



    voice "voice/a31/4100160a02.opus"
    aoi "\"Boop boop...\""


translate english a3141_3d18eeb3:



    voice "voice/a31/4100170a02.opus"
    aoi "\"Miyuki, you're so cool...\""


translate english a3141_00a7c680:



    voice "voice/a31/4100180a02.opus"
    aoi "\"Aoi's not cool at all.\""


translate english a3141_683e4a19:



    voice "voice/a31/4100190a01.opus"
    mx "\"Haah...\""


translate english a3141_dd7776e0:


    "Miyuki suelta un suspiro."


translate english a3141_dcd11376:



    voice "voice/a31/4100200a01.opus"
    mx "\"Okay, well, what do you think it is you're missing?\""


translate english a3141_65cd5a83:



    voice "voice/a31/4100210a02.opus"
    aoi "\"Height. Aoi's too short.\""


translate english a3141_aadf2f34:



    voice "voice/a31/4100220a02.opus"
    aoi "\"Can't compete with Miyuki's beauty.\""


translate english a3141_b42a76e0:



    voice "voice/a31/4100230a01.opus"
    mx "\"This isn't a pageant!\""


translate english a3141_1717049e:



    voice "voice/a31/4100240a01.opus"
    mx "\"Shinichi, help me out here!\""


translate english a3141_12b2d9fc:


    xy "\"Hmm... Let's see...\""


translate english a3141_5b9bfdd7:


    xy "\"For starters, try to keep your eye on the ball.\""


translate english a3141_01044f30:



    voice "voice/a31/4100250a02.opus"
    aoi "\"Keep my eye on the ball...?\""


translate english a3141_958d7039:


    xy "\"You're not looking at it when you swing. This time, try watching it and see what happens.\""


translate english a3141_4caf14dd:



    voice "voice/a31/4100260a02.opus"
    aoi "\"Boop boop...\""


translate english a3141_6ab000ca:


    "Aoi toma el bate y se dirige al cajón de bateo."


translate english a3141_ef2301cd:



    voice "voice/a31/4100270a02.opus"
    aoi "\"...I watched it.\""


translate english a3141_cd43e60e:



    voice "voice/a31/4100280a01.opus"
    mx "\"You have to do more than that, you goof!\""


translate english a3141_79f24ed7:


    xy "\"No, it's a good first step. We want her to get comfortable with the ball.\""


translate english a3141_466459a4:


    xy "\"Why don't you start with a bunt? Just hold the bat out in front of you.\""


translate english a3141_23382dba:



    voice "voice/a31/4100290a02.opus"
    aoi "\"Like this?\""


translate english a3141_1723fc9d:


    xy "\"That's it. Keep your eye on the ball and match the bat to its trajectory.\""


translate english a3141_01bc7bc6:



    voice "voice/a31/4100300a02.opus"
    aoi "\"Eye on the ball...\""


translate english a3141_d92fc366:



    voice "voice/a31/4100310a02.opus"
    aoi "\"Match the trajectory...\""


translate english a3141_d7c6251d:



    voice "voice/a31/4100320a02.opus"
    aoi "\"Boop boop!\""


translate english a3141_a39d0ae8:



    voice "voice/a31/4100330a02.opus"
    aoi "\"Oh... A-Aoi hit it...\""


translate english a3141_7b0fb671:


    "It wasn't much of a \"hit\"—más bien el rodado más débil del mundo—pero lo acepto."


translate english a3141_ce8c6139:


    xy "\"See? What'd I tell you?\""


translate english a3141_4d3658f9:



    voice "voice/a31/4100340a02.opus"
    aoi "\"Got it!\""


translate english a3141_30367a53:



    voice "voice/a31/4100350a02.opus"
    aoi "\"Shinichi, you're a great coach!\""


translate english a3141_4d6b540d:


    xy "\"Th-Thanks, I guess.\""


translate english a3141_2f44404d:



    voice "voice/a31/4100360a02.opus"
    aoi "\"Lemme try again.\""


translate english a3141_7926b5f0:



    voice "voice/a31/4100370a02.opus"
    aoi "\"Keep my eye on the ball...\""


translate english a3141_a18e8dd1:



    voice "voice/a31/4100380a02.opus"
    aoi "\"Boop boop!!!\""


translate english a3141_8f8e8300:



    voice "voice/a31/4100390a02.opus"
    aoi "\"Amazing... Another hit...\""


translate english a3141_0bec43bf:


    xy "\"This time, how about you try swinging?\""


translate english a3141_487e0a3e:



    voice "voice/a31/4100400a02.opus"
    aoi "\"Boop boop!\""


translate english a3141_cd51daec:


    "La pelota roza su torpe swing. Foul."


translate english a3141_6654f9a3:


    "Aun así, definitivamente está progresando."


translate english a3141_62e5bbb7:



    voice "voice/a31/4100410a01.opus"
    mx "\"You've always been a great teacher, you know.\""


translate english a3141_51f922fc:


    xy "\"Eh, I wouldn't say I'm anything special.\""


translate english a3141_8db2c2e6:



    voice "voice/a31/4100420a01.opus"
    mx "\"It's a talent you've had since grade school.\""


translate english a3141_7b8485db:


    xy "\"You think so?\""


translate english a3141_9100435a:



    voice "voice/a31/4100430a01.opus"
    mx "\"Trust me, I remember.\""


translate english a3141_29288e7e:



    voice "voice/a31/4100440a01.opus"
    mx "\"I've re-read my diary countless times.\""


translate english a3141_1b7722b6:


    "A decir verdad, yo también lo recuerdo."


translate english a3141_c4772ff4:


    "Viéndola ahora, nunca lo imaginarías... pero cuando Miyuki empezó, era incluso peor que Aoi."


translate english a3141_afd1a423:


    "Yo fui quien le enseñó a batear."


translate english a3141_9cdafa88:



    voice "voice/a31/4100450a02.opus"
    aoi "\"Boop boop!\""


translate english a3141_e75097c0:



    voice "voice/a31/4100460a02.opus"
    aoi "\"It flew...?\""


translate english a3141_cfdae794:



    voice "voice/a31/4100470a02.opus"
    aoi "\"It flew!\""


translate english a3141_5cc82129:


    xy "\"It sure did! I saw the whole thing.\""


translate english a3141_0b6d767d:


    "La sonrisa de Aoi es genuina y pura."


translate english a3141_1255cfd0:


    "Recuerdo vagamente que Miyuki sonreía así hace mucho tiempo."


translate english a3141_d4ba220e:



    voice "voice/a31/4100480a01.opus"
    mx "\"If you hadn't taught me baseball here all those years ago, I never would have landed this role.\""


translate english a3141_50e47b77:


    xy "\"Hey, c'mon. You got the part through your own efforts.\""


translate english a3141_bf67d49f:



    voice "voice/a31/4100490a01.opus"
    mx "\"Not true.\""


translate english a3141_0788556e:



    voice "voice/a31/4100500a01.opus"
    mx "\"You're the one who gave me the opportunity. As usual.\""


translate english a3141_31bb5edb:


    "Años de trabajo duro y diligente, y mira dónde está ahora."


translate english a3141_6ba427c8:


    "Puede que hayamos empezado en igualdad de condiciones, pero ahora estamos a kilómetros de distancia."


translate english a3141_bdeaee6c:



    voice "voice/a31/4100510a01.opus"
    mx "\"I see that old thing's still around, hm?\""


translate english a3141_8716ba40:


    "Señala la red de seguridad."


translate english a3141_eba3ee4a:


    "The net is adorned with a series of targets: \"Hit,\" \"Double,\" \"Triple,\"y \"Home Run.\""


translate english a3141_afc4a869:


    "Acierta estos blancos y ganarás cupones de juego gratis."


translate english a3141_352b60f5:


    "Vaya, eso me trae recuerdos..."


translate english a3141_1715e69c:


    "Cuando éramos pequeños, Miyuki y yo siempre nos retábamos a un juego."


translate english a3141_e7da2e3b:


    "Quien fallara más tiros tendría que cargar las dos mochilas todo el camino a casa."


translate english a3141_2b5cd37f:


    "Eso sí, casi nunca acertábamos esos blancos..."


translate english a3141_7aac9990:


    "Pero eso no nos impedía intentarlo."


translate english a3141_027f39cd:



    voice "voice/a31/4100520a01.opus"
    mx "\"I sure would like to see you take a swing, like old times.\""


translate english a3141_1f38ed99:


    "Su voz es un susurro."


translate english a3141_1d0cae54:


    "Pero no le respondo."


translate english a3141_64d22000:


    "No me da el ánimo."


translate english a3141_9ee7e6e2:


    "En vez de eso, miro en silencio a la distancia."


translate english a3141_9cae79af:


    "En el fondo, algo me dice..."


translate english a3141_bbfddec3:


    "...que si respondo a esa petición, destruirá todo lo que nosotros tres hemos construido."


translate english a3141_46605f9c:



    voice "voice/a31/4100530a02.opus"
    aoi "\"Boop boop!\""


translate english a3141_21e7cc53:



    voice "voice/a31/4100540a01.opus"
    mx "\"...You're certainly a fast learner, hmm?\""


translate english a3141_3108c562:



    voice "voice/a31/4100550a02.opus"
    aoi "\"All thanks to my master coach.\""


translate english a3141_1042c264:


    xy "\"Maybe you stand a chance of beating Miyuki now.\""


translate english a3141_f622e9c3:



    voice "voice/a31/4100560a02.opus"
    aoi "\"Beating her? In a fight?\""


translate english a3141_87fe8cea:



    voice "voice/a31/4100570a01.opus"
    mx "\"Why don't we make a little bet?\""


translate english a3141_94dd97df:


    "Miyuki señala los blancos con el bate."


translate english a3141_24d6f048:



    voice "voice/a31/4100580a01.opus"
    mx "\"We'll each take turns swinging the bat, and the person who hits their ball the closest to the target gets to tell the other two what to do.\""


translate english a3141_81912f80:



    voice "voice/a31/4100590a01.opus"
    mx "\"We can put a handicap on the ball speed to make it fair.\""


translate english a3141_2eed7e2e:



    voice "voice/a31/4100600a01.opus"
    mx "\"How about it? Wanna give it a try?\""


translate english a3141_ad669b0c:



    voice "voice/a31/4100610a02.opus"
    aoi "\"Yes!\""


translate english a3141_759f9e25:



    voice "voice/a31/4100620a02.opus"
    aoi "\"If Aoi wins, Shinichi and Miyuki have to get tog--\""


translate english a3141_1c83c506:


    xy "\"No.\""


translate english a3141_1020c259:


    "La rechazo con firmeza."


translate english a3141_4964cf6a:


    xy "\"Aoi, aren't you tired after all that?\""


translate english a3141_1c9dbbe2:



    voice "voice/a31/4100630a02.opus"
    aoi "\"Boop boop...?\""


translate english a3141_3525455f:


    xy "\"I know you weren't feeling 100%% today. Let's call it a day and go home--\""


translate english a3141_f7d72ff8:



    voice "voice/a31/4100640a01.opus"
    mx "\"What, you chicken? I see you've invented another one of your convenient excuses to get out of it.\""


translate english a3141_1a12bb99:


    xy "\"Sure, whatever, let's go with that.\""


translate english a3141_fe3a6abe:



    voice "voice/a31/4100650a01.opus"
    mx "\"It's NOT WHATEVER!\""


translate english a3141_bb58c512:


    xy "\"Huh?\""


translate english a3141_f3af5599:


    "No es propio de Miyuki gritar así."


translate english a3141_2a3ebcdc:



    voice "voice/a31/4100660a01.opus"
    mx "\"You know, you never used to be like this.\""


translate english a3141_7c6a05cc:



    voice "voice/a31/4100670a01.opus"
    mx "\"Shinichi, what is it you're so afraid of?\""


translate english a3141_0643b960:


    xy "\"I'm not 'afraid' of anything.\""


translate english a3141_b0c8ca05:


    xy "\"I just don't like pointless conflict.\""


translate english a3141_0bea514a:



    voice "voice/a31/4100680a01.opus"
    mx "\"Liar.\""


translate english a3141_43e004af:


    "Tiene toda la razón."


translate english a3141_c65d9974:


    "Ni siquiera encuentro el ánimo para enojarme por eso."


translate english a3141_dcf5fba2:


    xy "\"Fact of the matter is, Aoi isn't feeling her best.\""


translate english a3141_cccfd225:



    voice "voice/a31/4100690a02.opus"
    aoi "\"That's not--boop boop?\""


translate english a3141_dd30a0f0:


    "Aoi intenta discutir, pero se tambalea de lado."


translate english a3141_09e0be12:


    xy "\"See? Told you.\""


translate english a3141_ba0dbb5d:



    voice "voice/a31/4100700a02.opus"
    aoi "\"Boop boop boop boop...\""


translate english a3141_af2704f5:


    "Frunce el ceño para sí misma."


translate english a3141_8b94a6db:


    xy "\"Alright, let's get out of here.\""


translate english a3141_5ae11465:



    voice "voice/a31/4100710a02.opus"
    aoi "\"Okay.\""


translate english a3141_d35d10ca:



    voice "voice/a31/4100720a01.opus"
    mx "\"......\""


translate english a3141_4adb6bf8:


    "Miyuki todavía no parece convencida, pero la ignoro y guío el camino fuera del edificio."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
