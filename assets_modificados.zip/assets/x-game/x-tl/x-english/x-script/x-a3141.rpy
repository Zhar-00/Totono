

translate english a3141_ae3430f6:



    voice "voice/a31/4100010a02.opus"
    aoi "\"¿Así que aquí es donde está el béisbol?\""


translate english a3141_043fcaa8:



    voice "voice/a31/4100020a01.opus"
    mx "\"Así es.\""


translate english a3141_5a444192:



    voice "voice/a31/4100030a02.opus"
    aoi "\"Está todo destartalado.\""


translate english a3141_5c1c5166:


    xy "\"Ha estado así desde que éramos niños.\""


translate english a3141_6803e136:



    voice "voice/a31/4100040a01.opus"
    mx "\"De hecho, ahora que lo pienso, es cierto.\""


translate english a3141_2cf239df:



    voice "voice/a31/4100050a02.opus"
    aoi "\"¡Entendido!\""


translate english a3141_ef6c5a99:



    voice "voice/a31/4100060a02.opus"
    aoi "\"¿Ustedes dos solían venir aquí juntos de niños?\""


translate english a3141_90d29439:



    voice "voice/a31/4100070a01.opus"
    mx "\"Más bien Shinichi me arrastraba aquí, pero sí.\""


translate english a3141_6f71bfba:


    xy "\"Sí, supongo que se podría decir eso.\""


translate english a3141_e2d786d1:


    "Siempre se nos acababa el dinero de la mesada, pero el encargado nos tomó cariño y nos dejaba jugar gratis de vez en cuando."


translate english a3141_4efa5fb5:


    "A partir de ahí, las jaulas de bateo pronto se volvieron nuestro lugar habitual."


translate english a3141_ed29ac29:



    voice "voice/a31/4100080a01.opus"
    mx "\"¡Bueno, empecemos!\""


translate english a3141_ed485aba:



    voice "voice/a31/4100090a02.opus"
    aoi "\"¡Bien!\""


translate english a3141_89780390:



    voice "voice/a31/4100100a02.opus"
    aoi "\"¡Hyah...!\""


translate english a3141_361e36df:



    voice "voice/a31/4100110a02.opus"
    aoi "\"...¿Boop boop?\""


translate english a3141_d9040845:


    "El bate c<I></I>orta el aire vacío."


translate english a3141_16e61772:


    "Aoi ladea la cabeza, desconcertada."


translate english a3141_d96b0496:



    voice "voice/a31/4100120a02.opus"
    aoi "\"¿Aoi falló?\""


translate english a3141_6e52216f:



    voice "voice/a31/4100130a01.opus"
    mx "\"Mira, óbservame. Te voy a mostrar cómo se hace.\""


translate english a3141_c8863011:


    "Miyuki toma el bate de Aoi y entra al cajón de bateo. Después de dos swings de práctica, la pelota sale disparada—"


translate english a3141_ffc02576:



    voice "voice/a31/4100140a02.opus"
    aoi "\"¡Guau...!\""


translate english a3141_e4d609ed:


    "—y al segundo siguiente, la manda disparada hacia la red de seguridad."


translate english a3141_a67974d3:



    voice "voice/a31/4100150a01.opus"
    mx "\"¿Puedes notar qué estoy haciendo diferente?\""


translate english a3141_8c9ff9d1:



    voice "voice/a31/4100160a02.opus"
    aoi "\"Boop boop...\""


translate english a3141_3d18eeb3:



    voice "voice/a31/4100170a02.opus"
    aoi "\"Miyuki, eres tan genial...\""


translate english a3141_00a7c680:



    voice "voice/a31/4100180a02.opus"
    aoi "\"Aoi no es nada genial.\""


translate english a3141_683e4a19:



    voice "voice/a31/4100190a01.opus"
    mx "\"Haah...\""


translate english a3141_dd7776e0:


    "Miyuki suelta un suspiro."


translate english a3141_dcd11376:



    voice "voice/a31/4100200a01.opus"
    mx "\"Bueno, ¿y qué crees que te falta?\""


translate english a3141_65cd5a83:



    voice "voice/a31/4100210a02.opus"
    aoi "\"Altura. Aoi es muy bajita.\""


translate english a3141_aadf2f34:



    voice "voice/a31/4100220a02.opus"
    aoi "\"No puede competir con la belleza de Miyuki.\""


translate english a3141_b42a76e0:



    voice "voice/a31/4100230a01.opus"
    mx "\"¡Esto no es un concurso de belleza!\""


translate english a3141_1717049e:



    voice "voice/a31/4100240a01.opus"
    mx "\"¡Shinichi, ayúdame aquí!\""


translate english a3141_12b2d9fc:


    xy "\"Hmm... Veamos...\""


translate english a3141_5b9bfdd7:


    xy "\"Para empezar, trata de no quitarle el ojo a la pelota.\""


translate english a3141_01044f30:



    voice "voice/a31/4100250a02.opus"
    aoi "\"¿No quitarle el ojo a la pelota...?\""


translate english a3141_958d7039:


    xy "\"No la estás mirando cuando bateas. Esta vez, intenta mirarla y ve qué pasa.\""


translate english a3141_4caf14dd:



    voice "voice/a31/4100260a02.opus"
    aoi "\"Boop boop...\""


translate english a3141_6ab000ca:


    "Aoi toma el bate y se dirige al cajón de bateo."


translate english a3141_ef2301cd:



    voice "voice/a31/4100270a02.opus"
    aoi "\"...La miré.\""


translate english a3141_cd43e60e:



    voice "voice/a31/4100280a01.opus"
    mx "\"¡Tienes que hacer más que eso, tonta!\""


translate english a3141_79f24ed7:


    xy "\"No, es un buen primer paso. Queremos que se familiarice con la pelota.\""


translate english a3141_466459a4:


    xy "\"¿Por qué no empiezas con un toque de sorpresa? Solo sostén el bate frente a ti.\""


translate english a3141_23382dba:



    voice "voice/a31/4100290a02.opus"
    aoi "\"¿Así?\""


translate english a3141_1723fc9d:


    xy "\"Eso es. No le quites el ojo a la pelota y acompaña el bate a su trayectoria.\""


translate english a3141_01bc7bc6:



    voice "voice/a31/4100300a02.opus"
    aoi "\"Ojo en la pelota...\""


translate english a3141_d92fc366:



    voice "voice/a31/4100310a02.opus"
    aoi "\"Acompañar la trayectoria...\""


translate english a3141_d7c6251d:



    voice "voice/a31/4100320a02.opus"
    aoi "\"¡Boop boop!\""


translate english a3141_a39d0ae8:



    voice "voice/a31/4100330a02.opus"
    aoi "\"Oh... A-Aoi le dio...\""


translate english a3141_7b0fb671:


    "It wasn't much of a \"hit\"—más bien el rodado más débil del mundo—pero lo acepto."


translate english a3141_ce8c6139:


    xy "\"¿Ves? ¿Qué te dije?\""


translate english a3141_4d3658f9:



    voice "voice/a31/4100340a02.opus"
    aoi "\"¡Entendido!\""


translate english a3141_30367a53:



    voice "voice/a31/4100350a02.opus"
    aoi "\"¡Shinichi, eres un gran entrenador!\""


translate english a3141_4d6b540d:


    xy "\"G-Gracias, supongo.\""


translate english a3141_2f44404d:



    voice "voice/a31/4100360a02.opus"
    aoi "\"Déjame intentar otra vez.\""


translate english a3141_7926b5f0:



    voice "voice/a31/4100370a02.opus"
    aoi "\"Ojo en la pelota...\""


translate english a3141_a18e8dd1:



    voice "voice/a31/4100380a02.opus"
    aoi "\"¡¡¡Boop boop!!!\""


translate english a3141_8f8e8300:



    voice "voice/a31/4100390a02.opus"
    aoi "\"Increíble... Otro golpe...\""


translate english a3141_0bec43bf:


    xy "\"Esta vez, ¿qué tal si intentas batear?\""


translate english a3141_487e0a3e:



    voice "voice/a31/4100400a02.opus"
    aoi "\"¡Boop boop!\""


translate english a3141_cd51daec:


    "La pelota roza su torpe swing. Foul."


translate english a3141_6654f9a3:


    "Aun así, definitivamente está progresando."


translate english a3141_62e5bbb7:



    voice "voice/a31/4100410a01.opus"
    mx "\"Siempre has sido un gran maestro, ¿sabes?\""


translate english a3141_51f922fc:


    xy "\"Eh, no diría que soy nada especial.\""


translate english a3141_8db2c2e6:



    voice "voice/a31/4100420a01.opus"
    mx "\"Es un talento que has tenido desde la primaria.\""


translate english a3141_7b8485db:


    xy "\"¿Tú crees?\""


translate english a3141_9100435a:



    voice "voice/a31/4100430a01.opus"
    mx "\"Créeme, me acuerdo.\""


translate english a3141_29288e7e:



    voice "voice/a31/4100440a01.opus"
    mx "\"He releído mi diario infinidad de veces.\""


translate english a3141_1b7722b6:


    "A decir verdad, yo también lo recuerdo."


translate english a3141_c4772ff4:


    "Viéndola ahora, nunca lo imaginarías... pero cuando Miyuki empezó, era incluso peor que Aoi."


translate english a3141_afd1a423:


    "Yo fui quien le enseñó a batear."


translate english a3141_9cdafa88:



    voice "voice/a31/4100450a02.opus"
    aoi "\"¡Boop boop!\""


translate english a3141_e75097c0:



    voice "voice/a31/4100460a02.opus"
    aoi "\"¿Voló...?\""


translate english a3141_cfdae794:



    voice "voice/a31/4100470a02.opus"
    aoi "\"¡Voló!\""


translate english a3141_5cc82129:


    xy "\"¡Claro que sí! Lo vi todo.\""


translate english a3141_0b6d767d:


    "La sonrisa de Aoi es genuina y pura."


translate english a3141_1255cfd0:


    "Recuerdo vagamente que Miyuki sonreía así hace mucho tiempo."


translate english a3141_d4ba220e:



    voice "voice/a31/4100480a01.opus"
    mx "\"Si no me hubieras enseñado béisbol aquí hace todos esos años, nunca habría conseguido este papel.\""


translate english a3141_50e47b77:


    xy "\"Oye, vamos. Conseguiste el papel por tu propio esfuerzo.\""


translate english a3141_bf67d49f:



    voice "voice/a31/4100490a01.opus"
    mx "\"No es cierto.\""


translate english a3141_0788556e:



    voice "voice/a31/4100500a01.opus"
    mx "\"Tú eres el que me dio la oportunidad. Como siempre.\""


translate english a3141_31bb5edb:


    "Años de trabajo duro y diligente, y mira dónde está ahora."


translate english a3141_6ba427c8:


    "Puede que hayamos empezado en igualdad de condiciones, pero ahora estamos a kilómetros de distancia."


translate english a3141_bdeaee6c:



    voice "voice/a31/4100510a01.opus"
    mx "\"Veo que esa vieja cosa sigue por aquí, ¿eh?\""


translate english a3141_8716ba40:


    "Señala la red de seguridad."


translate english a3141_eba3ee4a:


    "The net is adorned with a series of targets: \"Hit,\" \"Double,\" \"Triple,\"y \"Home Run.\""


translate english a3141_afc4a869:


    "Acierta estos blancos y ganarás cupones de juego gratis."


translate english a3141_352b60f5:


    "Vaya, eso me trae recuerdos..."


translate english a3141_1715e69c:


    "Cuando éramos pequeños, Miyuki y yo siempre nos retábamos a un juego."


translate english a3141_e7da2e3b:


    "Quien fallara más tiros tendría que cargar las dos mochilas todo el camino a casa."


translate english a3141_2b5cd37f:


    "Eso sí, casi nunca acertábamos esos blancos..."


translate english a3141_7aac9990:


    "Pero eso no nos impedía intentarlo."


translate english a3141_027f39cd:



    voice "voice/a31/4100520a01.opus"
    mx "\"Claro que me gustaría verte batear, como en los viejos tiempos.\""


translate english a3141_1f38ed99:


    "Su voz es un susurro."


translate english a3141_1d0cae54:


    "Pero no le respondo."


translate english a3141_64d22000:


    "No me da el ánimo."


translate english a3141_9ee7e6e2:


    "En vez de eso, miro en silencio a la distancia."


translate english a3141_9cae79af:


    "En el fondo, algo me dice..."


translate english a3141_bbfddec3:


    "...que si respondo a esa petición, destruirá todo lo que nosotros tres hemos construido."


translate english a3141_46605f9c:



    voice "voice/a31/4100530a02.opus"
    aoi "\"¡Boop boop!\""


translate english a3141_21e7cc53:



    voice "voice/a31/4100540a01.opus"
    mx "\"...Ciertamente aprendes rápido, ¿eh?\""


translate english a3141_3108c562:



    voice "voice/a31/4100550a02.opus"
    aoi "\"Todo gracias a mi entrenador maestro.\""


translate english a3141_1042c264:


    xy "\"Quizá ahora tengas oportunidad de vencer a Miyuki.\""


translate english a3141_f622e9c3:



    voice "voice/a31/4100560a02.opus"
    aoi "\"¿Vencerla? ¿En una pelea?\""


translate english a3141_87fe8cea:



    voice "voice/a31/4100570a01.opus"
    mx "\"¿Por qué no hacemos una pequeña apuesta?\""


translate english a3141_94dd97df:


    "Miyuki señala los blancos con el bate."


translate english a3141_24d6f048:



    voice "voice/a31/4100580a01.opus"
    mx "\"Nos turnaremos para batear, y la persona que acerque más su pelota al objetivo podrá decirle a las otras dos qué hacer.\""


translate english a3141_81912f80:



    voice "voice/a31/4100590a01.opus"
    mx "\"Podemos poner un hándicap en la velocidad de la pelota para que sea justo.\""


translate english a3141_2eed7e2e:



    voice "voice/a31/4100600a01.opus"
    mx "\"¿Qué dices? ¿Quieres intentarlo?\""


translate english a3141_ad669b0c:



    voice "voice/a31/4100610a02.opus"
    aoi "\"¡Sí!\""


translate english a3141_759f9e25:



    voice "voice/a31/4100620a02.opus"
    aoi "\"Si Aoi gana, Shinichi y Miyuki tienen que estar jun...\""


translate english a3141_1c83c506:


    xy "\"No.\""


translate english a3141_1020c259:


    "La rechazo con firmeza."


translate english a3141_4964cf6a:


    xy "\"Aoi, ¿no estás cansada después de todo eso?\""


translate english a3141_1c9dbbe2:



    voice "voice/a31/4100630a02.opus"
    aoi "\"¿Boop boop...?\""


translate english a3141_3525455f:


    xy "\"I know you weren't feeling 100%% today. Let's call it a day and go home--\""


translate english a3141_f7d72ff8:



    voice "voice/a31/4100640a01.opus"
    mx "\"¿Qué, tienes miedo? Veo que inventaste otra de tus excusas convenientes para zafarte.\""


translate english a3141_1a12bb99:


    xy "\"Sí, lo que sea, quedémonos con eso.\""


translate english a3141_fe3a6abe:



    voice "voice/a31/4100650a01.opus"
    mx "\"¡NO ES LO QUE SEA!\""


translate english a3141_bb58c512:


    xy "\"¿Eh?\""


translate english a3141_f3af5599:


    "No es propio de Miyuki gritar así."


translate english a3141_2a3ebcdc:



    voice "voice/a31/4100660a01.opus"
    mx "\"Sabes, antes no eras así.\""


translate english a3141_7c6a05cc:



    voice "voice/a31/4100670a01.opus"
    mx "\"Shinichi, ¿qué es lo que te da tanto miedo?\""


translate english a3141_0643b960:


    xy "\"No le tengo 'miedo' a nada.\""


translate english a3141_b0c8ca05:


    xy "\"Simplemente no me gustan los conflictos sin sentido.\""


translate english a3141_0bea514a:



    voice "voice/a31/4100680a01.opus"
    mx "\"Mentiroso.\""


translate english a3141_43e004af:


    "Tiene toda la razón."


translate english a3141_c65d9974:


    "Ni siquiera encuentro el ánimo para enojarme por eso."


translate english a3141_dcf5fba2:


    xy "\"El hecho es que Aoi no se siente muy bien.\""


translate english a3141_cccfd225:



    voice "voice/a31/4100690a02.opus"
    aoi "\"Eso no es... ¿boop boop?\""


translate english a3141_dd30a0f0:


    "Aoi intenta discutir, pero se tambalea de lado."


translate english a3141_09e0be12:


    xy "\"¿Ves? Te dije.\""


translate english a3141_ba0dbb5d:



    voice "voice/a31/4100700a02.opus"
    aoi "\"Boop boop boop boop...\""


translate english a3141_af2704f5:


    "Frunce el ceño para sí misma."


translate english a3141_8b94a6db:


    xy "\"Bien, vámonos de aquí.\""


translate english a3141_5ae11465:



    voice "voice/a31/4100710a02.opus"
    aoi "\"Bien.\""


translate english a3141_d35d10ca:



    voice "voice/a31/4100720a01.opus"
    mx "\"......\""


translate english a3141_4adb6bf8:


    "Miyuki todavía no parece convencida, pero la ignoro y guío el camino fuera del edificio."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
