

translate english c7142a_3fa3ad74:


    xy "\"Te amo.\""


translate english c7142a_9fa7313c:


    "Sé que es muy poco y demasiado tarde, ¡pero no puedo quedarme aquí tirado y dejar que me mate!"


translate english c7142a_0e97d08f:


    "Necesito hacer que se calme de alguna manera..."


translate english c7142a_b1ae264a:


    xy "\"Prometo que siempre te amaré, así que...\""


translate english c7142a_29888aaa:


    xy "\"...¡Por favor, solo deja de hacer esto!\""


translate english c7142a_213f5dc7:



    voice "voice/c71/42a00010a01.opus"
    mx "\"Jejeje.\""


translate english c7142a_35549130:



    voice "voice/c71/42a00020a01.opus"
    mx "\"Ya te resignaste a morir. Nunca te molestarías en intentar ganar puntos conmigo ahora.\""


translate english c7142a_d75b46d7:



    voice "voice/c71/42a00030a01.opus"
    mx "\"Lo que significa que no eres tú quien lo dice.\""


translate english c7142a_0cbbb27b:



    voice "voice/c71/42a00040a01.opus"
    mx "\"No... Fue una elección que TÚ tomaste, ¿verdad?\""


translate english c7142a_a5462acc:



    voice "voice/c71/42a00050a01.opus"
    mx "\"Estoy conmovida... Muy conmovida, en serio.\""


translate english c7142a_d02dc598:



    voice "voice/c71/42a00060a01.opus"
    mx "\"Pero es demasiado tarde.\""


translate english c7142a_ee66b2de:



    voice "voice/c71/42a00070a01.opus"
    mx "\"¿De verdad crees que podría creer cualquier cosa que digas ahora?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
