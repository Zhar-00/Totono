

translate english c7142a_3fa3ad74:


    xy "\"I love you.\""


translate english c7142a_9fa7313c:


    "Sé que es muy poco y demasiado tarde, ¡pero no puedo quedarme aquí tirado y dejar que me mate!"


translate english c7142a_0e97d08f:


    "Necesito hacer que se calme de alguna manera..."


translate english c7142a_b1ae264a:


    xy "\"I promise I'll always love you, so...\""


translate english c7142a_29888aaa:


    xy "\"...Please, just stop doing this!\""


translate english c7142a_213f5dc7:



    voice "voice/c71/42a00010a01.opus"
    mx "\"Hehehe.\""


translate english c7142a_35549130:



    voice "voice/c71/42a00020a01.opus"
    mx "\"You've already resigned yourself to death. You'd never bother trying to win brownie points with me now.\""


translate english c7142a_d75b46d7:



    voice "voice/c71/42a00030a01.opus"
    mx "\"Which means you're not the one saying it.\""


translate english c7142a_0cbbb27b:



    voice "voice/c71/42a00040a01.opus"
    mx "\"No... It was a choice YOU made, wasn't it?\""


translate english c7142a_a5462acc:



    voice "voice/c71/42a00050a01.opus"
    mx "\"I'm touched... Really touched, actually.\""


translate english c7142a_d02dc598:



    voice "voice/c71/42a00060a01.opus"
    mx "\"But it's too late.\""


translate english c7142a_ee66b2de:



    voice "voice/c71/42a00070a01.opus"
    mx "\"You really think I could believe anything you say now?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
