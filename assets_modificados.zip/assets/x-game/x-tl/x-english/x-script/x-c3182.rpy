

translate english c3182_d35829be:


    "Pongo las manos en los barrotes de la puerta de la escuela."


translate english c3182_67e1f7fd:


    "El metal está mojado por la lluvia y bastante más frío de lo que esperaba."


translate english c3182_ac699dbf:


    "El fuerte traqueteo resuena por el campus bañado por la luna."


translate english c3182_4734b82a:


    "Pero no me importa."


translate english c3182_6fa4506c:


    "Me impulso y salto por encima en un solo movimiento fluido."


translate english c3182_80c18b5b:


    "Aquí estoy, solo en el predio de la escuela en plena noche."


translate english c3182_2b62d0ea:


    "Es un poco escalofriante, a decir verdad."


translate english c3182_76f436ce:


    "En cualquier otra situación, probablemente me daría la vuelta y correría a casa con el rabo entre las piernas."


translate english c3182_3837f4bc:


    "Y aun así, curiosamente, me encuentro de buen ánimo."


translate english c3182_bd2e309e:


    "De noche, el interior de mi casillero de zapatos se extiende en un túnel interminable de oscuridad."


translate english c3182_2b0b207a:


    "Mientras me cambio a mis zapatos de interior, el más leve repiqueteo de mis suelas sobre el linóleo parece reverberar como un disparo."


translate english c3182_743f72dc:


    "Es algo increíble cómo unas cuantas horas de diferencia pueden convertir un lugar familiar en un mundo totalmente distinto..."


translate english c3182_c2c6ebd3:


    "Aoi está aquí en algún lugar, al acecho en la oscuridad."


translate english c3182_9efc2f1d:


    "Estoy extrañamente seguro de ello."


translate english c3182_92cb6386:


    "Me escabullo por los pasillos, con cuidado de no hacer ruido."


translate english c3182_b8c9751e:


    xy "\"Bingo...\""


translate english c3182_b93dcdc8:


    "Hay charcos de agua de lluvia en el suelo."


translate english c3182_f8edcc3c:


    "Y estos charcos forman un rastro..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
