

translate english e3425_e9fa21cb:



    voice "voice/e34/2500010b02.opus"
    kmsm "\"ERROR.\""


translate english e3425_08fac874:



    voice "voice/e34/2500020b02.opus"
    kmsm "\"RETRY OR REVIEW THE CALCULATION PROCEDURE.\""


translate english e3425_5f037507:


    "No hay forma de saber cuándo aparecerá Miyuki."


translate english e3425_bf22819c:


    "Tengo que darme prisa."


translate english strings:


    old "Попробовать другое число"
    new "Probar otro número"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
