

translate english d7112_b49b53db:


    xy "\"No puedo con esto.\""


translate english d7112_d4070509:


    xy "\"Váyanse a la mierda de mi casa.\""


translate english d7112_81138ff4:



    voice "voice/d71/1200020a02.opus"
    aoi "\"Aoi...\""


translate english d7112_d2822e0c:



    voice "voice/d71/1200030a02.opus"
    aoi "\"...eligió... la opción equivocada...\""


translate english d7112_4f4bdd24:


    "Aoi baja la cabeza y murmura delirantemente para sí misma."


translate english d7112_c86e7ab6:


    "Ya no tengo energía para molestarme en corregirla."


translate english d7112_45092d23:



    voice "voice/d71/1200040b01.opus"
    xtl "\"¿Terminamos aquí?\""


translate english d7112_15b506e2:



    voice "voice/d71/1200050b01.opus"
    xtl "\"Demos por terminada esta noche.\""


translate english d7112_e340b9d6:


    "Su voz resuena a través del aire pesado del cuarto."


translate english d7112_c3fbf547:



    voice "voice/d71/1200060b01.opus"
    xtl "\"Tomémonos un día para calmarnos, y luego—\""


translate english d7112_c4dc4353:



    voice "voice/d71/1200070b03.opus"
    c "\"Pero Aoi-senpai—\""


translate english d7112_7bc619da:



    voice "voice/d71/1200080b01.opus"
    xtl "\"¡Ryuujirou!\""


translate english d7112_cb30863b:


    "Ryuujirou se queda en silencio."


translate english d7112_00f4b5d3:



    voice "voice/d71/1200090b01.opus"
    xtl "\"Vamos, Sone-san... Todos a casa.\""


translate english d7112_c4b9182e:



    voice "voice/d71/1200100a01.opus"
    mx "\"¿¿Pero y Aoi??\""


translate english d7112_30793721:



    voice "voice/d71/1200110a02.opus"
    aoi "\"No te preocupes.\""


translate english d7112_5257a54d:



    voice "voice/d71/1200120a02.opus"
    aoi "\"Todos se olvidarán de mí.\""


translate english d7112_59b3172f:



    voice "voice/d71/1200130a02.opus"
    aoi "\"Así va la historia.\""


translate english d7112_1cc73a66:



    voice "voice/d71/1200140a01.opus"
    mx "\"Aoi...\""


translate english d7112_cc491bff:


    xy "\"La oíste. No necesita tu preocupación.\""


translate english d7112_86d67cb2:


    "No voy a perder el tiempo sintiendo lástima por ella."


translate english d7112_5160f0e3:



    voice "voice/d71/1200150a02.opus"
    aoi "\"Shinichi... Adiós.\""


translate english d7112_5d75760a:


    xy "\"Oh... ¡Espera!\""


translate english d7112_2a467b2d:


    "Casi olvido algo."


translate english d7112_f76304c6:


    "Subo las escaleras a toda prisa."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
