

translate english d7112_b49b53db:


    xy "\"I can't take this.\""


translate english d7112_d4070509:


    xy "\"Get the fuck out of my house.\""


translate english d7112_81138ff4:



    voice "voice/d71/1200020a02.opus"
    aoi "\"Aoi...\""


translate english d7112_d2822e0c:



    voice "voice/d71/1200030a02.opus"
    aoi "\"...picked... the wrong choice...\""


translate english d7112_4f4bdd24:


    "Aoi baja la cabeza y murmura delirantemente para sí misma."


translate english d7112_c86e7ab6:


    "Ya no tengo energía para molestarme en corregirla."


translate english d7112_45092d23:



    voice "voice/d71/1200040b01.opus"
    xtl "\"Are we done here?\""


translate english d7112_15b506e2:



    voice "voice/d71/1200050b01.opus"
    xtl "\"Let's call it a night.\""


translate english d7112_e340b9d6:


    "Su voz resuena a través del aire pesado del cuarto."


translate english d7112_c3fbf547:



    voice "voice/d71/1200060b01.opus"
    xtl "\"Let's all just take a day to cool off, and then later—\""


translate english d7112_c4dc4353:



    voice "voice/d71/1200070b03.opus"
    c "\"But Aoi-senpai—\""


translate english d7112_7bc619da:



    voice "voice/d71/1200080b01.opus"
    xtl "\"Ryuujirou!\""


translate english d7112_cb30863b:


    "Ryuujirou se queda en silencio."


translate english d7112_00f4b5d3:



    voice "voice/d71/1200090b01.opus"
    xtl "\"Come on, Sone-san... Let's all go home.\""


translate english d7112_c4b9182e:



    voice "voice/d71/1200100a01.opus"
    mx "\"But what about Aoi?\""


translate english d7112_30793721:



    voice "voice/d71/1200110a02.opus"
    aoi "\"Don't worry.\""


translate english d7112_5257a54d:



    voice "voice/d71/1200120a02.opus"
    aoi "\"You'll all forget about me.\""


translate english d7112_59b3172f:



    voice "voice/d71/1200130a02.opus"
    aoi "\"That's how the story goes.\""


translate english d7112_1cc73a66:



    voice "voice/d71/1200140a01.opus"
    mx "\"Aoi...\""


translate english d7112_cc491bff:


    xy "\"You heard her. She doesn't need your concern.\""


translate english d7112_86d67cb2:


    "No voy a perder el tiempo sintiendo lástima por ella."


translate english d7112_5160f0e3:



    voice "voice/d71/1200150a02.opus"
    aoi "\"Shinichi... Bye-bye.\""


translate english d7112_5d75760a:


    xy "\"Oh... Wait!\""


translate english d7112_2a467b2d:


    "Casi olvido algo."


translate english d7112_f76304c6:


    "Subo las escaleras a toda prisa."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
