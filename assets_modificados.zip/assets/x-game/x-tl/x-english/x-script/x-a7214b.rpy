

translate english a7214b_0e73145c:



    voice "voice/a72/14b00010a01.opus"
    mx "\"Listen, Shinichi...\""


translate english a7214b_afc98a37:



    voice "voice/a72/14b00020a01.opus"
    mx "\"You like to... experiment, right...?\""


translate english a7214b_54d60fc3:



    voice "voice/a72/14b00030a01.opus"
    mx "\"Today's... a special day, so... I'd prefer... if you came inside me... but...\""


translate english a7214b_ab7c4d27:



    voice "voice/a72/14b00040a01.opus"
    mx "\"Nnng... nnn... If you want to... spice things up...\""


translate english a7214b_da539ac1:



    voice "voice/a72/14b00050a01.opus"
    mx "\"You could always... nnng... cum all over me instead... if you want...! Nnn!\""


translate english a7214b_0fb83041:



    voice "voice/a72/14b00060a01.opus"
    mx "\"Whatever you prefer... okay?\""


translate english a7214b_daff5fb3:


    "La tentación me está derritiendo el cerebro."


translate english a7214b_ddd541da:


    "Mientras siento que estoy al borde de explotar—"


translate english strings:


    old "Кончить в неё"
    new "Correrme dentro de ella"


    old "Кончить на неё"
    new "Correrme sobre ella"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
