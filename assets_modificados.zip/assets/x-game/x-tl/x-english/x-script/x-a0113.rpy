

translate english a0113_6a2d74d8:


    "Decido revisar el historial de llamadas."


translate english a0113_447f93cb:


    "\"Dios.\""


translate english a0113_447f93cb_1:


    "\"Dios.\""


translate english a0113_447f93cb_2:


    "\"Dios.\""


translate english a0113_447f93cb_3:


    "\"Dios.\""


translate english a0113_b2d5a04f:


    "...¿Qué demonios?"


translate english a0113_80a2c231:


    "Después, reviso la agenda de contactos."


translate english a0113_c7396f40:


    "Solo hay una entrada."


translate english a0113_65470cb0:


    "Sí, lo adivinaste. \"God.\""


translate english a0113_fe67494b:


    "...¿Un teléfono desechable para Dios?"


translate english a0113_0265d37d:


    "No hay forma de que esto le pertenezca DE VERDAD al de arriba, ¿verdad?"


translate english a0113_0eca86ca:


    xy "\"...¿Hm?\""


translate english a0113_82b0c284:




    voice "voice/a01/1300010a02.opus"
    voice "voice/a01/1300010a02.opus"
    bm "\"Bip bip...\""


translate english a0113_0accd139:


    xy "\"......\""


translate english a0113_0d0ba218:


    "Una chica me devuelve la mirada."


translate english a0113_b41e7f15:



    voice "voice/a01/1300020a02.opus"
    bm "\"Mi batería se está agotando.\""


translate english a0113_5d9726a4:


    xy "\"¿Qué batería...?\""


translate english a0113_229ea38a:



    voice "voice/a01/1300030a02.opus"
    bm "\"Necesito recargarme.\""


translate english a0113_63b0fa61:



    voice "voice/a01/1300040a02.opus"
    bm "\"¿Quieres... recibir una descarga?\""


translate english a0113_5d61e206:


    "Creo que pulsé el botón equivocado por accidente."


translate english a0113_ea4d60f7:


    "Parece que he lanzado uno de esos juegos de \"novela visual\"."


translate english a0113_73a47b92:


    "He visto a algunos amigos jugar estos en consolas portátiles."


translate english a0113_d5381e4d:


    "No me sorprendería que también hubieran dado el salto al móvil."


translate english a0113_36021c5e:


    "Nunca he jugado uno yo mismo."


translate english a0113_20f6343a:


    "Al menos... no creo que lo haya hecho..."


translate english a0113_f7e57b7b:


    "Pero siento que reconozco ese uniforme..."


translate english a0113_6f043525:


    xy "\"¿Yo te conozco...?\""


translate english a0113_73430c8d:



    voice "voice/a01/1300050a02.opus"
    bm "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english a0113_e0b09453:


    "Puedo oír una voz extraña."


translate english a0113_ff0ea4e8:



    voice "voice/a01/1300060a02.opus"
    bm "\"Bip bip bip bip bip bip bip bip bip bip bip bip bip bip bip...\""


translate english a0113_e6ac7c81:


    "Hay una chica en la azotea sobre las escaleras."


translate english a0113_f1b7ddac:


    "Alzando la mano recta hacia el aire."


translate english a0113_a8cddf1a:


    "Su expresión totalmente vacía."


translate english a0113_0fa285b5:


    "Solo mirando al vacío hacia el cielo..."


translate english a0113_23cbe4ef:


    "Mirando lo que sea que haya más allá..."


translate english a0113_058a987d:



    voice "voice/a01/1300070a02.opus"
    bm "\"Bip bip... bip bip bip... bip bip... bip...\""


translate english a0113_14ea5d4a:


    xy "\"¿Eh...?\""


translate english a0113_35eeba87:


    "Su cuerpo empieza a mecerse."


translate english a0113_a2b6732e:


    "Su voz se desvanece..."


translate english a0113_c559d31b:



    voice "voice/a01/1300080a02.opus"
    bm "\"Bip... bip... bip... b...\""


translate english a0113_7ee318b4:



    voice "voice/a01/1300090a02.opus"
    bm "\"Bip bip...\""


translate english a0113_fcddd2d4:


    xy "\"¡Whoa—!\""


translate english a0113_22a4e233:


    xy "\"Nng... Ay...\""


translate english a0113_1a263551:


    xy "\"¿E-Estás bien?\""


translate english a0113_6a942bff:



    voice "voice/a01/1300100a02.opus"
    bm "\"Bip bip...\""


translate english a0113_0accd139_1:


    xy "\"......\""


translate english a0113_ef556297:


    "Sus ojos se fijan en los míos."


translate english a0113_4cedd881:



    voice "voice/a01/1300110a02.opus"
    bm "\"Mi batería se está agotando.\""


translate english a0113_5d9726a4_1:


    xy "\"¿Qué batería...?\""


translate english a0113_6b96fbd1:



    voice "voice/a01/1300120a02.opus"
    bm "\"Necesito recargarme.\""


translate english a0113_0f973d5c:


    "Su rostro está tan cerca del mío."


translate english a0113_c66525d5:


    "Puedo sentir su aliento en mi piel."


translate english a0113_8c6400aa:


    "Sus labios están a centímetros."


translate english a0113_dd22def8:


    "Según la leyenda de la escuela..."


translate english a0113_ba974f0f:


    "...si dos personas se besan en la azotea, su amor será eterno."


translate english a0113_359dc447:



    voice "voice/a01/1300130a02.opus"
    bm "\"¿Quieres... recibir una descarga?\""


translate english strings:


    old "Подзарядиться"
    new "Recibir la descarga"


    old "Не подзаряжаться"
    new "No recibir la descarga"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
