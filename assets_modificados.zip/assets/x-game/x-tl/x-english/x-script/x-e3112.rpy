

translate english e3112_f7c675a6:



    voice "voice/e31/1200010a01.opus"
    mx "\"...¿Shinichi? Despierta. ¡DESPIERTA, tonto!\""


translate english e3112_32b17223:


    xy "\"Nnnrgh... whuh... nnn...\""


translate english e3112_c3f8682a:


    xy "\"¿Q... qué rayos...? ¿Dónde estoy...?\""


translate english e3112_efa1cbb4:


    "Lo siguiente que sé es que estoy tirado en medio del piso de la sala."


translate english e3112_cd69c064:


    "El teléfono de Miyuki está sobre la mesa con el juego todavía abierto."


translate english e3112_47011248:



    voice "voice/e31/1200020a01.opus"
    mx "\"No es saludable desmayarse justo después de comer. Vas a engordar.\""


translate english e3112_b9359e39:



    voice "voice/e31/1200030a01.opus"
    mx "\"¡Y si vas a dormir, al menos duerme en una cama decente!\""


translate english e3112_74e0999a:


    xy "\"Oh... Cierto... Perdón...\""


translate english e3112_6c239a02:


    "Me derrumbo sobre la cama, y mi conciencia se desvanece rápidamente."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
