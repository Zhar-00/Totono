

translate english e3112_f7c675a6:



    voice "voice/e31/1200010a01.opus"
    mx "\"...Shinichi? Wake up. Wake UP, you dummy!\""


translate english e3112_32b17223:


    xy "\"Nnnrgh... whuh... nnn...\""


translate english e3112_c3f8682a:


    xy "\"Wh... what the...? Where am I...?\""


translate english e3112_efa1cbb4:


    "Lo siguiente que sé es que estoy tirado en medio del piso de la sala."


translate english e3112_cd69c064:


    "El teléfono de Miyuki está sobre la mesa con el juego todavía abierto."


translate english e3112_47011248:



    voice "voice/e31/1200020a01.opus"
    mx "\"It's not healthy to pass out right after eating. You'll get fat.\""


translate english e3112_b9359e39:



    voice "voice/e31/1200030a01.opus"
    mx "\"And if you're going to sleep, at least sleep in a proper bed!\""


translate english e3112_74e0999a:


    xy "\"Oh... Right... Sorry...\""


translate english e3112_6c239a02:


    "Me derrumbo sobre la cama, y mi conciencia se desvanece rápidamente."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
