

translate english a5131_975d920b:


    xy "\"Perdón por la tardanza.\""


translate english a5131_c401fa5f:


    "Para cuando vuelvo, la primera clase ya empezó."


translate english a5131_093311dc:


    "Me disculpo con el profesor y regreso a mi pupitre."


translate english a5131_787d4cf3:


    xy "\"¿Hm?\""


translate english a5131_05a415ff:



    voice "voice/a51/3100010b01.opus"
    xtl "\"......! ......!\""


translate english a5131_b15019da:


    "Yuutarou me pasa una nota, sonriendo."


translate english a5131_1de9fe30:


    "—¿Te rechazó? Lo hizo, ¿verdad?!"


translate english a5131_220d51b5:


    xy "\"Haah...\""


translate english a5131_b63117cd:


    "Suspiro y arrugo la nota en una bola."


translate english a5131_53ed1d99:


    "Cuando levanto la vista—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
