

translate english d4222_90bb569b:


    "No tengo la menor idea de cómo ayudarla. Debería simplemente llamar a una ambulancia."


translate english d4222_61eb6c87:


    "Saco mi teléfono del bolsillo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
