

translate english c7142b_1db3d076:


    xy "\"I hate you.\""


translate english c7142b_ba2e8151:


    "Las palabras salen de mis labios en un murmullo."


translate english c7142b_b239a221:


    xy "\"After everything you've done, you want me to love you...?\""


translate english c7142b_cd7f172e:



    voice "voice/c71/42b00010a01.opus"
    mx "\"Yes, I'm sure that's how you feel.\""


translate english c7142b_412c4e45:



    voice "voice/c71/42b00020a01.opus"
    mx "\"But I know YOU feel differently.\""


translate english c7142b_d431eb84:



    voice "voice/c71/42b00030a01.opus"
    mx "\"YOU think YOU can just reload YOUR save file and try again, don't YOU?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
