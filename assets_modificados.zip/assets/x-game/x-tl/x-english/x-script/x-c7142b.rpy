

translate english c7142b_1db3d076:


    xy "\"Te odio.\""


translate english c7142b_ba2e8151:


    "Las palabras salen de mis labios en un murmullo."


translate english c7142b_b239a221:


    xy "\"Después de todo lo que has hecho, ¿quieres que te ame...?\""


translate english c7142b_cd7f172e:



    voice "voice/c71/42b00010a01.opus"
    mx "\"Sí, seguro que así te sientes.\""


translate english c7142b_412c4e45:



    voice "voice/c71/42b00020a01.opus"
    mx "\"Pero sé que TÚ te sientes diferente.\""


translate english c7142b_d431eb84:



    voice "voice/c71/42b00030a01.opus"
    mx "\"TÚ crees que puedes simplemente recargar TU archivo guardado e intentarlo otra vez, ¿verdad?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
