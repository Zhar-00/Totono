

translate english c4151_ac3d53a7:


    "Esa fue la última vez que vi a Aoi antes de que desapareciera."


translate english c4151_50ffc3df:


    "Lo único que dejó atrás fue un solo gatito."


translate english c4151_edd735d7:


    "Fue tan... repentino."


translate english c4151_af593612:



    voice "voice/c41/5100010a01.opus"
    mx "\"I guess she wanted to cut ties with us.\""


translate english c4151_bf9f50ca:


    "Miyuki murmura para sí misma."


translate english c4151_ab381a98:


    "Justo cuando pensaba que todos habíamos arreglado las cosas."


translate english c4151_888ca729:


    "¿Por qué Aoi nos dejaría en visto así?"


translate english c4151_52bdebe9:



    voice "voice/c41/5100020a01.opus"
    mx "\"Do you have any idea where she might be?\""


translate english c4151_a59fe015:


    "Claro que no."


translate english c4151_bc3466cf:


    "No tengo la menor idea."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
