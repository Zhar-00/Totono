

translate english a5165_5fe1d0ef:


    "Justo entonces suena el timbre, y los dos nos quedamos helados como venados ante los faros."


translate english a5165_c7bee4e6:


    xy "\"...Sorry. Looks like we have a visitor.\""


translate english a5165_0b490767:


    xy "\"I called Yuutarou over. The two of us are going to help you, okay?\""


translate english a5165_fd582e14:


    xy "\"Here, put this on. I know it's too big for you, but it'll have to do!\""


translate english a5165_139bb485:


    xy "\"Be sure to put it on before I get back, okay? Can you promise me?\""


translate english a5165_ef9de869:


    xy "\"Just wear it, okay?\""


translate english a5165_473c28ae:


    "Le entrego una de mis camisetas viejas y salgo de la habitación de inmediato."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
