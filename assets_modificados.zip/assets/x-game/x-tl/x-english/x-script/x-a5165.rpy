

translate english a5165_5fe1d0ef:


    "Justo entonces suena el timbre, y los dos nos quedamos helados como venados ante los faros."


translate english a5165_c7bee4e6:


    xy "\"...Perdón. Parece que tenemos visita.\""


translate english a5165_0b490767:


    xy "\"Llamé a Yuutarou. Los dos vamos a ayudarte, ¿sí?\""


translate english a5165_fd582e14:


    xy "\"Toma, ponte esto. Sé que es muy grande para ti, ¡pero tendrá que servir!\""


translate english a5165_139bb485:


    xy "\"Asegúrate de ponértelo antes de que vuelva, ¿sí? ¿Me lo prometes?\""


translate english a5165_ef9de869:


    xy "\"Solo póntelo, ¿sí?\""


translate english a5165_473c28ae:


    "Le entrego una de mis camisetas viejas y salgo de la habitación de inmediato."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
