

translate english e1139_c2ba8824:


    "No hay forma de que el mundo sea un videojuego."


translate english e1139_e9573284:


    "No hay parches de actualización en la vida real."


translate english e1139_c4578928:


    "Aoi es un personaje de un videojuego."


translate english e1139_05963ec5:


    "No estoy siendo retenido como cautivo."


translate english e1139_f070caca:


    "Miyuki simplemente no puede distinguir entre la fantasía y la realidad, eso es todo..."


translate english e1139_9fa0a28c:


    "Nada de esto puede ser cierto..."


translate english e1139_7e597ee3:


    "Y sin embargo... y sin embargo—"


translate english e1139_9dd0ef10:



    voice "voice/e11/3900010a01.opus"
    mx "\"Let's step inside the game.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
