

translate english e1153a_MAIN_9ea2f78c:


    " "



translate english e1153a_4b3b643d:



    voice "voice/e11/53a00010a01.opus"
    mx "\"There's no use fighting me.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
