

translate english e1155_6a84c334:



    voice "voice/e11/5500010a01.opus"
    mx "\"Come on... Let's stop all this.\""


translate english e1155_0f29c342:


    "Miyuki baja la cabeza."


translate english e1155_cc928280:



    voice "voice/e11/5500020a01.opus"
    mx "\"You know you'll never escape from me.\""


translate english e1155_77e9af8e:



    voice "voice/e11/5500030a01.opus"
    mx "\"So just give up... and kiss me...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
