

translate english e2322d_98b3c634:


    "Nada..."


translate english e2322d_bc397330:


    "La pantalla se bloquea, y suspiro profundamente."


translate english e2322d_de3e92ee:


    "Supongo que no conozco a Miyuki tan bien como creía..."


translate english e2322d_5c2ef076:


    "En silencio, la miro de reojo. A mi lado, su plácido sueño continúa sin interrupción."


translate english e2322d_74d95a88:


    "Si tan solo fuera una opción romántica en un videojuego... entonces podría conectarme y buscar una guía..."


translate english e2322d_e2db6fd3:


    "Pero esto es la realidad."


translate english e2322d_9d1f53fb:


    "No voy a averiguar las respuestas a estas preguntas a menos que empiece a prestar más atención a lo que dice."


translate english e2322d_bddf390e:


    "Todavía hay tanto que no sé sobre ella..."


translate english e2322d_a2344909:


    xy "\"...Haah...\""


translate english e2322d_437be171:


    "Aquí viene la autocompasión..."


translate english e2322d_23ca12b7:


    "Ya está. Me voy a la cama."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
