

translate english e2031_c26fc7f3:



    voice "voice/e20/3100010a01.opus"
    mx "\"Shinichi.\""


translate english e2031_bf5052cd:



    voice "voice/e20/3100020a01.opus"
    mx "\"It's been six months since you started living with me...\""


translate english e2031_b90009da:



    voice "voice/e20/3100030a01.opus"
    mx "\"A whole six months! Can you believe it?\""


translate english e2031_8ccd3add:



    voice "voice/e20/3100040a01.opus"
    mx "\"Look... Don't YOU think it's been long enough?\""


translate english e2031_9c2f3c28:



    voice "voice/e20/3100050a01.opus"
    mx "\"Seems like YOU'VE accepted YOUR defeat, anyway.\""


translate english e2031_23da4cbc:



    voice "voice/e20/3100060a01.opus"
    mx "\"YOU'VE stayed in this world for quite some time now, so...\""


translate english e2031_d1b94341:



    voice "voice/e20/3100070a01.opus"
    mx "\"I assume this means YOU'RE prepared to spend eternity with me?\""


translate english e2031_c1aeedb9:



    voice "voice/e20/3100080a01.opus"
    mx "\"YOU'LL stay with me forever, won't YOU?\""


translate english e2031_204819e9:


    xy "\"Miyuki...?\""


translate english e2031_ffe9eae4:



    voice "voice/e20/3100090a01.opus"
    mx "\"Come on! I need to know!\""


translate english e2031_f4eeb400:



    voice "voice/e20/3100100a01.opus"
    mx "\"Tell me how you really feel!\""


translate english strings:


    old "Я бы предпочёл остаться здесь"
    new "Preferiría quedarme aquí"


    old "Этот мир испорчен"
    new "Este mundo está desquiciado"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
