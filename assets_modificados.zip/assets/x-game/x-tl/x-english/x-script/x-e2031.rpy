

translate english e2031_c26fc7f3:



    voice "voice/e20/3100010a01.opus"
    mx "\"Shinichi.\""


translate english e2031_bf5052cd:



    voice "voice/e20/3100020a01.opus"
    mx "\"Han pasado seis meses desde que empezaste a vivir conmigo...\""


translate english e2031_b90009da:



    voice "voice/e20/3100030a01.opus"
    mx "\"¡Seis meses enteros! ¿Puedes creerlo?\""


translate english e2031_8ccd3add:



    voice "voice/e20/3100040a01.opus"
    mx "\"Mira... ¿No crees que ya ha pasado suficiente tiempo?\""


translate english e2031_9c2f3c28:



    voice "voice/e20/3100050a01.opus"
    mx "\"De todos modos, parece que ya aceptaste tu derrota.\""


translate english e2031_23da4cbc:



    voice "voice/e20/3100060a01.opus"
    mx "\"Ya llevas bastante tiempo en este mundo, así que...\""


translate english e2031_d1b94341:



    voice "voice/e20/3100070a01.opus"
    mx "\"Supongo que eso significa que estás listo para pasar la eternidad conmigo.\""


translate english e2031_c1aeedb9:



    voice "voice/e20/3100080a01.opus"
    mx "\"Te quedarás conmigo por siempre, ¿verdad?\""


translate english e2031_204819e9:


    xy "\"¿Miyuki...?\""


translate english e2031_ffe9eae4:



    voice "voice/e20/3100090a01.opus"
    mx "\"¡Vamos! ¡Necesito saberlo!\""


translate english e2031_f4eeb400:



    voice "voice/e20/3100100a01.opus"
    mx "\"¡Dime lo que sientes de verdad!\""


translate english strings:


    old "Я бы предпочёл остаться здесь"
    new "Preferiría quedarme aquí"


    old "Этот мир испорчен"
    new "Este mundo está desquiciado"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
