

translate english a2192b_660f1fce:


    xy "\"Toma, esto es para ti.\""


translate english a2192b_95327bfc:


    "Le entrego su regalo a Aoi."


translate english a2192b_bc575504:



    voice "voice/a21/92b00010a02.opus"
    aoi "\"Aoi no puede aceptarlo.\""


translate english a2192b_aeff5302:



    voice "voice/a21/92b00020a01.opus"
    mx "\"Está bien. Quiero que lo tengas.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
