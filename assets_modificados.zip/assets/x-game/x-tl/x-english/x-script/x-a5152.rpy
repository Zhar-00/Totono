

translate english a5152_b96e94e9:


    "De vuelta en casa, después de darle de cenar a Eru, por fin tengo tiempo de respirar."


translate english a5152_0c0be87b:


    "Miro el reloj. Ya casi anochece."


translate english a5152_c13a04c3:


    "Miyuki never specified a meetup time beyond \"tonight,\"pero probablemente se refería a cuando oscurezca."


translate english a5152_0accd139:


    xy "\"\"......Aaah...\"\""


translate english a5152_ba461e0b:


    "—Necesito hablar contigo."


translate english a5152_306e37d8:


    "Sigo leyendo su correo una y otra vez."


translate english a5152_8b6d1c83:


    "Puede que sea tonto, pero no TAN tonto."


translate english a5152_e52a8789:


    "Tengo una idea bastante clara de qué exactamente quiere hablar."


translate english a5152_f2bdd897:


    "El problema es..."


translate english a5152_a9a48116:


    "Significará trastocar toda nuestra amistad actual."


translate english a5152_54e48daf:


    "Los minutos pasan."


translate english a5152_4d15d3e2:


    "¿Ya estará esperándome en las jaulas de bateo?"


translate english a5152_62e506f2:


    "Puedo imaginarla ahí de pie, sola, bateando en silencio."


translate english a5152_99ec0a15:


    "La imagen mental basta para ponerme inquieto."


translate english a5152_ca003f8d:


    "Deberíamos seguir siendo amigos."


translate english a5152_2a5c1c5a:


    "Eso es lo que me he dicho todo este tiempo."


translate english a5152_c70b8af2:


    "Y sin embargo..."


translate english a5152_bb2b29ed:


    "Lo sé, pero..."


translate english a5152_4c129c32:


    "¿Y si..."


translate english a5152_39e7c143:


    "Pero..."


translate english a5152_f114b3f1:


    "Un escalofrío me recorre la columna."


translate english a5152_639a3ee3:


    "Mi cuerpo se niega a moverse."


translate english a5152_211270a2:


    "Quizá sea un vendedor a domicilio o un recolector callejero... en cuyo caso, probablemente se rendirá tras un intento."


translate english a5152_74895e0d:


    "Sin embargo—"


translate english a5152_ebc23d47:


    "El timbre sigue sonando."


translate english a5152_abfec0ad:


    "Resuena dentro de mi cabeza, sin fin."


translate english a5152_b7dd1b52:


    "Antes de haber decidido, ya estoy de pie."


translate english a5152_aee18e8b:


    "Sin embargo, al acercarme a la puerta principal, me quedo helado."


translate english a5152_20c7f43f:


    "Quizá se vayan tras ese último intento."


translate english a5152_debb84f4:


    "Empiezo a reconsiderar—"


translate english a5152_405309f6:


    xy "\"......Haah...\""


translate english a5152_a26ef1ed:


    "¿Ya terminó?"


translate english a5152_377f26e7:


    "Aguanto la respiración y busco cualquier señal de vida."


translate english a5152_bb58c512:


    xy "\"Huh?\""


translate english a5152_0a3f50d4:



    voice "voice/a51/5200020a02.opus"
    aoi "\"Shinichi...? You there?\""


translate english a5152_4ba492e0:


    xy "\"Aoi?!\""


translate english a5152_769836b0:


    "Corro apresuradamente a la puerta principal y la abro."


translate english a5152_3e61b9c2:



    voice "voice/a51/5200030a02.opus"
    aoi "\"Help me...\""


translate english a5152_2649732a:


    "Aoi cae sobre el umbral hacia mi casa, blanca como una sábana."


translate english a5152_18d6a50b:



    voice "voice/a51/5200040a02.opus"
    aoi "\"Lost my phone...\""


translate english a5152_9ce56893:


    "Se desploma en el sofá."


translate english a5152_445b302d:


    "Su voz es apenas un susurro diminuto y débil."


translate english a5152_76ce7784:



    voice "voice/a51/5200050a02.opus"
    aoi "\"Without my phone, Aoi can't get transmissions from God...\""


translate english a5152_bf5afaba:



    voice "voice/a51/5200060a02.opus"
    aoi "\"Aoi's... memories... will be erased...\""


translate english a5152_ccb7a8c9:


    xy "\"Don't worry. It's gonna be alright. Just calm down, okay?\""


translate english a5152_74dccfc7:



    voice "voice/a51/5200070a02.opus"
    aoi "Pero..."


translate english a5152_470422a3:



    voice "voice/a51/5200090a02.opus"
    aoi "\"Eru...\""


translate english a5152_4677fe86:


    "Con un poco de cariño de su gato transceptor, Aoi parece recobrar la compostura."


translate english a5152_a54195fe:


    xy "\"You just dropped it somewhere, yeah? I'll help you look for it. Trust me, we'll find it in no time.\""


translate english a5152_5286aea5:



    voice "voice/a51/5200100a02.opus"
    aoi "\"You mean it?\""


translate english a5152_80ae3275:


    xy "\"Of course! Would I lie to you?\""


translate english a5152_f5a186e9:



    voice "voice/a51/5200110a02.opus"
    aoi "\"Thank you so much!\""


translate english a5152_9b9eca11:


    xy "\"The thing is, uh... I have plans tonight. Can it wait until after?\""


translate english a5152_e63fe3a0:


    "Por alguna razón, no logro admitir que me voy a encontrar con Miyuki."


translate english a5152_3cd739fb:


    xy "\"I'll wrap it up real fast, then come straight back and—\""


translate english a5152_080cbad1:



    voice "voice/a51/5200120a02.opus"
    aoi "\"No!\""


translate english a5152_41005e8f:


    "Aoi se aferra a mi manga."


translate english a5152_54227755:



    voice "voice/a51/5200130a02.opus"
    aoi "\"Don't leave me... Shinichi...\""


translate english a5152_45200778:



    voice "voice/a51/5200140a02.opus"
    aoi "\"Aoi... doesn't want to disappear...!\""


translate english a5152_b2caf680:


    xy "\"Aoi's... memories... will be erased...\""


translate english a5152_7f42231d:


    "De la nada, de pronto tengo un recuerdo de Miyuki de niña."


translate english a5152_d327be72:


    "De la antigua ella, de cuando no encajaba."


translate english a5152_f60dae84:


    "De cuando yo era todo lo que tenía."


translate english a5152_fabbf627:


    "De golpe, todo encaja."


translate english a5152_9ce05651:


    "No tengo ningún talento especial."


translate english a5152_37b54b02:


    "Soy malo en los estudios y soy malo en los deportes."


translate english a5152_7b586ba8:


    "Soy el don nadie supremo."


translate english a5152_3acd6e9c:


    "Lo sé mejor que nadie."


translate english a5152_80ecf551:


    "Y sin embargo quería ayudarla de todos modos."


translate english a5152_12ad321b:


    "Quería poder mantener la cabeza en alto, sabiendo que era algo que logré por mí mismo."


translate english a5152_1c76b1a2:


    "Quizá entonces podría aprender a aceptarme tal como soy."


translate english a5152_e86df407:


    xy "\"You won't disappear.\""


translate english a5152_1802f47a:


    xy "\"I'm going to help you.\""


translate english a5152_e03ef954:



    voice "voice/a51/5200150a02.opus"
    aoi "\"Don't leave me... Shinichi...\""


translate english a5152_7b18ce53:



    voice "voice/a51/5200160a02.opus"
    aoi "\"Thank you...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
