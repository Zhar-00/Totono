

translate english a1122_f2b85151:



    voice "voice/a11/2200010a02.opus"
    aoi "\"¿Bip bip...?\""


translate english a1122_0accd139:


    xy "\"......\""


translate english a1122_ef556297:


    "Sus ojos se fijan en los míos."


translate english a1122_add13683:



    voice "voice/a11/2200020a02.opus"
    aoi "\"Mi batería se está agotando.\""


translate english a1122_5d9726a4:


    xy "\"¿Qué batería...?\""


translate english a1122_947d8a7a:



    voice "voice/a11/2200030a02.opus"
    aoi "\"Necesito recargarme.\""


translate english a1122_277f38bb:



    voice "voice/a11/2200040a02.opus"
    aoi "\"¿Quieres... recibir una descarga?\""


translate english a1122_a9d668aa:


    "Sí, definitivamente es el mismo juego de ayer."


translate english a1122_50a9be1b:


    "La conversación se desarrolla un poco diferente en el juego, pero en su mayor parte es exactamente igual a lo que pasó en la azotea."


translate english a1122_9c31b7cc:


    "Este nivel de precisión milimétrica no puede ser una coincidencia."


translate english a1122_0fd43e88:


    "Debía de estar intentando recrear la escena palabra por palabra a propósito."


translate english a1122_19e664c7:


    "¿De verdad está... interesada en mí...?"


translate english a1122_e65d36ad:


    xy "\"Whoa, tranquilo, amigo.\""


translate english a1122_ca01a7fa:


    "Murmuro para mí mismo."


translate english a1122_bac567af:


    "Es demasiado pronto para sacar cualquier tipo de conclusión."


translate english a1122_4f32c706:


    "Antes de ayer, Mukou y yo ni siquiera nos habíamos hablado."


translate english a1122_2af9e1a2:


    "Obligándome a mantener la cabeza fría, retomo el juego."


translate english a1122_e0df9c3a:



    voice "voice/a11/2200050a02.opus"
    aoi "\"¡Espera!\""


translate english a1122_4da409eb:


    xy "\"¿Qué demonios estás haciendo?\""


translate english a1122_417fb6e1:



    voice "voice/a11/2200060a02.opus"
    aoi "\"Soy la mamá gata.\""


translate english a1122_ad25b5eb:


    xy "\"Buen intento. Los gatos no hablan. Maúllan.\""


translate english a1122_e80fb7b7:



    voice "voice/a11/2200070a02.opus"
    aoi "\"Bip bip...\""


translate english a1122_96580822:


    "Aoi se mira a sí misma con el ceño fruncido por un momento."


translate english a1122_837efa71:



    voice "voice/a11/2200080a02.opus"
    aoi "\"¡Miau! Soy la mamá gata.\""


translate english a1122_f8c6441d:


    xy "\"No era eso lo que quería decir...\""



translate english a1122_6b2aef09:


    "La escena me resulta familiar."


translate english a1122_ad87bc30:


    "Al menos, definitivamente parece el tipo de cosa que diría la Mukou del mundo real."


translate english a1122_d7a5ee61:


    "Y conociendo su afición por las payasadas raras, no puedo estar seguro de que no haría algo así en la vida real."


translate english a1122_0fd4d656:


    "\"......\""


translate english a1122_577dddb7:


    "I shoot a furtive glance at the \"IRL\"Mukou."


translate english a1122_fe53b3ce:



    voice "voice/a11/2200090a02.opus"
    aoi "\"...Bip bip...\""


translate english a1122_fabe7a00:


    "Ahí está otra vez su pose característica."


translate english a1122_57d73944:


    "No toma apuntes. De hecho, parece no importarle la clase en absoluto. En vez de eso, solo se queda sentada, con la mano en el aire, mirando al vacío."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
