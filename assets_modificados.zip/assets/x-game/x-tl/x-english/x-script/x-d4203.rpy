

translate english d4203_d1e4872e:


    xy "\"...Oh, mi culpa.\""


translate english d4203_5da8a56d:


    xy "\"Solo me sorprendió ver a Eru aquí.\""


translate english d4203_54c2f1ab:



    voice "voice/d42/0300010a01.opus"
    mx "\"¿Te vas a quedar?\""


translate english d4203_7126ee93:


    "Eru maúlla con tristeza."


translate english d4203_4c971aa4:


    "Pero ya he tomado una decisión."


translate english d4203_11c1d4e2:


    xy "\"Claro que me quedo.\""


translate english d4203_a7db3aab:


    xy "\"¿Sabes? Pasé todo ese tiempo buscando a Aoi...\""


translate english d4203_10b0054c:


    xy "\"Pero al final, solo quería decirle... que por fin me había reconciliado con lo que de verdad siento.\""


translate english d4203_af4b7576:



    voice "voice/d42/0300030a01.opus"
    mx "\"¿Lo que sientes...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
