

translate english d4203_d1e4872e:


    xy "\"...Oh, my bad.\""


translate english d4203_5da8a56d:


    xy "\"I was just surprised to see Eru here.\""


translate english d4203_54c2f1ab:



    voice "voice/d42/0300010a01.opus"
    mx "\"Will you stay?\""


translate english d4203_7126ee93:


    "Eru maúlla con tristeza."


translate english d4203_4c971aa4:


    "Pero ya he tomado una decisión."


translate english d4203_11c1d4e2:


    xy "\"Of course I'll stay.\""


translate english d4203_a7db3aab:


    xy "\"You know, I spent all that time looking for Aoi...\""


translate english d4203_10b0054c:


    xy "\"But in the end, I just wanted to tell her... that I'd finally come to terms with how I truly feel.\""


translate english d4203_af4b7576:



    voice "voice/d42/0300030a01.opus"
    mx "\"How you feel...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
