

translate english c5221_046b90d0:



    voice "voice/c52/2100010b01.opus"
    xtl "\"¡Buenos días!\""


translate english c5221_a1218e7b:


    xy "\"Oh, hey. Buenos días.\""


translate english c5221_e12c37c6:



    voice "voice/c52/2100020b01.opus"
    xtl "\"¿Qué tal? ¿Algo mal?\""


translate english c5221_ff409b2c:


    xy "\"No, no realmente...\""


translate english c5221_c72d4c84:



    voice "voice/c52/2100030b01.opus"
    xtl "\"No peleaste con Mukou ni nada, ¿o sí?\""


translate english c5221_13e6e95f:



    voice "voice/c52/2100040a02.opus"
    aoi "\"¡Entendido!\""


translate english c5221_5688e4a9:


    "Oigo la voz de Aoi desde el otro lado del salón."


translate english c5221_5bf7ec27:


    "Miro y la encuentro de pie entre un grupo de chicas todas reunidas alrededor de Miyuki."


translate english c5221_82163992:


    "Aparentemente están empezando a ver a Aoi como una especie de mascota de la clase..."


translate english c5221_97fe3ddc:



    voice "voice/c52/2100050a02.opus"
    aoi "\"Aoi sabe la respuesta.\""


translate english c5221_a50d2706:



    voice "voice/c52/2100060a02.opus"
    aoi "\"Miyuki tiene copa F.\""


translate english c5221_4d5d8431:



    voice "voice/c52/2100070a01.opus"
    mx "\"¡HEY! ¡¿Cómo sabes eso?!\""


translate english c5221_aa90a416:



    voice "voice/c52/2100080a02.opus"
    aoi "\"Poderes de transceptor.\""


translate english c5221_fb1d48f6:


    xy "\"¿De qué demonios están hablando...?\""


translate english c5221_0e6e513e:



    voice "voice/c52/2100090b01.opus"
    xtl "\"Charla de chicas... ¡Lo de los sueños...!\""


translate english c5221_735ed8a4:



    voice "voice/c52/2100100b01.opus"
    xtl "\"¡Y los pechos de las chicas están llenos de esperanzas y deseos, ¿sabes?!\""


translate english c5221_b17e2a8c:


    xy "\"Por favor, cállate para siempre.\""


translate english c5221_37442ba1:



    voice "voice/c52/2100110b01.opus"
    xtl "Siento que se está integrando más últimamente.\""


translate english c5221_80b7ccbc:


    xy "\"Sí...\""


translate english c5221_cb2c59e0:



    voice "voice/c52/2100120b01.opus"
    xtl "\"......\""


translate english c5221_4a7acef5:



    voice "voice/c52/2100130b01.opus"
    xtl "\"¿Las cosas no van bien entre ustedes?\""


translate english c5221_a860db59:


    xy "\"Estamos bien.\""


translate english c5221_ac121a40:



    voice "voice/c52/2100140b01.opus"
    xtl "\"¿Seguro?\""



translate english c5221_34ff3fe8:


    xy "\"...¿Qué quieres de mí?\""


translate english c5221_49417314:


    "Puedo sentir mi voz subir una octava."


translate english c5221_3eb47a58:


    xy "\"¿Quieres decirme algo? Entonces dímelo a la cara.\""


translate english c5221_fc92a466:



    voice "voice/c52/2100150b01.opus"
    xtl "\"Pues... Es que... He estado oyendo unos rumores sobre, eh... que Mukou anda durmiendo por ahí...\""


translate english c5221_8e5d7ab4:


    xy "\"¡SON SOLO RUMORES!\""


translate english c5221_66ec53b7:


    "Mi voz resuena por todo el salón de clases."


translate english c5221_f014f4c0:


    "Al instante, puedo sentir a todos mirándome."


translate english c5221_127a7590:



    voice "voice/c52/2100160a02.opus"
    aoi "\"¿Shinichi...?\""


translate english c5221_a3f5f50a:


    "Aoi me mira, pero agito la mano para descartar su preocupación."


translate english c5221_15b9a8ac:


    "Me obligo a calmarme, luego me giro hacia Yuutarou."


translate english c5221_f16d57e9:


    xy "\"...Perdón por gritar así.\""


translate english c5221_247e6e50:



    voice "voice/c52/2100170b01.opus"
    xtl "\"No, fue mi culpa. Perdón.\""


translate english c5221_4ae789cd:


    "Si realmente confiara en Aoi, entonces no habría sentido la necesidad de gritar en primer lugar..."


translate english c5221_2c467375:


    "...y esta revelación realmente escuece."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
