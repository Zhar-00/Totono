

translate english c5221_046b90d0:



    voice "voice/c52/2100010b01.opus"
    xtl "\"Morning!\""


translate english c5221_a1218e7b:


    xy "\"Oh, hey. Morning.\""


translate english c5221_e12c37c6:



    voice "voice/c52/2100020b01.opus"
    xtl "\"What's up? Something wrong?\""


translate english c5221_ff409b2c:


    xy "\"No, not really...\""


translate english c5221_c72d4c84:



    voice "voice/c52/2100030b01.opus"
    xtl "\"You didn't have a fight with Mukou or something, did ya?\""


translate english c5221_13e6e95f:



    voice "voice/c52/2100040a02.opus"
    aoi "\"Got it!\""


translate english c5221_5688e4a9:


    "Oigo la voz de Aoi desde el otro lado del salón."


translate english c5221_5bf7ec27:


    "Miro y la encuentro de pie entre un grupo de chicas todas reunidas alrededor de Miyuki."


translate english c5221_82163992:


    "Aparentemente están empezando a ver a Aoi como una especie de mascota de la clase..."


translate english c5221_97fe3ddc:



    voice "voice/c52/2100050a02.opus"
    aoi "\"Aoi knows the answer.\""


translate english c5221_a50d2706:



    voice "voice/c52/2100060a02.opus"
    aoi "\"Miyuki is an F-cup.\""


translate english c5221_4d5d8431:



    voice "voice/c52/2100070a01.opus"
    mx "\"HEY! How do you know that?!\""


translate english c5221_aa90a416:



    voice "voice/c52/2100080a02.opus"
    aoi "\"Transceiver powers.\""


translate english c5221_fb1d48f6:


    xy "\"The hell are they even talking about...?\""


translate english c5221_0e6e513e:



    voice "voice/c52/2100090b01.opus"
    xtl "\"Girl talk... The stuff of dreams...!\""


translate english c5221_735ed8a4:



    voice "voice/c52/2100100b01.opus"
    xtl "\"And girls' breasts are filled with hopes and wishes, you know!\""


translate english c5221_b17e2a8c:


    xy "\"Please shut up forever.\""


translate english c5221_37442ba1:



    voice "voice/c52/2100110b01.opus"
    xtl "Siento que se está integrando más últimamente.\""


translate english c5221_80b7ccbc:


    xy "\"Yeah...\""


translate english c5221_cb2c59e0:



    voice "voice/c52/2100120b01.opus"
    xtl "\"......\""


translate english c5221_4a7acef5:



    voice "voice/c52/2100130b01.opus"
    xtl "\"Are things not going well between you guys?\""


translate english c5221_a860db59:


    xy "\"We're fine.\""


translate english c5221_ac121a40:



    voice "voice/c52/2100140b01.opus"
    xtl "\"You sure?\""



translate english c5221_34ff3fe8:


    xy "\"...What do you want from me?\""


translate english c5221_49417314:


    "Puedo sentir mi voz subir una octava."


translate english c5221_3eb47a58:


    xy "\"You wanna say something to me? Then say it to my face.\""


translate english c5221_fc92a466:



    voice "voice/c52/2100150b01.opus"
    xtl "\"Well... It's just... I've been hearing some rumors about, uh... Mukou sleeping around...\""


translate english c5221_8e5d7ab4:


    xy "\"THEY'RE JUST RUMORS!\""


translate english c5221_66ec53b7:


    "Mi voz resuena por todo el salón de clases."


translate english c5221_f014f4c0:


    "Al instante, puedo sentir a todos mirándome."


translate english c5221_127a7590:



    voice "voice/c52/2100160a02.opus"
    aoi "\"Shinichi...?\""


translate english c5221_a3f5f50a:


    "Aoi me mira, pero agito la mano para descartar su preocupación."


translate english c5221_15b9a8ac:


    "Me obligo a calmarme, luego me giro hacia Yuutarou."


translate english c5221_f16d57e9:


    xy "\"...Sorry for shouting like that.\""


translate english c5221_247e6e50:



    voice "voice/c52/2100170b01.opus"
    xtl "\"Nah, it was my bad. Sorry.\""


translate english c5221_4ae789cd:


    "Si realmente confiara en Aoi, entonces no habría sentido la necesidad de gritar en primer lugar..."


translate english c5221_2c467375:


    "...y esta revelación realmente escuece."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
