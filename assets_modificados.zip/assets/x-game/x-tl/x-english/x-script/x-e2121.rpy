

translate english e2121_ab757707:


    xy "\"Morning!\""


translate english e2121_10d8266e:



    voice "voice/e21/2100010b01.opus"
    xtl "\"Oh, it's a normie.\""


translate english e2121_1e178fc7:


    xy "\"...Please stop.\""


translate english e2121_b34e84b6:



    voice "voice/e21/2100020b01.opus"
    xtl "\"Oh, it's a normie.\""


translate english e2121_e943cf42:


    xy "\"Seriously, cut it out!\""


translate english e2121_94c3a0b9:



    voice "voice/e21/2100030b01.opus"
    xtl "\"Oh, it's a normie.\""


translate english e2121_91b390a9:


    xy "\"Dude! Knock it off!\""


translate english e2121_988afa67:



    voice "voice/e21/2100040b01.opus"
    xtl "\"Oh, it's a normie.\""


translate english e2121_4cf7a12d:


    xy "\"Wanna see some pics of Miyuki waking up in the morning?\""


translate english e2121_07f82b4f:



    voice "voice/e21/2100050b01.opus"
    xtl "\"I'm sorry!!! Private Shinichi! I'm hecka sorry, dude!\""


translate english e2121_21428a4c:


    xy "\"Good.\""


translate english e2121_188c045d:


    "Eso fue aterrador... pensé que estaba fallando por un segundo ahí..."


translate english e2121_c28ad8d4:



    voice "voice/e21/2100060b01.opus"
    xtl "\"So, where are those pics of Sone-san?\""


translate english e2121_01acdb1e:


    xy "\"Don't got any.\""


translate english e2121_7e680dd0:



    voice "voice/e21/2100070b01.opus"
    xtl "\"You don't?\""


translate english e2121_d279ffda:


    xy "\"She'd kill me if I tried!\""


translate english e2121_c8172493:



    voice "voice/e21/2100080b01.opus"
    xtl "\"Deceived! By a normie!!!\""


translate english e2121_dcdce098:


    xy "\"Seriously, quit calling me that!\""


translate english e2121_88d5cdb8:


    "En realidad sí tengo algo, aunque."


translate english e2121_9d539407:


    "Pero Miyuki me atrapó en el acto, y en cuanto a mi castigo—"


translate english e2121_d41264e9:


    "—me tomó fotos durmiendo."


translate english e2121_a56c5cd6:


    "—me tomó fotos en cosplay (contra mi voluntad)."


translate english e2121_5d9f8fd1:


    "—she took pics of me \"wetting the bed\"(es decir, me echó agua en las sábanas)."



translate english e2121_ebe992c1:


    "Luego me dijo que si alguna vez compartía las fotos que tomé, ella haría lo mismo con las suyas..."


translate english e2121_37deee70:


    "...y no estoy seguro de querer cruzar ese puente. Nunca."


translate english e2121_744d3734:



    voice "voice/e21/2100090b01.opus"
    xtl "\"You're acting real strange today, my guy!\""


translate english e2121_316c6cea:



    voice "voice/e21/2100100b01.opus"
    xtl "\"I don't know what's going on with you and Sone-san, but you're waaay too buddy-buddy!\""


translate english e2121_147b532e:


    xy "\"Well, uh... What about you, huh?\""


translate english e2121_8048072b:



    voice "voice/e21/2100110b01.opus"
    xtl "\"What do you mean, what about me?\""


translate english e2121_a77fd455:


    xy "\"Well...\""


translate english strings:


    old "Спросить о Хару"
    new "Preguntar por Haru"


    old "Спросить об Аой"
    new "Preguntar por Aoi"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
