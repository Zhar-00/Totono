

translate english e2191a_e9e12b64:



    voice "voice/e21/91a00010a01.opus"
    mx "\"...¿Qué hay con la caja?\""


translate english e2191a_c60fc95d:


    xy "\"Ni idea...\""


translate english e2191a_b2569056:


    xy "\"Me pregunto qué hay adentro...\""


translate english e2191a_04a30897:



    voice "voice/e21/91a00020a01.opus"
    mx "\"Dejémosla. La curiosidad mató al gato, sabes.\""


translate english e2191a_58dc74e0:


    xy "\"Dame un respiro. Dudo mucho que haya algo tan peligroso ahí.\""


translate english e2191a_93bdb4fc:



    voice "voice/e21/91a00030a01.opus"
    mx "\"¡En serio, vámonos!\""


translate english strings:


    old "Уйти"
    new "Irse"


    old "Открыть коробку"
    new "Abrir la caja"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
