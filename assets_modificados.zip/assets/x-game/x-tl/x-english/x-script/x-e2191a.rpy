

translate english e2191a_e9e12b64:



    voice "voice/e21/91a00010a01.opus"
    mx "\"...What's with the box?\""


translate english e2191a_c60fc95d:


    xy "\"No idea...\""


translate english e2191a_b2569056:


    xy "\"I wonder what's inside...\""


translate english e2191a_04a30897:



    voice "voice/e21/91a00020a01.opus"
    mx "\"Let's just leave it. Curiosity killed the cat, you know.\""


translate english e2191a_58dc74e0:


    xy "\"Gimme a break. I really doubt there's anything that dangerous in here.\""


translate english e2191a_93bdb4fc:



    voice "voice/e21/91a00030a01.opus"
    mx "\"Seriously, let's just go!\""


translate english strings:


    old "Уйти"
    new "Irse"


    old "Открыть коробку"
    new "Abrir la caja"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
