

translate english c3164_eb2ddd23:


    xy "\"I feel like there's gotta be some clue...\""


translate english c3164_ec39b8ab:


    "Es solo un presentimiento que tengo en las entrañas..."


translate english c3164_6d7afa45:


    "Tiene que haber algo... ¿verdad...?"


translate english c3164_08f1798c:


    "Nrrggh... ¡No sirve de nada...!"


translate english c3164_76a1913a:


    "¡Y lo siento justo en la punta de la lengua!"


translate english c3164_1d339d20:


    "¡Vale, piensa! ¿Dónde podría buscar pistas?"


translate english strings:


    old "Мобильная игра"
    new "El juego móvil"


    old "Школьные пешеходные ворота"
    new "La puerta peatonal de la escuela"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
