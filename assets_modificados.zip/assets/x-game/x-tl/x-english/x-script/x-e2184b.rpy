

translate english e2184b_8efca299:



    voice "voice/e21/84b00010a01.opus"
    mx "\"Me aseguraré de que nunca puedas traicionarme.\""


translate english e2184b_1878a373:


    xy "\"¿Traicionarte...?\""


translate english e2184b_51daddbd:



    voice "voice/e21/84b00020a01.opus"
    mx "\"Solo dame un poco más de tiempo...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
