

translate english e2184b_8efca299:



    voice "voice/e21/84b00010a01.opus"
    mx "\"I'll make sure you can never betray me.\""


translate english e2184b_1878a373:


    xy "\"Betray you...?\""


translate english e2184b_51daddbd:



    voice "voice/e21/84b00020a01.opus"
    mx "\"Just give me a little more time...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
