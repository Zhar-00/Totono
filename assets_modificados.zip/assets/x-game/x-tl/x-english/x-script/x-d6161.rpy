

translate english d6161_86be19b7:



    voice "voice/d61/6100010a01.opus"
    mx "\"......\""


translate english d6161_12e64a21:


    xy "\"......\""


translate english d6161_21b989b3:


    "Caminamos en silencio por el camino mientras la noche cae sobre nosotros."


translate english d6161_292fea41:


    "Miyuki abandonó la función solo para arrastrarme hasta aquí."


translate english d6161_d9115729:


    "Está tan mortalmente seria que ni siquiera siento que sea correcto hacer una broma casual."


translate english d6161_2269ba4d:


    "¿A dónde diablos me está llevando, exactamente?"


translate english d6161_e7769827:


    "Nos desviamos un poco de mi ruta habitual—"


translate english d6161_a3b7318d:



    voice "voice/d61/6100020a01.opus"
    mx "\"Llegamos.\""


translate english d6161_508ef86b:


    xy "\"¿La tienda de la esquina de la familia de Yuutarou...?\""


translate english d6161_91a20bfd:



    voice "voice/d61/6100030a01.opus"
    mx "\"No es el único que trabaja aquí, ¿sabes?\""


translate english d6161_d066009d:


    xy "\"...Oh, cierto. Está Haru-chan, o como se llame.\""


translate english d6161_93229d85:


    xy "\"Ella está en tu club, ¿verdad?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
