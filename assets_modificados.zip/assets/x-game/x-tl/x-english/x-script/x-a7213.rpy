

translate english a7213_b4d2564f:


    "Los ojos vidriosos de Miyuki se fijan en los míos."


translate english a7213_e9ae0f9c:


    "Cuando nuestros labios se encuentran, nuestros cuerpos se relajan."


translate english a7213_8a5fb250:



    voice "voice/a72/1300010a01.opus"
    mx "\"Mm... mmph... mmmph... Mm... mm... mmmm!!!\""


translate english a7213_09de018b:


    "En medio del beso, me abro paso hacia adentro."


translate english a7213_e1967373:



    voice "voice/a72/1300020a01.opus"
    mx "\"Nnhaah! Nnhaaahhh! Mm... mmph... mmmph... Mmmhnnnnnnn...!!!\""


translate english a7213_53aa82de:


    "Pulgada a pulgada, mi verga se hunde profundo en ella."


translate english a7213_57a67075:


    "La sangre se mezcla con sus fluidos, tiñéndolos de un rojo tenue."


translate english a7213_13461533:


    "Nunca he sentido algo así—"


translate english a7213_dd82592f:


    "¡Se siente tan bien que podría desmayarme...!"


translate english a7213_6c290f1e:



    voice "voice/a72/1300030a01.opus"
    mx "\"Nn... nnnn... nnn... nnnnn...! Oh god... Aah... It's so deep... Nn... nnnn...!!!\""


translate english a7213_8f8b47e4:



    voice "voice/a72/1300040a01.opus"
    mx "\"Shinichi... Slow down... Aaahh...! It's too much...!\""


translate english a7213_240d3168:


    xy "\"O-Okay!\""


translate english a7213_7edb7f2a:


    "Invocando mi autocontrol que se desvanece rápidamente, me obligo a detenerme a mitad de camino."


translate english a7213_27d07bc9:


    "Mirando a los ojos de Miyuki, sonrío."


translate english a7213_b5d65fc2:


    xy "\"Does it hurt?\""


translate english a7213_5cda59e6:



    voice "voice/a72/1300050a01.opus"
    mx "\"Y-Yeah... Just a little... But... more than that... it just feels kind of weird...\""


translate english a7213_06797876:



    voice "voice/a72/1300060a01.opus"
    mx "\"The thought of... mmm... your cock inside me... makes me so happy...\""


translate english a7213_cfa9713d:



    voice "voice/a72/1300070a01.opus"
    mx "\"So I figure... it's not so bad. I can hang in there...\""


translate english a7213_243ae6ce:


    "El dolor la tiene al borde de las lágrimas, pero aun así fuerza las palabras."


translate english a7213_0e1586b5:


    xy "\"Okay. We're halfway there—can you take the rest?\""


translate english a7213_59830ba4:



    voice "voice/a72/1300080a01.opus"
    mx "\"What?\""


translate english a7213_b13c9c57:


    "Fiel a mi palabra, mi longitud completa aún no ha entrado en ella."


translate english a7213_d426d953:



    voice "voice/a72/1300090a01.opus"
    mx "\"You're... gonna push in even deeper? For real? But you're so deep already—\""


translate english a7213_54ee7e54:



    voice "voice/a72/1300100a01.opus"
    mx "\"Huh...? Oh my god... I'm so full...\""


translate english a7213_d6e3d1ca:



    voice "voice/a72/1300110a01.opus"
    mx "\"At this rate, you're going to fill me completely...!\""


translate english a7213_84ba4238:


    xy "\"Sorry, Miyuki—!\""


translate english a7213_c3183f87:


    "Sus susurros extasiados derriban lo último de mi autocontrol."


translate english a7213_74f7a64c:


    "Mi verga se hunde aún más profundo dentro de ella."


translate english a7213_54e91cba:



    voice "voice/a72/1300120a01.opus"
    mx "\"Nnnggggghhhh!!! Nnnn... nnn... nnnnnnn!!!\""


translate english a7213_4ebc6220:


    "Pensando en todos los años que hemos pasado juntos—"


translate english a7213_a98e8bd1:



    voice "voice/a72/1300130a01.opus"
    mx "\"Haah... haah... haah... nnggg!!! Hnnn... aaahhh... aah... AAAHHH!!!\""


translate english a7213_05959072:


    "—empujo mi longitud hasta el fondo."


translate english a7213_26e800de:



    voice "voice/a72/1300140a01.opus"
    mx "\"Nnn... This feels... so weird... Hnnn! I can't... believe this is happening...\""


translate english a7213_224b279c:



    voice "voice/a72/1300150a01.opus"
    mx "\"It's really intense... It hurts... and it's hard to breathe...\""


translate english a7213_beb64d9d:



    voice "voice/a72/1300160a01.opus"
    mx "\"But... knowing you're inside me... It's like I can feel every inch... Nnng!\""


translate english a7213_39a2e736:



    voice "voice/a72/1300170a01.opus"
    mx "\"I'm... so... in love... with you...\""


translate english a7213_b47dc77f:



    voice "voice/a72/1300180a01.opus"
    mx "\"Does it feel good for you, too?\""


translate english a7213_d8abaada:


    xy "\"You feel amazing, Miyuki... but I...\""


translate english a7213_deb6dc8e:



    voice "voice/a72/1300190a01.opus"
    mx "\"...It's okay. Go ahead.\""


translate english a7213_77139934:


    "Con el consentimiento de Miyuki, empiezo a embestir lentamente."


translate english a7213_02dda841:



    voice "voice/a72/1300200a01.opus"
    mx "\"Nnhaah!\""


translate english a7213_a50955f8:



    voice "voice/a72/1300210a01.opus"
    mx "\"Mmph...! Aah... aaahh...! Nn... nngghh... nn... nnngg!\""


translate english a7213_85b6700b:



    voice "voice/a72/1300220a01.opus"
    mx "\"Aah... aah... nnn... nnnn... nngghh... nnn... nn... nnnnggg!\""


translate english a7213_e943c95e:



    voice "voice/a72/1300230a01.opus"
    mx "\"Nnhaah... Wait! Stop! Aaahh! Hold on! Slow down! Nnngg!!!\""


translate english a7213_864b5823:


    "Mi cuerpo me dice que la embista fuerte y me corra lo más rápido posible..."


translate english a7213_9f8dd9ff:


    "...pero refreno mis impulsos carnales y ralentizo mis embestidas."


translate english a7213_1ed819d3:



    voice "voice/a72/1300240a01.opus"
    mx "\"Nnhaaahh! Nnn... nnng... nnnggghhhh!! Haah... haah... haah... nnnngggg!!!\""


translate english a7213_99a4b9b1:



    voice "voice/a72/1300250a01.opus"
    mx "\"Nnhaah! Aah! Aah! Aah! Oh god! I can feel you... sliding in and out... Nnngg!!!\""


translate english a7213_a4d9bfc4:



    voice "voice/a72/1300260a01.opus"
    mx "\"Nnn... I can't... believe... nnnngg... this is... happening... Aah! Nnn!\""


translate english a7213_d73d4dd1:



    voice "voice/a72/1300270a01.opus"
    mx "\"But... Nnng! Shinichi? It feels good for you, right?\""


translate english a7213_69397ce5:



    voice "voice/a72/1300280a01.opus"
    mx "\"Does it... feel good inside me?\""


translate english a7213_300a4944:


    "La voz de Miyuki tiene un dejo de dolor."


translate english a7213_3676b7f0:


    "Pero percibo un leve cambio."


translate english a7213_a315fa4e:


    "Sí, un pequeño cambio..."


translate english a7213_32a03346:


    "Tan minúsculo que nadie más que yo lo notaría..."


translate english a7213_07db5fc9:



    voice "voice/a72/1300290a01.opus"
    mx "\"Nnhhh... nn... nnnng... aaaahh...! H-Hold on, Shinichi...\""


translate english a7213_15510067:



    voice "voice/a72/1300300a01.opus"
    mx "\"You've been holding back for a while now... I can tell...\""


translate english a7213_946b5f3c:



    voice "voice/a72/1300310a01.opus"
    mx "\"Don't you want to get off? You don't have to slow down for my sake...\""


translate english a7213_9d4f967e:



    voice "voice/a72/1300320a01.opus"
    mx "\"Just... Nn... gghh... Fuck me how you want to...!\""


translate english a7213_557a7d2f:


    xy "\"Liar...\""


translate english a7213_9b926bc0:



    voice "voice/a72/1300330a01.opus"
    mx "\"Huh...? Oh my god... I'm so full...\""


translate english a7213_a14db0af:


    xy "\"You don't have to fake it... Just tell me what you really want.\""


translate english a7213_e9013947:



    voice "voice/a72/1300340a01.opus"
    mx "\"I... I'm not faking anyth—\""


translate english a7213_4907db74:


    xy "\"Just... be honest with me...!\""


translate english a7213_c1fd86ee:


    xy "\"I love the real you, no matter what!\""


translate english a7213_8221d14e:



    voice "voice/a72/1300350a01.opus"
    mx "\"Shinichi—\""



translate english a7213_56f46f0e:


    "El último resto de su caparazón protector empieza a desmoronarse."


translate english a7213_d4b4018b:



    voice "voice/a72/1300360a01.opus"
    mx "\"Listen... um... This is my first time... And it definitely kinda hurts...\""


translate english a7213_4295802f:



    voice "voice/a72/1300370a01.opus"
    mx "\"But I love your cock... I really do... It's all I can think about right now, and...\""


translate english a7213_fc39070e:



    voice "voice/a72/1300380a01.opus"
    mx "\"It feels... amazing...\""


translate english a7213_9b633639:



    voice "voice/a72/1300390a01.opus"
    mx "\"I love the feeling of your cock inside me... I'm just... I'm on cloud nine...!\""


translate english a7213_64eac95e:



    voice "voice/a72/1300400a01.opus"
    mx "\"Give it to me... Love me with all you've got...\""


translate english a7213_9c619492:



    voice "voice/a72/1300410a01.opus"
    mx "\"Just rock my world, okay?\""


translate english a7213_72060f9e:


    xy "\"—Coming right up!\""


translate english a7213_d7ee5383:



    voice "voice/a72/1300430a01.opus"
    mx "\"Nnhaah! Aah! Aah! Oh fuck! Oh god! It... It's so deep...!\""


translate english a7213_80753a2f:



    voice "voice/a72/1300440a01.opus"
    mx "\"I can feel—your fat cock—Hnnn!!! It's... It's filling me up!!!\""


translate english a7213_b3e1ec9f:


    "Mientras embisto cada vez más rápido, la concha de Miyuki se contrae y se estremece como si hubiera cobrado vida."


translate english a7213_3d582c76:


    "Después de todo ese tiempo conteniéndome, llego rápido al clímax."


translate english a7213_a86badbd:


    "La habitación se llena con el sonido de la carne chocando—"


translate english a7213_df5da341:



    voice "voice/a72/1300450a01.opus"
    mx "\"AAAH! Oh god! I can't! It's... It's so intense... Nnn... I'm gonna break...!\""


translate english a7213_5d89b814:



    voice "voice/a72/1300460a01.opus"
    mx "\"Haah! Aah! Aaahh! Aaah! Huh? What the? I can feel it—swelling up—\""


translate english a7213_2b645c59:


    xy "\"Sorry—I'm gonna cum—!\""


translate english a7213_48e7b5b4:



    voice "voice/a72/1300470a01.opus"
    mx "\"Huh? What?! For real?! W-Wait! Slow down—If you cum inside me—!\""


translate english a7213_66d00296:



    voice "voice/a72/1300480a01.opus"
    mx "\"Wh...? Wait! Nnn... nnnngg! Aah! Oh god—I feel it—I feel your seed inside me!\""


translate english a7213_8a2cc3c6:



    voice "voice/a72/1300490a01.opus"
    mx "\"Oh fuck... It's filling me up! I'm so full of your cum—AAAH! Nnn... nnngg!!!\""


translate english a7213_c4a11ec4:


    "Mientras me corro, la concha de Miyuki se estremece en respuesta."


translate english a7213_9c3ca587:



    voice "voice/a72/1300500a01.opus"
    mx "\"Aaahh! It's... It's so warm... I feel it... flooding me... Nnnn...!\""


translate english a7213_2bd02963:



    voice "voice/a72/1300510a01.opus"
    mx "\"Oh god... It's seeping into every corner... I can feel you inside me...\""


translate english a7213_1eaee62a:


    xy "\"Miyuki... I... er...\""


translate english a7213_b6d9a396:



    voice "voice/a72/1300520a01.opus"
    mx "\"Shinichi... You just couldn't hold back, hmm?\""


translate english a7213_3454ce1d:


    xy "\"...Sorry...\""


translate english a7213_b67e8206:



    voice "voice/a72/1300530a01.opus"
    mx "\"Oh yeah? And how will you make it up to me?\""


translate english a7213_9a225408:


    xy "\"W-Well, if you get pregnant, I'll man up and—\""


translate english a7213_b7b8f76a:



    voice "voice/a72/1300540a01.opus"
    mx "\"That's not what I mean!\""


translate english a7213_14ea5d4a:


    xy "\"Huh...? Oh my god... I'm so full...\""


translate english a7213_ab7c4423:


    "Sin pensar, me muevo para salir, pero Miyuki envuelve mis caderas con sus largas piernas."


translate english a7213_e340a27e:



    voice "voice/a72/1300550a01.opus"
    mx "\"...Not yet.\""


translate english a7213_29cc6b1f:


    xy "\"What do you mean?\""


translate english a7213_923bceef:



    voice "voice/a72/1300560a01.opus"
    mx "\"What do you think I mean?! God!\""


translate english a7213_7f491d06:



    voice "voice/a72/1300570a01.opus"
    mx "\"I... I haven't cum yet, so...!\""


translate english a7213_a1b889ec:


    "La cara de Miyuki está roja brillante."


translate english a7213_7464f0cd:



    voice "voice/a72/1300580a01.opus"
    mx "\"So make me cum!\""


translate english a7213_0df8c437:


    xy "\"—!!!\""


translate english a7213_bc3c44d6:


    "Mi miembro marchito de repente vuelve a palpitar con vida."


translate english a7213_7a76d482:



    voice "voice/a72/1300590a01.opus"
    mx "\"Well, well... You only just came, and yet...\""


translate english a7213_02e4fa9f:



    voice "voice/a72/1300600a01.opus"
    mx "\"...Someone's getting hard again, aren't we?\""


translate english a7213_7e536838:


    "Se aprieta alrededor de mi verga como si intentara mantenerla llena de sangre."


translate english a7213_59060969:


    "Naturalmente, todavía estoy sensible por el orgasmo, y mi cuerpo se sacude por reflejo."


translate english a7213_4769361b:


    xy "\"Th... That kinda hurts...\""


translate english a7213_308978da:



    voice "voice/a72/1300610a01.opus"
    mx "\"Deal with it.\""


translate english a7213_84b835be:



    voice "voice/a72/1300620a01.opus"
    mx "\"It hurt when you had your way with me just now, but you didn't hear ME complain!\""


translate english a7213_a5a94c3b:


    xy "\"Yeah, because you enjoyed it!\""


translate english a7213_b37529e9:



    voice "voice/a72/1300630a01.opus"
    mx "\"And? So did you!\""


translate english a7213_f33877b6:


    "Mueve las caderas con destreza."


translate english a7213_90e6498d:


    xy "\"Whoa! Hey!\""


translate english a7213_28196970:



    voice "voice/a72/1300640a01.opus"
    mx "\"Oh wow... You can hear the cum squishing around in there...\""


translate english a7213_f0c0171e:



    voice "voice/a72/1300650a01.opus"
    mx "\"That's so dirty... Nnn... Shinichi... You're a dirty boy...\""


translate english a7213_3e62ce8e:



    voice "voice/a72/1300660a01.opus"
    mx "\"Nhhh... You can even smell it... Our fluids mixed together with the blood...\""


translate english a7213_2ea512de:



    voice "voice/a72/1300670a01.opus"
    mx "\"Can you feel yourself getting hard inside me? I can feel it twitching...\""


translate english a7213_15a818d1:



    voice "voice/a72/1300680a01.opus"
    mx "\"But you better not cum as fast as you did last time—\""


translate english a7213_1c23fad4:


    xy "\"There won't be any brakes on this train, you got that?\""


translate english a7213_d42407fe:



    voice "voice/a72/1300690a01.opus"
    mx "\"Deal.\""


translate english a7213_8a286687:



    voice "voice/a72/1300700a01.opus"
    mx "\"Just fuck me like I'm your toy.\""


translate english a7213_b31e05c5:


    "En respuesta, empiezo a embestir aún más rápido."


translate english a7213_76164216:



    voice "voice/a72/1300710a01.opus"
    mx "\"Hnnn! Nnn.... nnngggg!!!\""


translate english a7213_dd12e908:



    voice "voice/a72/1300720a01.opus"
    mx "\"AAAHH! AAH! Your cock's rock-hard again— It's practically—splitting me in half—!\""


translate english a7213_507b01bb:



    voice "voice/a72/1300730a01.opus"
    mx "\"Oh god—Your cock's so fat—It's herding all the semen into my womb!\""


translate english a7213_b09d096b:



    voice "voice/a72/1300740a01.opus"
    mx "\"Aaahh! Aah! Aah! Oh fuck—It's so—intense—AAAHH!\""


translate english a7213_6048fd88:



    voice "voice/a72/1300750a01.opus"
    mx "\"Ahah! You're railing me—even harder than—last time!\""


translate english a7213_122a22c9:



    voice "voice/a72/1300760a01.opus"
    mx "\"It's—It's so intense—It feels like—like you're reshaping my pussy with your cock!\""


translate english a7213_b2a1734c:


    "Sus paredes se someten a mí como si la capa fresca de semen hubiera aliviado la tensión."


translate english a7213_76957b49:


    "Se siente tan intenso que mis sentidos previamente embotados me gritan mientras me empujan al límite de nuevo."


translate english a7213_aca20a49:


    "Pero no puedo retroceder. No ahora."


translate english a7213_4679fb31:


    "Obligándome a calmarme, retiro mis caderas—"


translate english a7213_8fc76ac1:



    voice "voice/a72/1300770a01.opus"
    mx "\"Huh...? Are you pulling out?\""


translate english a7213_a7265cbd:


    xy "\"Of course not.\""


translate english a7213_ede0c0b1:


    "Sus piernas se aprietan alrededor de mí por reflejo, negándose a soltarme."


translate english a7213_60679ff1:


    "Me relajo y bajo las caderas. Luego meto y saco lentamente la punta de su entrada."


translate english a7213_4421b2d9:



    voice "voice/a72/1300780a01.opus"
    mx "\"Huh? Oh whoa... That feels so weird...\""


translate english a7213_09b79095:



    voice "voice/a72/1300790a01.opus"
    mx "\"Aaahh... This feels so completely different... It's hard to explain... It's really frustrating, kind of...?\""


translate english a7213_a6e961d4:



    voice "voice/a72/1300800a01.opus"
    mx "\"Aah! Aah! Aah! What the...? The gentle thrusts are... making me go limp...\""


translate english a7213_59d32b63:



    voice "voice/a72/1300810a01.opus"
    mx "\"Haahh! Aah! Aaahh! Aah! This is way more—way more—AAAHH!!!\""


translate english a7213_f73d2af6:


    "El cuerpo de Miyuki se sacude al ritmo de mi compás."


translate english a7213_8952c5ad:



    voice "voice/a72/1300820a01.opus"
    mx "\"Shinichi—Aah! Nnn! Please—!\""


translate english a7213_c9a96be2:



    voice "voice/a72/1300830a01.opus"
    mx "\"Hold my hand—Grab on—and don't let go—!\""


translate english a7213_748be2dc:


    "Me llama con una voz débil."


translate english a7213_e1cec978:


    "Entrelazo mis dedos con los suyos con fuerza."


translate english a7213_23a1c1f5:



    voice "voice/a72/1300840a01.opus"
    mx "\"Haaahh! Aah! Aah, aah, aah! Oh god—I—Nnng! Nnnn!!!\""


translate english a7213_a87ff971:



    voice "voice/a72/1300850a01.opus"
    mx "\"Somehow—holding hands—makes it feel—completely different—!!!\""


translate english a7213_54baba62:



    voice "voice/a72/1300860a01.opus"
    mx "\"I feel so—at peace—Nnnng!!!\""


translate english a7213_508e5db1:



    voice "voice/a72/1300870a01.opus"
    mx "\"I'm so—glad I—fell for you!\""


translate english a7213_d1a608b2:



    voice "voice/a72/1300880a01.opus"
    mx "\"Aah! Oh god! Something's—Something's happening—Something's building up inside me—\""


translate english a7213_0a883506:



    voice "voice/a72/1300890a01.opus"
    mx "\"Aaah! Aah! Aah! Aah! Aah! AAAAAHHH—\""


translate english a7213_2964e006:



    voice "voice/a72/1300900a01.opus"
    mx "\"NnhaaAAAAAAHHHHH!\""


translate english a7213_75074718:



    voice "voice/a72/1300910a01.opus"
    mx "\"Aah... nnhaah... nnn...! Nnggh... Hnn... nnn... nnnn... nnhaah!\""


translate english a7213_81771db4:



    voice "voice/a72/1300920a01.opus"
    mx "\"Haah... haah... haah... Aagh... nnn! Sh-Shinichi... AAAHHH?!\""


translate english a7213_8b3ecff0:


    "A pesar de su clímax, sigo embistiendo aún más fuerte que antes."


translate english a7213_09b1777f:



    voice "voice/a72/1300930a01.opus"
    mx "\"Hnnnn...! Aah... Shin...ichi...!!! I can't... I... already... came...!\""


translate english a7213_11d8e713:



    voice "voice/a72/1300940a01.opus"
    mx "\"The sound... and smell... is making me... lightheaded... I'm so... happy... and horny...!\""


translate english a7213_96cf3493:



    voice "voice/a72/1300950a01.opus"
    mx "\"Aaahh... aaahh... aah... aah...! It feels so good... I'm gonna... lose it...!\""


translate english a7213_ee7206b6:


    xy "\"Go ahead and let loose. I've got you.\""


translate english a7213_2dbbbb5f:



    voice "voice/a72/1300960a01.opus"
    mx "\"Okay... Thanks...!\""


translate english a7213_24b914b0:


    "Me sonríe, prácticamente embelesada. Dios, es tan linda que no puedo soportarlo."


translate english a7213_e92ef75f:


    "Esta es la recta final: la embisto con todas mis fuerzas."




translate english a7213_e96c9406:



    voice "voice/a72/1300420a01.opus"
    mx "\"......!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
