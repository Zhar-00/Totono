

translate english a7213_b4d2564f:


    "Los ojos vidriosos de Miyuki se fijan en los míos."


translate english a7213_e9ae0f9c:


    "Cuando nuestros labios se encuentran, nuestros cuerpos se relajan."


translate english a7213_8a5fb250:



    voice "voice/a72/1300010a01.opus"
    mx "\"Mm... mmph... mmmph... Mm... mm... mmmm!!!\""


translate english a7213_09de018b:


    "En medio del beso, me abro paso hacia adentro."


translate english a7213_e1967373:



    voice "voice/a72/1300020a01.opus"
    mx "\"¡Nnjaah! ¡Nnjaaahhh! Mm... mmph... mmmph... ¡Mmmhnnnnnnn...!!!\""


translate english a7213_53aa82de:


    "Pulgada a pulgada, mi verga se hunde profundo en ella."


translate english a7213_57a67075:


    "La sangre se mezcla con sus fluidos, tiñéndolos de un rojo tenue."


translate english a7213_13461533:


    "Nunca he sentido algo así—"


translate english a7213_dd82592f:


    "¡Se siente tan bien que podría desmayarme...!"


translate english a7213_6c290f1e:



    voice "voice/a72/1300030a01.opus"
    mx "\"¡Nn... nnnn... nnn... nnnnn...! Dios... Aah... Está tan profundo... ¡Nn... nnnn...!!!\""


translate english a7213_8f8b47e4:



    voice "voice/a72/1300040a01.opus"
    mx "\"Shinichi... Más despacio... ¡Aaahh...! ¡Es demasiado...!\""


translate english a7213_240d3168:


    xy "\"¡O-Okay!\""


translate english a7213_7edb7f2a:


    "Invocando mi autocontrol que se desvanece rápidamente, me obligo a detenerme a mitad de camino."


translate english a7213_27d07bc9:


    "Mirando a los ojos de Miyuki, sonrío."


translate english a7213_b5d65fc2:


    xy "\"¿Duele?\""


translate english a7213_5cda59e6:



    voice "voice/a72/1300050a01.opus"
    mx "\"S-Sí... Solo un poco... Pero... más que eso... simplemente se siente algo raro...\""


translate english a7213_06797876:



    voice "voice/a72/1300060a01.opus"
    mx "\"El pensar que... mmm... tu verga está dentro de mí... me hace tan feliz...\""


translate english a7213_cfa9713d:



    voice "voice/a72/1300070a01.opus"
    mx "\"Así que supongo que... no está tan mal. Puedo aguantar...\""


translate english a7213_243ae6ce:


    "El dolor la tiene al borde de las lágrimas, pero aun así fuerza las palabras."


translate english a7213_0e1586b5:


    xy "\"Okay. Vamos a la mitad—¿puedes con el resto?\""


translate english a7213_59830ba4:



    voice "voice/a72/1300080a01.opus"
    mx "\"¿Qué?\""


translate english a7213_b13c9c57:


    "Fiel a mi palabra, mi longitud completa aún no ha entrado en ella."


translate english a7213_d426d953:



    voice "voice/a72/1300090a01.opus"
    mx "\"¿Vas... a empujar aún más profundo? ¿De verdad? Pero ya estás muy profundo—\""


translate english a7213_54ee7e54:



    voice "voice/a72/1300100a01.opus"
    mx "\"¿Eh...? Dios mío... Estoy tan llena...\""


translate english a7213_d6e3d1ca:



    voice "voice/a72/1300110a01.opus"
    mx "\"¡A este paso, me vas a llenar por completo...!\""


translate english a7213_84ba4238:


    xy "\"¡Perdón, Miyuki—!\""


translate english a7213_c3183f87:


    "Sus susurros extasiados derriban lo último de mi autocontrol."


translate english a7213_74f7a64c:


    "Mi verga se hunde aún más profundo dentro de ella."


translate english a7213_54e91cba:



    voice "voice/a72/1300120a01.opus"
    mx "\"¡Nnnggggghhhh! ¡Nnnn... nnn... nnnnnnn!\""


translate english a7213_4ebc6220:


    "Pensando en todos los años que hemos pasado juntos—"


translate english a7213_a98e8bd1:



    voice "voice/a72/1300130a01.opus"
    mx "\"¡Jaah... jaah... jaah... nnggg! ¡Hnnn... aaahhh... aah... AAAHHH!\""


translate english a7213_05959072:


    "—empujo mi longitud hasta el fondo."


translate english a7213_26e800de:



    voice "voice/a72/1300140a01.opus"
    mx "\"Nnn... Esto se siente... tan raro... ¡Hnnn! No puedo... creer que esto esté pasando...\""


translate english a7213_224b279c:



    voice "voice/a72/1300150a01.opus"
    mx "\"Es realmente intenso... Duele... y es difícil respirar...\""


translate english a7213_beb64d9d:



    voice "voice/a72/1300160a01.opus"
    mx "\"Pero... saber que estás dentro de mí... Es como si pudiera sentir cada centímetro... ¡Nnng!\""


translate english a7213_39a2e736:



    voice "voice/a72/1300170a01.opus"
    mx "\"Estoy... tan... enamorada... de ti...\""


translate english a7213_b47dc77f:



    voice "voice/a72/1300180a01.opus"
    mx "\"¿También se siente bien para ti?\""


translate english a7213_d8abaada:


    xy "\"Te sientes increíble, Miyuki... pero yo...\""


translate english a7213_deb6dc8e:



    voice "voice/a72/1300190a01.opus"
    mx "\"...Está bien. Adelante.\""


translate english a7213_77139934:


    "Con el consentimiento de Miyuki, empiezo a embestir lentamente."


translate english a7213_02dda841:



    voice "voice/a72/1300200a01.opus"
    mx "\"¡Nnjaah!\""


translate english a7213_a50955f8:



    voice "voice/a72/1300210a01.opus"
    mx "\"¡Mmph...! ¡Aah... aaahh...! ¡Nn... nngghh... nn... nnngg!\""


translate english a7213_85b6700b:



    voice "voice/a72/1300220a01.opus"
    mx "\"¡Aah... aah... nnn... nnnn... nngghh... nnn... nn... nnnnggg!\""


translate english a7213_e943c95e:



    voice "voice/a72/1300230a01.opus"
    mx "\"¡Nnjaah...! ¡Espera! ¡Detente! ¡Aaahh! ¡Aguanta! ¡Más despacio! ¡Nnngg!\""


translate english a7213_864b5823:


    "Mi cuerpo me dice que la embista fuerte y me corra lo más rápido posible..."


translate english a7213_9f8dd9ff:


    "...pero refreno mis impulsos carnales y ralentizo mis embestidas."


translate english a7213_1ed819d3:



    voice "voice/a72/1300240a01.opus"
    mx "\"¡Nnjaaahh! ¡Nnn... nnng... nnnggghhhh! ¡Jaah... jaah... jaah... nnnngggg!\""


translate english a7213_99a4b9b1:



    voice "voice/a72/1300250a01.opus"
    mx "\"¡Nnjaah! ¡Aah! ¡Aah! ¡Aah! ¡Dios! Te puedo sentir... entrando y saliendo... ¡Nnngg!\""


translate english a7213_a4d9bfc4:



    voice "voice/a72/1300260a01.opus"
    mx "\"Nnn... No puedo... creer... nnnngg... que esto... esté pasando... ¡Aah! ¡Nnn!\""


translate english a7213_d73d4dd1:



    voice "voice/a72/1300270a01.opus"
    mx "\"Pero... ¡Nnng! ¿Shinichi? Se siente bien para ti, ¿verdad?\""


translate english a7213_69397ce5:



    voice "voice/a72/1300280a01.opus"
    mx "\"¿Se siente... bien dentro de mí?\""


translate english a7213_300a4944:


    "La voz de Miyuki tiene un dejo de dolor."


translate english a7213_3676b7f0:


    "Pero percibo un leve cambio."


translate english a7213_a315fa4e:


    "Sí, un pequeño cambio..."


translate english a7213_32a03346:


    "Tan minúsculo que nadie más que yo lo notaría..."


translate english a7213_07db5fc9:



    voice "voice/a72/1300290a01.opus"
    mx "\"¡Nnjaah... nn... nnnng... aaahh...! E-Espera, Shinichi...\""


translate english a7213_15510067:



    voice "voice/a72/1300300a01.opus"
    mx "\"Llevas un rato aguantándote... Me doy cuenta...\""


translate english a7213_946b5f3c:



    voice "voice/a72/1300310a01.opus"
    mx "\"¿No quieres venirte? No tienes que ir más despacio por mí...\""


translate english a7213_9d4f967e:



    voice "voice/a72/1300320a01.opus"
    mx "\"Solo... Nn... gghh... ¡Fóllame como tú quieras...!\""


translate english a7213_557a7d2f:


    xy "\"Mentiroso...\""


translate english a7213_9b926bc0:



    voice "voice/a72/1300330a01.opus"
    mx "\"¿Eh...? Dios mío... Estoy tan llena...\""


translate english a7213_a14db0af:


    xy "\"No tienes que fingir... Solo dime qué es lo que realmente quieres.\""


translate english a7213_e9013947:



    voice "voice/a72/1300340a01.opus"
    mx "\"¡Yo... no estoy fingiendo na—\""


translate english a7213_4907db74:


    xy "\"¡Solo... sé honesto conmigo...!\""


translate english a7213_c1fd86ee:


    xy "\"¡Amo al verdadero tú, sin importar qué!\""


translate english a7213_8221d14e:



    voice "voice/a72/1300350a01.opus"
    mx "\"Shinichi—\""



translate english a7213_56f46f0e:


    "El último resto de su caparazón protector empieza a desmoronarse."


translate english a7213_d4b4018b:



    voice "voice/a72/1300360a01.opus"
    mx "\"Escucha... em... Esta es mi primera vez... Y definitivamente duele bastante...\""


translate english a7213_4295802f:



    voice "voice/a72/1300370a01.opus"
    mx "\"Pero amo tu verga... De verdad... Es lo único en lo que puedo pensar ahora, y...\""


translate english a7213_fc39070e:



    voice "voice/a72/1300380a01.opus"
    mx "\"Se siente... increíble...\""


translate english a7213_9b633639:



    voice "voice/a72/1300390a01.opus"
    mx "\"Amo la sensación de tu verga dentro de mí... Es solo que... estoy en las nubes...!\""


translate english a7213_64eac95e:



    voice "voice/a72/1300400a01.opus"
    mx "\"Dame... Ámame con todo lo que tienes...\""


translate english a7213_9c619492:



    voice "voice/a72/1300410a01.opus"
    mx "\"Solo hazme perder la cabeza, ¿sí?\""


translate english a7213_72060f9e:


    xy "\"—¡Enseguida!\""


translate english a7213_d7ee5383:



    voice "voice/a72/1300430a01.opus"
    mx "\"¡Nnjaah! ¡Aah! ¡Aah! ¡Joder! ¡Dios! Es... Es tan profundo...!\""


translate english a7213_80753a2f:



    voice "voice/a72/1300440a01.opus"
    mx "\"Puedo sentir—tu gruesa verga—¡Hnnn! ¡Me... Me está llenando!\""


translate english a7213_b3e1ec9f:


    "Mientras embisto cada vez más rápido, la concha de Miyuki se contrae y se estremece como si hubiera cobrado vida."


translate english a7213_3d582c76:


    "Después de todo ese tiempo conteniéndome, llego rápido al clímax."


translate english a7213_a86badbd:


    "La habitación se llena con el sonido de la carne chocando—"


translate english a7213_df5da341:



    voice "voice/a72/1300450a01.opus"
    mx "\"¡AAH! ¡Dios! ¡No puedo! Es... Es tan intenso... Nnn... ¡Voy a romperme...!\""


translate english a7213_5d89b814:



    voice "voice/a72/1300460a01.opus"
    mx "\"¡Jaah! ¡Aah! ¡Aaahh! ¡Aah! ¿Eh? ¿Qué demonios? Lo puedo sentir—hinchándose—\""


translate english a7213_2b645c59:


    xy "\"Perdón—¡me voy a venir—!\""


translate english a7213_48e7b5b4:



    voice "voice/a72/1300470a01.opus"
    mx "\"¿Eh? ¿¡Qué!? ¿¡De verdad!? ¡E-Espera! Más despacio—¡Si te vienes dentro de mí—!\""


translate english a7213_66d00296:



    voice "voice/a72/1300480a01.opus"
    mx "\"¿Qu...? ¡Espera! ¡Nnn... nnnngg! ¡Aah! Dios—lo siento—¡siento tu semilla dentro de mí!\""


translate english a7213_8a2cc3c6:



    voice "voice/a72/1300490a01.opus"
    mx "\"Joder... ¡Me está llenando! ¡Estoy tan llena de tu esperma—AAAH! ¡Nnn... nnngg!\""


translate english a7213_c4a11ec4:


    "Mientras me corro, la concha de Miyuki se estremece en respuesta."


translate english a7213_9c3ca587:



    voice "voice/a72/1300500a01.opus"
    mx "\"¡Aaahh! Es... Es tan caliente... Lo siento... inundándome... ¡Nnnn...!\""


translate english a7213_2bd02963:



    voice "voice/a72/1300510a01.opus"
    mx "\"Dios... Se está filtrando en cada rincón... Te puedo sentir dentro de mí...\""


translate english a7213_1eaee62a:


    xy "\"Miyuki... Yo... er...\""


translate english a7213_b6d9a396:



    voice "voice/a72/1300520a01.opus"
    mx "\"Shinichi... Simplemente no pudiste contenerte, ¿hm?\""


translate english a7213_3454ce1d:


    xy "\"...Perdón...\""


translate english a7213_b67e8206:



    voice "voice/a72/1300530a01.opus"
    mx "\"¿Ah, sí? ¿Y cómo me lo vas a compensar?\""


translate english a7213_9a225408:


    xy "\"B-Bueno, si te embarazas, me haré cargo como un hombre y—\""


translate english a7213_b7b8f76a:



    voice "voice/a72/1300540a01.opus"
    mx "\"¡No me refiero a eso!\""


translate english a7213_14ea5d4a:


    xy "\"¿Eh...? Dios mío... Estoy tan llena...\""


translate english a7213_ab7c4423:


    "Sin pensar, me muevo para salir, pero Miyuki envuelve mis caderas con sus largas piernas."


translate english a7213_e340a27e:



    voice "voice/a72/1300550a01.opus"
    mx "\"...Todavía no.\""


translate english a7213_29cc6b1f:


    xy "\"¿A qué te refieres?\""


translate english a7213_923bceef:



    voice "voice/a72/1300560a01.opus"
    mx "\"¿¡A qué crees que me refiero!? ¡Dios!\""


translate english a7213_7f491d06:



    voice "voice/a72/1300570a01.opus"
    mx "\"Yo... todavía no me he venido, así que...!\""


translate english a7213_a1b889ec:


    "La cara de Miyuki está roja brillante."


translate english a7213_7464f0cd:



    voice "voice/a72/1300580a01.opus"
    mx "\"¡Así que hazme venirme!\""


translate english a7213_0df8c437:


    xy "\"—!!!\""


translate english a7213_bc3c44d6:


    "Mi miembro marchito de repente vuelve a palpitar con vida."


translate english a7213_7a76d482:



    voice "voice/a72/1300590a01.opus"
    mx "\"Vaya, vaya... Apenas acabas de venirte, y sin embargo...\""


translate english a7213_02e4fa9f:



    voice "voice/a72/1300600a01.opus"
    mx "\"...Alguien se está poniendo duro otra vez, ¿no?\""


translate english a7213_7e536838:


    "Se aprieta alrededor de mi verga como si intentara mantenerla llena de sangre."


translate english a7213_59060969:


    "Naturalmente, todavía estoy sensible por el orgasmo, y mi cuerpo se sacude por reflejo."


translate english a7213_4769361b:


    xy "\"Es... Eso duele un poco...\""


translate english a7213_308978da:



    voice "voice/a72/1300610a01.opus"
    mx "\"Aguántate.\""


translate english a7213_84b835be:



    voice "voice/a72/1300620a01.opus"
    mx "\"¡Dolió cuando hiciste lo que querías conmigo hace un momento, pero no me oíste quejarme!\""


translate english a7213_a5a94c3b:


    xy "\"Sí, porque lo disfrutaste.\""


translate english a7213_b37529e9:



    voice "voice/a72/1300630a01.opus"
    mx "\"¿Y? ¡Tú también!\""


translate english a7213_f33877b6:


    "Mueve las caderas con destreza."


translate english a7213_90e6498d:


    xy "\"¡Uah! ¡Oye!\""


translate english a7213_28196970:



    voice "voice/a72/1300640a01.opus"
    mx "\"Oh, guau... Se oye el esperma chapoteando ahí dentro...\""


translate english a7213_f0c0171e:



    voice "voice/a72/1300650a01.opus"
    mx "\"Qué sucio... Nnn... Shinichi... Eres un chico sucio...\""


translate english a7213_3e62ce8e:



    voice "voice/a72/1300660a01.opus"
    mx "\"Nhhh... Hasta se puede oler... Nuestros fluidos mezclados con la sangre...\""


translate english a7213_2ea512de:



    voice "voice/a72/1300670a01.opus"
    mx "\"¿Puedes sentirte ponerte duro dentro de mí? Puedo sentirlo palpitar...\""


translate english a7213_15a818d1:



    voice "voice/a72/1300680a01.opus"
    mx "\"Pero más te vale no venirte tan rápido como la última vez—\""


translate english a7213_1c23fad4:


    xy "\"No habrá frenos en este tren, ¿entendido?\""


translate english a7213_d42407fe:



    voice "voice/a72/1300690a01.opus"
    mx "\"Trato hecho.\""


translate english a7213_8a286687:



    voice "voice/a72/1300700a01.opus"
    mx "\"Solo fóllame como si fuera tu juguete.\""


translate english a7213_b31e05c5:


    "En respuesta, empiezo a embestir aún más rápido."


translate english a7213_76164216:



    voice "voice/a72/1300710a01.opus"
    mx "\"¡Hnnn! ¡Nnn.... nnngggg!\""


translate english a7213_dd12e908:



    voice "voice/a72/1300720a01.opus"
    mx "\"¡AAAH! ¡AAH! Tu verga está dura como piedra otra vez— Prácticamente—¡me está partiendo en dos—!\""


translate english a7213_507b01bb:



    voice "voice/a72/1300730a01.opus"
    mx "\"Dios—Tu verga está tan gruesa—¡Está arreando todo el semen hacia mi vientre!\""


translate english a7213_b09d096b:



    voice "voice/a72/1300740a01.opus"
    mx "\"¡Aaahh! ¡Aah! ¡Aah! Joder—Es tan—intenso—¡AAAH!\""


translate english a7213_6048fd88:



    voice "voice/a72/1300750a01.opus"
    mx "\"¡Ajá! ¡Me estás embistiendo—incluso más fuerte que—la última vez!\""


translate english a7213_122a22c9:



    voice "voice/a72/1300760a01.opus"
    mx "\"Es—Es tan intenso—Se siente como—como si estuvieras reformando mi coño con tu verga!\""


translate english a7213_b2a1734c:


    "Sus paredes se someten a mí como si la capa fresca de semen hubiera aliviado la tensión."


translate english a7213_76957b49:


    "Se siente tan intenso que mis sentidos previamente embotados me gritan mientras me empujan al límite de nuevo."


translate english a7213_aca20a49:


    "Pero no puedo retroceder. No ahora."


translate english a7213_4679fb31:


    "Obligándome a calmarme, retiro mis caderas—"


translate english a7213_8fc76ac1:



    voice "voice/a72/1300770a01.opus"
    mx "\"¿Eh...? ¿Estás saliendo?\""


translate english a7213_a7265cbd:


    xy "\"Claro que no.\""


translate english a7213_ede0c0b1:


    "Sus piernas se aprietan alrededor de mí por reflejo, negándose a soltarme."


translate english a7213_60679ff1:


    "Me relajo y bajo las caderas. Luego meto y saco lentamente la punta de su entrada."


translate english a7213_4421b2d9:



    voice "voice/a72/1300780a01.opus"
    mx "\"¿Eh? Oh, uah... Eso se siente tan raro...\""


translate english a7213_09b79095:



    voice "voice/a72/1300790a01.opus"
    mx "\"Aaahh... Esto se siente completamente distinto... Es difícil de explicar... Es realmente frustrante, en cierto modo...?\""


translate english a7213_a6e961d4:



    voice "voice/a72/1300800a01.opus"
    mx "\"¡Aah! ¡Aah! ¡Aah! ¿Qué demonios...? Las embestidas suaves me están... dejando flácida...\""


translate english a7213_59d32b63:



    voice "voice/a72/1300810a01.opus"
    mx "\"¡Jaaah! ¡Aah! ¡Aaahh! ¡Aah! ¡Esto es mucho más—mucho más—AAAHH!\""


translate english a7213_f73d2af6:


    "El cuerpo de Miyuki se sacude al ritmo de mi compás."


translate english a7213_8952c5ad:



    voice "voice/a72/1300820a01.opus"
    mx "\"Shinichi—¡Aah! ¡Nnn! ¡Por favor—!\""


translate english a7213_c9a96be2:



    voice "voice/a72/1300830a01.opus"
    mx "\"¡Toma mi mano—Agárrate—y no la sueltes—!\""


translate english a7213_748be2dc:


    "Me llama con una voz débil."


translate english a7213_e1cec978:


    "Entrelazo mis dedos con los suyos con fuerza."


translate english a7213_23a1c1f5:



    voice "voice/a72/1300840a01.opus"
    mx "\"¡Jaaaah! ¡Aah! ¡Aah, aah, aah! Dios—¡Yo—Nnng! ¡Nnnn!\""


translate english a7213_a87ff971:



    voice "voice/a72/1300850a01.opus"
    mx "\"De algún modo—tomados de la mano—se siente—¡completamente distinto—!\""


translate english a7213_54baba62:



    voice "voice/a72/1300860a01.opus"
    mx "\"Me siento tan—en paz—¡Nnnng!\""


translate english a7213_508e5db1:



    voice "voice/a72/1300870a01.opus"
    mx "\"¡Me alegro tanto de—haberme enamorado de ti!\""


translate english a7213_d1a608b2:



    voice "voice/a72/1300880a01.opus"
    mx "\"¡Aah! ¡Dios! Algo—Algo está pasando—¡Algo se está acumulando dentro de mí—\""


translate english a7213_0a883506:



    voice "voice/a72/1300890a01.opus"
    mx "\"¡Aaah! ¡Aah! ¡Aah! ¡Aah! ¡Aah! ¡AAAAAHH—\""


translate english a7213_2964e006:



    voice "voice/a72/1300900a01.opus"
    mx "\"¡NnjaaAAAAAAHHHHH!\""


translate english a7213_75074718:



    voice "voice/a72/1300910a01.opus"
    mx "\"¡Aah... nnjaah... nnn...! ¡Nnggh... Hnn... nnn... nnnn... nnjaah!\""


translate english a7213_81771db4:



    voice "voice/a72/1300920a01.opus"
    mx "\"Jaah... jaah... jaah... ¡Aagh... nnn! ¡Sh-Shinichi... AAAHHH!?\""


translate english a7213_8b3ecff0:


    "A pesar de su clímax, sigo embistiendo aún más fuerte que antes."


translate english a7213_09b1777f:



    voice "voice/a72/1300930a01.opus"
    mx "\"¡Hnnnn...! ¡Aah... Shin...ichi...! ¡No puedo... ya... me... vine...!\""


translate english a7213_11d8e713:



    voice "voice/a72/1300940a01.opus"
    mx "\"El sonido... y el olor... me están... mareando... ¡Estoy tan... feliz... y tan caliente...!\""


translate english a7213_96cf3493:



    voice "voice/a72/1300950a01.opus"
    mx "\"¡Aaahh... aaahh... aah... aah...! Se siente tan bien... ¡Voy a... perder la cabeza...!\""


translate english a7213_ee7206b6:


    xy "\"Adelante, suéltate. Te tengo.\""


translate english a7213_2dbbbb5f:



    voice "voice/a72/1300960a01.opus"
    mx "\"Okay... ¡Gracias...!\""


translate english a7213_24b914b0:


    "Me sonríe, prácticamente embelesada. Dios, es tan linda que no puedo soportarlo."


translate english a7213_e92ef75f:


    "Esta es la recta final: la embisto con todas mis fuerzas."




translate english a7213_e96c9406:



    voice "voice/a72/1300420a01.opus"
    mx "\"......!!!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
