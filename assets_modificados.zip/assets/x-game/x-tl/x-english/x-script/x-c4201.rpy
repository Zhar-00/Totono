

translate english c4201_4fa5e30f:


    "La forma de Miyuki es hermosa, como siempre."


translate english c4201_c1c3a6fe:


    "La pelota de béisbol vuela y golpea la red."


translate english c4201_abfdb466:



    voice "voice/c42/0100010a01.opus"
    mx "\"¿Quieres un turno?\""


translate english c4201_a3ae790d:


    xy "\"Paso.\""


translate english c4201_40815b14:



    voice "voice/c42/0100020a01.opus"
    mx "\"¿Nunca te cansas de solo mirar?\""


translate english c4201_69ba8cf8:


    xy "\"En realidad no. Y al parecer tú tampoco te cansas de batear.\""


translate english c4201_eaa0869c:



    voice "voice/c42/0100030a01.opus"
    mx "\"Claro que no. De verdad me encanta.\""


translate english c4201_caebce30:



    voice "voice/c42/0100040a01.opus"
    mx "\"Amo pararme aquí, con el ojo en la bola—\""


translate english c4201_d45f3c4e:



    voice "voice/c42/0100050a01.opus"
    mx "\"¡Y luego bateo!\""


translate english c4201_fe50fa7c:



    voice "voice/c42/0100060a01.opus"
    mx "\"Sin actuación, sin mentiras...\""


translate english c4201_32e86a79:



    voice "voice/c42/0100070a01.opus"
    mx "\"No tengo que pensar... Puedo simplemente ser yo. Mi yo puro.\""


translate english c4201_0bfbcac5:


    "De algún modo, siento que sé a qué se refiere."


translate english c4201_47eb093f:


    "Miyuki batea ese bate como si se hubiera liberado de todos los problemas del mundo."


translate english c4201_e0b1e04e:



    voice "voice/c42/0100080a01.opus"
    mx "\"Ahora que ella se fue...\""


translate english c4201_3f5fb14b:



    voice "voice/c42/0100090a01.opus"
    mx "\"Ahora que está lejos...\""


translate english c4201_14e4cf99:



    voice "voice/c42/0100100a01.opus"
    mx "\"Ahora que la extraño...\""


translate english c4201_027d64b6:



    voice "voice/c42/0100110a01.opus"
    mx "\"Por fin entiendo.\""


translate english c4201_cb2c9a0f:



    voice "voice/c42/0100120a01.opus"
    mx "\"Seré perfectamente honesta.\""


translate english c4201_af6af867:



    voice "voice/c42/0100130a01.opus"
    mx "\"Siempre odié a Aoi.\""


translate english c4201_357eb912:



    voice "voice/c42/0100140a01.opus"
    mx "\"Quería que se fuera.\""


translate english c4201_459c48c4:



    voice "voice/c42/0100150a01.opus"
    mx "\"No quería estar cerca de ella.\""


translate english c4201_88603690:



    voice "voice/c42/0100160a01.opus"
    mx "\"Pero al mismo tiempo, no podía dejarla fuera.\""


translate english c4201_b778f3a2:



    voice "voice/c42/0100170a01.opus"
    mx "\"En algún lugar en el fondo... quería SER ella.\""


translate english c4201_4ddb0227:



    voice "voice/c42/0100180a01.opus"
    mx "\"Era sincera con los demás, y sincera consigo misma, y siempre defendía lo que creía.\""


translate english c4201_4b15dee5:



    voice "voice/c42/0100190a01.opus"
    mx "\"Y eso me gustaba de ella.\""


translate english c4201_5ad5afcc:



    voice "voice/c42/0100200a01.opus"
    mx "\"Así que decidí...\""


translate english c4201_87ca00f6:



    voice "voice/c42/0100210a01.opus"
    mx "\"Que tal vez podría ser así.\""


translate english c4201_2866ed92:



    voice "voice/c42/0100220a01.opus"
    mx "\"Tal vez podría aprender a ser como ella—a dejar de pensar demasiado y empezar a enfrentar mis miedos de frente.\""


translate english c4201_59a12659:



    voice "voice/c42/0100230a01.opus"
    mx "\"Y ahora... Shinichi...\""


translate english c4201_6d7657c0:


    "Se da la vuelta para mirarme. Las jaulas de bateo están en absoluto silencio."


translate english c4201_48a65fe0:


    "Todo se detiene."


translate english c4201_af93df0a:


    "Estoy clavado en el sitio como si me tuviera agarrado del corazón."


translate english c4201_ecf8b3e9:



    voice "voice/c42/0100240a01.opus"
    mx "\"¿Me escucharás?\""


translate english c4201_944fe707:


    "Lo entiendo."


translate english c4201_925a91db:


    "Entiendo por qué Miyuki envidiaría a una chica terca e inflexible como Aoi."


translate english c4201_5ce5c7aa:


    "Y ahora que Aoi la ha cambiado, sé lo que va a decir."


translate english c4201_409a4ddd:


    "Estaba aterrada de lastimar a alguien... y de salir lastimada ella misma."


translate english c4201_be9df8ba:


    "Y así suprimió sus sentimientos durante todos estos años."


translate english c4201_aacdc701:



    voice "voice/c42/0100250a01.opus"
    mx "\"Quiero que sepas...\""


translate english c4201_65270319:



    voice "voice/c42/0100260a01.opus"
    mx "\"Que yo—\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
