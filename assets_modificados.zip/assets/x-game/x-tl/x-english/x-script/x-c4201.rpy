

translate english c4201_4fa5e30f:


    "La forma de Miyuki es hermosa, como siempre."


translate english c4201_c1c3a6fe:


    "La pelota de béisbol vuela y golpea la red."


translate english c4201_abfdb466:



    voice "voice/c42/0100010a01.opus"
    mx "\"Want a turn?\""


translate english c4201_a3ae790d:


    xy "\"I'll pass.\""


translate english c4201_40815b14:



    voice "voice/c42/0100020a01.opus"
    mx "\"Don't you ever get tired of just watching?\""


translate english c4201_69ba8cf8:


    xy "\"Not really. And apparently you don't get tired of swinging, either.\""


translate english c4201_eaa0869c:



    voice "voice/c42/0100030a01.opus"
    mx "\"Of course not. I really love it.\""


translate english c4201_caebce30:



    voice "voice/c42/0100040a01.opus"
    mx "\"I love standing here, my eye on the ball—\""


translate english c4201_d45f3c4e:



    voice "voice/c42/0100050a01.opus"
    mx "\"Then I swing!\""


translate english c4201_fe50fa7c:



    voice "voice/c42/0100060a01.opus"
    mx "\"No acting, no lies...\""


translate english c4201_32e86a79:



    voice "voice/c42/0100070a01.opus"
    mx "\"I don't have to think... I can just be myself. My raw self.\""


translate english c4201_0bfbcac5:


    "De algún modo, siento que sé a qué se refiere."


translate english c4201_47eb093f:


    "Miyuki batea ese bate como si se hubiera liberado de todos los problemas del mundo."


translate english c4201_e0b1e04e:



    voice "voice/c42/0100080a01.opus"
    mx "\"Now that she's gone...\""


translate english c4201_3f5fb14b:



    voice "voice/c42/0100090a01.opus"
    mx "\"Now that she's far away...\""


translate english c4201_14e4cf99:



    voice "voice/c42/0100100a01.opus"
    mx "\"Now that I miss her...\""


translate english c4201_027d64b6:



    voice "voice/c42/0100110a01.opus"
    mx "\"I finally understand.\""


translate english c4201_cb2c9a0f:



    voice "voice/c42/0100120a01.opus"
    mx "\"I'll be perfectly honest.\""


translate english c4201_af6af867:



    voice "voice/c42/0100130a01.opus"
    mx "\"I always hated Aoi.\""


translate english c4201_357eb912:



    voice "voice/c42/0100140a01.opus"
    mx "\"I wanted her gone.\""


translate english c4201_459c48c4:



    voice "voice/c42/0100150a01.opus"
    mx "\"I didn't want to be around her.\""


translate english c4201_88603690:



    voice "voice/c42/0100160a01.opus"
    mx "\"But at the same time, I couldn't shut her out.\""


translate english c4201_b778f3a2:



    voice "voice/c42/0100170a01.opus"
    mx "\"Somewhere deep down... I wanted to BE her.\""


translate english c4201_4ddb0227:



    voice "voice/c42/0100180a01.opus"
    mx "\"She was true to others, and true to herself, and she always stood up for what she believed in.\""


translate english c4201_4b15dee5:



    voice "voice/c42/0100190a01.opus"
    mx "\"And I liked that about her.\""


translate english c4201_5ad5afcc:



    voice "voice/c42/0100200a01.opus"
    mx "\"So I decided...\""


translate english c4201_87ca00f6:



    voice "voice/c42/0100210a01.opus"
    mx "\"Maybe I could be like that.\""


translate english c4201_2866ed92:



    voice "voice/c42/0100220a01.opus"
    mx "\"Maybe I could learn to be like her—to stop overthinking and start facing my fears head-on.\""


translate english c4201_59a12659:



    voice "voice/c42/0100230a01.opus"
    mx "\"And now... Shinichi...\""


translate english c4201_6d7657c0:


    "Se da la vuelta para mirarme. Las jaulas de bateo están en absoluto silencio."


translate english c4201_48a65fe0:


    "Todo se detiene."


translate english c4201_af93df0a:


    "Estoy clavado en el sitio como si me tuviera agarrado del corazón."


translate english c4201_ecf8b3e9:



    voice "voice/c42/0100240a01.opus"
    mx "\"Will you hear me out?\""


translate english c4201_944fe707:


    "Lo entiendo."


translate english c4201_925a91db:


    "Entiendo por qué Miyuki envidiaría a una chica terca e inflexible como Aoi."


translate english c4201_5ce5c7aa:


    "Y ahora que Aoi la ha cambiado, sé lo que va a decir."


translate english c4201_409a4ddd:


    "Estaba aterrada de lastimar a alguien... y de salir lastimada ella misma."


translate english c4201_be9df8ba:


    "Y así suprimió sus sentimientos durante todos estos años."


translate english c4201_aacdc701:



    voice "voice/c42/0100250a01.opus"
    mx "\"I want you to know...\""


translate english c4201_65270319:



    voice "voice/c42/0100260a01.opus"
    mx "\"That I—\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
