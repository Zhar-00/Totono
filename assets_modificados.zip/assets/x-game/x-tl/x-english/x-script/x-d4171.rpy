

translate english d4171_514b064c:


    "El recuerdo de aquel día fatídico cruza por mi mente."


translate english d4171_d2819e03:


    "Si Miyuki no hubiera amenazado con cortar lazos con Aoi entonces, quizás seguiríamos siendo amigos hoy."


translate english d4171_69ed93b0:


    "Pero todo se acabó ahora."


translate english d4171_63235f35:


    "Aoi desapareció sin protestar."


translate english d4171_fe4ce690:


    "Y ahora nuestra amistad se acabó."


translate english d4171_9968cbdb:


    xy "\"It's all in the past now.\""


translate english d4171_5efd9b27:



    voice "voice/d41/7100010b01.opus"
    xtl "\"Shinichi!!!\""


translate english d4171_e2c4a801:


    "Yuutarou me grita en la cara."


translate english d4171_a089e9cc:


    "Pero no me llega."


translate english d4171_7f902e80:


    "No hay Dios en mi mundo."


translate english d4171_aecf395c:


    "Ninguna señal divina."


translate english d4171_5581e235:


    "Mi única opción es acostumbrarme a mi nueva vida sin ella."


translate english d4171_05bff8b6:


    "Mi única opción... es seguir viviendo."


translate english d4171_52cbe71e:


    xy "\"She vanished of her own volition.\""


translate english d4171_bf146415:



    voice "voice/d41/7100020b01.opus"
    xtl "\"You're just using that as an excuse.\""


translate english d4171_c2fad319:


    xy "\"I know that, okay? I know that!\""


translate english d4171_ba722f9e:


    "Busco constantemente una excusa para no hacer nada."


translate english d4171_7eae9a27:


    "Así evito sentirme patético."


translate english d4171_238a1cf5:


    "Así evito salir herido."


translate english d4171_f70e203b:


    "Así es la clase de tipo que soy."


translate english d4171_3414e11f:


    "Así que solo tendré que acostumbrarme."


translate english d4171_61b40f49:



    voice "voice/d41/7100030b01.opus"
    xtl "\"—!!!\""


translate english d4171_f55b2e9c:


    "Yuutarou aparta sus manos de mí como si fuera basura."


translate english d4171_16ffbc6d:


    "Me tambaleo hacia atrás y me sujeto de un escritorio."


translate english d4171_5a13d5ba:



    voice "voice/d41/7100040b01.opus"
    xtl "\"Ask yourself what Mukou's taught you!\""


translate english d4171_4262d383:


    "Me empuja la carta de expulsión."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
