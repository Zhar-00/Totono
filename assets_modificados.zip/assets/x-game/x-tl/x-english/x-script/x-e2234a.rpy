

translate english e2234a_dd6ce9f2:



    voice "voice/e22/34a00010a01.opus"
    mx "\"How do you feel about this town, Shinichi?\""


translate english e2234a_2b3dc93d:


    "Nunca lo había pensado."


translate english e2234a_72081593:


    "No es una gran ciudad."


translate english e2234a_49d5b80a:


    "Pero tampoco es un pueblito rural."


translate english e2234a_58f4fcf4:


    "Solo un pueblo común y corriente."


translate english e2234a_7f572d37:


    "El tipo de pueblo que encuentras en cualquier lugar."


translate english e2234a_c14313d4:


    xy "\"Well, I'm not particularly in love with it, but I've lived here all my life, so... I can't really hate it, I guess.\""


translate english e2234a_8b001b6b:


    xy "\"What about you?\""


translate english e2234a_0ae28226:



    voice "voice/e22/34a00020a01.opus"
    mx "\"I love it.\""


translate english e2234a_b1fa614a:



    voice "voice/e22/34a00030a01.opus"
    mx "\"Because you're here.\""


translate english e2234a_8ab784ef:


    xy "\"...Aww, shucks...\""


translate english e2234a_cd9d6e0a:


    "Es muy dulce de su parte... me da un poco de vergüenza oírselo decir en mi cara..."


translate english e2234a_35da5c44:



    voice "voice/e22/34a00040a01.opus"
    mx "\"The view from up here completes me.\""


translate english e2234a_61f12c50:



    voice "voice/e22/34a00050a01.opus"
    mx "\"I don't need anything else.\""


translate english e2234a_970afad9:


    "Muy propio de una perfeccionista como Miyuki."


translate english e2234a_d915af75:



    voice "voice/e22/34a00060a01.opus"
    mx "\"This is where I was born and raised.\""


translate english e2234a_88400e19:



    voice "voice/e22/34a00070a01.opus"
    mx "\"So of course I'd love it here.\""


translate english e2234a_65b5db90:


    "Su susurro suena casi un poco triste."


translate english e2234a_56b12efd:



    voice "voice/e22/34a00080a01.opus"
    mx "\"...Down we go.\""


translate english e2234a_1d19a8ba:



    voice "voice/e22/34a00090a01.opus"
    mx "\"Alright, let's get going.\""


translate english e2234a_21428a4c:


    xy "\"Okay.\""


translate english e2234a_f3fed53b:


    "Cerramos el techo con llave tras nosotros y volvemos al salón de clases."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
