

translate english e2133_7bebc475:



    voice "voice/e21/3300010a01.opus"
    mx "\"Nasty, isn't it?\""


translate english e2133_49a78ee9:


    xy "\"You're not wrong...\""


translate english e2133_b53bdb1a:


    xy "\"I mean, why'd you even buy it in the first place?\""


translate english e2133_3ed9bfaf:



    voice "voice/e21/3300020a01.opus"
    mx "\"It was on sale. It's being discontinued, you know.\""


translate english e2133_a31cf3d0:



    voice "voice/e21/3300030a01.opus"
    mx "\"Because nobody ever drinks it.\""


translate english e2133_dab69adb:


    xy "\"Yeah, I can imagine.\""


translate english e2133_83ff3583:


    "No conozco a NADIE que le guste esa cosa."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
