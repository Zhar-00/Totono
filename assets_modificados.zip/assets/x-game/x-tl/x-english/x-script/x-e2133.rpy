

translate english e2133_7bebc475:



    voice "voice/e21/3300010a01.opus"
    mx "\"Asqueroso, ¿no?\""


translate english e2133_49a78ee9:


    xy "\"No te equivocas...\""


translate english e2133_b53bdb1a:


    xy "\"Digo, ¿por qué lo compraste en primer lugar?\""


translate english e2133_3ed9bfaf:



    voice "voice/e21/3300020a01.opus"
    mx "\"Estaba en oferta. Lo van a descontinuar, sabes.\""


translate english e2133_a31cf3d0:



    voice "voice/e21/3300030a01.opus"
    mx "\"Porque nadie lo bebe.\""


translate english e2133_dab69adb:


    xy "\"Sí, me lo imagino.\""


translate english e2133_83ff3583:


    "No conozco a NADIE que le guste esa cosa."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
