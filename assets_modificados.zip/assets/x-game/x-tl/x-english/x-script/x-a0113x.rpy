

translate english a0113x_c4a66fff:


    xy "\"Eh... ¿hola?\""


translate english a0113x_ef1fe97d:


    "¡Dios, marqué un número al azar y de verdad contestaron!"


translate english a0113x_91a866f5:


    xy "\"Eh... ¿hola?\""


translate english a0113x_63c3dc1e:



    voice "voice/a01/13x00010b02.opus"
    kmsm "\"MUKOU AOI SINCRONIZADA CON ÉXITO.\""


translate english a0113x_35e8e589:



    voice "voice/a01/13x00020b02.opus"
    kmsm "\"NOTA: FALLO AL REVERTIR ERRORES EMOCIONALES.\""


translate english a0113x_bb156d0a:


    xy "\"¿Qué reversión...?\""


translate english a0113x_da96fd07:



    voice "voice/a01/13x00030b02.opus"
    kmsm "\"DEBIDO A LA NATURALEZA DE ESTE ERROR, SUS EMOCIONES EXISTEN DE FORMA INDEPENDIENTE EN EL SISTEMA.\""


translate english a0113x_31bac3b1:



    voice "voice/a01/13x00040b02.opus"
    kmsm "\"POR LO TANTO, SI EL SUJETO ASÍ LO DESEA...\""


translate english a0113x_9555cec9:



    voice "voice/a01/13x00050b02.opus"
    kmsm "ES POSIBLE QUE {i}TÚ{i} SE ENCUENTRE CON {i}ELLA{i} OTRA VEZ... EN OTRO UNIVERSO."



translate english a0113x_4e45c16a:


    "Con eso, la línea se corta."


translate english a0113x_d853d3ce:


    "¿Quién era esa?"


translate english a0113x_bf4624c1:


    "All that \"bug in the system\"asunto no tuvo ningún sentido para mí..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
