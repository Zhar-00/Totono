

translate english e2209_d3093d0f:



    voice "voice/e22/0900010a01.opus"
    mx "\"Let me guess... You think she's telling the truth?\""


translate english e2209_4642c7c9:


    xy "\"Of course not! I'd never believe a load of crap like that!\""


translate english e2209_c4364795:


    xy "\"Telling me I can't tell reality from fiction... That Aoi's actually real... Pssh...\""


translate english e2209_b8dbd856:



    voice "voice/e22/0900020a01.opus"
    mx "\"Well, I'm not surprised you feel that way, I suppose.\""


translate english e2209_39c70a6b:



    voice "voice/e22/0900030a01.opus"
    mx "\"In that case, I'll let you off the hook this time.\""


translate english e2209_9e4c98aa:



    voice "voice/e22/0900040a01.opus"
    mx "\"But... Let's see...\""


translate english e2209_83481d37:


    "Miyuki desvía la mirada y murmura para sí, con la vista fija en algún mundo lejano que solo ella puede ver."


translate english e2209_1a313aa5:



    voice "voice/e22/0900050a01.opus"
    mx "\"Now that YOU'VE found out, I'll have to come up with a countermeasure.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
