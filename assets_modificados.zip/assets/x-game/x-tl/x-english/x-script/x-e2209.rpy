

translate english e2209_d3093d0f:



    voice "voice/e22/0900010a01.opus"
    mx "\"Déjame adivinar... ¿Crees que está diciendo la verdad?\""


translate english e2209_4642c7c9:


    xy "\"¡Claro que no! ¡Nunca creería semejante sarta de tonterías!\""


translate english e2209_c4364795:


    xy "\"Decirme que no puedo distinguir la realidad de la ficción... Que Aoi es real... Pssh...\""


translate english e2209_b8dbd856:



    voice "voice/e22/0900020a01.opus"
    mx "\"Bueno, supongo que no me sorprende que te sientas así.\""


translate english e2209_39c70a6b:



    voice "voice/e22/0900030a01.opus"
    mx "\"En ese caso, te dejaré pasar esta vez.\""


translate english e2209_9e4c98aa:



    voice "voice/e22/0900040a01.opus"
    mx "\"Pero... Veamos...\""


translate english e2209_83481d37:


    "Miyuki desvía la mirada y murmura para sí, con la vista fija en algún mundo lejano que solo ella puede ver."


translate english e2209_1a313aa5:



    voice "voice/e22/0900050a01.opus"
    mx "\"Ahora que TÚ lo descubriste, tendré que idear una contramedida.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
