

translate english e2209d_005a7bd5:



    voice "voice/e22/09d00010a01.opus"
    mx "\"If you really like her, you could always reload the game, or exit without playing through the scene, you know...\""


translate english e2209d_b3547855:



    voice "voice/e22/09d00020a01.opus"
    mx "\"What'll it be? Want to read the rest?\""


translate english e2209d_23f0b756:


    "¿No es obvio?"


translate english e2209d_c4751668:


    "No estaría haciendo clic en el texto si no me interesara ver a dónde va esta escena."


translate english e2209d_15c771fb:



    voice "voice/e22/09d00030a02.opus"
    aoi "\"You don't like condoms?\""


translate english e2209d_41eee976:



    voice "voice/e22/09d00040a02.opus"
    aoi "\"You prefer it raw?\""


translate english e2209d_bf336960:



    voice "voice/e22/09d00050b03.opus"
    c "\"Huh? N-No, that's not...\""


translate english e2209d_bb8d5bc0:



    voice "voice/e22/09d00060a02.opus"
    aoi "\"That's fine too.\""


translate english e2209d_4effdbc1:


    "El condón cayó de sus labios."


translate english e2209d_f6b11787:



    voice "voice/e22/09d00070a02.opus"
    aoi "\"You don't have to wear one if you don't want to.\""


translate english e2209d_a1495cc2:



    voice "voice/e22/09d00080a02.opus"
    aoi "\"Just hurry up and give it to me.\""


translate english e2209d_8f2fc7ba:



    voice "voice/e22/09d00090b03.opus"
    c "\"That's not what I meant to imply—\""


translate english e2209d_ec44712f:


    "Confundido, intenté protestar, pero—"


translate english e2209d_42e4900b:



    voice "voice/e22/09d00100a02.opus"
    aoi "\"Aoi loves sex. Aoi loves pussies, and Aoi loves cocks.\""


translate english e2209d_fb36ef43:



    voice "voice/e22/09d00110a02.opus"
    aoi "\"Doesn't matter whose. Doesn't matter what they look like.\""


translate english e2209d_3702e433:



    voice "voice/e22/09d00160a02.opus"
    aoi "\"Just a crazy nympho.\""


translate english e2209d_a09688ae:



    voice "voice/e22/09d00170a02.opus"
    aoi "\"But if you feel bad for me...\""


translate english e2209d_59f4191b:



    voice "voice/e22/09d00180a02.opus"
    aoi "\"...then give me that dick.\""


translate english e2209d_6be60e82:


    "Su sonrisa era tan radiante..."


translate english e2209d_69fba442:


    "Ya no pude resistirme a ella."


translate english e2209d_19c6c313:



    voice "voice/e22/09d00190a02.opus"
    aoi "\"—! —! —! Nnnnnngg!!!\""


translate english e2209d_5edf8aa5:



    voice "voice/e22/09d00200a02.opus"
    aoi "\"There it is—Haru-chan's—cock—is in me—!\""


translate english e2209d_2a4c87da:



    voice "voice/e22/09d00210a02.opus"
    aoi "\"It feels—so good—AAH! Oh—god—! Feels like—Aoi might—cum instantly—!!!\""


translate english e2209d_2890dbeb:



    voice "voice/e22/09d00220a01.opus"
    mx "\"Tsk, tsk...\""


translate english e2209d_7f81724f:



    voice "voice/e22/09d00230a01.opus"
    mx "\"Does this heroine even care about the protagonist? How can she even think about having sex with other guys?\""


translate english e2209d_587ac56a:



    voice "voice/e22/09d00240a01.opus"
    mx "\"...And yet I see you're still playing.\""


translate english e2209d_db3aea0b:



    voice "voice/e22/09d00250a01.opus"
    mx "\"Are you into this sort of thing...?\""


translate english e2209d_753672f4:



    voice "voice/e22/09d00260a01.opus"
    mx "\"Is that why you're... standing at attention?\""


translate english e2209d_6415d526:


    "Sonrojada, Miyuki mira fijamente el bulto en mis pantalones, y yo me apresuro a taparme."


translate english e2209d_9da940cd:


    "Extiende una mano con cautela."


translate english e2209d_fcebde03:



    voice "voice/e22/09d00270a01.opus"
    mx "\"No, it's okay... um... You don't have to be embarrassed.\""


translate english e2209d_9fd6b6d8:



    voice "voice/e22/09d00280a01.opus"
    mx "\"I mean... the sex scenes are kinda the whole point of the game, so...\""


translate english e2209d_1a77c956:


    xy "\"But—\""


translate english e2209d_4d059a26:



    voice "voice/e22/09d00290a01.opus"
    mx "\"...Want me to help you with that?\""


translate english e2209d_7fe1cf16:


    xy "\"Huh...?\""


translate english e2209d_381eac5b:



    voice "voice/e22/09d00300a01.opus"
    mx "\"Well, you're horny, right?\""


translate english e2209d_a0289c96:



    voice "voice/e22/09d00310a01.opus"
    mx "\"Isn't that why you randomly launched the game?\""


translate english e2209d_058d035d:


    "Acaricia suavemente la tienda de campaña en mis pantalones."


translate english e2209d_25abbf69:



    voice "voice/e22/09d00320a01.opus"
    mx "\"Keep playing.\""


translate english e2209d_d7dc7661:



    voice "voice/e22/09d00330a01.opus"
    mx "\"My hand will feel way better than yours, I promise.\""


translate english e2209d_d5ceef3a:


    "Baja la cremallera y saca con cuidado mi polla."


translate english e2209d_f6eeb326:


    "Sus delgados dedos se enrollan con dudas alrededor de mi miembro."


translate english e2209d_d22d9d94:



    voice "voice/e22/09d00340a01.opus"
    mx "\"It's so warm... You must be really turned on.\""


translate english e2209d_34c9cae9:


    "Me susurra al oído, y siento cómo las fuerzas drenan lentamente de mis extremidades."


translate english e2209d_1dd2f809:



    voice "voice/e22/09d00350a02gm.opus"
    aoi "\"Hnn! Nnn! It feels so good— Give me more! More! Fuck me harder!\""


translate english e2209d_7694de2c:



    voice "voice/e22/09d00360a02gm.opus"
    aoi "\"There's... a reset button... deep inside my pussy... And the more you press it—\""


translate english e2209d_74dc480d:



    voice "voice/e22/09d00370a02gm.opus"
    aoi "\"—the more Aoi glitches out! My code—will break down—\""


translate english e2209d_1dd6c7ad:



    voice "voice/e22/09d00380a02gm.opus"
    aoi "\"It feels so good—Aoi's gonna forget everyone but you— All Aoi can think about—is your cock—!\""


translate english e2209d_319e0c1d:


    "En el juego, el placer de Aoi empieza a aumentar, pero en este momento estoy algo distraído."


translate english e2209d_8eda1cc3:



    voice "voice/e22/09d00390a01.opus"
    mx "\"I'll get you off right along with her. Just like this... Up and down... How does it feel?\""


translate english e2209d_21b82b3b:


    "Miyuki susurra justo a mi lado."


translate english e2209d_d53b4a63:


    "Su mano izquierda me hace cosquillas en el costado mientras su derecha trabaja mi polla."


translate english e2209d_76112466:


    "Siento sus pechos apretados contra mi espalda."


translate english e2209d_ffec2444:



    voice "voice/e22/09d00400a01.opus"
    mx "\"Well? How's it feel, masturbating to a video game? Oh, right... I guess this doesn't really count as masturbation...\""


translate english e2209d_0b7b5e14:



    voice "voice/e22/09d00410a01.opus"
    mx "\"Rubbing and rubbing... Up and down, up and down... This is pretty naughty, isn't it?\""


translate english e2209d_7b6f0b27:



    voice "voice/e22/09d00420a01.opus"
    mx "\"Wait... Something's leaking from your tip.\""


translate english e2209d_4745ac33:


    xy "\"Nnn... nngh!\""


translate english e2209d_8578b57a:



    voice "voice/e22/09d00430a01.opus"
    mx "\"Eyes on the screen, mister! I'll match my timing to the game.\""


translate english e2209d_a34e1a3c:



    voice "voice/e22/09d00440a02.opus"
    aoi "\"AAAH! Oh god! Aoi can feel it... It's coming... The zappy... electricity... is coming...!\""


translate english e2209d_c892eadb:



    voice "voice/e22/09d00450a02.opus"
    aoi "\"Nnhaah! Aaahh! Nnn... nnng... nnngghh! Nnnngggggghhhhhhh—!!!\""


translate english e2209d_1c84005b:



    voice "voice/e22/09d00460a02.opus"
    aoi "\"Nnn—nngh—nnnngg—nnn! Nnn... nnn... Oh god—yes—Aoi's cumming—!\""


translate english e2209d_f3652295:



    voice "voice/e22/09d00470a02.opus"
    aoi "\"Cumming too hard—can't handle—too intense—nngh—oh no—can't hold it in—!\""


translate english e2209d_6ffd8bd7:



    voice "voice/e22/09d00480a02.opus"
    aoi "\"Nnn—nng—nnnngh—nnn—haah... aah... aaahh... aaaaaaaahhhh...!\""


translate english e2209d_d96a8407:



    voice "voice/e22/09d00490a02.opus"
    aoi "\"Aah... aah... It's... leaking out... It feels... so good... Aaahh! Nnn...\""


translate english e2209d_3850ecbc:



    voice "voice/e22/09d00500a02.opus"
    aoi "\"Nnhaah! Aah! Aah! Aah! Aah! It won't stop... It just won't stop...!\""


translate english e2209d_83753f4e:



    voice "voice/e22/09d00510a01.opus"
    mx "\"Oh dear. Looks like she peed herself. She must really be into it.\""


translate english e2209d_06b2a010:


    xy "\"Miyuki—slow down—!\""


translate english e2209d_d8730da3:



    voice "voice/e22/09d00520a01.opus"
    mx "\"Well, she's been cumming for a while now. These porn game heroines are like little fountains of lust, I suppose.\""


translate english e2209d_6b410165:



    voice "voice/e22/09d00530a01.opus"
    mx "\"Not sure how to replicate the piss, though... Oh, I know. Mmm... mm... sllrrpp... lllpp...\""


translate english e2209d_0df8c437:


    xy "\"—!!!\""



translate english e2209d_d0c54ba8:


    "La saliva gotea de su lengua."


translate english e2209d_48785ff1:


    "El cálido fluido cae sobre mi punta y se mezcla con sus movimientos, lubricando su palma."


translate english e2209d_4874e5c7:



    voice "voice/e22/09d00540a01.opus"
    mx "\"Maybe now you can self-insert a little better.\""


translate english e2209d_1c910d69:


    xy "\"Miyuki, I can't—\""


translate english e2209d_28e0f498:



    voice "voice/e22/09d00550a01.opus"
    mx "\"Hmm? Can't hold back? I'm not surprised... Your cock's been twitching for a while now...\""


translate english e2209d_c1254ee6:



    voice "voice/e22/09d00560a01.opus"
    mx "\"But you'll have to suck it up, Shinichi. I'm trying to add to your immersion here.\""


translate english e2209d_78c2d570:



    voice "voice/e22/09d00570a01.opus"
    mx "\"You can't cum before he does.\""


translate english e2209d_affba6a3:


    xy "\"Oh, come on...!\""


translate english e2209d_73d34c16:



    voice "voice/e22/09d00580a01.opus"
    mx "\"It probably won't be much longer, so hang in there.\""


translate english e2209d_46fdc069:



    voice "voice/e22/09d00590a01.opus"
    mx "\"It'll feel great cumming alongside him. Wouldn't YOU agree?\""


translate english e2209d_80f4d065:



    voice "voice/e22/09d00600a02.opus"
    aoi "\"Haahh... aah... Your cock... is rock hard... Are you... gonna cum...?\""


translate english e2209d_2986d96f:



    voice "voice/e22/09d00610a02.opus"
    aoi "\"That's okay... Go ahead... Blow your load inside my pussy...\""


translate english e2209d_8a5a9735:



    voice "voice/e22/09d00620a02.opus"
    aoi "\"Squirt your... baby batter... into my oven... Fill me up... Flood me...!\""


translate english e2209d_6428e023:



    voice "voice/e22/09d00630a02.opus"
    aoi "\"Please... Make Aoi your fucktoy!\""


translate english e2209d_fbe205cf:



    voice "voice/e22/09d00640a01.opus"
    mx "\"Almost there. Five more clicks and they'll cum. Time to... dial it up to eleven!!!\""


translate english e2209d_7067c23f:



    voice "voice/e22/09d00650a02.opus"
    aoi "\"Aaahh! Aah! Aah! Oh god—yes, yes, yes! Deeper! Just like that—oh god—\""


translate english e2209d_bed5e1ac:



    voice "voice/e22/09d00660a02.opus"
    aoi "\"Aoi loves you, Haru-chan! So much! And Aoi loves your cock, too!\""


translate english e2209d_cea4544b:



    voice "voice/e22/09d00670a02.opus"
    aoi "\"Haahh! Aah! Aah! Aoi's gonna cum... gonna cum... gonna cum... cumming... CUMMING...! Aah! Aaaaaahh—!\""


translate english e2209d_0aa1f175:



    voice "voice/e22/09d00680a02.opus"
    aoi "\"AAAAAAAAAAAAAAAAAAAAAAAHHHHH!!!\""


translate english e2209d_1033cb2a:



    voice "voice/e22/09d00690a02.opus"
    aoi "\"Nnhaah! Aaahh... aaaaahhh... It's so warm... Aoi can feel... your hot load... filling me...\""


translate english e2209d_466a9e49:



    voice "voice/e22/09d00700a02.opus"
    aoi "\"Your cock's twitching... over and over... inside me.... Haahh! Aah! Nnn! Nnngh! Nnn...!\""


translate english e2209d_2325d0bf:



    voice "voice/e22/09d00710a02.opus"
    aoi "\"So much... baby batter... Head... all glitchy...\""


translate english e2209d_fbf9267b:



    voice "voice/e22/09d00720a01.opus"
    mx "\"Good boy. You lasted all the way until they finished. Was it good for YOU, too?\""


translate english e2209d_f33e2e8b:


    xy "\"Oh... Yeah... it was good... but...\""


translate english e2209d_fef9876c:



    voice "voice/e22/09d00730a01.opus"
    mx "\"But what?\""


translate english e2209d_1ccd18d7:


    xy "\"Well—nngh!\""


translate english e2209d_f4e0a61c:


    xy "\"You can... go ahead and... stop now...!\""


translate english e2209d_96261e4a:



    voice "voice/e22/09d00740a01.opus"
    mx "\"Why? Doesn't it feel good?\""


translate english e2209d_9031495a:


    "Ya me corrí, y aun así sigue frotando mi polla, con la mano goteando de mi semen."


translate english e2209d_4f451f41:


    "No se detiene, ni siquiera después de exprimir hasta la última gota de mi uretra."


translate english e2209d_57159d4f:


    "Sus movimientos se sienten más pegajosos ahora, y el inconfundible aroma a semen sube desde mi entrepierna."


translate english e2209d_05c320d6:


    "Admito que SÍ se siente bien, pero—"


translate english e2209d_906095ce:


    xy "\"Any more and it's gonna start to hurt...!\""


translate english e2209d_04f4a4aa:



    voice "voice/e22/09d00750a01.opus"
    mx "\"Like I told you, I'm trying to match the game.\""


translate english e2209d_5f20f02f:


    xy "\"What? But—\""


translate english e2209d_2651fc95:



    voice "voice/e22/09d00760a02.opus"
    aoi "\"Aoi won't let you go... won't let you escape...\""


translate english e2209d_8f6e16a0:



    voice "voice/e22/09d00770a02.opus"
    aoi "\"Aoi was born to fuck.\""


translate english e2209d_0e0a45a5:



    voice "voice/e22/09d00780a02.opus"
    aoi "\"Aoi's a full-time cock wrangler. And that's all Aoi could ever want.\""


translate english e2209d_2b86b315:



    voice "voice/e22/09d00790a02.opus"
    aoi "\"That's what my body was made for. Streamlined to suit your tastes.\""


translate english e2209d_7781832d:



    voice "voice/e22/09d00800a02.opus"
    aoi "\"See? You're getting hard again.\""


translate english e2209d_f89cbbaf:



    voice "voice/e22/09d00810a01.opus"
    mx "\"And so are you, I notice.\""


translate english e2209d_f4c2dca6:



    voice "voice/e22/09d00820a01.opus"
    mx "\"So, does it hurt? Do you want me to stop?\""


translate english e2209d_ad9910bc:



    voice "voice/e22/09d00830a01.opus"
    mx "\"You don't, do you? Your cock wouldn't get hard from pain alone.\""


translate english e2209d_91801b83:



    voice "voice/e22/09d00840a01.opus"
    mx "\"I notice you're not answering me. You doing okay? You seem to be moaning an awful lot... Are you getting a little distracted, maybe?\""


translate english e2209d_d5fe940a:



    voice "voice/e22/09d00850a02gm.opus"
    aoi "\"It's all Aoi can ever think about... Haah! Aah! Aaahh! The zappy... It won't stop...!\""


translate english e2209d_1c1a300b:



    voice "voice/e22/09d00860a02gm.opus"
    aoi "\"Haahh! Aah! Aah! My womb...! It wants more of your semen, Haru-chan...!\""


translate english e2209d_5c37fa69:



    voice "voice/e22/09d00870a02gm.opus"
    aoi "\"It wants to slurp up all the baby batter in your ballsack...!\""


translate english e2209d_6ffb2dda:



    voice "voice/e22/09d00880a02gm.opus"
    aoi "\"Give me more... Fuck my slutty nympho pussy! Give it to me!!!\""


translate english e2209d_9d499b47:



    voice "voice/e22/09d00890a01.opus"
    mx "\"Look at that... Your legs are starting to quiver... Oh, and you're drooling a bit, too!\""


translate english e2209d_9e079185:



    voice "voice/e22/09d00900a01.opus"
    mx "\"Hmm... Can you actually cum twice in a row, though? Like a porn game protagonist?\""


translate english e2209d_0613455d:



    voice "voice/e22/09d00910a01.opus"
    mx "\"If you can't, we can exit the game here.\""


translate english e2209d_6fd479e0:



    voice "voice/e22/09d00920a01.opus"
    mx "\"But given that YOU'RE still clicking through... It must mean YOU'RE prepared to cum with him, right?\""


translate english e2209d_d16f125f:



    voice "voice/e22/09d00930a01.opus"
    mx "\"In that case, I'm gonna give you the biggest, wettest, loudest, most intense handjob of your life!\""


translate english e2209d_c2dfb42c:



    voice "voice/e22/09d00940a01.opus"
    mx "\"So, how does it feel, getting a handjob while playing a porn game? Does my hand feel good? It does, doesn't it?\""


translate english e2209d_10976398:



    voice "voice/e22/09d00950a02gm.opus"
    aoi "\"Nnhaah...! Nnn... nnng... Haru-chan, are you gonna cum some more...?\""


translate english e2209d_eccc4a71:



    voice "voice/e22/09d00960a02gm.opus"
    aoi "\"That's okay... Go ahead... Nnnggh! Go ahead and cum your brains out...!\""


translate english e2209d_2998a2f4:



    voice "voice/e22/09d00970a02gm.opus"
    aoi "\"Aoi loves to fuck... Aoi loves dick... but... that's not all...\""


translate english e2209d_cfa9d862:



    voice "voice/e22/09d00980a02gm.opus"
    aoi "\"Aoi loves you, too... Lots and lots... Forever and ever...\""


translate english e2209d_979cb9f2:



    voice "voice/e22/09d00990a02gm.opus"
    aoi "\"We were fated... to be together... Aaahh!!! That's why... we're... making love...!\""


translate english e2209d_58c53e0a:



    voice "voice/e22/09d01000a01.opus"
    mx "\"Wow. I can't believe she's betraying the protagonist like that.\""


translate english e2209d_24b5fc60:



    voice "voice/e22/09d01010a02gm.opus"
    aoi "\"Haaahh! Aah! It's... getting... even bigger...! Haaahhh! Aaaaahh!\""


translate english e2209d_a0fc81cb:



    voice "voice/e22/09d01020a01.opus"
    mx "\"This heroine is trash tier. Don't YOU agree?\""


translate english e2209d_f2bf3f5f:



    voice "voice/e22/09d01030a02gm.opus"
    aoi "\"Haru-chan... Aoi... Aoi loves you... Your cock... is all... Aoi needs...!\""


translate english e2209d_30d00e51:



    voice "voice/e22/09d01040a01.opus"
    mx "\"This character is such a slut. She only cares about getting off.\""


translate english e2209d_c1c5b063:



    voice "voice/e22/09d01050a02gm.opus"
    aoi "\"Aaahh! Aoi's gonna cum! Sorry— Aoi's cumming first again— Hyaah! Aaahh! Aah!\""


translate english e2209d_e350c113:



    voice "voice/e22/09d01060a01.opus"
    mx "\"Hmmm... Almost there, I think. But you'll have to hold out until his climax.\""


translate english e2209d_447f7683:



    voice "voice/e22/09d01070a02gm.opus"
    aoi "\"Hnn! Aoi's gonna cum! Hnng! Nnn! Aaahh! Aah! Aah, aah, aah, aah, aah, aah—AAAAAAAAHHHH!!!\""


translate english e2209d_d68cb7f5:



    voice "voice/e22/09d01080a01.opus"
    mx "\"Hahah! Look at that! Aoi's cumming! Right there on screen! Wow... That look on her face!\""


translate english e2209d_245bb328:



    voice "voice/e22/09d01090a02gm.opus"
    aoi "\"Hnng... nnnggh... nnn... nnggh! Cum...ming... still cummiiiiiinnngggg!\""


translate english e2209d_1d609f2b:



    voice "voice/e22/09d01100a01.opus"
    mx "\"Her climax just keeps going, huh? Hahahahaha! God, she's the worst. But YOU'RE still holding out, right? Just a little longer...\""


translate english e2209d_277eaca9:



    voice "voice/e22/09d01110a02gm.opus"
    aoi "\"Aah... aahaah... aaaaaaahhhh...! Your cock is... swelling up...!\""


translate english e2209d_349f6a37:



    voice "voice/e22/09d01120a01.opus"
    mx "\"On the verge? It sure feels like it to me... Well then... Heheheh... Let's finish you off!!!\""


translate english e2209d_5e180ba3:



    voice "voice/e22/09d01130a02gm.opus"
    aoi "\"Are you gonna cum? Right into my womb? Are you? Yesh pleashe! Give me all your baby batter... Aaahh!\""


translate english e2209d_5a23fdcc:



    voice "voice/e22/09d01140a01.opus"
    mx "\"Haha! Here we go. I'm gonna make you cum with my hand... One more click and you can let loose!\""


translate english e2209d_b0fe278b:



    voice "voice/e22/09d01150a02gm.opus"
    aoi "\"Hnng! Hnn... hnn... hnn— Hnnnngggggggghhhhhhhhh—!!!\""


translate english e2209d_6c0c42b5:



    voice "voice/e22/09d01160a01.opus"
    mx "\"Aah! You really blew your load pretty hard— Whoa! You came... right in the palm of my hand...!\""


translate english e2209d_028898ae:



    voice "voice/e22/09d01170a01.opus"
    mx "\"I can feel you pulsing... Oh! You're shooting harder than the first time...! You're twitching under my fingers... Ah! Another spurt!\""


translate english e2209d_b67e11a3:



    voice "voice/e22/09d01180a01.opus"
    mx "\"That's it... Go ahead and let it all out— There you go— Aah! You just keep going...\""


translate english e2209d_5e2d1f3f:



    voice "voice/e22/09d01190a01.opus"
    mx "\"Nng... nng... nnn— Heheh... Squeezed out every last drop.\""


translate english e2209d_ec2c1cdd:


    "Aprieta desde mi base hasta la punta, exprimiendo una vez más el último resto de semen de mi uretra, y sonríe."


translate english e2209d_8a38d0bf:



    voice "voice/e22/09d01200a01.opus"
    mx "\"Who needs to masturbate to 2D porn when you can get a handjob from me?\""


translate english e2209d_d82658c3:



    voice "voice/e22/09d01210a02.opus"
    aoi "\"Hnng... nnn... nnnn... nnn...\""


translate english e2209d_394bbeac:



    voice "voice/e22/09d01220a02.opus"
    aoi "\"Aoi's... so zappy... My head's... all buggy... Hehehe... Aoi feels all... spacey...\""


translate english e2209d_03ac8ab0:



    voice "voice/e22/09d01230a02.opus"
    aoi "\"Haha... haha... hahahahahahahahahaha...!!!\""


translate english e2209d_23087193:



    voice "voice/e22/09d01240a01.opus"
    mx "\"Haah... She really gets on my nerves.\""


translate english e2209d_c83429ac:



    voice "voice/e22/09d01250a01.opus"
    mx "\"There's no way anyone could fall in love with her.\""


translate english e2209d_dcbab8e5:



    voice "voice/e22/09d01260a01.opus"
    mx "\"Don't YOU agree?\""


translate english e2209d_c998cff2:


    xy "\"Definitely.\""


translate english e2209d_607edfe8:


    "Es imposible enamorarse de un personaje en 2D, para empezar."


translate english e2209d_6e874050:


    "Obviamente."


translate english e2209d_ef598f39:



    voice "voice/e22/09d01270a01.opus"
    mx "\"Oops... You came so hard, it got all over the cake.\""


translate english e2209d_2af7e5d8:


    "Ni siquiera me di cuenta de que había puesto mi pastel sobre la mesa..."


translate english e2209d_7af9d2cc:


    "Recoge mi semen junto con el glaseado."


translate english e2209d_191018f8:


    "Luego, como hipnotizada, desliza la cuchara en su boca."


translate english e2209d_59df28eb:


    xy "\"Uh... Miyuki...?\""


translate english e2209d_1537d116:



    voice "voice/e22/09d01280a01.opus"
    mx "\"Nom... mmm. Hehehe.\""


translate english e2209d_81e9a358:



    voice "voice/e22/09d01290a01.opus"
    mx "\"Delicious...\""


translate english e2209d_49f63e98:


    "Lo saborea un momento y luego traga."



translate english e2209d_23574fea:



    voice "voice/e22/09d00120a02.opus"
    aoi "\"Long ones, short ones, thick ones, thin ones. Doesn't matter. They all feel good inside me.\""


translate english e2209d_ce724745:



    voice "voice/e22/09d00130a02.opus"
    aoi "\"Aoi thinks about sex 24/7/365.\""


translate english e2209d_aefbb961:



    voice "voice/e22/09d00140b03.opus"
    c "\"That's... not healthy.\""


translate english e2209d_2fb27964:



    voice "voice/e22/09d00150a02.opus"
    aoi "\"Aoi's all glitchy.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
