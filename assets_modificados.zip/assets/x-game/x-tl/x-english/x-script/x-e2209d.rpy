

translate english e2209d_005a7bd5:



    voice "voice/e22/09d00010a01.opus"
    mx "\"Si de verdad te gusta, siempre puedes recargar el juego, o salir sin pasar por la escena, sabes...\""


translate english e2209d_b3547855:



    voice "voice/e22/09d00020a01.opus"
    mx "\"¿Qué será? ¿Quieres leer el resto?\""


translate english e2209d_23f0b756:


    "¿No es obvio?"


translate english e2209d_c4751668:


    "No estaría haciendo clic en el texto si no me interesara ver a dónde va esta escena."


translate english e2209d_15c771fb:



    voice "voice/e22/09d00030a02.opus"
    aoi "\"¿No te gustan los condones?\""


translate english e2209d_41eee976:



    voice "voice/e22/09d00040a02.opus"
    aoi "\"¿Lo prefieres sin?\""


translate english e2209d_bf336960:



    voice "voice/e22/09d00050b03.opus"
    c "\"¿Eh? N-No, no es que...\""


translate english e2209d_bb8d5bc0:



    voice "voice/e22/09d00060a02.opus"
    aoi "\"Eso también está bien.\""


translate english e2209d_4effdbc1:


    "El condón cayó de sus labios."


translate english e2209d_f6b11787:



    voice "voice/e22/09d00070a02.opus"
    aoi "\"No tienes que usar uno si no quieres.\""


translate english e2209d_a1495cc2:



    voice "voice/e22/09d00080a02.opus"
    aoi "\"Solo apúrate y dámelo.\""


translate english e2209d_8f2fc7ba:



    voice "voice/e22/09d00090b03.opus"
    c "\"No era lo que quería insinuar—\""


translate english e2209d_ec44712f:


    "Confundido, intenté protestar, pero—"


translate english e2209d_42e4900b:



    voice "voice/e22/09d00100a02.opus"
    aoi "\"Aoi ama el sexo. Aoi ama los coños y Aoi ama las vergas.\""


translate english e2209d_fb36ef43:



    voice "voice/e22/09d00110a02.opus"
    aoi "\"No importa de quién. No importa cómo se vean.\""


translate english e2209d_3702e433:



    voice "voice/e22/09d00160a02.opus"
    aoi "\"Solo una ninfómana loca.\""


translate english e2209d_a09688ae:



    voice "voice/e22/09d00170a02.opus"
    aoi "\"Pero si sientes lástima por mí...\""


translate english e2209d_59f4191b:



    voice "voice/e22/09d00180a02.opus"
    aoi "\"...entonces dame esa verga.\""


translate english e2209d_6be60e82:


    "Su sonrisa era tan radiante..."


translate english e2209d_69fba442:


    "Ya no pude resistirme a ella."


translate english e2209d_19c6c313:



    voice "voice/e22/09d00190a02.opus"
    aoi "\"—! —! —! ¡Nnnnnngg!!!\""


translate english e2209d_5edf8aa5:



    voice "voice/e22/09d00200a02.opus"
    aoi "\"Ahí está—la verga—de Haru-chan—está dentro de mí—!\""


translate english e2209d_2a4c87da:



    voice "voice/e22/09d00210a02.opus"
    aoi "\"¡Se siente—tan bien—AAH! Ay—Dios—! ¡Parece que—Aoi podría—venirse al instante—!!!\""


translate english e2209d_2890dbeb:



    voice "voice/e22/09d00220a01.opus"
    mx "\"Tsk, tsk...\""


translate english e2209d_7f81724f:



    voice "voice/e22/09d00230a01.opus"
    mx "\"¿A esta heroína siquiera le importa el protagonista? ¿Cómo puede pensar en tener sexo con otros tipos?\""


translate english e2209d_587ac56a:



    voice "voice/e22/09d00240a01.opus"
    mx "\"...Y aun así veo que sigues jugando.\""


translate english e2209d_db3aea0b:



    voice "voice/e22/09d00250a01.opus"
    mx "\"¿Te gusta este tipo de cosas...?\""


translate english e2209d_753672f4:



    voice "voice/e22/09d00260a01.opus"
    mx "\"¿Por eso estás... en posición de firme?\""


translate english e2209d_6415d526:


    "Sonrojada, Miyuki mira fijamente el bulto en mis pantalones, y yo me apresuro a taparme."


translate english e2209d_9da940cd:


    "Extiende una mano con cautela."


translate english e2209d_fcebde03:



    voice "voice/e22/09d00270a01.opus"
    mx "\"No, está bien... emm... No tienes que avergonzarte.\""


translate english e2209d_9fd6b6d8:



    voice "voice/e22/09d00280a01.opus"
    mx "\"Digo... las escenas de sexo son un poco el punto del juego, así que...\""


translate english e2209d_1a77c956:


    xy "\"Pero—\""


translate english e2209d_4d059a26:



    voice "voice/e22/09d00290a01.opus"
    mx "\"...¿Quieres que te ayude con eso?\""


translate english e2209d_7fe1cf16:


    xy "\"¿Eh...?\""


translate english e2209d_381eac5b:



    voice "voice/e22/09d00300a01.opus"
    mx "\"Bueno, estás caliente, ¿no?\""


translate english e2209d_a0289c96:



    voice "voice/e22/09d00310a01.opus"
    mx "\"¿No es por eso que abriste el juego de la nada?\""


translate english e2209d_058d035d:


    "Acaricia suavemente la tienda de campaña en mis pantalones."


translate english e2209d_25abbf69:



    voice "voice/e22/09d00320a01.opus"
    mx "\"Sigue jugando.\""


translate english e2209d_d7dc7661:



    voice "voice/e22/09d00330a01.opus"
    mx "\"Mi mano se sentirá mucho mejor que la tuya, lo prometo.\""


translate english e2209d_d5ceef3a:


    "Baja la cremallera y saca con cuidado mi polla."


translate english e2209d_f6eeb326:


    "Sus delgados dedos se enrollan con dudas alrededor de mi miembro."


translate english e2209d_d22d9d94:



    voice "voice/e22/09d00340a01.opus"
    mx "\"Está tan caliente... Debes estar muy excitado.\""


translate english e2209d_34c9cae9:


    "Me susurra al oído, y siento cómo las fuerzas drenan lentamente de mis extremidades."


translate english e2209d_1dd2f809:



    voice "voice/e22/09d00350a02gm.opus"
    aoi "\"¡Hnn! ¡Nnn! ¡Se siente tan bien— Dame más! ¡Más! ¡Cógeme más fuerte!\""


translate english e2209d_7694de2c:



    voice "voice/e22/09d00360a02gm.opus"
    aoi "\"Hay... un botón de reinicio... bien dentro de mi coño... Y mientras más lo presionas—\""


translate english e2209d_74dc480d:



    voice "voice/e22/09d00370a02gm.opus"
    aoi "\"—¡más se buguea Aoi! Mi código—se descompone—\""


translate english e2209d_1dd6c7ad:



    voice "voice/e22/09d00380a02gm.opus"
    aoi "\"Se siente tan bien—Aoi va a olvidar a todos menos a ti— ¡Lo único en lo que Aoi puede pensar—es en tu verga—!\""


translate english e2209d_319e0c1d:


    "En el juego, el placer de Aoi empieza a aumentar, pero en este momento estoy algo distraído."


translate english e2209d_8eda1cc3:



    voice "voice/e22/09d00390a01.opus"
    mx "\"Te haré venir junto con ella. Así... Arriba y abajo... ¿Cómo se siente?\""


translate english e2209d_21b82b3b:


    "Miyuki susurra justo a mi lado."


translate english e2209d_d53b4a63:


    "Su mano izquierda me hace cosquillas en el costado mientras su derecha trabaja mi polla."


translate english e2209d_76112466:


    "Siento sus pechos apretados contra mi espalda."


translate english e2209d_ffec2444:



    voice "voice/e22/09d00400a01.opus"
    mx "\"¿Y bien? ¿Cómo se siente masturbarse con un videojuego? Ah, cierto... Supongo que esto no cuenta realmente como masturbación...\""


translate english e2209d_0b7b5e14:



    voice "voice/e22/09d00410a01.opus"
    mx "\"Restregar y restregar... Arriba y abajo, arriba y abajo... Esto es bastante travieso, ¿no?\""


translate english e2209d_7b6f0b27:



    voice "voice/e22/09d00420a01.opus"
    mx "\"Espera... Algo está goteando de tu punta.\""


translate english e2209d_4745ac33:


    xy "\"¡Nnn... nngh!\""


translate english e2209d_8578b57a:



    voice "voice/e22/09d00430a01.opus"
    mx "\"¡Ojos en la pantalla, señor! Ajustaré mi ritmo al del juego.\""


translate english e2209d_a34e1a3c:



    voice "voice/e22/09d00440a02.opus"
    aoi "\"¡AAAH! ¡Ay, Dios! Aoi lo siente... Ya viene... ¡La electricidad... chispeante... ya viene...!\""


translate english e2209d_c892eadb:



    voice "voice/e22/09d00450a02.opus"
    aoi "\"¡Nnhaah! ¡Aaahh! ¡Nnn... nnng... nnngghh! ¡Nnnngggggghhhhhhh—!!!\""


translate english e2209d_1c84005b:



    voice "voice/e22/09d00460a02.opus"
    aoi "\"¡Nnn—nngh—nnnngg—nnn! ¡Nnn... nnn... Ay, Dios—sí—Aoi se viene—!\""


translate english e2209d_f3652295:



    voice "voice/e22/09d00470a02.opus"
    aoi "\"Viniéndose demasiado fuerte—no puede—demasiado intenso—nngh—ay no—¡no puede aguantar—!\""


translate english e2209d_6ffd8bd7:



    voice "voice/e22/09d00480a02.opus"
    aoi "\"¡Nnn—nng—nnnngh—nnn—haah... aah... aaahh... aaaaaaaahhhh...!\""


translate english e2209d_d96a8407:



    voice "voice/e22/09d00490a02.opus"
    aoi "\"Aah... aah... Se está... escurriendo... Se siente... tan bien... ¡Aaahh! Nnn...\""


translate english e2209d_3850ecbc:



    voice "voice/e22/09d00500a02.opus"
    aoi "\"¡Nnhaah! ¡Aah! ¡Aah! ¡Aah! ¡Aah! No para... ¡Simplemente no para...!\""


translate english e2209d_83753f4e:



    voice "voice/e22/09d00510a01.opus"
    mx "\"Oh, cielos. Parece que se orinó. Debe estar realmente metida en ello.\""


translate english e2209d_06b2a010:


    xy "\"¡Miyuki—más despacio—!\""


translate english e2209d_d8730da3:



    voice "voice/e22/09d00520a01.opus"
    mx "\"Bueno, lleva un rato viniéndose. Supongo que estas heroínas de juegos porno son como pequeñas fuentes de lujuria.\""


translate english e2209d_6b410165:



    voice "voice/e22/09d00530a01.opus"
    mx "\"Aunque no sé cómo replicar la orina... Oh, ya sé. Mmm... mm... sllrrpp... lllpp...\""


translate english e2209d_0df8c437:


    xy "\"—!!!\""



translate english e2209d_d0c54ba8:


    "La saliva gotea de su lengua."


translate english e2209d_48785ff1:


    "El cálido fluido cae sobre mi punta y se mezcla con sus movimientos, lubricando su palma."


translate english e2209d_4874e5c7:



    voice "voice/e22/09d00540a01.opus"
    mx "\"Quizás ahora puedas identificarte un poco mejor.\""


translate english e2209d_1c910d69:


    xy "\"Miyuki, no puedo—\""


translate english e2209d_28e0f498:



    voice "voice/e22/09d00550a01.opus"
    mx "\"¿Hmm? ¿No puedes aguantar? No me sorprende... Tu verga lleva un rato palpitando...\""


translate english e2209d_c1254ee6:



    voice "voice/e22/09d00560a01.opus"
    mx "\"Pero tendrás que aguantarte, Shinichi. Estoy tratando de aumentar tu inmersión aquí.\""


translate english e2209d_78c2d570:



    voice "voice/e22/09d00570a01.opus"
    mx "\"No puedes venirte antes que él.\""


translate english e2209d_affba6a3:


    xy "\"¡Ay, vamos...!\""


translate english e2209d_73d34c16:



    voice "voice/e22/09d00580a01.opus"
    mx "\"Probablemente no falte mucho, así que aguanta.\""


translate english e2209d_46fdc069:



    voice "voice/e22/09d00590a01.opus"
    mx "\"Se sentirá genial venirse junto a él. ¿No estás de acuerdo?\""


translate english e2209d_80f4d065:



    voice "voice/e22/09d00600a02.opus"
    aoi "\"Haahh... aah... Tu verga... está durísima... ¿Vas... a venirte...?\""


translate english e2209d_2986d96f:



    voice "voice/e22/09d00610a02.opus"
    aoi "\"Está bien... Adelante... Suelta tu carga dentro de mi coño...\""


translate english e2209d_8a5a9735:



    voice "voice/e22/09d00620a02.opus"
    aoi "\"¡Rocía tu... masa de bebé... en mi horno... Lléname... Inúndame...!\""


translate english e2209d_6428e023:



    voice "voice/e22/09d00630a02.opus"
    aoi "\"¡Por favor... Haz de Aoi tu juguete sexual!\""


translate english e2209d_fbe205cf:



    voice "voice/e22/09d00640a01.opus"
    mx "\"Casi listo. Cinco clics más y se vendrán. Hora de... ¡subirle hasta once!!!\""


translate english e2209d_7067c23f:



    voice "voice/e22/09d00650a02.opus"
    aoi "\"¡Aaahh! ¡Aah! ¡Aah! ¡Ay, Dios—sí, sí, sí! ¡Más profundo! Así—¡ay, Dios—\""


translate english e2209d_bed5e1ac:



    voice "voice/e22/09d00660a02.opus"
    aoi "\"¡Aoi te ama, Haru-chan! ¡Muchísimo! ¡Y Aoi también ama tu verga!\""


translate english e2209d_cea4544b:



    voice "voice/e22/09d00670a02.opus"
    aoi "\"¡Haahh! ¡Aah! ¡Aah! Aoi va a venirse... va a venirse... va a venirse... viniéndose... ¡VINIÉNDOSE...! ¡Aah! ¡Aaaaaahh—!\""


translate english e2209d_0aa1f175:



    voice "voice/e22/09d00680a02.opus"
    aoi "\"¡¡¡AAAAAAAAAAAAAAAAAAAAAAAHHHH!!!\""


translate english e2209d_1033cb2a:



    voice "voice/e22/09d00690a02.opus"
    aoi "\"¡Nnhaah! ¡Aaahh... aaaaahhh... Está tan caliente... Aoi siente... tu carga caliente... llenándome...\""


translate english e2209d_466a9e49:



    voice "voice/e22/09d00700a02.opus"
    aoi "\"Tu verga palpita... una y otra vez... dentro de mí.... ¡Haahh! ¡Aah! ¡Nnn! ¡Nnngh! ¡Nnn...!\""


translate english e2209d_2325d0bf:



    voice "voice/e22/09d00710a02.opus"
    aoi "\"Tanta... masa de bebé... Cabeza... toda bugueada...\""


translate english e2209d_fbf9267b:



    voice "voice/e22/09d00720a01.opus"
    mx "\"Buen chico. Aguantaste hasta que ellos terminaron. ¿También fue bueno para TI?\""


translate english e2209d_f33e2e8b:


    xy "\"Oh... Sí... estuvo bien... pero...\""


translate english e2209d_fef9876c:



    voice "voice/e22/09d00730a01.opus"
    mx "\"¿Pero qué?\""


translate english e2209d_1ccd18d7:


    xy "\"Bueno—¡nngh!\""


translate english e2209d_f4e0a61c:


    xy "\"¡Ya puedes... parar... ahora...!\""


translate english e2209d_96261e4a:



    voice "voice/e22/09d00740a01.opus"
    mx "\"¿Por qué? ¿No se siente bien?\""


translate english e2209d_9031495a:


    "Ya me corrí, y aun así sigue frotando mi polla, con la mano goteando de mi semen."


translate english e2209d_4f451f41:


    "No se detiene, ni siquiera después de exprimir hasta la última gota de mi uretra."


translate english e2209d_57159d4f:


    "Sus movimientos se sienten más pegajosos ahora, y el inconfundible aroma a semen sube desde mi entrepierna."


translate english e2209d_05c320d6:


    "Admito que SÍ se siente bien, pero—"


translate english e2209d_906095ce:


    xy "\"¡Un poco más y va a empezar a doler...!\""


translate english e2209d_04f4a4aa:



    voice "voice/e22/09d00750a01.opus"
    mx "\"Como te dije, estoy tratando de seguir el juego.\""


translate english e2209d_5f20f02f:


    xy "\"¿Qué? Pero—\""


translate english e2209d_2651fc95:



    voice "voice/e22/09d00760a02.opus"
    aoi "\"Aoi no te dejará ir... no te dejará escapar...\""


translate english e2209d_8f6e16a0:



    voice "voice/e22/09d00770a02.opus"
    aoi "\"Aoi nació para coger.\""


translate english e2209d_0e0a45a5:



    voice "voice/e22/09d00780a02.opus"
    aoi "\"Aoi es una domadora de vergas a tiempo completo. Y eso es todo lo que Aoi podría desear.\""


translate english e2209d_2b86b315:



    voice "voice/e22/09d00790a02.opus"
    aoi "\"Para eso fue hecho mi cuerpo. Optimizado para adaptarse a tus gustos.\""


translate english e2209d_7781832d:



    voice "voice/e22/09d00800a02.opus"
    aoi "\"¿Ves? Te estás poniendo duro otra vez.\""


translate english e2209d_f89cbbaf:



    voice "voice/e22/09d00810a01.opus"
    mx "\"Y tú también, noto.\""


translate english e2209d_f4c2dca6:



    voice "voice/e22/09d00820a01.opus"
    mx "\"Entonces, ¿duele? ¿Quieres que pare?\""


translate english e2209d_ad9910bc:



    voice "voice/e22/09d00830a01.opus"
    mx "\"No quieres, ¿verdad? Tu verga no se pondría dura solo por dolor.\""


translate english e2209d_91801b83:



    voice "voice/e22/09d00840a01.opus"
    mx "\"Noto que no me respondes. ¿Estás bien? Pareces estar gimiendo muchísimo... ¿Quizás te estás distrayendo un poco?\""


translate english e2209d_d5fe940a:



    voice "voice/e22/09d00850a02gm.opus"
    aoi "\"Es lo único en lo que Aoi puede pensar... ¡Haah! ¡Aah! ¡Aaahh! Lo chispeante... ¡No para...!\""


translate english e2209d_1c1a300b:



    voice "voice/e22/09d00860a02gm.opus"
    aoi "\"¡Haahh! ¡Aah! ¡Aah! Mi útero...! ¡Quiere más de tu semen, Haru-chan...!\""


translate english e2209d_5c37fa69:



    voice "voice/e22/09d00870a02gm.opus"
    aoi "\"¡Quiere sorber toda la masa de bebé en tu escroto...!\""


translate english e2209d_6ffb2dda:



    voice "voice/e22/09d00880a02gm.opus"
    aoi "\"¡Dame más... Coge mi zorra ninfómana de coño! ¡Dámelo!!!\""


translate english e2209d_9d499b47:



    voice "voice/e22/09d00890a01.opus"
    mx "\"Mira eso... Tus piernas empiezan a temblar... ¡Oh, y también estás babeando un poco!\""


translate english e2209d_9e079185:



    voice "voice/e22/09d00900a01.opus"
    mx "\"Hmm... ¿Pero de verdad puedes venirte dos veces seguidas? ¿Como un protagonista de juego porno?\""


translate english e2209d_0613455d:



    voice "voice/e22/09d00910a01.opus"
    mx "\"Si no puedes, podemos salir del juego aquí.\""


translate english e2209d_6fd479e0:



    voice "voice/e22/09d00920a01.opus"
    mx "\"Pero dado que TÚ sigues avanzando con clics... Debe significar que estás preparado para venirte con él, ¿verdad?\""


translate english e2209d_d16f125f:



    voice "voice/e22/09d00930a01.opus"
    mx "\"En ese caso, ¡te voy a dar la paja más grande, húmeda, ruidosa e intensa de tu vida!\""


translate english e2209d_c2dfb42c:



    voice "voice/e22/09d00940a01.opus"
    mx "\"Y, ¿cómo se siente recibir una paja mientras juegas un juego porno? ¿Mi mano se siente bien? Sí, ¿verdad?\""


translate english e2209d_10976398:



    voice "voice/e22/09d00950a02gm.opus"
    aoi "\"¡Nnhaah...! Nnn... nnng... Haru-chan, ¿vas a venirte más...?\""


translate english e2209d_eccc4a71:



    voice "voice/e22/09d00960a02gm.opus"
    aoi "\"Está bien... Adelante... ¡Nnnggh! ¡Adelante, vente hasta perder la cabeza...!\""


translate english e2209d_2998a2f4:



    voice "voice/e22/09d00970a02gm.opus"
    aoi "\"Aoi ama coger... Aoi ama las vergas... pero... eso no es todo...\""


translate english e2209d_cfa9d862:



    voice "voice/e22/09d00980a02gm.opus"
    aoi "\"Aoi también te ama... Muchísimo... Por siempre y siempre...\""


translate english e2209d_979cb9f2:



    voice "voice/e22/09d00990a02gm.opus"
    aoi "\"Estábamos destinados... a estar juntos... ¡¡¡Aaahh!!! ¡Por eso... estamos... haciendo el amor...!\""


translate english e2209d_58c53e0a:



    voice "voice/e22/09d01000a01.opus"
    mx "\"Guau. No puedo creer que esté traicionando al protagonista así.\""


translate english e2209d_24b5fc60:



    voice "voice/e22/09d01010a02gm.opus"
    aoi "\"¡Haaahh! ¡Aah! ¡Se está... poniendo... aún más grande...! ¡Haaahhh! ¡Aaaaahh!\""


translate english e2209d_a0fc81cb:



    voice "voice/e22/09d01020a01.opus"
    mx "\"Esta heroína es de nivel basura. ¿No estás de acuerdo?\""


translate english e2209d_f2bf3f5f:



    voice "voice/e22/09d01030a02gm.opus"
    aoi "\"Haru-chan... Aoi... Aoi te ama... ¡Tu verga... es todo... lo que Aoi necesita...!\""


translate english e2209d_30d00e51:



    voice "voice/e22/09d01040a01.opus"
    mx "\"Este personaje es una zorra. Solo le importa venirse.\""


translate english e2209d_c1c5b063:



    voice "voice/e22/09d01050a02gm.opus"
    aoi "\"¡Aaahh! ¡Aoi va a venirse! Perdón— Aoi se viene primero otra vez— ¡Hyaah! ¡Aaahh! ¡Aah!\""


translate english e2209d_e350c113:



    voice "voice/e22/09d01060a01.opus"
    mx "\"Hmmm... Creo que casi listo. Pero tendrás que aguantar hasta su clímax.\""


translate english e2209d_447f7683:



    voice "voice/e22/09d01070a02gm.opus"
    aoi "\"¡Hnn! ¡Aoi va a venirse! ¡Hnng! ¡Nnn! ¡Aaahh! ¡Aah! ¡Aah, aah, aah, aah, aah, aah—AAAAAAAAHHHH!!!\""


translate english e2209d_d68cb7f5:



    voice "voice/e22/09d01080a01.opus"
    mx "\"¡Jajaj! ¡Mira eso! ¡Aoi se está viniendo! ¡Ahí mismo en la pantalla! Guau... ¡Esa cara que pone!\""


translate english e2209d_245bb328:



    voice "voice/e22/09d01090a02gm.opus"
    aoi "\"¡Hnng... nnnggh... nnn... nnggh! Vi...nién...dose... ¡todavía viniééééndoseeee!\""


translate english e2209d_1d609f2b:



    voice "voice/e22/09d01100a01.opus"
    mx "\"Su clímax simplemente sigue, ¿eh? ¡Jajajajaja! Dios, es la peor. Pero TÚ sigues aguantando, ¿verdad? Solo un poco más...\""


translate english e2209d_277eaca9:



    voice "voice/e22/09d01110a02gm.opus"
    aoi "\"¡Aah... aahaah... aaaaaaahhhh...! ¡Tu verga se está... hinchando...!\""


translate english e2209d_349f6a37:



    voice "voice/e22/09d01120a01.opus"
    mx "\"¿Al límite? A mí sí me lo parece... Bueno entonces... Jejejeh... ¡Acabemos contigo!!!\""


translate english e2209d_5e180ba3:



    voice "voice/e22/09d01130a02gm.opus"
    aoi "\"¿Vas a venirte? ¿Justo en mi útero? ¿Sí? ¡Shí, por favor! Dame toda tu masa de bebé... ¡Aaahh!\""


translate english e2209d_5a23fdcc:



    voice "voice/e22/09d01140a01.opus"
    mx "\"¡Jaja! Aquí vamos. Te haré venir con mi mano... ¡Un clic más y puedes soltarte!\""


translate english e2209d_b0fe278b:



    voice "voice/e22/09d01150a02gm.opus"
    aoi "\"¡Hnng! ¡Hnn... hnn... hnn— Hnnnngggggggghhhhhhhhh—!!!\""


translate english e2209d_6c0c42b5:



    voice "voice/e22/09d01160a01.opus"
    mx "\"¡Aah! De verdad soltaste tu carga con fuerza— ¡Guau! Te viniste... ¡justo en la palma de mi mano...!\""


translate english e2209d_028898ae:



    voice "voice/e22/09d01170a01.opus"
    mx "\"Te siento pulsar... ¡Oh! ¡Estás disparando más fuerte que la primera vez...! Palpitas bajo mis dedos... ¡Ah! ¡Otro chorro!\""


translate english e2209d_b67e11a3:



    voice "voice/e22/09d01180a01.opus"
    mx "\"Eso es... Adelante, suéltalo todo— Así— ¡Aah! No paras...\""


translate english e2209d_5e2d1f3f:



    voice "voice/e22/09d01190a01.opus"
    mx "\"Nng... nng... nnn— Jejeh... Exprimí hasta la última gota.\""


translate english e2209d_ec2c1cdd:


    "Aprieta desde mi base hasta la punta, exprimiendo una vez más el último resto de semen de mi uretra, y sonríe."


translate english e2209d_8a38d0bf:



    voice "voice/e22/09d01200a01.opus"
    mx "\"¿Quién necesita masturbarse con porno 2D cuando puede recibir una paja de mí?\""


translate english e2209d_d82658c3:



    voice "voice/e22/09d01210a02.opus"
    aoi "\"Hnng... nnn... nnnn... nnn...\""


translate english e2209d_394bbeac:



    voice "voice/e22/09d01220a02.opus"
    aoi "\"Aoi está... muy chispeante... Mi cabeza... toda bugueada... Jejeje... Aoi se siente toda... ida...\""


translate english e2209d_03ac8ab0:



    voice "voice/e22/09d01230a02.opus"
    aoi "\"Jaja... jaja... ¡¡¡jajajajajajajajajaja...!!!\""


translate english e2209d_23087193:



    voice "voice/e22/09d01240a01.opus"
    mx "\"Haah... De verdad me pone de los nervios.\""


translate english e2209d_c83429ac:



    voice "voice/e22/09d01250a01.opus"
    mx "\"No hay forma de que alguien se enamore de ella.\""


translate english e2209d_dcbab8e5:



    voice "voice/e22/09d01260a01.opus"
    mx "\"¿No estás de acuerdo?\""


translate english e2209d_c998cff2:


    xy "\"Definitivamente.\""


translate english e2209d_607edfe8:


    "Es imposible enamorarse de un personaje en 2D, para empezar."


translate english e2209d_6e874050:


    "Obviamente."


translate english e2209d_ef598f39:



    voice "voice/e22/09d01270a01.opus"
    mx "\"Ups... Te viniste tan fuerte que cayó todo sobre el pastel.\""


translate english e2209d_2af7e5d8:


    "Ni siquiera me di cuenta de que había puesto mi pastel sobre la mesa..."


translate english e2209d_7af9d2cc:


    "Recoge mi semen junto con el glaseado."


translate english e2209d_191018f8:


    "Luego, como hipnotizada, desliza la cuchara en su boca."


translate english e2209d_59df28eb:


    xy "\"Eh... ¿Miyuki...?\""


translate english e2209d_1537d116:



    voice "voice/e22/09d01280a01.opus"
    mx "\"Ñam... mmm. Jejeje.\""


translate english e2209d_81e9a358:



    voice "voice/e22/09d01290a01.opus"
    mx "\"Delicioso...\""


translate english e2209d_49f63e98:


    "Lo saborea un momento y luego traga."



translate english e2209d_23574fea:



    voice "voice/e22/09d00120a02.opus"
    aoi "\"Largas, cortas, gruesas, delgadas. No importa. Todas se sienten bien dentro de mí.\""


translate english e2209d_ce724745:



    voice "voice/e22/09d00130a02.opus"
    aoi "\"Aoi piensa en sexo 24/7/365.\""


translate english e2209d_aefbb961:



    voice "voice/e22/09d00140b03.opus"
    c "\"Eso... no es saludable.\""


translate english e2209d_2fb27964:



    voice "voice/e22/09d00150a02.opus"
    aoi "\"Aoi está toda bugueada.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
