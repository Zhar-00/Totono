

translate english e2234b_c0b3bd7f:



    voice "voice/e22/34b00010a01.opus"
    mx "\"...Wanna see?\""


translate english e2234b_d27eeafa:


    xy "\"Huh?\""


translate english e2234b_6b46f8c9:



    voice "voice/e22/34b00020a01.opus"
    mx "\"Well... you know... I did promise you...\""


translate english e2234b_a9f01c4c:



    voice "voice/e22/34b00030a01.opus"
    mx "\"That thing after the home run competition...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
