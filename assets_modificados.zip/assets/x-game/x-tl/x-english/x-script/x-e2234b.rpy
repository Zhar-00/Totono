

translate english e2234b_c0b3bd7f:



    voice "voice/e22/34b00010a01.opus"
    mx "\"...¿Quieres ver?\""


translate english e2234b_d27eeafa:


    xy "\"¿Eh?\""


translate english e2234b_6b46f8c9:



    voice "voice/e22/34b00020a01.opus"
    mx "\"Pues... ya sabes... te lo prometí...\""


translate english e2234b_a9f01c4c:



    voice "voice/e22/34b00030a01.opus"
    mx "\"Eso después de la competencia de home runs...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
