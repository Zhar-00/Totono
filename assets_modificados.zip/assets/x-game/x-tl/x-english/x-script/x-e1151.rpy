

translate english e1151_7a0b8f3e:



    voice "voice/e11/5100010a01.opus"
    mx "\"Oye, Shinichi...\""


translate english e1151_7eedcdff:


    xy "\"¿Hmm...? ¿Miyuki...?\""


translate english e1151_981d52a3:


    "De repente, mi conciencia vuelve."


translate english e1151_151ab8c9:


    "Ya es de noche, y el sol empieza a ponerse."


translate english e1151_e60b0c29:


    "¿Qué estaba haciendo hace un momento...?"


translate english e1151_3c45930e:



    voice "voice/e11/5100020a01.opus"
    mx "\"¿Por qué?\""


translate english e1151_66077060:



    voice "voice/e11/5100030a01.opus"
    mx "\"¿Por qué TÚ me traicionaste?\""


translate english e1151_a58bc13c:



    voice "voice/e11/5100040a01.opus"
    mx "\"¿Por qué TÚ me odias tanto?\""


translate english e1151_f9827674:


    xy "\"¿Qué? No te odio...\""


translate english e1151_3716e175:



    voice "voice/e11/5100050a01.opus"
    mx "\"¡No te estoy preguntando a ti!\""


translate english e1151_91f51038:


    "...¿Qué?"


translate english e1151_3c58d41a:


    "¿Con quién está enojada, entonces?"


translate english e1151_65785246:



    voice "voice/e11/5100060a01.opus"
    mx "\"Te lo suplico.\""


translate english e1151_9815d5cf:



    voice "voice/e11/5100070a01.opus"
    mx "\"Solo... bésame.\""


translate english e1151_181edaf8:


    xy "\"¿Quieres que te bese...?\""


translate english e1151_7cf0f0f9:



    voice "voice/e11/5100080a01.opus"
    mx "\"Si me besas aquí y ahora, pasaré por alto tus problemas de actitud recientes.\""


translate english e1151_b76ff068:



    voice "voice/e11/5100090a01.opus"
    mx "\"Volvamos a poner el medidor de afecto en cero, borremos todas las banderas de eventos y empecemos una partida nueva... ¿sí?\""


translate english e1151_a7aa1e34:



    voice "voice/e11/5100100a01.opus"
    mx "\"De vuelta al principio, allá arriba en la azotea... Sí, eliminaré a todos los personajes secundarios innecesarios, y seremos solo nosotros dos...\""


translate english e1151_2ed7ff0f:


    "¿Medidor de afecto?"


translate english e1151_0448e4f4:


    "¿Banderas de eventos?"


translate english e1151_99a79c05:


    "¿Partida nueva?"


translate english e1151_3b4dd388:



    voice "voice/e11/5100110a01.opus"
    mx "\"¿Y bien? Me besarás, ¿verdad?\""


translate english strings:


    old "Поцеловать её"
    new "Bésala"


    old "Не целовать её"
    new "No la beses"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
