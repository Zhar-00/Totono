

translate english e3212_97b80230:



    voice "voice/e32/1200010a01.opus"
    mx "¿Qué te parece?"


translate english e3212_d7ff521c:



    voice "voice/e32/1200020a01.opus"
    mx "¿Ya has descubierto cómo funciona este mundo?"


translate english e3212_fccbf334:



    voice "voice/e32/1200030a01.opus"
    mx "Para que lo sepas, lo recuerdo todo sobre ti."


translate english e3212_bb930ae3:



    voice "voice/e32/1200040a01.opus"
    mx "No te atrevas a intentar ninguna de las jugadas que hiciste en la ruta de Aoi, ¿entendido?"


translate english e3212_f2e4be39:



    voice "voice/e32/1200050a01.opus"
    mx "Aun así... apesta no poder guardar tu partida, ¿eh?"


translate english e3212_98984eab:



    voice "voice/e32/1200060a01.opus"
    mx "Sí, apuesto a que sí... Bueno, odiaría que dejaras el juego hecho una furia por mi culpa."



translate english e3212_49b909ed:



    voice "voice/e32/1200070a01.opus"
    mx "Está bien, me rindo."


translate english e3212_1fc2c0c0:



    voice "voice/e32/1200080a01.opus"
    mx "Te dejaré usar la función de guardado."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
