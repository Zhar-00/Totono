

translate english e2172g_da494787:


    "\"Cocina para principiantes.\""



translate english e2172g_d41ed192:



    voice "voice/e21/72g00010a01.opus"
    mx "\"Escucha...\""


translate english e2172g_5fbe71d6:



    voice "voice/e21/72g00020a01.opus"
    mx "\"¿Por qué no varías y compras una revista porno o algo?\""


translate english e2172g_b77fd3cc:


    xy "\"¡¿Qué?! ¡No seas ridículo!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
