

translate english e2172g_da494787:


    "\"Cooking 101.\""



translate english e2172g_d41ed192:



    voice "voice/e21/72g00010a01.opus"
    mx "\"Listen...\""


translate english e2172g_5fbe71d6:



    voice "voice/e21/72g00020a01.opus"
    mx "\"Why not mix things up and buy a porno magazine or something?\""


translate english e2172g_b77fd3cc:


    xy "\"What?! Don't be ridiculous!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
