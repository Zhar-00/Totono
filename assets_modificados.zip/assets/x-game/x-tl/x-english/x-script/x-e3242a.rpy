

translate english e3242a_846bfd79:



    voice "voice/e32/42a00010a01.opus"
    mx "Bien."


translate english e3242a_bf577e90:



    voice "voice/e32/42a00020a01.opus"
    mx "Te trataré bien, así que quédate conmigo, ¿sí?"


translate english e3242a_ce73152b:



    voice "voice/e32/42a00030a01.opus"
    mx "Viviremos aquí en este mundo por siempre jamás."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
