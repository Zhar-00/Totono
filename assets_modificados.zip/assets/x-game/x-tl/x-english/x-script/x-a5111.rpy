

translate english a5111_f9a11ebc:


    xy "*bostezo*"


translate english a5111_0accd139:


    xy "\"......\""


translate english a5111_9d4d2059:


    "Tengo tanto sueño..."


translate english a5111_ee749094:


    "No pegué un ojo anoche."


translate english a5111_47e63d7d:


    xy "\"No es sorpresa.\""


translate english a5111_e9fa78ed:


    "Eru levanta la vista y me maúlla con curiosidad."


translate english a5111_9f74ef7a:


    xy "\"No, no es tu culpa.\""


translate english a5111_ba9ac199:


    xy "\"Espera, es cierto. ¡Tenemos que desayunar!\""


translate english a5111_92b087bb:


    xy "\"Bebe, bola de pelo.\""


translate english a5111_790adde3:


    "Con Eru en un brazo, uso la mano libre para inclinar la jeringa."


translate english a5111_85ef83a4:


    "Ahora bien..."


translate english a5111_c5ced2e1:


    "¿Y ahora qué?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
