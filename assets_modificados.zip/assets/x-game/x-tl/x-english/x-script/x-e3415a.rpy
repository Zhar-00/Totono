

translate english e3415a_0accd139:


    xy "\"......\""


translate english e3415a_a01f789c:



    voice "voice/e34/15a00010a01.opus"
    mx "\"Wait!\""


translate english e3415a_22dde288:


    "No."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
