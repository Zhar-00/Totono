

translate english e3432b_96d5f571:



    voice "voice/e34/32b00010b02.opus"
    kmsm "\"GOOD CHOICE.\""


translate english e3432b_cc333191:



    voice "voice/e34/32b00020b02.opus"
    kmsm "\"INPUT A DIFFERENT NUMBER?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
