

translate english e1155a_11f0d939:



    voice "voice/e11/55a00010a01.opus"
    mx "\"Come on, don't be like that...\""


translate english e1155a_d554dfbf:



    voice "voice/e11/55a00020a01.opus"
    mx "Solo... bésame...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
