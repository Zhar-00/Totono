

translate english e1135a_eead5679:



    voice "voice/e11/35a00010a01.opus"
    mx "\"YOU'VE read my diary, so surely YOU must.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
