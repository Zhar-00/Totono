

translate english e1135a_eead5679:



    voice "voice/e11/35a00010a01.opus"
    mx "\"TÚ has leído mi diario, así que seguro que sí.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
