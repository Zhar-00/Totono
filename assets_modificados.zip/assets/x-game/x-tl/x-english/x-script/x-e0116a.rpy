

translate english e0116a_b675373d:


    xy "\"¡Claro que sí! Eres más que suficiente.\""


translate english e0116a_7b6578ab:



    voice "voice/e01/16a00010a01.opus"
    mx "\"¿De verdad lo crees?\""


translate english e0116a_c1b56e8d:


    xy "\"Claro.\""


translate english e0116a_e9a5dbe6:



    voice "voice/e01/16a00020a01.opus"
    mx "\"...Bien.\""


translate english e0116a_250b87ec:



    voice "voice/e01/16a00030a01.opus"
    mx "\"Gracias.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
