

translate english e0116a_b675373d:


    xy "\"Of course you are! You're plenty good enough.\""


translate english e0116a_7b6578ab:



    voice "voice/e01/16a00010a01.opus"
    mx "\"You really think so?\""


translate english e0116a_c1b56e8d:


    xy "\"Of course.\""


translate english e0116a_e9a5dbe6:



    voice "voice/e01/16a00020a01.opus"
    mx "\"...Okay.\""


translate english e0116a_250b87ec:



    voice "voice/e01/16a00030a01.opus"
    mx "\"Thanks.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
