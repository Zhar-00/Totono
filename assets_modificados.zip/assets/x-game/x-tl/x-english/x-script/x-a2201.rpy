

translate english a2201_0accd139:


    xy "\"\"\"\"\"......\"\"\"\"\""


translate english a2201_10230d6f:



    voice "voice/a22/0100010a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2201_8db5864c:


    "Lado a lado, caminamos junto al río, con grillos cantando a lo lejos."


translate english a2201_3dfffa6f:


    "Ni siquiera puedo recordar la última vez que caminamos a casa juntos."


translate english a2201_ced3e559:


    "Sé que debería hacerme el tranquilo, pero no puedo evitar sentirme un poco cohibido."


translate english a2201_cf1e0dfb:


    "Di algo. ¡Lo que sea!"


translate english a2201_bdea77c8:


    "En mi pánico, mi mente se queda totalmente en blanco."


translate english a2201_8195baec:


    "Mi cabeza da vueltas con las palabras de despedida de Aoi."


translate english a2201_0f7141a5:



    voice "voice/a22/0100011a02.opus"
    aoi "\"This is your big chance to confess your love.\""


translate english a2201_7589f388:


    "Entonces el lejano chasquido de un bate de béisbol rompe el silencio."


translate english a2201_66a36dae:


    "Recuerdo todas esas noches que compartimos, volviendo a casa desde las jaulas de bateo."


translate english a2201_6798b4c2:


    "Se siente como si hubiera sido hace una eternidad."


translate english a2201_c51a8dcb:


    xy "\"It's been a long time, hasn't it?\""


translate english a2201_796de21a:



    voice "voice/a22/0100020a01.opus"
    mx "\"Four years, three months, and eleven days, to be exact.\""


translate english a2201_4553826f:


    xy "\"What?\""


translate english a2201_0b4708d6:



    voice "voice/a22/0100030a01.opus"
    mx "\"It's written in my diary. That's how I know.\""


translate english a2201_46e1a335:


    xy "\"Oh... Gotcha.\""


translate english a2201_6b1e2668:


    "Miyuki siempre ha tenido ojo para los pequeños detalles así, desde que éramos niños."


translate english a2201_dbf73688:


    "Recuerdos borrosos de la infancia flotan en mi mente."


translate english a2201_6f2f2c9e:



    voice "voice/a22/0100040a01.opus"
    mx "\"I'm glad we're friends again.\""


translate english a2201_b79359cf:


    "Miyuki murmura como si probara el concepto por primera vez."


translate english a2201_6f7fc4d4:


    xy "\"All thanks to Aoi... Oh, and you too, obviously.\""


translate english a2201_54c06129:



    voice "voice/a22/0100050a01.opus"
    mx "\"I'm glad we did this, actually. Made a lot of new discoveries.\""


translate english a2201_f9486b91:


    xy "\"Like what?\""


translate english a2201_dd26e11f:



    voice "voice/a22/0100060a01.opus"
    mx "\"Like, umm... the top of the roof.\""


translate english a2201_75e2414f:


    xy "\"Oh, right. Yeah, for sure.\""


translate english a2201_a8f9f354:


    "Todavía no puedo creer que algo así estuviera justo delante de mis narices todo este tiempo..."


translate english a2201_d72c6784:


    "Algo... tan sumamente hermoso..."


translate english a2201_e81de652:



    voice "voice/a22/0100070a01.opus"
    mx "\"What?\""


translate english a2201_bb58c512:


    xy "\"Huh?\""


translate english a2201_c6794a08:


    "De pronto me descubro mirando a Miyuki."


translate english a2201_35933ac8:


    xy "\"Oh, uh, it's nothing.\""


translate english a2201_a2746396:



    voice "voice/a22/0100080a01.opus"
    mx "\"...Ha. Okay.\""


translate english a2201_670d471c:


    "La expresión de Miyuki se agria de repente."


translate english a2201_394130c0:



    voice "voice/a22/0100090a01.opus"
    mx "\"Listen, Shinichi...\""


translate english a2201_d1d8a9b4:



    voice "voice/a22/0100100a01.opus"
    mx "\"How do you feel about Aoi?\""


translate english a2201_35f7da2c:


    "¿De dónde salió eso?"


translate english a2201_cd4fb6cd:



    voice "voice/a22/0100110a01.opus"
    mx "\"I find it a little strange that you'd try so hard to help someone else.\""


translate english a2201_02334bce:



    voice "voice/a22/0100120a01.opus"
    mx "\"So I started thinking maybe... you know...\""


translate english a2201_632014d5:


    "El tono de Miyuki es perfectamente casual."


translate english a2201_a04170b3:



    voice "voice/a22/0100130a01.opus"
    mx "\"Are you... interested in her?\""


translate english a2201_da847bb9:


    xy "\"What? No, no...\""


translate english a2201_16042a0b:



    voice "voice/a22/0100140a01.opus"
    mx "\"But you obviously did something to make her cry--\""


translate english a2201_fa87b71e:


    xy "\"I told you, that was all a misunderstanding!\""


translate english a2201_eb543ddb:


    xy "\"It's hard to explain... I want to be friends with her, but more than that...\""


translate english a2201_ccf46e98:



    voice "voice/a22/0100150a01.opus"
    mx "\"Protect her?\""


translate english a2201_7d013bcf:


    xy "\"Yeah, that! Exactly!\""


translate english a2201_6ae48311:


    "De alguna forma sabe exactamente lo que intentaba decir."


translate english a2201_e0581fa5:


    xy "\"She's always sitting by herself, staring into space, waiting for a call from 'God' or whoever... Not a single friend to her name...\""


translate english a2201_ba88fcf2:


    xy "\"Her family situation is a total mystery, and she's living in a manga cafe... If I don't keep an eye on her, I just know I'll give myself an ulcer worrying about her.\""


translate english a2201_4d16bc69:



    voice "voice/a22/0100160a01.opus"
    mx "\"About that... I've been thinking.\""


translate english a2201_3babea29:



    voice "voice/a22/0100170a01.opus"
    mx "\"This isn't some video game. This is real, and she's a real person.\""


translate english a2201_048ea16a:



    voice "voice/a22/0100180a01.opus"
    mx "\"I want to help her come to terms with her reality.\""


translate english a2201_9118d25c:



    voice "voice/a22/0100190a01.opus"
    mx "\"And I think that's the best thing we can do for her.\""


translate english a2201_c8505ddb:


    "Cuando Miyuki era niña, también era solitaria."


translate english a2201_743805db:


    "Era igual de bonita y talentosa que ahora, pero no dominaba bien la etiqueta social."


translate english a2201_75001a37:


    "Por ejemplo: cada vez que alguien señalaba uno de sus defectos, se esforzaba por corregirlo."


translate english a2201_ba91ace7:


    "Pero en vez de quedarse ahí, se esforzaba por presumir el fruto de sus esfuerzos y humillar a la persona que lo había señalado."


translate english a2201_5b70db2a:


    "Una pequeña mocosa precoz, en otras palabras."


translate english a2201_ff84628d:


    "Pero creo que quizá Miyuki aceptó ayudar porque ve a su antiguo yo en Aoi."


translate english a2201_f6177cd0:


    xy "\"What was it that helped you back then?\""


translate english a2201_ff5c3430:



    voice "voice/a22/0100200a01.opus"
    mx "\"What do you mean?\""


translate english a2201_354a4946:


    xy "\"I mean, at some point you started fitting in with the rest of the class, right?\""


translate english a2201_3e109fb1:



    voice "voice/a22/0100210a01.opus"
    mx "\"That was all you, duh.\""


translate english a2201_3aa14d0e:


    xy "\"...What?\""


translate english a2201_88425a5d:



    voice "voice/a22/0100220a01.opus"
    mx "\"You're the one who helped me, genius!\""


translate english a2201_7607ab8c:



    voice "voice/a22/0100230a01.opus"
    mx "\"You nominated me for the lead role in that play, remember?\""


translate english a2201_aa799ad1:


    xy "\"I did...? Ohhh! That's right! I remember now!\""


translate english a2201_914cde9b:



    voice "voice/a22/0100240a01.opus"
    mx "\"I knew it... You totally forgot...\""


translate english a2201_f6d84193:


    "En aquel entonces, nuestra clase decidió montar una obra para el festival de artes de la escuela, pero nadie quería el papel principal."


translate english a2201_a181be29:


    "Así que nominé a Miyuki al azar."


translate english a2201_f00067f5:


    "En ese momento, pensé que aunque al principio fuera mala, trabajaría diez veces más para dejarnos a todos boquiabiertos al final."


translate english a2201_7585d3ce:



    voice "voice/a22/0100250a01.opus"
    mx "\"The moment I got up on that stage, I knew.\""


translate english a2201_fd1d275c:



    voice "voice/a22/0100260a01.opus"
    mx "\"The play was my reality, and real life was my fiction.\""


translate english a2201_347ca933:



    voice "voice/a22/0100270a01.opus"
    mx "\"Putting myself in that frame of mind helped me to stop getting so worked up over the small details.\""


translate english a2201_8cfbf069:


    xy "\"And that's what helped you get along with the rest of the class?\""


translate english a2201_b3ae2c9d:



    voice "voice/a22/0100280a01.opus"
    mx "\"I really know how to play the part, don't you think?\""


translate english a2201_bd6332b3:


    xy "\"I suppose so, yeah.\""


translate english a2201_7b0deadf:



    voice "voice/a22/0100290a01.opus"
    mx "\"You're the only one who sees through it, anyway.\""


translate english a2201_5dbb6f48:


    "Murmura con mohín."


translate english a2201_b04d7927:


    xy "\"Well... See ya.\""


translate english a2201_4ae75834:



    voice "voice/a22/0100300a01.opus"
    mx "\"H-Hey, uh...\""


translate english a2201_f5f957b4:


    xy "\"Hmm? What's up?\""


translate english a2201_34aca425:



    voice "voice/a22/0100310a01.opus"
    mx "\"Listen... Um...\""


translate english a2201_94f22148:



    voice "voice/a22/0100320a01.opus"
    mx "\"About the... thing I was gonna ask you to help me with...\""


translate english a2201_20a9d75e:


    xy "\"The thing you mentioned back at the batting cages?\""


translate english a2201_6958a772:



    voice "voice/a22/0100330a01.opus"
    mx "\"Yeah, that.\""


translate english a2201_9b7e7d3e:


    "Me parece recordar que era REALMENTE reacia a hablar de eso..."


translate english a2201_e2d5e1f9:



    voice "voice/a22/0100340a01.opus"
    mx "\"Can you... promise not to tell anyone?\""


translate english a2201_02488e53:


    xy "\"Sure.\""


translate english a2201_8d4bce2c:



    voice "voice/a22/0100350a01.opus"
    mx "\"So, uh... You know how I'm playing the lead...\""


translate english a2201_ed997813:


    xy "\"Yeah, and?\""


translate english a2201_0c8464e3:



    voice "voice/a22/0100360a01.opus"
    mx "\"Well... umm... you see...\""


translate english a2201_e194cda8:



    voice "voice/a22/0100370a01.opus"
    mx "\"There's going to be... a kiss.\""


translate english a2201_d2561452:


    "Al instante, mi mente se queda en blanco."


translate english a2201_e70aadd0:



    voice "voice/a22/0100380a01.opus"
    mx "\"In the play, I mean. There's a kissing s<I></I>cene, and...\""


translate english a2201_0a7d8241:



    voice "voice/a22/0100390a01.opus"
    mx "\"...Shinichi, are you listening?\""


translate english a2201_711c47f8:


    xy "\"Y-Yeah, I'm listening. Sounds intense! Good luck with that.\""


translate english a2201_f18a5496:



    voice "voice/a22/0100400a01.opus"
    mx "\"It's my first time.\""


translate english a2201_8c5f0ade:



    voice "voice/a22/0100410a01.opus"
    mx "\"L-Like I said...\""


translate english a2201_058c2d5a:



    voice "voice/a22/0100420a01.opus"
    mx "\"...I haven't had my first kiss yet.\""


translate english a2201_975bb64e:


    xy "\"I... I see...\""


translate english a2201_ed4fd1cf:



    voice "voice/a22/0100430a01.opus"
    mx "\"Mmhmm... So yeah...\""


translate english a2201_d1a61f4b:


    xy "\"Well, uh, no surprise there!\""


translate english a2201_46e7df04:


    xy "\"I mean, you're pretty, but like, almost TOO pretty, you know? And, as far as I know, you've never really had a boyfriend.\""


translate english a2201_41b5300b:


    xy "\"So yeah, uh... That explains that, or whatever, haha... Yep, I can see how that would be the case... Yeah.\""


translate english a2201_83a93fd6:



    voice "voice/a22/0100440a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2201_9beb9587:


    xy "\"Are you... cool with it, or...?\""


translate english a2201_c0aa1c07:



    voice "voice/a22/0100450a01.opus"
    mx "\"I don't know.\""


translate english a2201_f463c7a9:



    voice "voice/a22/0100460a01.opus"
    mx "\"But... it's the climax of the play, so...\""


translate english a2201_42e22ea2:



    voice "voice/a22/0100470a01.opus"
    mx "\"I'm worried I might screw it up.\""


translate english a2201_a1674743:


    xy "\"Why not ask the other person to help you practice?\""


translate english a2201_0225b010:



    voice "voice/a22/0100480a01.opus"
    mx "\"...I can't bring myself to do it.\""


translate english a2201_ae079c80:



    voice "voice/a22/0100490a01.opus"
    mx "\"I told him I'm just gonna wing it during the performance.\""


translate english a2201_d83a5320:


    xy "\"Ah.\""



translate english a2201_f16b7c90:



    voice "voice/a22/0100500a01.opus"
    mx "\"So, um... well... uh...\""


translate english a2201_1a00f39f:



    voice "voice/a22/0100510a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2201_9c55586e:



    voice "voice/a22/0100520a01.opus"
    mx "\"...I'll just have to do my best.\""


translate english a2201_ccc39cd6:


    xy "\"...Well, uh...\""


translate english a2201_f929271d:


    xy "\"I'm... rooting for you, I guess.\""


translate english a2201_236ded81:



    voice "voice/a22/0100530a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2201_60211837:



    voice "voice/a22/0100540a01.opus"
    mx "\"Thanks.\""


translate english a2201_1f38ed99:


    "Su voz es apenas un susurro."


translate english a2201_df06570d:



    voice "voice/a22/0100550a01.opus"
    mx "\"Well... see you.\""


translate english a2201_78fcbfc1:


    xy "\"Have a good night.\""


translate english a2201_9dd775e7:


    "Los rápidos pasos de Miyuki se desvanecen en el crepúsculo."


translate english a2201_a40885c3:


    "En cuanto a mí, me quedo clavado en el sitio mucho después de que se va."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
