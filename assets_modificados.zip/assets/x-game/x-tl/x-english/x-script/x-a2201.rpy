

translate english a2201_0accd139:


    xy "\"\"\"\"\"......\"\"\"\"\""


translate english a2201_10230d6f:



    voice "voice/a22/0100010a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2201_8db5864c:


    "Lado a lado, caminamos junto al río, con grillos cantando a lo lejos."


translate english a2201_3dfffa6f:


    "Ni siquiera puedo recordar la última vez que caminamos a casa juntos."


translate english a2201_ced3e559:


    "Sé que debería hacerme el tranquilo, pero no puedo evitar sentirme un poco cohibido."


translate english a2201_cf1e0dfb:


    "Di algo. ¡Lo que sea!"


translate english a2201_bdea77c8:


    "En mi pánico, mi mente se queda totalmente en blanco."


translate english a2201_8195baec:


    "Mi cabeza da vueltas con las palabras de despedida de Aoi."


translate english a2201_0f7141a5:



    voice "voice/a22/0100011a02.opus"
    aoi "\"Esta es tu gran oportunidad de confesar tu amor.\""


translate english a2201_7589f388:


    "Entonces el lejano chasquido de un bate de béisbol rompe el silencio."


translate english a2201_66a36dae:


    "Recuerdo todas esas noches que compartimos, volviendo a casa desde las jaulas de bateo."


translate english a2201_6798b4c2:


    "Se siente como si hubiera sido hace una eternidad."


translate english a2201_c51a8dcb:


    xy "\"Ha pasado mucho tiempo, ¿no?\""


translate english a2201_796de21a:



    voice "voice/a22/0100020a01.opus"
    mx "\"Cuatro años, tres meses y once días, para ser exactos.\""


translate english a2201_4553826f:


    xy "\"¿Qué?\""


translate english a2201_0b4708d6:



    voice "voice/a22/0100030a01.opus"
    mx "\"Está escrito en mi diario. Así lo sé.\""


translate english a2201_46e1a335:


    xy "\"Ah... Ya veo.\""


translate english a2201_6b1e2668:


    "Miyuki siempre ha tenido ojo para los pequeños detalles así, desde que éramos niños."


translate english a2201_dbf73688:


    "Recuerdos borrosos de la infancia flotan en mi mente."


translate english a2201_6f2f2c9e:



    voice "voice/a22/0100040a01.opus"
    mx "\"Me alegra que volvamos a ser amigos.\""


translate english a2201_b79359cf:


    "Miyuki murmura como si probara el concepto por primera vez."


translate english a2201_6f7fc4d4:


    xy "\"Todo gracias a Aoi... Ah, y a ti también, obviamente.\""


translate english a2201_54c06129:



    voice "voice/a22/0100050a01.opus"
    mx "\"De hecho, me alegra haber hecho esto. Hice muchos descubrimientos nuevos.\""


translate english a2201_f9486b91:


    xy "\"¿Como qué?\""


translate english a2201_dd26e11f:



    voice "voice/a22/0100060a01.opus"
    mx "\"Como, emm... la parte de arriba del techo.\""


translate english a2201_75e2414f:


    xy "\"Ah, cierto. Sí, claro.\""


translate english a2201_a8f9f354:


    "Todavía no puedo creer que algo así estuviera justo delante de mis narices todo este tiempo..."


translate english a2201_d72c6784:


    "Algo... tan sumamente hermoso..."


translate english a2201_e81de652:



    voice "voice/a22/0100070a01.opus"
    mx "\"¿Qué?\""


translate english a2201_bb58c512:


    xy "\"¿Eh?\""


translate english a2201_c6794a08:


    "De pronto me descubro mirando a Miyuki."


translate english a2201_35933ac8:


    xy "\"Ah, em, no es nada.\""


translate english a2201_a2746396:



    voice "voice/a22/0100080a01.opus"
    mx "\"...Ja. Está bien.\""


translate english a2201_670d471c:


    "La expresión de Miyuki se agria de repente."


translate english a2201_394130c0:



    voice "voice/a22/0100090a01.opus"
    mx "\"Escucha, Shinichi...\""


translate english a2201_d1d8a9b4:



    voice "voice/a22/0100100a01.opus"
    mx "\"¿Qué sientes por Aoi?\""


translate english a2201_35f7da2c:


    "¿De dónde salió eso?"


translate english a2201_cd4fb6cd:



    voice "voice/a22/0100110a01.opus"
    mx "\"Me parece un poco raro que te esfuerces tanto por ayudar a alguien más.\""


translate english a2201_02334bce:



    voice "voice/a22/0100120a01.opus"
    mx "\"Así que empecé a pensar que tal vez... ya sabes...\""


translate english a2201_632014d5:


    "El tono de Miyuki es perfectamente casual."


translate english a2201_a04170b3:



    voice "voice/a22/0100130a01.opus"
    mx "\"¿Estás... interesado en ella?\""


translate english a2201_da847bb9:


    xy "\"¿Qué? No, no...\""


translate english a2201_16042a0b:



    voice "voice/a22/0100140a01.opus"
    mx "\"Pero obviamente hiciste algo para hacerla llorar...\""


translate english a2201_fa87b71e:


    xy "\"¡Ya te dije que todo fue un malentendido!\""


translate english a2201_eb543ddb:


    xy "\"Es difícil de explicar... Quiero ser su amigo, pero más que eso...\""


translate english a2201_ccf46e98:



    voice "voice/a22/0100150a01.opus"
    mx "\"¿Protegerla?\""


translate english a2201_7d013bcf:


    xy "\"¡Sí, eso! ¡Exacto!\""


translate english a2201_6ae48311:


    "De alguna forma sabe exactamente lo que intentaba decir."


translate english a2201_e0581fa5:


    xy "\"Siempre está sentada sola, mirando al vacío, esperando una llamada de 'Dios' o de quien sea... No tiene ni un solo amigo...\""


translate english a2201_ba88fcf2:


    xy "\"Su situación familiar es un misterio total, y vive en un manga café... Si no la vigilo, sé que me voy a ulcerar de preocupación por ella.\""


translate english a2201_4d16bc69:



    voice "voice/a22/0100160a01.opus"
    mx "\"Sobre eso... He estado pensando.\""


translate english a2201_3babea29:



    voice "voice/a22/0100170a01.opus"
    mx "\"Esto no es un videojuego. Esto es real, y ella es una persona real.\""


translate english a2201_048ea16a:



    voice "voice/a22/0100180a01.opus"
    mx "\"Quiero ayudarla a aceptar su realidad.\""


translate english a2201_9118d25c:



    voice "voice/a22/0100190a01.opus"
    mx "\"Y creo que eso es lo mejor que podemos hacer por ella.\""


translate english a2201_c8505ddb:


    "Cuando Miyuki era niña, también era solitaria."


translate english a2201_743805db:


    "Era igual de bonita y talentosa que ahora, pero no dominaba bien la etiqueta social."


translate english a2201_75001a37:


    "Por ejemplo: cada vez que alguien señalaba uno de sus defectos, se esforzaba por corregirlo."


translate english a2201_ba91ace7:


    "Pero en vez de quedarse ahí, se esforzaba por presumir el fruto de sus esfuerzos y humillar a la persona que lo había señalado."


translate english a2201_5b70db2a:


    "Una pequeña mocosa precoz, en otras palabras."


translate english a2201_ff84628d:


    "Pero creo que quizá Miyuki aceptó ayudar porque ve a su antiguo yo en Aoi."


translate english a2201_f6177cd0:


    xy "\"¿Qué fue lo que te ayudó a ti en aquel entonces?\""


translate english a2201_ff5c3430:



    voice "voice/a22/0100200a01.opus"
    mx "\"¿A qué te refieres?\""


translate english a2201_354a4946:


    xy "\"O sea, en algún momento empezaste a encajar con el resto de la clase, ¿no?\""


translate english a2201_3e109fb1:



    voice "voice/a22/0100210a01.opus"
    mx "\"Eso fue todo tuyo, obvio.\""


translate english a2201_3aa14d0e:


    xy "\"...¿Qué?\""


translate english a2201_88425a5d:



    voice "voice/a22/0100220a01.opus"
    mx "\"¡Tú eres el que me ayudó, genio!\""


translate english a2201_7607ab8c:



    voice "voice/a22/0100230a01.opus"
    mx "\"Me nominaste para el papel principal de esa obra, ¿recuerdas?\""


translate english a2201_aa799ad1:


    xy "\"¿Yo lo hice...? ¡Ohhh! ¡Es cierto! ¡Ya me acordé!\""


translate english a2201_914cde9b:



    voice "voice/a22/0100240a01.opus"
    mx "\"Lo sabía... Se te olvidó por completo...\""


translate english a2201_f6d84193:


    "En aquel entonces, nuestra clase decidió montar una obra para el festival de artes de la escuela, pero nadie quería el papel principal."


translate english a2201_a181be29:


    "Así que nominé a Miyuki al azar."


translate english a2201_f00067f5:


    "En ese momento, pensé que aunque al principio fuera mala, trabajaría diez veces más para dejarnos a todos boquiabiertos al final."


translate english a2201_7585d3ce:



    voice "voice/a22/0100250a01.opus"
    mx "\"En el momento en que subí a ese escenario, lo supe.\""


translate english a2201_fd1d275c:



    voice "voice/a22/0100260a01.opus"
    mx "\"La obra era mi realidad, y la vida real era mi ficción.\""


translate english a2201_347ca933:



    voice "voice/a22/0100270a01.opus"
    mx "\"Ponerme en ese estado mental me ayudó a dejar de alterarme por los detalles pequeños.\""


translate english a2201_8cfbf069:


    xy "\"¿Y eso fue lo que te ayudó a llevarte bien con el resto de la clase?\""


translate english a2201_b3ae2c9d:



    voice "voice/a22/0100280a01.opus"
    mx "\"De verdad sé cómo actuar el papel, ¿no crees?\""


translate english a2201_bd6332b3:


    xy "\"Supongo que sí.\""


translate english a2201_7b0deadf:



    voice "voice/a22/0100290a01.opus"
    mx "\"De todos modos, tú eres el único que se da cuenta.\""


translate english a2201_5dbb6f48:


    "Murmura con mohín."


translate english a2201_b04d7927:


    xy "\"Bueno... Nos vemos.\""


translate english a2201_4ae75834:



    voice "voice/a22/0100300a01.opus"
    mx "\"O-Oye, em...\""


translate english a2201_f5f957b4:


    xy "\"¿Hmm? ¿Qué pasa?\""


translate english a2201_34aca425:



    voice "voice/a22/0100310a01.opus"
    mx "\"Escucha... Em...\""


translate english a2201_94f22148:



    voice "voice/a22/0100320a01.opus"
    mx "\"Sobre eso... que te iba a pedir que me ayudaras...\""


translate english a2201_20a9d75e:


    xy "\"¿Eso que mencionaste en el béisbol?\""


translate english a2201_6958a772:



    voice "voice/a22/0100330a01.opus"
    mx "\"Sí, eso.\""


translate english a2201_9b7e7d3e:


    "Me parece recordar que era REALMENTE reacia a hablar de eso..."


translate english a2201_e2d5e1f9:



    voice "voice/a22/0100340a01.opus"
    mx "\"¿Puedes... prometer que no se lo dirás a nadie?\""


translate english a2201_02488e53:


    xy "\"Claro.\""


translate english a2201_8d4bce2c:



    voice "voice/a22/0100350a01.opus"
    mx "\"Así que, em... Ya sabes que tengo el papel principal...\""


translate english a2201_ed997813:


    xy "\"Sí, ¿y?\""


translate english a2201_0c8464e3:



    voice "voice/a22/0100360a01.opus"
    mx "\"Bueno... emm... verás...\""


translate english a2201_e194cda8:



    voice "voice/a22/0100370a01.opus"
    mx "\"Va a haber... un beso.\""


translate english a2201_d2561452:


    "Al instante, mi mente se queda en blanco."


translate english a2201_e70aadd0:



    voice "voice/a22/0100380a01.opus"
    mx "\"En la obra, digo. Hay una esc<I></I>ena de beso, y...\""


translate english a2201_0a7d8241:



    voice "voice/a22/0100390a01.opus"
    mx "\"...Shinichi, ¿estás escuchando?\""


translate english a2201_711c47f8:


    xy "\"S-Sí, te estoy escuchando. ¡Suena intenso! Mucha suerte con eso.\""


translate english a2201_f18a5496:



    voice "voice/a22/0100400a01.opus"
    mx "\"Es mi primera vez.\""


translate english a2201_8c5f0ade:



    voice "voice/a22/0100410a01.opus"
    mx "\"C-Como dije...\""


translate english a2201_058c2d5a:



    voice "voice/a22/0100420a01.opus"
    mx "\"...Todavía no he dado mi primer beso.\""


translate english a2201_975bb64e:


    xy "\"Ya... Ya veo...\""


translate english a2201_ed4fd1cf:



    voice "voice/a22/0100430a01.opus"
    mx "\"Mmhmm... Así que sí...\""


translate english a2201_d1a61f4b:


    xy "\"Bueno, em, ¡no es sorpresa!\""


translate english a2201_46e7df04:


    xy "\"O sea, eres linda, pero como que casi DEMASIADO linda, ¿sabes? Y, hasta donde sé, nunca has tenido novio.\""


translate english a2201_41b5300b:


    xy "\"Así que sí, em... Eso explica eso, o lo que sea, jaja... Sí, ya veo cómo podría ser el caso... Sí.\""


translate english a2201_83a93fd6:



    voice "voice/a22/0100440a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2201_9beb9587:


    xy "\"¿Te... parece bien, o...?\""


translate english a2201_c0aa1c07:



    voice "voice/a22/0100450a01.opus"
    mx "\"No sé.\""


translate english a2201_f463c7a9:



    voice "voice/a22/0100460a01.opus"
    mx "\"Pero... es el clímax de la obra, así que...\""


translate english a2201_42e22ea2:



    voice "voice/a22/0100470a01.opus"
    mx "\"Me preocupa arruinarlo.\""


translate english a2201_a1674743:


    xy "\"¿Por qué no le pides a la otra persona que te ayude a practicar?\""


translate english a2201_0225b010:



    voice "voice/a22/0100480a01.opus"
    mx "\"...No me animo a hacerlo.\""


translate english a2201_ae079c80:



    voice "voice/a22/0100490a01.opus"
    mx "\"Le dije que improvisaré durante la función.\""


translate english a2201_d83a5320:


    xy "\"Ah.\""



translate english a2201_f16b7c90:



    voice "voice/a22/0100500a01.opus"
    mx "\"Así que, em... bueno... eh...\""


translate english a2201_1a00f39f:



    voice "voice/a22/0100510a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2201_9c55586e:



    voice "voice/a22/0100520a01.opus"
    mx "\"...Solo tendré que dar lo mejor de mí.\""


translate english a2201_ccc39cd6:


    xy "\"...Bueno, em...\""


translate english a2201_f929271d:


    xy "\"Estoy... apoyándote, supongo.\""


translate english a2201_236ded81:



    voice "voice/a22/0100530a01.opus"
    mx "\"\"\"\"\"......\"\"\"\"\""


translate english a2201_60211837:



    voice "voice/a22/0100540a01.opus"
    mx "\"Gracias.\""


translate english a2201_1f38ed99:


    "Su voz es apenas un susurro."


translate english a2201_df06570d:



    voice "voice/a22/0100550a01.opus"
    mx "\"Bueno... nos vemos.\""


translate english a2201_78fcbfc1:


    xy "\"Que tengas buena noche.\""


translate english a2201_9dd775e7:


    "Los rápidos pasos de Miyuki se desvanecen en el crepúsculo."


translate english a2201_a40885c3:


    "En cuanto a mí, me quedo clavado en el sitio mucho después de que se va."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
