

translate english c7112_cc2bb63d:


    xy "\"Look, just be honest with me.\""


translate english c7112_0a33c564:


    xy "\"Tell me the real reason why you cheated on me.\""


translate english c7112_35d4f398:


    xy "\"Please, just... help me understand.\""


translate english c7112_7de6068b:


    "Sé que es patético, pero estoy desesperado."


translate english c7112_e47d30d6:


    "La amo demasiado. No puedo simplemente quitármelo de encima."


translate english c7112_67d7dee9:


    "¿Perdió el interés en mí?"


translate english c7112_d728d417:


    "¿O es que Ryuujirou es realmente bueno en la cama?"


translate english c7112_76c6b756:


    "Solo quiero una explicación. No me importa cuál sea."


translate english c7112_d4677d6b:


    "Solo quiero entender por qué."


translate english c7112_197a2834:



    voice "voice/c71/1200010a02.opus"
    aoi "\"Boop boop...\""


translate english c7112_c55065b6:


    "Aoi me mira con expresión ausente, de la misma forma que siempre solía hacerlo."


translate english c7112_2b0efd3b:



    voice "voice/c71/1200020a02.opus"
    aoi "\"Can we speak in private?\""


translate english c7112_7d657d79:


    "Murmura quedamente."


translate english c7112_b3536db2:


    "En apariencia, suena normal."


translate english c7112_8b5e9194:


    "Pero me doy cuenta."


translate english c7112_af79ebe9:


    "Está totalmente derrotada."


translate english c7112_fe226b4b:


    xy "\"...Guys?\""


translate english c7112_1caffc24:



    voice "voice/c71/1200030a01.opus"
    mx "\"......\""


translate english c7112_b0c64307:



    voice "voice/c71/1200040b01.opus"
    xtl "\"Alright.\""


translate english c7112_1c565089:


    "Miyuki se queda callada, pero Yuutarou habla en su lugar."


translate english c7112_80592780:



    voice "voice/c71/1200050b01.opus"
    xtl "\"Come on, Ryuujirou, let's go!\""


translate english c7112_aa29a837:



    voice "voice/c71/1200060b03.opus"
    c "\"Umm—\""


translate english c7112_37387458:



    voice "voice/c71/1200070b03.opus"
    c "\"Susuki-senpai... I don't really know what to say... I...\""


translate english c7112_3bef8a93:


    xy "\"I don't want to hear it.\""


translate english c7112_6a13a660:



    voice "voice/c71/1200080b03.opus"
    c "\"Okay, but... You have to believe me!\""


translate english c7112_38532ea2:



    voice "voice/c71/1200090b03.opus"
    c "\"Yes, we went to my room, but I swear, Aoi-senpai really did leave before anything happened... Honest... So...\""


translate english c7112_26384f6c:



    voice "voice/c71/1200100b03.opus"
    c "\"I'm pretty sure... she never stopped loving you, Susuki-senpai...\""


translate english c7112_12e64a21:


    xy "\"......\""


translate english c7112_785fbc6b:



    voice "voice/c71/1200110b01.opus"
    xtl "\"Ryuujirou.\""


translate english c7112_51e41b78:


    "Yuutarou pone suavemente una mano en el hombro tembloroso de Ryuujirou."


translate english c7112_493c55dc:



    voice "voice/c71/1200120b01.opus"
    xtl "\"Let's go.\""


translate english c7112_5ab7c1c2:



    voice "voice/c71/1200130b03.opus"
    c "\"...Bye.\""


translate english c7112_0af67bdf:


    "Los hermanos Akebono salen de la sala."


translate english c7112_0657699c:


    "Ahora solo quedamos Aoi, Miyuki y yo."


translate english c7112_8fd36a8c:


    "Los segundos pasan, lentos y constantes."


translate english c7112_9d0c4c9e:


    xy "\"Miyuki...\""


translate english c7112_43f367e5:


    xy "\"Please.\""


translate english c7112_4cce01e7:



    voice "voice/c71/1200140a01.opus"
    mx "\"Alright.\""


translate english c7112_ab9acac8:



    voice "voice/c71/1200150a01.opus"
    mx "\"I'll leave you two alone... but promise me something.\""


translate english c7112_4ed43f61:



    voice "voice/c71/1200160a01.opus"
    mx "\"Don't do anything crazy.\""


translate english c7112_be1de285:


    xy "\"I won't.\""


translate english c7112_4f879f65:


    "Miyuki suspira profundamente."


translate english c7112_dd6d5cb7:



    voice "voice/c71/1200170a01.opus"
    mx "\"I made a promise to myself back then.\""


translate english c7112_45ac6c92:



    voice "voice/c71/1200180a01.opus"
    mx "\"Everyone makes mistakes. I can forgive and forget—the first time.\""


translate english c7112_c0c264eb:



    voice "voice/c71/1200190a01.opus"
    mx "\"BUT...\""


translate english c7112_5218190d:



    voice "voice/c71/1200200a01.opus"
    mx "\"Mark my words... There better not be a second time.\""


translate english c7112_62a1cd13:



    voice "voice/c71/1200210a01.opus"
    mx "\"Love is eternal. Don't ruin it.\""


translate english c7112_e3adb631:


    xy "\"What...?\""


translate english c7112_2327dbd6:



    voice "voice/c71/1200220a01.opus"
    mx "\"See you later.\""


translate english c7112_f578a4d9:


    "Miyuki sale de la habitación."


translate english c7112_7cf45348:


    "Desafortunadamente, no estoy de humor para creer en el amor eterno."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
