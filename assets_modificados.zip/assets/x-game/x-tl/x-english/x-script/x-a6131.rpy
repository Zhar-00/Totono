

translate english a6131_b6bb5ebe:


    "Al día siguiente, Aoi ha desaparecido."


translate english a6131_8fd6707f:



    voice "voice/a61/3100010b01.opus"
    xtl "\"When I got home, she was already gone... I'm so sorry...!\""


translate english a6131_9bf14b01:


    xy "\"It's... It's not your fault.\""


translate english a6131_917612cb:


    "Se había saltado la escuela para recuperarse de su enfermedad, pero para cuando Yuutarou llegó a casa, ella y Eru ya se habían ido."


translate english a6131_640a4da1:


    "Buscamos en el café de manga... luego en el resto de la ciudad... pero no la encontramos por ningún lado."


translate english a6131_f69f3cc8:


    "When we asked our teacher, he wouldn't tell us much beyond \"her family moved away\"y \"they didn't leave an address.\""


translate english a6131_2a120888:


    "Y, naturalmente, su teléfono sigue sin tener señal."


translate english a6131_2cb93c42:


    "Así que ahora me quedo sin forma de volver a contactarla nunca."


translate english a6131_49e38f07:



    voice "voice/a61/3100020a02.opus"
    aoi "\"You'll never see me again.\""


translate english a6131_be20ce00:


    "Se fue del pueblo por su propia voluntad."


translate english a6131_409d8bc9:


    "Sus últimas palabras de despedida son prueba suficiente de ello."


translate english a6131_10578f6a:


    "Y ni siquiera se despidió."


translate english a6131_59002840:


    "Simplemente... me abandonó."


translate english a6131_c9357174:


    "Pero el mundo sigue igual."


translate english a6131_1a911fd1:


    "Para todos los demás, era solo una chica rara que solía estar en nuestra clase."


translate english a6131_8e16858c:


    "Han vuelto a sus vidas normales... y yo también."


translate english a6131_93dcbcbb:


    "Por fuera, nada ha cambiado."


translate english a6131_fc53be58:


    "Me despierto por la mañana."


translate english a6131_ec25e27e:


    "Voy a la escuela."


translate english a6131_1419e3d3:


    "Voy a clase."


translate english a6131_c47b26cd:


    "Almuerzo."


translate english a6131_374fcda1:


    "Intento mantenerme despierto."


translate english a6131_96fd8c50:


    "Vuelvo a casa."


translate english a6131_2666199b:


    "Veo televisión."


translate english a6131_a77eaf73:


    "Y luego me voy a la cama."


translate english a6131_d664671b:


    "Una y otra vez..."


translate english a6131_c17f522c:


    "Nada especial ni digno de mención sucede."


translate english a6131_495e7a14:


    "Mi vida diaria vuelve a ser como era antes de hacerme amigo de Aoi. Miyuki y yo tampoco volvemos a hablar."


translate english a6131_5721ad6e:


    "Pero algo ha cambiado... de forma permanente."


translate english a6131_d0ee72ef:


    "Y nunca se podrá deshacer."


translate english a6131_6d177491:



    voice "voice/a61/3100030a01.opus"
    mx "\"Good morning!\""


translate english a6131_73ffc0c3:



    voice "voice/a61/3100040a01.opus"
    mx "\"...What's that? The bakery by the train station?\""


translate english a6131_c4fedbe7:



    voice "voice/a61/3100050a01.opus"
    mx "\"I'm sorry... I'm on a diet right now. The big performance is coming up, after all.\""


translate english a6131_8d5fbc8d:



    voice "voice/a61/3100060a01.opus"
    mx "\"Yeah! Once it's over, let's definitely go sometime.\""


translate english a6131_e2e8a1b9:


    "Miyuki sigue siendo el centro de atención, como siempre."


translate english a6131_213a63c6:


    "Durante unos días, los rumores explotaron con habladurías sobre su fallida confesión amorosa, pero al final decidieron que debí haberlo inventado todo."


translate english a6131_34cea839:


    "Claramente nadie veía razón alguna para que alguien del calibre de Miyuki se interesara románticamente por un don nadie como yo."


translate english a6131_53815cc3:


    "No es que los culpe."


translate english a6131_38917f44:


    "En su lugar, probablemente habría tenido la misma reacción."


translate english a6131_0c196bf1:


    "Y Miyuki no me ha hablado desde entonces."


translate english a6131_902916c4:


    "Ha vuelto a ser la abeja reina, tal como era antes de conocer a Aoi."


translate english a6131_3673b91e:



    voice "voice/a61/3100070a01.opus"
    mx "\"\"............\"\""


translate english a6131_b9d37f96:


    "Estoy seguro de ello."


translate english a6131_8558e7b8:


    "Mientras tanto, en cuanto a Yuutarou—"


translate english a6131_7734bf17:



    voice "voice/a61/3100080b01.opus"
    xtl "\"Big news, Shinichi!\""


translate english a6131_5fe1d66e:


    xy "\"...What is it this time?\""


translate english a6131_6c086f90:



    voice "voice/a61/3100090b01.opus"
    xtl "\"I found a dirty magazine in my older cousin's desk!\""


translate english a6131_fdbfe6c0:



    voice "voice/a61/3100100b01.opus"
    xtl "\"It says 'Adults Only' on the cover! Surely it must be an artifact of male ambition!\""


translate english a6131_e35787b6:


    xy "\"But you can tell from the cover art that it's—\""


translate english a6131_d966e6f5:



    voice "voice/a61/3100110b01.opus"
    xtl "\"Too chicken, Private Shinichi?\""


translate english a6131_752608f8:


    xy "\"I wouldn't say that, but... It's pretty obvious the content of her little book isn't het—\""


translate english a6131_1718047a:



    voice "voice/a61/3100120b01.opus"
    xtl "\"It matters not! For the sake of boys and dreams everywhere, I must take the plunge!!!\""


translate english a6131_e0715a54:



    voice "voice/a61/3100130b01.opus"
    xtl "\"............\""


translate english a6131_1479ad2d:


    "Yuutarou se queda helado, con los ojos pegados a las páginas."


translate english a6131_406344ae:


    xy "\"Yuutarou?\""


translate english a6131_4334c755:



    voice "voice/a61/3100140b01.opus"
    xtl "\"I... I... I—\""


translate english a6131_80505e8c:



    voice "voice/a61/3100150b01.opus"
    xtl "\"I'VE BEEN BETRAAAAYED!!!\""


translate english a6131_dd836ef5:


    "—sigue siendo el intrépido capitán del Club BD."


translate english a6131_d3d853f0:


    "No deja que ningún contratiempo le impida seguir adelante en busca del próximo gran sueño."


translate english a6131_bcb8ff77:


    "...Aunque, sinceramente, desearía que dejara de exagerar sus payasadas solo por mí."


translate english a6131_db7735d6:


    "En cuanto a su hermano Ryuujirou, me dicen que él y su nueva novia rompieron de repente."


translate english a6131_5c5b9e6b:


    "¿Que si volverá a intentar algo con Yuutarou?"


translate english a6131_0bff1745:


    "Hasta donde sé, no hay de qué preocuparse. Me dicen que su exnovia le abrió los ojos a las delicias del bello sexo."


translate english a6131_979d4ebd:


    "Y con la ayuda de su buena apariencia, ha logrado convertirse en todo un galán, o eso dicen los rumores."


translate english a6131_4bdd1ebe:


    "Eso es... mejor que estar enamorado de tu propio hermano, supongo."


translate english a6131_efacfe34:


    "Y en cuanto a mí, bueno—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
