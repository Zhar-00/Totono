

translate english c4153_26f0e5a8:


    xy "\"...Oye, ¿Eru?\""


translate english c4153_71c9f2a6:


    xy "\"Me acostumbraré con el tiempo, ¿verdad?\""


translate english c4153_578e139c:


    "Pero el gatito de Aoi solo lame su leche en silencio."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
