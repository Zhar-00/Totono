

translate english a7212b_eb8449fd:



    voice "voice/a72/12b00010a01.opus"
    mx "\"Now... will you fuck me again?\""


translate english a7212b_cb10ae1b:


    xy "\"Again?\""


translate english a7212b_2092190c:



    voice "voice/a72/12b00020a01.opus"
    mx "\"Never mind. Forget I said that.\""


translate english a7212b_761e4389:



    voice "voice/a72/12b00030a01.opus"
    mx "\"Just fill me with your seed...\""


translate english a7212b_240c3e06:


    "A su petición, pongo una mano alrededor de mi verga y la guío hasta su entrada."


translate english a7212b_9d12c7f0:


    "Luego empujo dentro de ella—"


translate english a7212b_e3a6fb30:



    voice "voice/a72/12b00040a01.opus"
    mx "\"Relax, Shinichi.\""


translate english a7212b_7fe1cf16:


    xy "\"Huh...?\""


translate english a7212b_89921715:



    voice "voice/a72/12b00050a01.opus"
    mx "\"Up a little.\""


translate english a7212b_37d57c14:


    xy "\"O-Oh... Okay...\""


translate english a7212b_ded70f83:


    "De todas las veces para arruinarlo... Qué incómodo..."


translate english a7212b_5b140b07:



    voice "voice/a72/12b00060a01.opus"
    mx "\"Nervous, huh?\""


translate english a7212b_e45d2154:


    xy "\"Well, yeah, of course...\""


translate english a7212b_fa232307:



    voice "voice/a72/12b00070a01.opus"
    mx "\"Kiss me.\""


translate english a7212b_47d6c517:


    "Su susurro me seduce."


translate english a7212b_59aa12d3:



    voice "voice/a72/12b00080a01.opus"
    mx "\"Kiss me, and I'll make it all better.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
