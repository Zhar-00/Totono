

translate english e2154a_8303808d:


    xy "\"Sí, me daría rabia.\""


translate english e2154a_cc68eabd:


    "Nuestro tiempo juntos es especial."


translate english e2154a_e0302244:


    "No quiero que nadie más lo invada."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
