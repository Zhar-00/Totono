

translate english c6181_ea326692:


    "El elevador se detiene, y las puertas se abren."


translate english c6181_700772d1:


    "El pasillo está silencioso y vacío de vida, salvo por nosotros."


translate english c6181_6ea61bff:


    "Avanzamos sigilosamente por el pasillo, con cuidado de no hacer ruido."


translate english c6181_965c273c:


    "Entonces Yuutarou se detiene frente a una puerta."


translate english c6181_480e7b5d:


    "Departamento 804."


translate english c6181_b98f4335:



    voice "voice/c61/8100010b01.opus"
    xtl "\"Tú lleva la delantera de aquí en adelante.\""


translate english c6181_6865e322:


    "La llave de la puerta cuelga de su dedo."


translate english c6181_9b817a49:



    voice "voice/c61/8100020a01.opus"
    mx "\"Escucha con mucha atención, Shinichi.\""


translate english c6181_90a130e3:



    voice "voice/c61/8100030a01.opus"
    mx "\"Todavía no es tarde. Aún podemos volver.\""


translate english c6181_73078ccf:



    voice "voice/c61/8100040a01.opus"
    mx "\"Así que... ¿Estás seguro de que esto es lo que quieres?\""


translate english c6181_a32c14fa:


    "Quería creer en Aoi."


translate english c6181_41c8bbc9:


    "Sus palabras..."


translate english c6181_99cc1052:


    "Sus lágrimas..."


translate english c6181_cfc404eb:


    "Diablos, todavía estoy desesperado por creerle ahora."


translate english c6181_2c3b4ad2:


    "Pero Miyuki tiene razón."


translate english c6181_4a749906:


    "Soy un tipo celoso."


translate english c6181_69ce39b9:


    "Me niego a dejar que la mujer que amo me engañe con otro."


translate english c6181_256d54ec:


    "Tomo la llave de Yuutarou."


translate english c6181_b8cc172d:


    "Está fría y pesada, y se clava en mi piel."


translate english c6181_fa98bdc8:


    "Mi mano tiembla."


translate english c6181_47a519b5:


    "Pero ya no hay vuelta atrás."


translate english c6181_c3325e25:


    "Sin importar lo que me espere tras esta puerta—"


translate english c6181_214825c2:


    "Ya sea que pueda o no aceptar la realidad que encuentre allí—"


translate english c6181_6e39d2df:


    "Depositando todas mis esperanzas y miedos en la llave, la meto en la cerradura."


translate english c6181_c08abedf:


    "Lenta y silenciosamente, giro la llave."


translate english c6181_4ff25a9b:


    "Lenta y silenciosamente, la cerradura se abre."


translate english c6181_12e64a21:


    xy "\"......\""


translate english c6181_c2388dd4:


    "Entramos en silencio al departamento."


translate english c6181_56b9ce43:


    "El más leve roce de nuestros pasos suena ensordecedor."


translate english c6181_32d5b510:


    "Aguanto la respiración, me agarro el pecho y dejo que mis pies me lleven hacia adelante—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
