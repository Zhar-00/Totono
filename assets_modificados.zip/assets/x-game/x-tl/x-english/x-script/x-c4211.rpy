

translate english c4211_03944c99:


    "Encuentro a Eru sentado afuera de la entrada del edificio."


translate english c4211_d4522b8d:


    "Estoy genuinamente impresionado de que la bolita de pelo haya llegado hasta aquí con esas patitas diminutas."


translate english c4211_10c611d8:


    "Mientras levanto al gatito en mis brazos, sus bigotes se erizan."


translate english c4211_e6ef000b:


    xy "\"Aoi te está llamando, ¿no?\""


translate english c4211_60e01a68:


    xy "\"Déjame adivinar... ¿Por aquí?\""


translate english c4211_e8732b30:


    "Eru maúlla en respuesta, como si hubiera entendido mi pregunta."


translate english c4211_cd269f53:


    "Mis pies me llevan hacia adelante, sin vacilar."


translate english c4211_c3484f50:


    "No he visto a Aoi desde hace días."


translate english c4211_cfcefb35:


    "De algún modo, mi transmisión simplemente no lograba llegar hasta ella."


translate english c4211_f0cca61b:


    "Nuestra conexión es tenue en el mejor de los casos... pero al menos existe."


translate english c4211_540e4f5d:


    "¿Es esto el destino? O..."


translate english c4211_d0e80274:


    xy "\"¿Está aquí?\""


translate english c4211_960f3f8f:


    "La respuesta es obvia."


translate english c4211_a83657c9:


    "Después de todo, la puerta peatonal está abierta."


translate english c4211_21b7d871:


    "Y ella es la única que sabe cómo forzarla."


translate english c4211_76a7f8aa:


    "Y como en aquel día fatídico, y en efecto—"


translate english c4211_9cbb3ca5:


    "—la azotea también está abierta."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
