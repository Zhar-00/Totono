

translate english e2315_1855d132:


    "Una vez que relleno el azucarero con su contenido..."


translate english e2315_6b493189:


    "Recojo una buena cucharada y la espolvoreo por todas las fresas."


translate english e2315_61272533:


    xy "\"¡Ya, listo!\""


translate english e2315_b537fe01:



    voice "voice/e23/1500010a01.opus"
    mx "\"¿Shinichi? ¿Cuánto falta?\""


translate english e2315_eabc8ed9:



    voice "voice/e23/1500020a01.opus"
    mx "\"¡Casi termino de comer!\""


translate english e2315_c0eb7dcf:


    xy "\"Ya sé, ya sé... ¡Voy!\""


translate english e2315_295b06c4:


    "Agarro el tazón de fresas con crema y se lo llevo."


translate english e2315_9dac2abe:


    xy "\"Perdón por tardar. Aquí está tu postre.\""


translate english e2315_38e218c0:



    voice "voice/e23/1500030a01.opus"
    mx "\"¡Oh, guau! ¿Hiciste esto solo para mí?\""


translate english e2315_998cc006:


    xy "\"Es tu favorito, ¿verdad?\""


translate english e2315_81dc0b95:



    voice "voice/e23/1500040a01.opus"
    mx "\"¡Sí! ¡Me encanta!\""


translate english e2315_c6004476:



    voice "voice/e23/1500050a01.opus"
    mx "\"Shinichi... Gracias por todo lo que has hecho hoy.\""


translate english e2315_a6c71530:


    xy "\"De nada.\""


translate english e2315_114d6c45:



    voice "voice/e23/1500060a01.opus"
    mx "\"Ahora entonces... Hora de hincarle el diente.\""


translate english e2315_f5f33383:


    "Debe gustarle mucho esa cosa."


translate english e2315_e3874422:


    "Ni siquiera ha terminado su plato principal, y ya ha pasado al postre."


translate english e2315_04fe1de6:



    voice "voice/e23/1500070a01.opus"
    mx "\"Ñam... mm-mmm...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
