

translate english e2315_1855d132:


    "Una vez que relleno el azucarero con su contenido..."


translate english e2315_6b493189:


    "Recojo una buena cucharada y la espolvoreo por todas las fresas."


translate english e2315_61272533:


    xy "\"There, all done!\""


translate english e2315_b537fe01:



    voice "voice/e23/1500010a01.opus"
    mx "\"Shinichi? How much longer?\""


translate english e2315_eabc8ed9:



    voice "voice/e23/1500020a01.opus"
    mx "\"I'm almost done eating!\""


translate english e2315_c0eb7dcf:


    xy "\"I know, I know... Coming!\""


translate english e2315_295b06c4:


    "Agarro el tazón de fresas con crema y se lo llevo."


translate english e2315_9dac2abe:


    xy "\"Sorry I took so long. Here's your dessert.\""


translate english e2315_38e218c0:



    voice "voice/e23/1500030a01.opus"
    mx "\"Oh, wow! Did you make this just for me?\""


translate english e2315_998cc006:


    xy "\"It's your favorite, right?\""


translate english e2315_81dc0b95:



    voice "voice/e23/1500040a01.opus"
    mx "\"Yes! I love it!\""


translate english e2315_c6004476:



    voice "voice/e23/1500050a01.opus"
    mx "\"Shinichi... Thank you for everything you've done today.\""


translate english e2315_a6c71530:


    xy "\"You're very welcome.\""


translate english e2315_114d6c45:



    voice "voice/e23/1500060a01.opus"
    mx "\"Now then... Time to dig in.\""


translate english e2315_f5f33383:


    "Debe gustarle mucho esa cosa."


translate english e2315_e3874422:


    "Ni siquiera ha terminado su plato principal, y ya ha pasado al postre."


translate english e2315_04fe1de6:



    voice "voice/e23/1500070a01.opus"
    mx "\"Nom... mm-mmm...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
