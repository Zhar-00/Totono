

translate english e2122c_0dda3a7d:



    voice "voice/e21/22c00010a01.opus"
    mx "\"Nunca me cansaré de esto.\""



translate english e2122c_f398c56e:


    xy "\"¿Ah, sí?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
