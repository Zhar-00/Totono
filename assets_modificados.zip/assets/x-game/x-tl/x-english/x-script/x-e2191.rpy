

translate english e2191_e5cad6fe:



    voice "voice/e21/9100010a01.opus"
    mx "\"Jejeje... Jejeje...\""


translate english e2191_e1cee9c8:


    "Miyuki parece estar de un humor terriblemente bueno..."


translate english e2191_dc04b3be:


    xy "\"¿Pasó algo genial?\""


translate english e2191_95514352:



    voice "voice/e21/9100020a01.opus"
    mx "\"Jeje... Pues, verás... Entré a una rifa el otro día, y...\""


translate english e2191_86b1ccbb:



    voice "voice/e21/9100030a01.opus"
    mx "\"¡Gané dos boletos para ir de viaje!\""


translate english e2191_76d4eeb2:


    xy "\"¿Qué tipo de viaje?\""


translate english e2191_70aba8e6:



    voice "voice/e21/9100040a01.opus"
    mx "\"¡Un viaje a las aguas termales! ¿Quieres venir con—\""


translate english e2191_c4f94319:



    voice "voice/e21/9100050a01.opus"
    mx "\"¡Gané ese horno de agua que quería!\""


translate english e2191_c1b68fe8:


    xy "\"¿Qué es un horno de agua?\""


translate english e2191_70a086d9:



    voice "voice/e21/9100060a01.opus"
    mx "\"Es un horno que usa vapor en vez de fuego para cocinar—\""


translate english e2191_bde5d0b2:



    voice "voice/e21/9100070a01.opus"
    mx "\"¡Gané boletos para una función de cine anticipada!\""


translate english e2191_f398c56e:


    xy "\"¿Ah, sí?\""


translate english e2191_9eb96d2f:



    voice "voice/e21/9100080a01.opus"
    mx "\"Hay un encuentro después, y mi actor favorito es—\""


translate english e2191_4ac4ee27:


    xy "\"Espera...\""


translate english e2191_c064bce8:



    voice "voice/e21/9100090a01.opus"
    mx "\"¿Hmm? ¿Pasa algo...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
