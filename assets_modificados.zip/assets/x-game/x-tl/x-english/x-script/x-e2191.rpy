

translate english e2191_e5cad6fe:



    voice "voice/e21/9100010a01.opus"
    mx "\"Hmhmhm... Hehehe...\""


translate english e2191_e1cee9c8:


    "Miyuki parece estar de un humor terriblemente bueno..."


translate english e2191_dc04b3be:


    xy "\"Something cool happen?\""


translate english e2191_95514352:



    voice "voice/e21/9100020a01.opus"
    mx "\"Hehe... Well, you see... I entered into a raffle the other day, and...\""


translate english e2191_86b1ccbb:



    voice "voice/e21/9100030a01.opus"
    mx "\"I won two tickets to go on a trip!\""


translate english e2191_76d4eeb2:


    xy "\"What sort of trip?\""


translate english e2191_70aba8e6:



    voice "voice/e21/9100040a01.opus"
    mx "\"A trip to the hot springs! Wanna come with—\""


translate english e2191_c4f94319:



    voice "voice/e21/9100050a01.opus"
    mx "\"I won that water oven I've been wanting!\""


translate english e2191_c1b68fe8:


    xy "\"What's a water oven?\""


translate english e2191_70a086d9:



    voice "voice/e21/9100060a01.opus"
    mx "\"It's an oven that uses steam instead of fire to cook—\""


translate english e2191_bde5d0b2:



    voice "voice/e21/9100070a01.opus"
    mx "\"I won tickets to an advance movie screening!\""


translate english e2191_f398c56e:


    xy "\"Oh yeah?\""


translate english e2191_9eb96d2f:



    voice "voice/e21/9100080a01.opus"
    mx "\"There's a meet-and-greet afterwards, and my favorite actor is—\""


translate english e2191_4ac4ee27:


    xy "\"Wait...\""


translate english e2191_c064bce8:



    voice "voice/e21/9100090a01.opus"
    mx "\"Hmm? Is something wrong...?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
