

translate english d6172_7f74f381:


    xy "\"Yeah, and?\""


translate english d6172_d101e1a5:


    xy "\"So what if Haru-chan is Ryuujirou?\""


translate english d6172_bed5a580:



    voice "voice/d61/7200010a01.opus"
    mx "\"I had my suspicions when Haru-chan didn't show up to help out backstage like we agreed.\""


translate english d6172_046cb010:



    voice "voice/d61/7200020a01.opus"
    mx "\"Sure enough, it turns out Aoi and Haru-chan left the store together.\""


translate english d6172_91f51038:


    "...¿Qué?"


translate english d6172_14ed41b1:


    "¿De qué está hablando?"


translate english d6172_b41fd282:


    "No entiendo."


translate english d6172_cd30d3df:


    xy "\"There must be some mistake.\""


translate english d6172_e3133774:



    voice "voice/d61/7200030b01.opus"
    xtl "\"I was working the register, dude. I saw them.\""


translate english d6172_e05914fd:



    voice "voice/d61/7200040b01.opus"
    xtl "\"They stumbled right on out the door together.\""


translate english d6172_4203631e:


    xy "\"But Aoi's at my house!\""


translate english d6172_f34fb92a:


    "...No, no lo es."


translate english d6172_e57b7738:


    "Intenté llamarla, y no contestó."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
