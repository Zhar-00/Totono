

translate english d6172_7f74f381:


    xy "\"Sí, ¿y?\""


translate english d6172_d101e1a5:


    xy "\"¿Y qué si Haru-chan es Ryuujirou?\""


translate english d6172_bed5a580:



    voice "voice/d61/7200010a01.opus"
    mx "\"Tuve mis sospechas cuando Haru-chan no apareció a ayudar tras bambalinas como acordamos.\""


translate english d6172_046cb010:



    voice "voice/d61/7200020a01.opus"
    mx "\"Y efectivamente, resulta que Aoi y Haru-chan salieron juntas de la tienda.\""


translate english d6172_91f51038:


    "...¿Qué?"


translate english d6172_14ed41b1:


    "¿De qué está hablando?"


translate english d6172_b41fd282:


    "No entiendo."


translate english d6172_cd30d3df:


    xy "\"Debe haber algún error.\""


translate english d6172_e3133774:



    voice "voice/d61/7200030b01.opus"
    xtl "\"Estaba en la caja, amigo. Las vi.\""


translate english d6172_e05914fd:



    voice "voice/d61/7200040b01.opus"
    xtl "\"Salieron tambaleándose por la puerta, juntas.\""


translate english d6172_4203631e:


    xy "\"¡Pero Aoi está en mi casa!\""


translate english d6172_f34fb92a:


    "...No, no lo es."


translate english d6172_e57b7738:


    "Intenté llamarla, y no contestó."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
