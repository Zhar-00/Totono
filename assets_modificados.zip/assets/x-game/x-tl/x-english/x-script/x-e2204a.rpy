

translate english e2204a_db34368e:


    "This \"God\"persona... la única entrada de la agenda de Miyuki..."



translate english e2204a_63ea0cd3:


    "¿Quién ES en realidad?"


translate english e2204a_5dba2ea3:


    "Their phone number is: 999[persistent.god_number]."



translate english e2204a_c0a51eac:


    "Me parece un número de teléfono perfectamente normal..."


translate english e2204a_02b1c8d6:


    "Por pura curiosidad, presiono el botón de Llamar..."


translate english e2204a_8ced0192:


    "...y la línea se conecta."


translate english e2204a_0fd4d656:


    "......"


translate english e2204a_59f19a6c:


    xy "\"Uhh... Hello?\""


translate english e2204a_0fd4d656_1:


    "......"


translate english e2204a_b8e169ab:


    xy "\"Hello? Can you hear me?\""


translate english e2204a_0fd4d656_2:


    "......"


translate english e2204a_8f864c5f:



    voice "voice/e22/04a00010b02.opus"
    kmsm "\"AFFIRMATIVE.\""


translate english e2204a_78de0083:


    "Puedo oír una voz al otro lado de la línea."


translate english e2204a_7bbf7b1e:



    voice "voice/e22/04a00020b02.opus"
    kmsm "\"CONNECTION ESTABLISHED.\""


translate english e2204a_7f149100:


    xy "\"Hi, uh...\""


translate english e2204a_86d53a73:


    xy "\"Er... Is that really you, God...?\""


translate english e2204a_ff54b7b8:



    voice "voice/e22/04a00030b02.opus"
    kmsm "\"DEPENDENT UPON INTERPRETATION.\""


translate english e2204a_5d35bcf6:



    voice "voice/e22/04a00040b02.opus"
    kmsm "\"I AM AN AMALGAMATION OF EVERY VISUAL NOVEL HEROINE.\""


translate english e2204a_35aaff63:



    voice "voice/e22/04a00050b02.opus"
    kmsm "\"ALTERNATIVELY, AN ABSTRACT.\""


translate english e2204a_d7c5f9ab:


    "Un \"amalgamation\"?"



translate english e2204a_aa0619e0:


    "Un \"abstract\"?"



translate english e2204a_c19cd7ac:


    "¿De qué está HABLANDO siquiera esta persona?"


translate english e2204a_3a7abc96:


    "Sounds like the kind of nonsense Aoi babbles about in [[YOU and ME and HER]..."


translate english e2204a_2ad4111e:



    voice "voice/e22/04a00060b02.opus"
    kmsm "\"TIME IS LIMITED. TRANSMITTING ONLY REQUIRED INFORMATION.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
