

translate english e1156b_b2e7a1e5:


    "...¿Buscar a Aoi?"


translate english e1156b_2c970423:


    "Eso no puede ser."


translate english e1156b_20fe44ba:


    "¡Aoi es un personaje de videojuego!"


translate english e1156b_2f1483fb:


    "¡No hay forma de que exista en la vida real!"


translate english e1156b_39b7b728:


    "Supongo que podría ir a buscar una figura de Aoi, o una funda de almohada de Aoi..."


translate english e1156b_32559a44:


    "Y como Miyuki se ha ido, esta es mi única oportunidad de conseguir algo de mercancía..."


translate english e1156b_63c0f50d:


    "Pero eso no es importante ahora mismo."


translate english e1156b_d9f92652:


    "No, mi prioridad principal es—"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
