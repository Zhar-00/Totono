

translate english e1112e_b748aae9:



    voice "voice/e11/12e00010a01.opus"
    mx "\"Me lo prometiste, ¿recuerdas?\""


translate english e1112e_1a4a918c:



    voice "voice/e11/12e00020a01.opus"
    mx "\"Lo que significa que tienes que hacer exactamente lo que te digo.\""


translate english e1112e_a7a35dbc:



    voice "voice/e11/12e00030a01.opus"
    mx "\"¡Serás más feliz así!\""


translate english e1112e_763bfb71:



    voice "voice/e11/12e00040a01.opus"
    mx "\"¿No lo crees?\""


translate english e1112e_f09256ab:



    voice "voice/e11/12e00050a01.opus"
    mx "\"Te lo ruego... Por favor, no mires a ninguna otra mujer.\""


translate english e1112e_f4397b1d:


    "Esquivando la pregunta, tomo un sorbo de su sopa de miso casera."


translate english e1112e_5f7335ab:


    "Justo entonces, un telón oscuro cae sobre mis ojos."


translate english e1112e_a7de114f:


    "¿Es esto... mi cabello...?"


translate english e1112e_e171802a:


    "No recuerdo haberlo dejado crecer tanto..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
