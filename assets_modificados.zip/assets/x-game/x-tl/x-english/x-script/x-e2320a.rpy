

translate english e2320a_0f1b9ab1:


    "No estoy tan desesperado... y sin embargo..."


translate english e2320a_6f57c2a6:


    "Por alguna razón, mi cuerpo parece tener voluntad propia..."


translate english e2320a_f2af8d91:


    "Toco la pantalla."


translate english e2320a_8f14d347:


    "—Responde las siguientes 10 preguntas de opción múltiple."


translate english e2320a_f042151a:


    "—Advertencia: 3 intentos fallidos provocarán un bloqueo automático de 24 horas."


translate english e2320a_ccb7eb72:


    "...Parece que solo puedo equivocarme dos veces."


translate english e2320a_631131ff:


    "Tras leer con cuidado las instrucciones, paso a resolver las preguntas."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
