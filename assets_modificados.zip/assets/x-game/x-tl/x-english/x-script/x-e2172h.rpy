

translate english e2172h_da494787:


    "\"Cooking 101.\""



translate english e2172h_f3bd0eca:



    voice "voice/e21/72h00010a01.opus"
    mx "\"That's your seventh copy...\""


translate english e2172h_4c3db245:



    voice "voice/e21/72h00020a01.opus"
    mx "\"Now you'll have one for every day of the week.\""


translate english e2172h_f4a23df9:


    xy "\"Why would I do that? That makes no sense...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
