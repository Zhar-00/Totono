

translate english e2172h_da494787:


    "\"Cocina para principiantes.\""



translate english e2172h_f3bd0eca:



    voice "voice/e21/72h00010a01.opus"
    mx "\"Esa es tu séptima copia...\""


translate english e2172h_4c3db245:



    voice "voice/e21/72h00020a01.opus"
    mx "\"Ahora tendrás uno para cada día de la semana.\""


translate english e2172h_f4a23df9:


    xy "\"¿Por qué haría eso? No tiene sentido...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
