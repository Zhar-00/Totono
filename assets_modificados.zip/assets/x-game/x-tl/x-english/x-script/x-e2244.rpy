

translate english e2244_a64a2b49:


    "Hojeo una pila de volantes y cupones."


translate english e2244_ccdbd8af:


    "Sushi... Pizza... Comida china..."


translate english e2244_36a9a6b0:


    "De estos, Miyuki probablemente preferiría—"


translate english e2244_00c6537b:


    xy "\"Guess I'll order sushi, then?\""


translate english e2244_0b719bb0:


    xy "\"You said you haven't quite got the hang of making it at home, right?\""


translate english e2244_41022ad1:


    xy "\"Guess I'll order pizza, then?\""


translate english e2244_0b719bb0_1:


    xy "\"You said you haven't quite got the hang of making it at home, right?\""


translate english e2244_40d0b8a2:


    xy "\"Guess I'll order Chinese, then?\""


translate english e2244_0b719bb0_2:


    xy "\"You said you haven't quite got the hang of making it at home, right?\""


translate english e2244_29d8d7b9:



    voice "voice/e22/4400010a01.opus"
    mx "\"Aww, you remembered...!\""


translate english e2244_f424c14f:



    voice "voice/e22/4400020a01.opus"
    mx "\"That's an even better gift than the takeout!\""


translate english e2244_5eacade5:


    "Miyuki irradia alegría."


translate english e2244_3a2bece6:


    "Esa sonrisa hace que pedir comida para llevar valga totalmente la pena..."


translate english e2244_e01f1742:


    "Sintiéndome satisfecho, llamo al restaurante..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
