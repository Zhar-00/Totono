

translate english e2244_a64a2b49:


    "Hojeo una pila de volantes y cupones."


translate english e2244_ccdbd8af:


    "Sushi... Pizza... Comida china..."


translate english e2244_36a9a6b0:


    "De estos, Miyuki probablemente preferiría—"


translate english e2244_00c6537b:


    xy "\"¿Entonces pediré sushi, supongo?\""


translate english e2244_0b719bb0:


    xy "\"Dijiste que aún no le agarras bien la mano a hacerlo en casa, ¿verdad?\""


translate english e2244_41022ad1:


    xy "\"¿Entonces pediré pizza, supongo?\""


translate english e2244_0b719bb0_1:


    xy "\"Dijiste que aún no le agarras bien la mano a hacerlo en casa, ¿verdad?\""


translate english e2244_40d0b8a2:


    xy "\"¿Entonces pediré comida china, supongo?\""


translate english e2244_0b719bb0_2:


    xy "\"Dijiste que aún no le agarras bien la mano a hacerlo en casa, ¿verdad?\""


translate english e2244_29d8d7b9:



    voice "voice/e22/4400010a01.opus"
    mx "\"¡Ay, te acordaste...!\""


translate english e2244_f424c14f:



    voice "voice/e22/4400020a01.opus"
    mx "\"¡Eso es un regalo aún mejor que la comida para llevar!\""


translate english e2244_5eacade5:


    "Miyuki irradia alegría."


translate english e2244_3a2bece6:


    "Esa sonrisa hace que pedir comida para llevar valga totalmente la pena..."


translate english e2244_e01f1742:


    "Sintiéndome satisfecho, llamo al restaurante..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
