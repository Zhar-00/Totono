

translate english a9122a_4b153607:


    xy "\"Just what I deserve, don't you think?\""


translate english a9122a_39d89133:


    "Murmuro hacia la foto de aquel día."


translate english a9122a_4cbb8822:


    "Ni qué decir tiene que no me responde."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
