

translate english a2152_3d828df4:


    "Por fin, Aoi y Miyuki son oficialmente amigas."


translate english a2152_a90574f1:


    "No es que haya ayudado mucho."


translate english a2152_a5f4d12e:


    "Aun así, siento un profundo orgullo por su logro."


translate english a2152_d49cf70a:


    "Se siente como si hubiera dado otro paso adelante."


translate english a2152_e2a2d8e1:


    "Un paso pequeño, pero un paso al fin y al cabo."


translate english a2152_3743f06e:


    xy "\"Friends, huh?\""


translate english a2152_e354eb04:


    "Mis dedos vagan sin pensar por la pantalla de mi teléfono, y antes de que me dé cuenta, he abierto la entrada de Miyuki en mi agenda."


translate english a2152_fe98659d:


    "Antes de conocer a Aoi, nunca habría imaginado que algo así pasara."


translate english a2152_a60ce7b7:


    "Pero ahora, con un toque de botón, puedo contactar a Miyuki cuando quiera."


translate english a2152_0f4c500b:


    "Y así, estamos a mundos de distancia menos. El tiempo y la distancia son irrelevantes ahora."


translate english a2152_d250e596:


    xy "\"No, that's stupid.\""


translate english a2152_5f9b4ef1:


    "Me estoy engañando."


translate english a2152_fa97648b:


    "Es solo una entrada en una agenda. Datos sin significado. Unos y ceros."


translate english a2152_b2001964:


    "La distancia emocional entre nosotros no ha cambiado."


translate english a2152_865d5610:


    "Estoy seguro de que Miyuki lo sabe tan bien como yo."


translate english a2152_7d3f9020:


    "Eso me recuerda... que todavía no he recibido esa foto de Aoi."


translate english a2152_343031d2:


    "¿Se olvidó de enviarla?"


translate english a2152_4ec8c48a:


    "¿O su teléfono sigue sin servicio?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
