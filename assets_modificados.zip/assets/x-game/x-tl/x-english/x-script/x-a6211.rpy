

translate english a6211_ce23bc68:


    "El telón se levanta entre fuertes aplausos."


translate english a6211_e1888f24:


    "En el escenario, Miyuki de repente empieza a batear."


translate english a6211_0265c047:


    "En el silencioso auditorio, lo único que se oye es el sonido de su bate cortando el aire."


translate english a6211_a4b913c1:


    "Su swing es impecable."


translate english a6211_e9fb500e:


    "No habla, pero sus acciones hablan por ella, captando la atención del público."


translate english a6211_7dadf682:


    "Pero todo esto es pan comido para Miyuki."


translate english a6211_9252b1cf:


    "Aquí entre el público, mis ojos están pegados a ella."


translate english a6211_c52c18af:


    "Su voz resuena en mis oídos."


translate english a6211_70a783a4:


    "Sus palabras se filtran hasta mi alma."


translate english a6211_a434ffd3:


    "Cada uno de sus movimientos capta perfectamente mi atención."


translate english a6211_c6c091e8:


    "Cada pequeño gesto me cautiva."


translate english a6211_640871bc:


    "Y sus labios—"


translate english a6211_7ae7afae:


    "Cuanto más la observo, más ansioso me pongo."


translate english a6211_f9c24a3f:


    "A estas alturas, ya ni puedo seguir la trama."


translate english a6211_28f1d27e:


    "Algo sobre un jugador de béisbol que cubre un puesto en el equipo de softbol femenil."


translate english a6211_ae7c579d:


    "En el momento en que el actor entra en mi campo de visión, siento náuseas."


translate english a6211_3738f8e8:


    "Me tienta saltar del asiento y salir disparado hacia la puerta."


translate english a6211_dbd42415:


    "Quiero desaparecer."


translate english a6211_abc62cd5:


    "Pero mi cuerpo no se mueve."


translate english a6211_898b95b1:


    "Entonces llega la escena final culminante."


translate english a6211_cb9227b3:


    "No puedo soportarlo."


translate english a6211_4fc75e81:


    "Simplemente no tengo fuerzas."


translate english a6211_25c0f788:


    "Quiero salir de aquí."


translate english a6211_bddd9d70:


    "Necesito irme."


translate english a6211_aa6add2a:


    "Ahora."


translate english a6211_2c0db05f:


    "No quiero tener que ver esto."


translate english a6211_76e80e37:


    "No me importa si todo el público se ríe de mí."


translate english a6211_f7ef6458:


    "Mi pecho siente que va a explotar."


translate english a6211_1ee9e9c0:


    "No puedo soportar esta agonía—"


translate english a6211_a14b8e9a:



    voice "voice/a62/1100010a01.opus"
    mx "\"—¡Shinichi!\""


translate english a6211_14ea5d4a:


    xy "\"¿Eh...?\""


translate english a6211_fad3ad50:


    "Entonces me doy cuenta."


translate english a6211_9d172a98:


    "Se supone que Miyuki está actuando ahora mismo."


translate english a6211_e61267a8:


    "Está en medio de su bellamente ejecutada escena del beso."


translate english a6211_89cbc876:


    "Pero mientras los dos se acercan..."


translate english a6211_3e9856a1:


    "Sus labios se tuercen con el más leve indicio de miseria."


translate english a6211_88ebd263:


    "Pero nadie ve el desliz en su impecable actuación..."


translate english a6211_c7090b41:


    "...Nadie excepto yo."


translate english a6211_69542eac:


    xy "\"—!!!\""


translate english a6211_8515c4e5:


    "Ya no me importa la obra."


translate english a6211_f88be2e0:


    "Solo me importa Miyuki."


translate english a6211_990ef6ae:


    "Quiero salvarla de su sufrimiento."


translate english a6211_07f528cf:


    "Y para ello—"


translate english a6211_f72115f0:


    "—tengo que arruinar esta función."


translate english a6211_31d0e7c2:


    "La distancia entre ellos se cierra a cámara lenta."


translate english a6211_ada79e1d:


    "Necesito llamar su nombre—"


translate english a6211_f50e913c:


    "Necesito arruinar la función y salvarla—"


translate english a6211_1231a7c7:


    "Salto de pie en medio del público—{nw=1}"



translate english a6211_ccc53af0:


    "—pero justo antes de que sus labios se encuentren, el escenario se oscurece."


translate english a6211_78118747:


    "Es un apagón."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
