

translate english e1165b_674f651f:



    voice "voice/e11/6500470a01.opus"
    mx "\"Sorry, but...\""


translate english e1165b_fa807dff:



    voice "voice/e11/6500480a01.opus"
    mx "\"This is my only option...\""


translate english e1165b_3a286fdb:



    voice "voice/e11/6500490a01.opus"
    mx "\"This is the only way we can be happy together...\""


translate english e1165b_645bec3f:


    xy "\"Is it?\""


translate english e1165b_41929198:



    voice "voice/e11/6500500a01.opus"
    mx "\"What?\""


translate english e1165b_3a4f9884:


    xy "\"Is this happiness to you?\""


translate english e1165b_721e9ad8:



    voice "voice/e11/6500510a01.opus"
    mx "\"Of course it is! I mean—\""


translate english e1165b_bc4d90c3:


    xy "\"Liar.\""


translate english e1165b_3165ce49:


    xy "\"Your acting skills won't work on me.\""


translate english e1165b_15a1fb2a:



    voice "voice/e11/6500520a01.opus"
    mx "\"Shinichi...?\""


translate english e1165b_9226e86b:


    xy "\"Your voice is shaking.\""


translate english e1165b_12bd51e1:



    voice "voice/e11/6500530a01.opus"
    mx "\"No it's not!\""


translate english e1165b_82927617:


    xy "\"Yes it is.\""


translate english e1165b_786da96c:


    "Subo la escalera en silencio."


translate english e1165b_3519710f:


    "Miyuki aparta la mirada."


translate english e1165b_b7ebb484:


    "Camino directo hacia ella."


translate english e1165b_ad54b799:


    "No sé qué creer."


translate english e1165b_52645dbc:


    "No tengo forma de discernir la verdad."


translate english e1165b_f72ead97:


    "Pero hay una cosa que sí sé."


translate english e1165b_3d081812:


    xy "\"Miyuki.\""


translate english e1165b_c61b438d:


    "Paso a paso, me acerco a ella."


translate english e1165b_40c49260:



    voice "voice/e11/6500540a01.opus"
    mx "\"Shinichi...?\""


translate english e1165b_e746fba6:


    "Otro paso. Y otro."


translate english e1165b_42a1a4a0:



    voice "voice/e11/6500550a01.opus"
    mx "\"What are you thinking...?\""


translate english e1165b_5e4a57db:


    "Le ordeno a mi corazón que no lata descontroladamente."


translate english e1165b_0f5861af:



    voice "voice/e11/6500560a01.opus"
    mx "\"Shin...ichi...?\""


translate english e1165b_5282eee2:


    "Con suavidad, la atraigo hacia mí."


translate english e1165b_693ace1c:



    voice "voice/e11/6500570a01.opus"
    mx "\"......Okay.\""


translate english e1165b_9d125bf9:



    voice "voice/e11/6500580a01.opus"
    mx "\"Go ahead.\""


translate english e1165b_c20e60c5:


    "Miyuki cierra los ojos—"


translate english e1165b_fb7302b4:


    "—y le arrebato el teléfono de la mano."


translate english e1165b_69657135:


    xy "\"—!!!\""


translate english e1165b_df9e9bda:


    "¡Hora de salir corriendo!"


translate english e1165b_954be482:


    "¡Rápido, mientras aún tiene los ojos cerrados!"


translate english e1165b_21d45fb1:


    "¡Correré hasta que ya no pueda encontrarme!"


translate english e1165b_12b9c023:


    "Mientras me disculpo internamente con Miyuki—"


translate english e1165b_6618a8da:


    "—bajo las escaleras a toda velocidad."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
