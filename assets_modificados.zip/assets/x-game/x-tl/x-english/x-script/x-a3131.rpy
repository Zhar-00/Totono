

translate english a3131_67bd2659:


    xy "\"¿Hola...?\""


translate english a3131_df4d64db:



    voice "voice/a31/3100010b03.opus"
    c "\"Ah... ¡Yo... perdón, perdón!\""


translate english a3131_bb58c512:


    xy "\"¿Eh?\""


translate english a3131_6d4f65c2:


    "Justo cuando entro por la puerta, recibo una disculpa improvisada de esa chica de primer año."


translate english a3131_0db3e45b:



    voice "voice/a31/3100020b03.opus"
    c "\"¡Yo... te vi venir caminando, y todo fue tan rápido, y me asusté...!\""


translate english a3131_c4efa20c:


    xy "\"¿Hice algo?\""


translate english a3131_7f63f285:



    voice "voice/a31/3100030b03.opus"
    c "\"No, no... emm... En ese momento entré en pánico... ya sabes, que me vieran así... y no sabía qué hacer, así que...!\""


translate english a3131_6dd788ee:



    voice "voice/a31/3100040a02.opus"
    aoi "\"¿Te estaba mirando lascivamente?\""


translate english a3131_59de9cfe:



    voice "voice/a31/3100050b03.opus"
    c "\"¿Eh? No, no...\""


translate english a3131_a3ee6f27:


    xy "\"¡Claro que no! ¿Ves? ¡Ella sabe que no estaba siendo raro!\""


translate english a3131_073457d0:



    voice "voice/a31/3100060a02.opus"
    aoi "\"¿Tal vez simplemente no le gustas?\""


translate english a3131_417f4826:



    voice "voice/a31/3100070b03.opus"
    c "\"¡Eso no es cierto!\""


translate english a3131_7036d5c4:



    voice "voice/a31/3100080a02.opus"
    aoi "\"¿Entonces SÍ te gusta?\""


translate english a3131_951335a2:



    voice "voice/a31/3100090b03.opus"
    c "¡Lo odio! ¡Sí, así es! ¡Lo odio con todo mi ser!\""


translate english a3131_559bc951:


    xy "\"Ehhh...\""


translate english a3131_9375666f:



    voice "voice/a31/3100100b03.opus"
    c "\"¡Oh... em... ehhh...!\""


translate english a3131_03df355b:



    voice "voice/a31/3100110b03.opus"
    c "\"¡¡¡PER... PERDÓN!!!\""


translate english a3131_c0aa753f:


    "Una fracción de segundo después, sale disparada como alma que lleva el diablo."


translate english a3131_38ef0248:



    voice "voice/a31/3100120b03.opus"
    c "\"¡Auch!\""


translate english a3131_65d626f7:



    voice "voice/a31/3100130a02.opus"
    aoi "\"Parece que se cayó.\""


translate english a3131_2d3f8315:


    xy "\"Sí.\""


translate english a3131_6d31a706:



    voice "voice/a31/3100140a02.opus"
    aoi "\"Es una torpe.\""


translate english a3131_cb1b6262:



    voice "voice/a31/3100150a01.opus"
    mx "\"¡OYE! ¿¡Qué están haciendo, molestando a Haru-chan otra vez!?\""


translate english a3131_326eeaba:


    xy "\"¡No la estábamos molestando!\""


translate english a3131_54d7a7e9:


    "Si acaso, ¡estoy bastante seguro de que aquí la víctima soy yo!"


translate english a3131_0c499010:


    xy "\"Vaya... ¿Seguro que una florecita tan delicada como ella puede aguantar estar en una obra?\""


translate english a3131_9603a3e4:



    voice "voice/a31/3100160a01.opus"
    mx "\"De hecho, tiene mucho talento. Y además tiene la belleza.\""


translate english a3131_15c9479b:



    voice "voice/a31/3100170a02.opus"
    aoi "\"Shinichi, solo estás molesto porque te rechazaron.\""


translate english a3131_2514df1d:


    xy "\"¡No puede rechazar una confesión que nunca hice!\""


translate english a3131_ae8afaad:


    "Dicho esto, no me importaría verla actuar alguna vez..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
