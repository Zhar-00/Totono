

translate english a3131_67bd2659:


    xy "\"Hello...?\""


translate english a3131_df4d64db:



    voice "voice/a31/3100010b03.opus"
    c "\"Oh... I... I'm so sorry!\""


translate english a3131_bb58c512:


    xy "\"Huh?\""


translate english a3131_6d4f65c2:


    "Justo cuando entro por la puerta, recibo una disculpa improvisada de esa chica de primer año."


translate english a3131_0db3e45b:



    voice "voice/a31/3100020b03.opus"
    c "\"I... I saw you walking over, and it was all so fast, and I got scared...!\""


translate english a3131_c4efa20c:


    xy "\"Was it something I did?\""


translate english a3131_7f63f285:



    voice "voice/a31/3100030b03.opus"
    c "\"No, no... umm... At the time, I was just so panicked... y'know, being seen like this... and I didn't know what to do, so I...!\""


translate english a3131_6dd788ee:



    voice "voice/a31/3100040a02.opus"
    aoi "\"Was he ogling you?\""


translate english a3131_59de9cfe:



    voice "voice/a31/3100050b03.opus"
    c "\"Huh? No, no...\""


translate english a3131_a3ee6f27:


    xy "\"Of course not! See? She knows I wasn't being creepy!\""


translate english a3131_073457d0:



    voice "voice/a31/3100060a02.opus"
    aoi "\"Maybe she just doesn't like you?\""


translate english a3131_417f4826:



    voice "voice/a31/3100070b03.opus"
    c "\"That's not true!\""


translate english a3131_7036d5c4:



    voice "voice/a31/3100080a02.opus"
    aoi "\"So you DO like him?\""


translate english a3131_951335a2:



    voice "voice/a31/3100090b03.opus"
    c "¡Lo odio! ¡Sí, así es! ¡Lo odio con todo mi ser!\""


translate english a3131_559bc951:


    xy "\"Uhhhh...\""


translate english a3131_9375666f:



    voice "voice/a31/3100100b03.opus"
    c "\"Oh... uh... uhhhh...!\""


translate english a3131_03df355b:



    voice "voice/a31/3100110b03.opus"
    c "\"I... I'M SORRY!!!\""


translate english a3131_c0aa753f:


    "Una fracción de segundo después, sale disparada como alma que lleva el diablo."


translate english a3131_38ef0248:



    voice "voice/a31/3100120b03.opus"
    c "\"Oww!\""


translate english a3131_65d626f7:



    voice "voice/a31/3100130a02.opus"
    aoi "\"Looks like she fell.\""


translate english a3131_2d3f8315:


    xy "\"Yep.\""


translate english a3131_6d31a706:



    voice "voice/a31/3100140a02.opus"
    aoi "\"She's a klutz.\""


translate english a3131_cb1b6262:



    voice "voice/a31/3100150a01.opus"
    mx "\"HEY! What are you doing, picking on Haru-chan again?!\""


translate english a3131_326eeaba:


    xy "\"We weren't picking on her!\""


translate english a3131_54d7a7e9:


    "Si acaso, ¡estoy bastante seguro de que aquí la víctima soy yo!"


translate english a3131_0c499010:


    xy "\"Man... You sure a delicate little flower like her can handle being in a play?\""


translate english a3131_9603a3e4:



    voice "voice/a31/3100160a01.opus"
    mx "\"She's actually really talented. And she's got the looks to boot.\""


translate english a3131_15c9479b:



    voice "voice/a31/3100170a02.opus"
    aoi "\"Shinichi, you're just upset you got turned down.\""


translate english a3131_2514df1d:


    xy "\"She can't turn down a confession I never made!\""


translate english a3131_ae8afaad:


    "Dicho esto, no me importaría verla actuar alguna vez..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
