

translate english a3181_f3a631e5:



    voice "voice/a31/8100010a01.opus"
    mx "\"Aoi, ¿dónde estás?\""


translate english a3181_00fac4c5:


    "La voz de Miyuki resuena y se desvanece en la oscuridad."


translate english a3181_421c3a99:


    "El gimnasio está completamente oscuro."


translate english a3181_5c6ea206:


    "Normalmente no habría ni un alma aquí a esta hora."


translate english a3181_c055c894:


    xy "\"¡Sé que estás aquí, Aoi!\""


translate english a3181_4e5c11ac:



    voice "voice/a31/8100020a02.opus"
    aoi "\"¡Basta!\""


translate english a3181_bbeeefca:


    xy "\"¿Oíste eso?\""


translate english a3181_7f16d825:



    voice "voice/a31/8100030a01.opus"
    mx "\"Sí, definitivamente fue ella.\""


translate english a3181_d3c53b2d:



    voice "voice/a31/8100040a01.opus"
    mx "\"¡Sabemos que estás ahí! ¡Por favor, háblanos!\""


translate english a3181_66683434:


    "...Silencio."


translate english a3181_23e54998:


    "Aoi no responde."


translate english a3181_29e9e3b9:



    voice "voice/a31/8100050a01.opus"
    mx "\"¿Por qué te escondes?\""


translate english a3181_7e9ca391:



    voice "voice/a31/8100060a01.opus"
    mx "\"¡Vamos, Aoi, sal!\""


translate english a3181_496205f9:


    "Miyuki grita hacia la oscuridad."


translate english a3181_9c25eb80:


    "Pero Aoi se niega a responder."


translate english a3181_4bc6ab3e:


    "En vez de eso, lo único que oímos es—"


translate english a3181_d89eb7fd:



    voice "voice/a31/8100070a02.opus"
    aoi "\"...Hnn...\""


translate english a3181_78e6b96e:


    "—un sollozo ahogado."


translate english a3181_8c257ca8:


    "Está llorando."


translate english a3181_2e4a1002:



    voice "voice/a31/8100080a01.opus"
    mx "\"Aoi, ¿qué pasa?\""


translate english a3181_6419b579:



    voice "voice/a31/8100090a02.opus"
    aoi "\"¡Aléjense!\""


translate english a3181_45068d7c:



    voice "voice/a31/8100100a02.opus"
    aoi "\"No... hnn... se acerquen... más...\""


translate english a3181_b1af9fb2:



    voice "voice/a31/8100110a01.opus"
    mx "\"¿Por qué lloras?\""


translate english a3181_4539f64c:



    voice "voice/a31/8100120a02.opus"
    aoi "\"Hnn... nnn... nnnn... A-Aoi... no puede evitarlo... porque...\""


translate english a3181_dc9cbac6:



    voice "voice/a31/8100130a02.opus"
    aoi "\"¡Aoi... no hizo caso...!\""


translate english a3181_aaa42391:



    voice "voice/a31/8100140a01.opus"
    mx "\"¿A qué?\""


translate english a3181_8e64a180:



    voice "voice/a31/8100150a02.opus"
    aoi "\"Miyuki... me dijo que no, pero... Aoi... no dejaba de pensar en eso...\""


translate english a3181_21233ba6:



    voice "voice/a31/8100160a02.opus"
    aoi "\"No podía... abandonar al gatito... Quería... ser una heroína...\""


translate english a3181_80b2430c:



    voice "voice/a31/8100170a02.opus"
    aoi "\"Pero ahora... Miyuki va a... cortar lazos... y a dejar de ser mi amiga...\""


translate english a3181_6e480dfc:


    "Bueno, esa fue definitivamente la amenaza que hizo en su momento..."


translate english a3181_02b587c4:



    voice "voice/a31/8100180a01.opus"
    mx "\"¿Por eso no quiere salir...?\""


translate english a3181_e2c18ffd:


    xy "\"Probablemente.\""


translate english a3181_020b81dc:


    xy "\"Ya te eligió a ti antes que al gatito una vez.\""


translate english a3181_a5b76731:



    voice "voice/a31/8100190a01.opus"
    mx "\"......\""


translate english a3181_d57ef21a:


    xy "\"Vamos, Miyuki.\""


translate english a3181_8a65f361:



    voice "voice/a31/8100200a01.opus"
    mx "\"¡Lo entiendo, está bien!\""


translate english a3181_56af6876:


    "Miyuki suspira con frustración."


translate english a3181_7eb50298:



    voice "voice/a31/8100210a01.opus"
    mx "\"¡Me retracto, ¿sí? ¡Retiro todo!\""


translate english a3181_02dd6317:



    voice "voice/a31/8100220a02.opus"
    aoi "\"Hnn... nnn... ¿Tú... te retractas...?\""


translate english a3181_703b20f7:



    voice "voice/a31/8100230a01.opus"
    mx "\"¡No quiero cortar lazos! ¡Quiero seguir siendo amiga! ¡Ahora por favor sal y háblanos, Aoi!\""


translate english a3181_f077ecd0:



    voice "voice/a31/8100240a02.opus"
    aoi "\"¿Tú... estás segura de que no vas a cortar lazos conmigo?\""


translate english a3181_41b20c6a:


    "La voz vacilante de Aoi atraviesa la oscuridad."


translate english a3181_71dc36a5:



    voice "voice/a31/8100250a02.opus"
    aoi "\"¿Prometes que te retractas?\""


translate english a3181_26d76cf2:



    voice "voice/a31/8100260a01.opus"
    mx "\"¿Por qué otra razón vendría a buscarte a mitad de la noche cuando está diluviando?\""


translate english a3181_1c528da7:



    voice "voice/a31/8100270a01.opus"
    mx "\"No lo haría si no estuviera preocupada por ti. Obviamente.\""


translate english a3181_9f70decb:



    voice "voice/a31/8100280a02.opus"
    aoi "\"¿Lo dices en serio...?\""


translate english a3181_4cb46377:



    voice "voice/a31/8100290a01.opus"
    mx "\"No te mentiría sobre algo así.\""


translate english a3181_23e3fc78:



    voice "voice/a31/8100300a01.opus"
    mx "\"O sea, somos amigas, ¿no?\""


translate english a3181_e6a4c0a5:



    voice "voice/a31/8100310a02.opus"
    aoi "\"Gra... Gra...\""


translate english a3181_aa19fca5:



    voice "voice/a31/8100320a02.opus"
    aoi "\"¡Muchas gracias!\""


translate english a3181_07a4ad56:


    "Aoi sale corriendo de entre bambalinas—"


translate english a3181_5dc38faa:



    voice "voice/a31/8100330a01.opus"
    mx "\"¿¡Mamá gata!?\""


translate english a3181_9bc90938:


    "—llevando su mameluco de gatito."


translate english a3181_8bb76439:



    voice "voice/a31/8100340a02.opus"
    aoi "\"¡Miyuki! ¡Eres la mejor!\""


translate english a3181_71139df0:



    voice "voice/a31/8100350a01.opus"
    mx "\"Gra... Gracias. Solo me alegra que te sientas mejor.\""


translate english a3181_bda7e08b:


    "Puedo oír un pequeño chillido en la voz de Miyuki mientras el abrazo con salto de Aoi amenaza con casi tumbarlas a ambas al suelo."


translate english a3181_bb966e44:


    xy "\"Espera... ¿Dónde está el gatito?\""


translate english a3181_e78ed087:



    voice "voice/a31/8100360a02.opus"
    aoi "\"Aquí.\""


translate english a3181_ab78b333:



    voice "voice/a31/8100370a02.opus"
    aoi "\"Sal, Eru.\""


translate english a3181_8850c6f7:


    "Como si obedeciera una orden, el gatito asoma la cabeza del bolsillo del pecho del mameluco."


translate english a3181_93a9b228:


    "Dios, los niveles de ternura están fuera de serie... Hasta a mí me han hecho sonreír."


translate english a3181_b450ec51:



    voice "voice/a31/8100390a01.opus"
    mx "\"Yo... podría morir feliz...\""


translate english a3181_3fe7eea1:



    voice "voice/a31/8100400a02.opus"
    aoi "\"¡Boop boop! ¿¡Miyuki!?\""


translate english a3181_273e8fa1:


    "Miyuki cae al suelo, con una sonrisa soñadora en el rostro."


translate english a3181_f1687bd9:



    voice "voice/a31/8100410a02.opus"
    aoi "\"Miyuki... Aoi lo siente mucho...\""


translate english a3181_14d8aded:



    voice "voice/a31/8100420a02.opus"
    aoi "\"Eru también lo siente.\""


translate english a3181_2661ec34:



    voice "voice/a31/8100440a01.opus"
    mx "\"¡Basta! ¡Lo entiendo! ¡Ya es suficiente! ¡Basta!\""


translate english a3181_4a09b0fb:



    voice "voice/a31/8100450a01.opus"
    mx "\"¡No se acerquen más! ¡No queremos que se repita lo de la última vez!\""


translate english a3181_fa6a0c86:



    voice "voice/a31/8100460a02.opus"
    aoi "\"¡Pero Eru quiere abrazarte!\""


translate english a3181_1ab54a37:



    voice "voice/a31/8100470a01.opus"
    mx "\"¿¡Abrazarme!? Bueno... ¡supongo que si tengo que hacerlo...!\""


translate english a3181_703b913f:


    xy "\"¿¡Y qué pasó con evitar que se repita lo de la última vez!?\""


translate english a3181_e7806569:



    voice "voice/a31/8100480a01.opus"
    mx "\"¡De todos modos la historia siempre se va a repetir! Shinichi, ¿tienes un cubrebocas?\""


translate english a3181_eeac0900:


    xy "\"¿Por qué tendría uno?\""


translate english a3181_946aaf01:



    voice "voice/a31/8100490a01.opus"
    mx "\"¡¿Por qué NO tendrías?!\""


translate english a3181_d0615571:


    xy "\"¡No me grites!\""


translate english a3181_e1c90e65:


    "Cuando se trata de gatos, lo juro, esta chica deja de pensar con claridad..."


translate english a3181_7ce880d9:


    xy "\"¡Y Aoi, no la animes! ¿¡Y por qué llevas eso puesto!?\""


translate english a3181_cb09b06d:



    voice "voice/a31/8100500a02.opus"
    aoi "\"Bueno, mi ropa se mojó toda.\""


translate english a3181_8c4e9309:


    xy "\"¿Qué pasó con ese paraguas que te di?\""


translate english a3181_a7d2c625:



    voice "voice/a31/8100510a02.opus"
    aoi "\"¡Oh!\""


translate english a3181_13c4d478:


    "Se olvidó por completo de eso, ¿verdad...?"


translate english a3181_46e3bfa5:


    "De alguna forma no me sorprende..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
