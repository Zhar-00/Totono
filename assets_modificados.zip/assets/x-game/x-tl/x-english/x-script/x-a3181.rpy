

translate english a3181_f3a631e5:



    voice "voice/a31/8100010a01.opus"
    mx "\"Aoi, where are you?\""


translate english a3181_00fac4c5:


    "La voz de Miyuki resuena y se desvanece en la oscuridad."


translate english a3181_421c3a99:


    "El gimnasio está completamente oscuro."


translate english a3181_5c6ea206:


    "Normalmente no habría ni un alma aquí a esta hora."


translate english a3181_c055c894:


    xy "\"I know you're in here, Aoi!\""


translate english a3181_4e5c11ac:



    voice "voice/a31/8100020a02.opus"
    aoi "\"Stop!\""


translate english a3181_bbeeefca:


    xy "\"Did you hear that?\""


translate english a3181_7f16d825:



    voice "voice/a31/8100030a01.opus"
    mx "\"Yeah, that was definitely her.\""


translate english a3181_d3c53b2d:



    voice "voice/a31/8100040a01.opus"
    mx "\"We know you're there! Please talk to us!\""


translate english a3181_66683434:


    "...Silencio."


translate english a3181_23e54998:


    "Aoi no responde."


translate english a3181_29e9e3b9:



    voice "voice/a31/8100050a01.opus"
    mx "\"Why are you hiding?\""


translate english a3181_7e9ca391:



    voice "voice/a31/8100060a01.opus"
    mx "\"Come on, Aoi, get out here!\""


translate english a3181_496205f9:


    "Miyuki grita hacia la oscuridad."


translate english a3181_9c25eb80:


    "Pero Aoi se niega a responder."


translate english a3181_4bc6ab3e:


    "En vez de eso, lo único que oímos es—"


translate english a3181_d89eb7fd:



    voice "voice/a31/8100070a02.opus"
    aoi "\"...Hnn...\""


translate english a3181_78e6b96e:


    "—un sollozo ahogado."


translate english a3181_8c257ca8:


    "Está llorando."


translate english a3181_2e4a1002:



    voice "voice/a31/8100080a01.opus"
    mx "\"Aoi, what's wrong?\""


translate english a3181_6419b579:



    voice "voice/a31/8100090a02.opus"
    aoi "\"Stay away!\""


translate english a3181_45068d7c:



    voice "voice/a31/8100100a02.opus"
    aoi "\"Don't... hnn... come any... closer...\""


translate english a3181_b1af9fb2:



    voice "voice/a31/8100110a01.opus"
    mx "\"Why are you crying?\""


translate english a3181_4539f64c:



    voice "voice/a31/8100120a02.opus"
    aoi "\"Hnn... nnn... nnnn... A-Aoi... can't help it... because...\""


translate english a3181_dc9cbac6:



    voice "voice/a31/8100130a02.opus"
    aoi "\"Aoi... didn't listen...!\""


translate english a3181_aaa42391:



    voice "voice/a31/8100140a01.opus"
    mx "\"To what?\""


translate english a3181_8e64a180:



    voice "voice/a31/8100150a02.opus"
    aoi "\"Miyuki... told me not to, but... Aoi... couldn't stop thinking about it...\""


translate english a3181_21233ba6:



    voice "voice/a31/8100160a02.opus"
    aoi "\"Couldn't... abandon the kitten... Wanted... to be a hero...\""


translate english a3181_80b2430c:



    voice "voice/a31/8100170a02.opus"
    aoi "\"But now... Miyuki's gonna... cut ties... and stop being my friend...\""


translate english a3181_6e480dfc:


    "Bueno, esa fue definitivamente la amenaza que hizo en su momento..."


translate english a3181_02b587c4:



    voice "voice/a31/8100180a01.opus"
    mx "\"Is that why she won't come out...?\""


translate english a3181_e2c18ffd:


    xy "\"Probably.\""


translate english a3181_020b81dc:


    xy "\"She already chose you over the kitten once before.\""


translate english a3181_a5b76731:



    voice "voice/a31/8100190a01.opus"
    mx "\"......\""


translate english a3181_d57ef21a:


    xy "\"Come on, Miyuki.\""


translate english a3181_8a65f361:



    voice "voice/a31/8100200a01.opus"
    mx "\"I get it, alright?!\""


translate english a3181_56af6876:


    "Miyuki suspira con frustración."


translate english a3181_7eb50298:



    voice "voice/a31/8100210a01.opus"
    mx "\"I take it back, okay? I take it all back!\""


translate english a3181_02dd6317:



    voice "voice/a31/8100220a02.opus"
    aoi "\"Hnn... nnn... You... take it back...?\""


translate english a3181_703b20f7:



    voice "voice/a31/8100230a01.opus"
    mx "\"I don't want to cut ties! I want to stay friends! Now please get out here and talk to us, Aoi!\""


translate english a3181_f077ecd0:



    voice "voice/a31/8100240a02.opus"
    aoi "\"You... You sure you won't cut ties with me?\""


translate english a3181_41b20c6a:


    "La voz vacilante de Aoi atraviesa la oscuridad."


translate english a3181_71dc36a5:



    voice "voice/a31/8100250a02.opus"
    aoi "\"You promise you take it back?\""


translate english a3181_26d76cf2:



    voice "voice/a31/8100260a01.opus"
    mx "\"Why else would I come looking for you in the middle of the night when it's pouring down rain outside?\""


translate english a3181_1c528da7:



    voice "voice/a31/8100270a01.opus"
    mx "\"I wouldn't do it unless I was worried about you. Obviously.\""


translate english a3181_9f70decb:



    voice "voice/a31/8100280a02.opus"
    aoi "\"You mean it...?\""


translate english a3181_4cb46377:



    voice "voice/a31/8100290a01.opus"
    mx "\"I wouldn't lie to you about something like this.\""


translate english a3181_23e3fc78:



    voice "voice/a31/8100300a01.opus"
    mx "\"I mean, we're friends, aren't we?\""


translate english a3181_e6a4c0a5:



    voice "voice/a31/8100310a02.opus"
    aoi "\"Th... Th...\""


translate english a3181_aa19fca5:



    voice "voice/a31/8100320a02.opus"
    aoi "\"Thank you so much!\""


translate english a3181_07a4ad56:


    "Aoi sale corriendo de entre bambalinas—"


translate english a3181_5dc38faa:



    voice "voice/a31/8100330a01.opus"
    mx "\"Mommy cat?!\""


translate english a3181_9bc90938:


    "—llevando su mameluco de gatito."


translate english a3181_8bb76439:



    voice "voice/a31/8100340a02.opus"
    aoi "\"Miyuki! You're the best!\""


translate english a3181_71139df0:



    voice "voice/a31/8100350a01.opus"
    mx "\"Th... Thanks. I'm just glad you're feeling better.\""


translate english a3181_bda7e08b:


    "Puedo oír un pequeño chillido en la voz de Miyuki mientras el abrazo con salto de Aoi amenaza con casi tumbarlas a ambas al suelo."


translate english a3181_bb966e44:


    xy "\"Wait... Where's the kitten?\""


translate english a3181_e78ed087:



    voice "voice/a31/8100360a02.opus"
    aoi "\"Right here.\""


translate english a3181_ab78b333:



    voice "voice/a31/8100370a02.opus"
    aoi "\"Come on out, Eru.\""


translate english a3181_8850c6f7:


    "Como si obedeciera una orden, el gatito asoma la cabeza del bolsillo del pecho del mameluco."


translate english a3181_93a9b228:


    "Dios, los niveles de ternura están fuera de serie... Hasta a mí me han hecho sonreír."


translate english a3181_b450ec51:



    voice "voice/a31/8100390a01.opus"
    mx "\"I... I could die happy...\""


translate english a3181_3fe7eea1:



    voice "voice/a31/8100400a02.opus"
    aoi "\"Boop boop! Miyuki?!\""


translate english a3181_273e8fa1:


    "Miyuki cae al suelo, con una sonrisa soñadora en el rostro."


translate english a3181_f1687bd9:



    voice "voice/a31/8100410a02.opus"
    aoi "\"Miyuki... Aoi's really sorry...\""


translate english a3181_14d8aded:



    voice "voice/a31/8100420a02.opus"
    aoi "\"Eru's sorry, too.\""


translate english a3181_2661ec34:



    voice "voice/a31/8100440a01.opus"
    mx "\"Stop! I get it! That's enough! Just stop!\""


translate english a3181_4a09b0fb:



    voice "voice/a31/8100450a01.opus"
    mx "\"Don't come any closer! We don't want a repeat of what happened last time!\""


translate english a3181_fa6a0c86:



    voice "voice/a31/8100460a02.opus"
    aoi "\"But Eru wants to hug you!\""


translate english a3181_1ab54a37:



    voice "voice/a31/8100470a01.opus"
    mx "\"Hug me?! Well... I guess if I have to...!\""


translate english a3181_703b913f:


    xy "\"What happened to avoiding a repeat of last time?!\""


translate english a3181_e7806569:



    voice "voice/a31/8100480a01.opus"
    mx "\"History's always going to repeat itself regardless! Shinichi, do you have a face mask?\""


translate english a3181_eeac0900:


    xy "\"Why would I?\""


translate english a3181_946aaf01:



    voice "voice/a31/8100490a01.opus"
    mx "\"Why WOULDN'T you?!\""


translate english a3181_d0615571:


    xy "\"Don't snap at me!\""


translate english a3181_e1c90e65:


    "Cuando se trata de gatos, lo juro, esta chica deja de pensar con claridad..."


translate english a3181_7ce880d9:


    xy "\"And Aoi, don't encourage her! Why are you even wearing that?!\""


translate english a3181_cb09b06d:



    voice "voice/a31/8100500a02.opus"
    aoi "\"Well, my clothes got all wet.\""


translate english a3181_8c4e9309:


    xy "\"What happened to that umbrella I gave you?\""


translate english a3181_a7d2c625:



    voice "voice/a31/8100510a02.opus"
    aoi "\"Oh!\""


translate english a3181_13c4d478:


    "Se olvidó por completo de eso, ¿verdad...?"


translate english a3181_46e3bfa5:


    "De alguna forma no me sorprende..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
