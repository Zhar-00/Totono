

translate english a5163_0658033c:


    xy "\"Oye, ¿Aoi? Ya vuelvo.\""


translate english a5163_e0f3bf3a:


    "Subo corriendo las escaleras hasta mi cuarto."


translate english a5163_b7ed9bec:


    "Todavía tengo el teléfono que le pedí prestado a Yuutarou."


translate english a5163_b3ff884a:


    "Y esa novela visual me ayudó a encontrar la ubicación de Aoi hace unos días."


translate english a5163_1512f0a0:


    "En ese momento, pensé que Aoi solo estaba imitando lo que jugaba."


translate english a5163_3a70f6ef:


    "¿Pero y si el juego en realidad está prediciendo cosas que pasarán en la vida real?"


translate english a5163_b4c15322:


    "Ya sé... debo sonar como si tuviera un caso grave de cerebro de gamer."


translate english a5163_86173f58:


    "Pero es lo único con lo que cuento por ahora."


translate english a5163_4bac56c8:


    "Al menos vale la pena intentarlo."


translate english a5163_23240416:


    "Enciendo el teléfono y abro el juego."


translate english a5163_4a04f4b2:


    "My save file picks up back at the scene where \"Aoi\"acuna a un gatito en el gimnasio."


translate english a5163_b98c6117:


    "De inmediato presiono el botón de Saltar."


translate english a5163_47dd6ea9:


    "Las demás escenas pasan volando en avance rápido..."


translate english a5163_324a860a:


    "Y sigue, y sigue, y sigue..."


translate english a5163_25747065:



    voice "voice/a51/6300010a02.opus"
    aoi "\"No sirve de nada...\""


translate english a5163_85bdaf45:


    "Miro hacia atrás y encuentro a Aoi aferrada a la pared, desesperada por mantenerse en pie."


translate english a5163_df875b0f:



    voice "voice/a51/6300020a02.opus"
    aoi "\"Este evento no está... en el guion del juego...\""


translate english a5163_fbc2f7e7:



    voice "voice/a51/6300030a02.opus"
    aoi "\"Hay un glitch... en el universo...\""


translate english a5163_cfe703ae:


    xy "\"¡Uah! ¡Aoi! ¿¡Estás bien!?\""


translate english a5163_ae551b14:



    voice "voice/a51/6300040a02.opus"
    aoi "\"Mi batería se está... muriendo...\""


translate english a5163_3dc689ce:



    voice "voice/a51/6300050a02.opus"
    aoi "\"Un solo CG... no es... suficiente...\""


translate english a5163_307821d5:


    xy "\"¡¿De qué estás balbuceando?! Espera, voy a llamar una ambulancia...\""


translate english a5163_1d099d67:



    voice "voice/a51/6300060a02.opus"
    aoi "\"Esto no es... una enfermedad normal. Sin mi teléfono... Aoi no puede... guardar la partida...\""


translate english a5163_9c0e087a:



    voice "voice/a51/6300070a02.opus"
    aoi "\"Dios me... abandonó... Esto es todo... Se acabó...\""


translate english a5163_b9ddc474:


    xy "\"¡NO se acabó!\""


translate english a5163_5b169a6f:



    voice "voice/a51/6300080a02.opus"
    aoi "\"¿Boop... boop...?\""


translate english a5163_8ceef670:


    xy "\"¡Si tu dios no te ayuda, entonces yo lo haré! ¡No te toca decidir cuándo se acabó!\""


translate english a5163_8f9aa861:


    xy "\"O sea... ¿Para qué están los amigos?\""


translate english a5163_7fa59231:



    voice "voice/a51/6300090a02.opus"
    aoi "\"Am...i...gos...\""


translate english a5163_a9a96ab6:



    voice "voice/a51/6300100a02.opus"
    aoi "\"¿Somos... amigos...?\""


translate english a5163_77250007:


    xy "\"¡Claro que sí!\""


translate english a5163_0fd99b59:


    "Aoi mira al suelo un rato y murmura para sí misma, inaudible, como si saboreara el concepto."


translate english a5163_6baa259e:


    "Luego levanta la vista, directo a mis ojos."


translate english a5163_026583df:



    voice "voice/a51/6300110a02.opus"
    aoi "\"...Hace frío.\""


translate english a5163_901d947f:


    xy "\"Ah, cierto. Deberíamos limpiarte el sudor de la cara.\""


translate english a5163_dbfa88d2:


    xy "\"Ya vuelvo.\""


translate english a5163_c3187cc8:


    "No puedo seguir haciendo la vista gorda ante su condición."


translate english a5163_45664027:


    "Tiene que haber alguna forma de llevarla al médico..."


translate english a5163_def86741:


    "Pero voy a necesitar ayuda."


translate english a5163_9bdc5e2f:


    "En momentos así, solo hay una persona con la que sé que puedo contar."


translate english a5163_6d8ab6a1:



    voice "voice/a51/6300120b01.opus"
    xtl "\"¡Oye, amigo! ¿Cómo va tu noche?\""


translate english a5163_e770d286:



    voice "voice/a51/6300130b01.opus"
    xtl "\"Espera, no me digas... ¿Encontraste un nuevo artefacto de la ambición masculina...?\""


translate english a5163_f415e24b:


    xy "\"Perdón, pero estoy en apuros ahora. Aoi no está muy bien.\""


translate english a5163_acaf1b35:



    voice "voice/a51/6300140b01.opus"
    xtl "\"¿Mukou? ¿Qué pasa?\""


translate english a5163_565fe817:


    xy "\"No puedo explicarlo bien, pero necesito tu ayuda.\""


translate english a5163_9b449a50:



    voice "voice/a51/6300150b01.opus"
    xtl "\"¿Dónde nos encontramos?\""


translate english a5163_6124b997:


    xy "\"Mi casa. ¿Está bien?\""


translate english a5163_92f19d53:



    voice "voice/a51/6300160b01.opus"
    xtl "\"¡Claro que sí! ¡Es mi trabajo como tu capitán echar una mano en tiempos de necesidad!\""


translate english a5163_cb430efa:


    xy "\"Gracias. De verdad te debo una.\""


translate english a5163_a4b675da:



    voice "voice/a51/6300170b01.opus"
    xtl "\"¡Déjamelo a mí!\""


translate english a5163_57130f69:


    "Así sin más, Yuutarou aceptó ayudarme, sin hacer preguntas."


translate english a5163_4e478c33:


    "A veces puede ser insoportable, pero siempre está ahí cuando más importa... y por eso lo quiero."


translate english a5163_f61dc212:


    "Así que, ahora que la ayuda está en camino... ¿qué sigue?"


translate english a5163_df6342b5:


    "Tomo un paño y vuelvo a mi cuarto."


translate english a5163_a8aac761:


    xy "\"Ya vol... {nw=2}"



translate english a5163_2ca209ce:


    extend "ck...\""


translate english a5163_489a2693:



    voice "voice/a51/6300180a02.opus"
    aoi "\"Hola.\""


translate english a5163_fd9282b2:


    "Aparto la mirada de inmediato."


translate english a5163_79a77459:


    "Aoi se ha quitado la parte de arriba, dejando al descubierto su piel de porcelana."


translate english a5163_5a08f999:



    voice "voice/a51/6300190a02.opus"
    aoi "\"Límpiame...\""


translate english a5163_6d8718c9:



    voice "voice/a51/6300200a02.opus"
    aoi "\"Por favor...\""


translate english a5163_8a763816:


    xy "\"E-Está bien...\""


translate english a5163_77a7c5bf:


    "Sin dejar de desviar la mirada, me acerco a ella."


translate english a5163_7f71dee1:


    "Puedo oír su respiración agitada."


translate english a5163_1c18eab6:


    "Y siento cómo mi mirada es atraída como un imán."


translate english a5163_1e7ee392:


    "Luchando contra el impulso de mirar, le extiendo el paño con cuidado."


translate english a5163_56c20556:


    xy "\"E-Está bien, aquí voy...\""



translate english a5163_f1c1a2b6:



    voice "voice/a51/6300210a02.opus"
    aoi "\"Perdón, Miyuki.\""


translate english a5163_e64f0e24:


    xy "\"¿Eh? ¿Dijiste algo...?\""


translate english a5163_424d713c:



    voice "voice/a51/6300220a02.opus"
    aoi "\"Shinichi, mírame.\""


translate english a5163_14ea5d4a:


    xy "\"¿Eh...?\""


translate english a5163_a8c7ba95:



    voice "voice/a51/6300230a02.opus"
    aoi "\"¡Mírame!\""


translate english a5163_d42d38d5:


    "Puedo oír la desesperación en su voz."


translate english a5163_98ad8bec:


    "En silencio, hago lo que me pide."


translate english a5163_66e73652:


    "Su piel desnuda está empapada de sudor."


translate english a5163_8f0cb862:


    "Sus hombros tiemblan."


translate english a5163_ec6cc3e6:


    "Y puedo ver la curva de sus pequeños y torneados pechos."


translate english a5163_a58e2a39:



    voice "voice/a51/6300240a02.opus"
    aoi "\"Tócame.\""


translate english a5163_1db55dbf:


    xy "\"Espera... ¿¡Tocarte!?\""


translate english a5163_b3b52410:



    voice "voice/a51/6300250a02.opus"
    aoi "\"La batería de Aoi se está muriendo.\""


translate english a5163_7a3ad8fd:



    voice "voice/a51/6300260a02.opus"
    aoi "\"No hay suficiente chispazo.\""


translate english a5163_bd8ed005:



    voice "voice/a51/6300270a02.opus"
    aoi "\"Aoi fue hecha para recolectar CGs de eventos.\""


translate english a5163_742521d2:



    voice "voice/a51/6300280a02.opus"
    aoi "\"Sin ellos, la batería de Aoi morirá.\""


translate english a5163_fdb23468:



    voice "voice/a51/6300290a02.opus"
    aoi "\"Y entonces Aoi desaparecerá para siempre.\""


translate english a5163_52d64aa0:


    "Dos palabras me vienen a la mente: cerebro de gamer."


translate english a5163_20251d82:


    "Pero sacudo el pensamiento."


translate english a5163_b6d9f03e:


    "Los sentimientos de Aoi son reales."


translate english a5163_40e5cd8e:


    "Y ella está sufriendo."


translate english a5163_c6e2b3eb:



    voice "voice/a51/6300300a02.opus"
    aoi "\"Aoi... no quiere... desaparecer...\""


translate english a5163_e5985250:



    voice "voice/a51/6300310a02.opus"
    aoi "\"No después de conocerte...\""


translate english a5163_44fd8a39:



    voice "voice/a51/6300320a02.opus"
    aoi "\"Por favor, no me quites estos recuerdos...\""


translate english a5163_a9c128ad:



    voice "voice/a51/6300330a02.opus"
    aoi "\"No tenemos que ser más que amigos...\""


translate english a5163_97b7cc94:



    voice "voice/a51/6300340a02.opus"
    aoi "\"Por favor, solo... recárgame con tu chispazo...\""


translate english strings:


    old "Подзарядить её"
    new "Recibe la chispa"


    old "Не подзаряжать"
    new "No recibas la chispa"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
