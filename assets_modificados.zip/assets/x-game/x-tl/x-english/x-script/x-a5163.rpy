

translate english a5163_0658033c:


    xy "\"Hey, Aoi? I'll be right back.\""


translate english a5163_e0f3bf3a:


    "Subo corriendo las escaleras hasta mi cuarto."


translate english a5163_b7ed9bec:


    "Todavía tengo el teléfono que le pedí prestado a Yuutarou."


translate english a5163_b3ff884a:


    "Y esa novela visual me ayudó a encontrar la ubicación de Aoi hace unos días."


translate english a5163_1512f0a0:


    "En ese momento, pensé que Aoi solo estaba imitando lo que jugaba."


translate english a5163_3a70f6ef:


    "¿Pero y si el juego en realidad está prediciendo cosas que pasarán en la vida real?"


translate english a5163_b4c15322:


    "Ya sé... debo sonar como si tuviera un caso grave de cerebro de gamer."


translate english a5163_86173f58:


    "Pero es lo único con lo que cuento por ahora."


translate english a5163_4bac56c8:


    "Al menos vale la pena intentarlo."


translate english a5163_23240416:


    "Enciendo el teléfono y abro el juego."


translate english a5163_4a04f4b2:


    "My save file picks up back at the scene where \"Aoi\"acuna a un gatito en el gimnasio."


translate english a5163_b98c6117:


    "De inmediato presiono el botón de Saltar."


translate english a5163_47dd6ea9:


    "Las demás escenas pasan volando en avance rápido..."


translate english a5163_324a860a:


    "Y sigue, y sigue, y sigue..."


translate english a5163_25747065:



    voice "voice/a51/6300010a02.opus"
    aoi "\"It's no use...\""


translate english a5163_85bdaf45:


    "Miro hacia atrás y encuentro a Aoi aferrada a la pared, desesperada por mantenerse en pie."


translate english a5163_df875b0f:



    voice "voice/a51/6300020a02.opus"
    aoi "\"This event isn't... in the game script...\""


translate english a5163_fbc2f7e7:



    voice "voice/a51/6300030a02.opus"
    aoi "\"There's a glitch... in the universe...\""


translate english a5163_cfe703ae:


    xy "\"Whoa! Aoi! You okay?!\""


translate english a5163_ae551b14:



    voice "voice/a51/6300040a02.opus"
    aoi "\"My battery is... dying...\""


translate english a5163_3dc689ce:



    voice "voice/a51/6300050a02.opus"
    aoi "\"One single CG... isn't... enough...\""


translate english a5163_307821d5:


    xy "\"What are you babbling about?! Hold on, I'll call an ambulance—\""


translate english a5163_1d099d67:



    voice "voice/a51/6300060a02.opus"
    aoi "\"This isn't... a normal disease. Without my phone... Aoi can't... save the game...\""


translate english a5163_9c0e087a:



    voice "voice/a51/6300070a02.opus"
    aoi "\"God has... abandoned me... This is it... It's all over...\""


translate english a5163_b9ddc474:


    xy "\"It's NOT over!\""


translate english a5163_5b169a6f:



    voice "voice/a51/6300080a02.opus"
    aoi "\"Boop... boop...?\""


translate english a5163_8ceef670:


    xy "\"If your god won't help you, then I will! You don't get to decide when it's all over!\""


translate english a5163_8f9aa861:


    xy "\"I mean... What are friends for?\""


translate english a5163_7fa59231:



    voice "voice/a51/6300090a02.opus"
    aoi "\"Fr...i...ends...\""


translate english a5163_a9a96ab6:



    voice "voice/a51/6300100a02.opus"
    aoi "\"We're... friends...?\""


translate english a5163_77250007:


    xy "\"Damn right!\""


translate english a5163_0fd99b59:


    "Aoi mira al suelo un rato y murmura para sí misma, inaudible, como si saboreara el concepto."


translate english a5163_6baa259e:


    "Luego levanta la vista, directo a mis ojos."


translate english a5163_026583df:



    voice "voice/a51/6300110a02.opus"
    aoi "\"...It's cold.\""


translate english a5163_901d947f:


    xy "\"Oh, right. We should wipe that sweat off your face.\""


translate english a5163_dbfa88d2:


    xy "\"Be right back.\""


translate english a5163_c3187cc8:


    "No puedo seguir haciendo la vista gorda ante su condición."


translate english a5163_45664027:


    "Tiene que haber alguna forma de llevarla al médico..."


translate english a5163_def86741:


    "Pero voy a necesitar ayuda."


translate english a5163_9bdc5e2f:


    "En momentos así, solo hay una persona con la que sé que puedo contar."


translate english a5163_6d8ab6a1:



    voice "voice/a51/6300120b01.opus"
    xtl "\"Hey, man! How's your night going?\""


translate english a5163_e770d286:



    voice "voice/a51/6300130b01.opus"
    xtl "\"Wait, don't tell me... Did you find a new artifact of male amb—\""


translate english a5163_f415e24b:


    xy "\"Sorry, but I'm in a bad spot right now. Aoi's not doing so great.\""


translate english a5163_acaf1b35:



    voice "voice/a51/6300140b01.opus"
    xtl "\"Mukou? What's going on?\""


translate english a5163_565fe817:


    xy "\"I can't really explain, but I need your help.\""


translate english a5163_9b449a50:



    voice "voice/a51/6300150b01.opus"
    xtl "\"Where should I meet you?\""


translate english a5163_6124b997:


    xy "\"My place. Is that cool?\""


translate english a5163_92f19d53:



    voice "voice/a51/6300160b01.opus"
    xtl "\"But of course! It's my job as your captain to lend a hand in times of need!\""


translate english a5163_cb430efa:


    xy "\"Thanks. I really owe you one.\""


translate english a5163_a4b675da:



    voice "voice/a51/6300170b01.opus"
    xtl "\"Just leave it to me!\""


translate english a5163_57130f69:


    "Así sin más, Yuutarou aceptó ayudarme, sin hacer preguntas."


translate english a5163_4e478c33:


    "A veces puede ser insoportable, pero siempre está ahí cuando más importa... y por eso lo quiero."


translate english a5163_f61dc212:


    "Así que, ahora que la ayuda está en camino... ¿qué sigue?"


translate english a5163_df6342b5:


    "Tomo un paño y vuelvo a mi cuarto."


translate english a5163_a8aac761:


    xy "\"I'm ba... {nw=2}"



translate english a5163_2ca209ce:


    extend "ck...\""


translate english a5163_489a2693:



    voice "voice/a51/6300180a02.opus"
    aoi "\"Hi.\""


translate english a5163_fd9282b2:


    "Aparto la mirada de inmediato."


translate english a5163_79a77459:


    "Aoi se ha quitado la parte de arriba, dejando al descubierto su piel de porcelana."


translate english a5163_5a08f999:



    voice "voice/a51/6300190a02.opus"
    aoi "\"Wipe me down...\""


translate english a5163_6d8718c9:



    voice "voice/a51/6300200a02.opus"
    aoi "\"Please...\""


translate english a5163_8a763816:


    xy "\"O-Okay...\""


translate english a5163_77a7c5bf:


    "Sin dejar de desviar la mirada, me acerco a ella."


translate english a5163_7f71dee1:


    "Puedo oír su respiración agitada."


translate english a5163_1c18eab6:


    "Y siento cómo mi mirada es atraída como un imán."


translate english a5163_1e7ee392:


    "Luchando contra el impulso de mirar, le extiendo el paño con cuidado."


translate english a5163_56c20556:


    xy "\"O-Okay, here I go—\""



translate english a5163_f1c1a2b6:



    voice "voice/a51/6300210a02.opus"
    aoi "\"Sorry, Miyuki.\""


translate english a5163_e64f0e24:


    xy "\"Huh? Did you say someth—\""


translate english a5163_424d713c:



    voice "voice/a51/6300220a02.opus"
    aoi "\"Shinichi, look at me.\""


translate english a5163_14ea5d4a:


    xy "\"Huh...?\""


translate english a5163_a8c7ba95:



    voice "voice/a51/6300230a02.opus"
    aoi "\"Look at me!\""


translate english a5163_d42d38d5:


    "Puedo oír la desesperación en su voz."


translate english a5163_98ad8bec:


    "En silencio, hago lo que me pide."


translate english a5163_66e73652:


    "Su piel desnuda está empapada de sudor."


translate english a5163_8f0cb862:


    "Sus hombros tiemblan."


translate english a5163_ec6cc3e6:


    "Y puedo ver la curva de sus pequeños y torneados pechos."


translate english a5163_a58e2a39:



    voice "voice/a51/6300240a02.opus"
    aoi "\"Touch me.\""


translate english a5163_1db55dbf:


    xy "\"Wait... Touch you...?!\""


translate english a5163_b3b52410:



    voice "voice/a51/6300250a02.opus"
    aoi "\"Aoi's battery is dying.\""


translate english a5163_7a3ad8fd:



    voice "voice/a51/6300260a02.opus"
    aoi "\"Not enough zappy.\""


translate english a5163_bd8ed005:



    voice "voice/a51/6300270a02.opus"
    aoi "\"Aoi was made to collect event CGs.\""


translate english a5163_742521d2:



    voice "voice/a51/6300280a02.opus"
    aoi "\"Without them, Aoi's battery will die.\""


translate english a5163_fdb23468:



    voice "voice/a51/6300290a02.opus"
    aoi "\"And then Aoi will disappear forever.\""


translate english a5163_52d64aa0:


    "Dos palabras me vienen a la mente: cerebro de gamer."


translate english a5163_20251d82:


    "Pero sacudo el pensamiento."


translate english a5163_b6d9f03e:


    "Los sentimientos de Aoi son reales."


translate english a5163_40e5cd8e:


    "Y ella está sufriendo."


translate english a5163_c6e2b3eb:



    voice "voice/a51/6300300a02.opus"
    aoi "\"Aoi... doesn't want to... disappear...\""


translate english a5163_e5985250:



    voice "voice/a51/6300310a02.opus"
    aoi "\"Not after meeting you...\""


translate english a5163_44fd8a39:



    voice "voice/a51/6300320a02.opus"
    aoi "\"Please don't take these memories away from me...\""


translate english a5163_a9c128ad:



    voice "voice/a51/6300330a02.opus"
    aoi "\"We don't have to be more than friends...\""


translate english a5163_97b7cc94:



    voice "voice/a51/6300340a02.opus"
    aoi "\"Please, just... recharge me with your zappy...\""


translate english strings:


    old "Подзарядить её"
    new "Recibe la chispa"


    old "Не подзаряжать"
    new "No recibas la chispa"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
