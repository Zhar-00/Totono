

translate english e0113_5cf4dc7b:


    "Antes de que pueda revisar el historial de llamadas—"


translate english e0113_2ff60971:



    voice "voice/e01/1300010a01.opus"
    mx "\"That's mine.\""


translate english e0113_e7399540:


    "La puerta se abre. Es Miyuki."


translate english e0113_4ba7adbf:


    xy "\"Really? I didn't know you had a smartphone.\""


translate english e0113_826dc583:


    "Pensé que tenía uno de esos viejos teléfonos de concha..."


translate english e0113_220d81de:



    voice "voice/e01/1300020a01.opus"
    mx "\"I found it over at your house.\""


translate english e0113_7a8e2b08:


    xy "\"What? You did?\""


translate english e0113_d0f17d10:



    voice "voice/e01/1300030a01.opus"
    mx "\"Maybe you forgot. It was a long time ago, after all.\""


translate english e0113_580682cf:



    voice "voice/e01/1300040a01.opus"
    mx "\"But it's just so outdated now, you know?\""


translate english e0113_fcbf6b2e:



    voice "voice/e01/1300050a01.opus"
    mx "\"But it's just so tacky-looking, you know?\""


translate english e0113_bce5b82e:



    voice "voice/e01/1300060a01.opus"
    mx "\"But there are just so many bad memories associated with it now, you know?\""


translate english e0113_fdc48d0d:



    voice "voice/e01/1300070a01.opus"
    mx "\"So I got myself a new one.\""


translate english e0113_9934edf2:


    "Saca un flamante smartphone nuevo de su bolsillo."


translate english e0113_af20bbbc:


    "Es el último modelo, con una pantalla mucho más grande."


translate english e0113_6b12afd0:



    voice "voice/e01/1300080a01.opus"
    mx "\"As long as I've got the SIM card, I don't need that old one.\""


translate english e0113_46f508b5:



    voice "voice/e01/1300090a01.opus"
    mx "\"Would you go ahead and toss it for me?\""


translate english e0113_eedef60d:


    xy "\"What, throw it off the roof?\""


translate english e0113_bfebe126:



    voice "voice/e01/1300100a01.opus"
    mx "\"Yeah. Just throw it right off the roof.\""


translate english strings:


    old "Выбросить его"
    new "Lanzarlo"


    old "Не выбрасывать его"
    new "No lanzarlo"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
