

translate english e0113_5cf4dc7b:


    "Antes de que pueda revisar el historial de llamadas—"


translate english e0113_2ff60971:



    voice "voice/e01/1300010a01.opus"
    mx "\"Ese es mío.\""


translate english e0113_e7399540:


    "La puerta se abre. Es Miyuki."


translate english e0113_4ba7adbf:


    xy "\"¿En serio? No sabía que tenías un smartphone.\""


translate english e0113_826dc583:


    "Pensé que tenía uno de esos viejos teléfonos de concha..."


translate english e0113_220d81de:



    voice "voice/e01/1300020a01.opus"
    mx "\"Lo encontré en tu casa.\""


translate english e0113_7a8e2b08:


    xy "\"¿Qué? ¿En serio?\""


translate english e0113_d0f17d10:



    voice "voice/e01/1300030a01.opus"
    mx "\"Quizá lo olvidaste. Después de todo, fue hace mucho tiempo.\""


translate english e0113_580682cf:



    voice "voice/e01/1300040a01.opus"
    mx "\"Pero ya está muy anticuado, ¿sabes?\""


translate english e0113_fcbf6b2e:



    voice "voice/e01/1300050a01.opus"
    mx "\"Pero ya se ve muy ridículo, ¿sabes?\""


translate english e0113_bce5b82e:



    voice "voice/e01/1300060a01.opus"
    mx "\"Pero ya hay demasiados malos recuerdos asociados con él, ¿sabes?\""


translate english e0113_fdc48d0d:



    voice "voice/e01/1300070a01.opus"
    mx "\"Así que me compré uno nuevo.\""


translate english e0113_9934edf2:


    "Saca un flamante smartphone nuevo de su bolsillo."


translate english e0113_af20bbbc:


    "Es el último modelo, con una pantalla mucho más grande."


translate english e0113_6b12afd0:



    voice "voice/e01/1300080a01.opus"
    mx "\"Mientras tenga la tarjeta SIM, no necesito ese viejo.\""


translate english e0113_46f508b5:



    voice "voice/e01/1300090a01.opus"
    mx "\"¿Podrías tirarlo por mí?\""


translate english e0113_eedef60d:


    xy "\"¿Qué, tirarlo desde la azotea?\""


translate english e0113_bfebe126:



    voice "voice/e01/1300100a01.opus"
    mx "\"Sí. Solo tíralo desde la azotea.\""


translate english strings:


    old "Выбросить его"
    new "Lanzarlo"


    old "Не выбрасывать его"
    new "No lanzarlo"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
