

translate english e2172d_da494787:


    "\"Cocina para principiantes.\""



translate english e2172d_7ae7b3be:



    voice "voice/e21/72d00010a01.opus"
    mx "\"...Es la tercera vez.\""


translate english e2172d_46bc0fb0:


    xy "\"¿Qué?\""


translate english e2172d_a8f43d00:



    voice "voice/e21/72d00020a01.opus"
    mx "\"¿Cuántas veces vas a comprar ese libro estúpido?\""


translate english e2172d_19b72793:


    xy "\"No sé... Cada vez que lo veo, por alguna razón tengo que tenerlo...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
