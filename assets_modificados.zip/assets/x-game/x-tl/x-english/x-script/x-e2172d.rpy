

translate english e2172d_da494787:


    "\"Cooking 101.\""



translate english e2172d_7ae7b3be:



    voice "voice/e21/72d00010a01.opus"
    mx "\"...That's the third time.\""


translate english e2172d_46bc0fb0:


    xy "\"What?\""


translate english e2172d_a8f43d00:



    voice "voice/e21/72d00020a01.opus"
    mx "\"How many times are you going to buy that stupid book?\""


translate english e2172d_19b72793:


    xy "\"I dunno... Every time I see it, I just gotta have it for some reason...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
