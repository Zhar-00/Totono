

translate english e2225a_1393afeb:


    xy "\"Por favor... Consuélame.\""


translate english e2225a_b7deb526:



    voice "voice/e22/25a00010a01.opus"
    mx "\"Muy bien. En ese caso...\""


translate english e2225a_4326a9ef:



    voice "voice/e22/25a00020a01.opus"
    mx "\"...Uf...\""


translate english e2225a_e56fb695:


    "Toma aire."


translate english e2225a_65a2d9c6:


    "Aunque está demasiado oscuro para ver, me doy cuenta de que se inclina profundamente."


translate english e2225a_6251166a:



    voice "voice/e22/25a00030a01.opus"
    mx "\"Te serviré lo mejor que pueda.\""


translate english e2225a_ea998eba:


    "Oigo el revoloteo de la ropa."


translate english e2225a_6b965fc4:


    "Algo se retuerce."


translate english e2225a_64377b11:


    "Se desabrocha un cinturón."


translate english e2225a_6229021f:


    "Siento un peso sobre mi entrepierna."


translate english e2225a_cce6fb53:


    "Mi polla ya ha empezado a levantar la cabeza, y lo siguiente que sé—"


translate english e2225a_9518cd9d:


    "—algo suave la envuelve."


translate english e2225a_14a3ab23:


    "¿Es... es que ella...?"


translate english e2225a_7eb755ec:



    voice "voice/e22/25a00040a01.opus"
    mx "\"Emm... Esto no duele, ¿verdad, Amo?\""


translate english e2225a_37827876:


    xy "\"No, para nada. De hecho, se siente increíble.\""


translate english e2225a_c98ddcf3:



    voice "voice/e22/25a00050a01.opus"
    mx "\"Me alegra. Ahora entonces...\""


translate english e2225a_4ed948af:



    voice "voice/e22/25a00060a01.opus"
    mx "\"Hora de servirte hasta el final.\""


translate english e2225a_d27eeafa:


    xy "\"¿Eh?\""


translate english e2225a_125431cf:


    "Siento aumentar la presión alrededor de mi erección que se va endureciendo."


translate english e2225a_002fc459:


    "Vaya..."


translate english e2225a_d6646b0a:


    "Si tan solo no estuviera tan oscuro aquí..."


translate english e2225a_e27b0d78:


    "Tengo que arreglar esto de alguna manera."


translate english e2225a_b9ee347e:


    "En esta posición, no hay forma de que alcance el interruptor de la luz..."


translate english e2225a_0214a1a5:


    "Si tan solo hubiera otra fuente de luz..."


translate english e2225a_3c76b111:


    "¡Eso es!"


translate english e2225a_4292514e:



    voice "voice/e22/25a00070a01.opus"
    mx "\"¿Hmm? ¿Amo?\""


translate english e2225a_953b6a1c:



    voice "voice/e22/25a00080a01.opus"
    mx "\"¡¡¡Aaah!!!\""


translate english e2225a_fbd33f6c:


    "¡Tal como lo planeé!"


translate english e2225a_a7f171c8:


    "Bajo la tenue luz de las velas, puedo ver a Miyuki sonrojada mientras intenta hacerme una rusa con su atuendo de sirvienta."


translate english e2225a_5be5de8d:


    "Sus pechos no son grandes ni mucho menos, pero se esfuerza al máximo de todos modos—y eso lo hace aún más excitante."


translate english e2225a_7f36dca1:



    voice "voice/e22/25a00090a01.opus"
    mx "\"Esto es tan vergonzoso...\""


translate english e2225a_4638dd24:


    xy "\"¡Para nada! Es lindo.\""


translate english e2225a_2615bda2:



    voice "voice/e22/25a00100a01.opus"
    mx "\"¡...Nnn...!\""


translate english e2225a_d20895be:



    voice "voice/e22/25a00110a01.opus"
    mx "\"Pero me veo tan estúpida usando esto...\""


translate english e2225a_09d95861:


    xy "\"Te ves genial. En serio.\""


translate english e2225a_408a7c5d:



    voice "voice/e22/25a00120a01.opus"
    mx "\"\"\"......\"\"\""


translate english e2225a_554d541d:



    voice "voice/e22/25a00130a01.opus"
    mx "\"¿De verdad?\""


translate english e2225a_a98558e6:


    xy "\"En serio, en serio.\""


translate english e2225a_73de08fd:


    "Como prueba, mi erección gana terreno rápidamente."


translate english e2225a_042f7c6f:


    xy "\"Te lo ruego, por favor no pares.\""


translate english e2225a_14117896:



    voice "voice/e22/25a00140a01.opus"
    mx "\"...Vale, bien, confiaré en ti.\""


translate english e2225a_6bc6f12b:



    voice "voice/e22/25a00150a01.opus"
    mx "\"Digo... Ejem...\""


translate english e2225a_d5abe852:



    voice "voice/e22/25a00160a01.opus"
    mx "\"Entendido, Amo.\""


translate english e2225a_e7900352:



    voice "voice/e22/25a00170a01.opus"
    mx "\"Ahora entonces, permíteme continuar.\""


translate english e2225a_a48d3a2b:


    "Con la mirada apartada con timidez, Miyuki sube y baja mi polla entre sus pechos."


translate english e2225a_ac01e020:


    "Sus almohadillados montículos envuelven mi miembro."


translate english e2225a_858d1f4b:


    "El estilo del atuendo de sirvienta también realza mucho su busto..."


translate english e2225a_a6fac204:


    "Además, la tenue luz de las velas le da a la habitación un ambiente sensual."


translate english e2225a_6b9a0d5a:


    "Todo es tan surrealista que siento que me exalto tanto emocional como físicamente."


translate english e2225a_aec50dc0:



    voice "voice/e22/25a00180a01.opus"
    mx "\"¿Cómo lo estoy haciendo, Amo?\""


translate english e2225a_bb86fac7:


    "Sus labios se contraen con las palabras."


translate english e2225a_0558a37a:


    "Being called \"Master\"ya... empieza a marearme un poco."



translate english e2225a_aa03996e:


    "En este momento, ella es mi sirvienta."


translate english e2225a_2398743a:


    "Y está de rodillas con un atuendo de sirvienta y mi polla entre sus pechos, explícitamente solo para mi placer."


translate english e2225a_41a92303:



    voice "voice/e22/25a00190a01.opus"
    mx "\"¿Cómo está? ¿Demasiada presión?\""


translate english e2225a_88198a01:


    xy "\"Oye, Miyuki... ¿Puedes explicarme qué es lo que estás haciendo ahora?\""


translate english e2225a_788b322f:



    voice "voice/e22/25a00200a01.opus"
    mx "\"¿Qué? ¿Explicarte... lo que estoy haciendo?\""


translate english e2225a_5212bbfa:


    "Y en efecto, parece resistirse a la idea..."


translate english e2225a_b031c904:


    "Pero sé que está comprometida con esta personalidad de sirvienta."


translate english e2225a_870ea830:


    "Si la presiono un poco más, seguro que cede."


translate english e2225a_acbe04ff:


    xy "\"Quiero que lo digas.\""


translate english e2225a_65ca7018:


    xy "\"Te lo ruego, mi dulce sirvienta.\""


translate english e2225a_d2dae01d:


    "Me trago el orgullo y suplico."


translate english e2225a_f9c20289:


    "Por suerte, me ahorra más vergüenza."


translate english e2225a_d2114047:



    voice "voice/e22/25a00210a01.opus"
    mx "\"M-Muy bien entonces. Si insistes...\""


translate english e2225a_9eb044ec:



    voice "voice/e22/25a00220a01.opus"
    mx "\"Actualmente estoy... es... esti...\""


translate english e2225a_49dfe7af:



    voice "voice/e22/25a00230a01.opus"
    mx "\"...Estimulando... la, emm... ingurgitada... esteee... de mi amo...\""


translate english e2225a_b1c3c771:


    xy "\"¿Ingurgitada qué?\""


translate english e2225a_57c756d8:



    voice "voice/e22/25a00240a01.opus"
    mx "\"...Verga...\""


translate english e2225a_018a1bcb:


    xy "\"¿Hmm? ¿Qué fue eso?\""


translate english e2225a_fa75c178:



    voice "voice/e22/25a00250a01.opus"
    mx "\"...T-Tu verga...\""


translate english e2225a_177e5dee:


    "Hearing Miyuki say the word \"cock\"con un atuendo de sirvienta me tiene a punto de explotar..."



translate english e2225a_fb99fc63:



    voice "voice/e22/25a00260a01.opus"
    mx "\"Estoy... estimulando... la... verga... de mi amo... usando... mis pechos...\""


translate english e2225a_a32fb0b3:



    voice "voice/e22/25a00270a01.opus"
    mx "\"Estoy juntando mis pechos... usando ambas manos... para emparedarla adentro... nng... y luego moviendo mi cuerpo arriba y abajo...\""


translate english e2225a_7bbca49b:


    "A pesar de su mirada tímidamente apartada, sus palabras empiezan a cobrar calor poco a poco, como si decir eso la excitara."


translate english e2225a_15873945:



    voice "voice/e22/25a00280a01.opus"
    mx "\"Mi saliva está dejando toda mojada la verga del Amo... Y ahora está goteando por la punta...\""


translate english e2225a_ee4e4abc:



    voice "voice/e22/25a00290a01.opus"
    mx "\"Sigue... palpitando... ¡Aaah! ¿Y se está poniendo muy caliente...?\""


translate english e2225a_01f650b5:



    voice "voice/e22/25a00300a01.opus"
    mx "\"¿Amo? Emm... ¿Mis pechos... se sienten bien?\""


translate english e2225a_fb3e4c5f:


    xy "\"S-Sí... Se sienten genial... ¡Nnng!\""


translate english e2225a_f2fdc073:


    "Mientras respondo, contengo las ganas crecientes de correrme."


translate english e2225a_f1135d3b:


    "Normalmente Miyuki jamás se humillaría frente a otra persona."


translate english e2225a_fc85faab:


    "Pero ahora mismo es mi humilde sirvienta, dándome servicio con sus pechos."


translate english e2225a_503f6294:


    "Entrecerrando los ojos bajo la tenue luz de las velas, puedo ver que su piel brilla de sudor, y—"


translate english e2225a_8251ef67:


    xy "\"Tus pezones están duros...\""


translate english e2225a_a10e1227:



    voice "voice/e22/25a00310a01.opus"
    mx "\"¡Y-Yo... me disculpo...!\""


translate english e2225a_7abfba68:


    "Sigue frotando sus hinchados pezones contra mi miembro, todo el tiempo con cara de que va a llorar de vergüenza."


translate english e2225a_ed0d64e7:



    voice "voice/e22/25a00320a01.opus"
    mx "\"Mientras... froto la verga del Amo... entre mis... pechos... he estado... imaginándola... dentro de mí...\""


translate english e2225a_94468613:



    voice "voice/e22/25a00330a01.opus"
    mx "\"El pensamiento... ha puesto duros mis pezones... y— ¡Nnnng! Mis partes bajas... están tan... calientes... ¡No puedo...!\""


translate english e2225a_c3c832d5:



    voice "voice/e22/25a00340a01.opus"
    mx "\"Nn... nnn... nn... Todo lo que hago es... restregarla contra mis pechos... ¿Así que por qué me estoy... excitando tanto...? ¡¡¡Aaaahh!!!\""


translate english e2225a_b139fcd6:



    voice "voice/e22/25a00350a01.opus"
    mx "\"¡No puedo—aguantar más—! Amo, ¿puedo... lamer su verga?\""


translate english e2225a_a5492c25:


    "Sinceramente, esto ya se siente bastante bien tal como está."


translate english e2225a_6e1021b4:


    "Pero puedo oír la desesperación en su voz mientras me mira hacia arriba, con los labios húmedos de saliva, casi como una perra en celo."


translate english e2225a_63307664:


    "Y no puedo negárselo."


translate english e2225a_3e4653d1:


    xy "\"Lámela hasta dejarla limpia.\""


translate english e2225a_9e264e23:



    voice "voice/e22/25a00360a01.opus"
    mx "\"¡S-Sí, señor!\""


translate english e2225a_cdbcd97c:



    voice "voice/e22/25a00370a01.opus"
    mx "\"Usaré mi boca sucia... para estimular la verga del Amo...\""


translate english e2225a_4791c39c:



    voice "voice/e22/25a00380a01.opus"
    mx "\"Sllrpp... slrrpp... sllrpp... mm...\""


translate english e2225a_7c1a1ad6:


    "Usa sus pechos para sujetar mi polla en su lugar mientras tantea la punta con la lengua."


translate english e2225a_c5351f02:


    "Su lengua se desliza sobre mi uretra, luego empieza a moverse en pequeños círculos alrededor del glande."


translate english e2225a_23167869:



    voice "voice/e22/25a00390a01.opus"
    mx "\"Mmllpp... mmm... mmmph... mm... mmllpp... sllrpp... mm... mmlllpppp...\""


translate english e2225a_6781173b:



    voice "voice/e22/25a00400a01.opus"
    mx "\"Amo, ¿cómo se siente mi lengua? ¿Le estoy lamiendo a su satisfacción?\""


translate english e2225a_3e720274:


    "En comparación con el placer envolvente de sus pechos, la atención sobre mi punta se siente tan intensa que mi cuerpo se estremece en respuesta."


translate english e2225a_ed2352d8:


    "Pero no puedo ser demasiado indulgente con ella, o perderé mi autoridad como su amo."


translate english e2225a_bb69bc24:


    xy "\"Sigue moviendo esas tetas.\""


translate english e2225a_e855c0ab:



    voice "voice/e22/25a00410a01.opus"
    mx "\"¡Oh, lo siento muchísimo! Mm... mmm... mm... mmph... slrrpphh... slllrrpppp...\""


translate english e2225a_265c9322:



    voice "voice/e22/25a00420a01.opus"
    mx "\"¡Mmmm... mmph... mm... aaah! Su verga se está poniendo aún más dura...!\""


translate english e2225a_8a4fb324:



    voice "voice/e22/25a00430a01.opus"
    mx "\"¡Sssllrrpppp... mmm! Está goteando presemen por la punta... Sllrpp...\""


translate english e2225a_3927ac89:


    "Balancea su cuerpo de arriba abajo, llevando mi polla aún más profundo en su boca."


translate english e2225a_f8a6d892:


    "Sus labios se aprietan alrededor de mi grosor, y pierdo la compostura rápidamente."


translate english e2225a_084dd4de:



    voice "voice/e22/25a00440a01.opus"
    mx "\"¡Sllrrppp... mmmph... mmpp... mm! ¡Mmmm! ¡Aaah! Está empujando... tan profundo... ¡Mmmph!\""


translate english e2225a_0f52153c:



    voice "voice/e22/25a00450a01.opus"
    mx "\"Haah... mmmnn... mmlllppp... mmmm! Amo, ¿esto le está haciendo venir?\""


translate english e2225a_c00ce22d:



    voice "voice/e22/25a00460a01.opus"
    mx "\"Con esta—mmmh, mmm—verga devastando mi boca— yo también estoy bastante excitada—¡¡¡AAAH!!!\""


translate english e2225a_e2c3e938:



    voice "voice/e22/25a00470a01.opus"
    mx "\"Lo siento... La forma en que su verga palpita casi dolorosamente... ¡Mmmph! ¡Mmmph, mmllppp! ¡Mmmllpppp!!!\""


translate english e2225a_87eba92d:



    voice "voice/e22/25a00480a01.opus"
    mx "\"Ya no puede contener su eyaculación, ¿verdad? Mmmn... ¿Va a llenarme la boca con su semen?\""


translate english e2225a_d3a32f8d:



    voice "voice/e22/25a00490a01.opus"
    mx "\"¡Claro! ¡Adelante! Slllrrppp... ssllrpp... Siéntase libre de... eyacular... en mi boca o—sllrpp—por todos mis pechos...\""


translate english e2225a_30ebddde:



    voice "voice/e22/25a00500a01.opus"
    mx "\"Donde quiera— ¡Aaah! Lo siento venir—slllrppp— ¡Aah! Su verga está palpitando—¡aah, aah, aah—!\""


translate english e2225a_064a412a:



    voice "voice/e22/25a00510a01.opus"
    mx "\"¡Aaahh... aah... mm... mmmph... mmm! Hay tanto... y está tan caliente... ¡Aah, aah, aah...!\""


translate english e2225a_27c500ab:


    "Mis fluidos blancos y turbios manchan su lengua rosada mientras disparo mi lujuria dentro de ella de una sola vez."


translate english e2225a_64817ceb:



    voice "voice/e22/25a00520a01.opus"
    mx "\"Mm... mmm... mmmm... mmm... mmngg... mmm... mm... slrp... mmph... mmm... sllrpp... mm... ¡phaah!\""


translate english e2225a_27095c1b:


    "El semen gotea de las comisuras de su boca mientras lucha por tragarlo todo."


translate english e2225a_63826235:


    "Mientras tanto, sigue apretando sus pechos a lo largo de mi miembro, exprimiendo hasta la última gota de mi carga."


translate english e2225a_bd764291:


    "Luego sorbe las últimas gotas extraviadas de semen, recogiéndolas todas en su boca."


translate english e2225a_62205e18:



    voice "voice/e22/25a00530a01.opus"
    mx "\"Amo... Muchash... graciash... por todo... su semen...\""


translate english e2225a_7b9f0018:



    voice "voice/e22/25a00540a01.opus"
    mx "\"¿Puedo... consumirlo...?\""


translate english e2225a_8040f138:


    xy "\"...¿Quieres tragarlo?\""


translate english e2225a_ea3f24f4:



    voice "voice/e22/25a00550a01.opus"
    mx "\"Shí.\""


translate english e2225a_bf554db4:



    voice "voice/e22/25a00560a01.opus"
    mx "\"Desheo beber el semen del Amo... ¿Puedo hasherlo?\""


translate english e2225a_f7182527:


    xy "\"Hmm...\""


translate english e2225a_1a927007:


    "Me mira, con la boca llena de mi semen."


translate english e2225a_68eecbbb:


    "Es tan sexy cómo suplica por beber mis fluidos... dan ganas de provocarla."


translate english e2225a_1343124c:


    xy "\"Lo quieres tanto, ¿eh?\""


translate english e2225a_84f0e87e:



    voice "voice/e22/25a00570a01.opus"
    mx "\"Shí... Quiero tragarlo...\""


translate english e2225a_14cac808:


    xy "\"¿No quieres saborearlo?\""


translate english e2225a_df2353a8:



    voice "voice/e22/25a00580a01.opus"
    mx "\"No, no es esho...\""


translate english e2225a_f3948e1c:



    voice "voice/e22/25a00590a01.opus"
    mx "\"Sholo quiero shintirlo... dentro de mi cuerpo... Sllrrpp...\""


translate english e2225a_81b63ce7:


    "La saliva gotea por su lengua, humedeciendo sus labios."


translate english e2225a_4ce64ed5:


    "Su parte inferior se retuerce con impaciencia."


translate english e2225a_af0c0ed5:


    "Es tan erótico que mi marchita erección empieza a hincharse de nuevo entre sus pechos."


translate english e2225a_6982bb2c:



    voice "voice/e22/25a00600a01.opus"
    mx "\"Apúreshe... Déjeme tragar su semen, Amo...\""


translate english e2225a_95d4024a:


    xy "\"¿Lo quieres tanto que se te está cayendo la baba por toda la cara?\""


translate english e2225a_b9e9621a:



    voice "voice/e22/25a00610a01.opus"
    mx "\"Shí... Por favor no me provoque... Por favor... She lo ruego...\""


translate english e2225a_ae21a51b:


    "Las lágrimas asoman a sus ojos."


translate english e2225a_9f137d24:


    "No tengo corazón para hacerla esperar más."


translate english e2225a_a3d65a6c:


    xy "\"...Vale, puedes tragarlo.\""


translate english e2225a_770138b7:



    voice "voice/e22/25a00620a01.opus"
    mx "\"¡Sh-Shí, Amo...! ¡Gracias, Amo!\""


translate english e2225a_a5f2e671:



    voice "voice/e22/25a00630a01.opus"
    mx "\"¡Mm... mmng... nnglpp... mm... nnhaah... aah... aaah...!\""


translate english e2225a_7f34c32b:



    voice "voice/e22/25a00640a01.opus"
    mx "\"Eso estuvo delicioso, Amo... Absolutamente sublime...\""


translate english e2225a_1d7fe7df:


    "Traga el semen, se estremece y me mira de nuevo con ojos extasiados."


translate english e2225a_0d10f7b3:


    "A estas alturas, ya no puedo detenerme."


translate english e2225a_674c93b3:



    voice "voice/e22/25a00650a01.opus"
    mx "\"¿Hmm? ¿Amo...?\""


translate english e2225a_3a5d92b4:


    xy "\"Mira qué mojada estás...\""


translate english e2225a_205bd44f:



    voice "voice/e22/25a00660a01.opus"
    mx "\"¡Aaah! No, no—\""


translate english e2225a_434ab064:


    "Le levanto la falda de un tirón y le bajo las bragas. Y en efecto, su coño está más mojado que una sauna."


translate english e2225a_5c3de0e9:


    xy "\"Una sirvienta tan desvergonzada como tú debería ser castigada.\""


translate english e2225a_4262d5b7:



    voice "voice/e22/25a00670a01.opus"
    mx "\"¿Castigada...?\""


translate english e2225a_c3539c95:


    "Fluidos femeninos gotean por sus muslos."


translate english e2225a_3eaf5316:


    "Su expresión no es de duda, sino de ansia."


translate english e2225a_b004c6af:


    "A pesar de mi reciente orgasmo, mi erección ya ha vuelto a hincharse a su antigua gloria—"


translate english e2225a_7bde228e:



    voice "voice/e22/25a00680a01.opus"
    mx "\"¡¡¡AAAHH!!!\""


translate english e2225a_8f5651b2:


    "—así que se la meto de golpe."


translate english e2225a_da2deec5:



    voice "voice/e22/25a00690a01.opus"
    mx "\"¡¡¡Amo!!! Esto es demasiado repentino— ¡¡¡Nnnnnggg...!!!\""


translate english e2225a_3a02233c:



    voice "voice/e22/25a00700a01.opus"
    mx "\"¡Nnnngg! ¡No... esperaba... que lo metiera... tan rápido...! ¡Nnhaah! ¡Nnnn! ¡Nnnnggh!\""


translate english e2225a_4c3dcaf8:



    voice "voice/e22/25a00710a01.opus"
    mx "\"¡Es tan—nnng—intenso—nnnnn—desde el principio—!\""


translate english e2225a_8823b0c7:


    xy "\"Pero lo querías, ¿no?\""


translate english e2225a_b4cb7933:



    voice "voice/e22/25a00720a01.opus"
    mx "\"¡Sí, pero—no debo!!!\""


translate english e2225a_a777b31e:



    voice "voice/e22/25a00730a01.opus"
    mx "\"¡No debo... a-alcanzar el orgasmo... antes que mi Amo...! ¡Aaaahh!!!\""


translate english e2225a_4b77f2b5:


    "Intenta prepararse contra el placer."


translate english e2225a_674cadbb:


    "Pero su cuerpo se retuerce por voluntad propia, buscando saciar su lujuria."


translate english e2225a_9a76e2fe:


    "Es tan adorable que no puedo evitar hundir mi polla aún más profundo en ella."


translate english e2225a_c4644765:



    voice "voice/e22/25a00740a01.opus"
    mx "\"¡Haaahh! ¡Es tan profundo— No puedo soportarlo—AAAAAHHH!!!\""


translate english e2225a_caf46c01:



    voice "voice/e22/25a00750a01.opus"
    mx "\"¡Amo—su verga es tan grande— Se siente tan bien que creo que podría desmayarme— AAAH!\""


translate english e2225a_d2d9ee99:


    "Empiezo a embestir más rápido, y la habitación se llena con el sonido de la carne chocando."


translate english e2225a_4c6a5ba4:


    "Aprieta los puños cada vez más fuerte, temblando de placer."


translate english e2225a_5e002d3a:



    voice "voice/e22/25a00760a01.opus"
    mx "\"¡Haaah! ¡Aah! ¡Aah! ¡Aah! ¡Aah! ¡Ay, Dios! ¡Digo, ay, cielos! ¡No puedo! ¡Callarme!!!\""


translate english e2225a_01383aa2:



    voice "voice/e22/25a00770a01.opus"
    mx "\"¡Eso! ¡Se! ¡Siente! ¡Tan! ¡Increíblemente! ¡Bien! ¡Amo!!!\""


translate english e2225a_4fc12bdf:



    voice "voice/e22/25a00780a01.opus"
    mx "\"¡Ay no! ¡Voy a—aaahh! ¡Basta! ¡No, no, no, no—!\""


translate english e2225a_ca86f892:



    voice "voice/e22/25a00790a01.opus"
    mx "\"Amo—yo—mi coño no puede soportarlo— Voy a venirme... Voy a... ¡Voy a venirme— AAAAHHH!\""


translate english e2225a_2a950213:



    voice "voice/e22/25a00800a01.opus"
    mx "\"¡Me estoy viiiinieeeendoooo—!!!\""


translate english e2225a_24e47e7a:



    voice "voice/e22/25a00810a01.opus"
    mx "\"¡Aah... aaahh... nnn... nngghh... nnn...! ¡Aaahh... nnnggh... nnn... nnnn...!\""


translate english e2225a_76f054af:



    voice "voice/e22/25a00820a01.opus"
    mx "\"Aah, aah... nnng... nnn... gggh... aah... nnn... A-Amo... me disculpo...\""


translate english e2225a_4c9636f9:



    voice "voice/e22/25a00830a01.opus"
    mx "\"Nnng... Lo sé... Se supone que... debía servirlo... No debía... sucumbir... nnnn... a mi propio placer...\""


translate english e2225a_b3826297:



    voice "voice/e22/25a00840a01.opus"
    mx "\"Pero no pude evitarlo... ¡Nnnng! ¡Su verga! Se sintió tan bien... ¡Nnnngg!!!\""


translate english e2225a_dac70de5:



    voice "voice/e22/25a00850a01.opus"
    mx "\"¡No pude... detener...me...! ¡Nnnng! ¡De alcanzar... el c-clímax antes que usted...!\""


translate english e2225a_c71ac7b2:


    "Incluso en medio de su orgasmo, su voz aún suena llorosa."


translate english e2225a_d9e866ae:


    "Es tan sexy... tan linda... tan perfecta... que no puedo detenerme."


translate english e2225a_3d081812:


    xy "\"Miyuki...\""



translate english e2225a_e78a68d0:



    voice "voice/e22/25a00860a01.opus"
    mx "\"Sí, Am—\""


translate english e2225a_878c6d31:


    xy "\"No más juegos de rol. Solo seamos nosotros ahora, ¿sí?\""


translate english e2225a_18670cae:



    voice "voice/e22/25a00880a01.opus"
    mx "\"\"\"......\"\"\""


translate english e2225a_a2a2abf4:


    xy "\"¿Demasiado vergonzoso?\""


translate english e2225a_7f43f385:



    voice "voice/e22/25a00890a01.opus"
    mx "\"Pues sí... Hacerlo con este atuendo es tan raro... Pero se siente, o sea, mucho más caliente que lo normal...\""


translate english e2225a_bf2405ab:



    voice "voice/e22/25a00900a01.opus"
    mx "\"Así que solo me preocupa que... bueno... pienses que soy una especie de pervertida sexual...\""


translate english e2225a_0accd139:


    xy "\"\"\"......\"\"\""


translate english e2225a_8e385e01:



    voice "voice/e22/25a00910a01.opus"
    mx "\"¿Shinichi...?\""


translate english e2225a_964f4093:


    "Suena un poco asustada."


translate english e2225a_573a9cf2:


    "Pero para mí, es adorable."


translate english e2225a_50320c75:


    xy "\"Aunque seas una pervertida sexual, sigo queriendo estar contigo.\""


translate english e2225a_7e878e82:



    voice "voice/e22/25a00920a01.opus"
    mx "\"Pero...\""


translate english e2225a_409520f0:


    xy "\"¡Lo prometo, nunca podría odiarte por eso!\""


translate english e2225a_6a9201b0:



    voice "voice/e22/25a00930a01.opus"
    mx "\"...Vale.\""


translate english e2225a_26a4790a:



    voice "voice/e22/25a00940a01.opus"
    mx "\"Sí, tienes razón.\""


translate english e2225a_d944fa61:



    voice "voice/e22/25a00950a01.opus"
    mx "\"Después de todo, me lo prometiste con ese beso.\""


translate english e2225a_58c202a7:



    voice "voice/e22/25a00960a01.opus"
    mx "\"Estaremos juntos por siempre...\""


translate english e2225a_eb583b02:


    "Es verdad."


translate english e2225a_4bd443a0:


    "Miyuki y yo estamos destinados a estar juntos."


translate english e2225a_6e155563:


    xy "\"Solo tú y yo, ¿sí?\""


translate english e2225a_11cd31ff:



    voice "voice/e22/25a00970a01.opus"
    mx "\"...Vale.\""


translate english e2225a_67c291d4:


    "Espero a que asienta, y luego empiezo a embestir otra vez."


translate english e2225a_ce771177:



    voice "voice/e22/25a00980a01.opus"
    mx "\"¡Hnnnn! ¡Nn... nnngghh...!\""


translate english e2225a_1a71d604:



    voice "voice/e22/25a00990a01.opus"
    mx "\"Es simplemente tan... increíble... Tu verga... se siente tan bien... ¡Aaah!\""


translate english e2225a_1b2d3ee1:



    voice "voice/e22/25a01000a01.opus"
    mx "\"Oye... Shinichi... ¡¡¡Nnnnggg! También se siente bien para ti... ¿verdad...?\""


translate english e2225a_0af5bb4c:


    "Después del orgasmo, su coño está más apretado y húmedo que nunca."


translate english e2225a_fb52c57d:


    "No podría replicarlo ni usando las dos manos."


translate english e2225a_e998ada1:


    "Es como si encajáramos perfectamente..."


translate english e2225a_bc16d53b:



    voice "voice/e22/25a01010a01.opus"
    mx "\"¡Mi cuerpo... existe... para ti... y solo para ti...!\""


translate english e2225a_06259d09:



    voice "voice/e22/25a01020a01.opus"
    mx "\"¡Usando este... atuendo desvergonzado...! ¡Diciendo todas estas... cosas sucias...!\""


translate english e2225a_4f7a19a9:



    voice "voice/e22/25a01030a01.opus"
    mx "\"¡Lo hago... todo por ti!\""


translate english e2225a_54f04a61:



    voice "voice/e22/25a01040a01.opus"
    mx "\"¡Aaahh! Tu verga... ¡Ahora está durísima! ¡Justo ahí! ¡Nnhaah! ¡Aah! ¡Ay, Dios!\""


translate english e2225a_3261009f:



    voice "voice/e22/25a01050a01.opus"
    mx "\"¡Justo ahí, hasta el fondo... Se siente tan bien que... no puedo pensar bien...!\""


translate english e2225a_195187d6:



    voice "voice/e22/25a01060a01.opus"
    mx "\"¡Nnngh! ¡Nnn! ¿También se siente bien para ti? ¿Mi coño se siente bien...?\""


translate english e2225a_a04f6bf1:


    "Sinceramente, a estas alturas, se siente tan increíble que estoy a punto de perder el control."


translate english e2225a_2957b5f9:



    voice "voice/e22/25a01070a01.opus"
    mx "\"Nnng... Bien... Me alegra... Solo... olvida todo lo demás...\""


translate english e2225a_8b337d4f:



    voice "voice/e22/25a01080a01.opus"
    mx "\"Concéntrate en mí... y solo en mí... Es... todo lo que pido...\""


translate english e2225a_34281cd2:



    voice "voice/e22/25a01090a01.opus"
    mx "\"¡Solo hazme TUYA...!\""


translate english e2225a_16756e18:


    "Cuando llego a mis límites, decido—"



translate english e2225a_b166616d:



    voice "voice/e22/25a00870a01.opus"
    xy "\"Llámame Shinichi.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
