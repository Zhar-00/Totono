

translate english e2225a_1393afeb:


    xy "\"Please... Comfort me.\""


translate english e2225a_b7deb526:



    voice "voice/e22/25a00010a01.opus"
    mx "\"Very well. In that case...\""


translate english e2225a_4326a9ef:



    voice "voice/e22/25a00020a01.opus"
    mx "\"...Whew...\""


translate english e2225a_e56fb695:


    "Toma aire."


translate english e2225a_65a2d9c6:


    "Aunque está demasiado oscuro para ver, me doy cuenta de que se inclina profundamente."


translate english e2225a_6251166a:



    voice "voice/e22/25a00030a01.opus"
    mx "\"I shall serve you to the best of my ability.\""


translate english e2225a_ea998eba:


    "Oigo el revoloteo de la ropa."


translate english e2225a_6b965fc4:


    "Algo se retuerce."


translate english e2225a_64377b11:


    "Se desabrocha un cinturón."


translate english e2225a_6229021f:


    "Siento un peso sobre mi entrepierna."


translate english e2225a_cce6fb53:


    "Mi polla ya ha empezado a levantar la cabeza, y lo siguiente que sé—"


translate english e2225a_9518cd9d:


    "—algo suave la envuelve."


translate english e2225a_14a3ab23:


    "¿Es... es que ella...?"


translate english e2225a_7eb755ec:



    voice "voice/e22/25a00040a01.opus"
    mx "\"Umm... This doesn't hurt, does it, Master?\""


translate english e2225a_37827876:


    xy "\"No, not at all. It feels amazing, actually.\""


translate english e2225a_c98ddcf3:



    voice "voice/e22/25a00050a01.opus"
    mx "\"I'm glad. Now then...\""


translate english e2225a_4ed948af:



    voice "voice/e22/25a00060a01.opus"
    mx "\"Time to service you to completion.\""


translate english e2225a_d27eeafa:


    xy "\"Huh?\""


translate english e2225a_125431cf:


    "Siento aumentar la presión alrededor de mi erección que se va endureciendo."


translate english e2225a_002fc459:


    "Vaya..."


translate english e2225a_d6646b0a:


    "Si tan solo no estuviera tan oscuro aquí..."


translate english e2225a_e27b0d78:


    "Tengo que arreglar esto de alguna manera."


translate english e2225a_b9ee347e:


    "En esta posición, no hay forma de que alcance el interruptor de la luz..."


translate english e2225a_0214a1a5:


    "Si tan solo hubiera otra fuente de luz..."


translate english e2225a_3c76b111:


    "¡Eso es!"


translate english e2225a_4292514e:



    voice "voice/e22/25a00070a01.opus"
    mx "\"Hmm? Master?\""


translate english e2225a_953b6a1c:



    voice "voice/e22/25a00080a01.opus"
    mx "\"Aaah!!!\""


translate english e2225a_fbd33f6c:


    "¡Tal como lo planeé!"


translate english e2225a_a7f171c8:


    "Bajo la tenue luz de las velas, puedo ver a Miyuki sonrojada mientras intenta hacerme una rusa con su atuendo de sirvienta."


translate english e2225a_5be5de8d:


    "Sus pechos no son grandes ni mucho menos, pero se esfuerza al máximo de todos modos—y eso lo hace aún más excitante."


translate english e2225a_7f36dca1:



    voice "voice/e22/25a00090a01.opus"
    mx "\"This is so embarrassing...\""


translate english e2225a_4638dd24:


    xy "\"No way! It's cute.\""


translate english e2225a_2615bda2:



    voice "voice/e22/25a00100a01.opus"
    mx "\"...Nnn...!\""


translate english e2225a_d20895be:



    voice "voice/e22/25a00110a01.opus"
    mx "\"But I look so stupid wearing this...\""


translate english e2225a_09d95861:


    xy "\"You look great. Seriously.\""


translate english e2225a_408a7c5d:



    voice "voice/e22/25a00120a01.opus"
    mx "\"\"\"......\"\"\""


translate english e2225a_554d541d:



    voice "voice/e22/25a00130a01.opus"
    mx "\"Really?\""


translate english e2225a_a98558e6:


    xy "\"Really really.\""


translate english e2225a_73de08fd:


    "Como prueba, mi erección gana terreno rápidamente."


translate english e2225a_042f7c6f:


    xy "\"I'm begging you, please don't stop.\""


translate english e2225a_14117896:



    voice "voice/e22/25a00140a01.opus"
    mx "\"...Okay, fine, I'll trust you.\""


translate english e2225a_6bc6f12b:



    voice "voice/e22/25a00150a01.opus"
    mx "\"I mean... Ahem...\""


translate english e2225a_d5abe852:



    voice "voice/e22/25a00160a01.opus"
    mx "\"Understood, Master.\""


translate english e2225a_e7900352:



    voice "voice/e22/25a00170a01.opus"
    mx "\"Now then, allow me to continue.\""


translate english e2225a_a48d3a2b:


    "Con la mirada apartada con timidez, Miyuki sube y baja mi polla entre sus pechos."


translate english e2225a_ac01e020:


    "Sus almohadillados montículos envuelven mi miembro."


translate english e2225a_858d1f4b:


    "El estilo del atuendo de sirvienta también realza mucho su busto..."


translate english e2225a_a6fac204:


    "Además, la tenue luz de las velas le da a la habitación un ambiente sensual."


translate english e2225a_6b9a0d5a:


    "Todo es tan surrealista que siento que me exalto tanto emocional como físicamente."


translate english e2225a_aec50dc0:



    voice "voice/e22/25a00180a01.opus"
    mx "\"How am I doing, Master?\""


translate english e2225a_bb86fac7:


    "Sus labios se contraen con las palabras."


translate english e2225a_0558a37a:


    "Being called \"Master\"ya... empieza a marearme un poco."



translate english e2225a_aa03996e:


    "En este momento, ella es mi sirvienta."


translate english e2225a_2398743a:


    "Y está de rodillas con un atuendo de sirvienta y mi polla entre sus pechos, explícitamente solo para mi placer."


translate english e2225a_41a92303:



    voice "voice/e22/25a00190a01.opus"
    mx "\"How is it? Too much pressure?\""


translate english e2225a_88198a01:


    xy "\"Hey, Miyuki... Can you explain to me what it is you're doing right now?\""


translate english e2225a_788b322f:



    voice "voice/e22/25a00200a01.opus"
    mx "\"What? Explain to you... what I'm doing?\""


translate english e2225a_5212bbfa:


    "Y en efecto, parece resistirse a la idea..."


translate english e2225a_b031c904:


    "Pero sé que está comprometida con esta personalidad de sirvienta."


translate english e2225a_870ea830:


    "Si la presiono un poco más, seguro que cede."


translate english e2225a_acbe04ff:


    xy "\"I want you to say it.\""


translate english e2225a_65ca7018:


    xy "\"I'm begging you, my sweet little maid.\""


translate english e2225a_d2dae01d:


    "Me trago el orgullo y suplico."


translate english e2225a_f9c20289:


    "Por suerte, me ahorra más vergüenza."


translate english e2225a_d2114047:



    voice "voice/e22/25a00210a01.opus"
    mx "\"V-Very well then. If you insist...\""


translate english e2225a_9eb044ec:



    voice "voice/e22/25a00220a01.opus"
    mx "\"I am presently... st... sti...\""


translate english e2225a_49dfe7af:



    voice "voice/e22/25a00230a01.opus"
    mx "\"...Stimulating... my master's, um... engorged... er...\""


translate english e2225a_b1c3c771:


    xy "\"Engorged what?\""


translate english e2225a_57c756d8:



    voice "voice/e22/25a00240a01.opus"
    mx "\"...Cock...\""


translate english e2225a_018a1bcb:


    xy "\"Hmm? What was that?\""


translate english e2225a_fa75c178:



    voice "voice/e22/25a00250a01.opus"
    mx "\"...Y-Your cock...\""


translate english e2225a_177e5dee:


    "Hearing Miyuki say the word \"cock\"con un atuendo de sirvienta me tiene a punto de explotar..."



translate english e2225a_fb99fc63:



    voice "voice/e22/25a00260a01.opus"
    mx "\"I am... stimulating... my master's... cock... using... my breasts...\""


translate english e2225a_a32fb0b3:



    voice "voice/e22/25a00270a01.opus"
    mx "\"I'm pressing my breasts together... using both hands... to sandwich it inside... nng... and then moving my body up and down...\""


translate english e2225a_7bbca49b:


    "A pesar de su mirada tímidamente apartada, sus palabras empiezan a cobrar calor poco a poco, como si decir eso la excitara."


translate english e2225a_15873945:



    voice "voice/e22/25a00280a01.opus"
    mx "\"My saliva is making Master's cock all wet... And now it's leaking from the tip...\""


translate english e2225a_ee4e4abc:



    voice "voice/e22/25a00290a01.opus"
    mx "\"It keeps... twitching... Aaah! And it's getting really warm...?\""


translate english e2225a_01f650b5:



    voice "voice/e22/25a00300a01.opus"
    mx "\"Master? Um... Do my breasts... feel good?\""


translate english e2225a_fb3e4c5f:


    xy "\"Y-Yeah... They feel great... Nnng!\""


translate english e2225a_f2fdc073:


    "Mientras respondo, contengo las ganas crecientes de correrme."


translate english e2225a_f1135d3b:


    "Normalmente Miyuki jamás se humillaría frente a otra persona."


translate english e2225a_fc85faab:


    "Pero ahora mismo es mi humilde sirvienta, dándome servicio con sus pechos."


translate english e2225a_503f6294:


    "Entrecerrando los ojos bajo la tenue luz de las velas, puedo ver que su piel brilla de sudor, y—"


translate english e2225a_8251ef67:


    xy "\"Your nipples are hard...\""


translate english e2225a_a10e1227:



    voice "voice/e22/25a00310a01.opus"
    mx "\"I... I apologize...!\""


translate english e2225a_7abfba68:


    "Sigue frotando sus hinchados pezones contra mi miembro, todo el tiempo con cara de que va a llorar de vergüenza."


translate english e2225a_ed0d64e7:



    voice "voice/e22/25a00320a01.opus"
    mx "\"As I'm... rubbing Master's cock... between my... breasts... I've been... imagining it... inside me...\""


translate english e2225a_94468613:



    voice "voice/e22/25a00330a01.opus"
    mx "\"The thought... has made my nipples hard... and— Nnnng! My nether regions... are so... hot... I can't...!\""


translate english e2225a_c3c832d5:



    voice "voice/e22/25a00340a01.opus"
    mx "\"Nn... nnn... nn... All I'm doing is... rubbing it against my breasts... So why am I... getting so... aroused...? Aaaahh!!!\""


translate english e2225a_b139fcd6:



    voice "voice/e22/25a00350a01.opus"
    mx "\"I can't—hold back any longer—! Master, may I... lick your cock?\""


translate english e2225a_a5492c25:


    "Sinceramente, esto ya se siente bastante bien tal como está."


translate english e2225a_6e1021b4:


    "Pero puedo oír la desesperación en su voz mientras me mira hacia arriba, con los labios húmedos de saliva, casi como una perra en celo."


translate english e2225a_63307664:


    "Y no puedo negárselo."


translate english e2225a_3e4653d1:


    xy "\"Lick it clean.\""


translate english e2225a_9e264e23:



    voice "voice/e22/25a00360a01.opus"
    mx "\"Y-Yes, sir!\""


translate english e2225a_cdbcd97c:



    voice "voice/e22/25a00370a01.opus"
    mx "\"I shall use my dirty mouth... to stimulate Master's cock...\""


translate english e2225a_4791c39c:



    voice "voice/e22/25a00380a01.opus"
    mx "\"Sllrpp... slrrpp... sllrpp... mm...\""


translate english e2225a_7c1a1ad6:


    "Usa sus pechos para sujetar mi polla en su lugar mientras tantea la punta con la lengua."


translate english e2225a_c5351f02:


    "Su lengua se desliza sobre mi uretra, luego empieza a moverse en pequeños círculos alrededor del glande."


translate english e2225a_23167869:



    voice "voice/e22/25a00390a01.opus"
    mx "\"Mmllpp... mmm... mmmph... mm... mmllpp... sllrpp... mm... mmlllpppp...\""


translate english e2225a_6781173b:



    voice "voice/e22/25a00400a01.opus"
    mx "\"Master, how does my tongue feel? Am I licking you to your satisfaction?\""


translate english e2225a_3e720274:


    "En comparación con el placer envolvente de sus pechos, la atención sobre mi punta se siente tan intensa que mi cuerpo se estremece en respuesta."


translate english e2225a_ed2352d8:


    "Pero no puedo ser demasiado indulgente con ella, o perderé mi autoridad como su amo."


translate english e2225a_bb69bc24:


    xy "\"Keep moving those tits.\""


translate english e2225a_e855c0ab:



    voice "voice/e22/25a00410a01.opus"
    mx "\"Oh, I'm terribly sorry! Mm... mmm... mm... mmph... slrrpphh... slllrrpppp...\""


translate english e2225a_265c9322:



    voice "voice/e22/25a00420a01.opus"
    mx "\"Mmmm... mmph... mm... aaah! Your cock is getting even harder...!\""


translate english e2225a_8a4fb324:



    voice "voice/e22/25a00430a01.opus"
    mx "\"Sssllrrpppp... mmm! You're leaking pre-cum from the tip... Sllrpp...\""


translate english e2225a_3927ac89:


    "Balancea su cuerpo de arriba abajo, llevando mi polla aún más profundo en su boca."


translate english e2225a_f8a6d892:


    "Sus labios se aprietan alrededor de mi grosor, y pierdo la compostura rápidamente."


translate english e2225a_084dd4de:



    voice "voice/e22/25a00440a01.opus"
    mx "\"Sllrrppp... mmmph... mmpp... mm! Mmmm! Aaah! You're thrusting... so deep... Mmmph!\""


translate english e2225a_0f52153c:



    voice "voice/e22/25a00450a01.opus"
    mx "\"Haah... mmmnn... mmlllppp... mmmm! Master, is this getting you off?\""


translate english e2225a_c00ce22d:



    voice "voice/e22/25a00460a01.opus"
    mx "\"With this—mmmh, mmm—cock ravaging my mouth— I'm pretty aroused myse—AAAH!!!\""


translate english e2225a_e2c3e938:



    voice "voice/e22/25a00470a01.opus"
    mx "\"I can feel it... The way your cock is throbbing almost painfully... Mmmph! Mmmph, mmllppp! Mmmllpppp!!!\""


translate english e2225a_87eba92d:



    voice "voice/e22/25a00480a01.opus"
    mx "\"You can't hold your ejaculation back any longer, yes? Mmmn... Are you going to fill my mouth with your semen?\""


translate english e2225a_d3a32f8d:



    voice "voice/e22/25a00490a01.opus"
    mx "\"Certainly! Be my guest! Slllrrppp... ssllrpp... Feel free to... ejaculate... in my mouth or—sllrpp—all over my breasts...\""


translate english e2225a_30ebddde:



    voice "voice/e22/25a00500a01.opus"
    mx "\"Wherever you like— Aaah! I feel it coming—slllrppp— Aah! Your cock is twitching—aah, aah, aah—!\""


translate english e2225a_064a412a:



    voice "voice/e22/25a00510a01.opus"
    mx "\"Aaahh... aah... mm... mmmph... mmm! There's so much... and it's so warm... Aah, aah, aah...!\""


translate english e2225a_27c500ab:


    "Mis fluidos blancos y turbios manchan su lengua rosada mientras disparo mi lujuria dentro de ella de una sola vez."


translate english e2225a_64817ceb:



    voice "voice/e22/25a00520a01.opus"
    mx "\"Mm... mmm... mmmm... mmm... mmngg... mmm... mm... slrp... mmph... mmm... sllrpp... mm... phaah!\""


translate english e2225a_27095c1b:


    "El semen gotea de las comisuras de su boca mientras lucha por tragarlo todo."


translate english e2225a_63826235:


    "Mientras tanto, sigue apretando sus pechos a lo largo de mi miembro, exprimiendo hasta la última gota de mi carga."


translate english e2225a_bd764291:


    "Luego sorbe las últimas gotas extraviadas de semen, recogiéndolas todas en su boca."


translate english e2225a_62205e18:



    voice "voice/e22/25a00530a01.opus"
    mx "\"Mashter... Thank you... sho much... for all... of your shemen...\""


translate english e2225a_7b9f0018:



    voice "voice/e22/25a00540a01.opus"
    mx "\"May I... conshume it...?\""


translate english e2225a_8040f138:


    xy "\"...You want to swallow it?\""


translate english e2225a_ea3f24f4:



    voice "voice/e22/25a00550a01.opus"
    mx "\"Yesh.\""


translate english e2225a_bf554db4:



    voice "voice/e22/25a00560a01.opus"
    mx "\"I wish to drink Mashter's shemen... May I do sho?\""


translate english e2225a_f7182527:


    xy "\"Hmm...\""


translate english e2225a_1a927007:


    "Me mira, con la boca llena de mi semen."


translate english e2225a_68eecbbb:


    "Es tan sexy cómo suplica por beber mis fluidos... dan ganas de provocarla."


translate english e2225a_1343124c:


    xy "\"You want it that badly, huh?\""


translate english e2225a_84f0e87e:



    voice "voice/e22/25a00570a01.opus"
    mx "\"Yesh... I want to shwallow it...\""


translate english e2225a_14cac808:


    xy "\"You don't want to savor it?\""


translate english e2225a_df2353a8:



    voice "voice/e22/25a00580a01.opus"
    mx "\"No, it'sh not that...\""


translate english e2225a_f3948e1c:



    voice "voice/e22/25a00590a01.opus"
    mx "\"I jusht want to feel it... inshide my body... Sllrrpp...\""


translate english e2225a_81b63ce7:


    "La saliva gotea por su lengua, humedeciendo sus labios."


translate english e2225a_4ce64ed5:


    "Su parte inferior se retuerce con impaciencia."


translate english e2225a_af0c0ed5:


    "Es tan erótico que mi marchita erección empieza a hincharse de nuevo entre sus pechos."


translate english e2225a_6982bb2c:



    voice "voice/e22/25a00600a01.opus"
    mx "\"Pleashe hurry... Let me shwallow your shemen, Mashter...\""


translate english e2225a_95d4024a:


    xy "\"You want it so bad, you're getting drool all over your face?\""


translate english e2225a_b9e9621a:



    voice "voice/e22/25a00610a01.opus"
    mx "\"Yesh... Pleashe don't teashe me... Pleashe... I'm begging you...\""


translate english e2225a_ae21a51b:


    "Las lágrimas asoman a sus ojos."


translate english e2225a_9f137d24:


    "No tengo corazón para hacerla esperar más."


translate english e2225a_a3d65a6c:


    xy "\"...Okay, you can swallow it.\""


translate english e2225a_770138b7:



    voice "voice/e22/25a00620a01.opus"
    mx "\"Y-Yesh, Mashter...! Thank you, Mashter!\""


translate english e2225a_a5f2e671:



    voice "voice/e22/25a00630a01.opus"
    mx "\"Mm... mmng... nnglpp... mm... nnhaah... aah... aaah...!\""


translate english e2225a_7f34c32b:



    voice "voice/e22/25a00640a01.opus"
    mx "\"That was delicious, Master... Absolutely sublime...\""


translate english e2225a_1d7fe7df:


    "Traga el semen, se estremece y me mira de nuevo con ojos extasiados."


translate english e2225a_0d10f7b3:


    "A estas alturas, ya no puedo detenerme."


translate english e2225a_674c93b3:



    voice "voice/e22/25a00650a01.opus"
    mx "\"Hmm? Master...?\""


translate english e2225a_3a5d92b4:


    xy "\"Look how wet you are...\""


translate english e2225a_205bd44f:



    voice "voice/e22/25a00660a01.opus"
    mx "\"Aaah! No, don't—\""


translate english e2225a_434ab064:


    "Le levanto la falda de un tirón y le bajo las bragas. Y en efecto, su coño está más mojado que una sauna."


translate english e2225a_5c3de0e9:


    xy "\"A shameless maid like you ought to be punished.\""


translate english e2225a_4262d5b7:



    voice "voice/e22/25a00670a01.opus"
    mx "\"Punished...?\""


translate english e2225a_c3539c95:


    "Fluidos femeninos gotean por sus muslos."


translate english e2225a_3eaf5316:


    "Su expresión no es de duda, sino de ansia."


translate english e2225a_b004c6af:


    "A pesar de mi reciente orgasmo, mi erección ya ha vuelto a hincharse a su antigua gloria—"


translate english e2225a_7bde228e:



    voice "voice/e22/25a00680a01.opus"
    mx "\"AAAAHH!!!\""


translate english e2225a_8f5651b2:


    "—así que se la meto de golpe."


translate english e2225a_da2deec5:



    voice "voice/e22/25a00690a01.opus"
    mx "\"Master!!! This is too sudden— Nnnnnggg...!!!\""


translate english e2225a_3a02233c:



    voice "voice/e22/25a00700a01.opus"
    mx "\"Nnnngg! I wasn't... expecting you... to put it in... so fast...! Nnhaah! Nnnn! Nnnnggh!\""


translate english e2225a_4c3dcaf8:



    voice "voice/e22/25a00710a01.opus"
    mx "\"It's so—nnng—intense—nnnnn—right out the gate—!\""


translate english e2225a_8823b0c7:


    xy "\"But you wanted it, didn't you?\""


translate english e2225a_b4cb7933:



    voice "voice/e22/25a00720a01.opus"
    mx "\"Yes, but—I mustn't!!!\""


translate english e2225a_a777b31e:



    voice "voice/e22/25a00730a01.opus"
    mx "\"I mustn't... a-achieve orgasm... before my Master can... Aaaahh!!!\""


translate english e2225a_4b77f2b5:


    "Intenta prepararse contra el placer."


translate english e2225a_674cadbb:


    "Pero su cuerpo se retuerce por voluntad propia, buscando saciar su lujuria."


translate english e2225a_9a76e2fe:


    "Es tan adorable que no puedo evitar hundir mi polla aún más profundo en ella."


translate english e2225a_c4644765:



    voice "voice/e22/25a00740a01.opus"
    mx "\"Haaahh! It's so deep— I can't take it—AAAAAHHH!!!\""


translate english e2225a_caf46c01:



    voice "voice/e22/25a00750a01.opus"
    mx "\"Master—your cock is so large— It feels so good, I think I might pass out— AAAH!\""


translate english e2225a_d2d9ee99:


    "Empiezo a embestir más rápido, y la habitación se llena con el sonido de la carne chocando."


translate english e2225a_4c6a5ba4:


    "Aprieta los puños cada vez más fuerte, temblando de placer."


translate english e2225a_5e002d3a:



    voice "voice/e22/25a00760a01.opus"
    mx "\"Haaah! Aah! Aah! Aah! Aah! Oh god! I mean, oh goodness! I can't! Keep quiet!!!\""


translate english e2225a_01383aa2:



    voice "voice/e22/25a00770a01.opus"
    mx "\"That! Feels! So! Incredibly! Good! Master!!!\""


translate english e2225a_4fc12bdf:



    voice "voice/e22/25a00780a01.opus"
    mx "\"Oh no! I'm going to—aaahh! Stop! No, no, no, no—!\""


translate english e2225a_ca86f892:



    voice "voice/e22/25a00790a01.opus"
    mx "\"Master—I—my pussy can't take it— I'm gonna cum... I'm gonna... I'm gonna cum— AAAAHHH!\""


translate english e2225a_2a950213:



    voice "voice/e22/25a00800a01.opus"
    mx "\"I'm cuuuummmmmiiiinnnnngggggg—!!!\""


translate english e2225a_24e47e7a:



    voice "voice/e22/25a00810a01.opus"
    mx "\"Aah... aaahh... nnn... nngghh... nnn...! Aaahh... nnnggh... nnn... nnnn...!\""


translate english e2225a_76f054af:



    voice "voice/e22/25a00820a01.opus"
    mx "\"Aah, aah... nnng... nnn... gggh... aah... nnn... M-Master... I apologize...\""


translate english e2225a_4c9636f9:



    voice "voice/e22/25a00830a01.opus"
    mx "\"Nnng... I know... I was supposed... to service you... I wasn't meant... to succumb... nnnn... to my own pleasure...\""


translate english e2225a_b3826297:



    voice "voice/e22/25a00840a01.opus"
    mx "\"But I couldn't help it... Nnnng! Your cock! Felt so good... Nnnngg!!!\""


translate english e2225a_dac70de5:



    voice "voice/e22/25a00850a01.opus"
    mx "\"I couldn't... stop my...self...! Nnnng! From reaching... c-climax ahead of you...!\""


translate english e2225a_c71ac7b2:


    "Incluso en medio de su orgasmo, su voz aún suena llorosa."


translate english e2225a_d9e866ae:


    "Es tan sexy... tan linda... tan perfecta... que no puedo detenerme."


translate english e2225a_3d081812:


    xy "\"Miyuki...\""



translate english e2225a_e78a68d0:



    voice "voice/e22/25a00860a01.opus"
    mx "\"Yes, Mas—\""


translate english e2225a_878c6d31:


    xy "\"No more roleplay. Let's just be us right now, okay?\""


translate english e2225a_18670cae:



    voice "voice/e22/25a00880a01.opus"
    mx "\"\"\"......\"\"\""


translate english e2225a_a2a2abf4:


    xy "\"Too embarrassed?\""


translate english e2225a_7f43f385:



    voice "voice/e22/25a00890a01.opus"
    mx "\"Well, yeah... Doing it in this outfit is so weird... But it feels, like, way hotter than normal...\""


translate english e2225a_bf2405ab:



    voice "voice/e22/25a00900a01.opus"
    mx "\"So I'm just worried that... well... you'll think I'm some kind of sex freak...\""


translate english e2225a_0accd139:


    xy "\"\"\"......\"\"\""


translate english e2225a_8e385e01:



    voice "voice/e22/25a00910a01.opus"
    mx "\"Shinichi...?\""


translate english e2225a_964f4093:


    "Suena un poco asustada."


translate english e2225a_573a9cf2:


    "Pero para mí, es adorable."


translate english e2225a_50320c75:


    xy "\"Even if you're a sex freak, I still want to be with you.\""


translate english e2225a_7e878e82:



    voice "voice/e22/25a00920a01.opus"
    mx "\"But...\""


translate english e2225a_409520f0:


    xy "\"I promise, I could never hate you for it!\""


translate english e2225a_6a9201b0:



    voice "voice/e22/25a00930a01.opus"
    mx "\"...Okay.\""


translate english e2225a_26a4790a:



    voice "voice/e22/25a00940a01.opus"
    mx "\"Yeah, you're right.\""


translate english e2225a_d944fa61:



    voice "voice/e22/25a00950a01.opus"
    mx "\"You did promise me with that kiss, after all.\""


translate english e2225a_58c202a7:



    voice "voice/e22/25a00960a01.opus"
    mx "\"We'll be together forever...\""


translate english e2225a_eb583b02:


    "Es verdad."


translate english e2225a_4bd443a0:


    "Miyuki y yo estamos destinados a estar juntos."


translate english e2225a_6e155563:


    xy "\"Just you and me, alright?\""


translate english e2225a_11cd31ff:



    voice "voice/e22/25a00970a01.opus"
    mx "\"...Okay.\""


translate english e2225a_67c291d4:


    "Espero a que asienta, y luego empiezo a embestir otra vez."


translate english e2225a_ce771177:



    voice "voice/e22/25a00980a01.opus"
    mx "\"Hnnnn! Nn... nnngghh...!\""


translate english e2225a_1a71d604:



    voice "voice/e22/25a00990a01.opus"
    mx "\"It's just so... incredible... Your cock... feels so good... Aaah!\""


translate english e2225a_1b2d3ee1:



    voice "voice/e22/25a01000a01.opus"
    mx "\"Hey... Shinichi... Nnnnggg!!! It feels good for you too... right...?\""


translate english e2225a_0af5bb4c:


    "Después del orgasmo, su coño está más apretado y húmedo que nunca."


translate english e2225a_fb52c57d:


    "No podría replicarlo ni usando las dos manos."


translate english e2225a_e998ada1:


    "Es como si encajáramos perfectamente..."


translate english e2225a_bc16d53b:



    voice "voice/e22/25a01010a01.opus"
    mx "\"My body... exists... for you... only...!\""


translate english e2225a_06259d09:



    voice "voice/e22/25a01020a01.opus"
    mx "\"Wearing this... shameless outfit...! Saying all these... dirty things...!\""


translate english e2225a_4f7a19a9:



    voice "voice/e22/25a01030a01.opus"
    mx "\"I do it... all for you!\""


translate english e2225a_54f04a61:



    voice "voice/e22/25a01040a01.opus"
    mx "\"Aaahh! Your cock... It's rock-hard now! Right there! Nnhaah! Aah! Oh god!\""


translate english e2225a_3261009f:



    voice "voice/e22/25a01050a01.opus"
    mx "\"Right there, all the way in... Feels so good, I... I can't think straight...!!!\""


translate english e2225a_195187d6:



    voice "voice/e22/25a01060a01.opus"
    mx "\"Nnngh! Nnn! Does it feel good for you, too? Does my pussy feel good...?\""


translate english e2225a_a04f6bf1:


    "Sinceramente, a estas alturas, se siente tan increíble que estoy a punto de perder el control."


translate english e2225a_2957b5f9:



    voice "voice/e22/25a01070a01.opus"
    mx "\"Nnng... Good... I'm glad... Just... forget everything else...\""


translate english e2225a_8b337d4f:



    voice "voice/e22/25a01080a01.opus"
    mx "\"Focus on me... and me only... That's... all I ask...\""


translate english e2225a_34281cd2:



    voice "voice/e22/25a01090a01.opus"
    mx "\"Just make me YOURS...!\""


translate english e2225a_16756e18:


    "Cuando llego a mis límites, decido—"



translate english e2225a_b166616d:



    voice "voice/e22/25a00870a01.opus"
    xy "\"Call me Shinichi.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
