

translate english d7122_4016acab:


    "No podía creer su historia."


translate english d7122_99dd0bd6:


    "Se niega a aceptar responsabilidad por lo que ha hecho."


translate english d7122_f795a61b:


    "En cambio, echa toda la culpa a algún dios imaginario."


translate english d7122_3d9f35ed:


    "Hablar con ella es una pérdida de tiempo a estas alturas."


translate english d7122_17ca54c3:


    "Ahora solo quiero borrar cada último rastro de nuestra vida juntos."


translate english d7122_e8deab0f:


    "Así..."


translate english d7122_77e9dcb9:


    "...vuelvo a mi habitación para recoger sus pertenencias."


translate english d7122_686cba89:



    voice "voice/d71/2200010a01.opus"
    mx "\"Seems like you've made up your mind.\""


translate english d7122_05864cc4:


    xy "\"...What are you still doing here?\""


translate english d7122_dbb36566:


    "Pensé que ya había salido de la casa..."


translate english d7122_7e98a45d:



    voice "voice/d71/2200020a01.opus"
    mx "\"Sorry... I just couldn't help but worry.\""


translate english d7122_949880bf:


    xy "\"Well, you don't have to. Not anymore.\""


translate english d7122_13268419:


    "Me escabullo a su lado hacia mi cuarto."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
