

translate english e2192b_b1b88abc:


    xy "\"Still, it's worth a peek, don't you think?\""


translate english e2192b_27e52afb:


    "Doy un paso hacia la caja y extiendo la mano—"


translate english e2192b_907ac091:



    voice "voice/e21/92b00010a01.opus"
    mx "\"Hey! Stop that! There's nothing in there!\""


translate english e2192b_eccea461:


    xy "\"How do you know?\""


translate english e2192b_1159c3a4:



    voice "voice/e21/92b00020a01.opus"
    mx "\"I just do, okay?!\""


translate english e2192b_4bb1fd32:


    "Me mira ferozmente."


translate english e2192b_2071b159:


    "...¿Por qué le importa tanto esta caja?"


translate english e2192b_b220f225:



    voice "voice/e21/92b00030a01.opus"
    mx "\"Which is more important, me or the box?\""


translate english strings:


    old "Коробка"
    new "La caja"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
