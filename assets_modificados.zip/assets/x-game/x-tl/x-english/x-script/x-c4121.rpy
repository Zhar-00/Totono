

translate english c4121_ab757707:


    xy "\"¡Buenos días!\""


translate english c4121_7d21354e:



    voice "voice/c41/2100010b01.opus"
    xtl "\"Buenos días...\""


translate english c4121_044f1207:


    xy "\"¿Qué pasa, amigo? No te ves muy bien.\""


translate english c4121_4a8a1f71:



    voice "voice/c41/2100020b01.opus"
    xtl "\"Estoy bien... No, de verdad no.\""


translate english c4121_87dbff12:


    "Yuutarou casi nunca deja que las cosas lo afecten así... lo que significa que la situación con su hermano debe ser bastante seria."


translate english c4121_5d059ede:


    xy "\"He estado pensando.\""


translate english c4121_637c21a9:


    xy "\"Quizá lo que tu hermano necesita es una novia.\""


translate english c4121_76a1e2b0:



    voice "voice/c41/2100030b01.opus"
    xtl "\"¿Una novia...?\""


translate english c4121_da7a0e7a:


    xy "\"Puede que esté un poco inestable ahora, pero si tuviera una salida romántica apropiada en su vida, probablemente se calmaría.\""


translate english c4121_d770d2b4:



    voice "voice/c41/2100040b01.opus"
    xtl "\"Oh, ya veo. Tiene sentido.\""


translate english c4121_7987ab71:


    xy "\"¿Verdad que sí?\""


translate english c4121_3cfd53a0:



    voice "voice/c41/2100050b01.opus"
    xtl "\"Entonces, ¿cómo le conseguimos una chica?\""


translate english c4121_b4b82e9b:


    xy "\"Eres el capitán del Club de Chicos y Sueños, ¿no? Seguramente puedes ayudarlo a encontrar uno o dos sueños—\""


translate english c4121_19de4af1:



    voice "voice/c41/2100070b01.opus"
    xtl "\"¡¡¡Ni siquiera puedo encontrar mis propios malditos sueños!!! ¡¡¡Por eso debo perseguirlos!!!\""


translate english c4121_062bde6e:


    "Eso he oído."


translate english c4121_7eb4a0a1:


    xy "\"Pero tu hermano es modelo, ¿no? Así que debe ser guapo.\""


translate english c4121_4c0eb10e:


    xy "\"Seguramente puede encontrar a alguien con quien salir sin demasiados problemas.\""


translate english c4121_0e9fb5c1:



    voice "voice/c41/2100080b01.opus"
    xtl "\"Hmmm... No habla mucho del tema...\""


translate english c4121_9ca294e6:



    voice "voice/c41/2100090b01.opus"
    xtl "\"¡Oh!\""


translate english c4121_6dfa52cb:



    voice "voice/c41/2100100b01.opus"
    xtl "\"Ahora que lo pienso, creo que esta mañana mencionó que le gusta un poco alguien...\""


translate english c4121_323815b3:


    xy "\"Oh, ¿de verdad?\""




translate english c4121_12e64a21:


    xy "\"......\""


translate english c4121_b0be0236:



    voice "voice/c41/2100060b01.opus"
    xtl "\"......\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
