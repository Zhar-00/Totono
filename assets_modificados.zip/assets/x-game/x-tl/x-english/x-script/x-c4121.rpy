

translate english c4121_ab757707:


    xy "\"Morning!\""


translate english c4121_7d21354e:



    voice "voice/c41/2100010b01.opus"
    xtl "\"Morning...\""


translate english c4121_044f1207:


    xy "\"What's up, buddy? You don't look too good.\""


translate english c4121_4a8a1f71:



    voice "voice/c41/2100020b01.opus"
    xtl "\"I'm fine... No, I'm really not.\""


translate english c4121_87dbff12:


    "Yuutarou casi nunca deja que las cosas lo afecten así... lo que significa que la situación con su hermano debe ser bastante seria."


translate english c4121_5d059ede:


    xy "\"I've been thinking.\""


translate english c4121_637c21a9:


    xy "\"Maybe what your brother needs is a girlfriend.\""


translate english c4121_76a1e2b0:



    voice "voice/c41/2100030b01.opus"
    xtl "\"A girlfriend...?\""


translate english c4121_da7a0e7a:


    xy "\"He might be a little unstable right now, but if he had a proper romantic outlet in his life, he'd probably chill out.\""


translate english c4121_d770d2b4:



    voice "voice/c41/2100040b01.opus"
    xtl "\"Oh, I get it. That makes sense.\""


translate english c4121_7987ab71:


    xy "\"Doesn't it?\""


translate english c4121_3cfd53a0:



    voice "voice/c41/2100050b01.opus"
    xtl "\"So how do we get him a girl?\""


translate english c4121_b4b82e9b:


    xy "\"You're the captain of the Boys and Dreams Club, aren't you? Surely you can help him find a dream or two—\""


translate english c4121_19de4af1:



    voice "voice/c41/2100070b01.opus"
    xtl "\"I can't even find my own damn dreams!!! That's why I must pursue them!!!\""


translate english c4121_062bde6e:


    "Eso he oído."


translate english c4121_7eb4a0a1:


    xy "\"But your brother's a model, right? So he's gotta be good-looking.\""


translate english c4121_4c0eb10e:


    xy "\"Surely he can find someone to date without too much trouble.\""


translate english c4121_0e9fb5c1:



    voice "voice/c41/2100080b01.opus"
    xtl "\"Hmmm... He doesn't really talk about it too much...\""


translate english c4121_9ca294e6:



    voice "voice/c41/2100090b01.opus"
    xtl "\"Oh!\""


translate english c4121_6dfa52cb:



    voice "voice/c41/2100100b01.opus"
    xtl "\"Come to think of it, I'm pretty sure he mentioned this morning that he's got a little crush on someone...\""


translate english c4121_323815b3:


    xy "\"Oh, for real?\""




translate english c4121_12e64a21:


    xy "\"......\""


translate english c4121_b0be0236:



    voice "voice/c41/2100060b01.opus"
    xtl "\"......\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
