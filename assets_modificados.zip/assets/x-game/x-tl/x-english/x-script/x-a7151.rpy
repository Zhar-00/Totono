

translate english a7151_53126de5:


    "Los días pasan volando."


translate english a7151_437efc49:


    "Con Miyuki a mi lado, me siento tan completo."


translate english a7151_0d9712d8:


    "Sabes, nunca imaginé que las cosas saldrían así."


translate english a7151_3472b0bb:


    "A veces se siente como un sueño..."


translate english a7151_0accd139:


    xy "\"\"......\"\""


translate english a7151_64823d1f:


    "Pero algo falta."


translate english a7151_90f20efc:


    "Algo no está del todo bien..."


translate english a7151_a228ca51:


    "¿Pero qué?"


translate english a7151_0908f010:


    xy "\"¿Quién podría ser a esta hora...?\""


translate english a7151_4e4af4a0:


    xy "\"¡Tranquila! ¡Te oí la primera vez!\""


translate english a7151_4c5e21c2:


    xy "\"¿Miyuki? ¿Es... un ramo de flores?\""


translate english a7151_6deec02b:



    voice "voice/a71/5100010a01.opus"
    mx "\"¡Feliz cumpleaños!\""


translate english a7151_e787aefa:


    xy "\"...Oh, cierto.\""


translate english a7151_34681477:


    xy "\"Gracias.\""



translate english a7151_a71cfd70:



    voice "voice/a71/5100020a01.opus"
    mx "\"\"......\"\""


translate english a7151_784fb7fe:



    voice "voice/a71/5100030a01.opus"
    mx "\"¿A qué vino ese silencio incómodo de hace un momento?\""


translate english a7151_004610d7:



    voice "voice/a71/5100040a01.opus"
    mx "\"¿Olvidaste tu propio cumpleaños?\""


translate english a7151_3003c54a:


    xy "\"Jajajajaja...\""


translate english a7151_2058ac12:


    "¡Pues claro que sí!"


translate english a7151_120cb332:


    xy "\"Bueno, es fácil perder la cuenta de la fecha cuando estoy solo.\""


translate english a7151_18708605:



    voice "voice/a71/5100050a01.opus"
    mx "\"Entonces será mejor que me quede por aquí, ¿hm?\""


translate english a7151_980c9c35:



    voice "voice/a71/5100060a01.opus"
    mx "\"¡Ven, hagamos una pequeña fiesta!\""


translate english a7151_3b23c9fb:


    "Con eso, entra, cargando una caja grande."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
