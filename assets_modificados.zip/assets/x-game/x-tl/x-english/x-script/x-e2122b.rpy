

translate english e2122b_3647bb27:


    xy "\"I'm talking about Aoi, obviously.\""


translate english e2122b_c33bc2a6:



    voice "voice/e21/22b00010b01.opus"
    xtl "\"...What? Gimme a break!\""


translate english e2122b_1b6565cc:



    voice "voice/e21/22b00020b01.opus"
    xtl "\"I mean, sure, she's a super-cute routeless side character in [[YOU and ME and HER]!\""


translate english e2122b_ac407b3c:



    voice "voice/e21/22b00030b01.opus"
    xtl "\"Like, CRAZY cute!\""


translate english e2122b_dfe7da03:



    voice "voice/e21/22b00040b01.opus"
    xtl "\"I'm talking doujins, figurines, boobie mousepads, pillow covers, knockoff pocket pussies...\""


translate english e2122b_41e14682:



    voice "voice/e21/22b00050b01.opus"
    xtl "\"If I had the money, I...\""


translate english e2122b_0accd139:


    xy "\"......\""


translate english e2122b_a9bcce1c:



    voice "voice/e21/22b00060b01.opus"
    xtl "\"I... wouldn't buy any of it, obviously! No sir! Of course not!\""


translate english e2122b_00c2928f:


    xy "\"Right. Of course not.\""


translate english e2122b_485c6c4e:



    voice "voice/e21/22b00070b01.opus"
    xtl "\"Don't look at me like that!!!\""


translate english e2122b_8bc15982:



    voice "voice/e21/22b00080b01.opus"
    xtl "\"Just because you're a normie, you think you can judge me?! Think again!\""


translate english e2122b_841dd8ce:



    voice "voice/e21/22b00090b01.opus"
    xtl "\"I'll be taking my leave of you!\""


translate english e2122b_a25a04ab:


    "Yuutarou se marcha furioso de vuelta a su escritorio."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
