

translate english e2122b_3647bb27:


    xy "\"Estoy hablando de Aoi, obviamente.\""


translate english e2122b_c33bc2a6:



    voice "voice/e21/22b00010b01.opus"
    xtl "\"...¿Qué? ¡Dame un respiro!\""


translate english e2122b_1b6565cc:



    voice "voice/e21/22b00020b01.opus"
    xtl "\"I mean, sure, she's a super-cute routeless side character in [[YOU and ME and HER]!\""


translate english e2122b_ac407b3c:



    voice "voice/e21/22b00030b01.opus"
    xtl "\"¡O sea, ES una locura de linda!\""


translate english e2122b_dfe7da03:



    voice "voice/e21/22b00040b01.opus"
    xtl "\"Estoy hablando de doujins, figuras, mousepads de tetas, fundas de almohada, onaholes pirata...\""


translate english e2122b_41e14682:



    voice "voice/e21/22b00050b01.opus"
    xtl "\"Si tuviera dinero, yo...\""


translate english e2122b_0accd139:


    xy "\"......\""


translate english e2122b_a9bcce1c:



    voice "voice/e21/22b00060b01.opus"
    xtl "\"¡...no compraría nada de eso, obviamente! ¡No señor! ¡Claro que no!\""


translate english e2122b_00c2928f:


    xy "\"Claro. Claro que no.\""


translate english e2122b_485c6c4e:



    voice "voice/e21/22b00070b01.opus"
    xtl "\"¡¡¡No me mires así!!!\""


translate english e2122b_8bc15982:



    voice "voice/e21/22b00080b01.opus"
    xtl "\"¿¡Solo porque eres un normie crees que puedes juzgarme!? ¡Piénsalo bien!\""


translate english e2122b_841dd8ce:



    voice "voice/e21/22b00090b01.opus"
    xtl "\"¡Me retiro de tu presencia!\""


translate english e2122b_a25a04ab:


    "Yuutarou se marcha furioso de vuelta a su escritorio."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
