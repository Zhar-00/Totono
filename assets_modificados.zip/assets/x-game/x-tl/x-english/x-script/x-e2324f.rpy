

translate english e2324f_2c8c5bc4:


    "Han pasado 20 años desde la última vez que puse un pie en mi pueblo natal."


translate english e2324f_7c7c92aa:


    "Y este lugar no ha cambiado nada desde entonces."


translate english e2324f_1d864e59:


    "Casi como si el tiempo mismo se hubiera detenido solo para mí."


translate english e2324f_bb38e968:


    "Acelero el paso."


translate english e2324f_f6884242:


    "He sido un ermitaño durante muchísimos años."


translate english e2324f_c3aad6c2:


    "No estoy acostumbrado a que otra gente me mire."


translate english e2324f_a0f430c2:


    "Siento como si me miraran fijamente."


translate english e2324f_b0f75f8e:


    "Aunque... quizás de verdad lo están haciendo."


translate english e2324f_eb286fb1:


    "Apuesto a que no soy bienvenido en este pueblo."


translate english e2324f_e9372016:


    "Por un momento contemplo entrar a la tienda de la esquina—pero entonces me detengo en seco."


translate english e2324f_4679e1e4:


    "En el mostrador está la feliz pareja, atendiendo las cajas."


translate english e2324f_a198ced7:


    "Uno de ellos parece haber envejecido bastante..."


translate english e2324f_61ac5019:


    xy "\"...There was a vending machine around here, wasn't there?\""


translate english e2324f_29db3a58:


    "Es el fin de semana."


translate english e2324f_21fa3b62:


    "El campus está abierto por actividades de clubes, pero por suerte no hay mucha gente."


translate english e2324f_798c34cf:


    "No hace falta colarme con sigilo; simplemente entro."


translate english e2324f_eeb77f80:


    "Supuse que tendría que forzar la cerradura, pero resulta que siguen usando la misma de aquel entonces."


translate english e2324f_087a877c:


    "Con cuidado, abro la vieja puerta oxidada."


translate english e2324f_a7e4dbfd:



    voice "voice/e23/24f00010a02.opus"
    aoi "\"Boop boop...? Shinichi?\""


translate english e2324f_433f5ca4:



    voice "voice/e23/24f00020a01.opus"
    mx "\"You jerk! You're late!\""


translate english e2324f_43ed6577:


    xy "\"I know. Sorry for the wait.\""


translate english e2324f_4f5e1173:


    "Saco la lata de shochu highball de mi bolsillo."


translate english e2324f_f1081f31:



    voice "voice/e23/24f00030a01.opus"
    mx "\"Is that alcohol?\""


translate english e2324f_fbc44999:



    voice "voice/e23/24f00040a02.opus"
    aoi "\"Are you drinking at school?\""


translate english e2324f_9e1cb98f:



    voice "voice/e23/24f00050a02.opus"
    aoi "\"You delinquent!\""


translate english e2324f_c846adba:


    xy "\"It can't hurt, just once.\""


translate english e2324f_b299860f:



    voice "voice/e23/24f00060a01.opus"
    mx "\"...At least you showed up, I guess.\""


translate english e2324f_1df51a55:


    "Mientras el sol se pone, subo hasta lo alto del techo."


translate english e2324f_04689cf6:


    "El cielo es de un carmesí brillante."


translate english e2324f_fcc7bf86:


    "Justo como lo recuerdo."


translate english e2324f_87502489:


    "Como... lo recuerdo..."


translate english e2324f_47147052:



    voice "voice/e23/24f00070a01.opus"
    mx "\"Really takes you back to that fateful day, huh?\""


translate english e2324f_c9d9ddb1:



    voice "voice/e23/24f00080a02.opus"
    aoi "\"The day we said bye-bye.\""


translate english e2324f_1d2939ac:


    xy "\"...Yeah.\""


translate english e2324f_e9b898bb:



    voice "voice/e23/24f00090a01.opus"
    mx "\"Will you choose me?\""


translate english e2324f_6edf85f8:



    voice "voice/e23/24f00100a02.opus"
    aoi "\"Or choose me?\""


translate english e2324f_c089125d:



    voice "voice/e23/24f00110a01.opus"
    mx "\"We demanded an answer.\""


translate english e2324f_d895fbb4:



    voice "voice/e23/24f00120a02.opus"
    aoi "\"But you wouldn't give it.\""


translate english e2324f_fa4611aa:


    "Y entonces la tragedia golpeó."


translate english e2324f_0d354a2b:


    "Lo siguiente que supe fue que ambos yacían muertos, víctimas de su mutuo rencor."


translate english e2324f_8ad461c8:


    "Y sin embargo, cada vez que subía al techo, ahí estaban."


translate english e2324f_daac1239:


    "Sabía que estaban muertos."


translate english e2324f_b0f4f8bb:


    "Lo sabía."


translate english e2324f_86258fa8:


    "Pero no podía dejarlos ir."


translate english e2324f_8aa3917b:


    "Quería que siguiéramos juntos, solo nosotros tres."


translate english e2324f_a43fe4eb:


    "Era tan feliz que empezaba a perder la cabeza."


translate english e2324f_17fd4503:


    "...Y entonces sí la perdí."


translate english e2324f_38c2829f:


    "Mi mente estaba totalmente en pugna con la realidad."


translate english e2324f_ecd12471:


    "Incapaz de liberarme de mi delirio, me encerré aquí—"


translate english e2324f_ec506eee:


    "—hasta que derribaron la puerta y me llevaron al pabellón psiquiátrico."


translate english e2324f_40722686:


    "...Y entonces pasaron 20 años."


translate english e2324f_34ad3695:


    xy "\"Ggllpp... ggllpp... mmm...\""


translate english e2324f_d889eb5c:


    "Me bebo la bebida de un trago."


translate english e2324f_8e65a60c:


    "Luego me quedo ahí de pie, solo en el techo vacío."


translate english e2324f_4687b2c0:


    "Ellos nunca estuvieron aquí."


translate english e2324f_974c5f19:


    "Dejaron este mundo hace mucho, muchísimo tiempo."


translate english e2324f_a01a85fe:


    "Y ahora por fin puedo aceptarlo."


translate english e2324f_08b07da3:


    "Así que solo queda una cosa por hacer."


translate english e2324f_55a54d11:


    xy "\"Okay... I'm ready.\""


translate english e2324f_5df4daf4:


    "Hora de ir a verlos."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
