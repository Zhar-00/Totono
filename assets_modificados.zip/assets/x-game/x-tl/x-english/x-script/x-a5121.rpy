

translate english a5121_62c84dd3:


    xy "\"Homeroom's starting, you know.\""


translate english a5121_6d6b3c1a:



    voice "voice/a51/2100010a01.opus"
    mx "\"That doesn't matter.\""


translate english a5121_f5084b49:


    xy "\"Hey! That HURTS! Quit pulling so hard!\""


translate english a5121_a78e54f0:


    "Hay un silencio total aquí en el viejo gimnasio."


translate english a5121_53b58fca:


    "Al parecer hoy no hay clase de educación física en el primer periodo."


translate english a5121_c8706547:


    "Miyuki me arrastra hasta el centro de la cancha de básquetbol."


translate english a5121_6c5bad47:


    xy "\"So, what do you want?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
