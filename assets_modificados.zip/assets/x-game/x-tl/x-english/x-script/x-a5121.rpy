

translate english a5121_62c84dd3:


    xy "\"Va a empezar la clase de tutoría, ¿sabes?\""


translate english a5121_6d6b3c1a:



    voice "voice/a51/2100010a01.opus"
    mx "\"Eso no importa.\""


translate english a5121_f5084b49:


    xy "\"¡Oye! ¡Eso DUELE! ¡Deja de jalar tan fuerte!\""


translate english a5121_a78e54f0:


    "Hay un silencio total aquí en el viejo gimnasio."


translate english a5121_53b58fca:


    "Al parecer hoy no hay clase de educación física en el primer periodo."


translate english a5121_c8706547:


    "Miyuki me arrastra hasta el centro de la cancha de básquetbol."


translate english a5121_6c5bad47:


    xy "\"Y bien, ¿qué quieres?\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
