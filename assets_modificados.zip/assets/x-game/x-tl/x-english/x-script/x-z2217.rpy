

translate english z2217_81b59699:



    voice "voice/z22/1700010a01.opus"
    mx "El año casi se acaba, ¿eh?"


translate english z2217_97d58e82:



    voice "voice/z22/1700020a01.opus"
    mx "Gracias por venir a verme."


translate english z2217_75ebe2c5:



    voice "voice/z22/1700030a01.opus"
    mx "Now then, let's play some [[YOU and ME and HER]!"


translate english z2217_cfd0a2ac:



    voice "voice/z22/1700040a01.opus"
    mx "En realidad... solo por hoy, te dejaré jugar Axanael en su lugar, si quieres."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
