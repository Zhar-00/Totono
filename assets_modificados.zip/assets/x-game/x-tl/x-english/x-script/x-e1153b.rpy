

translate english e1153b_MAIN_9ea2f78c:


    " "



translate english e1153b_52270dd5:



    voice "voice/e11/53b00010a01.opus"
    mx "\"¡Resiste, ¿quieres?!\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
