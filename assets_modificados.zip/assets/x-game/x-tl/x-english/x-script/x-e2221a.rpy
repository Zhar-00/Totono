

translate english e2221a_cdc3d70a:



    voice "voice/e22/21a00010a01.opus"
    mx "\"From here on out, we can celebrate as much as you like.\""


translate english e2221a_63f5316c:


    xy "\"Th-Thanks...\""


translate english e2221a_dad3381c:


    "Sus palabras dan a entender que se quedará conmigo el resto de mi vida, y me aprieta el pecho."


translate english e2221a_a12a020e:


    xy "\"Man... Feels like I'm dreaming or something...\""


translate english e2221a_3f83a78f:



    voice "voice/e22/21a00020a01.opus"
    mx "\"How so?\""


translate english e2221a_1bf62b01:


    xy "\"It's hard to explain...\""


translate english strings:


    old "Я всегда надеялся, что всё так обернётся"
    new "Siempre esperé que las cosas resultaran así"


    old "Такое чувство, будто я проснусь и всё исчезнет"
    new "Siento que voy a despertar y todo habrá desaparecido"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
