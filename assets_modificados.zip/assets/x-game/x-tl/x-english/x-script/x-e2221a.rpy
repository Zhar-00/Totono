

translate english e2221a_cdc3d70a:



    voice "voice/e22/21a00010a01.opus"
    mx "\"De ahora en adelante, podemos celebrar tanto como quieras.\""


translate english e2221a_63f5316c:


    xy "\"Gr-Gracias...\""


translate english e2221a_dad3381c:


    "Sus palabras dan a entender que se quedará conmigo el resto de mi vida, y me aprieta el pecho."


translate english e2221a_a12a020e:


    xy "\"Vaya... Siento que estoy soñando o algo...\""


translate english e2221a_3f83a78f:



    voice "voice/e22/21a00020a01.opus"
    mx "\"¿Cómo es eso?\""


translate english e2221a_1bf62b01:


    xy "\"Es difícil de explicar...\""


translate english strings:


    old "Я всегда надеялся, что всё так обернётся"
    new "Siempre esperé que las cosas resultaran así"


    old "Такое чувство, будто я проснусь и всё исчезнет"
    new "Siento que voy a despertar y todo habrá desaparecido"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
