

translate english e2314a_8ae37322:


    "...¿Por qué estoy siquiera dudando esto?"


translate english e2314a_54c11937:


    "If I'm looking for sugar, then obviously I ought to take the one that's clearly labeled \"sugar\"..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
