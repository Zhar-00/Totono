

translate english e2237g_e26331ca:


    "Señalo hacia abajo, a sus bragas, ahora completamente empapadas con los fluidos de ambos."


translate english e2237g_f75849fa:



    voice "voice/e22/37g00010a01.opus"
    mx "\"Huh? ...Oh... uhhh...\""


translate english e2237g_491d80a2:



    voice "voice/e22/37g00020a01.opus"
    mx "\"Wh-What do we do...?\""


translate english e2237g_2141bcfd:


    "¿Debería simplemente ir sin ropa interior por el resto del día...?"


translate english e2237g_8d8b4359:


    "...No, eso es demasiado arriesgado."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
