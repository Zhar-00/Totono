

translate english b3122b_39148c09:



    voice "voice/b31/22b00010a02.opus"
    aoi "\"Todavía no.\""


translate english b3122b_d6efd40c:



    voice "voice/b31/22b00020a02.opus"
    aoi "\"Los últimos días... mis llamadas no entran.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
