

translate english b3122b_39148c09:



    voice "voice/b31/22b00010a02.opus"
    aoi "\"Not yet.\""


translate english b3122b_d6efd40c:



    voice "voice/b31/22b00020a02.opus"
    aoi "\"The past few days... My phone calls won't go through.\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
