

translate english e2316a_7aa525f2:



    voice "voice/e23/16a00010a01.opus"
    mx "\"...¡Está tan bueno!\""


translate english e2316a_28f19ada:


    xy "\"¿Sí?\""


translate english e2316a_5ee6ad4e:



    voice "voice/e23/16a00020a01.opus"
    mx "\"¿Sabes qué pienso?\""


translate english e2316a_ba41bd7c:



    voice "voice/e23/16a00030a01.opus"
    mx "\"Creo que esto también está hecho con tu amor.\""


translate english e2316a_ad873db8:



    voice "voice/e23/16a00040a01.opus"
    mx "\"......Es broma.\""


translate english e2316a_bc958b65:


    xy "\"¡C-Cierto!\""


translate english e2316a_588fe758:


    xy "\"No, sí, totalmente... ¡probablemente!\""


translate english e2316a_f0073a8e:


    "Desesperado por ocultar mi vergüenza, asiento con demasiado entusiasmo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
