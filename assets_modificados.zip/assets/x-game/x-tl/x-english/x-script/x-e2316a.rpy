

translate english e2316a_7aa525f2:



    voice "voice/e23/16a00010a01.opus"
    mx "\"...It's so good!\""


translate english e2316a_28f19ada:


    xy "\"Yeah?\""


translate english e2316a_5ee6ad4e:



    voice "voice/e23/16a00020a01.opus"
    mx "\"You know what I think?\""


translate english e2316a_ba41bd7c:



    voice "voice/e23/16a00030a01.opus"
    mx "\"I think this was made with your love, too.\""


translate english e2316a_ad873db8:



    voice "voice/e23/16a00040a01.opus"
    mx "\"......Just kidding.\""


translate english e2316a_bc958b65:


    xy "\"R-Right!\""


translate english e2316a_588fe758:


    xy "\"No, yeah, totally... probably!\""


translate english e2316a_f0073a8e:


    "Desesperado por ocultar mi vergüenza, asiento con demasiado entusiasmo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
