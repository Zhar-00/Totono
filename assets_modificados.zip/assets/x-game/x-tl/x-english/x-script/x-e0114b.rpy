

translate english e0114b_5cb034ea:


    xy "\"What are you talking about? Just trade it in at a store somewhere.\""


translate english e0114b_ba46ddf0:



    voice "voice/e01/14b00010a01.opus"
    mx "\"I want to get rid of it ASAP.\""


translate english e0114b_1da4178f:


    xy "\"Don't be—Hey, wait!\""


translate english e0114b_a6e14b52:


    "Toma el teléfono de mi mano—"


translate english e0114b_ba497598:



    voice "voice/e01/14b00020a01.opus"
    mx "\"HYAH!!!\""


translate english e0114b_8d98ac00:


    "—y lo lanza por encima de la valla de seguridad."


translate english e0114b_45b20c0d:


    xy "\"...Aw, man...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
