

translate english e0114b_5cb034ea:


    xy "\"¿De qué hablas? Solo cámbialo en alguna tienda.\""


translate english e0114b_ba46ddf0:



    voice "voice/e01/14b00010a01.opus"
    mx "\"Quiero deshacerme de él cuanto antes.\""


translate english e0114b_1da4178f:


    xy "\"No seas—¡Oye, espera!\""


translate english e0114b_a6e14b52:


    "Toma el teléfono de mi mano—"


translate english e0114b_ba497598:



    voice "voice/e01/14b00020a01.opus"
    mx "\"¡¡¡HYAH!!!\""


translate english e0114b_8d98ac00:


    "—y lo lanza por encima de la valla de seguridad."


translate english e0114b_45b20c0d:


    xy "\"...Ay, hombre...\""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
