label e2317_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2317:
    hide 絵色黒
    call eroute_bgm
    scene expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)

    "Моментом позже, Миюки крепко уснула."

    "Должно быть, она была ещё сильнее измотана, чем говорила."
    stop bgm fadeout (4000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    pause (3000/1000)
    hide 絵色黒
    with Dissolve(2000.0/1000)
    pause (500/1000)

    "На улице уже стемнело, а она всё ещё была в отключке."

    "И почему-то у меня появилось такое чувство, будто сегодня вечером мне всё сойдёт с рук."
    menu:
        "Пойти спать":
            $ SetChoiceSelect = 0
        "Взять её телефон":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e2318a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e2318b.nss";
    else:
        $ GameName = "e2318a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
