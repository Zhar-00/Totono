label e2032b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2032b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_ero")
    with Dissolve(0.0/1000)
    stop bgm fadeout (300.0/1000)
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_lost")
    xy "\"Нет, Миюки.\""
    "Признаю, нам вместе было очень весело."
    "Но нет, я не думаю, что это должно длиться бесконечно."
    xy "\"В смысле, мы всё ещё учимся в школе, и—\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_shout")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb24",channel = "bgm", if_changed = True)
    voice "voice/e20/32b00010a01.opus"
    mx "\"Я поняла!\""
    "Миюки внезапно начала кричать."
    $ St("C",300,0,0,"bu曽根美雪_私服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e20/32b00020a01.opus"
    mx "\"Я всё поняла, ладно?!\""
    voice "voice/e20/32b00030a01.opus"
    mx "\"Я знаю, что мы не должны так жить!\""
    voice "voice/e20/32b00040a01.opus"
    mx "\"И я знаю, что это не может длиться бесконечно!\""
    voice "voice/e20/32b00050a01.opus"
    mx "\"Но... если это то, что ты чувствуешь... то...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_病み_fear")
    with Dissolve(200.0/1000)
    voice "voice/e20/32b00060a01.opus"
    mx "\"Вытащи меня из этого мира...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/e20/32b00070a01.opus"
    mx "\"Мы можем вернуться обратно в старую игру... к тому, как всё было...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/e20/32b00080a01.opus"
    mx "\"Просто не переставай любить меня!..\""
    xy "\"...Прости, эм...\""
    xy "\"Я... я не понимаю, о чём ты говоришь.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e20/32b00090a01.opus"
    mx "\"......\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e20/32b00100a01.opus"
    mx "\"Ладно.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e20/32b00110a01.opus"
    mx "\"Давай начнём сначала.\""
    voice "voice/e20/32b00120a01.opus"
    mx "\"Я перезапущу весь мир с нуля.\""
    xy "\"Перезапустишь весь мир с нуля?..\""
    voice "voice/e20/32b00130a01.opus"
    mx "\"Я сброшу этот рут.\""
    voice "voice/e20/32b00140a01.opus"
    mx "\"Я верю в ТЕБЯ, ладно?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_病み_mad")
    with Dissolve(200.0/1000)
    stop bgm fadeout (3000.0/1000)
    voice "voice/e20/32b00150a01.opus"
    mx "\"Надеюсь, ТЫ поймёшь, что я чувствую в этот раз.\""
    "Она пробормотала это себе под нос..."
    "...и коснулась экрана на своём телефоне."
    pause (16/1000)
    $ MetaFlagReset();
    $ GameName = "z1111.nss" ;
    $ renpy.quit(relaunch = True)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
