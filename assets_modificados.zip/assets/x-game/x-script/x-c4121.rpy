label c4121_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if meet_aoi == True:
        $ GameName = "c4122.nss"
    else:
        $ GameName = "d4122.nss"
    return
label c4121:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve(1500.0/1000)
    xy "\"Доброе утро!\""
    scene expression ("cg/bg/m/"+imagename["bg010600_1_学校教室_m"]+".jpg") as 絵背景:
        xcenter .5
        ypos -230
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_lost")
    with Dissolve(500.0/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    voice "voice/c41/2100010b01.opus"
    xtl "\"Доброе утро...\""

    xy "\"В чём дело, приятель? Выглядишь неважно.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c41/2100020b01.opus"

    xtl "\"Я в порядке... Нет, я правда не в порядке.\""

    "Ютаро почти никогда не позволяет чему-либо выбить себя из колеи таким образом... а это значит, что ситуация с его братом, должно быть, очень серьёзная."

    xy "\"Я тут подумал.\""

    xy "\"Скорее всего, твоему брату нужна девушка.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c41/2100030b01.opus"

    xtl "\"Девушка?..\""

    xy "\"Возможно, он сейчас немного не в себе, но если у него в жизни будет романтический выход, то он, скорее всего, успокоится.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c41/2100040b01.opus"

    xtl "\"А, я понял. В этом есть смысл.\""

    xy "\"Да ладно?\""
    voice "voice/c41/2100050b01.opus"

    xtl "\"Только вот как мы найдём ему девушку?\""
    xy "\"......\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c41/2100060b01.opus"
    xtl "\"......\""

    xy "\"Ты же капитан клуба \"Ребята и мечты\", разве нет? Разумеется, ты можешь помочь ему найти парочку-другую мечтаний—\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_gag")
    with Dissolve(200.0/1000)
    voice "voice/c41/2100070b01.opus"

    xtl "\"Я не могу найти даже свои чёртовы мечты!!! Именно поэтому я и должен их преследовать!!!\""

    "Я его услышал."

    xy "\"Но твой брат работает моделью, верно? Значит, он должен быть симпатичным.\""

    xy "\"Уверен, он сможет найти какую-нибудь девушку и пригласить её на свидание без особых проблем.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c41/2100080b01.opus"

    xtl "\"Хм-м-м... Он мне почти ничего об этом не рассказывает...\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/c41/2100090b01.opus"

    xtl "\"О!\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c41/2100100b01.opus"

    xtl "\"Если подумать, он, по-моему, упоминал сегодня утром о том, что немного запал на кое-кого...\""
    xy "\"О, правда?\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
