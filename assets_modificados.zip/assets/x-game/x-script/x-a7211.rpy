label a7211_MAIN:
    call expression GameName
    $ persistent.imagelog["eva7211美雪私がバースデープレゼントa"]=True
    $ persistent.imagelog["eva7211美雪私がバースデープレゼントb"]=True
    $ persistent.imagelog["eva7211美雪私がバースデープレゼントc"]=True
    $ persistent.imagelog["eva7211美雪さんご開帳a"]=True
    $ persistent.imagelog["eva7211美雪さんご開帳b"]=True
    $ persistent.imagelog["eva7211美雪さんご開帳c"]=True
    $ persistent.imagelog["eva7211美雪さんご開帳d"]=True
    $ persistent.imagelog["eva7211美雪さん処女喪失a"]=True
    queue bgm "ttb15"
    $ PreGameName = GameName
    if persistent.c_route == True:
        $ GameName = "a7212a.nss"
    elif persistent.non_virgin == True:
        $ GameName = "a7212b.nss"
    else:
        $ GameName = "a7212a.nss"
    return
label a7211:
    hide 絵色黒
    with Dissolve(0.0/1000)
    show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントa"]+".jpg") as 絵専 zorder 1010 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントb"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントa"]+".jpg") as 絵専 zorder 1010 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントb"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    with Dissolve(1000.0/1000)
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    pause (1000/1000)
    xy "\"Миюки...\""
    voice "voice/a72/1100010a01.opus"
    mx "\"Шиничи...\""
    hide 絵捏造窓絵専上
    with Dissolve(1000.0/1000)
    pause (500/1000)
    with Dissolve(1000.0/1000)

    "Мы целовались."
    voice "voice/a72/1100020a01.opus"

    mx "М-мф... м-м... м-м-м... м-мф..."

    "Сначала переплетались наши губы, а потом - и наши языки."

    "Наши движения медленно синхронизировались."
    hide 絵専
    with Dissolve(800.0/1000)
    voice "voice/a72/1100030a01.opus"

    mx "М-мф... Шиничи... о боже... не могу поверить... мы правда... целуемся... м-м..."

    "Я мог почувствовать её дыхание на моей коже."

    "Она с восхищением смотрела на меня."

    "А потом она притянула меня к себе поближе для ещё одного страстного поцелуя."
    voice "voice/a72/1100040a01.opus"

    mx "М-м-мф... м-м... м-м-м... м-м... М-мф... м-мф... м-м-м!.."

    "Первоначальная неловкость начала исчезать."

    "Наши языки танцевали."

    "Проникшись страстью, я начал расстёгивать её блузку."
    $ sename = "se人体_動作_衣擦れ濡れ場02"
    play se sedict[sename]
    pause (500/1000)
    show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントb"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(1000.0/1000)
    pause (800/1000)
    voice "voice/a72/1100050a01.opus"

    mx "Ты тоже должен раздеться, ладно? М-м..."
    $ sename = "se人体_動作_衣擦れ濡れ場01"
    play se sedict[sename]

    "Пока мы целовались, Миюки начала раздевать меня."

    "Мы оба были отвлечены нашими языками, но мы делали всё возможное."

    "Хотя должен признать, что её неуклюжесть была очень милой..."
    voice "voice/a72/1100060a01.opus"

    mx "Руки вверх!"

    "Услышав её просьбу, я поднял свои руки над головой."

    "Но должен признать, от неё это прозвучало прямо как от моей мамы..."
    voice "voice/a72/1100070a01.opus"
    mx "\"Что-то не так?\""

    xy "Ничего."
    voice "voice/a72/1100080a01.opus"

    mx "Что ничего?"

    xy "Твоё лицо."

    xy "То, как ты выглядишь, когда начинаешь дуться."
    show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントb"]+".jpg") as 絵専 zorder 1010 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントc"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/a72/1100090a01.opus"
    mx "\"......!\""

    xy "Ты опять покраснела."
    voice "voice/a72/1100100a01.opus"

    mx "Ну и что?! У тебя с этим проблемы?"

    xy "Нет. По правде говоря, это даже мило."
    voice "voice/a72/1100110a01.opus"

    mx "Чт..."

    xy "Хотел бы я, чтобы ты всегда так краснела."
    voice "voice/a72/1100120a01.opus"

    mx "Не смеши!"
    voice "voice/a72/1100130a01.opus"

    mx "Это самая глупая вещь, которую я когда-либо слышала!"

    xy "Да ладно, дай мне посмотреть на тебя во всей красе."
    hide 絵捏造窓絵専上
    with Dissolve(500.0/1000)
    voice "voice/a72/1100140a01.opus"

    mx "...Ладно..."

    "В школе она всегда была защищена непроницаемой личностью."

    "Но под ней она была такой же робкой девушкой, как и в те времена."
    hide 絵専
    with Dissolve(1000.0/1000)
    voice "voice/a72/1100150a01.opus"

    mx "М-м-м... м-мф... м-м... м-м-м..."

    "Я обернул свои руки вокруг её голой спины."

    "Она была намного меньше и мягче, чем я думал."

    "От этого мне даже захотелось обнять её покрепче и защищать."

    "И чем крепче я обнимал её..."
    show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントb"]+".jpg") as 絵専 zorder 0 at truecenter
    pause (16/1000)
    with Dissolve(500.0/1000)

    "...тем сильнее я чувствовал упругость её груди."

    "Её обширные курганы грозились вывалиться из её лифчика."
    $ sename = "se人体_動作_起き上がる02"
    play se sedict[sename]

    "Наши губы всё ещё были сомкнуты, и я протянул руку, чтобы попытаться расстегнуть его—"
    $ sename = "se人体_動作_衣擦れ濡れ場04"
    play se sedict[sename]

    xy "М-м... м-м-м... м-м?.."
    voice "voice/a72/1100160a01.opus"
    mx "\"Шиничи.\""
    voice "voice/a72/1100170a01.opus"

    mx "Можешь не спешить."
    voice "voice/a72/1100180a01.opus"

    mx "Я никуда не уйду, знаешь ли."

    xy "Я... я знаю..."

    "Прекрасно, теперь она меня поддразнивает..."

    "Подавив своё стремление к спешке, я успокоил себя и осторожно расстегнул её лифчик."
    $ sename = "se人体_動作_衣擦れ02"
    play se sedict[sename]
    pause (500/1000)
    show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントc"]+".jpg") as 絵専 zorder 0 at truecenter
    with Dissolve(1000.0/1000)
    pause (500/1000)
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントc"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(500.0/1000)
    pause (800/1000)
    voice "voice/a72/1100190a01.opus"

    mx "Шиничи... я польщена, но ты меня смущаешь..."
    voice "voice/a72/1100200a01.opus"

    mx "Не глазей... посмотри на меня..."
    hide 絵専
    with Dissolve(500.0/1000)
    voice "voice/a72/1100210a01.opus"

    mx "М-мф... м-м-м..."

    "И в \"наказание\" за то, что я пялился на её грудь, Миюки поцеловала меня."

    "Я обнял её ещё раз, впервые прижав наши голые груди друг к другу."

    "Они были мягче, чем всё, что я когда-либо чувствовал за всю свою жизнь..."

    "И на самих кончиках—"
    show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントc"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(600.0/1000)
    pause (1000/1000)

    xy "Твои соски потвердели."

    xy "Этот поцелуй тебя так сильно заводит?"
    voice "voice/a72/1100220a01.opus"

    mx "Д-да..."
    voice "voice/a72/1100230a01.opus"

    mx "Похоже на то..."

    "Она наклонила голову от озадаченности. Боже, она такая милая, я не могу!"
    $ sename = "se人体_動作_押し倒す"
    play se sedict[sename]
    pause (16/1000)
    hide 絵専
    show expression ("cg/bg/l/"+imagename["bg030300_3_自宅リビング_l"]+".jpg") as 絵背景 zorder 100 at truecenter
    with Dissolve(150.0/1000)
    voice "voice/a72/1100240a01.opus"

    mx "А-а-ах!"

    "Я толкнул её на диван."
    voice "voice/a72/1100250a01.opus"

    mx "Шиничи... М-м-мф... м-м... м-м..."
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳a"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(1000.0/1000)
    pause (1000/1000)

    show expression ("cg/ev/l/"+imagename["eva7211美雪さんご開帳a_l"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(800.0/1000)
    pause (1000/1000)

    "Её щёки покраснели от предвкушения... и напряжения."

    xy "Тебе страшно?"
    voice "voice/a72/1100260a01.opus"

    mx "...Я ещё никому не позволяла увидеть меня такой..."

    "Получается, я был первым, кто заставил её испытать такие чувства."

    "Я не мог больше сдерживаться, даже на одну секунду."
    $ sename = "se人体_擬音_水音"
    play se sedict[sename]
    xy "\"Миюки...\""
    show expression ("cg/ev/l/"+imagename["eva7211美雪さんご開帳c_l"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/a72/1100270a01.opus"

    mx "Н-нгха-а... н-н-н... а-ах! О боже... не лижи их так громко!.."
    voice "voice/a72/1100280a01.opus"

    mx "Как же неловко— А-А-АХ! Твой язык— трогает мой сосок— А-АХ!"

    "Всякий раз, когда мой язык касался её груди, её тело дёргалось и пошатывалось."
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳a"]+".jpg") as 絵専 zorder 1010 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳c"]+".jpg") as 絵捏造窓 zorder 1010 at truecenter
    with Dissolve(500.0/1000)

    "Я начал тянуть свои губы ниже.。"

    "Я неохотно оторвался от её груди, скользя своим языком по нежному склону её живота и пройдя мимо её милого маленького пупка..."
    $ sename = "se人体_擬音_水音"
    play se sedict[sename]
    pause (300/1000)
    voice "voice/a72/1100290a01.opus"

    mx "А-ах!"

    "...пока я не дошёл до её трусиков."

    "Потом я прошёл по изгибу её ляжек, пока моя голова не оказалась прямо между её ног—"
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳a"]+".jpg") as 絵専 zorder 1010 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳b"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    with Dissolve(300.0/1000)
    voice "voice/a72/1100300a01.opus"

    mx "А-ах! Нет! Не надо!"

    xy "О, ты уже намокла—"
    voice "voice/a72/1100310a01.opus"

    mx "Заткнись!"
    voice "voice/a72/1100320a01.opus"

    mx "Я знаю, что я мокрая, ладно?!"
    voice "voice/a72/1100330a01.opus"

    mx "В смысле, ты разве можешь винить меня за это? Я просто очень сильно тебя люблю..."

    xy "...Миюки..."
    hide 絵捏造窓
    with Dissolve(300.0/1000)
    voice "voice/a72/1100340a01.opus"
    mx "......"
    voice "voice/a72/1100350a01.opus"

    mx "Ты хочешь посмотреть, да..."

    "По правде говоря, я очень хочу это увидеть..."
    voice "voice/a72/1100360a01.opus"

    mx "...Поняла..."
    voice "voice/a72/1100370a01.opus"
    mx "Ладно..."

    "Она слабо вздохнула."
    voice "voice/a72/1100380a01.opus"

    mx "...Приступай."
    $ sename = "se人体_動作_衣擦れ濡れ場03"
    play se sedict[sename]

    "Я нежно снял с неё трусики."
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳b"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳a"]+".jpg") as 絵捏造窓絵専上 zorder 1110 at truecenter
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    pause (500/1000)
    voice "voice/a72/1100390a01.opus"

    mx "А-ах... н-н-н..."
    voice "voice/a72/1100400a01.opus"
    mx "......"

    "Миюки затихла и отвернулась."

    "Чем дольше я ждал, тем сильнее краснело её лицо."
    voice "voice/a72/1100410a01.opus"

    mx "...Скажи уже что-нибудь!"

    xy "Ты красивая."
    voice "voice/a72/1100420a01.opus"

    mx "Заткнись!"
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳b"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳c"]+".jpg") as 絵捏造窓絵専上 zorder 1110 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1100430a01.opus"

    mx "Н-нгха-а! Н-н-н!.."
    $ sename = "se人体_動作_衣擦れ濡れ場04"
    play se sedict[sename]

    "Не в состоянии остановить себя, я протянул руку и коснулся её киски."

    "Её половые губы уже были смазаны жидкостью."
    $ sename = "se人体_擬音_水音"
    play se sedict[sename]
    voice "voice/a72/1100440a01.opus"

    mx "А-а-ах! А-ах... а-ах... н-н-н-н! Ха-а... н-н-н... ха-а... н-н-н... н-нгха-а-а-а!"

    "Малейшее прикосновение заставляло Миюки извиваться."

    "А это значит—"
    $ sename = "se人体_動作_衣擦れ濡れ場02"
    play se sedict[sename]
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳b"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳c"]+".jpg") as 絵捏造窓絵専上 zorder 1110 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1100450a01.opus"

    mx "А-а-а-ах!"
    voice "voice/a72/1100460a01.opus"

    mx "А-ах! Эй! Перестань! Это очень чувствительное— Н-нгха-а-а-а!"

    "И, разумеется, когда я прижимал палец к её клитору, она начинала извиваться ещё сильнее."
    voice "voice/a72/1100470a01.opus"

    mx "А-ах! Н-нгха-а! Эй! Не... Не будь таким грубым—"
    voice "voice/a72/1100480a01.opus"

    mx "...А?"
    hide 絵捏造窓
    hide 絵専
    with Dissolve(400.0/1000)
    voice "voice/a72/1100490a01.opus"

    mx "Ч-что ты делаешь? Убери своё лицо! Ха-а! Эй! Твоё дыхание щекочет—!"

    "Миюки пыталась отодвинуться, но я схватил её за ноги обеими руками и притянул свои губы прямо к её влажной киске."
    $ sename = "se人体_擬音_水音"
    play se sedict[sename]
    show expression ("cg/ev/l/"+imagename["eva7211美雪さんご開帳b_l"]+".jpg") as 絵専前 zorder 1100 at truecenter
    show expression ("cg/ev/l/"+imagename["eva7211美雪さんご開帳c_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(300.0/1000)
    pause (1000/1000)
    with Dissolve((2000.0+1000.0)/1000)
    voice "voice/a72/1100500a01.opus"

    mx "Н-нха-а-а-а-а-а-а-а-а-а-а-а-а-а!!!"
    voice "voice/a72/1100510a01.opus"

    mx "ЭЙ! Придурок! П-перестань сейчас же! Не суй туда свой рот! Это мерзко— А-А-АХ!"
    voice "voice/a72/1100520a01.opus"

    mx "О боже... Хватит! Я чувствую, как твой язык... извивается вокруг... Почему мне от этого так—?!"
    voice "voice/a72/1100530a01.opus"

    mx "А-А-А-А-АХ! Не соси его! Это слишком интенсивно— А-АХ! Это так приятно—!"
    hide 絵専前
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳c"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(500.0/1000)

    "С течением времени, Миюки чувствовала себя комфортнее в своей шкуре."

    "Её стоны становились громче, и, судя по всему, чем больше шума я создавал, тем сильнее она от этого заводилась."
    voice "voice/a72/1100540a01.opus"

    mx "Ха-а... а-ах... а-ах!.. О боже! А-а-ах... я слышу, как ты хлюпаешь—!"
    voice "voice/a72/1100550a01.opus"

    mx "Это так приятно... это сводит меня с ума... я схожу с ума—! Шиничи... можно мне... можно мне расслабиться?"

    "В ответ я прижал кончик своего языка к её набухшему клитору."
    voice "voice/a72/1100560a01.opus"

    mx "А-А-А-АХ! О боже! Прямо здесь! Мне страшно— как же хорошо— а-а-а-ах!"
    voice "voice/a72/1100570a01.opus"

    mx "Я сейчас... я сейчас кончу, Шиничи... я сейчас кончу! Н-нг-гх... н-нха-а... Я кончаю, я кончаю, я кончаю!"
    voice "voice/a72/1100580a01.opus"

    mx "Я КОНЧА-А-А-А-А-АЮ—!!!"
    stop se fadeout (150.0/1000)
    show expression Solid("FFFFFF") as 絵演色白 zorder 5000
    with Dissolve((200.0+800.0)/1000)
    with Dissolve((250.0+1000.0)/1000)
    hide 絵板写
    pause (500/1000)
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳c"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さんご開帳d"]+".jpg") as 絵捏造窓絵専上 zorder 1110 at truecenter
    hide 絵演色白
    with Dissolve(1500.0/1000)
    pause (2000/1000)
    voice "voice/a72/1100590a01.opus"

    mx "А-ах... а-ах... а-ах... н-нг-г... н-н-н... н-н-н-н... н-н... н-н-н... н-н..."
    voice "voice/a72/1100600a01.opus"

    mx "А-ах... н-н... н-н-н... н-н-н-н... Шиничи... Что... произошло со мной?.."

    xy "Наверное, у тебя только что был оргазм?.."
    voice "voice/a72/1100610a01.opus"

    mx "Я... наверное... Я не совсем уверена... это было так приятно... мой разум... просто опустел..."
    voice "voice/a72/1100620a01.opus"

    mx "Твой язычок... заставил меня кончить..."
    show expression ("cg/ev/l/"+imagename["eva7211美雪さんご開帳d_l"]+".jpg") as 絵専 zorder 1200 at truecenter
    with Dissolve(500.0/1000)
    pause (500/1000)

    "Она смотрела на меня затуманенным, несосредоточенным взглядом."

    "Прямо сейчас она была абсолютно беззащитной."

    "Я хочу обнять её..."

    "Я хочу сделать её своей..."
    $ sename = "se人体_動作_抱きつく01"
    play se sedict[sename]
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失a"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/ev/l/"+imagename["eva7211美雪さん処女喪失a_l"]+".jpg") as 絵専上 zorder 1200:
        pos (-200,-10)
    with Dissolve(1000.0/1000)
    pause (1000/1000)

    xy "Миюки, я..."
    voice "voice/a72/1100630a01.opus"
    mx "А-ах..."
    pause (500/1000)

    "Я наклонился и прижал свой набухший член к её влажному проходу."
    voice "voice/a72/1100640a01.opus"

    mx "Не может быть... Он такой большой!.."
    voice "voice/a72/1100650a01.opus"

    mx "Он такой твёрдый... и горячий... как будто он сейчас взорвётся..."

    "По крайней мере, она была права насчёт этого момента."

    "Даже без какой-либо прямой стимуляции, у меня уже давно в штанах была разбита палатка."

    "На самом слабом участке кожи - где происходил обмен тепла с телом - я почувствовал, как преякулят начал вытекать из моей головки в предвкушении."
    xy "\"Миюки.\""
    voice "voice/a72/1100660a01.opus"

    mx "Д-да... я знаю... я готова."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
