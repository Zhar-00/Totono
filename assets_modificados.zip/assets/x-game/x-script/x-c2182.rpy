label c2182_MAIN:
    call expression GameName
    $ persistent.imagelog["efbg猫ヘアピンソロ"]=True
    $ PreGameName = GameName
    $ GameName = "a2183.nss"
    $ miyuki_plot = True
    return
label c2182:
    hide 絵色黒
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg070100_2_雑貨店店内"]+".jpg")
    show expression ("cg/ef/"+imagename["efbg猫ヘアピンソロ"]+".jpg") as 絵背景 zorder 100 at truecenter
    pause (500/1000)

    "Очевидно, это был единственный в своём роде предмет ручной работы. Его орнамент был слегка закрученным."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
