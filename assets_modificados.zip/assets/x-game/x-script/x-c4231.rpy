label c4231_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label c4231:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    scene expression Solid("000000") as 絵色黒
    show expression ("cg/bg/l/"+imagename["bg900100_3_雰囲気空_l"]+".jpg") as 絵背景 zorder 1000:
        xcenter .5
        ypos 0
        linear 300 ypos -576
    show expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")
    hide 上背景
    hide 絵色黒
    with Dissolve(2000.0/1000)

    "Как и следовало ожидать, чем больше мы разговаривали, тем больше Аой, судя по всему, выздоравливала."

    "Как будто она и правда перезаряжала свои батарейки."

    xy "\"Эй, могу ли я спросить тебя кое о чём?\""

    xy "\"Зачем ты нас так напугала?\""
    voice "voice/c42/3100010a02.opus"
    aoi "......"

    "Озадаченная, Аой уставилась на небо."

    "Звёзды мерцали в море тьмы."

    "И вот мы здесь, в центре вселенной."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_見上げ_normal")
    hide 絵背景
    with Dissolve(800.0/1000)
    voice "voice/c42/3100020a02.opus"
    aoi "\"Этот мир - ВИДЕОИГРА.\""
    voice "voice/c42/3100030a02.opus"

    aoi "\"В этом руте, Аой - второстепенный персонаж.\""
    $ St("C",300,0,0,"bu向日アオイ電波_制服_見上げ_think")
    with Dissolve(200.0/1000)
    voice "voice/c42/3100040a02.opus"

    aoi "\"Но... Аой заглючило.\""
    voice "voice/c42/3100050a02.opus"

    aoi "\"В программе нашёлся баг.\""
    voice "voice/c42/3100060a02.opus"

    aoi "\"И он не будет исправлен, пока моя передача не пройдёт.\""
    $ St("C",300,0,0,"bu向日アオイ電波_制服_見上げ_normal")
    with Dissolve(200.0/1000)
    voice "voice/c42/3100070a02.opus"

    aoi "\"Именно поэтому Аой и исчезла.\""

    xy "\"Без объяснений? И даже не попрощавшись?\""
    $ St("C",300,0,0,"bu向日アオイ電波_制服_見上げ_lost")
    with Dissolve(200.0/1000)
    voice "voice/c42/3100080a02.opus"

    aoi "\"Как только Аой ушла, ты должен был забыть её.\""
    voice "voice/c42/3100090a02.opus"

    aoi "\"Таково правило этой вселенной.\""

    xy "\"Ну, прости, но я не мог тебя забыть.\""

    xy "\"Мы с Ютаро искали тебя по всему чёртовому городу.\""
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c42/3100100a02.opus"

    aoi "\"Меня?\""

    xy "\"Есть кое-что, что мне правда надо скинуть со своей души.\""

    "Всё то время, что я бежал по всему городу, я спрашивал себя: зачем я ищу её?"



    "И как только я нашёл её, что я хотел сказать ей?"

    "Как выяснилось, я хотел поговорить с ней о—"
    return
    return
label c4231_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_think")
    with Dissolve(0.0/1000)
    menu:
        "Миюки":
            $ SetChoiceSelect = 0
        "Сама Аой":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "d4232.nss"
    elif SetChoiceSelect==1:
        $ GameName = "c4232.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
