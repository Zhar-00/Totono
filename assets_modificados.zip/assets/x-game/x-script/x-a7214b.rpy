label a7214b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label a7214b:
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/bg/l/"+imagename["bg030300_3_自宅リビング_l"]+".jpg") as 絵背景 zorder 15:
        pos (620,-410)
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失f"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(0.0/1000)
    voice "voice/a72/14b00010a01.opus"

    mx "\"Слушай, Шиничи...\""
    voice "voice/a72/14b00020a01.opus"

    mx "\"Тебе ведь нравится... экспериментировать, верно?..\""
    voice "voice/a72/14b00030a01.opus"

    mx "\"Сегодня... особенный день, так что... я бы предпочла... чтобы ты кончил в меня... но...\""
    voice "voice/a72/14b00040a01.opus"

    mx "\"Н-н-нг... н-н-н... если хочешь... разнообразия...\""
    voice "voice/a72/14b00050a01.opus"

    mx "\"Ты всегда можешь... н-н-нг... кончить на меня... если хочешь!.. Н-н-н!\""
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失c"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    with Dissolve(300.0/1000)
    voice "voice/a72/14b00060a01.opus"

    mx "\"Как ты сам захочешь... ладно?\""

    "От искушения мой мозг начал плавиться."

    "И почувствовав, что я уже на грани семяизвержения, я—"
    return
label a7214b_SELECT:
    $ lastsel = "a7214b_SELECT"
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失f"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失c"]+".jpg") as 絵捏造窓絵専上 zorder 1110 at truecenter
    with Dissolve(0.0/1000)
    menu:
        "Кончить в неё":
            $ SetChoiceSelect = 0
        "Кончить на неё":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==1:
        $ bukkake = True
        $ persistent.library_scene1_out = True
    $ GameName = "a7214a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
