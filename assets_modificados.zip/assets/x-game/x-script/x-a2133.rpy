label a2133_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a2134.nss"
    return
label a2133:
    hide 絵色黒 with dissolve
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010300_1_学校屋根_l"]+".jpg") as 絵背景 zorder 100 at center
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    with Dissolve(1500.0/1000)
    voice "voice/a21/3300010a01.opus"
    mx "Фух, я наелась."
    xy "Я тоже."
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    voice "voice/a21/3300020a01.opus"
    mx "А теперь давайте начнём делать домашку по мате—"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    voice "voice/a21/3300030a02.opus"
    aoi "Буп-буп... Батарея сильно разряжена..."
    xy "Дай угадаю. Тебе нужна перезарядка?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_smile")
    voice "voice/a21/3300040a01.opus"
    mx "Хех. У меня было предчувствие, что это случится."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Сказав это, Миюки достала что-то из своего упакованного обеда."
    $ sename = "se物体_缶_開ける"
    play se sedict[sename]
    pause (300/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_surprise")
    voice "voice/a21/3300050a02.opus"
    aoi "Буп-буп..."
    voice "voice/a21/3300060a02.opus"
    aoi "Этот звук... Этот запах..."
    show expression ("cg/ef/"+imagename["efbgヤバトマ"]+".jpg") as 絵画像 zorder 1000 at center
    with Dissolve((500.0+1000.0)/1000)
    pause (300/1000)
    voice "voice/a21/3300070a02.opus"
    aoi "Это же Ябалей!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    hide 絵画像
    with Dissolve(500.0/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    voice "voice/a21/3300080a01.opus"
    mx "Хочешь?"
    voice "voice/a21/3300090a02.opus"
    aoi "А Аой можно?"
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_normal")
    voice "voice/a21/3300100a01.opus"
    mx "Только если ты пообещаешь сделать свою домашку после того, как выпьешь его."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_shout")
    voice "voice/a21/3300110a02.opus"
    aoi "Буп... буп... буп-буп!"
    voice "voice/a21/3300120a02.opus"
    aoi "Договорились! Одна банка Ябалея зарядит меня!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_病み_smile")
    voice "voice/a21/3300130a01.opus"
    mx "Прекрасно."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Миюки передала ей банку."
    voice "voice/a21/3300140a02.opus"
    aoi "Гл-л-л-л... гл-л-л-л... гл-л-л-л... гл-л-л-л..."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/3300150a02.opus"
    aoi "Фух!.."
    "Аой выпила всё до дна за один присест, как и в прошлый раз."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/3300160a02.opus"
    aoi "Перезарядка завершена."
    voice "voice/a21/3300170a01.opus"
    mx "Тебе правда нравится томатный сок, м-м?"
    voice "voice/a21/3300180a02.opus"
    aoi "Он просто божественен."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/3300190a02.opus"
    aoi "Не хочешь?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    voice "voice/a21/3300200a01.opus"
    mx "Что? Нет, я—"
    voice "voice/a21/3300210a02.opus"
    aoi "Не стесняйся. Попробуй."
    voice "voice/a21/3300220a01.opus"
    mx "Эм... Ну... Насчёт этого..."
    voice "voice/a21/3300230a02.opus"
    aoi "Миюки, тебе не нравятся томаты?"
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    voice "voice/a21/3300240a01.opus"
    mx "Я просто пока не хочу его пить, вот и всё."
    "По правде говоря, в её обеде УЖЕ были томаты."
    xy "Да ладно, не отказывайся, пока не попробуешь."
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_shout")
    voice "voice/a21/3300250a01.opus"
    mx "Я вовсе не «отказываюсь»!"
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_normal")
    voice "voice/a21/3300260a01.opus"
    mx "Ну да ладно. Давайте начнём делать нашу домашку."
    xy "Развлекайтесь."
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_shout")
    voice "voice/a21/3300270a01.opus"
    mx "Ты её тоже делаешь, мистер!"
    xy "...Да, мэм..."
    pause (800/1000)
    scene expression Solid("000000") as 絵色黒 zorder 5000 with dissolve
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
