label e2232b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2233a.nss"
    return
label e2232b:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(0.0/1000)

    xy "\"Не согласен.\""

    xy "\"У неё есть сентиментальная ценность, понимаешь? Воспоминания о последнем человеке, который сидел за ней. Ты не можешь называть это мусором.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e22/32b00010a01.opus"

    mx "\"Ты хоть помнишь, кто сидел за ней последним?\""

    xy "\"Ну...\""

    "Я напряг мозги."

    "Хм-м-м..."

    "Облом. Не могу вспомнить."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/32b00020a01.opus"

    mx "\"Правильно! За ней никто не сидел.\""

    "Ну ладно. Я и не удивлён, что не смог вспомнить."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
