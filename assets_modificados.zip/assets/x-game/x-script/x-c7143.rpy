label c7143_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ persistent.c_route = True
    $ persistent.title_on = False
    python:
        if persistent.passed_c_route_month == None or persistent.passed_c_route_day == None:
            from time import strftime, localtime
            persistent.passed_c_route_month = int(strftime("%m",localtime()))
            persistent.passed_c_route_day = int(strftime("%d",localtime()))
            persistent.DIARY_COUNT += 1
    $ DeleteAllSave()
    $ renpy.quit(relaunch=True)
    return
label c7143:
    hide 絵色黒
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/bg/l/"+imagename["bg030100_3_自宅自室_l"]+".jpg") as 絵演出背景 zorder 15 at truecenter
    $ St("C",300,150,0,"fu曽根美雪血まみれ_私服_恋人_mad")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"fu曽根美雪血まみれ_私服_病み_lost")
    with Dissolve(400.0/1000)
    pause (700/1000)
    voice "voice/c71/4300010a01.opus"
    mx "\"ТЫ... предал меня.\""
    pause (300/1000)
    $ St("C",300,0,0,"fu曽根美雪血まみれ_私服_病み_mad")
    with Dissolve(300.0/1000)
    pause (700/1000)
    voice "voice/c71/4300020a01.opus"
    mx "\"И теперь... я собираюсь отомстить.\""
    stop bgm fadeout (3000.0/1000)
    pause (700/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(500.0/1000)
    pause (500/1000)
    show expression ("cg/ef/"+imagename["efbg自宅自室天井昼"]+".jpg") as 絵背景 zorder 100 at center
    with Dissolve((1000.0+1000.0)/1000)
    $ sename = "se人体_動作_衣擦れ04"
    play se sedict[sename]
    $ sename = "se物体_バット_地面叩く"
    play se sedict[sename]
    pause (800/1000)
    pause (1500/1000)
    xy "\"Миюки?!..\""
    "Она осторожно подставила конец своей биты..."
    "...прямо к моей мошонке."
    "Я вздрогнул."
    voice "voice/c71/4300030a01.opus"
    mx "\"Я знаю, что ты просто самостоятельный персонаж.\""
    voice "voice/c71/4300040a01.opus"
    mx "\"Но моё сердце не согласно с этим.\""
    voice "voice/c71/4300050a01.opus"
    mx "\"Так что... здесь мы и попрощаемся.\""
    xy "\"С-стой... Пожалуйста, остановись!\""
    voice "voice/c71/4300060a01.opus"
    mx "\"Всё нормально. Ты можешь просто начать сначала.\""
    "Миюки смотрела на меня с почти заскучавшим видом."
    voice "voice/c71/4300070a01.opus"
    mx "\"Пора исправить эти баги, м-м?\""
    xy "\"Миюки! Сто—\""
    pause (1500/1000)
    stop bgm fadeout (0.0/1000)

    scene black
    $ renpy.pause(1)
    scene expression "cg/ef/0e78f89a3c4e30c312266c18d9aa1b2ecd9964b6.jpg"
    with Dissolve(5)

    voice "voice/c71/4300080a01.opus"
    mx "\"Алло? Бог?\""
    voice "voice/c71/4300090a01.opus"
    mx "\"Сохрани мои воспоминания. Шоу начинается.\""
    voice "voice/c71/4300100a01.opus"
    mx "\"Используй мой мод-патч...\""
    voice "voice/c71/4300110a01.opus"
    mx "\"...и установи обновление для игры [[Ты, я и она].\""
    voice "voice/c71/4300120a01.opus"
    mx "\"С ДнЁМ РоЖДЕниЯ\""

    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
