label a6141_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if temp_root_recreate == False:
        $ GameName = "b6142.nss"
    else:
        $ GameName = "a6142.nss"
    return
label a6141:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    show expression Solid("000000") as 絵色黒
    with Dissolve(0.0/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (300/1000)
    $ sename = "se物体_紙_手紙開く"
    play se sedict[sename]
    pause (700/1000)
    "Я был прикован к месту с билетом в руках."
    "На этом выступлении произойдёт первый поцелуй Миюки."
    "И оно начнётся уже завтра."
    xy "......"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
