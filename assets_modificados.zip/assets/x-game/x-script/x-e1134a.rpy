label e1134a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1135.nss"
    $ roof = True;
    return
label e1134a:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(0.0/1000)

    xy "\"Прости, Ютаро! Нужно бежать!\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Я взял Миюки за руку и начал бежать."
    voice "voice/e11/34a00010a01.opus"
    mx "\"Увидимся позже, Акебоно-кун!\""
    voice "voice/e11/34a00020b01.opus"
    xtl "\"Эм... ладно! Увидимся!\""
    $ sename = "se人体_足音_走る複数美雪L"
    play se sedict[sename]

    "После этого мы оставили Ютаро позади так, будто бежали со сцены."
    stop se fadeout 1.5
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    hide 絵色黒
    with Dissolve(1000.0/1000)
    xy "\"Боже, Ютаро вёл себя как-то странно...\""

    "Мы виделись каждый день в школе, но он почему-то говорил так, будто мы не общались месяцами или ещё что..."

    "И что за автокатастрофа?.."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/34a00030a01.opus"
    mx "\"Он немного рассеянный в последнее время.\""
    xy "\"С чего бы?\""
    voice "voice/e11/34a00040a01.opus"
    mx "\"Я слышала, что он и Хару-чан встречаются.\""
    xy "\"...Серьёзно?!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/e11/34a00050a01.opus"
    mx "\"Серьёзно.\""
    hide StC with Dissolve(200.0/1000)

    "Срань господня."

    "Если это правда, то... наследию клуба «Ребята и мечты» придёт конец."

    "Я не совсем уверен, должен ли я радоваться или грустить..."

    "Стоп."

    "Разве они не родственники?.."
    show expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg")
    with Dissolve(500.0/1000)
    $ sename = "se人体_足音_歩く複数美雪L"
    play se sedict[sename]

    "Мы вместе шли в школу, держась за руки."

    "Мы иногда проходили мимо других учеников в такой же форме, но меня это нисколько не смущало."

    "Я горжусь быть парнем Миюки."
    show expression ("cg/bg/"+imagename["bg010400_2_学校校門"]+".jpg")
    with Dissolve(500.0/1000)
    xy "\"Эй, в общем, куда мы идём?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/34a00060a01.opus"
    mx "\"К центру вселенной.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/34a00070a01.opus"
    mx "\"Я решила... рассказать тебе всю правду.\""
    hide StC with Dissolve(200.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010500_2_学校昇降口"]+".jpg")
    pause (200/1000)
    hide 絵色黒
    with Dissolve(500.0/1000)
    pause (1000/1000)
    show expression ("cg/bg/"+imagename["bg010700_2_学校廊下"]+".jpg")
    $ sename = "se人体_足音_歩く複数美雪廊下"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    pause (1000/1000)
    show expression ("cg/bg/"+imagename["bg010100_2_学校階段"]+".jpg")
    with Dissolve(500.0/1000)
    pause (1000/1000)
    $ sename = "se物体_ドア鉄_開く01"
    play se sedict[sename]
    pause (1200/1000)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    show expression ("cg/ef/"+imagename["efbg空汎用西日"]+".jpg") as 絵背景
    with Dissolve(600.0/1000)
    pause (1000/1000)
    $ roof = True;
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    hide 絵背景
    with ImageDissolve("cg/data/circle_04_00_0.png",3)
    pause (1000/1000)
    xy "\"М-м-м...\""

    "Я улыбнулся себе."

    "Солнце заходило за горизонт."

    "Его лучи ослепительны."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/34a00080a01.opus"
    mx "\"Стой здесь.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    show expression ("cg/bg/"+imagename["bg010210_2_学校屋上屋根向"]+".jpg")
    with Dissolve(500.0/1000)

    "Миюки схватилась за поручень лестницы, ведущей на крышу над лестничной клеткой; это была самая верхняя часть школьной крыши."
    voice "voice/e11/34a00090a01.opus"
    mx "\"Не подглядывай!\""
    xy "\"Знаю я, знаю...\""
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]

    "Какое клише..."

    "Тем временем, Миюки быстро залезла на самый верх крыши."

    "Я видел её силуэт на закате."

    "Её красота имела поразительное, почти потустороннее качество."
    voice "voice/e11/34a00100a01.opus"
    mx "\"Ты ведь знаешь, зачем я привела тебя сюда сегодня, верно?\""
    xy "\"Эм, нет?.. Вообще без понятия.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
