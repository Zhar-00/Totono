label a6211_MAIN:
    call expression GameName
    $ persistent.imagelog["eva6211美雪演劇キスb"]=True
    $ PreGameName = GameName
    $ GameName = "a6221.nss"
    return
label a6211:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010802_2_学校体育館演劇中"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010802_2_学校体育館演劇中_l"]+".jpg") as 絵背景 zorder 100:
        xcenter .5
        ypos -500
    show expression ("cg/bg/l/"+imagename["bg010802_2_学校体育館演劇中_l"]+".jpg") as 絵背景上 zorder 100:
        xcenter .5
        ypos -500
    with dissolve
    hide 上背景
    $ sename = "se物体_演劇_ブザー"
    play se sedict[sename]
    $ sename = "se環境_ガヤ_拍手L"
    play se sedict[sename]
    "Занавес раскрылся под бурные аплодисменты."
    $ sename = "se人体_動作_バットスイング01"
    play se sedict[sename]
    with Dissolve((300.0+1000.0)/1000)
    hide 絵色白
    with Dissolve(300.0/1000)
    $ renpy.music.play("ttb24",channel = "bgm", if_changed = True)
    "Выйдя на сцену, Миюки внезапно начала махать битой."
    "В тихой аудитории можно было расслышать только звуки биты, проходящей сквозь воздух."
    "Её замах был идеальным."
    "Она ничего не говорила, но её действия говорили за неё всё, привлекая тем самым внимание аудитории."
    "Но это всё было для Миюки детской игрой."
    hide 絵専
    with Dissolve(1000.0/1000)
    "Здесь, в аудитории, мой взгляд был прикован к ней."
    "Её голос раздавался эхом в моих ушах."
    "Её слова пронизывали меня до глубины души."
    show expression ("cg/bg/l/"+imagename["bg010802_2_学校体育館演劇中_l"]+".jpg") as 絵背景 zorder 101:
        pos (0,-800)
        zoom 2
        linear 20 xpos -600
    with Dissolve(1000.0/1000)
    "Каждое её движение безотказно притягивало к себе моё внимание."
    "Один её малейший жест уже завораживал меня."
    "А её губы—"
    "Чем дольше я наблюдал за ней, тем сильнее я начинал нервничать."
    "Сейчас я даже не мог уловить ход сюжета."
    hide 絵背景
    with Dissolve(1000.0/1000)
    "Что-то про бейсболиста, заполняющего место в женской команде по софтболу."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    "В тот момент, когда актёр оказался в поле моего зрения, мне стало не по себе."
    "Мне очень хотелось спрыгнуть со стула и убежать за дверь."

    "Мне хотелось исчезнуть."
    "Но моё тело не двигалось."
    show expression ("cg/ev/l/"+imagename["eva6211美雪演劇キスa_l"]+".jpg") as 絵専 zorder 1100:
        pos (-280,-10)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    "И вскоре началась кульминационная сцена."
    show expression ("cg/ev/"+imagename["eva6211美雪演劇キスa"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵専
    with Dissolve(500.0/1000)
    "Я так больше не могу."
    "У меня уже сил нет."
    "Я хочу уйти отсюда."
    "Мне надо уйти."
    "Сейчас же."
    "Я не хочу заставлять себя смотреть на это."
    "И мне всё равно, что вся аудитория будет после этого смеяться надо мной."
    "В моей груди было такое ощущение, будто она сейчас взорвётся."
    "Я не вынесу этих мучений—"
    hide 絵専
    with Dissolve(1000.0/1000)
    voice "voice/a62/1100010a01.opus"
    mx "—Шиничи!"
    xy "А?.."
    with Dissolve(1000.0/1000)
    hide 絵専
    show expression ("cg/ev/l/"+imagename["eva6211美雪演劇キスb_l"]+".jpg") as 絵専 zorder 1101:
        pos (380,680)
    show expression ("cg/ev/l/"+imagename["eva6211美雪演劇キスa_l"]+".jpg") as 絵専上 zorder 1101:
        pos (380,680)
    with Dissolve(1000.0/1000)
    pause (500/1000)
    pause (500/1000)
    "А потом я понял."
    "Миюки должна была выступать сейчас."
    "Она была уже в середине своей красиво выполненной сцены поцелуя."
    "Но как только эти двое сблизились..."
    "Её губы скрутились с малейшим намёком на страдания."
    "Никто не увидел этого промаха в её безупречной игре..."
    show expression ("cg/ev/"+imagename["eva6211美雪演劇キスb"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(800.0/1000)
    stop bgm fadeout (6000.0/1000)
    "...Никто, кроме меня."
    xy "......!!!"
    with Dissolve(500.0/1000)
    "Меня уже не волновало само выступление."
    "Меня сейчас волновала только Миюки."
    "Я хочу спасти её от этих страданий."
    "И для этого..."
    "...я должен испортить это выступление."
    show expression ("cg/ev/l/"+imagename["eva6211美雪演劇キスb_l"]+".jpg") as 絵専上:
        pos (-440,-120)
    with Dissolve((800.0+1000.0)/1000)
    "Расстояние между ними медленно уменьшалось."
    "Я должен позвать её по имени..."
    "Я должен испортить это выступление и спасти её..."
    with Dissolve((0.0+1000.0)/1000)
    $ sename = "se人体_動作_座るソファー"
    play se sedict[sename]
    "Я встал на ноги в центре аудитории...{nw=1}"
    stop bgm fadeout (200.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 4000 with None
    $ sename = "se物体_体育館_停電"
    play se sedict[sename]

    pause (300/1000)
    with Dissolve((0.0+1000.0)/1000)
    pause (50/1000)
    pause (50/1000)
    with Dissolve((150.0+1000.0)/1000)
    with Dissolve((0.0+1000.0)/1000)
    pause (100/1000)
    hide 絵色白
    with Dissolve(200.0/1000)
    "...но прежде, чем их губы слились в поцелуе, сцена вдруг потемнела."

    pause (3000/1000)
    "Произошло отключение электричества."
    $ EyeCatchIn(0.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
