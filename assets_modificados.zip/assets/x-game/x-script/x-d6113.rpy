label d6113_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d6151.nss"
    return
label d6113:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030200_2_自宅玄関"]+".jpg")
    with Dissolve(0.0/1000)

    xy "\"Извини, приятель. Шоу скоро начнётся. Мне надо идти.\""
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]
    play voc "d61/1300010b04"
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]

    "Я отпихнул его в сторону и открыл дверь."
    show expression ("cg/bg/"+imagename["bg020100_2_自宅外正面"]+".jpg")
    with Dissolve(500.0/1000)
    play voc "d61/1300020b04"
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]

    xy "\"Эй! А ну тащи свою задницу обратно!\""

    xy "\"Аой сейчас нездоровится. Мне надо, чтобы ты остался здесь и присмотрел за ней, ладно?\""
    $ sename = "se物体_ドア自宅_鍵開ける02"
    play se sedict[sename]

    "Я схватил его и вышвырнул обратно в дом, после чего плотно закрыл дверь."
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((1000.0+1000.0)/1000)
    pause (500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
