label c4171_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4181.nss"
    $ yutaro_help = True
    return
label c4171:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010600_1_学校教室_l"]+".jpg") as 絵背景 zorder 15:
        pos (-550,-290)
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(0.0/1000)

    "Ютаро готов разорвать со мной связи из-за этого."

    "Я уже давно закрываю на это глаза, но..."

    "...я знаю, что не могу сидеть на жопе ровно."
    xy "\"Я пойду поищу Аой.\""
    stop bgm fadeout (1000/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/c41/7100010b01.opus"
    xtl "\"ВОТ ЭТО МОЙ МАЛЬЧИК!!!\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/c41/7100020b01.opus"
    xtl "\"Вот это НАСТОЯЩИЙ член РиМ, которого я когда-либо видел!\""
    $ sename = "se物体_紙_破かれる"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Ютаро разорвал письмо об изгнании."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/c41/7100030b01.opus"
    xtl "\"Поиски начнутся сегодня, после занятий!\""

    xy "\"А? Ты пойдёшь со мной?\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_happy")
    with Dissolve(200.0/1000)
    voice "voice/c41/7100040b01.opus"
    xtl "\"Ну конечно! Всё-таки я твой капитан!\""
    xy "\"Ха-ха-ха... ладно. Тогда увидимся.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_shy")
    with Dissolve(200.0/1000)
    voice "voice/c41/7100050b01.opus"
    xtl "\"Обязательно!\""
    $ sename = "se人体_動作_抱きつく01"
    play se sedict[sename]
    $ sename = "se人体_動作_掴む胸倉"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)

    "Мы обменялись крепким рукопожатием. А в это время..."
    hide 絵背景
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(500.0/1000)
    voice "voice/c41/7100060a01.opus"
    mx "\"......\""

    "...Миюки молча смотрела на нас в другой части комнаты."
    show expression Solid("000000") as 絵色黒 zorder 30000
    with Dissolve((500.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
