label a5111_MAIN:
    call expression GameName
    $ persistent.imagelog["bg030300_1_自宅リビング"]=True
    $ PreGameName = GameName
    $ GameName = "a5112.nss"
    return
label a5111:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030100_1_自宅自室"]+".jpg")
    show expression Solid("000000") as 絵色黒
    show expression ("cg/ef/"+imagename["efbg自宅自室天井昼消灯"]+".jpg") as 絵演 zorder 20 at truecenter
    $ sename = "se物体_アラーム_鳴る01"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve(0.0/1000)
    pause (1000/1000)
    hide 絵色黒
    with Dissolve(2000.0/1000)
    pause (500/1000)
    xy "*зевает*"
    xy "......"
    "Я такой сонный..."
    "Вчера ночью я не мог и глаз сомкнуть."
    xy "Я и не удивлён."
    play voc "a51/1100010b04"
    $ sename = "se人体_動作_抱きつく01"
    play se sedict[sename]
    hide 絵演
    with Dissolve(300.0/1000)
    "Иру посмотрел вверх и мяукнул мне от любопытства."
    xy "Нет, это не твоя вина."
    xy "Стоп, точно. Мы же должны позавтракать!"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg030300_1_自宅リビング"]+".jpg")
    pause (500/1000)
    hide 絵色黒
    with Dissolve(800.0/1000)
    xy "Давай пей, комок шерсти."
    play voc "a51/1100020b04"
    play voc "a51/1100030b04"
    "Схватив Иру одной рукой, я использовал свободную руку, чтобы наклонить шприц к нему."
    "А теперь..."
    "Что дальше?"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
