label e2032a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2005.nss"
    return
label e2032a:
    hide 絵色黒
    $ renpy.music.play("ttb02",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_ero")
    with Dissolve(0.0/1000)
    xy "\"Да, я остаюсь.\""
    "Я кивнул без колебаний."
    "Я рад жить здесь, с Миюки."
    "И я надеюсь, что мы сможем быть вместе очень, очень долго."
    "По правде говоря, мне больше никто не нужен."
    $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_hard")
    with Dissolve(200.0/1000)
    voice "voice/e20/32a00010a01.opus"
    mx "\"...Спасибо.\""
    xy "\"Миюки?!..\""
    "Я присмотрелся получше."
    "На глазах Миюки... наворачивались слёзы."
    xy "\"Что-то не так?\""
    voice "voice/e20/32a00020a01.opus"
    mx "\"Ничего. Я в порядке... просто...\""
    $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_cry")
    with Dissolve(200.0/1000)
    voice "voice/e20/32a00030a01.opus"
    mx "\"Я самая счастливая девушка на всём белом свете.\""
    "Вопреки её словам, она выглядела совсем не «в порядке». По её щекам скатывались большие слёзы."
    "...Я ещё никогда не видел её такой счастливой."
    xy "\"Миюки.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/e20/32a00040a01.opus"
    mx "\"Слушай, эм...\""
    voice "voice/e20/32a00050a01.opus"
    mx "\"Я хочу поцеловать ТЕБЯ... И это не просто поцелуй. А вечный поцелуй.\""
    hide StC with Dissolve(200.0/1000)
    "Я молча кивнул..."
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    "...и прижался к её губам своими губами."
    pause (2000/1000)
    with Dissolve(4000.0/1000)
    pause (2000/1000)
    $ persistent.eternal_day = True
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
