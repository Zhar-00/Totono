label c3166_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if remember_totono == True:
        $ GameName = "c3171.nss"
    else:
        $ GameName = "c4121.nss"
    return
label c3166:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    if PreGameName == "c3165":
        $ St("C",300, 0,0,"st曽根美雪_制服_腕組み_sad")
    elif PreGameName == "d3163":
        $ St("C",300, 0,0,"st曽根美雪_制服_腕組み_smile")
    elif PreGameName == "d3165":
        pass
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/c31/6600010a01.opus"

    mx "\"Увидимся завтра в школе.\""

    xy "\"Ладно. Увидимся завтра.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Я вошёл в свой дом."
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((500.0+1000.0)/1000)
    $ sename = "se物体_ドア自宅_閉まる"
    play se sedict[sename]
    pause (2000/1000)
    show expression ("cg/ef/"+imagename["efbg自宅自室天井消灯"]+".jpg") as 上背景 zorder 15 at truecenter
    show expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    hide 絵色黒
    with Dissolve(2000.0/1000)
    $ renpy.music.play("ttb12",channel = "bgm", if_changed = True)

    "Какой длинный день..."

    "В конце концов, я по-прежнему был без понятия, где сейчас Аой или чем она занимается."

    "По сути дела, у меня не было даже конкретных доказательств того, что она ушла из манга-кафе, чтобы спасти кота."

    "Я мог только спросить её завтра об этом, если увижу её в школе."

    "Я залез на кровать и медленно закрыл глаза—"
    stop bgm fadeout (2000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((1500.0+1000.0)/1000)
    stop bgm fadeout (4000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((3000.0+1000.0)/1000)
    $ EyeCatchIn(2000.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
