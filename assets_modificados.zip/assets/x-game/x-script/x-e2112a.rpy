label e2112a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2113.nss"
    return
label e2112a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg040100_1_街通学路"]+".jpg")
    with Dissolve(0.0/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Кажется, я понял, что она пыталась сказать."

    "И поэтому я подошёл к ней поближе."

    "Пока её левая рука неохотно висела между нами, я протянул к ней свою правую руку—"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
