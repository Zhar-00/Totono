label a3161_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010401_3_学校校門閉通用口開雨"]=True
    $ persistent.imagelog["bg020100_3_自宅外正面雨"]=True
    $ persistent.imagelog["bg040200_3_街川縁雨"]=True
    $ persistent.imagelog["bg900100_3_雰囲気空雨"]=True
    $ persistent.imagelog["efevエル初登場夜雨"]=True
    $ PreGameName = GameName
    if miyuki_plot == True:
        $ GameName = "c3162.nss"
    else:
        $ GameName = "a3162.nss"
    return
label a3161:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg") as 絵背景 zorder 1000 at truecenter
    show expression ("cg/ef/"+imagename["efbg自宅自室天井消灯"]+".jpg") as 絵背景弐 zorder 100 at center
    with Dissolve(1000.0/1000)
    pause (300/1000)
    $ sename = "se物体_照明_スイッチ"
    play se sedict[sename]
    hide 絵背景
    with Dissolve(150.0/1000)
    pause (700/1000)
    $ sename = "se人体_動作_衣擦れ04"
    play se sedict[sename]
    with Dissolve((500.0+1000.0)/1000)
    pause (300/1000)
    $ renpy.music.play("ttb06",channel = "bgm", if_changed = True)
    pause (500/1000)
    "Но потом я задумался..."
    "Что, если бы Аой была одна?"
    "Что, если бы нас не было рядом с ней?"
    "Что, если бы Миюки не была рядом, чтобы отчитать её?"
    stop bgm fadeout (15000.0/1000)
    $ sename = "se環境_自然_雨L"
    play rain ("se/"+sedict[sename]+".opus") fadein 1 loop
    $ renpy.music.set_volume(.2,channel="rain")
    "Очевидно, Аой приютила бы котёнка."
    "Она бы попыталась пронести котёнка в манга-кафе, но потерпела бы неудачу. А потом его менеджер выгнал бы её. А потом..."
    "Потом она провела бы всю ночь на улице."
    "Для меня это было ясным как день."
    "Аой не было бы к кому обратиться."
    "А котёнок бы замёрз до смерти на морозе."
    xy "Бог, ты там?.."
    "Для Аой, Бог существует. Только так она чувствовала поддержку в том, какой жизнью она решила жить."
    "И потом, этот Бог определённо может проявить благосклонность к тем людям, которые делают хорошие вещи."
    "Если у Бога и правда есть телефон..."
    "Если до Него можно достучаться всего одним телефонным звонком..."
    "Ответит ли Он на её молитвы?"
    "Он ждёт где-то там, за небесами?.."
    stop bgm fadeout (1000.0/1000)
    xy "Стоп... небо?.."
    $ sename = "se人体_動作_起き上がる01"
    play se sedict[sename]
    hide 絵背景弐
    with Dissolve(300.0/1000)
    pause (200/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    $ sename = "se物体_カーテン_引く"
    play se sedict[sename]
    with Dissolve((100.0+1000.0)/1000)
    show expression ("cg/bg/l/"+imagename["bg900100_3_雰囲気空雨_l"]+".jpg") as 絵背景 zorder 100 at truecenter
    $ sename = "se物体_窓_開ける"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(200.0/1000)
    $ renpy.music.set_volume(.5,channel = "rain", delay =.1)
    pause (500/1000)
    xy "О чёрт... дождь пошёл!"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    hide 絵背景
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面雨"]+".jpg")
    pause (500/1000)
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(1000.0/1000)
    $ sename = "se物体_ドア自宅_閉まる"
    play se sedict[sename]
    $ sename = "se人体_足音_駆け出す"
    play se sedict[sename]
    pause (200/1000)
    show expression ("cg/bg/"+imagename["bg040100_3_街通学路雨"]+".jpg")
    pause (200/1000)
    $ sename = "se人体_足音_走る雨01L"
    play se sedict[sename]
    with Dissolve(200.0/1000)
    "Осенью ночь стала довольно холодной."
    "Одной ничтожной картонной коробки не было достаточно, чтобы согреться."
    "Тот котёнок может замёрзнуть на улице, будучи беспомощным и озадаченным, зовя маму, которая никогда не вернётся..."
    show expression ("cg/bg/"+imagename["bg010401_3_学校校門閉通用口開雨"]+".jpg")
    with Dissolve(200.0/1000)
    "Даже я не настолько бессердечен, чтобы закрыть на это глаза."
    "И в те секунды, когда Аой об этом догадается, я просто знаю, что она прибежит прямо сюда."
    show expression ("cg/bg/"+imagename["bg040200_3_街川縁雨"]+".jpg")
    with Dissolve(200.0/1000)
    pause (500/1000)
    stop se fadeout (0.0/1000)
    "Я нашёл картонную коробку, промокшую насквозь от дождя."
    "Я открыл её и с опаской заглянул внутрь..."
    $ sename = "se人体_衝撃_取り上げる"
    play se sedict[sename]
    show expression ("cg/ef/"+imagename["efevエル初登場夜雨"]+".jpg") as 絵演効果 zorder 1000 at center
    with Dissolve((0.0+1000.0)/1000)
    pause (500/1000)
    "Котёнка там уже не было."
    "Вероятно, это означает, что кто-то другой пришёл и приютил бедное создание, но..."
    "Должен ли я заглянуть в манга-кафе, на всякий случай?.."
    $ sename = "se物体_携帯_着信音03"
    play se sedict[sename]
    pause (1000/1000)
    "И тут мои мысли прервал мой рингтон."
    hide 絵演効果
    with Dissolve(500.0/1000)
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    xy "Алло?"
    voice "voice/a31/6100010a01.opus"
    mx "Шиничи?! Я сейчас нахожусь в манга-кафе—"
    xy "Что? Ты серьёзно?!"
    "Ну конечно. Миюки, должно быть, тоже ищет Аой."
    "По правде говоря, это очень успокаивало."
    "Она, должно быть, пришла к тому же выводу, что и я."
    xy "А где Аой?"
    voice "voice/a31/6100020a01.opus"
    mx "Охранник сказал мне, что она выбежала наружу пару минут назад."
    voice "voice/a31/6100030a01.opus"
    mx "И перед тем, как уйти, она спрашивала, можно ли у них держать питомцев."
    xy "Я так и думал..."
    xy "Я стою у картонной коробки. Котёнка в ней нет."
    voice "voice/a31/6100040a01.opus"
    mx "Чёрт побери, Аой!"
    xy "Э-эй, да ладно тебе, не злись на неё из-за этого! Никто в здравом уме не станет бросать котёнка под дождь на верную гибель!"
    voice "voice/a31/6100050a01.opus"
    mx "Я знаю!"
    xy "Просто... перестань кричать, ладно? Сделай вдох."
    voice "voice/a31/6100060a01.opus"
    mx "Ты правда думаешь, что Аой в состоянии позаботиться о коте в одиночку?"
    "По правде говоря, Аой трудно было назвать ребёнком."
    "Она, наверное, могла бы позаботиться о себе и котёнке, учитывая то, что она—"
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵色回想黒 zorder 3900
    with Dissolve((0.0+300.0)/1000)
    show expression ("cg/ev/"+imagename["eva1171アオイ雨濡れa"]+".jpg") as 絵覆 zorder 2100 at truecenter
    with Dissolve(800.0/1000)
    pause (500/1000)
    xy "......"
    "А потом я вспомнил, как она рассеянно стояла перед школьными воротами без зонта и ждала Миюки под проливным дождём."
    hide 絵覆
    hide 絵色回想黒
    hide 絵画像
    hide 絵色黒
    with Dissolve(400.0/1000)
    voice "voice/a31/6100070a01.opus"
    mx "Мы должны найти её!"
    xy "Но где нам её искать?"
    voice "voice/a31/6100080a01.opus"
    mx "Не знаю. Есть идеи?"
    xy "Э-э-эм... может, в доме её родителей?"
    voice "voice/a31/6100090a01.opus"
    mx "Было бы здорово, если бы это было так."
    "Смысл этого был мне ясен, и я не мог это отрицать."
    "Куда же ещё Аой могла уйти?"
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵色回想黒 zorder 3900
    with Dissolve((0.0+300.0)/1000)
    show expression ("cg/ev/"+imagename["eva0113アオイ送信中d"]+".jpg") as 絵覆 zorder 2100 at truecenter
    with Dissolve(800.0/1000)
    pause (500/1000)
    "Первое, что пришло на ум – это верхняя часть школьной крыши над лестничной клеткой."
    "Но Аой сейчас вряд ли захочет находиться снаружи, особенно с котёнком в руках."
    hide 絵色回想黒
    hide 絵覆
    hide 絵画像
    hide 絵色黒
    with Dissolve(400.0/1000)
    "В таком случае, что нам ещё остаётся?"
    "Куда она ещё могла уйти?.."
    "…………"
    with Dissolve(500.0/1000)
    "...Это бесполезно."
    "Я не могу думать о чём-то другом."
    "Я даже не знаю, с чего начать..."
    "У меня нет и первой зацепки..."
    with Dissolve(500.0/1000)
    "У меня ничего нет..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
