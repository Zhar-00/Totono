label e1139_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010200_9_学校屋上"]=True
    $ persistent.imagelog["bg010210_9_学校屋上屋根向"]=True
    $ PreGameName = GameName
    $ GameName = "e1165.nss"
    return
label e1139:
    hide 絵色黒
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    show expression ("cg/ev/"+imagename["eve1158a美雪ラスボスb"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/bg/"+imagename["bg010210_9_学校屋上屋根向"]+".jpg")
    with Dissolve(0.0/1000)
    "Этот мир никоим образом не может быть видеоигрой."
    "В реальной жизни нет никаких патчей обновления."
    "Аой - персонаж в видеоигре."
    "Меня не держат в плену."
    "Миюки просто не может отличить фантазию от реальности, только и всего..."
    "Ничто из этого не может являться правдой..."
    "И всё же... и всё же—"
    voice "voice/e11/3900010a01.opus"
    mx "\"Давай войдём в игру.\""
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
