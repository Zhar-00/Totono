label e1141a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2000.nss"
    return
label e1141a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    scene expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    pause (200/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/41a00010a01.opus"

    mx "\"Тебе больше не надо совершать никаких выборов.\""
    voice "voice/e11/41a00020a01.opus"

    mx "\"Этот мир был модифицирован, и теперь...\""
    voice "voice/e11/41a00030a01.opus"

    mx "\"...тебе не нужно ни о чём беспокоиться.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e11/41a00040a01.opus"

    mx "\"Ты будешь счастлив со мной.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
