label c3182_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c3191.nss"
    $ meet_aoi = True
    return
label c3182:
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    hide 絵色黒
    show expression ("cg/bg/l/"+imagename["bg010402_3_学校校門閉_l"]+".jpg") as 絵背景 zorder 100:
        pos (-350,-380)
    show expression ("cg/bg/"+imagename["bg010402_3_学校校門閉"]+".jpg")
    with Dissolve(0.0/1000)

    "Я схватился руками за прутья школьных ворот."

    "Металл был мокрым от дождя и немного холодным, чем я того ожидал."
    $ sename = "se物体_校門_揺れる01"
    play se sedict[sename]
    pause (300/1000)

    "Громкий скрежет донёсся эхом до корпуса, освещаемого луной."

    "Но мне было всё равно."

    "Я подтянулся и перепрыгнул через них одним плавным движением."
    stop se fadeout (1000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010500_3_学校昇降口"]+".jpg")
    pause (1500/1000)
    hide 絵背景
    hide 絵色黒
    with Dissolve(800.0/1000)
    pause (300/1000)

    "И вот я здесь, один на школьной площади посреди ночи."

    "По правде говоря, здесь было немного жутковато."

    "В любой другой ситуации я бы, наверное, развернулся и побежал домой, поджав хвост."

    "Но всё же, как ни странно, у меня было хорошее настроение."
    $ sename = "se物体_靴箱_開ける"
    play se sedict[sename]
    $ sename = "se物体_ドア室内_開く03"
    play se sedict[sename]

    "Ночью, внутри моего шкафчика для обуви, простирался бесконечный туннель темноты."
    $ sename = "se物体_靴箱_取り出す"
    play se sedict[sename]

    "Как только я переобулся в свою сменную обувь, небольшой скрежет моей подошвы об линолеум раздался эхом, словно выстрел из оружия."

    "Было невероятным то, как разница в несколько часов превратила знакомое место в абсолютно иной мир..."

    "Аой была где-то здесь и скрывалась в темноте."

    "Я почему-то был уверен в этом."

    "Я прокрался по коридору, стараясь не издавать шума."
    show expression ("cg/bg/"+imagename["bg010700_3_学校廊下"]+".jpg")
    with Dissolve(800.0/1000)
    pause (300/1000)

    xy "\"Бинго...\""

    "На полу были капли дождевой воды."

    "И эти капли образовывали след..."
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵演色黒
    with Dissolve(800.0/1000)
    pause (1500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
