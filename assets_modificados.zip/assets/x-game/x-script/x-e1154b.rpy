label e1154b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1154d.nss"
    return
label e1154b:
    hide 絵色黒
    $ renpy.music.play("ttb22",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110500_1_マンショントイレ"]+".jpg")
    with Dissolve(0.0/1000)

    "Я решил проверить её список контактов."

    "Но я смог попасть только на экран блокировки."

    "У неё ещё и разблокировка по отпечатку пальца стояла."

    "Я решил проверить это своим указательным пальцем, но, естественно, мой палец был отклонён."

    "Я заметил, что здесь также есть вариант «Разблокировка по секретным вопросам»..."

    "Может, стоит сымпровизировать?"
    $ renpy.vibrate(.3)
    $ sename = "se人体_衝撃_叩く机02"
    play se sedict[sename]

    xy "\"Воу!!!\""

    "Ч-что это, чёрт побери, было?!"

    "Дверь в уборную просто—!"
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_壊れる01"
    play se sedict[sename]
    pause (100/1000)
    $ sename = "se物体_ドアトイレ_壊れる01"
    play se sedict[sename]
    pause (1000/1000)
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_壊れる01"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_壊れる03"
    play se sedict[sename]
    show expression ("cg/ef/"+imagename["efbgマンショントイレ破壊a"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵板写

    xy "\"Да вы издеваетесь...\""
    voice "voice/e11/54b00010a01.opus"

    mx "\"Я не отпущу тебя!!!..\""
    $ sename = "se物体_ドアトイレ_軋む03"
    play se sedict[sename]
    $ renpy.vibrate(.3)

    "Дверь в уборную громко заскрипела."

    "Миюки засунула монтировку внутрь!"
    show expression ("cg/ef/"+imagename["efbgマンショントイレ破壊b"]+".jpg") as 絵背景 zorder 100 at truecenter
    with Dissolve(500.0/1000)
    pause (800/1000)
    stop se fadeout (150.0/1000)
    $ sename = "se物体_ドアトイレ_壊れる02"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_軋む03"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    pause (16/1000)
    show expression ("cg/ef/"+imagename["efbgマンショントイレ破壊c"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵板写
    pause (800/1000)
    $ sename = "se物体_ドアトイレ_壊れる02"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_軋む03"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    pause (16/1000)
    show expression ("cg/ef/"+imagename["efbgマンショントイレ破壊d"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵板写

    "И на моих глазах она начала вскрывать дверь—"
    $ sename = "se物体_ドアトイレ_壊れる02"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_軋む02"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    pause (16/1000)
    show expression ("cg/ef/"+imagename["efbgマンショントイレ破壊e"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵板写
    voice "voice/e11/54b00020a01.opus"

    mx "\"Ты думаешь, что сможешь позвонить Богу? ТОЛЬКО ЧЕРЕЗ МОЙ ТРУП!!!\""
    stop se fadeout (150.0/1000)
    $ sename = "se物体_ドアトイレ_壊れる02"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_軋む03"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    show expression Solid("FFFFFF") as 絵色白
    show expression ("cg/ev/"+imagename["eve1154b美雪血涙"]+".jpg") as 絵専 zorder 1100 at truecenter
    hide 絵背景
    pause (30/1000)
    hide 絵板写
    hide 絵色白
    with Dissolve(2000.0/1000)
    stop se fadeout (1000.0/1000)
    pause (800/1000)
    voice "voice/e11/54b00030a01.opus"
    mx "\"Шиничи...\""
    $ sename = "se物体_バール_転がる"
    play se sedict[sename]

    xy "\"У-успокойся, Миюки!\""
    voice "voice/e11/54b00040a01.opus"

    mx "\"Ха-ха... ха-ха... ха-ха-ха-ха-ха-ха-ха-ха-ха-ха!!!..\""
    voice "voice/e11/54b00050a01.opus"

    mx "\"Успокоиться? И как я, по-твоему, должна успокоиться?\""

    "Она сорвала дверь с её же петель!.."

    "Она поменяла монтировку на биту, а потом встала в дверном проёме."

    "Я в ловушке..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
