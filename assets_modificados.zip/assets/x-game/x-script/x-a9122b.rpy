label a9122b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if persistent.a_route == True:
        $ GameName = "b1121.nss"
        $ GameContiune = 1
        return
    else:
        $ GameCircle=False
    return
label a9122b:
    hide 絵色黒
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    show expression ("cg/ef/"+imagename["efbg空汎用西日"]+".jpg") as 絵専 zorder 15 at truecenter
    with Dissolve(0.0/1000)

    xy "\"Именно то, что я и заслужил, не правда ли?\""

    "Пробормотал я небу."

    "Нет нужды говорить о том, что мне никто так и не ответил."
    stop bgm fadeout (4000.0/1000)
    show expression Solid("000000") as 絵演色黒
    with Dissolve(500.0/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
