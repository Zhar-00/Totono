label d4171_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d4181.nss"
    return
label d4171:
    hide 絵色黒
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010600_1_学校教室_l"]+".jpg") as 絵背景 zorder 15:
        pos (-550,-290)
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵色回想黒 zorder 3900
    show expression ("cg/ef/"+imagename["efevエル初登場"]+".jpg") as 絵覆過去絵 zorder 525 at truecenter
    with Dissolve(500.0/1000)
    "Воспоминания о том роковом дне всплыли у меня в голове."
    hide 絵覆過去絵
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵覆外絵色回想黒 zorder 3900
    with Dissolve((0.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg040200_3_街川縁"]+".jpg") as 絵演過去背景 zorder 535 at truecenter
    $ st_timezone = "夜"
    $ St("C",800,0,0,"st曽根美雪_制服_通常_shout")
    with Dissolve(500.0/1000)
    "Если бы Миюки тогда не грозилась разорвать свои связи с Аой, то, наверное, мы были бы друзьями даже сегодня."
    "Но теперь всё кончено."
    hide 絵色回想黒
    hide 絵演過去背景
    show expression Solid("000000") as 絵色黒下敷
    $ st_timezone = "昼"
    $ St("C",800,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(500.0/1000)
    "Аой исчезла без протестов."
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((1000.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    pause (500/1000)
    "И теперь нашей дружбе пришёл конец."
    hide StC
    hide StMR
    hide StML
    hide 絵覆外絵色回想黒
    hide 絵演過去背景
    hide 絵色回想黒
    hide 絵色黒下敷
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    hide 絵色黒
    with Dissolve(1500.0/1000)
    xy "\"Всё уже в прошлом.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/d41/7100010b01.opus"
    xtl "\"Шиничи!!!\""
    "Ютаро кричал мне в лицо."
    "Но его крики прошли мимо меня."
    "В моём мире не было никакого Бога."
    "И не было никакого священного сигнала."
    "Мой единственный выбор - привыкать к своей новой жизни без неё."
    "Мой единственный выбор... продолжать жить."
    xy "\"Она исчезла по своей воле.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/d41/7100020b01.opus"
    xtl "\"Ты просто используешь это как оправдание.\""
    xy "\"Я знаю об этом, ладно? Я знаю об этом!\""
    "Я постоянно искал какое-либо оправдание, чтобы ничего не делать."
    "Таким образом я избегал повода чувствовать себя жалким."
    "Таким образом я избегал различных травм."
    "Просто я такой парень."
    "Так что я просто должен привыкнуть к этому."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/d41/7100030b01.opus"
    xtl "\"—!!!\""
    $ sename = "se人体_動作_解放する"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    hide 絵背景
    with Dissolve(500.0/1000)
    "Ютаро убрал от меня свои руки так, будто я был мусором."
    "Я опешил и опёрся на парту позади себя."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/d41/7100040b01.opus"
    xtl "\"Спроси себя, чему Муко научила тебя!\""
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((500.0+1000.0)/1000)
    hide StC with Dissolve(0.0/1000)
    "Он сунул мне своё письмо об изгнании."
    stop se fadeout (1000.0/1000)
    stop bgm fadeout (3000.0/1000)
    pause (500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
