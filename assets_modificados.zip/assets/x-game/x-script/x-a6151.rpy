label a6151_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a6161.nss"
    return
label a6151:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg") as 絵背景 zorder 100 at truecenter
    show expression Solid("000000") as 絵色黒
    hide 上背景
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (300/1000)
    $ sename = "se物体_照明_スイッチ"
    play se sedict[sename]
    hide 絵背景
    with Dissolve(150.0/1000)
    pause (500/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    $ sename = "se物体_布団_潜り込む"
    play se sedict[sename]
    with Dissolve((300.0+1000.0)/1000)
    "Я залез под одеяло и закрыл глаза."
    show expression im.AlphaMask("cg/bg/white.jpg","cg/data/circle_02_01_0.png") as 絵色白
    show expression ("cg/bg/l/"+imagename["bg010802_2_学校体育館演劇中_l"]+".jpg") as 絵背景 zorder 100:
        xpos -250
        ycenter .5
        linear 30 xpos -500
    pause (1000/1000)
    show expression Solid("000000") as 絵色黒
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (500/1000)
    $ sename = "se環境_ガヤ_拍手L"
    play se sedict[sename]
    hide 絵色白
    with Dissolve(3000.0/1000)
    pause (1000/1000)
    "В моих снах была премьера."
    "Миюки целовала своего любовника под бурные аплодисменты."
    show expression ("cg/bg/"+imagename["bg010802_2_学校体育館演劇中"]+".jpg")
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((12000.0+800.0)/1000)
    hide 絵背景
    with Dissolve(500.0/1000)
    "Она целовала кого-то другого, не меня."
    "Меня не было в зале."
    "Меня нигде нельзя было найти."
    stop se fadeout (300.0/1000)
    with Dissolve((300.0+1000.0)/1000)
    "...Хотел бы я просто исчезнуть."
    pause (1000/1000)
    $ EyeCatchIn(0.0)
    show expression Solid("000000") as 絵色黒 zorder 10010
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
