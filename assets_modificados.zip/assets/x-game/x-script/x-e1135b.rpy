label e1135b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1135c.nss"
    return
label e1135b:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010210_2_学校屋上屋根向"]+".jpg")
    show expression ("cg/ev/l/"+imagename["eve1158a美雪ラスボス_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    voice "voice/e11/35b00010a01.opus"

    mx "\"А, точно... Я забыла, что ТЫ не читал мой дневник...\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
