label e2324a_MAIN:
    call expression GameName
    $ persistent.imagelog["efbg美雪の手美雪のガラケーb"]=True
    $ PreGameName = GameName
    $ GameName = "e2324c.nss"
    return
label e2324a:
    hide 絵色黒
    $ renpy.music.play("bgm/ttb27.opus",channel = "music", if_changed = True)
    $ renpy.music.play("ttb27_ef",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    show expression ("cg/ef/"+imagename["efbg美雪の手美雪のガラケーa"]+".jpg") as 絵演背景 zorder 1100 at truecenter
    show expression ("cg/ef/"+imagename["efbg美雪の手美雪のガラケーb"]+".jpg") as 絵演背景上 zorder 1105 at center
    voice "voice/e23/24a00010a01.opus"

    mx "\"Хе-хе...\""

    "Выходит, я сейчас позвонил не Богу."
    voice "voice/e23/24a00020a01.opus"

    mx "\"Хе-хе-хе-хе-хе...\""
    voice "voice/e23/24a00030a01.opus"

    mx "\"Ха-ха... А-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА!..\""
    hide 絵動作
    with Dissolve(600.0/1000)
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_happy")
    with Dissolve(400.0/1000)

    "Я позвонил Миюки."

    "Она держала второй телефон - обычную раскладушку - и стояла с ухмылкой до ушей."

    "И телефон продолжал звонить."
    if (persistent.unlock_challenge == 1):
        $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00040a01.opus"

        mx "\"С первой попытки.\""
        xy "\"А?..\""
        voice "voice/e23/24a00050a01.opus"

        mx "\"ТЫ всё правильно угадал с первой попытки!\""
        $ St("C",300,0,0,"fu曽根美雪_私服_恋人_happy")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00060a01.opus"

        mx "\"Я чувствую ТВОЮ любовь ко мне по ту сторону экрана...\""
    elif (persistent.unlock_challenge == 2):
        $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00070a01.opus"

        mx "\"Со второй попытки.\""
        xy "\"А?..\""
        voice "voice/e23/24a00080a01.opus"

        mx "\"ТЫ всё правильно угадал только со второй попытки!\" "
        $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00090a01.opus"

        mx "\"Должно быть, ТЫ очень переживаешь за меня.\""
    elif (persistent.unlock_challenge == 3):
        $ St("C",300,0,0,"fu曽根美雪_私服_通常_normal")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00100a01.opus"

        mx "\"С третьей попытки.\""
        xy "\"А?..\""
        voice "voice/e23/24a00110a01.opus"

        mx "\"ТЫ всё правильно угадал только с третьей попытки!\""
        $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00120a01.opus"

        mx "\"Третий раз - удачный, наверное?\""
    elif (persistent.unlock_challenge==4):
        $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_normal")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00130a01.opus"

        mx "\"С четвёртой попытки.\""
        xy "\"А?..\""
        voice "voice/e23/24a00140a01.opus"

        mx "\"ТЫ всё правильно угадал только с четвёртой попытки.\""
        $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_smile")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00150a01.opus"

        mx "\"Поговаривают, четыре - несчастливое число, знаешь ли.\""
    elif (persistent.unlock_challenge==5):
        $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_normal")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00160a01.opus"

        mx "\"С пятой попытки.\""
        xy "\"А?..\""
        voice "voice/e23/24a00170a01.opus"

        mx "\"ТЫ всё правильно угадал только с пятой попытки.\""
        $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_sad")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00180a01.opus"

        mx "\"А я уже начала волноваться, что ТЫ никогда не догадаешься!\""
    elif (persistent.unlock_challenge==6):
        $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_normal")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00190a01.opus"

        mx "\"С шестой попытки.\""
        xy "\"А?..\""
        voice "voice/e23/24a00200a01.opus"

        mx "\"У ТЕБЯ на это ушло шесть попыток, но ТЫ наконец-то всё правильно угадал.\""
        $ St("C",300,0,0,"fu曽根美雪_私服_通常_pride")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00210a01.opus"

        mx "\"Боже! Долго же ТЫ возился!\""
    elif (persistent.unlock_challenge==7):
        $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_normal")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00220a01.opus"

        mx "\"С седьмой попытки.\""
        xy "\"А?..\""
        voice "voice/e23/24a00230a01.opus"

        mx "\"У ТЕБЯ на это ушло целых семь попыток, но ТЫ каким-то образом ещё смог догадаться обо всём.\""
        $ St("C",300,0,0,"fu曽根美雪_私服_病み_normal")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00240a01.opus"

        mx "\"Семь - счастливое число, наверное?\""
    elif (persistent.unlock_challenge==8):
        $ St("C",300,0,0,"fu曽根美雪_私服_病み_sad")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00250a01.opus"

        mx "\"С восьмой попытки.\""
        xy "\"А?..\""
        $ St("C",300,0,0,"fu曽根美雪_私服_通常_pride")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00260a01.opus"

        mx "\"Серьёзно... у ТЕБЯ ушло целых восемь попыток, чтобы догадаться об этом?\""
        voice "voice/e23/24a00270a01.opus"

        mx "\"Боже, ТЫ такой тупой!\""
    elif (persistent.unlock_challenge==9):
        $ St("C",300,0,0,"fu曽根美雪_私服_通常_sigh")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00280a01.opus"

        mx "\"С девятой попытки.\""
        xy "\"А?..\""
        $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_normal")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00290a01.opus"

        mx "\"У ТЕБЯ ушло на это девять попыток, но ТЫ наконец-то всё правильно угадал.\""
        voice "voice/e23/24a00300a01.opus"

        mx "\"ТЕБЕ и правда пришлось попотеть, да?\""
    elif (persistent.unlock_challenge > 9):
        $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_fear")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00310a01.opus"

        mx "\"Двухзначное число, а?\""
        xy "\"А?..\""
        $ St("C",300,0,0,"fu曽根美雪_私服_病み_sad")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00320a01.opus"

        mx "\"У ТЕБЯ ушло на это более девяти попыток, но ТЫ наконец-то добился успеха.\""
        $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
        with Dissolve(200.0/1000)
        voice "voice/e23/24a00330a01.opus"

        mx "\"Но, знаешь... я правда тронута тем, что ТЫ приложил все усилия, чтобы узнать обо мне побольше.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_病み_smile")
    with Dissolve(400.0/1000)

    "Выражение её лица было таким ярким и жизнерадостным, и это... по правде говоря, выглядело жутковато."
    voice "voice/e23/24a00340a01.opus"

    mx "\"ТЫ ведь понимаешь, что никакое прохождение в интернете ТЕБЕ не поможет, верно?\""
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e23/24a00350a01.opus"

    mx "\"Всё просто. ТЫ знаешь про те вопросы с несколькими вариантами ответа?\""
    voice "voice/e23/24a00360a01.opus"

    mx "\"Все ответы были полностью рандомизированы.\""
    voice "voice/e23/24a00370a01.opus"

    mx "\"Три возможных варианта ответа на каждый из тридцати разных вопросов.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e23/24a00380a01.opus"

    mx "\"Моя личность - это одна из двухсот пяти триллионов, восьмисот девяносто одного миллиарда, ста тридцати двух миллионов, девяносто четырёх тысяч и шестисот сорока девяти возможных вариаций...\""
    voice "voice/e23/24a00390a01.opus"

    mx "\"И она была сгенерирована для ТЕБЯ одного.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/e23/24a00400a01.opus"

    mx "\"И ТЫ сделал всё возможное, чтобы узнать всё обо мне.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e23/24a00410a01.opus"

    mx "\"Спасибо.\""

    "Что? Почему она меня благодарит?"
    $ St("C",300,0,0,"fu曽根美雪_私服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e23/24a00420a01.opus"

    mx "\"Я притворилась спящей, и ТЫ купился на это...\""
    voice "voice/e23/24a00430a01.opus"

    mx "\"Но ТЫ изо всех сил старался понять меня...\""
    $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e23/24a00440a01.opus"

    mx "\"Если честно, я самая счастливая девушка на свете.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e23/24a00450a01.opus"

    mx "\"И поэтому я расскажу тебе правду.\""

    "Правду?.."
    pause (16/1000)
    stop bgm fadeout (0.0/1000)
    stop music
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
