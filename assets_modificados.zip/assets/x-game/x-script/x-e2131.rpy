label e2131_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2131:
    hide 絵色黒
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 100 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(300.0/1000))
    scene expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ roof = True;

    xy "\"Ням, ням, ням... м-м-м...\""
    voice "voice/e21/3100010a01.opus"

    mx "\"...Ну как?\""

    xy "\"Прекрасно.\""

    "Как обычно, у меня не было претензий к обеду, который она приготовила."

    "Одного его вкуса было достаточно, чтобы заставить меня улыбаться..."
    if persistent.miyuki[22] == 0:

        xy "\"Боже, твоя жареная свинина - просто объедение.\""
    elif persistent.miyuki[22] == 1:

        xy "\"Боже, твои шаомайские пельмени - просто объедение.\""
    elif persistent.miyuki[22] == 2:

        xy "\"Боже, твой рис такикоми - просто объедение.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100020a01.opus"

    mx "\"Ну, всё-таки это МОИ фирменные блюда.\""

    xy "\"Поверить не могу, что моя любимая еда вдруг оказалась твоими фирменными блюдами... Наверное, это судьба или ещё что.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100030a01.opus"

    mx "\"Нет, я довела её до совершенства, ПОТОМУ ЧТО это твоё любимое блюдо.\""

    xy "\"Правда?..\""
    voice "voice/e21/3100040a01.opus"

    mx "\"Правда-правда. Я хозяйка своей судьбы.\""

    "Боже... похоже, Миюки может сделать всё, что захочет..."

    xy "\"Но всё же, я впечатлён, что ты знала о том, что это моё любимое блюдо.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100050a01.opus"

    mx "\"Спустя все те годы, что мы знаем друг друга? Разумеется, я рано или поздно узнала бы об этом!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100060a01.opus"

    mx "\"Стоп... Ты хочешь сказать, что не знаешь, какое моё любимое блюдо?\""

    xy "\"Р-разумеется, знаю! Безусловно!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100070a01.opus"

    mx "\"Ну ладно, давай послушаем. Какая моя любимая еда?\""

    xy "\"Твоя любимая еда... ну...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100080a01.opus"

    mx "\"Да?..\""

    xy "\"...Сладости!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100090a01.opus"

    mx "\"...Ты должен говорить конкретнее!\""

    xy "\"Прости...\""

    xy "\"А КАКОЙ у тебя любимый десерт, кстати?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100100a01.opus"

    mx "\"Хм... Посмотрим...\""
    if persistent.miyuki[4] == 0:
        voice "voice/e21/3100110a01.opus"

        mx "\"Пирожные, наверное?\""
    elif persistent.miyuki[4] == 1:
        voice "voice/e21/3100120a01.opus"

        mx "\"Сахарные яблоки! Обожаю их.\""
    elif persistent.miyuki[4] == 2:
        voice "voice/e21/3100130a01.opus"

        mx "\"Ну, я всегда мечтала съесть целое ведро пудинга...\""

    xy "\"Какой же детский ответ.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100140a01.opus"

    mx "\"Не лезь не в своё дело.\""

    xy "\"Ну ладно, а какую еду ты ненавидишь?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100150a01.opus"

    mx "\"Ну, я не РЕБЁНОК. Я могу съесть практически всё.\""

    xy "\"Разумеется, ты МОЖЕШЬ это съесть, но наверняка есть хотя бы одна вещь, которую ты не захочешь есть, если можешь её избежать.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100160a01.opus"

    mx "\"Ну...\""

    "Миюки задумалась на какое-то время, а потом посмотрела на меня."
    if persistent.miyuki[5] == 0:
        $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
        with Dissolve(200.0/1000)
        voice "voice/e21/3100170a01.opus"

        mx "\"Тушёное свиное брюхо. Оно слишком жирное.\""
    elif persistent.miyuki[5] == 1:
        $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
        with Dissolve(200.0/1000)
        voice "voice/e21/3100180a01.opus"

        mx "\"Лососёвая икра. Текстура у неё просто отвратительная.\""
    elif persistent.miyuki[5] == 2:
        $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
        with Dissolve(200.0/1000)
        voice "voice/e21/3100190a01.opus"

        mx "\"Грейпфрут. Я просто терпеть не могу его вкус.\""

    xy "\"А, понятно.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100200a01.opus"

    mx "\"...Чего ты ухмыляешься?!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/3100210a01.opus"

    mx "\"У тебя тоже есть нелюбимая еда, знаешь ли! К примеру, вот ЭТО!\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (200/1000)
    $ sename = "se物体_缶_置く"
    play se sedict[sename]

    xy "\"Гха!..\""
    show expression ("cg/ef/"+imagename["efbgヤバトマ"]+".jpg") as 絵演効果 zorder 100 at center
    with Dissolve((0.0+1000.0)/1000)
    pause (500/1000)

    "Она поставила передо мной банку с томатным соком Ябалея."
    voice "voice/e21/3100220a01.opus"

    mx "\"Что бы ты предпочёл выпить, это или чай?\""
    if persistent.eternal_day or persistent.eternal_day:
        $ GameName = "e2132c.nss";
    else:
        menu:
            "Томатный сок Ябалея":
                $ SetChoiceSelect = 0
            "Чай":
                $ SetChoiceSelect = 1
        if SetChoiceSelect==0:
            $ persistent.miyuki_love -= 1
            $ GameName = "e2132a.nss";
        elif SetChoiceSelect==1:
            $ persistent.miyuki_love += 1
            $ GameName = "e2132b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
