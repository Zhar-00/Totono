label e2318a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1111.nss"
    return
label e2318a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)

    "Тем не менее, когда Миюки потеряла сознание, мне особо нечего было делать."

    "После хорошего сна, я уверен, завтра она будет в полном порядке."
    $ sename = "se物体_布団_潜り込む"
    play se sedict[sename]

    "Хотя вся ночь была ещё впереди, я решил прилечь рядом с ней на диване."
    pause (16/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
