label e2122c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2123.nss"
    return
label e2122c:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/22c00010a01.opus"

    mx "\"Мне это никогда не надоест.\""

    xy "\"А, да?\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
