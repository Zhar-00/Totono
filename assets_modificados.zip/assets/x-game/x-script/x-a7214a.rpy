label a7214a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if bukkake == True:
        $ GameName = "a7215b.nss"
    else:
        $ GameName = "a7215a.nss"
        $ persistent.ejaculation += 1
    return
label a7214a:
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/bg/l/"+imagename["bg030300_3_自宅リビング_l"]+".jpg") as 絵背景 zorder 15:
        pos (620,-410)
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失f"]+".jpg") as 絵専 zorder 1110 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失c"]+".jpg") as 絵捏造窓絵専上 zorder 1110 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失f"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    voice "voice/a72/14a00010a01.opus"

    mx "\"Я так ужасно выгляжу... А-А-АХ! О боже! Я чувствую себя такой опустошённой!..\""
    voice "voice/a72/14a00020a01.opus"

    mx "\"А-а-а-ах... а-ах... Ох... господи... я так счастлива... до мозга костей...\""
    voice "voice/a72/14a00030a01.opus"

    mx "\"Ты заполняешь меня полностью, Шиничи... Я так влюблена, я... я не могу...\""
    voice "voice/a72/14a00040a01.opus"

    mx "\"Ахах... Я... опять кончаю?.. А ты? Ты уже на пределе?\""
    voice "voice/a72/14a00050a01.opus"

    mx "\"Давай— Я приму её всё! Просто... просто отдай её мне! Ха-а! А-ах!\""
    voice "voice/a72/14a00060a01.opus"

    mx "\"А-а-ах! Меня так заполняет твой член— Н-нг-гх-х! Я скоро кончу... Кончай со мной... Я кончаю... Я кончаю—!\""
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失b"]+".jpg") as 絵捏造窓絵専上 zorder 1110 at truecenter
    with Dissolve(300.0/1000)
    voice "voice/a72/14a00070a01.opus"

    mx "\"Н-нха-ах! Ха-а-а! А-ах! А-ах! А-а-а-а-а-а-ах— А-а-а-а-а-а-а-а-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-АХ!!!\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
