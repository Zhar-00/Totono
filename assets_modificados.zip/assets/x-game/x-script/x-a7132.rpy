label a7132_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a7133.nss"
    return
label a7132:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    with Dissolve(500.0/1000)
    $ sename = "se物体_紙_取り出す"
    play se sedict[sename]
    pause (300/1000)

    xy "\"Это форма заявления об уходе из клуба?..\""

    xy "\"...Видимо, нет...\""
    $ sename = "se物体_紙_手紙開く"
    play se sedict[sename]
    pause (300/1000)

    "Слова \"Заявление об уходе из клуба\" были зачёркнуты."

    "Вместо них, над зачёркнутыми словами витиеватым каллиграфическим почерком было написано следующее: \"ПИСЬМО ОБ ИЗГНАНИИ\"."

    "И, разумеется, письмо было подписано \"Ютаро Акебоно\"."

    "Почему он так старался сделать его красивым?.."

    "А потом я увидел содержание самого письма."
    "—УМРИ!!!"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
