label a2182_MAIN:
    call expression GameName
    $ persistent.imagelog["efbg猫ヘアピンペア"]=True
    $ PreGameName = GameName
    $ GameName = "a2183.nss"
    python:
        if persistent.passed_a2182_month == None or persistent.passed_a2182_day == None:
            from time import strftime, localtime
            persistent.passed_a2182_month = int(strftime("%m",localtime()))
            persistent.passed_a2182_day = int(strftime("%d",localtime()))
            persistent.DIARY_COUNT += 1
    return
label a2182:
    hide 絵色黒
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg070100_2_雑貨店店内"]+".jpg")
    show expression ("cg/ef/"+imagename["efbg猫ヘアピンペア"]+".jpg") as 絵背景 zorder 100 at center
    pause (500/1000)
    "Судя по всему, это была единственная в своём роде вещь ручной работы. Рядом с ней лежала вторая, немного другая заколка, выполненная в том же стиле."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
