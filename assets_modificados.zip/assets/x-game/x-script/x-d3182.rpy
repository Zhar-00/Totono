label d3182_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4121.nss"
    return
label d3182:
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    hide 絵色黒
    show expression ("cg/bg/l/"+imagename["bg010402_3_学校校門閉_l"]+".jpg") as 絵背景 zorder 100:
        pos (-350,-380)
    show expression ("cg/bg/"+imagename["bg010402_3_学校校門閉"]+".jpg")
    with Dissolve(0.0/1000)

    xy "\"...О чём я, чёрт побери, думаю?\""
    hide 絵背景
    with Dissolve(300.0/1000)

    "Я наконец-то пришёл в чувства."

    "Я всерьёз размышлял о том, чтобы проникнуть на территорию школы ночью и пойти искать там Аой лишь потому, что видеоигра сама намекнула мне на это?"

    "Боже, какой же я тупой."

    "Каким образом Аой вообще проникла бы в школьный корпус с котёнком на руках?"

    xy "\"...Этого не может быть.\""

    "Я развернулся и пошёл домой."
    stop bgm fadeout (3000.0/1000)
    $ EyeCatchIn(2000.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
