label d7123_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d7131.nss"
    return
label d7123:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    $ sename = "se人体_足音_階段自宅上がる01"
    play se sedict[sename]
    pause (300/1000)
    scene expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    with Dissolve(500.0/1000)
    pause (300/1000)
    $ sename = "se物体_照明_スイッチ"
    play se sedict[sename]
    pause (300/1000)
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    with Dissolve(150.0/1000)
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]
    pause (1000/1000)
    "Я временно запер Иру на втором этаже, чтобы у Миюки не было приступа аллергии."
    "Я осторожно взял его."
    xy "\"Здесь мы и попрощаемся.\""
    "На удивление, Иру не издал ни звука."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    pause (500/1000)
    scene expression ("cg/bg/"+imagename["bg030200_3_自宅玄関"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    hide 絵色黒
    with Dissolve(800.0/1000)
    pause (500/1000)
    xy "\"Аой.\""
    xy "\"Ты присмотришь за ним, верно?\""
    voice "voice/d71/2300010a02.opus"
    aoi "\"Да.\""
    "Аой кивнула так, будто была готова к этому."
    "Я положил Иру."
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]
    pause (300/1000)
    "«Кот-передатчик» посмотрел на меня в последний раз."
    "Я отвёл свой взгляд."
    hide StC with Dissolve(200.0/1000)
    pause (500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
