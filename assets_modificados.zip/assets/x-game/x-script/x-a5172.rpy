label a5172_MAIN:
    call expression GameName
    $ persistent.imagelog["efbg美雪の手アオイのスマフォ"]=True
    $ PreGameName = GameName
    $ GameName = "a5173.nss"
    return
label a5172:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(0.0/1000)
    voice "voice/a51/7200010a01.opus"
    mx "Тогда, полагаю, нам это не понадобится."
    pause (200/1000)
    show expression ("cg/ef/"+imagename["efbg美雪の手アオイのスマフォ"]+".jpg") as 絵演効果 zorder 1000 at center
    with Dissolve((300.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    pause (700/1000)
    xy "Это телефон Аой?!"
    voice "voice/a51/7200020a02.opus"
    aoi "А?!"
    "Аой громко ахнула под моей кроватью."
    "Мой желудок превратился в лёд."
    "Но Миюки пошла дальше."
    show expression ("cg/bg/m/"+imagename["bg030100_3_自宅自室_m"]+".jpg") as 絵背景 zorder 100 at truecenter
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    hide 絵演効果
    with Dissolve(500.0/1000)
    pause (500/1000)
    voice "voice/a51/7200030a01.opus"
    mx "У меня было такое чувство, будто это её телефон."
    xy "Где ты его нашла?"
    voice "voice/a51/7200040a01.opus"
    mx "Он лежал прямо за бейсбольным полем."
    voice "voice/a51/7200050a01.opus"
    mx "Я пришла сюда, чтобы вернуть его, но... если её здесь нет, то, думаю, я пойду домой—"
    voice "voice/a51/7200060a02.opus"
    aoi "Не надо!"
    xy "Я подержу его для неё!"
    "Я повысил свой голос, чтобы заглушить шёпот Аой."
    xy "Она, скорее всего, рано или поздно придёт за своей обувью!"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a51/7200070a01.opus"
    mx "Хм-м-м... думаю, в этом есть смысл."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/a51/7200080a01.opus"
    mx "Держи."
    hide StC with Dissolve(200.0/1000)
    xy "Спасибо—"
    hide 絵背景
    $ sename = "se物体_携帯_落ちる01"
    play se sedict[sename]
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a51/7200090a01.opus"
    mx "Ёлки-иголки! Какая я глупая, я уронила его!"
    "Телефон упал на пол и ускользнул прямо под кровать."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a51/7200100a01.opus"
    mx "Мне вот интересно, ты там внизу лежишь?"
    pause (200/1000)
    $ sename = "se人体_動作_衣擦れ01"
    play se sedict[sename]
    hide StC with Dissolve(500.0/1000)
    with Dissolve(800.0/1000)
    pause (500/1000)
    "Миюки медленно опустилась на пол."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
