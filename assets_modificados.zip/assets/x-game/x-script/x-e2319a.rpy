label e2319a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2319a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)

    "Как только я решил открыть её список контактов—"

    "Экран изменился."

    "Разблокировка по отпечатку."

    "Я заметил, что здесь был также и вариант «Разблокировка по секретным вопросам», но я не настолько отчаянно хотел сунуть туда свой нос..."
    menu:
        "Разблокировать через секретные вопросы":
            $ SetChoiceSelect = 0
        "Пойти спать":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e2320a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e2320b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
