label e1111a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1111a:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    pause (16/1000)
    pause (16/1000)
    with Dissolve(0.0/1000)
    hide 絵色黒
    with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    pause (16/1000)
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    pause (1000/1000)
    if persistent.miyuki_love > 12:
        $ persistent.EmotionalMusic = 5
    elif persistent.miyuki_love > 4:
        $ persistent.EmotionalMusic = 4
    elif persistent.miyuki_love > -4:
        $ persistent.EmotionalMusic = 3
    elif persistent.miyuki_love > -12:
        $ persistent.EmotionalMusic = 2
    else:
        $ persistent.EmotionalMusic = 1
    if persistent.eternal_day:
        play bgm "ttb27"
    elif persistent.meta_sex:
        pass
    elif persistent.world_recreate:
        play bgm "ttb02"
    elif persistent.EmotionalMusic == 5:
        play bgm "ttb11"
    elif persistent.EmotionalMusic == 4:
        play bgm "ttb16"
    elif persistent.EmotionalMusic == 3:
        play bgm "ttb04"
    elif persistent.EmotionalMusic == 2:
        play bgm "ttb21"
    elif persistent.EmotionalMusic == 1:
        play bgm "ttb18"
    if persistent.EmotionalMusic == 1:
        $ St("C",300,0,0,"bu曽根美雪_私服_病み_normal")
        with Dissolve(200.0/1000)
        voice "voice/e11/11a00010a01_d.opus"
        mx "\"Доброе утро.\""
    elif persistent.EmotionalMusic == 2:
        $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_normal")
        with Dissolve(200.0/1000)
        voice "voice/e11/11a00010a01_c.opus"
        mx "\"Доброе утро.\""
    elif persistent.EmotionalMusic == 4:
        $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
        with Dissolve(200.0/1000)
        voice "voice/e11/11a00010a01.opus"
        mx "\"Доброе утро.\""
    elif persistent.EmotionalMusic == 5:
        $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
        with Dissolve(200.0/1000)
        voice "voice/e11/11a00010a01_b.opus"
        mx "\"Доброе утро.\""
    else:
        $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
        with Dissolve(200.0/1000)
        voice "voice/e11/11a00010a01.opus"
        mx "\"Доброе утро.\""

    "Миюки поприветствовала меня, пока готовила наш завтрак."
    if persistent.EmotionalMusic == 1:
        $ St("C",300,0,0,"bu曽根美雪_私服_病み_normal")
        with Dissolve(200.0/1000)
        voice "voice/e11/11a00020a01_c.opus"

        mx "\"Чем займёмся сегодня?\""
    elif persistent.EmotionalMusic == 2:
        $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_normal")
        with Dissolve(200.0/1000)
        voice "voice/e11/11a00020a01_c.opus"

        mx "\"Чем займёмся сегодня?\""
    elif persistent.EmotionalMusic == 4:
        $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
        with Dissolve(200.0/1000)
        voice "voice/e11/11a00020a01_b.opus"

        mx "\"Чем займёмся сегодня?\""
    elif persistent.EmotionalMusic == 5:
        $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
        with Dissolve(200.0/1000)
        voice "voice/e11/11a00020a01_b.opus"

        mx "\"Чем займёмся сегодня?\""
    else:
        $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
        with Dissolve(200.0/1000)
        voice "voice/e11/11a00020a01.opus"

        mx "\"Чем займёмся сегодня?\""
    python:
        from random import randrange
        choice_number = randrange(0,10)
    if (choice_number == 0):
        $ choice0 = "Пообщаться с Миюки";
        $ choice1 = "Пообщаться с Аой";
        $ choice2 = "Пообщаться с самим собой";
    elif (choice_number == 1):
        $ choice0 = "Поднять очки привязанности Миюки";
        $ choice1 = "Поднять очки привязанности Аой";
        $ choice2 = "Ничего не делать";
    elif (choice_number == 2):
        $ choice0 = "Приспособиться к новому миру";
        $ choice1 = "Бежать из нового мира";
        $ choice2 = "Ничего не делать";
    elif (choice_number == 3):
        $ choice0 = "Заняться сексом с Миюки";
        $ choice1 = "Заняться сексом с Аой";
        $ choice2 = "Я не в настроении";
    elif (choice_number == 4):
        $ choice0 = "Забыть Аой";
        $ choice1 = "Помнить Аой";
        $ choice2 = "Ничего не делать";
    elif (choice_number == 5):
        $ choice0 = "Сохранить свои воспоминания с Миюки";
        $ choice1 = "Загрузить свои воспоминания с Аой";
        $ choice2 = "Продолжить";
    elif (choice_number == 6):
        $ choice0 = "Остаться в квартире";
        $ choice1 = "Бежать из квартиры";
        $ choice2 = "Ничего не делать";
    elif (choice_number == 7):
        $ choice0 = "Любить Миюки";
        $ choice1 = "Любить Аой";
        $ choice2 = "Что ВООБЩЕ такое любовь?";
    elif (choice_number == 8):
        $ choice0 = "Защищать Миюки";
        $ choice1 = "Драться с Миюки";
        $ choice2 = "Ждать и наблюдать";
    elif (choice_number == 9):
        $ choice0 = "Продолжить рут Миюки";
        $ choice1 = "Выбрать рут Аой";
        $ choice2 = "Ничего не делать";
    if not persistent.aoi_sex1:
        $ choice2 = "Пожалуйста, верни Аой.";
    if persistent.about_save:
        $ SetChoiceSelect = menu([(choice0,0),(choice1,1),(choice2,2)])
        if SetChoiceSelect==0:
            $ persistent.miyuki_love += 1
        elif SetChoiceSelect==1:
            $ persistent.miyuki_love -= 1
    else:
        $ SetChoiceSelect = 0
    if not persistent.about_save:
        $ GameName = "e1121.nss";
    elif persistent.miyuki_sex1 and persistent.miyuki_sex2 and not persistent.world_recreate:
        $ persistent.miyuki_noescape = True
        $ GameName = "e1131.nss";
    elif SetChoiceSelect==2 and not persistent.world_recreate and not persistent.aoi_sex1:
        $ GameName = "e1211.nss";
        $ persistent.miyuki_love -= 1
    elif persistent.EmotionalMusic == 1:
        $ GameName = "e1112e.nss";
    elif persistent.EmotionalMusic == 2:
        $ GameName = "e1112d.nss";
    elif persistent.EmotionalMusic == 3:
        $ GameName = "e1112a.nss";
    elif persistent.EmotionalMusic == 4:
        $ GameName = "e1112b.nss";
    else:
        $ GameName = "e1112c.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
