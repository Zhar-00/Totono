label e2172i_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2173.nss"
    return
label e2172i:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(0.0/1000)

    "Книгу «Кулинария-101»."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/e21/72i00010a01.opus"

    mx "\"Аргх! Забудь!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e21/72i00020a01.opus"

    mx "\"Мне уже надоело играть в эту игру с тобой!\""
    xy "\"......?\""

    "О чём это она?"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
