label a7215a_MAIN:
    call expression GameName
    $ persistent.imagelog["eva7211美雪さん処女喪失g"]=True
    $ PreGameName = GameName
    $ GameName = "a7216.nss"
    return
label a7215a:
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    hide 絵色黒
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失f"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失b"]+".jpg") as 絵捏造窓絵専上 zorder 1110 at truecenter
    show expression Solid("FFFFFF") as 絵演色白
    with Dissolve(0.0/1000)
    pause (16/1000)
    hide 絵演色白
    with Dissolve(150.0/1000)
    pause (50/1000)
    show expression Solid("FFFFFF") as 絵演色白
    pause (16/1000)
    hide 絵演色白
    with Dissolve(150.0/1000)
    pause (200/1000)
    show expression Solid("FFFFFF") as 絵演色白 zorder 5000
    with Dissolve((200.0+800.0)/1000)
    with Dissolve((200.0+1000.0)/1000)
    pause (500/1000)
    hide 絵板写
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失g"]+".jpg") as 絵専 zorder 1100 at truecenter
    hide 絵演色白
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    voice "voice/a72/15a00010a01.opus"

    mx "А-ах... н-н... н-н-н... н-нг-г-гх-х!.. Ха-а... ха-а... ха-а... н-н-н..."
    voice "voice/a72/15a00020a01.opus"

    mx "Ты кончаешь... так обильно... я чувствую, как ты... пульсируешь..."

    "Киска Миюки крепко обхватила мой ствол, выжимая из него всё до последней капли."

    "Мой член начал становиться мягче, и я начал медленно вытаскивать его из её прохода."
    hide 絵専
    hide 絵捏造窓
    show expression ("cg/bg/l/"+imagename["bg030300_3_自宅リビング_l"]+".jpg") as 絵背景 zorder 15:
        pos (620,-410)
    with Dissolve(1000.0/1000)
    voice "voice/a72/15a00030a01.opus"

    mx "А-ах! Не надо! Она сейчас выльется наружу... А-а-а-ах!"

    xy "...Тебе правда нравится быть наполненной моей спермой, да?"
    voice "voice/a72/15a00040a01.opus"

    mx "Чт... А-ах!"
    voice "voice/a72/15a00050a01.opus"

    mx "Дело... дело не в том, что мне это \"нравится\" или ещё что..."
    voice "voice/a72/15a00060a01.opus"

    mx "Это просто... воспоминание о нашей любви."

    xy "А... т-точно."

    "Это так мило... я аж покраснел..."

    "Но это правда; мы с Миюки наконец-то скрепили наш любовный союз."

    "Алая сперма, вытекающая из неё, - достаточное тому доказательство."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
