label c5211_MAIN:
    call expression GameName
    $ persistent.imagelog["bg030500_3_自宅廊下２階"]=True
    $ persistent.imagelog["bg030500_3_自宅廊下２階消灯"]=True
    $ persistent.imagelog["bg030311_3_自宅リビングカーテン開消灯"]=True
    $ PreGameName = GameName
    $ GameName = "c5221.nss"
    return
label c5211:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030200_2_自宅玄関"]+".jpg")
    $ sename = "se物体_ドア自宅_閉まる"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve(1000.0/1000)
    pause (500/1000)
    show expression ("cg/bg/"+imagename["bg030400_3_自宅廊下"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(800.0/1000)

    xy "\"Я дома!\""

    "Я прокричал эти слова, но ответа не последовало."

    "Всё было в полном порядке до поры до времени..."

    "Так почему я вдруг почувствовал такую обеспокоенность?"

    xy "\"Эй! Ты здесь?\""

    xy "\"Аой?\""
    pause (500/1000)
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]
    pause (500/1000)

    xy "\"Привет, Иру.\""
    play voc "c52/1100010b04"
    show expression ("cg/bg/"+imagename["bg030300_2_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    pause (100/1000)
    $ sename = "se擬音_コミカル_ヒョイ"
    play se sedict[sename]
    pause (300/1000)
    play voc "c52/1100020b04"
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]

    xy "\"Куда же она подевалась?..\""

    "Пробормотал я себе под нос, пока играл с Иру."
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg030311_3_自宅リビングカーテン開消灯"]+".jpg")
    $ st_timezone = "消灯"
    with Dissolve(4000.0/1000)

    "Обычно мне не по себе от того, что я чуть ли не на всеобщее обозрение выставляю свои отношения."

    "Так что мы с Аой довольно часто уходили из школы в одиночку."

    "Но, оглядываясь назад, меня в этом что-то беспокоило."

    "Аой не состояла ни в каких клубах или ещё что."

    "И я почему-то сомневаюсь, что у неё были ещё какие-нибудь близкие друзья, помимо Миюки."
    with Dissolve(500.0/1000)

    "Так чем же она сейчас занимается?"
    $ sename = "se物体_インターホン_鳴る"
    play se sedict[sename]
    pause (300/1000)
    voice "voice/c52/1100030a02.opus"

    aoi "\"Аой дома!\""
    $ sename = "se物体_ドア自宅_閉まる"
    play se sedict[sename]
    pause (500/1000)

    "Входная дверь открылась, и Аой прокричала эти слова."
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]

    "Иру спрыгнул с дивана, чтобы поприветствовать её."
    voice "voice/c52/1100040a02.opus"

    aoi "\"Ты скучал по мне, Иру?\""
    $ sename = "se物体_ドア室内_開く01"
    play se sedict[sename]
    pause (800/1000)
    $ St("C",300,0,0,"st向日アオイ_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/c52/1100050a02.opus"

    aoi "\"Пора ужинать—\""

    xy "\"Добро пожаловать домой.\"."

    xy "\"Где ты была?\""
    $ St("C",300,0,0,"st向日アオイ_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c52/1100060a02.opus"

    aoi "\"Ходила за молоком.\""
    $ sename = "se物体_ビニル袋_鳴る"
    play se sedict[sename]

    "Аой достала коробку молока из пакета, который принесла из магазина за углом."

    "Но самый ближайший магазин за углом здесь - семейный магазин Ютаро - находился всего в десяти минутах ходьбы отсюда."

    "Это не должно было занять у неё столько времени..."
    $ St("C",300,0,0,"st向日アオイ_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/c52/1100070a02.opus"

    aoi "\"Что-то не так?\""

    xy "\"А, ничего.\""
    $ St("C",300,0,0,"st向日アオイ_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c52/1100080a02.opus"
    aoi "\"Шиничи?\""

    xy "\"Я сказал, ничего.\""
    $ St("C",300,0,0,"st向日アオイ_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c52/1100090a02.opus"

    aoi "\"Стой!\""

    "Аой отчаянно пыталась остановить меня."
    voice "voice/c52/1100100a02.opus"

    aoi "\"Э-эм, Аой надо поговорить с т—\""

    xy "\"Прости. Это подождёт.\""
    $ St("C",300,0,0,"st向日アオイ_制服_通常_pain")
    with Dissolve(200.0/1000)
    voice "voice/c52/1100110a02.opus"
    aoi "\"Шиничи...\""
    stop se fadeout (150.0/1000)
    $ sename = "se人体_足音_階段自宅上がる01"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg030500_3_自宅廊下２階消灯"]+".jpg")
    hide StC
    hide StMR
    hide StML
    with Dissolve(500.0/1000)
    pause (500/1000)

    "Я отмахнулся от неё и поднялся по лестнице."

    "Она даже не пыталась угнаться за мной."
    $ sename = "se物体_ドア室内_閉まる01"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    with Dissolve(500.0/1000)
    pause (1000/1000)
    $ renpy.music.play("ttb06",channel = "bgm", if_changed = True)
    pause (500/1000)

    "Я начал смотреть в окно."
    show expression ("cg/ef/"+imagename["efbg空汎用満月"]+".jpg") as 絵背景 zorder 15 at truecenter
    with Dissolve(800.0/1000)
    pause (500/1000)
    xy "\"......\""

    "Бледная луна висела над тёмным полотном ночного неба."

    "Это напомнило мне о той ночи, когда мы переспали на крыше."

    "Тогда я был очень счастлив."

    "Честно, о чём-то большем я не мог и мечтать."

    "И я уверен, она чувствовала то же самое."

    "...Но это было тогда."

    "А теперь, с каждым мгновением, мы отдалялись всё сильнее."

    "Мы всё ещё на одной планете?"
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((3000.0+1000.0)/1000)
    pause (1500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
