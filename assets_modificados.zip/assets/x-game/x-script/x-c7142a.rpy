label c7142a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c7143.nss"
    return
label c7142a:
    hide 絵色黒
    $ st_timezone = "昼"
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    show expression ("cg/bg/l/"+imagename["bg030100_3_自宅自室_l"]+".jpg") as 絵演出背景 zorder 15 at truecenter
    $ St("C",300,150,0,"fu曽根美雪血まみれ_私服_恋人_mad")
    with Dissolve(0.0/1000)

    xy "\"Я люблю тебя.\""

    "Я знаю, что для этого уже слишком поздно, но я не могу просто лежать здесь и позволить ей убить меня!"

    "Я должен как-нибудь заставить её успокоиться..."

    xy "\"Я обещаю, что буду всегда любить тебя, так что...\""

    xy "\"...Пожалуйста, просто перестань делать это!\""
    pause (300/1000)
    $ St("C",300,0,0,"fu曽根美雪血まみれ_私服_病み_mad")
    with Dissolve(400.0/1000)
    pause (700/1000)
    voice "voice/c71/42a00010a01.opus"

    mx "\"Хе-хе-хе.\""
    pause (300/1000)
    $ St("C",300,0,0,"fu曽根美雪血まみれ_私服_病み_lost")
    with Dissolve(300.0/1000)
    pause (700/1000)
    voice "voice/c71/42a00020a01.opus"

    mx "\"Ты уже подписал свой смертный приговор. Ты бы никогда не попытался заполучить моё поощрение.\""
    voice "voice/c71/42a00030a01.opus"

    mx "\"А это значит, что это не ты сказал эти слова.\""
    pause (300/1000)
    $ St("C",300,150,0,"fu曽根美雪血まみれ_私服_恋人_mad")
    with Dissolve(400.0/1000)
    pause (700/1000)
    voice "voice/c71/42a00040a01.opus"

    mx "\"Нет... Это был выбор, который ТЫ сделал, так ведь?\""
    voice "voice/c71/42a00050a01.opus"

    mx "\"Я тронута... Очень тронута, если честно.\""
    pause (300/1000)
    $ St("C",300,150,0,"fu曽根美雪血まみれ_私服_恋人_lost")
    with Dissolve(300.0/1000)
    pause (700/1000)
    voice "voice/c71/42a00060a01.opus"

    mx "\"Но уже слишком поздно.\""
    pause (300/1000)
    $ St("C",300,150,0,"fu曽根美雪血まみれ_私服_恋人_mad")
    with Dissolve(300.0/1000)
    pause (700/1000)
    voice "voice/c71/42a00070a01.opus"

    mx "\"Ты правда думаешь, что я поверю всему тому, что ты сейчас скажешь?\""
    pause (300/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
