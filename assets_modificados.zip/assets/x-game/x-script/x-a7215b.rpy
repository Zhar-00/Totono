label a7215b_MAIN:
    call expression GameName
    $ persistent.imagelog["eva7211美雪さん処女喪失h"]=True
    $ PreGameName = GameName
    $ GameName = "a7216.nss"
    $ bukkake = False
    return
label a7215b:
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失f"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失b"]+".jpg") as 絵捏造窓絵専上 zorder 1110 at truecenter
    show expression Solid("FFFFFF") as 絵演色白
    with Dissolve(0.0/1000)
    pause (16/1000)
    hide 絵演色白
    with Dissolve(150.0/1000)
    pause (50/1000)
    show expression Solid("FFFFFF") as 絵演色白
    pause (16/1000)
    hide 絵演色白
    with Dissolve(150.0/1000)
    pause (200/1000)
    show expression Solid("FFFFFF") as 絵演色白 zorder 5000
    with Dissolve((200.0+800.0)/1000)
    with Dissolve((200.0+1000.0)/1000)
    pause (500/1000)
    hide 絵板写
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失h"]+".jpg") as 絵専 zorder 1100 at truecenter
    hide 絵演色白
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    voice "voice/a72/15b00010a01.opus"

    mx "Хн-н! Н-н-н! Н-н-н-н-н! Н-н-н! Н-нха-а... а-ах... а-а-а-ах..."
    voice "voice/a72/15b00020a01.opus"

    mx "А-ах... н-н... н-н-н... н-нг-г-гх-х!.. Ха-а... ха-а... ха-а... ннн..."
    voice "voice/a72/15b00030a01.opus"

    mx "Ты кончаешь... так обильно... Твой член всё ещё продолжает... Н-н-н-н!"

    "Как только я вытащил из неё свой член, сперма выплёскивалась из моей головки, словно лава из вулкана."

    "И каждый раз, когда моя молочно-белая жидкость попадала на её кожу, всё её тело дёргалось."
    voice "voice/a72/15b00040a01.opus"

    mx "Ха-а... а-ах... н-н-н... она вся на моей груди... и на моём лице... её так много... я удивлена..."
    hide 絵捏造窓
    hide 絵専
    show expression ("cg/bg/l/"+imagename["bg030300_3_自宅リビング_l"]+".jpg") as 絵背景 zorder 15:
        pos (620,-410)
    with Dissolve(800.0/1000)

    "Её пальцы дрожали, она протянула руку и зачерпнула немного моей жидкости."

    "А потом, с восторженным выражением лица, она поднесла её к своему рту."
    voice "voice/a72/15b00050a01.opus"

    mx "М-м... хл-л-люп... хл-л-л-л-люп... м-м-м... м-м-м-м... хл-л-л-люп... м-м... м-м-м-м... м-м-м..."
    voice "voice/a72/15b00060a01.opus"

    mx "М-м-м... н-нгл-л-л!.. М-м... Хе-хе! Ого..."
    voice "voice/a72/15b00070a01.opus"

    mx "Как будто ты пометил меня своим запахом... и внутри, и снаружи..."

    "Она лучезарно улыбнулась мне, будучи полностью удовлетворённой..."

    "...и я не мог не улыбнуться ей в ответ."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
