label e2182d_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2182d:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(0.0/1000)

    xy "\"Как насчёт... заняться этим в школе?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    voice "voice/e21/82d00010a01.opus"
    mx "\"......Да...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/82d00020a01.opus"

    mx "\"По правде говоря, я и сама размышляла над этим.\""

    xy "\"О... Здорово.\""

    "Похоже, мы на одной волне."

    "Полагаю, это означает, что мы... сексуально совместимы..."

    "От одной лишь мысли об этом я немного смутился."
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/82d00030a01.opus"

    mx "\"В общем... Знаешь ту пустую парту в классе?\""
    voice "voice/e21/82d00040a01.opus"

    mx "\"Они сказали мне переместить её на крышу. И я подумала, что ты мог бы помочь мне.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/e21/82d00050a01.opus"

    mx "\"И что, если... мы потом займёмся этим там?\""

    "Крыша, разумеется, предлагала нам немного уединения..."
    $ persistent.miyuki_sex_promise = True;
    $ temp_miyuki_sex_promise = True;
    if persistent.minus_choice  and persistent.world_recreate:
        $ GameName = "e2184b.nss";
    else:
        $ GameName = "e2184a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
