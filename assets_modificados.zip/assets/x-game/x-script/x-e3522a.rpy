label e3522a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3521a.nss"
    return
label e3522a:
    hide 絵色黒
    stop bgm fadeout (2000.0/1000)
    show expression ("cg/bg/m/"+imagename["bg010300_9_学校屋根_m"]+".jpg") as 絵背景 at truecenter
    $ St("C",300,0,0,"fu曽根美雪_制服_腕組み_sad")
    with Dissolve(0.0/1000)
    with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ renpy.music.play("ttb26",channel = "bgm", if_changed = True)
    voice "voice/e35/22a00010a01.opus"

    mx "\"Куда ты пошёл?..\""
    $ St("C",300,0,0,"fu曽根美雪_制服_腕組み_fear")
    with Dissolve(800.0/1000)
    voice "voice/e35/22a00020a01.opus"

    mx "\"Ты...\""
    $ St("C",300,0,0,"fu曽根美雪_制服_病み_sad")
    with Dissolve(800.0/1000)
    voice "voice/e35/22a00030a01.opus"

    mx "\"Ты жалеешь о том, что выбрал меня?\""
    menu:
        "Конечно же нет.":
            pass
    menu:
        "Это был нелёгкий выбор.":
            pass
    menu:
        "И мои чувства никогда не изменятся.":
            pass
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
