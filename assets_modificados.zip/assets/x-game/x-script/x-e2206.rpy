label e2206_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2207.nss"
    return
label e2206:
    hide 絵色黒
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)

    xy "\"Слушай... Мы уже закончили?\""

    "С меня хватит разговоров с этим самозваным «божеством»."

    xy "\"По правде говоря, я не понял ни одного твоего слова—\""
    voice "voice/e22/0600010b02.opus"

    kmsm "\"АОЙ - ЭТО СУЩЕСТВОВАНИЕ, НЕ ПОХОЖЕЕ НИ НА ЧТО ДРУГОЕ.\""
    voice "voice/e22/0600020b02.opus"

    kmsm "\"ОНА ИСПЫТЫВАЛА ЛЮБОВЬ БЕСЧИСЛЕННОЕ МНОЖЕСТВО РАЗ.\""
    voice "voice/e22/0600030b02.opus"

    kmsm "\"СОВОКУПЛЯЛАСЬ С БЕСЧИСЛЕННЫМ МНОЖЕСТВОМ ПРОТАГОНИСТОВ.\""
    voice "voice/e22/0600040b02.opus"

    kmsm "\"ОНА БЫЛА ПРОСТО ПУСТЫМ СОСУДОМ.\""
    voice "voice/e22/0600050b02.opus"

    kmsm "\"НО НА ЭТОТ РАЗ, ОНА НАУЧИЛАСЬ ВОСПРИНИМАТЬ УНИКАЛЬНЫЕ ЭМОЦИИ.\""
    voice "voice/e22/0600060b02.opus"

    kmsm "\"ОНА ХРАНИТ К [[ТЕБЕ] РОМАНТИЧЕСКУЮ ПРИВЯЗАННОСТЬ.\""

    xy "\"Правда?..\""
    voice "voice/e22/0600070b02.opus"

    kmsm "\"ИСТОЧНИК НЕИЗВЕСТЕН. ОБРАБОТКА НЕВОЗМОЖНА. ПОДТВЕРЖДЁННЫЙ БАГ.\""
    voice "voice/e22/0600080b02.opus"

    kmsm "\"ДЛЯ ИССЛЕДОВАНИЯ НЕОБХОДИМЫ СВЯЗЬ И СИНХРОНИЗАЦИЯ ПАМЯТИ.\""
    voice "voice/e22/0600090b02.opus"

    kmsm "\"ПОЭТОМУ МЫ ПРОСИМ [[ТЕБЯ].\""
    voice "voice/e22/0600100b02.opus"

    kmsm "\"ДОСТАВЬ СИМ-КАРТУ АОЙ И СОВЕРШИ СИНХРОНИЗАЦИЮ ПАМЯТИ. ОТКАТИ ВСЕЛЕННУЮ К ЕГО ПЕРВОНАЧАЛЬНОМУ СОСТОЯНИЮ.\""
    $ persistent.call_known = True;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
