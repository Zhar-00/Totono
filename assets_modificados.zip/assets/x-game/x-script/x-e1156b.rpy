label e1156b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1156b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)

    "...Пойти искать Аой?"

    "Я что-то перепутал."

    "Аой - персонаж в видеоигре!"

    "Она никак не может существовать в реальности!"

    "Думаю, я мог бы пойти искать фигурку Аой, или даже наволочку с её изображением..."

    "И раз уж Миюки ушла, это мой единственный шанс заполучить какой-нибудь сувенир..."

    "Но это сейчас не важно."

    "Нет, сейчас у меня в приоритете—"
    menu:
        "Пойти искать Миюки":
            $ SetChoiceSelect = 0
        "Пойти искать Аой":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e1156a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e1156c.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
