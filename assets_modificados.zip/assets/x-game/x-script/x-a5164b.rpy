label a5164b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5165.nss"
    return
label a5164b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ renpy.music.play("ttb07",channel = "bgm", if_changed = True)
    show expression ("cg/ev/"+imagename["eva5163アオイ汗拭き"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    "То, что я скажу ей, наверняка причинит ей боль."
    "Это изменит нашу дружбу... навсегда."
    "Я знаю это."
    "Но... я её друг."
    "Если она мне так же дорога, как я это и утверждаю, то я должен рассказать ей правду."
    "Твой «бог» ненастоящий, Аой."
    "Вся эта неразбериха с батареями и передатчиками? Это просто твоя выдуманная фантазия."
    "Видеоигры – не то же самое, что и реальная жизнь."
    "Ты просто—"
    show expression ("cg/ev/l/"+imagename["eva5163アオイ汗拭き_l"]+".jpg") as 絵専弐:
        pos (-490,-185)
    $ sename = "se人体_動作_衣擦れ02"
    play se sedict[sename]
    with Dissolve((500.0+1000.0)/1000)
    xy "Аой... Всё это—"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
