label e3431_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e3431:
    hide 絵色黒
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    $ renpy.music.play("ttb14",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)
    pause (800/1000)
    voice "voice/e34/3100010b02.opus"

    kmsm "\"...ОБНАРУЖЕН НЕОЖИДАННЫЙ ОТВЕТ.\""
    voice "voice/e34/3100020b02.opus"

    kmsm "\"ВВЕДЁННОЕ ЧИСЛО ЯВЛЯЕТСЯ ЧИТ-КОДОМ. ОНО ОТКРЫВАЕТ ВСЕ СЦЕНКИ И СЕКС-СЦЕНЫ.\""
    voice "voice/e34/3100030b02.opus"

    kmsm "\"И В СВОЮ ОЧЕРЕДЬ, ОСНОВНАЯ СЮЖЕТНАЯ ЛИНИЯ БУДЕТ ОТБРОШЕНА.\""
    voice "voice/e34/3100040b02.opus"

    kmsm "\"ЭТО ОБНОВЛЕНИЕ НЕОБРАТИМО. ПОСЛЕ ЕГО ЗАВЕРШЕНИЯ ОБЫЧНАЯ ИГРА СТАНЕТ НЕДОСТУПНОЙ.\""
    voice "voice/e34/3100050b02.opus"

    kmsm "\"ВНИМАНИЕ. ЕСЛИ СУБЪЕКТ ЖЕЛАЕТ ИСПЫТАТЬ МИР ТАК, КАК И ЗАДУМЫВАЛОСЬ, НЕМЕДЛЕННО ЗАКРОЙТЕ ИГРУ.\""
    voice "voice/e34/3100060b02.opus"

    kmsm "\"[[ТЫ] ВСЁ ЕЩЁ ХОЧЕШЬ ПРОДОЛЖИТЬ?\""
    $ active_time -= 1 ;
    menu:
        "Передать чит-код":
            $ SetChoiceSelect = 0
        "Отменить передачу":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e3432a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e3432b.nss";
    if (active_time <= 0):
        $ GameName = "e3424h.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
