label e2172h_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2173.nss"
    return
label e2172h:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(0.0/1000)

    "Книгу «Кулинария-101»."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/e21/72h00010a01.opus"

    mx "\"Это уже твоя седьмая копия...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/72h00020a01.opus"

    mx "\"Теперь у тебя есть все копии на каждый день недели.\""

    xy "\"Зачем я вообще делаю это? В этом нет никакого смысла...\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
