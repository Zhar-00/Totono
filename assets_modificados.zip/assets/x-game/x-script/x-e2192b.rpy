label e2192b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2192b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(0.0/1000)

    xy "\"Но всё же, заглянуть в неё определённо стоит, тебе так не кажется?\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Я подошёл к коробке и протянул руку—"
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_rage")
    with Dissolve(200.0/1000)
    voice "voice/e21/92b00010a01.opus"

    mx "\"Эй! Стой! Там ничего нет!\""

    xy "\"Откуда ты знаешь?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/e21/92b00020a01.opus"

    mx "\"Я просто знаю, ладно?!\""

    "Она озлобленно посмотрела на меня."

    "...Чего это она так сильно переживает из-за этой коробки?"
    voice "voice/e21/92b00030a01.opus"

    mx "\"Что для тебя намного важнее, я или коробка?\""
    menu:
        "Миюки":
            $ SetChoiceSelect = 0
        "Коробка":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ persistent.miyuki_love += 1
        $ GameName = "e2193a.nss";
    elif SetChoiceSelect==1:
        $ persistent.miyuki_love -= 1
        $ GameName = "e2193b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
