label e2203e_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2203e:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)

    xy "\"......Что за?\""

    "Именно тогда, когда я попытался открыть её список контактов, появился экран блокировки."

    "У него ещё стояла разблокировка по отпечатку пальца."

    "Я проверил её своим указательным пальцем, но, естественно, мой отпечаток был отклонён."

    "Я заметил, что здесь ещё есть вариант «Разблокировка с помощью секретных вопросов»..."

    "Но Миюки вернётся в любую минуту."
    show expression ("cg/bg/"+imagename["bg110110_1_マンションリビングソファー"]+".jpg")
    with Dissolve(500.0/1000)

    "Поэтому я положил телефон обратно на стол и вернулся к своему домашнему заданию, как хороший мальчик."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
