label e1165c_MAIN:
    call expression GameName
    $ persistent.imagelog["ef美雪鬼ごっこ体育館"]=True
    $ persistent.imagelog["bg010800_9_学校体育館"]=True
    $ PreGameName = GameName
    $ GameName = "e1165a.nss"
    return
label e1165c:
    show expression ("cg/bg/l/"+imagename["bg010100_9_学校階段_l"]+".jpg") as 絵背景 zorder 100:
        pos (-512,-140)
    hide 上背景
    hide 上背景
    with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    show expression ("cg/bg/l/"+imagename["bg010100_9_学校階段_l"]+".jpg") as 絵背景 zorder 100:
        pos (-512,-140)
    $ renpy.music.play("ttb23_ic",channel = "bgm", if_changed = True)
    voice "voice/e11/6500590a01.opus"
    mx "\"...О боже.\""
    voice "voice/e11/6500600a01.opus"
    mx "\"Ты обманул меня.\""
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_0.png",.5)
    show expression ("cg/bg/"+imagename["bg010700_9_学校廊下"]+".jpg")
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]
    hide 絵背景
    "Я обманул тебя не ради забавы, поверь мне!"
    "Но..."
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵覆 zorder 2020
    show expression ("cg/ev/"+imagename["eve1165アオイサヨナラa"]+".jpg") as 絵覆絵演回想 zorder 2010 at truecenter
    hide 絵回想板
    with Dissolve(800.0/1000)
    voice "voice/e11/6500610a02.opus"
    aoi "\"Нет! НЕ-Е-ЕТ!..\""
    voice "voice/e11/6500620a02.opus"
    aoi "\"Не стирай меня!..\""
    voice "voice/e11/6500630a02.opus"
    aoi "\"Аой не... хочет исчезать...\""
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    hide 絵覆
    hide 絵覆絵演回想
    hide 絵色回想黒
    pause (500/1000)
    hide 絵色黒
    with Dissolve(500.0/1000)
    "Миюки стёрла Аой из реальности."
    "Я не знаю, что произошло... или как она вообще смогла сделать это..."
    "...но я не могу просто закрыть на это глаза."
    "Миюки просто двинулась."
    "Но она моя старая подруга... и моя девушка."
    "А это значит, я должен это исправить."
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    voice "voice/e11/6500640a01.opus"
    mx "\"Видя то, как ты обманул меня...\""
    voice "voice/e11/6500650a01.opus"
    mx "\"Полагаю, это означает, что тебя стоит наказать.\""
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_1.png",.5)
    show expression ("cg/bg/"+imagename["bg010500_9_学校昇降口"]+".jpg")
    hide 絵背景
    hide 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_1.png",.5)
    "Обойдусь, спасибо!"
    "Пора бежать из школы—"
    $ sename = "se物体_ドア昇降口_揺らす"
    play se sedict[sename]
    xy "\"—!!!\""
    "Я помню, что эти двери были открыты, когда я пришёл сюда..."
    "Но теперь они по какой-то причине были закрыты..."
    voice "voice/e11/6500660a01.opus"
    mx "\"Куда это ты собрался?\""
    voice "voice/e11/6500670a01.opus"
    mx "\"Да ладно. Тебе некуда бежать.\""
    "А я уверен в обратном."
    "Если я не смогу выбраться через парадный вход, то мне придётся—"
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_0.png",.5)
    show expression ("cg/bg/"+imagename["bg010700_9_学校廊下"]+".jpg")
    hide 絵背景
    hide 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_1.png",.5)
    pause (300/1000)
    voice "voice/e11/6500680a01.opus"
    mx "\"Нашла тебя.\""
    xy "\"—?!\""
    "Это не может быть правдой!"
    "Я бежал так, будто от этого зависела вся моя жизнь..."
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_1.png",.5)
    show expression ("cg/bg/"+imagename["bg010700_9_学校廊下"]+".jpg")
    hide 絵背景
    pause (300/1000)
    "...но она даже не запыхалась!"
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_0.png",.5)
    show expression ("cg/bg/"+imagename["bg010700_9_学校廊下"]+".jpg")
    hide 絵背景
    hide 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_1.png",.5)
    pause (300/1000)
    "Как?.."
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_1.png",.5)
    show expression ("cg/bg/"+imagename["bg010700_9_学校廊下"]+".jpg")
    hide 絵背景
    hide 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_1.png",.5)
    pause (300/1000)
    "Как она смогла так легко меня догнать?"
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/circle_02_00_0.png",.5)
    show expression ("cg/bg/"+imagename["bg010700_9_学校廊下"]+".jpg")
    hide 絵背景
    hide 絵黒幕
    with ImageDissolve("cg/data/circle_02_00_1.png",.5)
    pause (300/1000)
    "Я пробирался сквозь свой искажённый мир."
    "Крепко сжимая телефон Миюки в руке."
    "Но я не мог сбежать."
    "Чёрный выход... Спортзал... Соединяющий коридор..."
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_0.png",.5)
    show expression ("cg/bg/"+imagename["bg010500_9_学校昇降口"]+".jpg")
    hide 絵背景
    hide 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_1.png",.5)
    pause (200/1000)
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_1.png",.5)
    show expression ("cg/bg/"+imagename["bg010100_9_学校階段"]+".jpg")
    hide 絵背景
    hide 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_0.png",.5)
    pause (200/1000)
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_0.png",.5)
    show expression ("cg/bg/"+imagename["bg010700_9_学校廊下"]+".jpg")
    hide 絵背景
    hide 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_1.png",.5)
    pause (200/1000)
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/slide_01_01_1.png",.5)
    show expression ("cg/bg/"+imagename["bg010800_9_学校体育館"]+".jpg")
    pause (200/1000)
    $ sename = "se物体_ドア体育_開く03"
    play se sedict[sename]
    hide 絵効果
    hide 絵背景
    hide 絵黒幕
    with ImageDissolve("cg/data/slide_06_00_0.png",.5)
    "Они все были крепко закрыты."
    "Окна тоже не открывались."
    "Выхода нет."
    $ sename = "se物体_ドア体育_開く01"
    play se sedict[sename]
    show expression ("cg/ef/"+imagename["ef美雪鬼ごっこ体育館"]+".jpg") as 絵演効果 zorder 1000:
        ypos -576
        linear 12 ypos 0
    pause (16/1000)
    with Dissolve((0.0+1000.0)/1000)
    voice "voice/e11/6500690a01.opus"
    mx "\"Это бесполезно.\""
    voice "voice/e11/6500700a01.opus"
    mx "\"Я перекрыла все выходы.\""

    "Это невозможно."
    "И всё же... разумеется, я был здесь в ловушке."
    "Куда бы я не пошёл, голос Миюки всюду находил меня."
    "Я больше не чувствовал расстояния."
    "Куда бы я не побежал, я мог почти что заметить, как Миюки стояла впереди."
    "Нет..."
    hide 絵演効果
    with Dissolve(800.0/1000)
    voice "voice/e11/6500710a01.opus"
    mx "\"Я же сказала тебе, это бесполезно.\""
    xy "\"—!!!\""
    show expression Solid("000000") as 絵黒幕
    with ImageDissolve("cg/data/circle_02_00_0.png",.5)
    scene expression ("cg/bg/"+imagename["bg010700_9_学校廊下"]+".jpg")
    hide 絵背景
    hide 絵黒幕
    with ImageDissolve("cg/data/circle_02_00_1.png",.5)
    "Я тут же побежал назад."
    "Миюки, похоже, никуда не торопилась, и всё же она опережала меня каждый раз."
    "И такими темпами я от неё никогда не смогу убежать!"

    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵色回想黒 zorder 3900
    show expression ("cg/ev/l/"+imagename["eve1165アオイサヨナラb_l"]+".jpg") as 絵覆絵演回想 zorder 2010 at truecenter
    hide 絵回想板
    with Dissolve(800.0/1000)
    voice "voice/e11/6500720a02.opus"
    aoi "\"Мой кодовый номер.\""
    voice "voice/e11/6500730a02.opus"
    aoi "\"Вставь его... в телефон Миюки...\""
    voice "voice/e11/6500740a02.opus"
    aoi "\"И... верни меня... назад...\""
    hide 絵覆絵演回想
    hide 絵色回想黒
    with Dissolve(800.0/1000)
    xy "\"...Точно!\""
    "Мне не НУЖНО бежать!"
    "Моя цель - вернуть Аой обратно в реальность."
    "Так что мне надо просто выиграть немного времени, пока у меня не появится возможность совершить телефонный звонок!"
    "Мой взгляд зацепился за приоткрытую дверь."
    "Я забежал в класс и осторожно закрыл дверь, дабы она не создала лишний шум."
    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    with Dissolve(150.0/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    "Это не наш класс."
    "Это класс первокурсников, в котором я ни разу не был."
    "Теперь, когда я здесь, Миюки не должна меня видеть."
    "А это значит, у меня должно быть время на то, чтобы позвонить Аой—"
    voice "voice/e11/6500750a01.opus"
    mx "\"Я знаю тебя, Шиничи.\""
    voice "voice/e11/6500760a01.opus"
    mx "\"И я могу предсказать каждый твой шаг.\""


    "Шаги Миюки не стихали."
    "Как?"
    "Как она понимает, на каком я этаже?"
    "Как будто она наперёд знала о том, куда я пойду..."
    "Стоп, что я делаю? У меня нет времени на то, чтобы переживать из-за этого!"
    "Я спрятался за учительской кафедрой и достал телефон Миюки."
    "До того, как она исчезла, она сказала мне использовать её кодовый номер."
    stop se fadeout (3000.0/1000)
    "И этот номер—"
label e1165c_call:
    call screen  miyuki_phone
    $ input_number = int(_return)
    $ input_number_str = _return
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
