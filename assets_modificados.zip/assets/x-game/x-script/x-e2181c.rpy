label e2181c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2181b.nss"
    return
label e2181c:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    $ sename = "se人体_動作_投球02"
    play se sedict[sename]
    pause (200/1000)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (200/1000)

    xy "\"А?!\""

    "Моя бита прошла сквозь воздух."

    "Я правильно угадал её ход, и всё же она превзошла все мои ожидания..."

    xy "\"У тебя здорово получилось...\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/81c00010a01.opus"

    mx "\"Ты хоть представляешь себе, как много практики я в это вложила?\""

    "Верно подмечено... я не мог себе это даже представить..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
