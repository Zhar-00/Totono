label c6182_MAIN:
    call expression GameName
    $ persistent.imagelog["bg110300_3_マンション寝室"]=True
    $ persistent.imagelog["efbg猫ヘアピン通常浮気現場"]=True
    $ persistent.imagelog["bg110100_3_マンションリビング"]=True
    queue bgm "ttb22"
    $ PreGameName = GameName
    $ GameName = "c6191.nss"
    return
label c6182:
    hide 絵色黒
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    xy "......"

    "В квартире было пусто."

    "Учитывая всю ту элитную мебель, что была здесь, я не мог себе представить, что здесь живёт обычный школьник."

    "Но так или иначе, здесь никого не было."
    $ sename = "se物体_ドア室内_閉まる01"
    play se sedict[sename]
    pause (300/1000)
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/c61/8200010a01.opus"

    mx "\"В уборной никого. В ванной тоже никто не прячется. Да и обувь у порога не стоит.\""
    $ St("ML",300,0,0,"st曙雄太郎_私服_通常_think")
    voice "voice/c61/8200020b01.opus"

    xtl "\"Получается, они сюда и не приходили?..\""
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_normal")
    voice "voice/c61/8200030a01.opus"

    mx "\"Нет, они определённо были здесь.\""
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_hard")
    voice "voice/c61/8200040a01.opus"

    mx "\"Ванна влажная. И вода из-под крана всё ещё тёплая.\""
    voice "voice/c61/8200050a01.opus"

    mx "\"Рюджиро ушёл из магазина за углом вместе с Аой.\""
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_pride")
    voice "voice/c61/8200060a01.opus"

    mx "\"А потом, в какой-то момент после этого, кто-то принял здесь душ.\""

    xy "\"...Это просто косвенные улики...\""
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/c61/8200070a01.opus"

    mx "\"И правда. На данный момент у нас нет никаких конкретных доказательств.\""

    xy "\"Ютаро, ты не против, если я осмотрюсь здесь?\""
    $ St("ML",300,0,0,"st曙雄太郎_私服_通常_hard")
    voice "voice/c61/8200080b01.opus"

    xtl "\"Делай что хочешь, приятель.\""

    "Я бы соврал, если бы сказал, что мне не страшно."

    "Но, возможно, есть шанс, что я смогу найти доказательства её невиновности."
    xy "\"......\""

    "Я молча кивнул."
    hide StC
    hide StMR
    hide StML
    show expression Solid("000000") as 絵色黒
    with Dissolve(1000.0/1000)
    pause (500/1000)

    "Я не хочу смотреть."

    "Я не хочу искать что-либо."

    "Но я проигнорировал голос, кричащий в моей голове, и всё равно начал копаться в квартире."

    "Как будто какая-то невидимая сила заставляла меня делать это."
    stop bgm fadeout (2000.0/1000)
    show expression ("cg/bg/"+imagename["bg110300_3_マンション寝室"]+".jpg")
    $ st_timezone = "昼"
    hide 絵色黒
    with Dissolve(1000.0/1000)
    voice "voice/c61/8200090a01.opus"

    mx "\"А-а-ах!\""
    xy "\"Миюки!\""
    $ sename = "se人体_動作_抱きつく02"
    play se sedict[sename]
    pause (300/1000)

    "Миюки отскочила, и я поймал её своими руками."
    xy "\"В чём дело?\""
    $ St("ML",300,0,0,"bu曽根美雪_制服_病み_fear")
    voice "voice/c61/8200100a01.opus"

    mx "\"Там...\""
    hide StML with Dissolve(200.0/1000)

    "Миюки показывала на мусорное ведро за кроватью."

    "Что бы там не лежало, этого, судя по всему, было достаточно, чтобы выбить её из колеи."

    "Я почувствовал, как у меня начало плыть перед глазами."

    "Если бы только я мог сейчас потерять сознание."
    $ St("C",300,0,0,"st曙雄太郎_私服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c61/8200110b01.opus"
    xtl "\"Шиничи?\""

    xy "\"Дерзай.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Пока я держал Миюки, мои руки были немного заняты."

    "Ютаро вместо меня подошёл к мусорному ведру."
    voice "voice/c61/8200120b01.opus"

    xtl "\"......Угх.\""

    "Он заворчал."

    xy "\"В чём дело?\""

    xy "\"Что там?\""

    xy "\"Эй! Ютаро! Скажи мне, что там!!!\""
    $ renpy.music.play("ttb22",channel = "bgm", if_changed = True)
    voice "voice/c61/8200130b01.opus"

    xtl "\"...Презервативы.\""

    "От этого слова у меня скрутило живот."
    $ St("C",300,0,0,"st曙雄太郎_私服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c61/8200140b01.opus"

    xtl "\"Их упаковка была вскрыта, но...\""
    voice "voice/c61/8200150b01.opus"

    xtl "\"Они не были использованы.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Это был последний гвоздь, забиваемый в крышку гроба, последний удар, от которого у меня помутнело в глазах."

    "Боль в моей ноге казалась отдалённой, как будто это происходит в другом мире."
    show expression ("cg/bg/"+imagename["bg110300_3_マンション寝室"]+".jpg") as 揺れ背景 zorder 15 at truecenter
    $ sename = "se人体_動作_抱きつく02"
    play se sedict[sename]
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/c61/8200160a01.opus"

    mx "\"Шиничи, стой здесь.\""

    "Восстановив своё самообладание, теперь Миюки обнимала меня."
    voice "voice/c61/8200170a01.opus"

    mx "\"Ещё рано сдаваться.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/c61/8200180a01.opus"

    mx "\"В смысле, у нас нет каких-либо доказательств, что Аой—\""

    xy "\"Аой определённо была здесь.\""
    $ sename = "se人体_動作_起き上がる01"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)

    "Я медленно наклонился и подобрал вещь, на которую наступил."

    "Мои пальцы онемели и дрожали."

    "Я едва смог поднять её."

    xy "\"Аой изменяет мне.\""
    show expression ("cg/ef/"+imagename["efbg猫ヘアピン通常浮気現場"]+".jpg") as 絵演効果 zorder 1000 at center
    with Dissolve((1000.0+1000.0)/1000)
    pause (1500/1000)
    $ persistent.imagelog["passed_c6182"]=True
    stop bgm fadeout (4000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((4000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
