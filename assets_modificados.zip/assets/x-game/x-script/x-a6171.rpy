label a6171_MAIN:
    call expression GameName
    $ persistent.imagelog["bg060100_1_バッティングセンター店内"]=True
    $ persistent.imagelog["bg060200_1_バッティングセンターボックス"]=True
    $ PreGameName = GameName
    $ GameName = "a6181.nss"
    return
label a6171:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg060100_1_バッティングセンター店内"]+".jpg")
    with Dissolve(1000.0/1000)
    xy "......"
    "Как обычно, на бейсбольном поле не было ни души."
    "Я сидел на скамейке с битой в руке и смотрел в никуда."
    "Мои эмоции росли в груди, пока наконец не взорвались, после чего они погрузились в смутную бесформенность, которая кружилась у меня в животе."
    "Не имея возможности высвобождения, они скапливались во мне, словно осадок."
    "Время шло."
    "Я втайне возлагал большие надежды."
    show expression Solid("000000") as 絵色黒
    with Dissolve((1000.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg") as 絵背景 zorder 100 at truecenter
    pause (500/1000)
    with Dissolve((1000.0+300.0)/1000)
    "Вот я здесь, сижу в нашем старом-добром месте встречи."
    "В том месте, где я однажды изменил её судьбу."
    with Dissolve((1000.0+1000.0)/1000)
    hide 絵背景
    $ sename = "se物体_バット_取る"
    play se sedict[sename]
    pause (1000/1000)
    "И каким-то образом я убедил себя, что, возможно, приход сюда изменит также и мою."
    "Но я так и не смог попасть ни по одному мячу."
    "Я не мог и одного замаха сделать."
    show expression ("cg/bg/"+imagename["bg060200_1_バッティングセンターボックス"]+".jpg")
    $ sename = "se物体_バット_転がる"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (500/1000)
    xy "Ха-ха-ха..."
    "Я слабо посмеялся над своим же жалким положением вещей."
    "Я ещё никогда не ненавидел себя так сильно за всю свою жизнь."
    play voc "a61/7100010b04"
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    "И тут я услышал знакомый звук."
    show expression ("cg/bg/"+imagename["bg060100_1_バッティングセンター店内"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg060100_1_バッティングセンター店内_l"]+".jpg") as 絵演背景 zorder 1010:
        pos (-50,-576)
    with Dissolve(1000.0/1000)
    "Маленький чёрный котёнок вылез из-под скамейки."
    xy "Иру, это ты?"
    play voc "a61/7100020b04"
    "Кот-передатчик мило мяукнул в ответ."
    "Если Иру здесь... то..."
    $ sename = "se人体_足音_歩くアオイL"
    play se sedict[sename]
    pause (3500/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    stop se fadeout (150.0/1000)
    hide 絵演背景
    with Dissolve(1000.0/1000)
    pause (500/1000)
    voice "voice/a61/7100030a02.opus"
    aoi "Шиничи."
    xy "Где ты была?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a61/7100040a02.opus"
    aoi "Ну..."
    xy "Зачем ты вернулась?"
    xy "Ты пришла сюда, чтобы показывать пальцем и смеяться?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a61/7100050a02.opus"
    aoi "Нет."
    xy "Тогда ПОЧЕМУ ты здесь?"
    xy "А, я понял. Ты пришла, чтобы всё исправить."
    xy "Ты ведь думаешь, что я и Миюки должны быть вместе, верно?"
    xy "И поэтому ты попытаешься вывести меня на правильный «рут» или что-то в таком роде?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a61/7100060a02.opus"
    aoi "Аой скучала по тебе."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a61/7100070a02.opus"
    aoi "Как только ты вышел на рут, другие девушки должны были отойти на второй план."
    voice "voice/a61/7100080a02.opus"
    aoi "И Аой после этого больше не должна была тебя видеть."
    voice "voice/a61/7100090a02.opus"
    aoi "Но..."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a61/7100100a02.opus"
    aoi "Аой очень сильно по тебе скучала..."

    "Этот разговор был как мёртвому припарка."
    "И всё же меня переполняла ненависть к самому себе."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a61/7100110a02.opus"
    aoi "Почему ты не идёшь на спектакль?"

    voice "voice/a61/7100120a02.opus"
    aoi "У тебя ничего не сложилось с Миюки?"

    voice "voice/a61/7100130a02.opus"
    aoi "Ты поцеловал её?"
    xy "...Нет."
    xy "Она поцелует кого-нибудь другого, но не меня."
    voice "voice/a61/7100140a02.opus"
    aoi "А ты не хочешь?"
    xy "...Я не буду говорить об этом."
    voice "voice/a61/7100150a02.opus"
    aoi "Значит, ты ХОЧЕШЬ этого."
    xy "Я сказал, не буду!"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_shy")
    with Dissolve(200.0/1000)
    voice "voice/a61/7100160a02.opus"
    aoi "Ты хочешь поцеловать её."
    xy "Заткнись!"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a61/7100170a02.opus"
    aoi "Буп-буп..."

    show expression ("cg/bg/l/"+imagename["bg060100_1_バッティングセンター店内_l"]+".jpg") as 絵背景 zorder 1000:
        pos (-1024,-400)
    hide StC with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)
    xy "...Я этого не заслуживаю."
    xy "Она явно не моего уровня."
    xy "Даже я не НАСТОЛЬКО тупой."
    voice "voice/a61/7100180a02.opus"
    aoi "Ты этого не знаешь."
    xy "Разумеется, знаю."
    voice "voice/a61/7100190a02.opus"
    aoi "Буп-буп?.."
    xy "Как долго ты ещё собираешься жить в своём мире фантазий? Это не игра. Это реальность."
    xy "Я не могу измениться. Я уже пытался."
    xy "Бог не настоящий. Чудес не бывает."
    "Мой рот двигался сам по себе, выговаривая все те слова, которые я не говорил до этого."

    xy "И твоего бога тоже нет."
    hide 絵背景
    with Dissolve(1000.0/1000)
    stop bgm fadeout (200.0/1000)
    $ sename = "se物体_バット_取る"
    play se sedict[sename]
    "Внезапно Аой взяла бейсбольную биту."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a61/7100200a02.opus"
    aoi "Давай заключим пари."
    xy "Что?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/a61/7100210a02.opus"
    aoi "Аой сейчас забьёт хоум-ран."
    show expression ("cg/bg/"+imagename["bg060200_1_バッティングセンターボックス"]+".jpg")
    hide StC with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)
    pause (300/1000)
    $ sename = "se人体_動作_バット構える01"
    play se sedict[sename]
    pause (300/1000)
    "Она прошла к месту отбивающего."
    "А потом она приняла позу отбивающего, как мы её и учили."
    voice "voice/a61/7100220a02.opus"
    aoi "И если Аой забьёт хоум-ран..."
    voice "voice/a61/7100230a02.opus"
    aoi "Ты расскажешь Миюки о своих чувствах."
    xy "Прошу прощения? Не смеши."
    voice "voice/a61/7100240a02.opus"
    aoi "Буп-буп!"
    "Она не ответила."
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    "Мяч полетел в неё, и она замахнулась битой."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((4000.0+1000.0)/1000)
    pause (1800/1000)
    stop se fadeout (200.0/1000)
    pause (200/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
