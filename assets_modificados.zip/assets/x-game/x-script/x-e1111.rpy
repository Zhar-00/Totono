label e1111_MAIN:
    call expression GameName
    $ persistent.imagelog["bg110100_1_マンションリビング"]=True
    $ PreGameName = GameName
    return
label e1111:
    hide 絵色黒
    if persistent.eternal_day:
        $ GameName = "e1181.nss"
    elif persistent.meta_sex:
        $ GameName = "e1171.nss"
    elif persistent.minus_choice and persistent.world_recreate:
        $ GameName = "e1141b.nss";
    elif persistent.miyuki_sex1 and persistent.miyuki_sex2 and persistent.world_recreate:
        $ GameName = "e1141a.nss";
    elif persistent.miyuki_decision4 and not persistent.world_recreate:
        $ GameName = "e1165c.nss";
    elif persistent.miyuki_decision3 and not persistent.world_recreate:
        $ GameName = "e1165b.nss";
    elif persistent.miyuki_decision2 and not persistent.world_recreate:
        $ GameName = "e1134c.nss";
    elif persistent.miyuki_decision and not persistent.world_recreate:
        $ GameName = "e1155i.nss";
    elif persistent.waste and not persistent.miyuki_decision:
        $ GameName = "e1155.nss";
    elif persistent.minus_choice and not persistent.world_recreate and not persistent.resist1 and not persistent.no_resist1:
        $ GameName = "e1151.nss";
    elif persistent.minus_choice and not persistent.world_recreate:
        $ GameName = "e1151a.nss";
    elif persistent.aoi_sex1 and persistent.aoi_sex2 and persistent.aoi_sex3:
        $ GameName = "e1151.nss";
        $ persistent.miyuki_noescape = True
    else:
        $ GameName = "e1111a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
