label a5113_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5121.nss"
    return
label a5113:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg")
    stop bgm fadeout (500.0/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (200/1000)
    with Dissolve(500.0/1000)
    pause (500/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a51/1300010b01.opus"
    xtl "Ах!.. Только заговорили об ангеле, и она уже тут как тут—"
    voice "voice/a51/1300020a01.opus"
    mx "Шиничи!"
    voice "voice/a51/1300030b01.opus"
    xtl "...А?"
    voice "voice/a51/1300040a01.opus"
    mx "Ау? Шиничи? Слышишь меня?"
    xy "......Чего тебе надо?"
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    "В обычной ситуации Миюки улыбалась всякий раз, когда входила в класс, но сегодня у неё было каменное выражение лица..."
    "...и она заговорила со мной, абсолютным неудачником."
    "Внезапно в классе повисла странная тишина."
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    with Dissolve(200.0/1000)
    voice "voice/a51/1300050a01.opus"
    mx "Мне надо отвлечь тебя на пару минут."
    xy "Что? И куда мы пойдём?"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a51/1300060a01.opus"
    mx "Просто иди за мной!"
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Не желая принимать «нет» за ответ, Миюки силой потащила меня за собой."
    show expression ("cg/bg/"+imagename["bg010700_1_学校廊下"]+".jpg")
    with Dissolve(500.0/1000)
    "Я нерешительно выбежал за ней из комнаты, пытаясь игнорировать других учеников, которые смотрели на нас с любопытством."
    voice "voice/a51/1300070b01.opus"
    xtl "Предатель... Предатель... Предательский блюз..."
    voice "voice/a51/1300080b01.opus"
    xtl "Ду-ду-ду... ду-ду-ду-ду... ду-ду-ду-ду..."
    "Заунывная песня Ютаро раздавалась эхом по всему коридору."
    "О боже, теперь весь класс точно начнёт распространять слухи обо мне..."
    "Это уже настоящая преисподняя..."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
