label a0113u_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if persistent.aoi_true == True or persistent.miyuki_true == True:
        $ GameName = "f1111.nss"
    else:
        if persistent.c_route == True:
            $ GameName = "e0113.nss"
        else:
            $ GameName = "a0113.nss"
    return
label a0113u:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    $ sename = "se物体_携帯_発信待機L"
    play se sedict[sename]
    pause (3000/1000)
    $ sename = "se物体_携帯_繋がる"
    play se sedict[sename]
    pause (1000/1000)
    if input_number == "707078181" and preferences.language == None:
        python:
            from random import randrange
            i = randrange(0,3)
        if i == 0:
            bm "Привет, это я, Лао-цзы, бог воодушевления. Кто из вас, шутников, призвал меня?"
            bm "Верите или нет, но Лао-цзы разбомбит ваш почтовый ящик в два счёта. Вы этого хотите?"
            xy "Это было страшно..."
        elif i == 1:
            bm "Добро пожаловать в немецкую ортопедическую больницу!"
            bm "Эта больница специализируется на строгом сестринском контроле! И у нас хорошая репутация!"
            xy "Странно всё это."
        elif i == 2:
            bm "Курортный центр Острова лоли приветствует вас!"
            bm "На данный момент времени на острове есть две лоли, *jj и o*r*n! А ещё там есть один гей по имени I*em*ple, который наслаждается жизнью!"
            xy "Как по мне, эта идея весьма заманчивая."
    else:
        xy "......Что за?"
        "Я ошибся номером?"
        "Нет, стоп... Даже если я и ошибся, в этом по-прежнему нет никакого смысла."
        "Всякий раз, когда возникает проблема во время соединения, ты обычно слышишь сообщение от автоответчика, верно?"
        "Такое чувство, будто этот телефон сломан или ещё что..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
