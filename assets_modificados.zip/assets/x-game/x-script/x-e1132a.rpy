label e1132a_MAIN:
    call expression GameName
    $ persistent.imagelog["bg110100_2_マンションリビング"]=True
    $ PreGameName = GameName
    $ GameName = "e1133.nss"
    return
label e1132a:
    scene expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg") behind 絵色黒
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)

    xy "\"Я лупфу тепфя...\""
    voice "voice/e11/32a00010a01.opus"
    mx "\"Спасибо.\""

    "Холодное металлическое лезвие отошло от моей шеи."
    hide 絵色黒
    with Dissolve(200.0/1000)
    pause (100/1000)
    hide 絵色白
    with Dissolve(1000.0/1000)
    pause (300/1000)
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_happy")

    "Потом она сняла полотенце с моего лица, и моё зрение вернулось."

    "Следующее, что я увидел - то, как Миюки улыбалась."

    "Я рад, что сказал ей о своих чувствах. Её счастье того стоило."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
