label e2320a_MAIN:
    call expression GameName
    $ persistent.e2320a_Pass = True;
    $ PreGameName = GameName
    $ GameName = "e2321.nss"
    return
label e2320a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)

    "Я не настолько отчаялся... и всё же..."

    "По какой-то причине, моё тело начало двигаться по своей воле..."

    "Я коснулся экрана."
    if (not persistent.e2320a_Pass):
        $ renpy.pause(delay=.5)

    "—Пожалуйста, ответьте на следующие 10 вопросов с несколькими вариантами ответа."

    "—Внимание: 3 неудачные попытки приведут к автоматической блокировке на 24 часа."



    "...Звучит так, будто я могу ошибиться лишь дважды."

    "Внимательно прочитав инструкции, я перешёл к рассмотрению вопросов."


    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
