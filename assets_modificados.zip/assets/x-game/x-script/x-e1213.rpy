label e1213_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1213:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    show expression Solid("000000") as 絵演色黒
    hide 絵演色黒
    with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(0.0/1000))
    $ st_timezone = "昼"
    voice "voice/e12/1300010a01.opus"

    mx "\"Всё развлекаешься?\""

    xy "\"Воу!\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_sigh")
    with Dissolve(200.0/1000)

    "Я внезапно услышал голос позади себя и чуть было не выскочил из собственной шкуры."

    xy "\"Не пугай меня так!\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/e12/1300020a01.opus"

    mx "\"Ого, я показалась очень невежливой?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e12/1300030a01.opus"

    mx "\"И всё же я позволила тебе одолжить мой телефон, чтобы ты мог провести немного времени с Аой.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e12/1300040a01.opus"

    mx "\"А, я поняла... Ты сейчас был в середине сцены секса или что-то в таком духе?\""

    xy "\"Н-нет! Конечно же нет!\""
    voice "voice/e12/1300050a01.opus"

    mx "\"Ты уверен насчёт этого?\""

    xy "\"......Н-нгх...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e12/1300060a01.opus"

    mx "\"Ну да ладно. Сегодня я ещё позволю тебе легко отделаться.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e12/1300070a01.opus"

    mx "\"Но теперь ты понимаешь, верно?\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e12/1300080a01.opus"

    mx "\"Аой - просто героиня в визуальной новелле. Её не существует.\""

    "...С чего это она вдруг взяла?"

    xy "\"Ну, да, разумеется!\""
    voice "voice/e12/1300090a01.opus"

    mx "\"Хорошо.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e12/1300100a01.opus"

    mx "\"Я доверяю ТЕБЕ.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Она улыбнулась и похлопала меня по плечу."
    $ persistent.aoi_sex1 = True
    $ temp_aoi_unreal = True
    $ GameName = "e3111.nss";
    pause (16/1000)
    scene expression "cg/bg/black.jpg" zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
