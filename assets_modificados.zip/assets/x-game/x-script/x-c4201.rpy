label c4201_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if yutaro_help == True:
        $ GameName = "c4202.nss"
    else:
        $ GameName = "d4202.nss"
    return
label c4201:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg060100_3_バッティングセンター店内"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    $ sename = "se人体_動作_バッティング02"
    play se sedict[sename]
    pause (800/1000)
    "Форма Миюки была такой же прекрасной, что и всегда."
    "Бейсбольный мяч взлетел и попал прямо в сетку."
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/c42/0100010a01.opus"
    mx "\"Хочешь попробовать?\""
    xy "\"Я пас.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/c42/0100020a01.opus"
    mx "\"Тебе никогда не надоест просто смотреть?\""
    xy "\"Да нет. А ты, судя по всему, не устанешь вечно махать битой.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/c42/0100030a01.opus"
    mx "\"Конечно же нет. Мне это очень нравится.\""
    hide StC with Dissolve(200.0/1000)
    $ sename = "se人体_動作_バット構える01"
    play se sedict[sename]
    voice "voice/c42/0100040a01.opus"
    mx "\"Мне нравится, когда я стою здесь, сосредоточив свой взгляд на мяче...\""
    $ sename = "se人体_動作_バット構える02"
    play se sedict[sename]
    pause (1000/1000)
    $ sename = "se人体_動作_バットスイング01"
    play se sedict[sename]
    pause (200/1000)
    $ sename = "se人体_動作_バッティング02"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白打
    show expression ("cg/ev/l/"+imagename["eva1211美雪バッティングa_l"]+".jpg") as 絵専上:
        pos (-1024,-30)
        linear .5 pos (-210,-30)
    with Dissolve((500.0+1000.0)/1000)
    with Dissolve((1000.0+0.0)/1000)
    voice "voice/c42/0100050a01.opus"
    mx "\"А потом делаю замах!\""
    voice "voice/c42/0100060a01.opus"
    mx "\"Без актёрской игры, без вранья...\""
    voice "voice/c42/0100070a01.opus"
    mx "\"Мне не нужно думать... я могу просто быть собой. Своей первичной личностью.\""
    show expression ("cg/ev/"+imagename["eva1211美雪バッティングa"]+".jpg") as 絵専 at truecenter with Dissolve(.5)
    hide 絵専上 with Dissolve(.5)
    "Мне почему-то кажется, что я знаю, к чему она клонит."
    "Миюки махала своей битой так, будто она была свободна от проблем всего мира."
    $ renpy.music.play("ttb13",channel = "bgm", if_changed = True)
    show expression ("cg/ev/l/"+imagename["eva1211美雪バッティングa_l"]+".jpg") as 絵専上:
        pos (-900,-167)
        linear 50 pos (-210,-167)
    with Dissolve((2000.0+1000.0)/1000)
    $ sename = "se人体_動作_バッティング02"
    play se sedict[sename]
    with Dissolve((0.0+1000.0)/1000)
    pause (150/1000)
    with Dissolve((1000.0+0.0)/1000)
    pause (500/1000)
    voice "voice/c42/0100080a01.opus"
    mx "\"Теперь, когда она ушла...\""
    voice "voice/c42/0100090a01.opus"
    mx "\"Когда она где-то далеко...\""
    voice "voice/c42/0100100a01.opus"
    mx "\"И когда я начала по ней скучать...\""
    voice "voice/c42/0100110a01.opus"
    mx "\"Я наконец-то поняла.\""
    $ sename = "se人体_動作_バッティング02"
    play se sedict[sename]
    with Dissolve((0.0+1000.0)/1000)
    pause (150/1000)
    with Dissolve((1000.0+0.0)/1000)
    pause (500/1000)
    voice "voice/c42/0100120a01.opus"
    mx "\"Я буду предельно честной.\""
    voice "voice/c42/0100130a01.opus"
    mx "\"Я всегда ненавидела Аой.\""
    $ sename = "se人体_動作_バッティング02"
    play se sedict[sename]
    with Dissolve((0.0+1000.0)/1000)
    pause (150/1000)
    with Dissolve((1000.0+0.0)/1000)
    pause (500/1000)
    voice "voice/c42/0100140a01.opus"
    mx "\"Я хотела, чтобы она ушла.\""
    $ sename = "se人体_動作_バッティング02"
    play se sedict[sename]
    with Dissolve((0.0+1000.0)/1000)
    pause (150/1000)
    with Dissolve((1000.0+0.0)/1000)
    pause (500/1000)
    voice "voice/c42/0100150a01.opus"
    mx "\"Я не хотела быть рядом с ней.\""
    voice "voice/c42/0100160a01.opus"
    mx "\"Но в то же время, я не могла заткнуть её.\""
    voice "voice/c42/0100170a01.opus"
    mx "\"Где-то в глубине души... я хотела БЫТЬ ею.\""
    voice "voice/c42/0100180a01.opus"
    mx "\"Она была честна с другими, и честна с самой собой, и она всегда защищала то, во что верила.\""
    voice "voice/c42/0100190a01.opus"
    mx "\"И мне это нравилось в ней.\""
    $ sename = "se人体_動作_バッティング02"
    play se sedict[sename]
    with Dissolve((0.0+1000.0)/1000)
    pause (150/1000)
    with Dissolve((1000.0+0.0)/1000)
    hide 絵色白打
    pause (500/1000)
    voice "voice/c42/0100200a01.opus"
    mx "\"И поэтому я решила...\""
    voice "voice/c42/0100210a01.opus"
    mx "\"Наверное, я могла быть такой.\""
    voice "voice/c42/0100220a01.opus"
    mx "\"Наверное, я могла бы научиться быть такой, как она; перестать зацикливаться и начать смотреть своим страхам в лицо.\""
    stop bgm fadeout (500/1000)
    $ sename = "se物体_バット_転がる"
    play se sedict[sename]
    hide 絵専
    hide 絵専上 with Dissolve(.5)
    pause (500/1000)
    voice "voice/c42/0100230a01.opus"
    mx "\"И теперь... Шиничи...\""
    "Она повернулась ко мне лицом. Над бейсбольным полем повисла мёртвая тишина."
    scene expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15 at truecenter:
        ypos 258
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(1000.0/1000)
    "Всё вдруг замерло."
    "Я был прикован к месту так, будто она держала меня за душу."
    $ renpy.music.play("ttb12",channel = "bgm", if_changed = True)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c42/0100240a01.opus"
    mx "\"Ты выслушаешь меня?\""
    "Я понял."
    "Я понял, почему Миюки завидовала такой упрямой и бескомпромиссной девушке, как Аой."
    "И теперь, когда Аой изменила её, я знаю, что она собиралась сказать."
    "Она боялась причинить кому-нибудь вред... и боялась пострадать сама."
    "И поэтому она подавляла свои чувства все эти годы."
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c42/0100250a01.opus"
    mx "\"Я хочу, чтобы ты знал...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/c42/0100260a01.opus"
    mx "\"Что я—\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
