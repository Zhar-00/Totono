label a0113_MAIN:
    call expression GameName
    $ persistent.imagelog["eva0113アオイ屋上覆い被さりa"]=True
    $ persistent.imagelog["eva0113アオイ送信中e"]=True
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label a0113:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    "Я решил проверить историю вызовов."
    "«Бог»."
    "«Бог»."
    "«Бог»."
    "«Бог»."
    "...Какого чёрта?"
    "Далее я решил проверить список контактов."
    "Здесь была всего одна запись."
    "И да, вы угадали. «Бог»."
    "...Одноразовый телефон для Бога?"
    "Он ведь ЯВНО не принадлежит тому большому человеку на небесах, верно?"
    xy "...Хм?"
    show expression ("cg/ef/"+imagename["efgaゲーム画面ロード"]+".jpg") as 絵場面推移 at center
    with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1.5)
    pause 1
    image 絵効果 = im.MatrixColor(("cg/ef/"+imagename["effiテレビ画面用効果フィルター"]+".jpg"),im.matrix.invert())
    show 絵効果 behind 絵場面推移:
        alpha 0.2
    show expression ("cg/ev/"+imagename["eva0113アオイ屋上覆い被さりa"]+".jpg") as 絵専 behind 絵場面推移, 絵効果 at center
    hide 絵場面推移 with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1)
    voice "voice/a01/1300010a02.opus"
    voice "voice/a01/1300010a02.opus"
    bm "Буп-буп..."
    xy "......"
    show expression ("cg/ev/l/"+imagename["eva0113アオイ屋上覆い被さりa_l"]+".jpg") as 絵専上 behind 絵効果 with Dissolve(1.8):
        pos (-285,-120)
        linear 7 pos (-332,-156)
    "Девушка смотрела на меня."
    voice "voice/a01/1300020a02.opus"
    bm "У меня батарейка села."
    xy "Какая ещё батарейка?.."
    voice "voice/a01/1300030a02.opus"
    bm "Мне нужна перезарядка."
    show expression ("cg/ev/l/"+imagename["eva0113アオイ屋上覆い被さりa_l"]+".jpg") as 絵専上二 behind 絵効果 with Dissolve(1.8):
        zoom 1.5
        align (0.3,0.3)
        pos (512-181, 288-54)
        linear 7 pos (512-228, 288-90)
    voice "voice/a01/1300040a02.opus"
    bm "Не хочешь... подзарядиться?"
    hide 絵専
    hide 絵効果
    hide 絵専上
    show expression ("cg/ef/"+imagename["efgaゲーム画面ロード"]+".jpg") as 絵場面推移 at center
    with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1.5)
    pause 1
    hide 絵専上二 with None
    hide 絵場面推移 with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1)
    "Кажется, я случайно нажал не на ту кнопку."
    "Похоже, я запустил одну из тех «визуальных новелл»."
    "Я видел, как некоторые мои друзья играли в них на портативных консолях."
    "Я бы не удивился, если они портировали их и на телефоны тоже."
    "Я никогда не играл в них."
    "По крайней мере... я сомневаюсь в этом..."
    "Но мне кажется, я узнаю эту форму..."
    xy "Я тебя знаю?.."
    voice "voice/a01/1300050a02.opus"
    bm "Буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп..."
    "Я слышал странный голос."
    $ renpy.music.play("ttb01",channel = "bgm", if_changed = True,fadein = .8)
    show expression ("cg/ev/l/"+imagename["eva0113アオイ送信中e_l"]+".jpg") as 絵専 zorder 1105 at center with Dissolve(1.8):
        yanchor 0
        ypos -576
        linear 3 ypos -270
    show expression ("cg/ev/"+imagename["eva0113アオイ送信中e"]+".jpg") as 絵専下 behind 絵専 zorder 1100 at center
    voice "voice/a01/1300060a02.opus"
    bm "Буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп..."
    "Девушка стояла на крыше."
    "Её рука была поднята вверх."
    "А выражение её лица было абсолютно пустым."
    hide 絵専 with Dissolve(1000/1000)
    "Она просто бездумно смотрела в небо..."
    "Глядя на всё то, что было за горизонтом..."
    voice "voice/a01/1300070a02.opus"
    bm "Буп-буп... буп-буп-буп... буп-буп... буп..."
    xy "А?.."
    show expression ("cg/ev/l/"+imagename["eva0113アオイ送信中e_l"]+".jpg") as 絵専 zorder 1100 at center:
        pos (-430,-360)
        linear 8 ypos -300
    "Её тело начало качаться."
    "А голос постепенно затихал..."
    voice "voice/a01/1300080a02.opus"
    bm "Буп... буп... буп... б..."
    voice "voice/a01/1300090a02.opus"
    bm "Буп-буп..."
    show expression Solid("000000") as 絵色黒 zorder 5000
    hide 絵専
    hide 絵専上
    hide 絵専下
    $ renpy.music.set_volume(0,channel="bgm")
    xy "Воу—!"
    $ sename = "se人体_衝撃_転倒複数"
    play se sedict[sename]
    pause 1
    xy "Гх-х... Ай..."
    xy "Т-ты в порядке?"
    show expression ("cg/ev/"+imagename["eva0113アオイ屋上覆い被さりa"]+".jpg") as 絵専 at center
    hide 絵色黒 with Dissolve(1000/1000)
    $ renpy.music.set_volume(.8,channel="bgm")
    voice "voice/a01/1300100a02.opus"
    bm "Буп-буп..."
    xy "......"
    show expression ("cg/ev/l/"+imagename["eva0113アオイ屋上覆い被さりa_l"]+".jpg") as 絵専上 with Dissolve(1.8):
        pos (-285,-120)
        linear 7 pos (-332,-156)
    "Её взгляд был прикован ко мне."
    voice "voice/a01/1300110a02.opus"
    bm "У меня батарейка села."
    xy "Какая ещё батарейка?.."
    voice "voice/a01/1300120a02.opus"
    bm "Мне нужна перезарядка."
    show expression ("cg/ev/l/"+imagename["eva0113アオイ屋上覆い被さりa_l"]+".jpg") as 絵専上二 with Dissolve(1.8):
        zoom 1.5
        align (0.3,0.3)
        pos (512-181, 288-54)
        linear 7 pos (512-228, 288-90)
    "Её лицо было близко к моему."
    "Я мог почувствовать её дыхание."
    "Она раскрыла губы."
    "Согласно школьной легенде..."
    show expression Solid("000000") as 絵色黒 with Dissolve(1.4)
    "...Если два человека поцелуются на крыше, их любовь будет вечной."
    hide 絵色黒 with Dissolve(1000/1000)
    voice "voice/a01/1300130a02.opus"
    bm "Не хочешь... подзарядиться?"
    return
label a0113_SELECT:
    $ renpy.save("lastsel")
    $ renpy.music.play("ttb01",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    show expression ("cg/ev/l/"+imagename["eva0113アオイ屋上覆い被さりa_l"]+".jpg") as 絵専上二 with Dissolve(1.8):
        zoom 1.5
        align (0.3,0.3)
        pos (512-228, 288-90)
    menu:
        "Подзарядиться":
            $ SetChoiceSelect = 0
        "Не подзаряжаться":
            $ SetChoiceSelect = 1
    if SetChoiceSelect == 0:
        $ GameName = "a0114a.nss"
    elif SetChoiceSelect==1:
        $ GameName = "a0114b.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
