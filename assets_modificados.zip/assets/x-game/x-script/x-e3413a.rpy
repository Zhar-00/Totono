label e3413a_MAIN:
    call expression GameName
    $ persistent.imagelog["bg110600_3_マンション台所"]=True
    $ PreGameName = GameName
    return
label e3413a:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    $ sename = "se環境_水音_シャワーL"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg110301_3_マンション寝室消灯"]+".jpg")
    $ st_timezone = "夜"
    with Dissolve(0.0/1000)

    "Раз уж я проснулся, то я мог бы пойти поискать кота и сделать пару фотографий для Миюки!"

    "Взяв телефон в руку, я решил выйти наружу."
    show expression ("cg/bg/"+imagename["bg110600_3_マンション台所"]+".jpg")
    with Dissolve(500.0/1000)

    "Я прошёл через обеденную комнату к парадной двери—"
    voice "voice/e34/13a00010a01.opus"

    mx "\"Стоять!\""

    "Внезапно из ванной раздался голос."
    voice "voice/e34/13a00020a01.opus"

    mx "\"Шиничи...\""
    voice "voice/e34/13a00030a01.opus"

    mx "\"Куда это ты собрался?\""
    menu:
        "Я никуда не ухожу":
            $ SetChoiceSelect = 0
        "Я иду фотографировать кота":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e3414b.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e3414a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
