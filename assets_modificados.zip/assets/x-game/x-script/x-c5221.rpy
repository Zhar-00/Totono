label c5221_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c5231.nss"
    return
label c5221:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    $ sename = "se環境_ガヤ_教室ざわめくL"
    play se sedict[sename]
    with Dissolve(1500.0/1000)
    pause (500/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c52/2100010b01.opus"
    xtl "\"Доброе утро!\""

    xy "\"О, привет. Доброе.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c52/2100020b01.opus"

    xtl "\"В чём дело? Что-то не так?\""

    xy "\"Нет, дело не в этом...\""
    voice "voice/c52/2100030b01.opus"

    xtl "\"Ты ведь не поссорился с Муко или ещё что, так ведь?\""
    voice "voice/c52/2100040a02.opus"
    aoi "\"Поняла!\""
    hide StC with Dissolve(0.0/1000)
    hide 演背景
    with Dissolve(500.0/1000)

    "Я услышал голос Аой с другой стороны комнаты."

    "Я оглянулся и заметил, как она стояла среди группы девушек, собравшихся вокруг Миюки."

    "Судя по всему, они начали расценивать Аой как какого-то школьного питомца..."
    $ St("ML",300,0,0,"st向日アオイ_制服_挙手_normal")
    voice "voice/c52/2100050a02.opus"

    aoi "\"Аой знает ответ.\""
    $ St("ML",300,0,0,"st向日アオイ_制服_通常_shout")
    voice "voice/c52/2100060a02.opus"

    aoi "\"У Миюки чашечки размера F.\""
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_angry")
    voice "voice/c52/2100070a01.opus"

    mx "\"ЭЙ! Как ты узнала?!\""
    $ St("ML",300,0,0,"st向日アオイ_制服_通常_smile")
    voice "voice/c52/2100080a02.opus"

    aoi "\"Сила передатчика.\""
    hide StC
    hide StMR
    hide StML
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_smile")
    with Dissolve(500.0/1000)

    xy "\"О чём они там вообще говорят?..\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_shy")
    with Dissolve(200.0/1000)
    voice "voice/c52/2100090b01.opus"

    xtl "\"Женские штучки... Удел мечтаний!..\""
    voice "voice/c52/2100100b01.opus"

    xtl "\"И женские груди тоже наполнены надеждами и мечтами, знаешь ли!\""

    xy "\"Будь добр, заткнись навеки.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c52/2100110b01.opus"

    xtl "\"Так или иначе, я рад видеть, что Муко вернулась на занятия. Похоже, она со временем начинает всё больше вписываться в коллектив класса.\""

    xy "\"Да...\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c52/2100120b01.opus"
    xtl "......"
    voice "voice/c52/2100130b01.opus"

    xtl "\"Между вами что-то не так, ребята?\""

    xy "\"У нас всё в порядке.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c52/2100140b01.opus"
    xtl "\"Да разве?\""

    xy "\"...Чего ты от меня хочешь?\""

    "Я почувствовал, как мой голос поднялся на октаву."

    xy "\"Ты хочешь мне что-то сказать? Так скажи это мне в лицо.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c52/2100150b01.opus"

    xtl "\"Ну... просто... мне доводилось слышать кое-какие слухи о том, что, эм... Муко спит с кем попало...\""
    stop bgm fadeout (150/1000)
    stop se fadeout (150.0/1000)
    $ sename = "se人体_衝撃_叩く机02"
    play se sedict[sename]

    xy "\"ЭТО ПРОСТО СЛУХИ!\""
    hide StC with Dissolve(0.0/1000)
    hide 演背景
    with Dissolve(500.0/1000)
    pause (1000/1000)

    "Мой голос раздался эхом по всему классу."

    "Я тут же почувствовал, как все начали смотреть на меня."
    pause (1000/1000)
    $ St("C",300,0,0,"st向日アオイ_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c52/2100160a02.opus"
    aoi "\"Шиничи?..\""

    "Аой посмотрела на меня, но я махнул рукой, дабы избавить себя от её беспокойства."

    "Я собрался с силами, чтобы успокоиться, после чего развернулся обратно к Ютаро."
    hide StC
    hide StMR
    hide StML
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(500.0/1000)

    xy "\"...Прости, что так закричал.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c52/2100170b01.opus"

    xtl "\"Да не, это я виноват. Прости.\""

    "Если я правда доверяю Аой, то я не стал бы вообще кричать из-за этого..."

    "...и от осознания этого мне было очень больно."
    stop se fadeout (1000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
