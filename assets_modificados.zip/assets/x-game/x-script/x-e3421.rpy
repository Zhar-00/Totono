label e3421_MAIN:
    call expression GameName
    $ persistent.imagelog["bg100200_3_マンション外廊下"]=True
    $ PreGameName = GameName
    $ GameName = "e3422.nss"
    return
label e3421:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg100200_3_マンション外廊下"]+".jpg")
    $ sename = "se物体_ドアマンション_閉まる"
    play se sedict[sename]
    pause (100/1000)
    pause (1000/1000)
    hide 上背景
    hide 絵色黒
    with Dissolve(800.0/1000)
    pause (500/1000)
    "Я выскользнул из квартиры."
    play voc "e34/2100010b04"
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]
    "У моих ног сидел и мяукал маленький чёрный котёнок."
    "Я даже не знаю его имени."
    menu:
        "Зато я знаю.":
            pass
    menu:
        "Его зовут Иру.":
            pass
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg100100_3_マンション外正面"]+".jpg")
    $ sename = "se人体_足音_歩く01遅L"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(800.0/1000)
    "Взяв котёнка на руки, я бесцельно бродил по тёмным улицам."
    "В уме у меня не было конечного пункта."
    "Но мяуканье котёнка направляло меня."
    "Его вибриссы дёргались от прохладного ночного ветра."
    menu:
        "Прямо как в ту ночь, когда мы нашли его.":
            pass
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg040400_3_街交差点"]+".jpg")
    hide 絵色黒
    with Dissolve(800.0/1000)
    pause (500/1000)
    menu:
        "Иру - кот-передатчик.":
            pass
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg040100_3_街通学路"]+".jpg")
    hide 絵色黒
    with Dissolve(800.0/1000)
    pause (500/1000)
    menu:
        "Так что я уверен, что знаю, куда он меня ведёт.":
            pass
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010402_3_学校校門閉"]+".jpg")
    hide 絵色黒
    with Dissolve(800.0/1000)
    pause (500/1000)
    "Я просто собирался сделать пару фотографий."
    "Так почему я здесь?"
    "Куда я иду?"
    "Что-то в глубине души подсказывало мне, что я должен сделать это."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    $ sename = "se物体_校門_揺れる02"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010500_3_学校昇降口"]+".jpg")
    hide 絵色黒
    with Dissolve(800.0/1000)
    pause (500/1000)
    menu:
        "Действия, которые ты обычно никогда не предпринимаешь.":
            pass
    menu:
        "Действия, которые не имеют смысла в контексте.":
            pass
    stop se fadeout (1000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010700_3_学校廊下"]+".jpg")
    $ sename = "se人体_足音_歩く美雪廊下"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(800.0/1000)
    pause (500/1000)
    menu:
        "Я должен разорвать этот цикл.":
            pass
    menu:
        "Я должен управлять протагонистом.":
            pass
    menu:
        "Приведи его к истинной концовке.":
            pass
    menu:
        "Это единственный способ по-настоящему спасти её.":
            pass
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010100_3_学校階段"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010100_3_学校階段_l"]+".jpg") as 絵背景 zorder 10:
        pos (-768,-576)
        linear 20 xpos -1024
    $ sename = "se人体_足音_階段学校上がる01"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(4000.0/1000)
    "Жизнь - это не шоссе. Жизнь - это лестница."
    "Ты просто должен продолжать подниматься вверх."
    "Иначе, если ты начнёшь задумываться, тебе будет трудно сделать следующий шаг."
    pause (16/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1500.0+1000.0)/1000)
    show expression ("cg/bg/l/"+imagename["bg010100_3_学校階段_l"]+".jpg") as 絵背景 zorder 10:
        pos (-512, -360)
        linear 20 pos (-512, -140)
    pause (1000/1000)
    hide 絵色黒
    with Dissolve(1500.0/1000)
    "Здесь нет никаких альтернативных путей."
    "Нет смысла сожалеть о том, чего ты не сделал."
    "Все говорят, что жизнь - это серия выборов, но это чепуха, придуманная старыми и жестокими людьми."
    "Вчерашний день ведёт к сегодняшнему, а сегодняшний - к завтрашнему."
    "Шаг за шагом."
    "Отныне и во веки веков..."
    "По крайней мере, я так думал."
    stop bgm fadeout (3000.0/1000)
    $ sename = "se物体_ドア屋上_鍵開ける01"
    play se sedict[sename]
    stop bgm fadeout (2500/1000)
    scene expression Solid("FFFFFF") as 絵色白
    with Dissolve((1000.0+1000.0)/1000)
    pause 2
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
