label e2153_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2153:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010400_2_学校校門"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/5300010a01.opus"

    mx "\"Ты знаешь... очень мило, что мы идём домой только вдвоём.\""
    voice "voice/e21/5300020a01.opus"

    mx "\"Можешь себе представить, что случилось бы, если бы кто-нибудь попытался помешать нам? Тебя такое разозлило бы?\""
    if persistent.eternal_day:
        $ GameName = "e2154a.nss";
    else:
        menu:
            "Определённо":
                $ SetChoiceSelect = 0
            "Не совсем":
                $ SetChoiceSelect = 1
        if SetChoiceSelect==0:
            $ persistent.miyuki_love += 1
            $ GameName = "e2154a.nss";
        elif SetChoiceSelect==1:
            $ persistent.miyuki_love -= 1
            $ GameName = "e2154b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
