label e2237g_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ temp_miyuki_sex2 = True;
    $ persistent.miyuki_sex2 = True;
    python:
        if persistent.passed_miyuki_sex2_month == None or persistent.passed_miyuki_sex2_day == None:
            from time import strftime, localtime
            persistent.passed_miyuki_sex2_month = int(strftime("%m",localtime()))
            persistent.passed_miyuki_sex2_day = int(strftime("%d",localtime()))
            persistent.DIARY_COUNT += 1
    $ bukkake = False ;
    $ persistent.count_e2237g +=1;
    if (persistent.count_e2237g > 1):
        $ GameName = "e2237i.nss";
    else:
        $ GameName = "e2237h.nss";
    return
label e2237g:
    hide 絵色黒
    call eroute_bgm
    scene expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)

    "Я показал на её трусики, которые уже были насквозь мокрыми от наших жидкостей."
    voice "voice/e22/37g00010a01.opus"

    mx "\"А? ...Ох... э-э-эм...\""
    voice "voice/e22/37g00020a01.opus"

    mx "\"Ч-что же нам делать?..\""

    "Должна ли она походить без нижнего белья до конца этого дня?.."

    "...Нет, это слишком рискованно."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
