label d4223_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d4233.nss"
    return
label d4223:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")
    show expression ("cg/ev/"+imagename["evc4221アオイ眠り姫b"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)

    xy "\"Не смеши. Ты забыла о том, что когда я тебя только нашёл, ты не дышала?\""
    $ sename = "se人体_動作_ポケット探る"
    play se sedict[sename]

    "Я быстро достал свой телефон."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
