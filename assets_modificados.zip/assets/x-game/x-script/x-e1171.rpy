label e1171_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2000.nss"
    return
label e1171:
    hide 絵色黒
    call eroute_bgm
    scene expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/7100010a01.opus"

    mx "\"Доброе утро.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
    voice "voice/e11/7100020a01.opus"

    mx "\"...Да.\""
    voice "voice/e11/7100030a01.opus"

    mx "\"Я здесь счастлива.\""
    voice "voice/e11/7100040a01.opus"

    mx "\"Я буду всегда верить в ТЕБЯ, ладно?\""
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
