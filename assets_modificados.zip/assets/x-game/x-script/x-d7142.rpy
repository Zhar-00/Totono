label d7142_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a7231.nss"
    return
label d7142:
    hide 絵色黒
    $ renpy.music.play("ttb24",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    if PreGameName == "d7111":
        $ St("C",300,0,0,"st曽根美雪_制服_病み_sad")
    else:
        $ St("C",300,0,0,"st曽根美雪_私服_病み_sad")
    with Dissolve(0.0/1000)
    if PreGameName == "d7111":
        $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    else:
        $ St("C",300,0,0,"st曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/d71/4200010a01.opus"

    mx "\"Тебе уже лучше?\""
    xy "\"......\""

    xy "\"...Мне так больно...\""

    xy "\"Я ни за что не смогу чувствовать себя лучше из-за всего этого!..\""
    if PreGameName == "d7111":
        $ St("C",300,0,0,"st曽根美雪_制服_病み_sad")
    else:
        $ St("C",300,0,0,"st曽根美雪_私服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/d71/4200020a01.opus"

    mx "\"Да... скорее всего, не сможешь.\""

    xy "\"Это был мой единственный выбор...\""

    xy "\"Всё уже никогда не будет по-другому...\""

    xy "\"Я ведь прав, Миюки? Пожалуйста, скажи мне, что я прав...\""
    voice "voice/d71/4200030a01.opus"

    mx "\"Никто не винит тебя в том, что случилось.\""
    voice "voice/d71/4200040a01.opus"

    mx "\"Так или иначе, это всё равно должно было случиться.\""
    if PreGameName == "d7111":
        $ St("C",300,0,0,"st曽根美雪_制服_恋人_smile")
    else:
        $ St("C",300,0,0,"st曽根美雪_私服_恋人_smile")
    with Dissolve(300.0/1000)
    pause (1000/1000)
    voice "voice/d71/4200050a01.opus"

    mx "\"Это твоя судьба.\""

    xy "\"Что?\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    if PreGameName == "d7111":
        $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
    else:
        $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/d71/4200060a01.opus"

    mx "\"Ты слышал меня. Судьба.\""
    if PreGameName == "d7111":
        $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    else:
        $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/d71/4200070a01.opus"

    mx "\"И любовь...\""
    if PreGameName == "d7111":
        $ St("C",300,0,0,"bu曽根美雪_制服_恋人_ero")
    else:
        $ St("C",300,0,0,"bu曽根美雪_私服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/d71/4200080a01.opus"

    mx "\"...вечна.\""
    $ sename = "se人体_動作_立ち上がる"
    play se sedict[sename]
    $ sename = "se人体_動作_衣擦れ02"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(400.0/1000)
    pause (1000/1000)

    "Её шёпот подавил все мои страдания."

    "Её голос нежно проник в мою голову, и мой разум в миг опустел."

    "Её волосы тёрлись об меня."

    "Она обнимала меня своими мягкими руками."

    "Я мог почувствовать её аромат."

    "Сейчас я хотел просто остаться здесь, в этих объятиях, и забыть обо всём..."

    "На веки вечные..."
    stop bgm fadeout (4000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    $ EyeCatchIn(0.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
