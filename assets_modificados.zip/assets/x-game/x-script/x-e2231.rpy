label e2231_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ roof = True;
    return
label e2231:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ tz(1)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/3100010a01.opus"
    mx "\"Эй, Шиничи?\""
    voice "voice/e22/3100020a01.opus"
    mx "\"Можешь помочь мне убрать эту парту?\""
    show expression ("cg/ev/"+imagename["eva1111アオイ受信中c"]+".jpg") as 絵専 zorder 900 at center
    with Dissolve((1000.0+1000.0)/1000)
    pause (500/1000)
    "Находясь в классе, Миюки внезапно обратилась ко мне."
    "Она показала на парту, стоявшую в углу комнаты."
    "Если подумать, она давно никем не использовалась..."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    hide 絵専
    with Dissolve(500.0/1000)
    voice "voice/e22/3100030a01.opus"

    mx "\"Ты ведь состоишь в комитете по уборке, верно? Пожалуйста?\""
    xy "\"Ладно.\""
    "Всё-таки я не могу отказать президенту класса."
    voice "voice/e22/3100040a01.opus"
    mx "\"Ты неси это, а я понесу вот это.\""
    xy "\"Спасибо.\""
    hide StC with Dissolve(200.0/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010700_1_学校廊下"]+".jpg")
    with Dissolve((500.0)/1000)
    "Она схватилась за стул, и мы вместе потащили стол в коридор."
    "Наш пункт назначения: крыша."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010100_1_学校階段"]+".jpg")
    pause (500/1000)
    xy "\"Ха-а... ха-а... н-н-нг!\""
    xy "\"Н-нгха... Фух...\""
    xy "\"Мы сделали это!..\""
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    $ roof = True;
    show expression Solid("FFFFFF") as 絵色白
    $ sename = "se物体_ドア鉄_開く01"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(500.0/1000)
    pause (500/1000)
    hide 絵色白
    with Dissolve(1000.0/1000)
    pause (800/1000)
    $ sename = "se物体_机_置く"
    play se sedict[sename]
    "Как только мы наконец-то пронесли его через всю лестничную клетку, я поставил парту на крыше."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/3100050a01.opus"
    mx "\"Отличная работа.\""
    "Миюки поставила стул рядом с ней."
    "Здесь была целая куча неиспользуемых парт."
    "Некоторые из них уже проржавели от воздействия стихии."
    voice "voice/e22/3100060a01.opus"
    mx "\"Думаю, эта парта теперь не хуже мусора.\""
    if persistent.eternal_day:
        $ GameName = "e2232a.nss";
    else:
        menu:
            "Согласен":
                $ SetChoiceSelect = 0
            "Не согласен":
                $ SetChoiceSelect = 1
        if SetChoiceSelect==0:
            $ persistent.miyuki_love += 1
            $ GameName = "e2232a.nss";
        elif SetChoiceSelect==1:
            $ persistent.miyuki_love -= 1
            $ GameName = "e2232b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
