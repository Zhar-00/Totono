label e2324f_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2324g.nss"
    return
label e2324f:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    stop bgm fadeout (0.0/1000)
    "Прошло уже 20 лет с тех пор, как я бывал в последний раз в своём родном городе."
    "И с тех пор это место ничуть не изменилось."
    "Как будто время остановилось для меня одного."
    "Я начал идти быстрее."
    "Я был отшельником уже много-много лет."
    "Я не привык к тому, что другие люди смотрели на меня."
    "Такое чувство, будто они пялились."
    "Но опять же... Может, они и правда пялились."
    "Держу пари, что мне не рады в этом городе."
    show expression ("cg/bg/"+imagename["bg080100_2_コンビニ外正面"]+".jpg")
    with Dissolve((500.0)/1000)
    "На какое-то мгновение я подумал о том, чтобы заглянуть в магазин за углом... но потом я остановился."
    "За стойкой на кассе стояла и работала одна счастливая пара."
    "И один из них выглядел довольно старым..."
    xy "\"...Где-то рядом должен стоять торговый автомат, разве нет?\""
    show expression ("cg/bg/"+imagename["bg010400_2_学校校門"]+".jpg")
    with Dissolve((500.0)/1000)
    "Сегодня был выходной."
    "Корпус был открыт для клубных мероприятий, но, к счастью, здесь было не так много людей."
    "Мне незачем выглядывать из-за угла; я просто зайду туда."
    show expression ("cg/bg/"+imagename["bg010500_2_学校昇降口"]+".jpg")
    with Dissolve((500.0)/1000)
    pause (200/1000)
    show expression ("cg/bg/"+imagename["bg010700_2_学校廊下"]+".jpg")
    with Dissolve((500.0)/1000)
    pause (200/1000)
    show expression ("cg/bg/"+imagename["bg010100_2_学校階段"]+".jpg")
    with Dissolve((500.0)/1000)
    pause (200/1000)
    $ sename = "se物体_ドア屋上_鍵開ける01"
    play se sedict[sename]
    "Я предположил, что мне придётся сломать замок, но как выяснилось, они всё ещё используют тот же самый замок, что и тогда."
    $ sename = "se物体_ドア鉄_回す"
    play se sedict[sename]
    "Я осторожно нажал на старую ржавую дверь."
    with Dissolve((0.0+1000.0)/1000)
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    pause (500/1000)
    hide 絵色白
    with Dissolve(1500.0/1000)
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/e23/24f00010a02.opus"
    aoi "\"Буп-буп?.. Шиничи?\""
    $ St("MR",300,15,0,"st曽根美雪_制服_腕組み_shout")
    voice "voice/e23/24f00020a01.opus"
    mx "\"Дурак! Ты опоздал!\""
    xy "\"Я знаю. Простите за ожидание.\""
    $ sename = "se人体_動作_ポケット探る"
    play se sedict[sename]
    "Я достал из кармана банку с хайболом шочу."
    $ sename = "se物体_缶_開ける"
    play se sedict[sename]
    pause (200/1000)
    $ St("MR",300,15,0,"st曽根美雪_制服_通常_shock")
    voice "voice/e23/24f00030a01.opus"
    mx "\"Это спиртное?\""
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/e23/24f00040a02.opus"
    aoi "\"Ты пьёшь алкоголь?\""
    voice "voice/e23/24f00050a02.opus"
    aoi "\"Ты правонарушитель!\""
    xy "\"Один раз не навредит.\""
    $ St("MR",300,15,0,"st曽根美雪_制服_通常_smile")
    voice "voice/e23/24f00060a01.opus"
    mx "\"...По крайней мере, ты появился, наверное.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (200/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010300_2_学校屋根"]+".jpg")
    pause (500/1000)
    hide 絵色黒
    with Dissolve(500.0/1000)
    "Как только солнце село, я поднялся на верх крыши."
    with Dissolve((1000.0+1000.0)/1000)
    "Небо было малинового цвета."
    "Так, как я помню."
    show expression Solid("990000") as 絵演色血
    with ImageDissolve("cg/data/slide_02_01_0.png",10)
    "То, как... я помню это..."
    $ renpy.music.play("ttb24",channel = "bgm", if_changed = True)
    show expression Solid("990000") as 絵演色血上 zorder 110
    with Dissolve((500.0+1000.0)/1000)
    pause (500/1000)
    hide 絵演色血上
    hide 絵演色血
    show expression ("cg/bg/"+imagename["bg010300_2_学校屋根"]+".jpg")
    with Dissolve(1000.0/1000)
    $ St("MR",300,15,0,"bu曽根美雪_制服_腕組み_smile")
    voice "voice/e23/24f00070a01.opus"
    mx "\"Это правда мысленно возвращает тебя к тому роковому дню, да?\""
    $ St("ML",300,-15,0,"bu向日アオイ電波_制服_通常_shy")
    show expression ("cg/ef/"+imagename["eff血01"]+".png") as 絵覆葵絵演血
    with Dissolve((15000.0+1000.0)/1000)
    voice "voice/e23/24f00080a02.opus"
    aoi "\"В тот день, когда мы попрощались.\""
    xy "\"...Ага.\""
    voice "voice/e23/24f00090a01.opus"
    mx "\"Ты выберешь меня?\""
    $ St("ML",300,-15,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/e23/24f00100a02.opus"
    aoi "\"Или выберешь меня?\""
    voice "voice/e23/24f00110a01.opus"
    mx "\"Мы потребовали ответа.\""
    voice "voice/e23/24f00120a02.opus"
    aoi "\"Но ты так и не дал нам его.\""
    hide 絵色黒
    show expression Solid("FFFFFF") as 絵色白
    show expression ("cg/bg/"+imagename["bg010300_2_学校屋根"]+".jpg")
    $ sename = "se物体_バット_転がる"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    hide 上背景
    pause (50/1000)
    hide 絵色白
    hide 絵覆葵絵演血
    with Dissolve(150.0/1000)
    pause (1000/1000)
    "А потом случилась трагедия."
    "Следующее, что я помню - они обе лежали мёртвыми, став жертвами взаимного недовольства."
    "И всё же, каждый раз, когда я поднимался на крышу, там стояли они."
    "Я знал, что они были мертвы."
    "Я знал это."
    "Но я не мог их отпустить."
    "Я хотел, чтобы мы втроём были вместе."
    "Я был так счастлив, что даже начал терять это."
    with Dissolve((10000.0+1000.0)/1000)
    "...А потом я потерял это."
    "Мой разум был в полном противоречии с реальностью."
    "Не в состоянии выбраться из своей иллюзии, я закрылся здесь..."
    "...пока они не выломали дверь и не отвезли меня в психушку."
    stop bgm fadeout (4000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    pause (500/1000)
    "...А потом прошло целых 20 лет."
    $ sename = "se環境_ガヤ_学校屋上授業中"
    play se sedict[sename]
    hide 絵板写
    hide 絵色黒
    with Dissolve(500.0/1000)
    xy "\"Гл-л-л-л... гл-л-л-л... м-м-м...\""
    "Я выпил свой напиток."
    "А потом я стоял здесь, один на пустой крыше."
    "Их никогда не было здесь."
    "Они давным-давно покинули этот мир."
    "И теперь я наконец-то могу смириться с этим."
    "Так что осталось сделать только одно."
    xy "\"Ладно... я готов.\""
    stop se fadeout (150.0/1000)
    $ sename = "se物体_缶_落ちる"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒
    pause (1000/1000)
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    pause (500/1000)
    "Пора пойти проведать их."
    show expression Solid("000000")
    $ renpy.vibrate(.3)
    $ sename = "se人体_衝撃_バットで殴る04"
    play se sedict[sename]
    $ sename = "se人体_血_飛び散る"
    play se sedict[sename]
    show screen rmenu
    $ renpy.pause()
    hide screen rmenu
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
