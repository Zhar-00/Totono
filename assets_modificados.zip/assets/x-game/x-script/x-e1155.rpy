label e1155_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1155:
    hide 絵色黒
    stop bgm fadeout (150.0/1000)
    $ renpy.music.play("ttb22",channel = "bgm", if_changed = True)
    if (BackFile == "e1151a.nss"):
        show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
        $ St("C",300,0,0,"fu曽根美雪_制服_病み_sad")
        hide 上背景
    else:
        pause (16/1000)
        $ St("C",300,0,0,"fu曽根美雪_制服_病み_sad")
    pause (16/1000)
    scene expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    pause (16/1000)
    $ persistent.meta_date += 1
    voice "voice/e11/5500010a01.opus"

    mx "\"Давай... Давай покончим со всем этим.\""

    "Миюки опустила голову."
    voice "voice/e11/5500020a01.opus"

    mx "\"Ты знаешь, что никогда не сбежишь от меня.\""
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/e11/5500030a01.opus"

    mx "\"Так что просто сдайся... и поцелуй меня...\""
    menu:
        "Поцеловать её":
            $ SetChoiceSelect = 0
        "Не целовать её":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e1152a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e1155a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
