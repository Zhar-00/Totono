label d4181_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if meet_aoi == False:
        $ GameName = "d4182a.nss";
    else:
        $ GameName = "d4182b.nss";
    return
label d4181:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg080100_3_コンビニ外正面"]+".jpg")
    $ sename = "se人体_足音_歩く01遅L"
    play se sedict[sename]
    pause (500/1000)
    hide 上背景
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (300/1000)

    xy "\"Чему Муко научила меня...\""

    "Она меня правда чему-то учила?"
    stop se fadeout (1000.0/1000)
    $ sename = "se物体_チャイム_入店"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg090100_2_コンビニ店内"]+".jpg")
    with Dissolve((400.0)/1000)
    $ st_timezone = "昼"
    pause (200/1000)
    $ St("C",300,0,0,"st曙龍二郎_バイト_通常_normal")
    with Dissolve(200.0/1000)
    $ St("C",300,0,0,"st曙龍二郎_バイト_通常_surprise")
    voice "voice/d41/8100010b03.opus"

    c "\"Добро пожаловать— А-АХ!\""
    $ St("C",300,0,0,"st曙龍二郎_バイト_通常_shy")
    with Dissolve(200.0/1000)
    voice "voice/d41/8100020b03.opus"

    c "\"С-Сузуки-семпай!\""

    xy "\"О, привет, Хару-чан.\""
    voice "voice/d41/8100040b03.opus"

    c "\"Эм... а... мне надо поговорить с тобой!\""

    xy "\"Правда?\""
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
