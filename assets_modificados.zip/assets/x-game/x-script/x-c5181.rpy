label c5181_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c5182.nss"
    return
label c5181:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg")
    $ sename = "se人体_足音_走る美雪来る"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    pause (200/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/c51/8100010a01.opus"

    mx "\"Я вернулась!\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/c51/8100020a01.opus"

    mx "\"И взяла для нас мороженого из Каваками.\""
    voice "voice/c51/8100030a02.opus"

    aoi "\"Спасибо!\""
    voice "voice/c51/8100040a01.opus"

    mx "\"Ну так что, идём?\""
    $ sename = "se人体_足音_駆け出す"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Миюки пошла вперёд, её глаза сверкали."

    "Ей и правда нравится Кошачья мята, это уж точно..."
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    $ sename = "se人体_足音_歩く複数３人"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    pause (500/1000)

    "Мы шли по реке и наслаждались своим мороженым."
    voice "voice/c51/8100050a01.opus"

    mx "\"М-м-м-м! Как вку-у-у-усно!\""
    voice "voice/c51/8100060a01.opus"

    mx "\"Вкус красной фасоли был правильным выбором.\""
    voice "voice/c51/8100070a02.opus"

    aoi "\"Клубничное мороженое тоже очень вкусное!\""

    "Они шли бок о бок и наслаждались своим лакомством."

    "Для меня это было словно дежавю."

    xy "\"Миюки, а ты уверена, что тебе можно есть его во время диеты?\""
    voice "voice/c51/8100080a01.opus"

    mx "\"Ох, я бросила спектакль.\""

    xy "\"Ты бросила его?\""
    voice "voice/c51/8100090a01.opus"

    mx "\"Мы с моим семпаем не смогли прийти к согласию в том, что делать с финальной сценой, и теперь они переписывают весь сценарий.\""
    voice "voice/c51/8100100a02.opus"

    aoi "\"О нет, Миюки... Это ужасно. Ты так усердно тренировалась для этого...\""
    voice "voice/c51/8100110a01.opus"

    mx "\"Всё нормально! Правда!\""
    voice "voice/c51/8100120a01.opus"

    mx "\"Ну и что, что я потеряла свою главную роль? У меня гораздо более высокие амбиции.\""
    voice "voice/c51/8100130a02.opus"

    aoi "\"Более высокие? Прямо как в космосе?\""

    "Не настолько высокие, балда..."
    voice "voice/c51/8100140a01.opus"

    mx "\"Нет, нет. Гораздо выше.\""
    voice "voice/c51/8100150a01.opus"

    mx "\"В тысячу раз выше этого.\""

    "Миюки посмотрела на небо."

    "В какой-то мере она напоминала мне Аой."
    stop se fadeout (1000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
