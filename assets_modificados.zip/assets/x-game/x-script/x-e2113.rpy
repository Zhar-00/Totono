label e2113_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2113:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040100_1_街通学路"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e21/1300010b03.opus"

    c "\"Доброе утро, Сонэ-семпай!\""
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/e21/1300020a01.opus"

    mx "\"А— Привет! Доброе утро!\""
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/e21/1300030b03.opus"

    c "\"Я... я... я вижу, Сузуки-семпай сегодня с тобой!\""
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_pinch")
    with Dissolve(200.0/1000)
    voice "voice/e21/1300040b03.opus"

    c "\"Доброе утро!!!\""
    xy "\"Доброе!\""

    "И тут нас вдруг прервал один из наших товарищей с театрального клуба, а именно - Хару-чан."
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/e21/1300050b03.opus"

    c "\"Эм... а... э-эм... э... а...\""

    xy "\"М-м? Ты чего-то хотела?\""
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/e21/1300060b03.opus"

    c "\"А? А, нет, конечно же нет!\""
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_fear")
    with Dissolve(200.0/1000)
    voice "voice/e21/1300070b03.opus"

    c "\"Мне ничего не нужно! Совсем! ИЗВИНИ, ЧТО ВООБЩЕ ПОЗДОРОВАЛАСЬ!!!\""
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_pinch")
    with Dissolve(200.0/1000)
    voice "voice/e21/1300080b03.opus"

    c "\"ПРОЩАЙ НАВСЕГДА!!!\""
    $ sename = "se人体_足音_走る美雪去る"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    stop se fadeout (2000.0/1000)

    xy "\"П-постой!\""
    voice "voice/e21/1300090b03.opus"

    c "\"А-а-ах!\""
    $ sename = "se人体_衝撃_転倒01"
    play se sedict[sename]
    pause (500/1000)

    xy "\"Ты только что споткнулась о воздух?\""

    xy "\"Боже, какая же ты неуклюжая.\""
    $ St("C",300,-30,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/1300100a01.opus"
    mx "\"......\""

    "Миюки сжала губы и посмотрела на Хару-чан."

    "А потом она подошла ко мне—"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/1300110a01.opus"
    mx "\"......!!!\""

    xy "\"А?..\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se人体_動作_奪い取る"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白
    pause (30/1000)
    hide 絵色白
    with Dissolve(70.0/1000)

    "—и крепко схватила меня за руку."

    xy "\"Ай! Ай-яй-яй!\""
    voice "voice/e21/1300120a01.opus"

    mx "\"Пошли!\""

    xy "\"А? Но—\""
    voice "voice/e21/1300130a01.opus"

    mx "\"Просто пошли!\""
    show expression ("cg/ev/"+imagename["eva7131美雪手繋ぎ登校"]+".jpg") as 絵背景 zorder 100 at center
    with Dissolve((1000.0+1000.0)/1000)

    "И, собственно, как только моя рука оказалась в крепкой хватке Миюки, мы продолжили идти к школьным воротам."
    if persistent.count_e2111 >4:
        $ GameName = "e2114.nss";
    else:
        $ GameName = "e3111.nss";
        scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
