label e2111_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2111:
    hide 絵色黒
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 100 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(300.0/1000))
    scene expression ("cg/bg/"+imagename["bg040100_1_街通学路"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ persistent.count_e2111 += 1
    $ St("C",300,0,0,"st曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/1100010a01.opus"
    mx "\"Доброе утро!\""
    xy "\"Доброе!\""
    hide StC with Dissolve(200.0/1000)
    $ sename = "se人体_足音_歩く複数美雪L"
    play se sedict[sename]
    "Ученики махали друг другу рукой по дороге в школу."
    "Поскольку мы с Миюки жили в одном доме..."
    "...естественно, мы пошли по одной дороге в школу."
    if persistent.miyuki[20] == 0:
        "Мы шли по ней прямо, без обходов."
    elif persistent.miyuki[20] == 1:
        "...Хотя иногда нам приходилось сворачивать в сторону святилища, когда видели кота впереди."
    elif persistent.miyuki[20] == 2:
        "...И иногда нам ещё приходилось сворачивать в сторону реки, если погода была хорошей."
    voice "voice/e21/1100020a01.opus"
    mx "\"Шиничи.\""
    xy "\"М-м? В чём дело?\""
    voice "voice/e21/1100030a01.opus"
    mx "\"С-слушай, эм...\""
    "Миюки шла рядом со мной."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    stop se fadeout (500.0/1000)
    voice "voice/e21/1100040a01.opus"
    mx "\"Как ты относишься к тому... что люди держатся за руки на глазах у других людей?\""
    "Я опустил свой взгляд."
    voice "voice/e21/1100050a01.opus"
    mx "\"Лично я не особо помешана на этом, если говорить честно.\""
    if persistent.miyuki[2] == 0:
        voice "voice/e21/1100060a01.opus"
        mx "\"Это очень неловко.\""
    elif persistent.miyuki[2] == 1:
        voice "voice/e21/1100070a01.opus"
        mx "\"Такое чувство, будто мы пытаемся похвастаться или что-то ещё.\""
    elif persistent.miyuki[2] == 2:
        voice "voice/e21/1100080a01.opus"
        mx "\"Я предпочитаю держать личные вещи в тайне.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e21/1100090a01.opus"
    mx "\"Но...\""
    "Она неловко протянула мне свою левую руку."
    if persistent.eternal_day:
        $ GameName = "e2112a.nss";
    else:
        menu:
            "Подойти поближе":
                $ SetChoiceSelect = 0
            "Отойти подальше":
                $ SetChoiceSelect = 1
        if SetChoiceSelect==0:
            $ persistent.miyuki_love += 1
            $ GameName = "e2112a.nss";
        elif SetChoiceSelect==1:
            if persistent.world_recreate:
                $ GameName = "e2112c.nss";
            else:
                $ persistent.miyuki_love -= 1
                $ GameName = "e2112b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
