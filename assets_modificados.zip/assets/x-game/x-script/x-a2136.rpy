label a2136_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a2137.nss"
    return
label a2136:
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010300_1_学校屋根_l"]+".jpg") as 絵背景 zorder 100 at center
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    with Dissolve(1500.0/1000)
    $ sename = "se物体_缶_開ける"
    play se sedict[sename]
    voice "voice/a21/3600010a02.opus"
    aoi "Гл-л-л-л... гл-л-л-л... гл-л-л-л..."
    $ sename = "se物体_缶_置く"
    play se sedict[sename]
    voice "voice/a21/3600020a02.opus"
    aoi "Я всё!"
    show expression ("cg/ef/"+imagename["efbgヤバトマ"]+".jpg") as 絵画像 zorder 1000 at center
    with Dissolve((300.0+1000.0)/1000)
    "В очередной раз, обед Аой состоял всего из одной банки Ябалея."
    voice "voice/a21/3600030a02.opus"
    aoi "Вот и всё..."
    voice "voice/a21/3600040a02.opus"
    aoi "Но..."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    hide 絵画像
    with Dissolve(500.0/1000)
    "Взгляд Аой перешёл на обед Миюки. Не то, чтобы я винил её за это."
    voice "voice/a21/3600050a01.opus"
    mx "Разделишь обед со мной, Муко-сан?"
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/3600060a02.opus"
    aoi "Буп-буп?.."
    "Миюки пододвинула контейнер к Аой."
    voice "voice/a21/3600070a01.opus"
    mx "Ты всё ещё голодная, верно?"
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    voice "voice/a21/3600080a02.opus"
    aoi "Но это твоя еда."
    voice "voice/a21/3600090a01.opus"
    mx "Мне нужно следить за своим весом. Всё-таки спектакль уже не за горами. Ты ведь поможешь мне, верно?"
    voice "voice/a21/3600100a02.opus"
    aoi "Но..."
    voice "voice/a21/3600110a01.opus"
    mx "Скажи «а-а-а»!"
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/3600120a02.opus"
    aoi "А-а..."
    "Миюки помахала осьминожьим хот-догом под носом Аой."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/3600130a02.opus"
    aoi "А-а... а-а-а-а... а-а-а-а-а-а!.."
    "Губы Аой разомкнулись так, будто она была очарована."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/3600140a02.opus"
    aoi "Ням."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "И-и-и хот-дога как не бывало."
    voice "voice/a21/3600150a02.opus"
    aoi "Ням-ням... ням-ням..."
    voice "voice/a21/3600160a02.opus"
    aoi "М-м-м... что ЭТО?!.."
    voice "voice/a21/3600170a01.opus"
    mx "Ну, как тебе?"
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_挙手_shout")
    voice "voice/a21/3600180a02.opus"
    aoi "Это ЖУЛЬНИЧЕСТВО!"
    xy "Какое ещё жульничество?"
    voice "voice/a21/3600190a01.opus"
    mx "Я вовсе не обманывала тебя или ещё что."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_shout")
    voice "voice/a21/3600200a02.opus"
    aoi "Нет... Дело в том, насколько он вкусный!"
    voice "voice/a21/3600210a01.opus"
    mx "А, точно. Спасибо."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_挙手_shout")
    voice "voice/a21/3600220a02.opus"
    aoi "Такой же вкусный, как и Ябалей!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_sigh")
    voice "voice/a21/3600230a01.opus"
    mx "...Ты уверена, что я могу принять это за комплимент?"
    xy "Н-наверное..."
    pause (800/1000)
    scene expression Solid("000000") as 絵色黒 zorder 5000 with dissolve
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
