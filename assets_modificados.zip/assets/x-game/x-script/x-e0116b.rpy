label e0116b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e0116b:
    hide 絵色黒
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(0.0/1000)

    xy "\"Не совсем.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/e01/16b00010a01.opus"

    mx "\"...Понятно.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e01/16b00020a01.opus"

    mx "\"Думаю, мне просто надо стараться чуточку сильнее.\""

    xy "\"Не заставляй себя, ладно?\""

    xy "\"Просто ты склонна предвзято относиться к таким вещам.\""
    voice "voice/e01/16b00030a01.opus"

    mx "\"Не волнуйся.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e01/16b00040a01.opus"

    mx "\"Поверь мне, я всё прекрасно вижу.\""
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
