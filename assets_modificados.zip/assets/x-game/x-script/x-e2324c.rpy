label e2324c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if temp_e == True:
        $ temp_e = False
        if persistent.root_recreate == True:
            $ GameName = "a3125a.nss"
        else:
            scene 絵色黒 with fade
            $ GameCircle=False
        return
    $ GameName = "e2324d.nss"
    return
label e2324c:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    stop bgm fadeout (0.0/1000)
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)

    xy "\"Давай! Шоу скоро начнётся!\""
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]
    play voc "e23/24c00010b04"
    voice "voice/e23/24c00020a02.opus"

    aoi "\"Ещё не всё! Ужин почти готов!\""

    xy "\"Забудь об этом... видишь? Начинается!\""

    "Реклама закончилась, и я сосредоточил всё своё внимание на телевизоре."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010600_2_学校教室"]+".jpg")
    with Dissolve((0.0+200.0)/1000)
    pause (200/1000)
    hide 絵色黒
    with Dissolve(500.0/1000)
    pause (300/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e23/24c00030a01.opus"

    mx "\"Почему?! Ответь мне!\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_rage")
    with Dissolve(200.0/1000)
    voice "voice/e23/24c00040a01.opus"

    mx "\"Почему... Почему ты меня так предал?!\""

    "Миюки Сонэ бросила школу, чтобы дебютировать в сфере развлечений."

    "В последнее время её популярность стремительно росла; не проходит и дня, когда я не вижу её где-нибудь на экране."

    "Она была такой известной, что ей все почти что поклонялись."

    "Я всегда знал, что у неё есть талант, но я и подумать не мог..."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/e23/24c00050a01.opus"

    mx "\"Если ты собираешься предать меня...\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (200/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_lost")
    with Dissolve(200.0/1000)
    voice "voice/e23/24c00060a01.opus"

    mx "\"То мне придётся поквитаться с тобой.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_mad")
    with Dissolve(200.0/1000)
    voice "voice/e23/24c00070a01.opus"

    mx "\"Ты можешь бежать, но тебе не спрятаться. Я буду преследовать тебя до самого края Земли...\""
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    hide StC with Dissolve(0.0/1000)
    scene expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    hide 絵演効果
    hide 絵色黒
    with Dissolve(500.0/1000)

    xy "\"Воу! Жутковато!\""
    voice "voice/e23/24c00080a02.opus"

    aoi "\"Буп-буп? Пока не везёт?\""

    xy "\"А?\""
    voice "voice/e23/24c00090a02.opus"

    aoi "\"Миюки никогда не давали романтические роли в драмах.\""
    voice "voice/e23/24c00100a02.opus"

    aoi "\"Это странно.\""

    xy "\"Как только ты упомянула об этом, да, ты права...\""

    "Мы смотрели большую часть шоу, в которых она снималась, но я не мог вспомнить, чтобы она где-либо играла романтического героя..."

    "Если подумать, я даже не слышал никаких слухов о её личной жизни... Это немного странно, учитывая то, какая она известная..."
    show expression ("cg/bg/"+imagename["bg010600_2_学校教室"]+".jpg") as 絵演背景 zorder 310 at truecenter
    with Dissolve((0.0+200.0)/1000)
    $ St("C",320,0,0,"fu曽根美雪_制服_腕組み_sad")
    with Dissolve(500.0/1000)

    xy "\"Она ничуть не изменилась с тех пор, как мы учились в одной школе, да?\""
    voice "voice/e23/24c00110a02.opus"

    aoi "\"Миюки не может ни с кем встречаться.\""

    xy "\"Да, без шуток.\""

    xy "\"Наверное, это трудно, быть знаменитостью...\""
    play voc "e23/24c00120b04"

    xy "\"Хм? О! Как раз вовремя, Иру.\""

    xy "\"Налетай, пока не остыло.\""
    hide StC
    hide StMR
    hide StML
    hide 絵演背景
    with Dissolve(500.0/1000)

    "Я отвернулся от телевизора."

    "На столе меня уже ждал домашний ужин, приготовленный Аой."
    voice "voice/e23/24c00130a02.opus"

    aoi "\"Буп-буп... Ешь!\""
    voice "voice/e23/24c00140a02.opus"

    aoi "\"Это говядина, отваренная в Ябалее!\""

    xy "\"Ого... Выглядит очень вкусно!\""
    play voc "e23/24c00150b04"
    voice "voice/e23/24c00160a02.opus"

    aoi "\"Приятного аппетита.\""

    xy "\"Не откажусь!\""

    xy "\"Ням, ням, ням... м-м-м...\""
    voice "voice/e23/24c00170a02.opus"

    aoi "\"Ну? Как тебе?\""

    xy "\"Очень вкусно!\""

    xy "\"Одно из твоих лучших блюд!\""
    voice "voice/e23/24c00180a02.opus"

    aoi "\"Спасибо!\""
    hide StC with Dissolve(200.0/1000)

    "Пикантный вкус Ябалея плясал на моём языке..."

    "...и я молча благодарил Бога за то, что он свёл меня с Аой вместе."
    if temp_e:
        return
    show screen rmenu
    $ renpy.pause()
    hide screen rmenu
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
