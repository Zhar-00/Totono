label e1134b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1134c.nss"
    return
label e1134b:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(0.0/1000)

    xy "\"Прости, Миюки! Увидимся позже!\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]

    "Я схватил Ютаро за руку и начал бежать."
    voice "voice/e11/34b00010a01.opus"

    mx "\"Какого хрена, Шиничи?!\""
    voice "voice/e11/34b00020b01.opus"

    xtl "\"В-воу! Не тащи меня за собой, чувак!\""

    xy "\"Просто иди со мной!\""

    "Мы двое бежали так быстро, будто за нами черти гнались."

    "Но Миюки не стала нас догонять."
    $ persistent.miyuki_decision2 = True;
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
