label e2243a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2311.nss"
    return
label e2243a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_normal")
    with Dissolve(0.0/1000)

    xy "\"У меня не так много опыта, но ЗАТО у меня есть это!\""

    "Я подошёл к книжной полке и достал оттуда кулинарную книгу, которую купил на днях."

    xy "\"Я планировал приготовить для тебя нечто особенное.\""
    voice "voice/e22/43a00010a01.opus"

    mx "\"...Понятно...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/43a00020a01.opus"

    mx "\"Ну, тогда... Милости прошу, дорогуша.\""

    xy "\"Без проблем! Просто предоставь это мне!\""
    hide StC with Dissolve(200.0/1000)

    "Я помчал на кухню на всех парах."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
