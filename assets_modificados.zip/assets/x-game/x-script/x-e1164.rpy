label e1164_MAIN:
    call expression GameName
    $ persistent.imagelog["eve1158a美雪ラスボスb"]=True
    $ persistent.imagelog["bg010100_9_学校階段"]=True
    $ persistent.imagelog["bg010400_9_学校校門"]=True
    $ persistent.imagelog["bg010500_9_学校昇降口"]=True
    $ persistent.imagelog["bg010700_9_学校廊下"]=True
    $ persistent.imagelog["bg040100_9_街通学路"]=True
    $ PreGameName = GameName
    $ GameName = "e1165.nss"
    return
label e1164:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg")
    with Dissolve(500.0/1000)
    pause (300/1000)
    "Несколько минут спустя..."
    show expression ("cg/bg/"+imagename["bg080100_2_コンビニ外正面"]+".jpg")
    hide 絵色黒
    with Dissolve(500.0/1000)
    pause (300/1000)
    "Мы пришли домой к Ютаро."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/6400010b01.opus"
    xtl "\"Еле успели!\""
    hide StC with Dissolve(200.0/1000)
    pause (200/1000)
    $ sename = "se物体_チャイム_入店"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg090100_2_コンビニ店内"]+".jpg")
    with Dissolve((500.0)/1000)
    $ st_timezone = "昼"
    pause (200/1000)
    $ St("C",300,0,0,"st曙龍二郎_バイト_通常_normal")
    with Dissolve(200.0/1000)
    $ St("C",300,0,0,"st曙龍二郎_バイト_通常_smile")
    voice "voice/e11/6400020b03.opus"
    c "\"Добро пожаловать— О! Братик!\""
    voice "voice/e11/6400030b01.opus"
    xtl "\"Я дома! А где Муко?\""
    $ St("C",300,0,0,"st曙龍二郎_バイト_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/6400040b03.opus"
    c "\"Она переодевается в подсобке.\""
    voice "voice/e11/6400050b01.opus"
    xtl "\"А, понял.\""
    xy "\"Переодевается?\""
    hide StC
    hide StMR
    hide StML
    show expression ("cg/bg/m/"+imagename["bg090100_2_コンビニ店内_m"]+".jpg") as 絵背景雄太郎 at truecenter
    $ St("C",2300,0,0,"bu曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/6400060b01.opus"
    xtl "\"Она работает здесь на полставки.\""
    voice "voice/e11/6400070b01.opus"
    xtl "\"В смысле, она всё-таки девушка Рюджиро.\""
    xy "\"Рю... джиро?..\""
    "Опять же, я не мог понять, что сказал Ютаро."
    hide StC
    hide StMR
    hide StML
    with Dissolve((0.0+0.0)/1000)
    $ St("ML",740,0,0,"st曙龍二郎_バイト_通常_shy")
    with Dissolve(200.0/1000)
    "Он показал на Хару-чан."
    "Но Хару-чан никоим образом не может быть Рюджиро!.."
    $ St("ML",300,0,0,"st曙龍二郎_バイト_通常_surprise")
    voice "voice/e11/6400080b03.opus"
    c "\"Эм... А кто это?\""
    xy "\"Да брось! Мы в одном клубе, разве нет? Почему ты ведёшь себя так, будто ни разу меня не встречала?\""
    $ St("ML",300,0,0,"st曙龍二郎_バイト_通常_shy")
    voice "voice/e11/6400090b03.opus"
    c "\"Мы... в одном клубе?..\""
    voice "voice/e11/6400100b01.opus"
    xtl "\"Шиничи!\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_smile")
    voice "voice/e11/6400110b01.opus"
    xtl "\"Ты самый ценный участник клуба «Ребята и мечты»!\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_surprise")
    voice "voice/e11/6400120b01.opus"
    xtl "\"Я ни за что на свете не позволю театральному клубу украсть тебя!\""
    xy "\"Я... не в театральном клубе?..\""
    xy "\"Хару-чан, это правда?\""
    $ St("ML",300,0,0,"st曙龍二郎_バイト_通常_shy")
    voice "voice/e11/6400130b03.opus"
    c "\"Д-да... Определённо...\""
    xy "......"
    "Мои воспоминания не совпадали с их утверждениями."
    "Они что, просто издеваются надо мной?"
    "Или..."
    "Мои воспоминания... неверные?.."
    voice "voice/e11/6400140a02.opus"
    aoi "\"Поняла.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "И тут девушка вышла из подсобки с поднятой рукой."
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    pause (700/1000)
    voice "voice/e11/6400150a02.opus"
    aoi "\"У тебя амнезия?\""
    "Это... Аой."
    xy "\"......Что?\""
    xy "\"Какого чёрта Аой делает здесь?\""
    voice "voice/e11/6400160b01.opus"
    xtl "\"Как я уже сказал, она работает здесь на полставки—\""
    xy "\"Я не это имел в виду!\""
    xy "\"Разве она не героиня в визуальной новелле?!..\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/e11/6400170a02.opus"
    aoi "\"Буп-буп?..\""
    voice "voice/e11/6400180b01.opus"
    xtl "\"Если это была шутка, то она не очень смешная.\""
    voice "voice/e11/6400190b01.opus"
    xtl "\"Муко в нашем классе учится, чувак.\""
    xy "\"Серьёзно?..\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/e11/6400200a02.opus"
    aoi "\"Поняла.\""
    "Аой снова подняла свою руку ввысь."
    voice "voice/e11/6400210a02.opus"
    aoi "\"Пошли со мной.\""
    xy "\"А?\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/e11/6400220a02.opus"
    aoi "\"Сюда.\""
    hide StC with Dissolve(200.0/1000)
    "Судя по всему, Аой хотела поговорить со мной наедине..."
    "И по её просьбе, я вышел вместе с ней наружу."
    scene expression ("cg/bg/"+imagename["bg080100_2_コンビニ外正面"]+".jpg")
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    xy "......"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/6400230a02.opus"
    aoi "......"
    "Стоя перед магазином, она развернулась ко мне лицом."
    "Чем больше я смотрел на неё, тем больше я убеждался в этом... она была абсолютно ИДЕНТИЧНОЙ своей копии в видеоигре."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/e11/6400240a02.opus"
    aoi "\"Объясни мне кое-что.\""
    voice "voice/e11/6400250a02.opus"
    aoi "\"Как ты узнал?\""
    xy "\"Узнал что?\""
    voice "voice/e11/6400260a02.opus"
    aoi "\"Мою истинную личность.\""
    "То есть, она ПРАВДА является персонажем в видеоигре?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_密着_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/6400270a02.opus"
    aoi "\"Скажи мне. Как ты это узнал?\""
    xy "\"В смысле, как? Ты была прямо там, в игре!\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_密着_think")
    with Dissolve(200.0/1000)
    voice "voice/e11/6400280a02.opus"
    aoi "\"В этой игре?\""
    "Она достала свой телефон."
    "На его экране отображалась та самая визуальная новелла."
    "И Аой в игре..."
    "...выглядела точно так же, как и Аой, которая стояла передо мной..."
    stop se fadeout (150.0/1000)
    $ sename = "se環境_自然_遠雷L"
    play se sedict[sename]
    with Dissolve((0.0+800.0)/1000)
    pause (30/1000)
    with Dissolve(500.0/1000)
    pause (500/1000)
    xy "\"Какого?..\""
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg900100_9_雰囲気空渦"]+".jpg")
    hide StC
    hide StMR
    hide StML
    with Dissolve(500.0/1000)
    pause (800/1000)
    "Я посмотрел наверх и заметил, как чёрные штормовые облака кружили в небе над нами, хотя до этого был обычный закат."
    "Почти как маленький тайфун, образовавшийся над школой—"
    voice "voice/e11/6400290a02.opus"
    aoi "\"Бог!..\""
    $ sename = "se人体_足音_走るアオイ"
    play se sedict[sename]
    "Аой начала бежать."
    show expression ("cg/bg/"+imagename["bg040100_9_街通学路"]+".jpg")
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]
    hide 絵背景
    with Dissolve(400.0/1000)
    pause (200/1000)
    xy "\"Что за?! Аой?! Куда ты—\""
    voice "voice/e11/6400300a02.opus"
    aoi "\"К центру вселенной!\""
    voice "voice/e11/6400310a02.opus"
    aoi "\"Вселенная скоро получит патч обновления!\""
    xy "\"Патч обновления?\""
    voice "voice/e11/6400320a02.opus"
    aoi "\"Мир скоро изменится.\""
    voice "voice/e11/6400330a02.opus"
    aoi "\"Как только Бог получил сигнал...\""
    voice "voice/e11/6400340a02.opus"
    aoi "\"Игра становится реальностью.\""
    show expression ("cg/bg/"+imagename["bg010400_9_学校校門"]+".jpg")
    with Dissolve(400.0/1000)
    "Слова Миюки звучали эхом у меня в ушах."
    "«Я изменю этот мир»."
    "Я не понимаю..."
    "Как мне отличить реальность от вымысла?.."
    show expression ("cg/bg/"+imagename["bg010500_9_学校昇降口"]+".jpg")
    with Dissolve(400.0/1000)
    "Аой должна была быть героиней в визуальной новелле."
    "Но потом я увидел её своими глазами!"
    "Это не может быть сном."
    "Это реальная жизнь."
    show expression ("cg/bg/"+imagename["bg010700_9_学校廊下"]+".jpg")
    $ sename = "se人体_足音_歩く複数美雪廊下"
    play se sedict[sename]
    with Dissolve(400.0/1000)
    "Если всё то, что происходило до вчерашнего дня, было частью видеоигры..."
    "И видеоигра «становится реальностью»..."
    show expression ("cg/bg/"+imagename["bg010100_9_学校階段"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010100_9_学校階段_l"]+".jpg") as 絵背景:
        pos (-1024,-576)
    with Dissolve(400.0/1000)
    "Получается..."
    with Dissolve(400.0/1000)
    "Миюки сотрёт Аой из реальности?"
    $ sename = "se物体_ドア鉄_回す"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白
    with Dissolve((4000.0+1000.0)/1000)
    pause (2000/1000)
    $ sename = "se物体_ドア鉄_開く01"
    play se sedict[sename]
    with Dissolve((1000.0+1000.0)/1000)
    $ roof = True;
    show expression ("cg/bg/"+imagename["bg010200_9_学校屋上"]+".jpg")
    pause (2000/1000)
    hide 上背景
    hide 絵色白
    with Dissolve(3000.0/1000)
    pause (1000/1000)
    "Я побежал на крышу и обернулся."
    "И в центре вселенной стояла—"
    show expression ("cg/ev/"+imagename["eve1158a美雪ラスボスb"]+".jpg") as 絵専下 zorder 1100 at center
    show expression ("cg/ev/l/"+imagename["eve1158a美雪ラスボスb_l"]+".jpg") as 絵専 zorder 1105:
        pos (-512,-576)
        linear 3 ypos -270
    with Dissolve((800.0+1000.0)/1000)
    pause (1000/1000)
    xy "\"МИЮКИ!\""
    voice "voice/e11/6400350a01.opus"
    mx "\"Шиничи...\""
    hide 絵専
    with Dissolve(800.0/1000)
    voice "voice/e11/6400360a01.opus"
    mx "\"И, как погляжу, Аой с тобой.\""
    voice "voice/e11/6400370a02.opus"
    aoi "\"Миюки, отдай мне телефон.\""
    show expression ("cg/ev/"+imagename["eve1135美雪セカイ改変a"]+".jpg") as 絵専 zorder 1100 at truecenter
    hide StC with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg010200_9_学校屋上"]+".jpg")
    hide 絵専下
    with Dissolve(800.0/1000)
    voice "voice/e11/6400380a01.opus"
    mx "\"Уже слишком поздно.\""
    voice "voice/e11/6400390a02.opus"
    aoi "\"Ох...\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
