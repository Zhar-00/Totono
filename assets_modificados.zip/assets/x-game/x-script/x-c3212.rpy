label c3212_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c3221.nss"
    return
label c3212:
    hide 絵色黒
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_smile")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200010a02.opus"

    aoi "\"Хорошо, что Хару-чан решила помочь нам.\""

    "После того, как мы вытащили её из-под кучи сигаретных пачек, мы помогли ей расставить их обратно."

    "В знак благодарности, робкая и неуклюжая Хару научила нас всему, что она знала об уходе за котятами."

    "И теперь мы кормили Иру пастеризованным молоком, которое Хару выбрала для нас."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    xy "......"
    voice "voice/c32/1200020a02.opus"
    aoi "......"
    xy "\"Ты, случаем, не хочешь...\""
    xy "\"...переночевать здесь?\""
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200030a02.opus"
    aoi "\"Буп-буп...\""

    xy "\"Время уже позднее, и я знаю, что ты себя сейчас неважно чувствуешь. А ночёвка в манга-кафе не поспособствует твоему хорошему отдыху.\""
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200040a02.opus"

    aoi "\"Но... это активирует флаг рискованного события...\""
    voice "voice/c32/1200050a02.opus"
    aoi "......"

    xy "\"Что ещё за флаг события?..\""
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_pain")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200060a02.opus"
    aoi "\"...Буп-буп.\""
    hide 絵背景
    hide StC with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)

    "Аой затихла и посмотрела на Иру."

    "Котёнок лакал молоко своим маленьким язычком. И не успели мы и опомниться, как мы оба уже улыбались."

    xy "\"Этот маленький комочек шерсти выглядит довольно счастливым.\""
    voice "voice/c32/1200070a02.opus"

    aoi "\"Молоко выглядит как сперма.\""

    xy "\"—?!\""

    xy "\"Воу! Боже! Не говори такое!\""
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_密着_think")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200080a02.opus"

    aoi "\"Почему нет?\""

    xy "\"Потому что я так сказал!\""
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200090a02.opus"

    aoi "\"Буп-буп... ладно.\""
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_通常_normal")
    with Dissolve(200.0/1000)
    stop bgm fadeout (5000.0/1000)
    voice "voice/c32/1200100a02.opus"
    aoi "\"Но...\""

    "Аой затихла и посмотрела на меня."

    "Хотя нет, не на меня..."

    "На мою промежность?!.."
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200110a02.opus"

    aoi "\"Аой не будет против попить твоего \"молока\".\""

    xy "\"Пф-ф-ф-ф-ф?!\""

    xy "\"Перестань, Аой! Ты ведёшь себя странно—!\""
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_通常_think")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb12",channel = "bgm", if_changed = True)
    voice "voice/c32/1200120a02.opus"

    aoi "\"Да, это ПРАВДА странно.\""
    voice "voice/c32/1200130a02.opus"

    aoi "\"Каждый раз, когда Аой зовёт тебя по имени...\""
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_密着_think")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200140a02.opus"

    aoi "\"...моя грудь начинает сжиматься...\""
    voice "voice/c32/1200150a02.opus"

    aoi "\"...и голова идёт кругом.\""
    $ sename = "se人体_動作_衣擦れ02"
    play se sedict[sename]
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_密着_think")
    with Dissolve(500.0/1000)
    pause (500/1000)
    voice "voice/c32/1200160a02.opus"

    aoi "\"Что не так со мной?\""
    $ sename = "se人体_動作_衣擦れ04"
    play se sedict[sename]

    "Аой наклонилась ко мне поближе."

    "Её щёки были бледно-розового цвета."

    "Мой взгляд был прикован к ней."

    xy "\"Звучит так, будто т-ты, скорее всего, простудилась, или ещё что.\""
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200170a02.opus"

    aoi "\"Нет. У этого момента нет своей сценки.\""
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_密着_normal")
    with Dissolve(200.0/1000)
    $ sename = "se人体_動作_衣擦れ04"
    play se sedict[sename]

    "Она приложила руку к своей груди."
    voice "voice/c32/1200180a02.opus"

    aoi "\"Аой чувствует себя такой возбуждённой...\""
    voice "voice/c32/1200190a02.opus"

    aoi "\"Прямо здесь.\""
    $ sename = "se人体_動作_衣擦れ02"
    play se sedict[sename]
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_密着_ero")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200200a02.opus"

    aoi "\"Может ли Аой поцеловать тебя?\""

    xy "\"Воу, погоди-ка—!\""
    $ sename = "se人体_動作_衣擦れ01"
    play se sedict[sename]
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_sad")
    with Dissolve(200.0/1000)

    "Я тут же убрал её руку в сторону."
    voice "voice/c32/1200210a02.opus"
    aoi "\"Буп-буп?\""
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200220a02.opus"

    aoi "\"Почему нет?\""

    xy "\"Ну... потому что...\""

    xy "\"Потому что я так сказал.\""
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c32/1200230a02.opus"

    aoi "\"Ты тоже чувствуешь себя странно?\""

    xy "\"Я... я иду спать!\""

    xy "\"Я уже расстелил для тебя одеяло, так что ты должна тоже готовиться ко сну.\""

    xy "\"Спокойной ночи!\""
    stop bgm fadeout (500/1000)
    $ sename = "se人体_足音_階段自宅上がる02"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 30000
    with Dissolve((200.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
