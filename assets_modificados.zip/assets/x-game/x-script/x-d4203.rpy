label d4203_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d4242.nss"
    return
label d4203:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15 at truecenter
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(0.0/1000)

    xy "\"...Ой, прости.\""

    xy "\"Я просто удивился, увидев здесь Иру.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/d42/0300010a01.opus"

    mx "\"Ты ведь останешься?\""
    play voc "d42/0300020b04"
    show expression ("cg/bg/"+imagename["bg060100_3_バッティングセンター店内"]+".jpg")
    with Dissolve(500.0/1000)

    "Иру печально мяукнул."

    "Но я уже принял решение."
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15 at truecenter
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(500.0/1000)

    xy "\"Разумеется, я останусь.\""

    xy "\"Ты знаешь, я потратил всё это время на поиски Аой...\""

    xy "\"Но в конце концов, я просто хотел сказать ей... что я наконец-то смирился с тем, что я действительно чувствую.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/d42/0300030a01.opus"

    mx "\"И что ты чувствуешь?..\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
