label e2172d_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2173.nss"
    return
label e2172d:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(0.0/1000)

    "Книгу «Кулинария-101»."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/e21/72d00010a01.opus"

    mx "\"...Это уже третий раз.\""

    xy "\"Что?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/72d00020a01.opus"

    mx "\"Сколько ещё раз ты собираешься купить эту дурацкую книгу?\""

    xy "\"Не знаю... Всякий раз, когда вижу её, у меня по какой-то причине появляется желание купить её...\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
