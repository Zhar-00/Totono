label e1156a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1157.nss"
    return
label e1156a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)

    "После всей той несуразицы, что она сказала, я начал беспокоиться за Миюки."

    "И поэтому я пошёл вслед за ней из дома—"
    $ miyuki_chase = True;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
