label e2201_MAIN:
    call expression GameName
    $ persistent.imagelog["bg110110_1_マンションリビングソファー"]=True
    $ persistent.imagelog["bg110600_2_マンション台所"]=True
    $ PreGameName = GameName
    return
label e2201:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ st_timezone = "昼"
    pause (1000/1000)
    $ sename = "se人体_動作_字を書く"
    play se sedict[sename]
    pause (1000/1000)
    xy "\"......\""
    voice "voice/e22/0100010a01.opus"
    mx "\"......\""

    "Мы с Миюки сидели друг напротив друга."

    "Между нами лежали наши раскрытые тетради."

    "Мы были заняты нашей домашней работой."
    voice "voice/e22/0100020a01.opus"

    mx "\"Эй, Шиничи? Насчёт одного вопроса—\""

    xy "\"Хм? А, вот этого?\""

    "На первый взгляд, Миюки выглядела так, будто она освоила все школьные предметы..."
    if persistent.miyuki[14] == 0:

        "...но по правде говоря, у неё была одна слабость: биология."
    elif persistent.miyuki[14] == 1:

        "...но по правде говоря, у неё была одна слабость: физика."
    elif persistent.miyuki[14] == 2:

        "...но по правде говоря, у неё была одна слабость: химия."

    "И поэтому я помогал ей с этим."

    xy "\"Ну, тут ЭТО идёт СЮДА, а потом ты меняешь ЭТО—\""
    voice "voice/e22/0100030a01.opus"

    mx "\"А?.. А-а-а, поняла!\""

    "Я всегда был очень хорошим учителем."

    "Под моим руководством, Миюки решала задачи молниеносно."
    $ sename = "se人体_動作_字を書く"
    play se sedict[sename]

    "Шкряб, шкряб, шкряб..."

    "Наши ручки соприкасались с бумагой."

    "Я мог почувствовать её дыхание, сидя по другую сторону стола."
    voice "voice/e22/0100040a01.opus"

    mx "\"Хотелось бы, чтобы этот момент длился бесконечно...\""
    xy "\"Хм?\""
    voice "voice/e22/0100050a01.opus"

    mx "\"А, ничего.\""
    voice "voice/e22/0100060a01.opus"

    mx "\"Просто захотелось сказать это.\""

    xy "\"Постарайся сосредоточиться, ладно?\""
    voice "voice/e22/0100070a01.opus"

    mx "\"Я знаю, знаю.\""

    "Она виновато посмотрела на меня, и её ручка упала ровно."
    show expression ("cg/bg/"+imagename["bg110110_1_マンションリビングソファー"]+".jpg")
    $ St("C",300,0,30,"bu曽根美雪_制服_通常_smile")
    with Dissolve(500.0/1000)
    voice "voice/e22/0100080a01.opus"

    mx "\"Мне надо сконцентрироваться немного сильнее...\""
    voice "voice/e22/0100090a01.opus"

    mx "\"Время для чего-нибудь сладкого!\""
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Так ВОТ, чего она хотела..."

    "И как только она встала на ноги..."
    $ sename = "se物体_携帯_落ちる02"
    play se sedict[sename]
    xy "\"Хм?..\""

    "...её телефон вывалился из кармана."
    xy "......"
    show expression ("cg/bg/"+imagename["bg110600_2_マンション台所"]+".jpg")
    with Dissolve(500.0/1000)
    pause (300/1000)

    "Я мельком глянул в столовую."

    "Очевидно, она зашла в уборную по дороге на кухню."

    "Похоже, она будет отсутствовать ещё какое-то время..."
    if persistent.eternal_day:
        $ GameName = "e2202a.nss";
    else:
        menu:
            "Оставить её телефон в покое":
                $ SetChoiceSelect=0
            "Начать играться с ним":
                $ SetChoiceSelect=1
        if SetChoiceSelect==0:
            $ persistent.miyuki_love += 1
            $ GameName = "e2202a.nss";
        elif SetChoiceSelect==1:
            $ persistent.miyuki_love -= 1
            $ GameName = "e2202b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
