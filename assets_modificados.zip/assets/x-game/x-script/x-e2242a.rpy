label e2242a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2242a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(0.0/1000)

    xy "\"Почему бы мне не приготовить чего-нибудь сегодня?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/e22/42a00010a01.opus"

    mx "\"Что?\""

    xy "\"Я просто чувствую себя ужасно, заставляя тебя всё время готовить для меня.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/42a00020a01.opus"

    mx "\"Не говори глупостей. Всё нормально!\""
    xy "\"Но—\""
    voice "voice/e22/42a00030a01.opus"

    mx "\"Не волнуйся об этом! Так или иначе, готовка - это моё хобби.\""

    xy "\"Я просто хочу показать тебе, как сильно я ценю тебя, только и всего.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e22/42a00040a01.opus"
    mx "\"......\""

    "Похоже, она не хочет, чтобы я вообще приближался к кухне..."

    "От этого у меня даже возникли кое-какие подозрения... как будто она может там что-то прятать..."

    "Не поймите неправильно, я ценю все её старания, но иногда она меня очень пугает..."
    voice "voice/e22/42a00050a01.opus"

    mx "\"Слушай, Шиничи... Ты вообще умеешь готовить?\""
    if (persistent.cook_book==True):
        $ GameName = "e2243a.nss";
    else:
        $ GameName = "e2243b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
