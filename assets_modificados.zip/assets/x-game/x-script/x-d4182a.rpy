label d4182a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d4183.nss"
    return
label d4182a:
    hide 絵色黒
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    scene expression Solid("000000") as 絵色黒
    with Dissolve(500.0/1000)

    "И вот появился свидетель; в самом неожиданном для меня месте."

    "Судя по словам Хару-чан, в ту дождливую ночь она работала за кассой, когда Аой зашла в магазин с котёнком в руках."

    "Котёнок был очень голодным, и Аой хотела покормить его."

    "Так и началась их дружба, и даже после того, как Аой перестала появляться на занятиях, Хару-чан иногда встречала её."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
