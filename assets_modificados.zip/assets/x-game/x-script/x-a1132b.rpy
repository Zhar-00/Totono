label a1132b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a1133.nss"
    return
label a1132b:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    with Dissolve((0.0)/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演葵背景 zorder 1050 at center:
        xpos (512-150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg","cg/st/mask/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg") as 絵演葵立絵 zorder 1100 at center:
        xpos (512+150)
    xy "Хм-м-м... Не думаю, что это так работает."
    xy "Ты не можешь РЕШИТЬСЯ дружить с кем-либо, понимаешь?"
    "По правде говоря, это была лишь оговорка."
    pause (16/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演美雪背景 zorder 9950 at center:
        xpos (512+150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st曽根美雪_制服_腕組み_normal"]+".jpg","cg/st/mask/"+imagename["st曽根美雪_制服_腕組み_normal"]+".jpg") as 絵演美雪立絵 zorder 10000 at center:
        xpos (512-150)
    with Dissolve((0.0+1000.0)/1000)
    "Моя настоящая причина заключалась в Миюки."
    "Я не хочу находиться рядом с ней больше, чем смогу вынести."
    pause (16/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演葵背景 zorder 10950 at center:
        xpos (512-150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg","cg/st/mask/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg") as 絵演葵立絵 zorder 11000 at center:
        xpos (512+150)
    with Dissolve(200.0/1000)
    xy "Я не могу давать обещаний."
    pause (16/1000)
    show expression im.AlphaMask("cg/st/1/"+imagename["st向日アオイ電波_制服_通常_think"]+".jpg","cg/st/mask/"+imagename["st向日アオイ電波_制服_通常_think"]+".jpg") as 絵演葵立絵 zorder 11000 at center:
        xpos (512+150)
    with Dissolve(200.0/1000)
    voice "voice/a11/32b00010a02.opus"
    aoi "Не можешь?"
    pause (16/1000)
    show expression im.AlphaMask("cg/st/1/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg","cg/st/mask/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg") as 絵演葵立絵 zorder 11000 at center:
        xpos (512+150)
    with Dissolve(200.0/1000)
    voice "voice/a11/32b00020a02.opus"
    aoi "А как же Миюки?"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
