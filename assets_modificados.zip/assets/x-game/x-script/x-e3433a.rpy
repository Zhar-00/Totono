label e3433a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ roof = False;
    $ AllSaveDelete()
    $ persistent.complete = True
    $ renpy.quit(relaunch=True)
    return
label e3433a:
    hide 絵色黒
    $ renpy.music.play("ttb14",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e34/33a00010b02.opus"
    kmsm "\"ПОНЯЛ.\""
    voice "voice/e34/33a00020b02.opus"
    kmsm "\"ЖАЛЬ, ЧТО МЫ НЕ МОЖЕМ ПРОАНАЛИЗИРОВАТЬ ЭМОЦИОНАЛЬНЫЕ ОШИБКИ АОЙ.\""
    voice "voice/e34/33a00030b02.opus"
    kmsm "\"НО МЫ НЕ МОЖЕМ ЗАСТАВЛЯТЬ [[ТЕБЯ].\""
    voice "voice/e34/33a00040b02.opus"
    kmsm "\"ВЫБОР СУБЪЕКТА АБСОЛЮТЕН.\""
    stop bgm fadeout (3000.0/1000)
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    voice "voice/e34/33a00050b02.opus"
    kmsm "\"...НАЧИНАЙ ПЕРЕДАЧУ.\""
    "С согласия Бога..."
    pause (1000/1000)
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    pause (1000/1000)
    "...Я нажал на кнопку вызова."
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    voice "voice/e34/33a00060b02.opus"
    kmsm "\"НАЧИНАЮ ПРИНУДИТЕЛЬНОЕ ОБНОВЛЕНИЕ.\""
    voice "voice/a01/13v00070b02.opus"

    bm "\"ДЕСЯТЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00080b02.opus"

    bm "\"ДЕВЯТЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00090b02.opus"

    bm "\"ВОСЕМЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00100b02.opus"

    bm "\"СЕМЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00110b02.opus"

    bm "\"ШЕСТЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00120b02.opus"

    bm "\"ПЯТЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00130b02.opus"

    bm "\"ЧЕТЫРЕ.\"{w=1}{nw}"
    voice "voice/a01/13v00140b02.opus"

    bm "\"ТРИ.\"{w=1}{nw}"
    voice "voice/a01/13v00150b02.opus"

    bm "\"ДВА.\"{w=1}{nw}"
    voice "voice/a01/13v00160b02.opus"

    bm "\"ОДИН.\"{w=1}{nw}"
    voice "voice/a01/13v00170b02.opus"

    bm "\"НОЛЬ.\"{w=1}{nw}"
    stop bgm fadeout (0/1000)
    pause (16/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
