label c6112_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label c6112:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg030200_2_自宅玄関"]+".jpg")
    $ sename = "se物体_ドア室内_開く01"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve(500.0/1000)
    pause (1500/1000)
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]
    pause (500/1000)

    "Как только я обулся у порога, я услышал звон колокольчика, а потом я заметил, как Иру встал на моём пути."
    play voc "c61/1200010b04"

    xy "\"Эй, да ладно. Успокойся, комок шерсти.\""

    xy "\"Что? Ты не хочешь, чтобы я ушёл, да?\""

    xy "\"Просто расслабься. Я вовсе не бросаю Аой или ещё что, ладно?\""
    play voc "c61/1200020b04"
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]

    "Иру проигнорировал меня."

    "Этот малыш был явно не в себе."

    "А ведь обычно он прилежно себя ведёт..."
    return
    return
label c6112_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030200_2_自宅玄関"]+".jpg")
    with Dissolve(0.0/1000)
    menu:
        "Принять это как знак":
            $ SetChoiceSelect = 0
        "Всё равно пойти смотреть спектакль":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "c6113.nss"
    elif SetChoiceSelect==1:
        $ GameName = "d6113.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
