label a0131_MAIN:
    call expression GameName
    $ persistent.imagelog["bg030100_3_自宅自室"]=True
    $ persistent.imagelog["bg030101_3_自宅自室消灯"]=True
    $ persistent.title_on = True
    $ SYSTEM_title_lock=False
    $ PreGameName = GameName
    $ GameName = "a1111.nss"
    python:
        if persistent.passed_a0131_month == None or persistent.passed_a0131_day == None:
            from time import strftime, localtime
            persistent.passed_a0131_month = int(strftime("%m",localtime()))
            persistent.passed_a0131_day = int(strftime("%d",localtime()))
            persistent.DIARY_COUNT += 1
    return
label a0131:
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    show expression Solid("000000") as 絵色黒下
    pause (500/1000)
    $ st_timezone = "昼"
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵色黒 zorder 500
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(800/1000)
    "Аой Муко..."
    "Это имя мне всё равно ни о чём не говорит."
    hide StC
    hide 絵色黒
    hide 絵色黒下
    with Dissolve((500.0/1000))
    $ renpy.music.play("ttb06",channel = "bgm", if_changed = True)
    "Если честно, я не такой уж и общительный человек."
    "Я просто социально неловок."
    "То есть, прошло уже почти шесть месяцев, а я по-прежнему не знаю, как зовут всех девушек в нашем классе."
    "Однако, в нашем классе была одна девушка-телефонистка, у которой была сильная игровая зависимость."
    "Трудно поверить, что я мог забыть кого-то настолько... уникального... как она."
    $ sename = "se物体_照明_スイッチ"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    with Dissolve((150.0)/1000)
    pause (1000/1000)
    xy "Ха-а-а..."
    $ sename = "se物体_布団_潜り込む"
    play se sedict[sename]
    show expression ("cg/ef/"+imagename["efbg自宅自室天井消灯"]+".jpg") as 絵演背景 zorder 100 at center
    with Dissolve((600.0+1000.0)/1000)
    pause (1000/1000)
    "Я плюхнулся на кровать."
    show expression im.AlphaMask("cg/ev/m/"+imagename["eva0113アオイ屋上覆い被さりa_m"]+".jpg",im.Scale("cg/data/circle_02_00_1.png",1536,864)) as 絵覆絵専 zorder 200:
        pos (-105,-105)
        linear 20 pos (-229,-126)
    with Dissolve((1000.0+1000.0)/1000)
    pause (500.0/1000)
    voice "voice/a01/3100010a02.opus"
    aoi "Не хочешь... подзарядиться?"
    "Тогда, на крыше..."
    "Всё, начиная от её позы и заканчивая внешним видом..."
    "И всё то, что она говорила..."
    "Всё это было точь-в-точь как в той сцене из мобильной игры."
    "Она как будто вылезла из экрана прямиком в реальную жизнь."
    "И ещё там протагониста звали «Шиничи Сузуки»..."
    "Нет, не может быть."
    "У меня нет способности превращать видеоигры в реальность, так ведь?.."
    hide 絵覆絵専 with Dissolve(600.0/1000)
    xy "Воу-воу, приятель."
    "Теперь Я становлюсь заядлым геймером!"
    "Та визуальная новелла была на телефоне Муко."
    "Скорее всего, она просто запомнила все диалоги."
    "Возможно, она просто воплощает их в жизнь!"
    "И она, скорее всего, специально указала моё имя в качестве имени протагониста!"
    "...Но почему?"
    xy "Давай забудем."
    "У меня сильно разыгралось воображение."
    "Я накинул одеяло поверх своей головы и закрыл глаза."
    stop bgm fadeout (4000/1000)
    show expression Solid("000000") as 絵色黒 zorder 11000
    with Dissolve((3000.0+1000.0)/1000)
    pause (2000/1000)
    "Той ночью, в своих снах, я увидел Миюки..."
    "..И мы там поцеловались."
    pause (1000/1000)
    scene expression Solid("FFFFFF") as 絵色黒 zorder 11000
    with Dissolve((3000+1000)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
