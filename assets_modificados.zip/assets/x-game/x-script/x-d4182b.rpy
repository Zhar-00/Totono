label d4182b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d4183.nss"
    return
label d4182b:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    with Dissolve(500.0/1000)

    "Хару-чан была самой маловероятной свидетельницей в мире."

    "И всё же, судя по её словам, Аой заглядывала в магазин за углом несколько раз, чтобы купить что-нибудь... даже после своего предполагаемого исчезновения."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
