label a1161_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010600_2_学校教室"]=True
    $ persistent.imagelog["bg010700_1_学校廊下"]=True
    queue bgm "ttb25"
    $ PreGameName = GameName
    $ GameName = "a1171.nss"
    return
label a1161:
    scene expression ("cg/bg/"+imagename["bg010700_1_学校廊下"]+".jpg")
    with Dissolve((0.0)/1000)
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    pause (500/1000)
    $ St("MR",300,30,0,"st向日アオイ電波_制服_挙手_shout")
    voice "voice/a11/6100010a02.opus"
    aoi "Миюки!"
    voice "voice/a11/6100020a02.opus"
    aoi "Давай пообедаем вме—"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,-30,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a11/6100030a01.opus"
    mx "Извини, у меня уже есть планы с другими друзьями."
    voice "voice/a11/6100040a02.opus"
    aoi "Оу..."
    voice "voice/a11/6100050a01.opus"
    mx "А ещё, я бы предпочла, чтобы ты не обращалась ко мне таким образом."
    voice "voice/a11/6100060a02.opus"
    aoi "Поняла."
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    show expression Solid("000000") as 絵色黒
    with Dissolve((1000.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve((0.0)/1000)
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    pause (1000/1000)
    with Dissolve((1000.0+0.0)/1000)
    pause (500/1000)
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_挙手_normal")
    voice "voice/a11/6100070a02.opus"
    aoi "Миюки! Насчёт домашки по математике—"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,30,0,"st曽根美雪_制服_通常_normal")
    voice "voice/a11/6100080a01.opus"
    mx "Нет смысла делать её, если не разберёшься в ней сама. Если ты увидишь мою домашку, тебе это не даст никакой пользы."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a11/6100090a02.opus"
    aoi "Хорошо."
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a11/6100100a02.opus"
    aoi "Миюки, ты очень добрая."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,30,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a11/6100110a01.opus"
    mx "Не жди того, что я буду нянчиться с тобой."
    voice "voice/a11/6100120a01.opus"
    mx "И ещё, не могла бы ты перестать меня так называть?"
    voice "voice/a11/6100130a02.opus"
    aoi "Прости."
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    with Dissolve((1000.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010500_1_学校昇降口"]+".jpg")
    with Dissolve((0.0)/1000)
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    pause (1000/1000)
    with Dissolve((1000.0+0.0)/1000)
    pause (500/1000)
    $ St("MR",300,30,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/a11/6100140a02.opus"
    aoi "Миюки, не хочешь составить мне компанию в арт-про—"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,-30,0,"st曽根美雪_制服_通常_normal")
    voice "voice/a11/6100150a01.opus"
    mx "Перестань меня так называть."
    voice "voice/a11/6100160a02.opus"
    aoi "Прости."
    $ St("ML",300,-30,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a11/6100170a01.opus"
    mx "И вообще, у меня уже есть один друг, которому я всегда составляю компанию."
    voice "voice/a11/6100180a02.opus"
    aoi "Тогда что насчёт зав—"
    voice "voice/a11/6100190a01.opus"
    mx "Ни завтра, ни когда-либо ещё. Иди попроси кого-нибудь другого."
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    with Dissolve((1000.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010600_2_学校教室"]+".jpg")
    with Dissolve((0.0)/1000)
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    pause (1000/1000)
    with Dissolve((1000.0+0.0)/1000)
    pause (500/1000)
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a11/6100200a02.opus"
    aoi "Миюки! Давай проведём время вместе после школы."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,30,0,"st曽根美雪_制服_通常_pride")
    voice "voice/a11/6100210a01.opus"
    mx "Ты опять это сделала."
    voice "voice/a11/6100220a02.opus"
    aoi "Прости."
    $ St("MR",300,30,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a11/6100230a01.opus"
    mx "У меня сегодня репетиция, так что я сомневаюсь, что у меня будет время на это."
    voice "voice/a11/6100240a02.opus"
    aoi "Аой может подождать."
    voice "voice/a11/6100250a01.opus"
    mx "Репетиция закончится довольно поздно."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/a11/6100260a02.opus"
    aoi "Аой всё ещё может подождать."
    voice "voice/a11/6100270a01.opus"
    mx "Я, наверное, после этого ещё проведу время с остальными членами театрального клуба."
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a11/6100280a02.opus"
    aoi "Мы друзья."
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/a11/6100290a02.opus"
    aoi "Так что Аой подождёт."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,30,0,"st曽根美雪_制服_通常_sigh")
    voice "voice/a11/6100300a01.opus"
    mx "Ха-а... Ну, как хочешь."
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    hide StMR with Dissolve(200.0/1000)
    pause (1000/1000)
    stop se fadeout (1000.0/1000)
    "Положив себе на плечо свою бейсбольную биту, Миюки, не оборачиваясь, вышла из класса."
    stop bgm fadeout (2500.0/1000)
    stop se fadeout (2000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    hide 絵色黒
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
