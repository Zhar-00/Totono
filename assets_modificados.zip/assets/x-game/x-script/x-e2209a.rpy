label e2209a_MAIN:
    call expression GameName
    $ persistent.imagelog["eve2209aアオイコンドーム咥えくぱぁa"]=True
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label e2209a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)

    "Я выбрал игру на экране приложений."
    stop bgm fadeout (3000.0/1000)
    scene expression ("cg/ef/"+imagename["efgaゲーム画面ロード"]+".jpg") as 絵場面推移 at center
    with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1.5)
    pause 1
    image 絵効果 = im.MatrixColor(("cg/ef/"+imagename["effiテレビ画面用効果フィルター"]+".jpg"),im.matrix.invert())
    show 絵効果 behind 絵場面推移:
        alpha 0.2
    show expression ("cg/bg/"+imagename["bg110300_3_マンション寝室"]+".jpg") as 絵専 behind 絵場面推移, 絵効果 at center
    hide 絵場面推移 with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1)
    show expression ("cg/bg/"+imagename["bg110300_3_マンション寝室"]+".jpg")
    voice "voice/e22/09a00010a02.opus"

    aoi "\"Поняла! Хару-чан!\""
    voice "voice/e22/09a00020b03.opus"

    c "\"В-в чём дело?..\""

    "Аой-семпай снова подняла свою руку в воздух, как и всегда."
    show expression ("cg/ev/"+imagename["eve2209aアオイコンドーム咥えくぱぁa"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(500.0/1000)
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    pause (1000/1000)
    voice "voice/e22/09a00030a02.opus"

    aoi "\"Займись со мной сексом.\""
    voice "voice/e22/09a00040b03.opus"

    c "\"Ч-что? Но—\""
    voice "voice/e22/09a00050a02.opus"

    aoi "\"Нет смысла сдерживаться.\""
    voice "voice/e22/09a00060a02.opus"

    aoi "\"Твой член уже твёрдый. И с него капает.\""

    "Она права."

    "После того, как она энергично мастурбировала мне, из моей головки начала сочиться чистая жидкость."

    "И теперь она стояла передо мной абсолютно голая."
    voice "voice/e22/09a00070a02.opus"

    aoi "\"Ты не хочешь?\""
    voice "voice/e22/09a00080a02.opus"

    aoi "\"Киска Аой уже вся мокрая.\""

    "Она держала презерватив в своих губах."

    "Её бёдра двигались от нетерпения."

    "Воспользовавшись своими пальцами, она раздвинула другие свои губы пошире, чтобы мне было всё видно."

    "Её глаза плавали от желания."

    "У меня сегодня не было репетиции, и она так отчаянно хотела увидеть меня."

    "Она настояла на том, чтобы прийти ко мне домой..."

    "...и попросила меня переодеться прямо перед ней."

    "Она с самого начала добивалась этого?.."
    scene expression ("cg/ef/"+imagename["efgaゲーム画面ロード"]+".jpg") as 絵場面推移 at center
    with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1.5)
    pause 1
    hide 絵専上二 with None
    hide 絵場面推移 with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1)
    hide 絵専
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)

    xy "\"Что... ЭТО такое?\""
    voice "voice/e22/09a00090a01.opus"

    mx "\"Это побочный рут.\""
    show expression ("cg/bg/"+imagename["bg110110_1_マンションリビングソファー"]+".jpg")
    $ St("C",300,0,30,"bu曽根美雪_制服_通常_smile")
    with Dissolve(300.0/1000)
    pause (200/1000)

    "И тут я увидел, как Миюки уже сидела рядом со мной на диване и смотрела на экран телефона через моё плечо."
    voice "voice/e22/09a00100a01.opus"

    mx "\"Главного героя не было на этой сцене, поэтому она показана с другой точки обзора.\""

    "«Хару-чан»... я знаю кое-кого по имени Хару в театральном клубе в реальности, но она определённо девушка."

    "Тем временем, Хару-чан в игре был таким же кротким, как и она, но он определённо парень."

    "...Стоп, что?"

    xy "\"Этот персонаж занимается сексом с другими людьми, кроме протагониста?\""
    $ St("C",300,0,30,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/e22/09a00110a01.opus"

    mx "\"Немыслимо, правда?\""
    voice "voice/e22/09a00120a01.opus"

    mx "\"А ведь совсем недавно она сошлась и с ним тоже.\""
    scene expression ("cg/ef/"+imagename["efgaゲーム画面ロード"]+".jpg") as 絵場面推移 at center
    with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1.5)
    pause 1
    image 絵効果 = im.MatrixColor(("cg/ef/"+imagename["effiテレビ画面用効果フィルター"]+".jpg"),im.matrix.invert())
    show 絵効果 behind 絵場面推移:
        alpha 0.2
    show expression ("cg/ev/"+imagename["eve2209aアオイコンドーム咥えくぱぁa"]+".jpg") as 絵専 behind 絵場面推移, 絵効果 at center
    hide 絵場面推移 with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1)
    show expression ("cg/ev/"+imagename["eve2209aアオイコンドーム咥えくぱぁa"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/bg/"+imagename["bg110300_3_マンション寝室"]+".jpg")
    with Dissolve(500.0/1000)
    voice "voice/e22/09a00130a02.opus"

    aoi "\"Аой наденет презерватив за тебя.\""

    "Она начала вскрывать пачку с презервативом."

    "Тем временем, мой ствол продолжал набухать."
    voice "voice/e22/09a00140b03.opus"

    c "\"Семпай... Зачем ты делаешь это?\""

    "Я не мог не спросить её об этом."
    voice "voice/e22/09a00150b03.opus"

    c "\"Я ведь тебе даже не интересен, так ведь?\""
    voice "voice/e22/09a00160b03.opus"

    c "\"Так почему ты пытаешься заняться со мной сексом?\""
    voice "voice/e22/09a00170b03.opus"

    c "\"Я просто не могу—!\""
    hide 絵専
    show expression ("cg/bg/"+imagename["bg110110_1_マンションリビングソファー"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,30,"bu曽根美雪_制服_通常_pride")
    scene expression ("cg/ef/"+imagename["efgaゲーム画面ロード"]+".jpg") as 絵場面推移 at center
    with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1.5)
    pause 1
    hide 絵専上二 with None
    hide 絵場面推移 with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1)
    hide 絵専
    scene expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    with Dissolve(500.0/1000)
    voice "voice/e22/09a00180a01.opus"

    mx "\"Ого. Она собирается заняться сексом с каким-то другим парнем, который ей даже не нравится?\""
    $ St("C",300,0,30,"bu曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/e22/09a00190a01.opus"

    mx "\"Какая невероятно распутная героиня.\""

    xy "\"...Мы пока не знаем этого.\""
    $ St("C",300,0,30,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e22/09a00200a01.opus"

    mx "\"Хо-хо? Ты доверяешь ей, да?\""
    voice "voice/e22/09a00210a01.opus"

    mx "\"После всего этого, ты по-прежнему думаешь, что она не предаст протагониста?\""
    return
    return
label e2209a_SELECT:
    $ lastsel = "e2209a_SELECT"
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110110_1_マンションリビングソファー"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,30,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(0.0/1000)
    menu:
        "Она его предаст":
            $ SetChoiceSelect = 0
        "Она его не предаст":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ persistent.miyuki_love += 1
        $ GameName = "e2209b.nss";
    elif SetChoiceSelect==1:
        $ persistent.miyuki_love -= 1
        $ GameName = "e2209c.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
