label a5121_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010800_1_学校体育館"]=True
    $ PreGameName = GameName
    if aoi_sex0 == True:
        $ GameName = "c5122.nss"
    else:
        $ GameName = "a5122.nss"
    return
label a5121:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010500_1_学校昇降口"]+".jpg")
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    pause (700/1000)
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    pause (700/1000)
    xy "Классный час скоро начнётся, знаешь ли."
    voice "voice/a51/2100010a01.opus"
    mx "Это не так важно."
    xy "Эй! БОЛЬНО ведь! Перестань меня тянуть с такой силой!"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010800_1_学校体育館"]+".jpg")
    pause (1000/1000)
    $ sename = "se物体_ドア体育_開く01"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(800.0/1000)
    pause (300/1000)
    "В старом спортзале стояла мёртвая тишина."
    "Очевидно, первого урока ни у кого здесь сегодня не было."
    show expression ("cg/bg/m/"+imagename["bg010800_1_学校体育館_m"]+".jpg") as 絵背景 zorder 100 at truecenter
    stop se fadeout (0.0/1000)
    with Dissolve(300.0/1000)
    pause (200/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    "Миюки потащила меня к самому центру баскетбольной площадки."
    xy "Ну, так чего тебе надо?"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
