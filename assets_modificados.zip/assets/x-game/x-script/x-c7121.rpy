label c7121_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label c7121:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    pause (2000/1000)
    xy "\"Ладно... Они ушли.\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    "Теперь в гостиной остались только я и Аой."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c71/2100010a02.opus"
    aoi "\"Буп-буп...\""
    "Её глаза выглядели как два больших блюдца."
    "Как будто все её надежды были разбиты вместе с её телефоном."
    "Я сделал глубокий вдох, чтобы успокоиться."
    "А потом я подошёл к Аой поближе."
    xy "\"Пожалуйста, скажи мне...\""
    xy "\"Почему ты меня предала?..\""
    voice "voice/c71/2100020a02.opus"
    aoi "\"Аой...\""
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    voice "voice/c71/2100030a02.opus"
    aoi "\"Аой - романтический выбор.\""
    xy "\"......\""
    voice "voice/c71/2100040a02.opus"
    aoi "\"Бог создал меня как персонажа в этой игре—\""
    xy "\"ЗАТКНИСЬ НАХУЙ!\""
    "Прежде, чем я смог остановить себя, я закричал на неё."
    xy "\"Меня уже ТОШНИТ от твоей ёбаной видеоигровой херни!\""
    voice "voice/c71/2100050a02.opus"
    aoi "\"Это правда.\""
    "Её взгляд был непоколебим."
    voice "voice/c71/2100060a02.opus"
    aoi "\"Бог настоящий.\""
    voice "voice/c71/2100070a02.opus"
    aoi "\"Бог - это понятие.\""
    voice "voice/c71/2100080a02.opus"
    aoi "\"Слияние всевозможных любовных интересов в любом существующем мире.\""
    voice "voice/c71/2100090a02.opus"
    aoi "\"Абстракция.\""
    voice "voice/c71/2100100a02.opus"
    aoi "\"Аой - олицетворение этого Бога.\""
    voice "voice/c71/2100110a02.opus"
    aoi "\"Аватар, извлечённый из огромной базы данных и оптимизированный для того, чтобы идеально соответствовать этому миру.\""
    voice "voice/c71/2100120a02.opus"
    aoi "\"С одной единственной целью.\""
    voice "voice/c71/2100130a02.opus"
    aoi "\"Преследовать как можно больше главных героев.\""
    voice "voice/c71/2100140a02.opus"
    aoi "\"И собрать сценки всех событий.\""
    voice "voice/c71/2100150a02.opus"
    aoi "\"Этот «рут Аой», на котором сейчас ТЫ находишься...\""
    voice "voice/c71/2100160a02.opus"
    aoi "\"...также является и «рутом Шиничи» для Бога.\""
    voice "voice/c71/2100170a02.opus"
    aoi "\"Как только Бог добился секса с Шиничи...\""
    voice "voice/c71/2100180a02.opus"
    aoi "\"Рут Шиничи считается пройденным.\""
    voice "voice/c71/2100190a02.opus"
    aoi "\"А без новых сценок, само существование Аой бессмысленно.\""
    voice "voice/c71/2100200a02.opus"
    aoi "\"Моя батарейка разрядится окончательно, и мой сигнал перестанет доходить, а это чревато невозможностью сохранить игру... из-за чего Аой просто исчезнет.\""
    voice "voice/c71/2100210a02.opus"
    aoi "\"Поэтому Аой начала проходить рут Хару-чан.\""
    voice "voice/c71/2100220a02.opus"
    aoi "\"Именно поэтому Аой и изменила тебе.\""
    "Её выражение лица нисколько не изменилось."
    "Она выпалила это всё так, будто это была самая обычная вещь в мире."
    "Как будто она читала сценарий."
    voice "voice/c71/2100230a02.opus"
    aoi "\"Но именно здесь мы и попрощаемся.\""
    voice "voice/c71/2100240a02.opus"
    aoi "\"Пока-пока.\""
    pause (500/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(400.0/1000)
    pause (500/1000)
    "Она молча развернулась."
    "А потом начала уходить."
    "Её неуверенные шаги становились всё тише."
    return
    return
label c7121_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    menu:
        "Аой врёт":
            $ SetChoiceSelect = 0
        "Я уже не знаю, чему верить":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "c7122.nss"
    else:
        $ GameName = "d7122.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
