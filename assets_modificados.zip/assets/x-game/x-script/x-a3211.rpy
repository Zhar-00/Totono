label a3211_MAIN:
    call expression GameName
    $ persistent.imagelog["bg030300_3_自宅リビング"]=True
    $ PreGameName = GameName
    if meet_aoi == True:
        $ GameName = "c3212.nss"
    else:
        $ GameName = "a3212.nss"
    return
label a3211:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    with Dissolve(1000.0/1000)
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_normal")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    voice "voice/a32/1100010a02.opus"
    aoi "Иру!"
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a32/1100020a02.opus"
    aoi "Пей."
    play voc "a32/1100030b04"
    "Аой нежно придавила кончик шприца для кормления ко рту Иру."
    play voc "a32/1100040b04"
    voice "voice/a32/1100050a02.opus"
    aoi "......"
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a32/1100060a02.opus"
    aoi "Похоже, Иру очень понравилось!"
    xy "Да, без шуток."
    "Это маленькое создание, должно быть, сильно проголодалось."
    "Иру крепко схватился за кончик шприца."
    "Мы не смогли найти ни одного магазина, где могли бы продавать детские бутылочки, но, по крайней мере, эта штука, похоже, отлично справляется с этой задачей."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
