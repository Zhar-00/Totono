label a6143_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a6151.nss"
    return
label a6143:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg010210_1_学校屋上屋根向"]+".jpg")
    with Dissolve(500.0/1000)
    "Я не мог заставить себя подняться на крышу снова."
    "Это место было охвачено воспоминаниями о нашей дружбе."
    "Это место Аой описывала как центр вселенной."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1500.0+1000.0)/1000)
    pause (500/1000)
    "Но в то же время, я не собирался искать её."
    "Да и всё равно она, наверное, не хочет, чтобы я искал её."
    "Она отвергла нашу дружбу."
    "Не то, чтобы я винил её за это."
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    $ sename = "se環境_ガヤ_学校屋上授業中"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(1000.0/1000)
    "Но в реальной жизни нет никаких контрольных точек."
    "У меня не было возможности загрузить игру и начать сначала."
    "Но всё же, я должен продолжать двигаться вперёд."
    "Я буду жить спокойной жизнью."
    "Без каких-либо проблем."
    "Без неразумных ожиданий."
    "Просто спокойная, посредственная жизнь."
    "Честная жизнь."
    "Мне не нужно быть на вершине мира."
    "Я не должен стоять в центре вселенной."
    "Не все должны быть такими особенными, верно?"
    stop se fadeout (2000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
