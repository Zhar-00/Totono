label a1111_MAIN:
    call expression GameName
    $ persistent.imagelog["eva1111アオイ受信中a"]=True
    $ persistent.imagelog["eva1111アオイ受信中b"]=True
    $ persistent.imagelog["bg010400_1_学校校門"]=True
    $ persistent.imagelog["bg010500_1_学校昇降口"]=True
    $ persistent.imagelog["bg010600_1_学校教室"]=True
    $ persistent.imagelog["bg030100_1_自宅自室"]=True
    $ persistent.imagelog["bg030200_1_自宅玄関"]=True
    $ persistent.imagelog["bg040100_1_街通学路"]=True
    $ PreGameName = GameName
    $ GameName = "a1121.nss"
    return
label a1111:
    $ tz(1)
    show expression ("cg/bg/"+imagename["bg030100_1_自宅自室"]+".jpg")
    show expression Solid("FFFFFF") as 絵色黒
    show expression ("cg/ef/"+imagename["efbg自宅自室天井昼消灯"]+".jpg") as 絵演 behind 絵色黒 at center
    $ sename = "se物体_アラーム_鳴る01"
    play se sedict[sename]
    pause (1000/1000)
    hide 絵色黒 with Dissolve(2000.0/1000)
    pause (500/1000)
    xy "Хыа-а-а…"
    $ sename = "se物体_照明_スイッチ"
    play se sedict[sename]
    pause (500/1000)
    $ sename = "se人体_動作_衣擦れ01"
    play se sedict[sename]
    hide 絵板写
    with Dissolve(1000.0/1000)
    $ renpy.music.play("ttb04",channel = "bgm", if_changed = True)
    "Начался новый день."
    show expression ("cg/bg/"+imagename["bg030200_1_自宅玄関"]+".jpg")
    $ sename = "se人体_足音_階段自宅上がる01"
    play se sedict[sename]
    hide 絵板写
    with Dissolve(1000.0/1000)
    "Боже, тот сон, который приснился мне вчера ночью, был довольно странным..."
    show expression ("cg/bg/"+imagename["bg040100_1_街通学路"]+".jpg")
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]
    hide 絵板写
    with Dissolve(1000.0/1000)
    "Но я знаю, что сегодня будет такой же день, что и всегда."
    show expression ("cg/bg/"+imagename["bg010400_1_学校校門"]+".jpg")
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    hide 絵板写
    with Dissolve(1000.0/1000)
    "Очередной обыденный—"
    show expression ("cg/bg/"+imagename["bg010500_1_学校昇降口"]+".jpg")
    hide 絵板写
    with Dissolve(1000.0/1000)
    pause (200/1000)
    stop bgm fadeout (2000/1000)
    $ sename = "se物体_靴箱_開ける"
    play se sedict[sename]
    pause (500/1000)
    $ sename = "se物体_紙_落ちる"
    play se sedict[sename]
    pause (300/1000)
    xy "...А?"
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")

    with Dissolve(1000.0/1000)
    pause (500/1000)
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    hide 絵板写
    with Dissolve(1000.0/1000)
    pause (200/1000)
    "Письмо выпало из моего обувного шкафчика."
    $ sename = "se物体_紙_手紙開く"
    play se sedict[sename]
    pause (300/1000)
    "Я донёс письмо до своей парты и аккуратно распаковал его, слегка ужаснувшись от того, что ожидало меня внутри него."
    show expression Solid("000000") as 絵色黒
    with Dissolve((400.0+1000.0)/1000)
    pause (300/1000)
    "—Встретимся на крыше в обед."
    hide 絵色黒
    show expression Solid("FFFFFF") as 絵色白
    pause (30/1000)
    with vpunch
    $ renpy.vibrate(.3)
    hide 絵色白
    with Dissolve(70.0/1000)
    voice "voice/a11/1100010b01.opus"
    xtl "УМРИ!"
    xy "А-А-АХ!"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(0.0/1000)
    show expression ("cg/bg/m/"+imagename["bg010600_1_学校教室_m"]+".jpg") as 絵演背景:
        xalign .5
        ypos -230
    hide 絵板写
    with Dissolve(300.0/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    xy "Ютаро?! Ты подсматривал?!"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100020b01.opus"
    xtl "Сначала я узнал, что вы с Сонэ-сан старые друзья... а потом я узнал, что ты не только пытался изменить ей с Муко..."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100030b01.opus"
    xtl "Но более того, ты также получил и это старомодное любовное письмо?!"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_cry")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100040b01.opus"
    xtl "Ты норми, да? ДА! Ты чёртов НОРМИ!"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_gag")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100050b01.opus"
    xtl "Твой бог, возможно, и простит тебя, но как капитан клуба «Ребята и мечты», я, Ютаро Акебоно, НИКОГДА ТЕБЯ НЕ ПРОЩУ!!!"
    xy "Не суй свой нос в чужие письма."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100060b01.opus"
    xtl "Прости!"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100070b01.opus"
    xtl "Но ты знаешь, что подобные вещи могут повлиять на дальнейшее существование клуба!"
    "А, да. Клуб «Ребята и мечты»."
    "Не волнуйся... для меня он тоже не несёт никакого смысла."
    "Ютаро описывает свой клуб как «клуб парней, которые хотят воплотить свои мечты в реальность»."
    "Лично я понятия не имею, что это означает."
    "Сам клуб, на самом деле, существует довольно долгое время, но с таким названием я не могу себе представить, как много человек будет готово вывернуться наизнанку, лишь бы вступить в него."
    "Что неудивительно, как только началась весна, Ютаро остался единственным членом в клубе, а сам клуб был на грани расформирования."
    "В конечном счёте, он убедил меня «вступить» в него (только на словах) лишь ради того, чтобы поддерживать жизнь клуба."
    xy "Не так уж и важно, что я делаю, пока я ещё состою в клубе, верно?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100080b01.opus"
    xtl "Хе-хе-хе... Дружище, ты не можешь воплотить в реальность ту мечту, в которой уже живёшь."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100090b01.opus"
    xtl "В тот момент, когда ты достиг романтической самореализации и стал норми, твоё членство аннулировано! Это клятва, данная парнями из РиМ!!!"
    xy "Может, расформировать клуб будет лучше?.."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100100b01.opus"
    xtl "Я тоже начал задумываться над этим."
    "Ютаро, возможно, и выглядел глупым, но он отнёсся к этому со всей серьёзностью."
    voice "voice/a11/1100110b01.opus"
    xtl "Не вижу смысла разрушать отношения ради поддержания жизни своего клуба, понимаешь?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    stop bgm fadeout (2000/1000)
    voice "voice/a11/1100120b01.opus"
    xtl "Вот."
    "Он положил что-то на мою парту."
    show expression ("cg/ef/"+imagename["efbg雄太郎のスマフォ"]+".jpg") as 絵演効果 zorder 1000 at center
    with ImageDissolve("cg/data/slide_04_00_1.png",(500.0+1000.0)/1000)
    pause (300/1000)
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    xy "Это же та игра, которую я видел вчера!"
    "После того, как Муко ушла, Ютаро требовал объяснить все подробности произошедшего."
    "Очевидно, я не мог рассказать ему всё то, что говорила Миюки, но я рассказал ему про визуальную новеллу на её телефоне."
    with Dissolve((500.0+0.0)/1000)
    xy "Я мало чего смог объяснить тебе, чтобы ты мог продолжить поиски... Как ты её нашёл?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100130b01.opus"
    xtl "А, Рюджиро много чего знает об этих играх."
    xy "Кто такой Рюджиро?"
    voice "voice/a11/1100140b01.opus"
    xtl "Мой младший брат."
    voice "voice/a11/1100150b01.opus"
    xtl "Ты сказал, что та героиня выглядела точь-в-точь как Муко, поэтому я показал ему её фотографию. И этого было достаточно."
    with Dissolve((300.0+1000.0)/1000)
    "Я посмотрел на девушку на экране."
    show expression ("cg/ev/"+imagename["eva1111アオイ受信中a"]+".jpg") as 絵専 zorder 1100 at center
    with Dissolve((300.0+1000.0)/1000)
    hide 絵演効果
    voice "voice/a11/1100160a02.opus"
    aoi "......"
    "А потом я перевёл взгляд на девушку, сидевшую в нескольких партах от меня."
    voice "voice/a11/1100170a02.opus"
    aoi "......"
    "Они были абсолютно одинаковыми."
    "Идеальное воссоздание из двумерной модели."
    "Если бы мне сказали, что разработчики опирались на её внешность, когда создавали её, я бы не засомневался в этом ни на секунду."
    "Муко тихо сидела за своей партой. Она не пыталась поговорить с кем-либо и не играла на телефоне; она просто уставилась в никуда."
    "Пока остальные обсуждали своё утро с друзьями, пространство вокруг неё было абсолютно бесшумным, словно вакуум."
    "Как будто она сосредоточила всё своё существование на улавливании мельчайших радиоволн из самых дальних уголков космоса..."
    show expression ("cg/ev/"+imagename["eva1111アオイ受信中b"]+".jpg") as 絵専 zorder 1100 at center
    show expression ("cg/ev/"+imagename["eva1111アオイ受信中b"]+".jpg") as 絵専二 zorder 1100 at center
    voice "voice/a11/1100180a02.opus"
    aoi "Поняла!"
    "А потом она резко подняла свою руку вверх."
    voice "voice/a11/1100190a02.opus"
    aoi "Передача получена."
    voice "voice/a11/1100200a02.opus"
    aoi "Расписание разработки подтверждено."
    voice "voice/a11/1100210a02.opus"
    aoi "Рут уже в прогрессе."
    hide 絵専二 with Dissolve(0.0/1000)
    "Она болтала всё это не кому-то конкретно."
    "Но наш класс уже привык к её выходкам."
    "Никто не находил её поведение удивительным."
    "По крайней мере, у меня было такое чувство."
    xy "Ну и чудачка."
    voice "voice/a11/1100220b01.opus"
    xtl "Ничего против неё не имею, но... думаю, ты метишь куда-то не туда."
    hide 絵専
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(300.0/1000)
    pause (200/1000)
    voice "voice/a11/1100230b01.opus"
    xtl "Она просто сплошная головная боль."
    xy "А? Я не говорил, что так сильно заинтересован ей."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100240b01.opus"
    xtl "Тогда почему ты спрашиваешь про неё?"
    xy "Она пыталась поцеловать меня на крыше! Разумеется, мне после этого стало бы хоть немного любопытно, понимаешь?"
    xy "Но это всё."
    voice "voice/a11/1100250b01.opus"
    xtl "Ради твоего же блага, я на это очень надеюсь."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100260b01.opus"
    xtl "Я слышал довольно плохие слухи, чувак."
    xy "Например?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100270b01.opus"
    xtl "Говорят, она полная шлюха."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100280b01.opus"
    xtl "Разумеется, я не купился на такое!"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100290b01.opus"
    xtl "В смысле, с ней невозможно разговаривать, не говоря уже о чём-либо ещё."
    $ st_timezone = "夕"
    show expression im.AlphaMask(("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg"),"cg/data/circle_02_00_1.png") as 絵覆絵背景 zorder 2005 at center
    $ St("X",2100,0,0,"st向日アオイ電波_制服_通常_normal")
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵色黒 zorder 2105 at center
    with Dissolve((0.0+300.0)/1000)
    hide 絵板写 with Dissolve(500.0/1000)
    "После вчерашнего наблюдения её выходок, присущих заядлому геймеру, я согласился с ним."
    $ st_timezone = "昼"
    hide StX
    show expression ("cg/ev/"+imagename["eva0113アオイ屋上覆い被さりa"]+".jpg") as 絵覆絵専 zorder 2100 at center
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(0.0/1000)
    hide 絵板写 with Dissolve(300.0/1000)
    "Она выглядела так, будто находилась в своём маленьком мирке... или, по крайней мере, совсем не обращала внимание на людей вокруг себя."
    "Она не может вести разговор, чтобы спасти свою жизнь."
    hide 絵覆絵専
    hide 絵色黒
    hide 絵専
    hide 絵覆絵背景
    hide 絵板写 with Dissolve(600.0/1000)
    xy "Эй, Ютаро?"
    xy "Эта игра доступна в магазине приложений?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_normal")
    with Dissolve(0.0/1000)
    voice "voice/a11/1100300b01.opus"
    xtl "Можешь взять его себе."
    xy "Что? Телефон?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100310b01.opus"
    xtl "Да. Рюджиро недавно себе новый купил."
    voice "voice/a11/1100320b01.opus"
    xtl "В нём нет сим-карты, так что ты не можешь кому-либо по нему звонить, но ты можешь скачивать игры без проблем."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100330b01.opus"
    xtl "По его словам, это культовая классическая NTR-игра."
    xy "NTR? Это ещё что?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100340b01.opus"
    xtl "Как будто я знаю! Это какая-то технология в визуальных новеллах, наверное."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100350b01.opus"
    xtl "Но я от этого получаю кое-какую ауру РиМ!"
    xy "А... понимаю..."
    stop bgm fadeout (3000/1000)
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (1000/1000)
    show expression ("cg/ev/m/"+imagename["eva0121美雪さんおはようございます_m"]+".jpg") as 絵専 zorder 1000:
        xalign .5
        ypos -80
    show expression ("cg/ev/l/"+imagename["eva0121美雪さんおはようございます_l"]+".jpg") as 絵専二 zorder 1100:
        xpos -100
        yalign .999
        linear 15 xpos 0
    show expression Solid("FFFFFF") as 絵色白 zorder 5000
    pause (100/1000)
    pause (100/1000)
    hide 絵色白 with Dissolve(300.0/1000)
    pause (1000/1000)
    pause (500/1000)
    voice "voice/a11/1100360a01.opus"
    mx "Доброе утро!"
    hide 絵専二 with Dissolve(1)
    "Голос Миюки прошёлся эхом по всему классу."
    "И после этого все девушки начали собираться вокруг неё в гигантский круг."
    "Они начали задавать ей вопросы так, будто она увидела вчерашнюю премьеру сезона или услышала про новый магазин, который только что открылся в городе."
    "Вне зависимости от темы вопроса, Миюки отвечала каждой с грацией, утончённостью и улыбкой."
    "И после этого она начала озарять всё вокруг своей улыбкой, привлекая тем самым внимание многих парней в нашем классе."
    "Такое происходит каждое утро; и каждый раз это заставляет меня с болью осознавать расстояние между нами."
    "Миюки Сонэ была королевой, а я – никем."
    show expression ("cg/ev/"+imagename["eva0121美雪さんおはようございます"]+".jpg") as 絵専 zorder 1000 at center
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(0.0/1000)
    hide 絵板写 with Dissolve(500.0/1000)
    voice "voice/a11/1100370b01.opus"
    xtl "Одинокий цветок, расцветающий в огромной пустыне этого кампуса!.."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_shy")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100380b01.opus"
    xtl "Боже... Она так прекрасна..."
    xy "Ага..."
    with Dissolve((500.0+1000.0)/1000)
    "Здесь, в классе, она была звездой шоу."
    "Но я знал, что она просто играла свою роль."
    "Как её старый друг, я знаю, какая она на самом деле: привередливая и откровенная."
    hide 絵専 with Dissolve(500.0/1000)
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100390b01.opus"
    xtl "Ч-чувак! Ты видел это?!"
    xy "М-м?"
    voice "voice/a11/1100400b01.opus"
    xtl "Сонэ-сан только что посмотрела на нас!"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_shy")
    with Dissolve(200.0/1000)
    voice "voice/a11/1100410b01.opus"
    xtl "Ха-а, я не могу. Я схожу от неё с ума! А если я хочу воплотить свою мечту в реальность, я должен признаться ей в любви. Это судьба!"
    xy "Удачи. Я болею за тебя, чел."
    "И всё же, даже когда я сказал ему это..."
    show expression ("cg/ev/"+imagename["eva1111アオイ受信中a"]+".jpg") as 絵専 zorder 1100 at center
    with Dissolve((600.0+1000.0)/1000)
    voice "voice/a11/1100420a02.opus"
    aoi "Буп-буп..."
    "...Я не мог не посмотреть на Муко краем глаза."
    "На фоне радостной болтовни, она сидела абсолютно неподвижно, настоящая картина одиночества."
    pause (1000/1000)
    scene expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (500/1000)
    pause (1000/1000)
    with dissolve
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
