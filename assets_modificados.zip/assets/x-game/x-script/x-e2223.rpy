label e2223_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2223:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    "Сладость пирожного, вкупе со сладкими словами Миюки..."
    "Вместе они создавали магическое заклинание, которое отнимало у меня все силы на размышления."
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/2300010a01.opus"
    mx "\"А, точно. Время для твоего подарка.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/e22/2300020a01.opus"
    mx "\"Ну... Помнишь, о чём я тебя спрашивала?\""

    xy "\"Хм? Что ты имеешь в виду?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/e22/2300030a01.opus"
    mx "\"Ну, знаешь... То самое.\""
    xy "\"Что то самое?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/2300040a01.opus"
    mx "\"Ты знаешь про то самое.\""
    xy "\"......Наверное?\""
    xy "\"Э-э-э-эм... Можешь просветить меня?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/e22/2300050a01.opus"

    mx "Угх! Боже! Ты забыл?!"
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e22/2300060a01.opus"
    mx "\"Я спрашивала тебя, нравятся ли тебе формы горничных!\""
    xy "\"А... точно. Это. Да.\""
    "...По правде говоря, я всё равно не помню этого."
    "Когда она спрашивала меня об этом?.."
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/2300070a01.opus"
    mx "\"Т-так или иначе... я тут подумала...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/e22/2300080a01.opus"
    mx "\"И решила надеть форму горничной на твой день рождения!\""
    xy "\"Что?\""
    if (    persistent.EmotionalMusic > 4 or persistent.world_recreate or persistent.eternal_day):
        $ GameName = "e2224b.nss";
    else:
        $ GameName = "e2224a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
