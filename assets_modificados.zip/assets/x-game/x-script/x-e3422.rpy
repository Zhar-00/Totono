label e3422_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010220_9_学校屋上屋根向全景"]=True
    $ persistent.imagelog["bg900200_9_雰囲気街並み"]=True
    $ persistent.imagelog["bg010210_3_学校屋上屋根向"]=True
    $ persistent.imagelog["efbgアオイのスマフォ操作着信美雪"]=True
    $ PreGameName = GameName
    return
label e3422:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白
    show expression ("cg/bg/"+imagename["bg010200_3_学校屋上"]+".jpg") behind 絵色白
    show expression ("cg/ef/"+imagename["efbg空汎用満月"]+".jpg") as 絵背景 zorder 100 at truecenter
    show expression ("cg/ef/"+imagename["efbg空汎用満月_雲"]+".png") zorder 110:
        xpos -800
        yalign .5
    hide 絵色白
    with Dissolve(1000.0/1000)
    $ roof = True;
    $ sename = "se環境_自然_風モンゴルL"
    play se sedict[sename]
    xy "......"
    scene expression ("cg/bg/"+imagename["bg010200_3_学校屋上"]+".jpg") as 絵上背景 zorder 1010 at center
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010200_3_学校屋上"]+".jpg")
    hide 上背景
    pause (500/1000)

    "На школьной крыше было тихо, темно и пусто."

    "Я ещё никогда не был здесь ночью..."
    play voc "e34/2200010b04"
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]

    "Иру выпрыгнул из моих рук."

    "Он развернулся..."
    play voc "e34/2200020b04"
    show expression ("cg/bg/l/"+imagename["bg010210_3_学校屋上屋根向_l"]+".jpg") as 絵背景 zorder 100:
        xpos -1024
        yalign .5
    with Dissolve(500.0/1000)

    "...и начал подниматься по лестнице, ведущей на верхнюю часть крыши."

    xy "\"Ты хочешь, чтобы я поднялся туда?\""
    play voc "e34/2200030b04"
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]

    "Я кивнул котёнку..."
    $ sename = "se人体_動作_梯子のぼる一歩"
    play se sedict[sename]

    "А потом схватился за перекладину."
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    pause (500/1000)
    stop se fadeout .2

    "Шаг..."

    "...за шагом..."

    "Я медленно поднимался наверх."
    scene expression ("cg/bg/"+imagename["bg900100_3_雰囲気空"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵色黒
    with Dissolve(800.0/1000)
    pause (500/1000)

    "Небо - это море звёзд."

    "Свет сиял с небес."
    show expression ("cg/bg/"+imagename["bg900200_3_雰囲気街並み"]+".jpg") as 絵背景 zorder 100 at truecenter
    show expression ("cg/bg/"+imagename["bg900200_3_雰囲気街並み"]+".jpg")
    with Dissolve(500.0/1000)

    "Свет сиял от городских фонарей внизу."

    "Как будто я стоял в центре вселенной."
    show expression ("cg/ef/"+imagename["efbgアオイのスマフォ操作着信美雪"]+".jpg") as 絵背景 at truecenter
    $ sename = "se物体_携帯_着信音01L"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    pause (200/1000)
    $ renpy.music.play("ttb14",channel = "bgm", if_changed = True)
    pause (1000/1000)

    "Кто-то звонил Миюки."

    "Я проверил экран её телефона. Это был Бог."
    menu:
        "Но меня это не удивило.":
            pass
    menu:
        "Всё-таки это центр вселенной.":
            pass
    menu:
        "Где сигнал радиоволн достигал своего пика.":
            pass
    menu:
        "И сюда нас привёл кот-передатчик.":
            pass
    stop se fadeout .15
    show expression im.MatrixColor("cg/ef/"+imagename["efbgアオイのスマフォ操作着信美雪"]+".jpg",im.matrix.invert()) as 絵背景上 at truecenter
    pause .5
    $ renpy.vibrate(.5)
    hide 絵背景上
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg900200_9_雰囲気街並み_l"]+".jpg") as 絵演背景遠 zorder 15:
        pos (0,-60)
    hide 絵背景
    with Dissolve(500.0/1000)

    xy "\"Алло?\""
    "————"

    xy "\"Алло? Меня слышно?\""
    "————"
    voice "voice/e34/2200040b02.opus"
    kmsm "\"ОТВЕТ ПОЛОЖИТЕЛЬНЫЙ.\""
    voice "voice/e34/2200050b02.opus"

    kmsm "\"СОЕДИНЕНИЕ УСТАНОВЛЕНО.\""
    play voc "e34/2200060b04"
    hide 絵演背景遠
    with Dissolve(1000.0/1000)
    hide 絵動作

    "Стоя у моих ног, кот гордо мяукнул."

    "Меня привели сюда не мои выборы..."

    "Да и судьбой это не назовёшь."
    menu:
        "Ты хочешь знать, что привело тебя сюда?":
            pass
    menu:
        "Это был я. Игрок по ту сторону экрана.":
            pass
    menu:
        "Тот, кто делал выборы за тебя.":
            pass
    voice "voice/e34/2200070b02.opus"

    kmsm "\"МЫ ПОЛАГАЕМ, [[ТЫ] НАМЕРЕВАЕШЬСЯ...\""
    voice "voice/e34/2200080b02.opus"

    kmsm "\"...ОТКАТИТЬ ВСЕЛЕННУЮ.\""

    "Бог заявлял мне об этом на другом конце линии."
    voice "voice/e34/2200090b02.opus"

    kmsm "\"ТОЛЬКО У МИЮКИ И АОЙ ЕСТЬ РАЗРЕШЕНИЕ НА ЕГО ИНИЦИИРОВАНИЕ.\""
    voice "voice/e34/2200100b02.opus"

    kmsm "\"НО ЭТА ВСЕЛЕННАЯ УЖЕ БЫЛА ИЗМЕНЕНА.\""
    voice "voice/e34/2200110b02.opus"

    kmsm "\"СУЩЕСТВОВАНИЕ АОЙ БЫЛО ПОЧТИ ПОЛНОСТЬЮ СТЁРТО.\""
    menu:
        "ПОЧТИ полностью?":
            pass
    voice "voice/e34/2200120b02.opus"
    kmsm "\"ОТВЕТ ПОЛОЖИТЕЛЬНЫЙ.\""
    voice "voice/e34/2200130b02.opus"

    kmsm "\"ФРАГМЕНТ ЕЁ СОЗНАНИЯ ЖИВЁТ В ФОРМЕ ЭЛЕКТРОМАГНИТНЫХ ВОЛН.\""
    voice "voice/e34/2200140b02.opus"

    kmsm "\"ЕЁ МОЖНО ВОССТАНОВИТЬ, ИСПОЛЬЗУЯ ЕЁ КОДОВЫЙ НОМЕР.\""
    menu:
        "Я помню, как Миюки говорила то же самое.":
            pass
    menu:
        "Но того кодового номера уже нет.":
            pass
    menu:
        "Миюки изменила его.":
            pass
    voice "voice/e34/2200150b02.opus"

    kmsm "\"МЫ ПОДГОТОВИЛИ РЕЗЕРВНЫЙ НОМЕР.\""
    menu:
        "Ладно, но как мы узнаем его?":
            pass
    menu:
        "Весь этот разговор записывается в историю.":
            pass
    menu:
        "Если ты скажешь его нам...":
            pass
    menu:
        "То Миюки узнает об этом и изменит его.":
            pass
    voice "voice/e34/2200160b02.opus"

    kmsm "\"ОТВЕТ ОТРИЦАТЕЛЬНЫЙ.\""
    voice "voice/e34/2200170b02.opus"

    kmsm "\"МИЮКИ ЗНАЕТ О ВСЕХ НОМЕРАХ, КОТОРЫЕ СУЩЕСТВУЮТ В ЭТОЙ ВСЕЛЕННОЙ.\""
    voice "voice/e34/2200180b02.opus"

    kmsm "\"ОДНАКО...\""
    voice "voice/e34/2200190b02.opus"

    kmsm "\"ОНА НЕ МОЖЕТ ВЫЯВИТЬ НОМЕРА, КОТОРЫЕ СУЩЕСТВУЮТ ЗА ЕГО ГРАНЬЮ.\""
    voice "voice/e34/2200200b02.opus"

    kmsm "\"ОНА НЕ МОЖЕТ УВИДЕТЬ ВСЕЛЕННУЮ СУБЪЕКТА.\""
    menu:
        "Вселенную субъекта?":
            pass
    voice "voice/e34/2200210b02.opus"

    kmsm "\"ОТВЕТ ПОЛОЖИТЕЛЬНЫЙ. ИНАЧЕ ГОВОРЯ - РЕАЛЬНОСТЬ.\""
    menu:
        "Реальность?..":
            pass
    menu:
        "То есть, МОЯ вселенная?":
            pass
    voice "voice/e34/2200220b02.opus"

    kmsm "\"В [[ТВОЕЙ] ВСЕЛЕННОЙ СУЩЕСТВУЕТ ВОСЬМИЗНАЧНЫЙ КОД.\""
    voice "voice/e34/2200230b02.opus"

    kmsm "\"[[ТЫ] УЖЕ НАШЁЛ ЕГО?\""
    $ active_time = 10;
    menu:
        "Да":
            $ SetChoiceSelect = 0
        "Нет":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e3423a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e3423b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
