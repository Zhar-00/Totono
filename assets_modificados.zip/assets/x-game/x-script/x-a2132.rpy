label a2132_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a2133.nss"
    return
label a2132:
    hide 絵色黒
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010300_1_学校屋根_l"]+".jpg") as 絵背景 zorder 100 at center
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    with Dissolve(1500.0/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    voice "voice/a21/3200010a02.opus"
    aoi "Фух... Как жарко..."
    voice "voice/a21/3200020a01.opus"
    mx "Похоже, лето снова наступило."
    xy "Не хотите заскочить в Кураками?"
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/3200030a02.opus"
    aoi "Что такое Кураками?"
    xy "Кураками Электроникс. Оно прямо по улице от школы."
    xy "Они там продают мороженое."
    xy "Я время от времени хожу туда после школы вместе со своими друзьями."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/3200040a02.opus"
    aoi "Вместе с друзьями?.."
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    hide StML with Dissolve(200.0/1000)
    "Аой посмотрела на Миюки."
    voice "voice/a21/3200050a02.opus"
    aoi "Миюки, не хочешь взять мороженого—"
    $ sename = "se擬音_コミカル_キュピーン"
    play se sedict[sename]
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_hard")
    voice "voice/a21/3200060a01.opus"
    mx "Прошу прощения?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_surprise")
    voice "voice/a21/3200070a02.opus"
    aoi "Буп-буп?.."
    xy "Успокойся! Всё в порядке! Просто забудь, Миюки!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Взгляд Миюки был настолько злобным, что я не мог не вмешаться, чтобы разрядить обстановку."
    hide 絵背景
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/3200080a02.opus"
    aoi "Эм, Шиничи?"
    voice "voice/a21/3200090a02.opus"
    aoi "Миюки пускает искры из глаз!"
    xy "Мне кажется, ты её разозлила..."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a21/3200100a02.opus"
    aoi "Как?"
    xy "Может, в тот момент, когда ты назвала её «Миюки» несмотря на то, что она уже миллион раз просила тебя перестать её так называть?"
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a21/3200110a02.opus"
    aoi "Буп-буп?.."
    "Тем не менее, у меня было такое чувство, будто за этим скрывалось что-то большее..."
    pause (800/1000)
    scene expression Solid("000000") as 絵色黒 zorder 5000 with dissolve
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
