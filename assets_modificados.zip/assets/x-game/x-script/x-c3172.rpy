label c3172_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c3181.nss"
    return
label c3172:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    show expression ("cg/ef/"+imagename["efbg自宅自室天井消灯"]+".jpg") as 絵演背景 zorder 15 at truecenter
    with Dissolve(0.0/1000)
    "Наверное, Миюки права."
    "Возможно, я просто объединяю видеоигры и реальность. В смысле, Аой никоим образом не могла пойти на такие сложности и приобрести кота ради этого."
    "Но я вспоминаю тот день, когда увидел её стоявшей под дождём..."
    "Я мог представить себе, как она бесцельно блуждала по тёмным улицам с котёнком на руках..."
    "Ну и хуй с ним."
    "Пусть это будет тяжёлый случай игровой зависимости. Мне насрать."
    "На данный момент я готов на всё, чтобы прояснить эти сохраняющиеся сомнения."
    $ sename = "se人体_動作_飛び起きる"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg") as 絵演背景上 zorder 15 at truecenter
    with Dissolve(200.0/1000)
    xy "\"Сделаем это.\""
    "Я спрыгнул с кровати и взял телефон, взятый во временное пользование."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
