label a3111_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a3121.nss"
    return
label a3111:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    with Dissolve(2000.0/1000)
    pause (500/1000)
    show expression ("cg/bg/m/"+imagename["bg010600_1_学校教室_m"]+".jpg") as 絵背景 zorder 100 at center
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_sad")
    with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)
    pause (100/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    voice "voice/a31/1100010b01.opus"
    xtl "Он признался мне в любви."
    xy "...Что?"
    voice "voice/a31/1100020b01.opus"
    xtl "Он сказал, что я был первым, кто не стал обращать внимание на его странные увлечения."
    voice "voice/a31/1100030b01.opus"
    xtl "Что он всегда любил меня, как брата, но... недавно он осознал, что за этим стоит нечто большее."
    voice "voice/a31/1100040b01.opus"
    xtl "Рюджиро... признался мне в любви... пока переодевался в бабу."
    xy "И что... он надел?.."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_lost")
    with Dissolve(200.0/1000)
    voice "voice/a31/1100050b01.opus"
    xtl "Женский школьный купальник..."
    xy "...Не шутишь?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a31/1100060b01.opus"
    xtl "Моя жизнь не настолько спокойна, чтобы так шутить!"
    "Мне сегодня с утра довелось услышать весьма неприятные известия..."
    xy "В смысле, тебе пришлось ему отказать, верно?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/1100070b01.opus"
    xtl "Но... но!.."
    voice "voice/a31/1100080b01.opus"
    xtl "В том купальнике... Рюджиро, он..."
    voice "voice/a31/1100090b01.opus"
    xtl "Он был милым..."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_gag")
    voice "voice/a31/1100100b01.opus"
    xtl "ОН БЫЛ МИЛЫМ!!!"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_cry")
    with Dissolve(200.0/1000)
    voice "voice/a31/1100110b01.opus"
    xtl "МОЙ МЛАДШИЙ БРАТ НЕ МОЖЕТ БЫТЬ НАСТОЛЬКО МИЛЫМ!!!"
    "Звучит как посредственная лёгкая новелла..."
    stop bgm fadeout (1000.0/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白 zorder 5000
    with Dissolve((400.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/ev/"+imagename["eva0121美雪さんおはようございます"]+".jpg") as 絵画像 zorder 1000 at center
    show expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg")
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    hide 絵色白
    with Dissolve(800.0/1000)
    pause (1500/1000)
    voice "voice/a31/1100120a01.opus"
    mx "Доброе утро, народ!"
    voice "voice/a31/1100130b01.opus"
    xtl "Д-доброе утро, Сонэ-сан!"
    voice "voice/a31/1100140a01.opus"
    mx "Акебоно-кун?.. Почему ты плачешь так рано утром?"
    voice "voice/a31/1100150b01.opus"
    xtl "Сонэ-сан! Это долгая история, но ты выслушай меня! Под конец, я уверен, ты будешь рыдать вместе со м—"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(0.0/1000)
    hide 絵背景
    hide 絵画像
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/a31/1100160a01.opus"
    mx "Стоп, а где Аой?"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/1100170a01.opus"
    mx "Шиничи, ты не видел её?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    show expression ("cg/ef/"+imagename["efev美雪のキス"]+".jpg") as 絵美雪接吻 zorder 20 with fade
    voice "voice/a22/1100010a01.opus"
    mx "Сейчас будет..."
    voice "voice/a22/1100020a01.opus"
    play voc "a22/1100030a01"
    pause .5
    play sound "voice/a22/1100040a01.opus"
    pause .5
    play voc "a22/1100050a01"
    pause .5
    play sound "voice/a22/1100060a01.opus"
    pause .5
    extend " поцелуй."
    voice "voice/a31/1100240a01.opus"
    mx "...Эм, Шиничи? Ты меня слышишь?"
    hide 絵美雪接吻
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(0.0/1000)
    xy "А, эм... {nw=1}"
    with Dissolve(500.0/1000)
    extend "Если подумать, сегодня утром я её не видел."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/1100250a01.opus"
    mx "Она опаздывает, не находишь?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    show expression Solid("000000") as 絵色回想黒 zorder 4900
    with Dissolve((0.0+300.0)/1000)
    show expression ("cg/ev/l/"+imagename["eva1111アオイ受信中a_l"]+".jpg") as 絵画像 zorder 2010 at center
    with Dissolve(500.0/1000)
    "В обычной ситуации Аой уже сидит за своей партой и смотрит в никуда, когда я захожу в класс..."
    hide 絵色回想黒
    hide 絵色黒
    hide 絵画像
    with Dissolve(500.0/1000)
    voice "voice/a31/1100260b01.opus"
    xtl "Х-хн... н-н-н... уа-а-а-а!.."
    xy "Хм? Что-то не так, Ютаро?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_cry")
    with Dissolve(200.0/1000)
    voice "voice/a31/1100270b01.opus"
    xtl "Она полностью... проигнорировала меня..."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_gag")
    with Dissolve(200.0/1000)
    voice "voice/a31/1100280b01.opus"
    xtl "Стоп... Шиничи! С каких это пор ты сдружился с—"
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    hide StC with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg")
    with Dissolve(500.0/1000)
    pause (500/1000)
    $ St("MR",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/a31/1100290a02.opus"
    aoi "Доброе утро, Миюки!"
    $ St("ML",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a31/1100300a01.opus"
    mx "Доброе утро, Аой. Ты опоздала!"
    voice "voice/a31/1100310a02.opus"
    aoi "Наверное, я была слишком взволнована походом на бейсбольное поле... Вот и проспала свой будильник."
    "Таким было её утверждение..."
    xy "......"
    show expression ("cg/bg/m/"+imagename["bg010610_1_学校教室扉前_m"]+".jpg") as 絵背景 zorder 1010 at center
    $ St("X",1300,0,0,"bu向日アオイ電波_制服_通常_sad")
    with Dissolve(800.0/1000)
    pause (300/1000)
    "Но мне так не кажется."
    "Она просто не выглядела сонной... но она выглядела измотанной."
    "Может, её что-то беспокоит?"
    stop se fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
