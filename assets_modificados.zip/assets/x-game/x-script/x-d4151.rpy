label d4151_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4152.nss"
    return
label d4151:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    show expression Solid("000000") as 絵色黒
    with Dissolve(0.0/1000)

    "Это был последний раз, когда я видел Аой перед её исчезновением."
    pause (1000/1000)
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010800_1_学校体育館"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    hide 絵色黒
    with Dissolve(800.0/1000)
    voice "voice/d41/5100010a01.opus"

    mx "\"Готова поспорить, она приютила того кота. Именно поэтому она и пугает нас.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/d41/5100020a01.opus"

    mx "\"...Это моя вина.\""
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((1500.0+1000.0)/1000)
    hide StC with Dissolve(0.0/1000)
    pause (1000/1000)

    "Миюки долгое время была в плохом настроении после этого."

    "Но что до меня, мне хотелось верить, что за её исчезновением стоит нечто большее..."

    "Должна быть какая-то другая причина... Что-то, чего мы не понимаем..."
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    hide 絵色黒
    with Dissolve(1500.0/1000)
    pause (1000/1000)

    "Но даже когда Аой не было рядом, мои отношения с Миюки оставались крепкими."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
