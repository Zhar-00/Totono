label e2234a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2234a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e22/34a00010a01.opus"
    mx "\"Какие чувства ты испытываешь к этому городу, Шиничи?\""
    "Я никогда не задумывался над этим."
    show expression ("cg/bg/"+imagename["bg900200_1_雰囲気街並み"]+".jpg") as 絵背景 zorder 500 at truecenter
    show expression ("cg/ef/"+imagename["efbg屋上フェンス"]+".png") as 絵背景網 zorder 505 at truecenter
    with Dissolve(600.0/1000)
    pause (700/1000)
    "Это не такой уж и большой город."
    "Но это и не какая-нибудь деревня."
    "Просто обычный город."
    "Такой город можно увидеть где угодно."
    xy "\"Ну, я не особо влюблён в него, но я прожил здесь всю свою жизнь, так что... я правда не могу его ненавидеть, наверное.\""
    xy "\"А что насчёт тебя?\""
    voice "voice/e22/34a00020a01.opus"
    mx "\"Мне он очень нравится.\""
    if persistent.miyuki[16] == 0:
        voice "voice/e22/34a00030a01.opus"
        mx "\"Потому что ты здесь.\""
        xy "\"...Оу, блин...\""
        "Это так мило с её стороны... Мне было немного неловко слышать, как она говорила это прямо мне в лицо..."
    elif persistent.miyuki[16] == 1:
        voice "voice/e22/34a00040a01.opus"
        mx "\"Вид отсюда дополняет меня.\""
        voice "voice/e22/34a00050a01.opus"
        mx "\"Мне больше ничего не нужно.\""
        "Было вполне логично услышать это от такого перфекциониста, как Миюки."
    elif persistent.miyuki[16] == 2:
        voice "voice/e22/34a00060a01.opus"
        mx "\"Именно здесь я родилась и выросла.\""
        voice "voice/e22/34a00070a01.opus"
        mx "\"Так что, разумеется, мне нравится жить в нём.\""
        "Её шёпот прозвучал почти что печально."
    voice "voice/e22/34a00080a01.opus"
    mx "\"...Ну, что есть - то есть.\""
    hide 絵背景
    hide 絵背景網
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    stop se fadeout (4000.0/1000)
    voice "voice/e22/34a00090a01.opus"
    mx "\"Ладно, пошли.\""
    xy "\"Хорошо.\""
    hide StC with Dissolve(200.0/1000)
    "Мы закрыли проход на крышу за собой и вернулись в класс."
    stop se fadeout (1000.0/1000)
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    $ roof = False;
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
