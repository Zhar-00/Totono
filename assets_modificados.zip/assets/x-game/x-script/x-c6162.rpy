label c6162_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6171.nss"
    return
label c6162:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg080100_3_コンビニ外正面"]+".jpg")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c61/6200010a01.opus"
    mx "\"Проблема в нём.\""
    "...Я не понимаю."
    "Что такого в том, что Аой общается с Хару-чан?"
    "Стоп..."
    xy "\"Ты только что сказала «он»?\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se物体_ドア自動_開く"
    play se sedict[sename]
    pause (500/1000)
    "И тут автоматические двери распахнулись."
    $ St("C",300,0,0,"st曙雄太郎_バイト_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c61/6200020b01.opus"
    xtl "\"Шиничи!\""
    $ sename = "se人体_衝撃_転倒03"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (500/1000)
    voice "voice/c61/6200030b01.opus"
    xtl "\"Мне очень жаль, чувак!!!\""
    "Ютаро выбежал на улицу и упал на колени."
    xy "\"Воу, что происходит?\""
    voice "voice/c61/6200040b01.opus"
    xtl "\"Я никогда бы не подумал, что Рюджиро окажется таким парнем!..\""
    voice "voice/c61/6200050b01.opus"
    xtl "\"Я просто... мне нет оправдания!!!\""
    xy "\"Что случилось с твоим братом? Я не понимаю...\""
    $ St("ML",300,0,0,"st曽根美雪_制服_病み_sad")
    voice "voice/c61/6200060a01.opus"
    mx "\"У меня всегда были подозрения, но это только подтвердило их.\""
    "Миюки повернулась ко мне."
    $ St("ML",300,0,0,"st曽根美雪_制服_病み_normal")
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    voice "voice/c61/6200070a01.opus"
    mx "\"Рюджиро - И ЕСТЬ Хару-чан.\""
    pause (500/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
