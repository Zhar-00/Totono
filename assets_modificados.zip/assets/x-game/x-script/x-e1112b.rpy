label e1112b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2000.nss"
    return
label e1112b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    $ St("C",740,0,0,"bu曽根美雪_私服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/12b00010a01.opus"
    mx "\"Очень плохо.\""
    voice "voice/e11/12b00020a01.opus"
    mx "\"Я единственная, кого можно выбрать.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e11/12b00030a01.opus"
    mx "\"Но-о-о... Хм-м...\""
    voice "voice/e11/12b00040a01.opus"
    mx "\"Если честно, мне кажется, ТЫ уже начал влюбляться в меня...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e11/12b00050a01.opus"
    mx "\"Быть может, я подумаю над тем, чтобы дать тебе право выбора...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/12b00060a01.opus"
    mx "\"А теперь давай.\""
    voice "voice/e11/12b00070a01.opus"
    mx "\"Пей свой мисо суп, и пошли.\""
    "Вкус её бульона просто таял у меня во рту."
    "Он был таким вкусным и успокаивающим, что, кажется, я мог бы сейчас упасть в обморок..."
    scene expression "cg/bg/black.jpg" zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause 1
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
