label c2193_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a2194.nss"
    return
label c2193:
    $ renpy.music.play("ttb08",channel = "bgm", if_changed = True)
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_surprise")
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(0.0/1000)
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/c21/9300010a02.opus"
    aoi "\"Нет. Это подарок от Шиничи!\""
    $ St("MR",300,0,0,"st曽根美雪_制服_恋人_smile")
    voice "voice/c21/9300020a01.opus"
    mx "\"Я просто попрошу его принести мне что-нибудь другое позже. Что-нибудь, что подойдёт мне больше.\""
    voice "voice/c21/9300030a01.opus"
    mx "\"Ты ведь не возражаешь, верно, Шиничи?\""
    xy "\"Ха-а... полагаю, у меня нет выбора, да?\""
    "Она правда хочет, чтобы я купил ей что-то другое, или она сказала это просто так, чтобы Аой не лезла в её дело?"
    "Мне не очень хотелось узнать это..."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/c21/9300040a01.opus"
    mx "\"Вот, держи.\""
    $ sename = "se物体_ビニル袋_鳴る"
    play se sedict[sename]
    "Миюки сунула пакет в руки Аой."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/c21/9300050a02.opus"
    aoi "\"...Ты уверена?\""
    voice "voice/c21/9300060a01.opus"
    mx "\"Абсолютно уверена!\""
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/c21/9300070a02.opus"
    aoi "\"Но...\""
    xy "\"Считай это подарком от нас обоих.\""
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/c21/9300080a01.opus"
    mx "\"Примерь-ка! Очень хочу глянуть на твою милую улыбку.\""
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/c21/9300090a02.opus"
    aoi "\"Буп-буп...\""
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/c21/9300100a02.opus"
    aoi "\"Ладно.\""
    $ sename = "se物体_ビニル袋_鳴る"
    play se sedict[sename]
    "Аой спокойно приняла подарок."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
