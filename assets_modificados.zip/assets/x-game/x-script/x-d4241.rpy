label d4241_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d4242.nss"
    return
label d4241:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(1500.0/1000)

    xy "\"...И тогда я понял, что она уже ушла.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/d42/4100010a01.opus"

    mx "\"Ушла?..\""

    xy "\"Ты думаешь, я всё выдумываю?\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/d42/4100020a01.opus"

    mx "\"При любых других обстоятельствах, да... Но опять же, мы сейчас говорим об Аой.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/d42/4100030a01.opus"

    mx "\"Это место - центр вселенной... Да и к тому же, это было посреди ночи.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/d42/4100040a01.opus"

    mx "\"Идеальная среда для небольшого волшебства.\""

    xy "\"...Хах. Я удивлён.\""

    xy "\"Я уже было подумал, что ты сейчас назовёшь меня игроманом или ещё как-нибудь.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/d42/4100050a01.opus"

    mx "\"Я решила верить...\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/d42/4100060a01.opus"

    mx "\"...в середину между мечтами и реальностью.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/d42/4100070a01.opus"

    mx "\"Думаю, я должна поблагодарить Аой за это.\""

    xy "\"Да...\"!"

    "Именно благодаря Аой я и нахожусь здесь."

    "Это уж точно."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    stop bgm fadeout (3000.0/1000)
    voice "voice/d42/4100080a01.opus"

    mx "\"Значит, с Аой мы уже закончили, да?\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/d42/4100090a01.opus"

    mx "\"А теперь позволь мне—\""
    stop bgm fadeout (2000.0/1000)

    xy "\"—Погоди секунду.\""
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (500/1000)

    "Я не знаю, была ли та Аой, которую я увидел наверху, настоящей или просто иллюзией."

    "Но если она специально пришла сюда, чтобы посмотреть на меня в последний раз..."

    "Если то мгновение, которое мы разделяли, имело более глубокий смысл..."

    "То, думаю, я понимаю, что она хотела, чтобы я понял."
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15 at truecenter
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    hide 絵色黒
    with Dissolve(2000.0/1000)
    pause (1000/1000)

    xy "\"Можешь для начала отпустить меня?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/d42/4100100a01.opus"

    mx "\"В чём дело?..\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
