label c3164_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label c3164:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(0.0/1000)

    xy "\"Мне просто кажется, что здесь должна быть какая-то зацепка...\""

    "Я это просто нутром чую..."

    "Должно же быть что-то... верно?.."

    "Нр-рг-гх... это бесполезно!.."

    "Я это даже на кончике языка чувствую!"

    "Ладно, думай! Где мне искать подсказки?"
    return
    return
label c3164_SELECT:
    $ renpy.save("lastsel")
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(0.0/1000)
    menu:
        "Мобильная игра":
            $ SetChoiceSelect = 0
        "Школьные пешеходные ворота":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "c3165.nss";
    elif SetChoiceSelect==1:
        $ GameName = "d3165.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
