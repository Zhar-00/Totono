label e2212c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2212c:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e22/12c00010a01.opus"
    mx "\"Ладно, я пойду.\""
    xy "\"Что?\""
    voice "voice/e22/12c00020a01.opus"
    mx "\"Я передумала. Я пойду на физкультуру.\""
    voice "voice/e22/12c00030a01.opus"
    mx "\"Нет смысла прогуливать её, если тебя не будет рядом.\""
    xy "\"......\""
    hide StC with Dissolve(200.0/1000)
    pause (200/1000)
    $ sename = "se物体_ドア鉄_閉まる02"
    play se sedict[sename]
    pause (100/1000)
    "Миюки ушла с высоко поднятой головой."
    "Э-э-эм... Ладно..."
    "Наверное, она не так сильно ненавидит физкультуру, как утверждает."
    "Проклиная себя за свою же тупость, я побежал за ней вниз по лестнице..."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    $ roof = False;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
