label e1112a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2000.nss"
    return
label e1112a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/12a00010a01.opus"

    mx "\"Ты тратишь своё время.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/12a00020a01.opus"

    mx "\"Я единственная, кого можно выбрать, знаешь ли.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/12a00030a01.opus"

    mx "\"Хм... Посмотрим... Какую сцену нам разыграть на этот раз?..\""

    "Миюки улыбалась, пока говорила это."

    "Тем временем, я взял свою миску с мисо супом."

    "М-м-м... Вкусно..."
    scene expression "cg/bg/black.jpg" zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause 1
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
