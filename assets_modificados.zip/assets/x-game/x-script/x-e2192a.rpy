label e2192a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2194.nss"
    return
label e2192a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(0.0/1000)

    xy "\"Ладно. Пошли.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/92a00010a01.opus"

    mx "\"Хорошо.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
