label e2207_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2207:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    stop bgm fadeout (150.0/1000)
    $ sename = "se人体_動作_バットスイング01"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白
    pause (30/1000)
    hide 絵色白
    with Dissolve(70.0/1000)
    xy "\"Воу!!!\""
    $ sename = "se物体_携帯_落ちる02"
    play se sedict[sename]
    "Бейсбольная бита прошла в сантиметре от меня."
    "Я выронил телефон от удивления."
    $ sename = "se物体_携帯_繋がる"
    play se sedict[sename]
    pause (2000/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e22/0700010a01.opus"
    mx "\"Плохой мальчик.\""
    "Миюки подобрала телефон и завершила вызов."
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e22/0700020a01.opus"
    mx "\"Ты что делал?\""
    xy "\"Ничего...\""
    voice "voice/e22/0700030a01.opus"
    mx "\"Скажи мне правду.\""
    voice "voice/e22/0700040a01.opus"
    mx "\"Ты разговаривал с Богом, так ведь?\""
    menu:
        "Я говорил по телефону":
            $ SetChoiceSelect = 0
        "Никаких звонков не было":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ persistent.miyuki_love += 1
        $ GameName = "e2208a.nss";
    elif SetChoiceSelect==1:
        $ persistent.miyuki_love -= 1
        $ GameName = "e2208b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
