label e2164b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2165.nss"
    return
label e2164b:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg070100_2_雑貨店店内"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/ef/"+imagename["efbg猫ヘアピンペア"]+".jpg") as 絵背景 zorder 1000 at truecenter
    with Dissolve(0.0/1000)

    xy "\"Стоп, их здесь две?\""
    hide 絵背景
    with Dissolve(800.0/1000)
    pause (300/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/64b00010a01.opus"

    mx "\"Да? Ну и что, что их здесь две?\""

    xy "\"А?.. Нет, в смысле, это нормально, но...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/64b00020a01.opus"

    mx "\"Но что?\""

    "Мне нечего было ответить."

    "Даже я не знаю, почему меня волновало их количество на витрине..."

    xy "\"Эм... ну...\""
    voice "voice/e21/64b00030a01.opus"

    mx "\"Ну что?\""

    xy "\"Ну... Они совсем не одинаковые, видишь?\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
