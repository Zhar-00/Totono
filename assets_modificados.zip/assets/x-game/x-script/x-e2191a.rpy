label e2191a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2191a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e21/91a00010a01.opus"

    mx "\"...Что это за коробка?\""

    xy "\"Без понятия...\""

    xy "\"Мне интересно, что внутри...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/91a00020a01.opus"

    mx "\"Давай просто оставим её. Любопытство до добра не доводит, знаешь ли.\""

    xy "\"Да брось. Я сомневаюсь, что там лежит что-то опасное.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/e21/91a00030a01.opus"

    mx "\"Серьёзно, давай просто уйдём!\""
    menu:
        "Уйти":
            $ SetChoiceSelect = 0
        "Открыть коробку":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ persistent.miyuki_love += 1
        $ GameName = "e2192a.nss";
    elif SetChoiceSelect==1:
        $ persistent.miyuki_love -= 1
        $ GameName = "e2192b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
