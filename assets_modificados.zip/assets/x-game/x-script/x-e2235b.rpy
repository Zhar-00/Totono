label e2235b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2236.nss"
    return
label e2235b:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    $ St("C",740,0,0,"bu曽根美雪_制服_恋人_shy")
    with Dissolve(0.0/1000)

    xy "\"Какого ещё соревнования по хоум-рану?\""
    voice "voice/e22/35b00010a01.opus"

    mx "\"А, точно... Ты не помнишь.\""
    voice "voice/e22/35b00020a01.opus"

    mx "\"Но ТЫ сказал мне...\""
    $ St("C",740,0,0,"bu曽根美雪_制服_病み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/35b00030a01.opus"

    mx "\"...что хочешь меня.\""

    "Да, я совсем этого не помню..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
