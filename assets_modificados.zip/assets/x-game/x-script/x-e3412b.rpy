label e3412b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1111.nss"
    return
label e3412b:
    hide 絵色黒
    $ sename = "se環境_水音_シャワーL"
    play se sedict[sename]
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110301_3_マンション寝室消灯"]+".jpg")
    $ st_timezone = "夜"
    with Dissolve(0.0/1000)
    $ sename = "se人体_動作_衣擦れ01"
    play se sedict[sename]
    with Dissolve((0.0+1000.0)/1000)
    with Dissolve(800.0/1000)

    "Я не хочу рисковать подхватить простуду, поэтому я залез на кровать и уснул."
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
