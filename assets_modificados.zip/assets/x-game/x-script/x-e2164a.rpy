label e2164a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2164a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg070100_2_雑貨店店内"]+".jpg")
    $ st_timezone = "昼"
    if (NekoPin==2):
        show expression ("cg/ef/"+imagename["efbg猫ヘアピンペア"]+".jpg") as 絵背景
    else:
        show expression ("cg/ef/"+imagename["efbg猫ヘアピンソロ"]+".jpg") as 絵背景
    with Dissolve(0.0/1000)

    "Цена у неё... как раз меня и волновала, да."

    "Ну да ладно. Миюки эта заколка, похоже, очень нравится, так что—"
    hide 絵背景
    with Dissolve(800.0/1000)

    xy "\"Хочешь, я куплю её для тебя?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/e21/64a00010a01.opus"

    mx "\"А? Но...\""

    xy "\"Ты ведь хочешь её, да?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e21/64a00020a01.opus"

    mx "\"Она на мне не будет хорошо смотреться—\""

    xy "\"А я уверен, тебе она будет очень к лицу.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_ero")
    with Dissolve(200.0/1000)
    voice "voice/e21/64a00030a01.opus"

    mx "\"Ты так думаешь?..\""
    if persistent.eternal_day or persistent.eternal_day:
        $ GameName = "e2165a.nss";
    else:
        $ GameName = "e2165.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
