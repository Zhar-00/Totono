label e2225e_MAIN:
    call expression GameName
    $ persistent.imagelog["eve2225a美雪男の浪漫メイドf"]=True
    $ PreGameName = GameName
    $ temp_miyuki_sex1 = True;
    $ persistent.miyuki_sex1 = True;
    $ persistent.count_e2225e +=1;
    $ persistent.library_scene6 = True;
    if (persistent.count_e2225b > 0 and persistent.count_e2225e == 1):
        $ GameName = "e2225h.nss";
    elif (persistent.count_e2225e > 1):
        $ GameName = "e2225g.nss";
    else:
        $ GameName = "e2225f.nss";
    hide 和谐的黑色 onlayer hexie
    if (RECO_PLAY==1):
        $ GameCircle=False
    return
label e2225e:
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    show expression ("cg/ev/"+imagename["eve2225a美雪男の浪漫メイドd"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)

    xy "\"Миюки... я сейчас кончу на тебя!..\""
    voice "voice/e22/25e00010a01.opus"

    mx "\"Ха-а-а! Н-н-н... Хорошо... Ладно... А-а-ах! Кончай куда хочешь— А-А-АХ! А-АХ!\""
    voice "voice/e22/25e00020a01.opus"

    mx "\"Просто выплесни всё своё семя на меня—! Н-н-нг... Покрой меня своей спермой—!!!\""
    voice "voice/e22/25e00030a01.opus"

    mx "\"Н-нха-а-А-А-АХ! А-ах! А-а-а-ах! Ох, блядь! Это так интенсивно— А-А-АХ!!!\""
    voice "voice/e22/25e00040a01.opus"

    mx "\"Ты скоро кончишь?.. Н-н-нг— н-нха-а! А-ах! А-ах! Ты скоро кончишь на меня?\""
    voice "voice/e22/25e00050a01.opus"

    mx "\"Давай! Я тоже кончаю— Н-н-нгх! Н-нха-а-а! Да! Вот так! А-а-а-ах! Я кончаю!!!\""
    voice "voice/e22/25e00060a01.opus"

    mx "\"Ха-а! А-ах! А-ах! А-ах! А-ах! А-а-а-ах! А-ах! А-ах, а-ах, а-ах! А-а-а-а-а-а-ах—\""
    voice "voice/e22/25e00070a01.opus"

    mx "\"Н-нха-а-а-а-а-а-а-а-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-АХ—!!!\""
    show expression Solid("FFFFFF") as 絵演色白 zorder 5000
    with Dissolve((200.0+800.0)/1000)
    with Dissolve((250.0+1000.0)/1000)
    show expression ("cg/ev/"+imagename["eve2225a美雪男の浪漫メイドf"]+".jpg") as 絵専 zorder 1100 at truecenter
    pause (500/1000)
    hide 絵絶頂板
    hide 絵演色白
    with Dissolve(1500.0/1000)
    pause (1000/1000)
    voice "voice/e22/25e00080a01.opus"

    mx "\"А-а-а-ах— а-ах, н-нха-а-а, а-а-а-ах— н-н-нг!!! Ха-а... ха-а-а-а-а!.. Н-н-н-нг-г... ха-а-а!..\""
    voice "voice/e22/25e00090a01.opus"

    mx "\"Хн-н... н-н-н... н-нха-а-а... а-ах... Ого... Её... так много... н-н-нгх!\""
    voice "voice/e22/25e00100a01.opus"

    mx "\"Она... вся на мне... Хн-н-н... н-н-н... Даже между моими грудями... и запах—\""

    "Миюки восторженно бормотала, будучи покрытой моим семенем."

    "Это зрелище было таким сексуальным, от него моё тело даже начало дрожать сильнее."
    voice "voice/e22/25e00110a01.opus"

    mx "\"Ха-а... а-ах!.. Ты всё ещё кончаешь?.. Теперь я окрашена в твои цвета... внутри и снаружи...\""

    "Обессиленный, я рухнул на неё..."
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 1900
    with Dissolve((3000.0+500.0)/1000)

    "..и потерял своё сознание."
    show expression Solid("000000") as 絵色黒上 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (16/1000)
    if (RECO_PLAY==1):
        pass
    else:
        scene expression "cg/bg/black.jpg" as 絵色黒 zorder 2000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(30000/1000))
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
