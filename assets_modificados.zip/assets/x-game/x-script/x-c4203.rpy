label c4203_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4211.nss"
    return
label c4203:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg060100_3_バッティングセンター店内"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(800.0/1000)
    "Нет никаких гарантий, что Иру точно приведёт меня к Аой."
    "Мне не стоит бросать Миюки из-за него."
    "И не было абсолютно никакой логической причины, по которой я должен следовать за Иру."
    "Я знаю это..."
    "И всё же..."
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15 at truecenter
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(500.0/1000)
    $ renpy.music.play("ttb14",channel = "bgm", if_changed = True)
    xy "\"Я должен идти. Мне надо разобраться с этим раз и навсегда.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c42/0300010a01.opus"
    mx "\"......\""
    "Миюки сделала глубокий вдох, полностью заполнив свои лёгкие, а потом медленно выдохнула."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/c42/0300020a01.opus"
    mx "\"Ладно.\""
    "Она неохотно кивнула."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c42/0300030a01.opus"
    mx "\"Но в таком случае, тебе лучше выслушать меня позже.\""
    xy "\"Хорошо. Увидимся.\""
    hide StC
    hide StMR
    hide StML
    hide 絵背景
    show expression ("cg/bg/"+imagename["bg060100_3_バッティングセンター店内"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(200.0/1000)
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]
    pause (1000/1000)
    voice "voice/c42/0300040a01.opus"
    mx "\"Шиничи!\""
    "Как только я начал бежать, Миюки позвала меня."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/c42/0300050a01.opus"
    mx "\"Я буду ждать!\""
    voice "voice/c42/0300060a01.opus"
    mx "\"Это обещание, слышишь меня?! Я буду ждать!\""
    show expression Solid("000000") as 絵色黒
    hide StC
    hide StMR
    hide StML
    with Dissolve(800.0/1000)
    pause (500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
