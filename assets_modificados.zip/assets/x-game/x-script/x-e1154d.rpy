label e1154d_MAIN:
    call expression GameName
    $ PreGameName = GameName
    while True:
        " "
    return
label e1154d:
    hide 絵色黒
    $ renpy.music.play("ttb22",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110500_1_マンショントイレ"]+".jpg")
    show expression ("cg/ev/"+imagename["eve1154b美雪血涙"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    voice "voice/e11/54d00010a01.opus"

    mx "\"Почему ТЫ не ответил мне взаимностью?\""
    voice "voice/e11/54d00020a01.opus"

    mx "\"Я так сильно ТЕБЯ люблю!\""
    voice "voice/e11/54d00030a01.opus"

    mx "\"Причём так сильно, что мне придётся убить ТЕБЯ!\""
    voice "voice/e11/54d00040a01.opus"

    mx "\"Мне приходится убивать человека, которого люблю, снова и снова!!!\""
    voice "voice/e11/54d00050a01.opus"

    mx "\"Я уже ебанулась в край!!!\""
    voice "voice/e11/54d00060a01.opus"

    mx "\"Пожалуйста...\""
    voice "voice/e11/54d00070a01.opus"

    mx "\"ТЫ мне не поможешь?\""
    $ renpy.vibrate(5)
    $ sename = "se人体_衝撃_バットで殴る04"
    play se sedict[sename]
    scene expression Solid("FFFFFF") as 絵色白
    pause (30/1000)
    pause (200/1000)
    $ persistent.waste = True;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
