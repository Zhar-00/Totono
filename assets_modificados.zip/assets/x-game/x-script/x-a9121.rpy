label a9121_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if aoi_stop == True or temp_root_recreate == True:
        $ GameName = "a9122a.nss"
    else:
        $ GameName = "a9122b.nss"
    return
label a9121:
    hide 絵色黒
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    scene expression ("cg/ef/"+imagename["efbg空汎用西日"]+".jpg") as 絵専 zorder 15 at truecenter
    with Dissolve(1000.0/1000)

    "Солнце заходит за городом."

    "Медленно но верно, оно скрывалось за горизонтом."

    "Алое небо просто захватывало дух..."

    "Это выглядело почти как сценические декорации."

    "Что до меня, я мог быть только самим собой."

    "Находясь в ловушке своего маленького мира, я буду жить нормальной жизнью, и тогда история закончится прежде, чем я узнаю об этом."

    "Никакого вступления, никакой кульминации, никакого заключения, и никакой скромной резолюции."

    "Вот здесь я и оказался, я остался в лузерах и другие тропы были для меня закрыты."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
