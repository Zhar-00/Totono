label d3172_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4121.nss"
    return
label d3172:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    show expression ("cg/ef/"+imagename["efbg自宅自室天井消灯"]+".jpg") as 絵演背景 zorder 10 at truecenter
    with Dissolve(0.0/1000)
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵覆絵色回想黒
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg") as 絵演回想背景 behind 絵覆絵色回想黒 zorder 2015 at truecenter
    $ st_timezone = "夜"
    $ St("C",2300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(500.0/1000)
    voice "voice/d31/7200010a01.opus"

    mx "\"Теперь и ТЫ смешиваешь видеоигры с реальностью?\""
    hide StC
    hide StMR
    hide StML
    hide 絵演回想背景
    hide 絵覆
    with Dissolve(300.0/1000)
    xy "\"......\""

    "Миюки права."

    "Я должен был помочь ей вернуться в реальный мир."

    "Я не могу подхватить от неё игровую зависимость!"

    "Я должен просто заставить себя уснуть."
    $ sename = "se物体_布団_潜り込む"
    play se sedict[sename]
    pause (300/1000)
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((500.0+1000.0)/1000)

    "Обняв свою подушку, я закрыл глаза."
    pause (2000/1000)
    $ EyeCatchIn(2000.0)
    show expression Solid("FFFFFF") as 絵色白 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
