label a6222_MAIN:
    call expression GameName
    $ persistent.imagelog["eva6222美雪世界の中心で愛を叫ぶアレa"]=True
    $ persistent.imagelog["eva6222美雪世界の中心で愛を叫ぶアレb"]=True
    $ PreGameName = GameName
    $ persistent.imagelog["bg010300_3_学校屋根"]=True
    $ persistent.one_choice1= True
    $ GameName = "a7111.nss";
    return
label a6222:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg010200_3_学校屋上"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_病み_fear")
    with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)

    xy "Эй, Миюки..."

    xy "Не хочешь подняться наверх?"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a62/2200010a01.opus"
    mx "\"...Конечно.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Я отвёл Миюки вверх по лестнице на крышу."
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010300_3_学校屋根_l"]+".jpg") as 絵背景弐 zorder 1000:
        xpos 0
        ycenter .5
        linear 40 xpos -512
    pause (1000/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    stop se fadeout (1000.0/1000)
    $ renpy.music.play("ttb02",channel = "bgm", if_changed = True)
    pause (1500/1000)
    xy "\"......\""
    voice "voice/a62/2200020a01.opus"
    mx "\"......\""

    "У меня не было слов, которыми можно было его описать."

    "Утро или вечер, вид отсюда открывался по-настоящему прекрасный..."

    "Но ночной вид превосходил их обоих в разы."

    xy "Как будто мы в центре вселенной находимся, а?"
    voice "voice/a62/2200030a01.opus"

    mx "Можно и так сказать."

    "Земля и небо превратились в море сверкающих огней."

    "Мы двое были сильно увлечены этим зрелищем, чтобы заметить похолодание."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    hide 絵背景弐
    with Dissolve(1000.0/1000)

    xy "Слушай, Миюки?"

    xy "Ты слышала одну школьную легенду про крышу?"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_angry")
    voice "voice/a62/2200040a01.opus"

    mx "Стоп?.. У н-неё есть своя легенда?!"

    "Покрасневшие щёки Миюки полностью выдали её."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/a62/2200050a01.opus"

    mx "А, точно, это! Да, я слышала её!"
    voice "voice/a62/2200060a01.opus"

    mx "Меня чуть ли не постоянно приглашали сюда, знаешь ли!"

    xy "Да и к тому же, именно по этой причине ты и призналась мне впервые в своих чув—"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a62/2200070a01.opus"

    mx "Я же попросила тебя забыть о том, что это вообще происходило!"

    xy "Прости."

    "—Если два человека поцелуются на крыше, их любовь будет вечной."

    "Я был абсолютно уверен, что любой человек, который учится в нашей школе, знает о ней."

    xy "Ты думаешь, она правдивая?"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a62/2200080a01.opus"

    mx "Я не верю слухам."
    voice "voice/a62/2200090a01.opus"

    mx "Просто я не из таких людей."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/a62/2200100a01.opus"

    mx "Но... думаю... наверное... я готова попробовать..."

    xy "Неужели Аой заставила тебя передумать?"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a62/2200110a01.opus"
    mx "......"
    hide StC with Dissolve(200.0/1000)

    "Миюки кивнула."

    "Она замолчала на какое-то время..."

    "...а потом посмотрела мне прямо в глаза."
    show expression ("cg/ev/"+imagename["eva6222美雪世界の中心で愛を叫ぶアレa"]+".jpg") as 絵専 zorder 1100 at center
    $ sename = "se人体_動作_抱きつく02"
    play se sedict[sename]
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    voice "voice/a62/2200120a01.opus"

    mx "Слушай, Шиничи..."
    voice "voice/a62/2200130a01.opus"

    mx "Ты поможешь мне..."
    voice "voice/a62/2200140a01.opus"

    mx "...сделать это место центром моей вселенной?"
label a6222_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    show expression ("cg/ev/"+imagename["eva6222美雪世界の中心で愛を叫ぶアレa"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    menu:
        "Кивнуть":
            pass
    $ persistent.one_choice1 = True
    hide 絵色黒
    show expression ("cg/ev/"+imagename["eva6222美雪世界の中心で愛を叫ぶアレa"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    $ sename = "se人体_動作_衣擦れ04"
    play se sedict[sename]

    "Я кивнул и подошёл к ней поближе."

    "Мы смотрели друг другу в глаза."

    "Она улыбнулась с облегчением."

    "Это была настоящая Миюки."

    "Девушка, которая пряталась за её сценическим образом."

    "А я был единственным человеком, кому она показывала своё истинное \"я\"."

    "Она закрыла глаза."
    $ sename = "se人体_動作_衣擦れ04"
    play se sedict[sename]

    "Я нежно обнял её своими руками."

    "Неровное дыхание."

    "Красные щёки."

    "Словно притянутый её очарованием..."
    show expression ("cg/ev/"+imagename["eva6222美雪世界の中心で愛を叫ぶアレb"]+".jpg") as 絵専弐 zorder 1100 at center
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)

    "...я поцеловал её."

    "Мы так долго любили друг друга."

    "И мы всё это время пытались это скрывать."

    "Но теперь наш поцелуй свяжет нас навеки."

    "Моё сердце колотилось от радости, а мои чувства начали угасать... пока не осталась только одна Миюки."

    "Я был словно на седьмом небе от счастья..."

    "...или, наверное, летал в космосе."
    stop bgm fadeout (5000.0/1000)
    pause (1000/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    voice "voice/a62/2200150a01.opus"

    mx "Обещай мне..."
    voice "voice/a62/2200160a01.opus"

    mx "Обещай мне, что никогда не бросишь меня, Шиничи."
    pause (2000/1000)
    $ EyeCatchIn(2000.0)
    show expression Solid("FFFFFF") as 絵色白 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (3000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
