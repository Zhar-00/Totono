label e2151_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2151:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010400_2_学校校門"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ sename = "se人体_足音_走る美雪来る"
    play se sedict[sename]
    pause (1500/1000)
    stop se fadeout (300.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e21/5100010a01.opus"
    mx "\"Прости, что я так долго!\""
    xy "\"О, привет... Взяла мороженое?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/5100020a01.opus"
    mx "\"Ага! Вот твоё.\""
    xy "\"Здорово, спасибо.\""
    "Она передала мне ванильный сэндвич с мороженым."

    xy "\"Здорово! Это моё любимое! ...А что ты себе взяла?\""
    if persistent.miyuki[7] == 0:
        "Миюки достала мороженое-моти, которое купила себе."
    elif persistent.miyuki[7] == 1:
        "Миюки достала арбузный фруктовый лёд, который купила себе."
    elif persistent.miyuki[7] == 2:
        "Миюки достала леденец с помадкой, который купила себе."
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e21/5100040a01.opus"
    mx "\"Мне обычно нравится его покупать.\""
    if persistent.eternal_day:
        $ GameName = "e2152b.nss";
    else:
        menu:
            "А ты уверена, что не растолстеешь?":
                $ SetChoiceSelect = 0
            "Давай поделимся?":
                $ SetChoiceSelect = 1
        if SetChoiceSelect==0:
            $ persistent.miyuki_love -= 1
            $ GameName = "e2152a.nss";
        elif SetChoiceSelect==1:
            $ persistent.miyuki_love += 1
            $ GameName = "e2152b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
