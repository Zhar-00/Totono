label e1122b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1122b.nss";
    return
label e1122b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    if (persistent.LF_e1122b_01 == true):
        $ St("C",300,0,0,"bu曽根美雪_私服_恋人_sad")
    else:
        $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
        $ persistent.LF_e1122b_01 = true;

    xy "\"Нет, не могу.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/22b00010a01.opus"

    mx "\"Да ла-а-адно. Не будь таким.\""
    voice "voice/e11/22b00020a01.opus"

    mx "\"Ничего хорошего не случится, если ты отвергнешь меня, знаешь ли. Тебе стоит ещё раз подумать над этим.\""
    voice "voice/e11/22b00030a01.opus"

    mx "\"Теперь ты можешь доказать свою любовь ко мне?\""
    if not persistent.love_roop_reject_count:
        $ persistent.love_roop_reject_count = 0
    $ persistent.love_roop_reject_count+=1
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
