label d7112_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d7123.nss"
    return
label d7112:
    hide 絵色黒
    $ renpy.music.play("ttb19",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(0.0/1000)
    xy "\"Я так больше не могу.\""
    xy "\"Уёбывай из моего дома.\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/d71/1200020a02.opus"
    aoi "\"Аой...\""
    voice "voice/d71/1200030a02.opus"
    aoi "\"...сделала... неправильный выбор...\""
    "Аой опустила голову и несла какой-то бред."
    "У меня больше нет сил поправлять её."
    pause (500/1000)
    stop bgm fadeout (2000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((2000.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    pause (2000/1000)
    hide 絵色黒
    with Dissolve(2000.0/1000)
    $ St("MR",300,0,0,"st曙雄太郎_私服_通常_hard")
    voice "voice/d71/1200040b01.opus"
    xtl "\"Мы уже закончили?\""
    $ St("MR",300,0,0,"st曙雄太郎_私服_通常_sad")
    voice "voice/d71/1200050b01.opus"
    xtl "\"Давайте разойдёмся по домам.\""
    "Его голос перекликался с тяжёлой атмосферой в комнате."
    $ St("MR",300,0,0,"st曙雄太郎_私服_通常_hard")
    voice "voice/d71/1200060b01.opus"
    xtl "\"Давайте мы все проведём остаток этого дня, чтобы успокоиться, а потом—\""
    $ St("ML",300,0,0,"st曙龍二郎_私服_通常_sad")
    voice "voice/d71/1200070b03.opus"
    c "\"Но Аой-семпай—\""
    $ St("MR",300,0,0,"st曙雄太郎_私服_通常_angry")
    voice "voice/d71/1200080b01.opus"
    xtl "\"Рюджиро!\""
    "Рюджиро замолчал."
    $ St("MR",300,0,0,"st曙雄太郎_私服_通常_hard")
    voice "voice/d71/1200090b01.opus"
    xtl "\"Пошли, Сонэ-сан... Давай разойдёмся по домам.\""
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    voice "voice/d71/1200100a01.opus"
    mx "\"А как же Аой?\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (500/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    voice "voice/d71/1200110a02.opus"
    aoi "\"Не волнуйся.\""
    voice "voice/d71/1200120a02.opus"
    aoi "\"Ты всё забудешь обо мне.\""
    voice "voice/d71/1200130a02.opus"
    aoi "\"Таков ход истории.\""
    voice "voice/d71/1200140a01.opus"
    mx "\"Аой...\""
    xy "\"Ты слышала её. Ей не нужно твоё беспокойство.\""
    "Я не собираюсь тратить своё время, жалея её."
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((500.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    show expression ("cg/bg/"+imagename["bg030200_3_自宅玄関"]+".jpg")
    pause (500/1000)
    $ st_timezone = "昼"
    hide 絵色黒
    with Dissolve(500.0/1000)
    pause (500/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/d71/1200150a02.opus"
    aoi "\"Шиничи... Пока-пока.\""
    xy "\"А... Стой!\""
    "Чуть не забыл кое-что."
    "Я побежал по лестнице."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
