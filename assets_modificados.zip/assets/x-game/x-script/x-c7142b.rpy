label c7142b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c7143.nss"
    return
label c7142b:
    hide 絵色黒
    $ st_timezone = "昼"
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    $ St("C",300,150,0,"fu曽根美雪血まみれ_私服_恋人_mad")
    with Dissolve(0.0/1000)

    xy "\"Я тебя ненавижу.\""

    "Эти слова сошли с моих губ в бормотании."

    xy "\"После всего того, что ты сделала, ты хочешь, чтобы я любил тебя?..\""
    pause (300/1000)
    $ St("C",300,0,0,"fu曽根美雪血まみれ_私服_病み_lost")
    with Dissolve(400.0/1000)
    pause (700/1000)
    voice "voice/c71/42b00010a01.opus"

    mx "\"Да, я уверена, что ты сейчас испытываешь именно такие чувства.\""
    pause (300/1000)
    $ St("C",300,150,0,"fu曽根美雪血まみれ_私服_恋人_lost")
    with Dissolve(400.0/1000)
    pause (700/1000)
    voice "voice/c71/42b00020a01.opus"

    mx "\"Но я знаю, что ТЫ испытываешь другие чувства.\""
    pause (300/1000)
    $ St("C",300,150,0,"fu曽根美雪血まみれ_私服_恋人_mad")
    with Dissolve(300.0/1000)
    pause (700/1000)
    voice "voice/c71/42b00030a01.opus"

    mx "\"И ТЫ сейчас подумал, что сможешь загрузиться со своего сохранения и попробовать ещё раз, да?\""
    pause (300/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
