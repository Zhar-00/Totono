label a7212a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a7213.nss"
    return
label a7212a:
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失a"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    voice "voice/a72/12a00010a01.opus"
    mx "\"Ты... лишишь меня девственности?\""

    "По её просьбе, я взял свой член одной рукой и подвёл его к её проходу."

    "И прежде, чем я смог вставить хотя бы головку—"
    voice "voice/a72/12a00020a01.opus"
    mx "\"Н-н... н-н-н...\""
    xy "\"Просто расслабься, Миюки.\""
    voice "voice/a72/12a00030a01.opus"
    mx "\"Ой... прости!\""
    voice "voice/a72/12a00040a01.opus"
    mx "\"Эм... как-то так?..\""

    "Я прижал член к её проходу, но её губы оставались плотно закрытыми, не пропуская меня таким образом."
    xy "\"Хм... у тебя там всё ещё слишком тесновато.\""
    voice "voice/a72/12a00050a01.opus"
    mx "\"Наверное, я просто... нервничаю...\""
    xy "\"Хоть мы и не на сцене?\""
    show expression ("cg/ev/l/"+imagename["eva7211美雪さんご開帳a_l"]+".jpg") as 絵専 zorder 1010:
        pos (20,175)
    with Dissolve(500.0/1000)
    voice "voice/a72/12a00060a01.opus"

    mx "Это не просто очередная репетиция, знаешь ли! Идиот!"

    "От выражения её лица я даже опешил..."
    xy "\"Я люблю тебя такой, какая ты есть.\""
    xy "\"И я хочу полностью овладеть твоим настоящим \"я\".\""
    voice "voice/a72/12a00070a01.opus"
    mx "\"Шиничи?..\""
    show expression ("cg/ev/l/"+imagename["eva7211美雪さんご開帳b_l"]+".jpg") as 絵捏造窓絵専上 zorder 1110 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/a72/12a00080a01.opus"
    mx "\"О-откуда это у тебя ТАКИЕ заявления?!\""
    voice "voice/a72/12a00090a01.opus"
    mx "\"Предупреждай меня перед тем, как говорить что-то подобное... моё сердце может не выдержать такое... придурок!\""
    scene expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失a"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(500.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
