label e1167b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1168.nss"
    return
label e1167b:
    hide 絵色黒
    $ renpy.music.play("ttb23_ic",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    with Dissolve(0.0/1000)

    "Слова невольно сорвались с моих губ."

    "Но я должен был ожидать это."

    "Всё-таки я не знаю, о каком «кодовом номере» говорила Аой."
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    voice "voice/e11/67b00010a01.opus"

    mx "\"Хе-хе... хе-хе-хе-хе...\""
    voice "voice/e11/67b00020a01.opus"

    mx "\"А-А-А-АХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА—!!!\""
    stop bgm fadeout (5000.0/1000)
    pause (500/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (2000/1000)
    show expression ("cg/bg/"+imagename["bg010610_9_学校教室扉前"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(1000.0/1000)
    pause (300/1000)
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    voice "voice/e11/67b00030a01.opus"

    mx "\"Ты ошибся в наборе?\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/67b00040a01.opus"

    mx "\"О боже, ты забыл секретный кодовый номер Аой?\""
    $ St("C",300,0,0,"st曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e11/67b00050a01.opus"

    mx "\"Как ты мог забыть день рождения своей драгоценной и маленькой Аой-чан?\""
    xy "\"Миюки...\""

    "У меня было такое чувство, будто я впервые за всю свою жизнь увидел Миюки такой... ликующей."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/67b00060a01.opus"

    mx "\"Ну ладно. Я расскажу тебе.\""
    voice "voice/e11/67b00070a01.opus"

    mx "\"В общем, вот...\""
    voice "voice/e11/67b00080a01.opus"

    mx "\"Секретный номер, чтобы вернуть Аой назад...\""
    voice "voice/e11/67b00090a01.opus"
    mx "\"999-0523-0523.\""
    voice "voice/e11/67b00100a01.opus"

    mx "\"Сначала набери 999. А потом набери день рождения Аой - 0523 - дважды.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/67b00110a01.opus"

    mx "\"В чём дело? Ты не собираешься его набирать? После того, как я его уже преподнесла тебе на блюдечке с голубой каёмочкой?\""
    $ St("C",300,0,0,"st曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e11/67b00120a01.opus"

    mx "\"Ну ладно. Давай я наберу его за тебя.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (16/1000)
    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    $ sename = "se人体_動作_奪い取る"
    play se sedict[sename]
    with Dissolve(300.0/1000)

    "Миюки взяла телефон и держала его под таким углом, чтобы я мог увидеть, как она вводила номер, который озвучила мне."
    $ sename = "se物体_携帯_発信待機L"
    play se sedict[sename]
    pause (1500/1000)

    "Она нажала на кнопку вызова."

    "Но..."
    stop se fadeout (150.0/1000)
    voice "voice/e11/67b00130b02.opus"

    kmsm "\"НАБРАННЫЙ ВАМИ НОМЕР СЕЙЧАС НАХОДИТСЯ ВНЕ ЗОНЫ ДОСТУПА.\""

    "Звонок не проходил."
    xy "\"Почему?..\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
