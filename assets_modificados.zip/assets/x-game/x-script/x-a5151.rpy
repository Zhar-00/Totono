label a5151_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010700_2_学校廊下"]=True
    $ PreGameName = GameName
    $ GameName = "a5152.nss"
    return
label a5151:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010600_2_学校教室"]+".jpg")
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve(1000.0/1000)
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a51/5100010b01.opus"
    xtl "Шиничи! Не хочешь заскочить в зал игровых автоматов со—"
    xy "Извини, у меня уже есть планы."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a51/5100020b01.opus"
    xtl "Ох, ладно."
    xy "Увидимся!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010700_2_学校廊下"]+".jpg")
    with Dissolve(500.0/1000)
    "Как только уроки закончились, я собрал свои вещи и встал на ноги."
    "Аой в школу так и не вернулась."
    "Я сделал неправильный выбор вчера ночью?.."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    pause (500/1000)
    $ sename = "se人体_足音_歩く01L"
    play se sedict[sename]
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    pause (500/1000)
    hide 絵色黒
    with Dissolve(500.0/1000)
    "Я забрал Иру с крыши, а потом отправился в манга-кафе."
    "Когда я спросил насчёт Аой, работники сразу поняли, кого я имел в виду. Они сказали мне, что она вышла из кафе рано утром, и так и не вернулась."
    "Судя по их словам, она не выглядела особо больной."
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    with Dissolve(800.0/1000)
    pause (500/1000)
    "Так почему она не пришла в школу?"
    "Неужели она вернулась домой к своим родителям?"
    "Или с ней что-то произошло?"
    show expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg")
    with Dissolve(800.0/1000)
    pause (300/1000)
    "...Никакие теории не помогут мне найти ответ."
    "Я просто мало чего знаю о ней, всё просто."
    stop se fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
