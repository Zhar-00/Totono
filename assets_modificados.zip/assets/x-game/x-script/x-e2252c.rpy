label e2252c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2253.nss"
    return
label e2252c:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg090100_3_コンビニ店内"]+".jpg")
    $ st_timezone = "昼"
    hide StC
    hide StMR
    hide StML
    $ sename = "se人体_動作_衣擦れ04"
    play se sedict[sename]
    with Dissolve(200.0/1000)

    xy "\"Ох...\""

    "Её пальцы внезапно проскользнули между моими."
    voice "voice/e22/52c00010a01.opus"

    mx "\"...Хорошо?\""
    xy "\"Эм... конечно...\""

    "Её тепло растопило все мои сомнения."

    "Эта тонкая, слабая связь наполняла меня глубоким чувством безопасности."

    "...Но потом объявился этот парень."
    hide StC with Dissolve(200.0/1000)
    $ St("C",300,0,0,"st曙雄太郎_バイト_通常_cry")
    with Dissolve(200.0/1000)
    voice "voice/e22/52c00020b01.opus"

    xtl "\"Хн-н-нг... н-н-н... н-н-н...\""
    voice "voice/e22/52c00030b01.opus"

    xtl "\"Уа-а-а-а-а-а-а-а-а-а-а-а-а-а-а-а-а!!!..\""

    "Ютаро дрожал."
    $ St("C",300,0,0,"st曙雄太郎_バイト_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/52c00040b01.opus"

    xtl "\"Я забираю свои слова обратно! Тебе не нужно умирать!\""
    $ St("C",300,0,0,"st曙雄太郎_バイト_通常_gag")
    with Dissolve(200.0/1000)
    voice "voice/e22/52c00050b01.opus"

    xtl "\"Я просто хочу, чтобы ты был счастлив!\""
    voice "voice/e22/52c00060b01.opus"

    xtl "\"Продолжай сражаться, товарищ! Продолжай сражаться!\""

    "...С чем это я должен «сражаться», интересно?.."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
