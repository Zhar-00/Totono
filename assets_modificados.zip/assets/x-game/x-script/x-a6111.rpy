label a6111_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a6121.nss"
    return
label a6111:
    hide 絵色黒
    show expression ("cg/bg/m/"+imagename["bg040100_1_街通学路_m"]+".jpg") as 絵背景 zorder 100 at truecenter
    show expression ("cg/bg/"+imagename["bg040100_1_街通学路"]+".jpg")
    pause (500/1000)
    $ sename = "se人体_足音_歩く01L"
    play se sedict[sename]
    with Dissolve(1500.0/1000)
    "Жизнь – это не шоссе. Жизнь – это лестница."
    "Ты просто должен продолжать подниматься вверх."
    "Иначе, если ты начнёшь задумываться, тебе будет трудно сделать следующий шаг."
    "Здесь нет никаких альтернативных путей."
    "Нет смысла сожалеть о том, чего ты не сделал."
    "Все говорят, что жизнь – это серия выборов, но это чепуха, придуманная старыми и жестокими людьми."
    "Вчерашний день ведёт к сегодняшнему, а сегодняшний – к завтрашнему."
    "Шаг за шагом."
    "Что ждёт впереди?"
    "Никогда не узнаешь, пока не окажешься там."
    stop se fadeout (1000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
