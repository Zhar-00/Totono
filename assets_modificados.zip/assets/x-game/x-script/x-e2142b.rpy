label e2142b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2142b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010800_1_学校体育館"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(0.0/1000)

    xy "\"Мы разве не договорились приберечь его для дебютного выступления?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/e21/42b00010a01.opus"
    mx "\"Но...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/e21/42b00020a01.opus"

    mx "\"Ты обещаешь, что поцелуешь меня?\""

    xy "\"Когда придёт время, да.\""

    "Она посмотрела на меня, и я кивнул ей."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
