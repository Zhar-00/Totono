label e2191_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2191:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ sename = "se人体_足音_歩く複数美雪L"
    play se sedict[sename]
    pause (1000/1000)
    voice "voice/e21/9100010a01.opus"
    mx "\"Хм-хм-хм... Хе-хе-хе...\""
    "Миюки, похоже, была в очень хорошем настроении..."
    xy "\"Произошло что-то классное?\""
    stop se fadeout (300.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/9100020a01.opus"
    mx "\"Хе-хе... Ну, видишь ли... я на днях приняла участие в лотерее, и...\""
    if persistent.miyuki[27] == 0:
        $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
        with Dissolve(200.0/1000)
        voice "voice/e21/9100030a01.opus"
        mx "\"Я выиграла два билета на поездку!\""
        xy "\"Какую ещё поездку?\""
        voice "voice/e21/9100040a01.opus"

        mx "\"Поездку на горячие источники! Не хочешь со—\""
    elif persistent.miyuki[27] == 1:
        $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
        with Dissolve(200.0/1000)
        voice "voice/e21/9100050a01.opus"
        mx "\"Я выиграла ту водяную печь, о которой мечтала!\""
        xy "\"Что ещё за водяная печь?\""
        voice "voice/e21/9100060a01.opus"
        mx "\"Это такая печка, которая использует пар для приготовления еды—\""
    elif persistent.miyuki[27] == 2:
        $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
        with Dissolve(200.0/1000)
        voice "voice/e21/9100070a01.opus"
        mx "\"Я выиграла билеты на предварительный показ фильма!\""
        xy "\"А, да?\""
        voice "voice/e21/9100080a01.opus"
        mx "\"После него состоится встреча, и мой любимый актёр—\""
    xy "\"Погоди...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/9100090a01.opus"

    mx "\"Хм? Что-то не так?..\""
    if persistent.eternal_day or persistent.eternal_day:
        $ GameName = "e2191b.nss";
    else:
        $ GameName = "e2191a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
