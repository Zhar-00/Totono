label c3211_MAIN:
    call expression GameName
    $ persistent.imagelog["bg080100_2_コンビニ外正面"]=True
    $ persistent.imagelog["bg090100_2_コンビニ店内"]=True
    $ PreGameName = GameName
    $ GameName = "a3211.nss"
    return
label c3211:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg080100_2_コンビニ外正面"]+".jpg")
    $ sename = "se物体_チャイム_入店"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg090100_2_コンビニ店内"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(800.0/1000)

    "Как только я вошёл в угловой магазин, я посмотрел на прилавок."

    "За кассой стоял кто-то другой, не Ютаро."
    $ St("C",300,0,0,"st曙龍二郎_バイト_通常_smile")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb09",channel = "bgm", if_changed = True)
    voice "voice/c32/1100010b03.opus"

    c "\"Д-добро—\""
    $ St("C",300,0,0,"st曙龍二郎_バイト_通常_fear")
    with Dissolve(200.0/1000)
    voice "voice/c32/1100020b03.opus"

    c "\"А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-АХ!!!\""
    hide StC with Dissolve(200.0/1000)

    "Она завизжала и попыталась скрыться за прилавком."
    $ sename = "se物体_棚_棚ぶつかる"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg090100_2_コンビニ店内"]+".jpg") as 揺れ背景 zorder 15 at truecenter

    "А потом она снесла полки с сигаретными пачками, стоявшие позади неё."
    $ sename = "se物体_棚_棚崩れる"
    play se sedict[sename]

    "Коробки обрушились на неё лавиной, тем самым захоронив её."
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/c32/1100030a02.opus"

    aoi "\"Это та самая неуклюжая девочка?\""

    xy "\"Да... та самая, с театрального клуба.\""
    hide StC with Dissolve(200.0/1000)

    "Я никоим образом не мог спутать этот душераздирающий крик с чьим-нибудь другим."

    xy "\"Эм... ты там в порядке?\""
    $ St("ML",300,0,0,"st曙龍二郎_バイト_通常_sad")
    voice "voice/c32/1100040b03.opus"

    c "\"Д-да... я в порядке... а-а-ай...\""

    xy "\"Я могу помочь тебе расставить сигаретные пачки обратно—\""
    $ St("ML",300,0,0,"st曙龍二郎_バイト_通常_fear")
    voice "voice/c32/1100050b03.opus"

    c "\"Нет, спасибо! Я сама справлюсь! Не переживай из-за этого!\""
    $ St("ML",300,0,0,"st曙龍二郎_バイト_通常_normal")
    voice "voice/c32/1100060b03.opus"

    c "\"Так или иначе, я к этому уже привыкла.\""
    $ St("MR",300,0,0,"st向日アオイ電波_着ぐるみ_通常_think")
    voice "voice/c32/1100070a02.opus"

    aoi "\"Ты заметил что-нибудь грязное? Её трусики, например?\""
    $ St("ML",300,0,0,"st曙龍二郎_バイト_通常_surprise")
    voice "voice/c32/1100080b03.opus"

    c "\"Что? О боже! Заткнись! Не надо—!\""

    xy "\"Я ничего не видел.\""

    "Да, она носит трусики, тоже мне открытие!"

    xy "\"Ладно, мы сейчас должны сосредоточиться на котёнке.\""
    $ St("MR",300,0,0,"st向日アオイ電波_着ぐるみ_通常_shout")
    voice "voice/c32/1100090a02.opus"
    aoi "\"Ты прав.\""

    xy "\"А, стой—!\""
    play voc "c32/1100100b04"
    show expression ("cg/bg/l/"+imagename["bg090100_2_コンビニ店内_l"]+".jpg") as 上背景 zorder 15:
        pos (-1000,-300)
    hide StC
    hide StMR
    hide StML
    with Dissolve(500.0/1000)

    "Я пытался остановить её, но было уже слишком поздно."

    "Аой достала Иру из своего кармана, и он прыгнул прямо на полку над прилавком."
    $ St("C",300,0,0,"bu曙龍二郎_バイト_通常_fear")
    with Dissolve(200.0/1000)
    voice "voice/c32/1100110b03.opus"

    c "\"А-А-АХ! Семпай, нет!\""
    voice "voice/c32/1100120b03.opus"

    c "\"В наш магазин нельзя впускать питомцев!!!\""
    $ St("C",300,0,0,"bu曙龍二郎_バイト_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c32/1100130b03.opus"

    c "\"А-а-аг-гх-х! Убирайся отсюда, киса—!\""
    hide StC with Dissolve(200.0/1000)

    "Котёнок всё ещё был немного неуклюж в своих движениях..."

    "...но у этой девочки с театрального клуба дела с этим были ещё хуже."
    $ St("C",300,0,0,"bu曙龍二郎_バイト_通常_surprise")
    with Dissolve(200.0/1000)
    $ St("C",300,0,0,"bu曙龍二郎_バイト_通常_pinch")
    voice "voice/c32/1100140b03.opus"

    c "\"Если они узнают, что я впустила тебя в магазин— А-А-А-АХ!\""
    $ St("C",300,0,0,"bu曙龍二郎_バイト_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/c32/1100150b03.opus"

    c "\"То они мне— урежут зарплату— А-А-А-А-А-А-А-А-АХ!!!\""
    $ sename = "se物体_棚_倒れる"
    play se sedict[sename]

    "Она попыталась залезть на полку, чтобы добраться до котёнка, и тут же рухнула вместе с ней."

    "И она снова оказалась погребённой под горой из сигаретных пачек."
    with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/c32/1100160a02.opus"

    aoi "\"Тебе нравятся неуклюжие девушки?\""

    xy "\"Просто заткнись и помоги мне вытащить её оттуда.\""
    stop bgm fadeout (3000/1000)
    show expression Solid("000000") as 絵色黒 zorder 30000
    with Dissolve((2000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
