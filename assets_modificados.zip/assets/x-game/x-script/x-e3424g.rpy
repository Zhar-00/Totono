label e3424g_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3441.nss"
    return
label e3424g:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    with Dissolve(2000.0/1000)
    xy "\"Эй, эм...\""
    $ sename = "se人体_動作_ポケット探る"
    play se sedict[sename]
    "Я вытащил её телефон из кармана."
    xy "\"Прости, что убежал вместе с ним. Я правда не знаю, о чём я думал.\"\n\"Всё нормально.\""
    $ St("C",300,0,0,"fu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e34/24g00010a01.opus"
    mx "\"Я просто рада, что ТЫ решил остаться. Это всё, что мне нужно.\""
    $ St("C",300,0,0,"fu曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e34/24g00020a01.opus"
    mx "\"Но...\"\n\"Я. Сказала. Всё. Нормально.\""
    xy "Похоже, у меня не было права голоса."
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e34/24g00030a01.opus"
    mx "\"Ну а теперь, пошли до—\""
    "\"АПЧХИ!\""
    voice "voice/e34/24g00040a01.opus"
    mx "\"Хм? У тебя опять аллергия?\""
    voice "voice/e34/24g00050a01.opus"

    mx "\"АПЧХИ!\""

    xy "\"Хм? У тебя опять аллергия?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/e34/24g00060a01.opus"
    mx "\"Нет, скорее всего, это из-за того, что у меня волосы ещё не высохли.\""
    xy "\"Но я могу поклясться, что здесь был кот... Что за?\""
    xy "\"Он ушёл?..\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e34/24g00070a01.opus"
    mx "\"Твой мозг всё ещё не проснулся или что?\""
    "Я был не совсем уверен, но... опять же, не похоже, что котёнок мог сам уйти с крыши."
    "Оглядываясь назад, он даже и не выглядел как обычный кот."
    "Он выглядел почти что... потусторонне..."
    xy "\"...Боже, сегодня был странный день.\""
    voice "voice/e34/24g00080a01.opus"
    mx "\"Ты, наверное, устал.\""
    voice "voice/e34/24g00090a01.opus"
    mx "\"А теперь давай пойдём домой и поспим немного.\""
    xy "\"Да, наверное...\""
    hide StC with Dissolve(200.0/1000)
    "После этого, по требованию Миюки, мы ушли с центра вселенной..."
    stop se fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((4000.0+1000.0)/1000)
    pause (2000/1000)
    $ roof = False;
    $ persistent.aoi_call_miss = True;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
