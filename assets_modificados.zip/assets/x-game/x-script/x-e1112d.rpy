label e1112d_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2000.nss"
    return
label e1112d:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/12d00010a01.opus"

    mx "\"......Нет.\""
    voice "voice/e11/12d00020a01.opus"

    mx "\"Ты никогда не получишь то, чего хочешь.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/12d00030a01.opus"

    mx "\"Почему бы тебе просто не любить меня?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_病み_smile")
    voice "voice/e11/12d00040a01.opus"

    mx "\"Для тебя так будет намного легче.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Уклонившись от её вопроса, я решил отхлебнуть немного её домашнего мисо супа."

    "Как только миска коснулась моих губ, мои пальцы начали чесать мой подбородок."

    "...Какого?"

    "С каких пор у меня такая длинная борода?"
    scene expression "cg/bg/black.jpg" zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause 1
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
