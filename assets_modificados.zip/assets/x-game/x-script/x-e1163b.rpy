label e1163b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1164.nss"
    return
label e1163b:
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    $ sename = "se人体_足音_歩く01遅L"
    play se sedict[sename]
    $ sename = "se人体_足音_歩く01L"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    voice "voice/e11/63b00010b01.opus"

    xtl "\"Чувак, ты только посмотри на свои волосы! И на свою бороду!\""
    voice "voice/e11/63b00020b01.opus"

    xtl "\"Я бы тебя ни за что не узнал!\""

    xy "\"На мои что?..\""

    "Как только он упомянул об этом... мои волосы и правда стали довольно длинными..."

    xy "\"Это странно...\""
    voice "voice/e11/63b00030b01.opus"

    xtl "\"Ты ударился головой в той автокатастрофе или что?\""

    xy "\"Нет, нет!\""

    xy "\"По крайней мере... я сомневаюсь в этом...\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
