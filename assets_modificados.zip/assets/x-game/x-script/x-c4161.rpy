label c4161_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ hamonjo = True
    if meet_aoi == False:
        $ GameName = "d4171.nss";
    else:
        call expression (GameName+"_SELECT")
    return
label c4161:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg") as 揺れ背景 zorder 15 at truecenter
    with Dissolve(1000.0/1000)
    pause (300/1000)
    voice "voice/c41/6100010b01.opus"
    xtl "\"......!!!\""
    $ sename = "se人体_衝撃_叩く机02"
    play se sedict[sename]
    pause (500/1000)

    xy "\"Ну и что это такое я вижу?\""
    $ sename = "se物体_紙_掴む"
    play se sedict[sename]
    pause (300/1000)

    "Как только Ютаро вошёл в класс, он подошёл к моей парте и резко положил на неё кусок бумаги."

    "Форма заявления об уходе из клуба."

    "Стоп... над этой надписью что-то написано."

    xy "\"Письмо... об изгнании?..\""
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/6100020b01.opus"

    xtl "\"Похоже, я совершил ошибку, пригласив тебя в клуб РиМ.\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/c41/6100030b01.opus"

    xtl "\"Так что, с этого момента, ты В ПРОЛЁТЕ!!!\""

    xy "\"Ладно.\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/c41/6100040b01.opus"

    xtl "\"Как ты можешь так хладнокровно к этому относиться?!\""

    xy "\"В смысле, я и с самого начала не хотел вступать в него.\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/6100050b01.opus"

    xtl "\"Я даже не подозревал, что ты на деле окажешься таким трусом!\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/c41/6100060b01.opus"

    xtl "\"И ты называешь себя мужчиной?! Разве ты не чувствуешь тяжесть одиночества на своих плечах?! Найди свои мечты! Именно так и живёт настоящий мужчина!\""

    xy "\"Можешь веселиться без меня, приятель.\""

    "Ютаро может кричать столько, сколько ему будет угодно, но я—"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c41/6100070b01.opus"
    xtl "\"......!!!\""
    stop bgm fadeout (500/1000)
    $ sename = "se人体_動作_掴む胸倉"
    $ renpy.vibrate(.3)
    play se sedict[sename]
    show expression ("cg/bg/l/"+imagename["bg010600_1_学校教室_l"]+".jpg") as 絵背景 zorder 15:
        pos (-550,-290)
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    hide 揺れ背景
    xy "\"А?..\""

    "Внезапно Ютаро схватил меня за воротник."

    "Он смотрел на меня с напряжённостью, которая была более неприятной, чем обычно."

    xy "\"Ютаро?..\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    voice "voice/c41/6100080b01.opus"

    xtl "\"Я разрываю с тобой связи.\""
    xy "\"А?..\""
    voice "voice/c41/6100090b01.opus"

    xtl "\"Я не могу дружить с тобой, если ты даже за Муко присмотреть не можешь.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/6100100b01.opus"

    xtl "\"Больше никогда со мной не разговаривай!!!\""

    "Разорвать связи..."

    "Знакомые слова пронзили моё сердце."

    xy "\"Да брось, это не весело.\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/6100110b01.opus"

    xtl "\"Я вовсе не дурачусь. Я серьёзно!\""
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c41/6100120b01.opus"

    xtl "\"Шиничи, я знаю то, что ты знаешь. Если ты позволишь своим мечтам ускользнуть, ты разрушишь свою жизнь.\""
    voice "voice/c41/6100130b01.opus"

    xtl "\"И я знаю, что ты знаешь, что тебе нужно сделать.\""
    return
    return
label c4161_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    show expression ("cg/bg/l/"+imagename["bg010600_1_学校教室_l"]+".jpg") as 絵背景 zorder 15:
        pos (-550,-290)
    with Dissolve(0.0/1000)
    menu:
        "Искать свои мечты":
            $ SetChoiceSelect = 0
        "Забыть об этом":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "c4171.nss"
    elif SetChoiceSelect==1:
        $ GameName = "d4171.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
