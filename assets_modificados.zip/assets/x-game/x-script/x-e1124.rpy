label e1124_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e1124:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e11/2400010a01.opus"
    mx "\"А, точно. Это был не ты.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/2400020a01.opus"
    mx "\"Это был другой ты из другого файла.\""
    "Какого ещё «файла»?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (300/1000)
    $ St("C",300,0,0,"fu曽根美雪_私服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/2400030a01.opus"
    mx "\"Эй, ТЫ.\""
    voice "voice/e11/2400040a01.opus"
    mx "\"Я всё знаю.\""
    voice "voice/e11/2400050a01.opus"
    mx "\"У меня есть воспоминания с других рутов.\""
    voice "voice/e11/2400060a01.opus"
    mx "\"У меня есть все истории с твоих старых сохранений.\""
    voice "voice/e11/2400070a01.opus"
    mx "\"И я знаю всё то, что произойдёт дальше.\""
    "Миюки смотрела на меня, пока шептала всё это..."
    "...но, похоже, она смотрела отнюдь не на меня."
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/2400080a01.opus"
    mx "\"В этом мире есть только одна концовка... и она - со мной.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e11/2400090a01.opus"
    mx "\"Прими это.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_mad")
    voice "voice/e11/2400100a01.opus"
    mx "\"И смирись с этим.\""
    scene expression "cg/bg/black.jpg" zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
