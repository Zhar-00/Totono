label e2154a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2154a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010400_2_学校校門"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(0.0/1000)

    xy "\"Да, меня такое взбесило бы.\""

    "Наше время, проведённое вместе, было особенным."

    "Я не хочу, чтобы какой-то посторонний человек вмешался в это."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
