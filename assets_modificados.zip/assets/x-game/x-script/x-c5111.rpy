label c5111_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5121.nss"
    return
label c5111:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    scene expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg")
    with dissolve

    "На следующее утро..."
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(500.0/1000)
    pause (500/1000)
    $ renpy.music.play("ttb04",channel = "bgm", if_changed = True)
    xy "\"Доброе утро!\""
    voice "voice/c51/1100010b01.opus"
    xtl "\"Эй, доброе утро!\""
    $ St("C",300,0,0,"st向日アオイ_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c51/1100020a02.opus"
    aoi "\"Буп-буп...\""
    voice "voice/c51/1100030b01.opus"
    xtl "\"О, это же Муко!\""
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    hide StC
    hide StMR
    hide StML
    with Dissolve(500.0/1000)
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_hard")
    voice "voice/c51/1100040b01.opus"
    xtl "\"Ты нашёл её?!\""
    xy "\"Да, можно и так сказать.\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_normal")
    voice "voice/c51/1100050b01.opus"
    xtl "\"Здорово! Я так рад за тебя!\""
    $ St("ML",300,0,0,"st向日アオイ_制服_通常_normal")
    voice "voice/c51/1100060a02.opus"
    aoi "\"Ютаро?\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_think")
    voice "voice/c51/1100070b01.opus"
    xtl "\"Д-да? В чём дело?\""

    "Аой подошла к Ютаро и посмотрела ему прямо в глаза."
    $ St("ML",300,0,0,"st向日アオイ_制服_通常_shout")
    voice "voice/c51/1100080a02.opus"
    aoi "\"Спасибо, что присмотрел за мной.\""
    $ St("ML",300,0,0,"st向日アオイ_制服_通常_smile")
    voice "voice/c51/1100090a02.opus"
    aoi "\"Это многое для меня значит.\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_shock")
    voice "voice/c51/1100100b01.opus"
    xtl "\"А?..\""

    "Ютаро посмотрел на её улыбку и застыл на месте."
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_shy")
    voice "voice/c51/1100110b01.opus"

    xtl "\"А-а, точно! Пф-ф! Я просто делал свою работу как капитан клуба \"Ребята и мечты\"!\""
    xy "\"Ого, смотрите, кто смутился...\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_surprise")
    voice "voice/c51/1100120b01.opus"
    xtl "\"Я не смутился!\""
    $ St("ML",300,0,0,"st向日アオイ_制服_通常_think")
    voice "voice/c51/1100130a02.opus"
    aoi "\"Ты цундере?\""

    "О боже, надеюсь, что нет."
    hide StC
    hide StMR
    hide StML
    $ St("MR",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(300.0/1000)
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    voice "voice/c51/1100140b01.opus"
    xtl "\"Кстати, Шиничи.\""
    voice "voice/c51/1100150b01.opus"
    xtl "\"Ты поговорил с ней, верно?\""
    xy "\"Да, поговорил.\""
    $ St("MR",300,0,0,"bu曙雄太郎_制服_通常_shock")
    voice "voice/c51/1100160b01.opus"
    xtl "\"Стоп... Тогда... П-п-получается!!!\""
    voice "voice/c51/1100170b01.opus"
    xtl "\"В-в-в-вы двое занимались этим?!\""
    xy "\"А можно по-русски?\""
    $ St("MR",300,0,0,"bu曙雄太郎_制服_通常_gag")
    voice "voice/c51/1100180b01.opus"
    xtl "\"Зависит от твоего ответа, я могу просто засунуть петарду тебе в жопу и позволить самой природе разгребать твои останки!\""
    xy "\"Ладно, смотри—\""
    hide StMR
    hide StML
    $ sename = "se擬音_コミカル_ヒョコ"
    play se sedict[sename]
    $ St("ML",300,0,0,"bu向日アオイ_制服_挙手_normal")
    voice "voice/c51/1100190a02.opus"
    aoi "\"Мы подзарядились.\""

    xy "\"Аой?! Ты нас подслушивала?!\""
    $ St("MR",300,0,0,"bu曙雄太郎_制服_通常_think")
    voice "voice/c51/1100200b01.opus"
    xtl "\"Это ещё что должно означать?\""
    $ St("ML",300,0,0,"bu向日アオイ_制服_通常_normal")
    voice "voice/c51/1100210a02.opus"
    aoi "\"Мы занимались сексом.\""
    xy "\"Эй!\""
    hide StML with Dissolve(200.0/1000)
    voice "voice/c51/1100220a02.opus"
    aoi "\"М-м ф-фн-нм-мсь ф-фкф-фм.\""
    hide StC
    hide StMR
    hide StML
    hide StL
    hide StR
    $ St("MR",300,0,0,"bu曙雄太郎_制服_通常_shock")
    voice "voice/c51/1100230b01.opus"

    xtl "\"Ч-что ты только что?!..\""

    xy "\"Я более чем уверен, что она просто... чихнула! Я ведь прав, Аой?!\""
    voice "voice/c51/1100240a02.opus"
    aoi "\"М-м ф-фл-лис се-еп-пх-хм-м.\""
    stop bgm fadeout (500.0/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (300/1000)
    hide StC
    hide StMR
    hide StML
    hide StL
    hide StR
    hide 絵演背景
    show expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg")
    with Dissolve(500.0/1000)
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    pause (300/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/c51/1100250a01.opus"
    mx "\"......\""

    "Дверь открылась, и Миюки вошла в класс."

    "Но её обычное \"доброе утро\" на этот раз не прозвучало."

    "Вместо этого, она подошла прямо к нам, поджав губы."
    $ sename = "se人体_足音_歩く美雪体育館"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    hide StC
    hide StMR
    hide StML
    hide StL
    hide StR
    with Dissolve(500.0/1000)
    pause (1200/1000)
    $ St("L",310,0,0,"st向日アオイ_制服_よろけ_sad")
    $ St("R",300,0,0,"st曽根美雪_制服_通常_hard")
    voice "voice/c51/1100260a02.opus"
    aoi "\"Буп-буп... буп... буп...\""

    "Кровь застыла в жилах Аой."

    "Они впервые увидели друг друга за такой долгий промежуток времени."

    "И Аой знает, что Миюки была недовольна её небольшим призрачным актом—"
    $ St("L",300,0,0,"st向日アオイ_制服_よろけ_pain")
    voice "voice/c51/1100270a02.opus"
    aoi "\"М-Миюки... Слушай... Э-эм...\""
    hide StMR
    hide StML
    hide StL
    hide StR
    $ St("R",300,0,0,"st曽根美雪_制服_通常_normal")
    voice "voice/c51/1100280a01.opus"
    mx "\"Шиничи.\""
    xy "\"А?.. Я?\""
    $ sename = "se環境_ガヤ_教室ざわめくL"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    hide StL
    hide StR
    show expression ("cg/bg/m/"+imagename["bg010600_1_学校教室_m"]+".jpg") as 絵演背景 zorder 15:
        pos (-400,-230)
    $ St("R",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(500.0/1000)

    "Миюки проигнорировала Аой и обратилась ко мне."
    $ St("R",300,0,0,"st曽根美雪_制服_通常_hard")
    voice "voice/c51/1100290a01.opus"
    mx "\"Пошли со мной.\""
    xy "\"Что? Но—\""
    $ St("R",300,0,0,"st曽根美雪_制服_病み_hard")
    voice "voice/c51/1100300a01.opus"
    mx "\"Я сказала, ПОШЛИ СО МНОЙ!\""

    "Вот так, королева школы обратилась ко мне, к ничтожеству всего класса, прямо перед всеми."

    "Во всём классе тут же начался галдёж от такого неожиданного сюжетного поворота."
    $ St("R",300,0,0,"st曽根美雪_制服_病み_normal")
    voice "voice/c51/1100310a01.opus"
    mx "\"Давай! Поторапливайся!\""
    xy "\"У-уже иду!\""
    hide 絵演背景
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    hide StC
    hide StMR
    hide StML
    hide StL
    hide StR
    with Dissolve(300.0/1000)
    pause (300/1000)
    $ St("C",300,0,0,"st向日アオイ_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c51/1100320a02.opus"
    aoi "\"Шиничи...\""
    xy "\"Я пойду поговорю с ней. Жди меня здесь, ладно?\""
    hide StC
    hide StMR
    hide StML
    hide StL
    hide StR
    with Dissolve(200.0/1000)
    stop bgm fadeout (2000.0/1000)
    show expression ("cg/bg/"+imagename["bg010700_1_学校廊下"]+".jpg")
    with Dissolve(500.0/1000)
    pause (200/1000)

    "Я попрощался с Аой, после чего развернулся и вышел из класса вместе с Миюки."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
