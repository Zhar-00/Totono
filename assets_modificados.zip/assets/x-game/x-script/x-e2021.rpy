label e2021_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a7211.nss"
    return
label e2021:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e20/2100010a01.opus"
    mx "\"Шиничи.\""
    voice "voice/e20/2100020a01.opus"

    mx "\"Прошёл уже целый месяц.\""
    voice "voice/e20/2100030a01.opus"

    mx "\"Ты знал об этом? Боже, как быстро время летит...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e20/2100040a01.opus"

    mx "\"Особенно когда ТЫ включаешь режим пропуска.\""

    xy "\"Какой ещё режим пропуска?..\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e20/2100050a01.opus"

    mx "\"Эй, Шиничи?\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/e20/2100060a01.opus"

    mx "\"А помнишь... когда у нас был первый секс?\""
    xy "\"Что?\""
    voice "voice/e20/2100070a01.opus"

    mx "\"Помнишь, где мы были, или в какой позе мы им занимались?\""
    voice "voice/e20/2100080a01.opus"

    mx "\"Наверное, ты не помнишь, хм...\""

    xy "\"Н-ну...\""

    "Я не могу отрицать это..."

    "По какой-то причине у меня в голове был сплошной туман..."

    "Я не могу вспомнить..."
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e20/2100090a01.opus"

    mx "\"Тебе не надо скрывать это.\""
    voice "voice/e20/2100100a01.opus"

    mx "\"Знаю! Чтобы отпраздновать наш первый месяц вместе...\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e20/2100110a01.opus"

    mx "\"...я позволю тебе пережить всё это снова.\""
    stop bgm fadeout (500.0/1000)
    pause (16/1000)
    scene expression "cg/bg/black.jpg" zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
