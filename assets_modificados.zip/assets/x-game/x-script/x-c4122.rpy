label c4122_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4131.nss"
    return
label c4122:
    hide 絵色黒
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(500.0/1000)
    voice "voice/c41/2200010a02.opus"

    aoi "\"Он должен трахнуть её.\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_shock")
    voice "voice/c41/2200020b01.opus"

    xtl "\"Н-нгха?!\""

    xy "\"Аой! Следи за своим языком!\""
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/c41/2200030a02.opus"

    aoi "\"Он пристрастится к плотским утехам.\""
    voice "voice/c41/2200040a02.opus"

    aoi "\"Его мужские инстинкты возьмут над ним верх.\""

    xy "\"Ладно, хватит уже, спасибо—\""
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/c41/2200050a02.opus"

    aoi "\"Должна ли Аой трахнуть его?\""

    xy "\"Я же сказал тебе, перестань так говорить!\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_hard")
    voice "voice/c41/2200060b01.opus"

    xtl "\"Рядовой Шиничи!\""

    xy "\"Что? Чего ты на меня так смотришь?\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_shy")
    voice "voice/c41/2200070b01.opus"

    xtl "\"С этого момента, я, Ютаро Акебоно, капитан клуба \"Ребята и мечты\", только что пришёл к соглашению со своими истинными чувствами! Я люблю тебя!\""
    xy "\"Чего, ещё раз?\""
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/c41/2200080a02.opus"

    aoi "\"Это мужская любовь?\""
    voice "voice/c41/2200090b01.opus"

    xtl "\"Я люблю тебя— наверное? В смысле, может быть? Возможно? Скорее всего? По большей части? Почти целиком?\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_gag")
    voice "voice/c41/2200100b01.opus"

    xtl "\"Я... я не... я... я не... я... А-А-АГ-ГХ-Х! Я не знаю! Я сам себя не понимаю!\""
    voice "voice/c41/2200110b01.opus"

    xtl "\"Чёрт побери! Если бы только мои мужские инстинкты дали о себе знать! Кто-нибудь, пожалуйста! Помогите мне пристраститься к плотским утехам!\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_shy")
    voice "voice/c41/2200120b01.opus"

    xtl "\"Ладно! Муко-сан, я рассчитываю на тебя!\""
    $ St("ML",300,0,0,"st向日アオイ電波_制服_密着_normal")
    voice "voice/c41/2200130a02.opus"

    aoi "\"Ты хочешь потрахаться?\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_smile")
    voice "voice/c41/2200140b01.opus"

    xtl "\"Что за вздор! Я джентльмен!\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_shy")
    voice "voice/c41/2200150b01.opus"

    xtl "\"Я не \"трахаюсь\"... я занимаюсь любовью!\""
    $ St("ML",300,0,0,"st向日アオイ電波_制服_密着_shout")
    voice "voice/c41/2200160a02.opus"

    aoi "\"И как ты ею занимаешься?\""
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_surprise")
    voice "voice/c41/2200170b01.opus"

    xtl "\"А, уверен, ты поможешь мне разобраться с этим!\""
    $ sename = "se人体_衝撃_叩く02"
    play se sedict[sename]
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_pinch")
    voice "voice/c41/2200180b01.opus"

    xtl "\"АЙ!\""

    xy "\"Недоумок! Сейчас восемь утра! Не говори об этом дерьме во весь голос!\""
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/c41/2200190a02.opus"

    aoi "\"Ты ревнуешь?\""

    xy "\"Нет!\""
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    stop bgm fadeout (1000/1000)
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg") as 絵演背景 zorder 15 at truecenter
    hide StC
    hide StMR
    hide StML
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(500.0/1000)
    pause (500/1000)
    voice "voice/c41/2200200a01.opus"
    mx "\"Доброе!\""
    voice "voice/c41/2200210b01.opus"

    xtl "\"Д-доброе утро, Сонэ-сан!!!\""
    hide 絵演背景
    hide StC with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)

    "Миюки вошла в класс с высоко поднятой головой, как и обычно."

    "И прежде, чем она прошла к своей парте, она окинула нас взглядом."
    $ St("C",300,0,0,"st曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c41/2200220a01.opus"
    mx "\"......\""
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (600/1000)
    pause (1200/1000)
    show expression ("cg/bg/l/"+imagename["bg010600_1_学校教室_l"]+".jpg") as 絵背景 zorder 15 at truecenter
    $ St("C",300,0,0,"bu向日アオイ電波_制服_よろけ_pain")
    with Dissolve(500.0/1000)

    "Аой тут же переменилась в лице."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_よろけ_sad")
    with Dissolve(200.0/1000)
    voice "voice/c41/2200230a02.opus"
    aoi "\"Шиничи...\""

    xy "\"Не волнуйся. Я разберусь с этим.\""
    stop se fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 30000
    with Dissolve((1500.0+1000.0)/1000)
    hide 絵背景
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
