label a2193_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a2194.nss"
    return
label a2193:
    hide 絵色黒
    $ renpy.music.play("ttb08",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_surprise")
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(0.0/1000)
    $ sename = "se物体_ビニル袋_鳴る"
    play se sedict[sename]
    xy "А теперь пришло время для второго подарка."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_shock")
    "Я достал вторую упаковку, в которой была ещё одна заколка."
    voice "voice/a21/9300010a01.opus"
    mx "О боже, ты не..."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a21/9300020a02.opus"
    aoi "Ты исказил своё передвижение?"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_normal")
    voice "voice/a21/9300030a01.opus"
    mx "Ты купил ОБЕ?"
    show expression im.AlphaMask("cg/ef/"+imagename["efbg猫ヘアピンペア"]+".jpg","cg/data/circle_02_00_1.png") as 絵覆絵背景 zorder 2010 at center
    with Dissolve(500.0/1000)
    "Мне очень повезло, что у них были две такие заколки..."
    hide 絵覆絵背景
    with Dissolve(500.0/1000)
    xy "Одинаковые заколки для тебя и твоей лучшей подружки."
    xy "Ты ведь возьмёшь её, верно?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/a21/9300040a02.opus"
    aoi "Пожалуйста, Миюки..."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_sigh")
    voice "voice/a21/9300050a01.opus"
    mx "...Ха-а..."
    "Миюки вздохнула, признав поражение."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_normal")
    voice "voice/a21/9300060a01.opus"
    mx "Шиничи, ты только что потратил все свои деньги на еду, да?"
    xy "...Это было настолько очевидно?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/a21/9300070a01.opus"
    mx "Начиная с завтрашнего дня, я приготовлю обед для нас обоих. Это должно придать тебе сил на какое-то время."
    xy "Серьёзно?! Ты просто спасительница!"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/a21/9300080a02.opus"
    aoi "Сделано с любовью Миюки."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_shy")
    voice "voice/a21/9300090a01.opus"
    mx "Угх, заткнись! Господи!"
    stop se fadeout (1000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    pause (800/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
