label c4152_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if meet_aoi == True:
        $ GameName = "c4153.nss";
    else:
        $ GameName = "c4161.nss";
    return
label c4152:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg010700_2_学校廊下"]+".jpg")
    with Dissolve(500.0/1000)

    "Я пытался спросить своего классного учителя об Аой, но он мне говорил только \"Мы о ней ничего не слышали\"."

    "Никто ничего не знал даже про её семейные обстоятельства."

    "Очевидно, никто даже не догадывался о том, что она решила остаться в манга-кафе."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    pause (2000/1000)

    "С тех пор..."
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    hide 絵色黒
    with Dissolve(500.0/1000)

    "Я поднялся на \"центр вселенной\" всего один раз."

    "Я подумал, что, возможно, если я позвоню ей отсюда, то сигнал моего телефона сможет дойти до неё."

    "Я знаю, что это были последствия игровой зависимости. Я просто надеялся на чудо."
    $ sename = "se物体_携帯_圏外"
    play se sedict[sename]
    pause (3000/1000)

    "Но сколько раз я не пытался дозвониться..."

    "...звонок до неё так и не доходил."

    "Я получал только сообщения об отсутствии сигнала."
    show expression ("cg/bg/"+imagename["bg900100_1_雰囲気空"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(500.0/1000)

    "Но ведь так оно и бывает, верно?"

    "Кто-то новенький приходит в твою жизнь..."

    "...а потом, не успеваешь и глазом моргнуть, как он уже уходит."

    "Один человек приходит, другой - уходит."

    "Снова и снова."
    show expression ("cg/bg/"+imagename["bg040100_1_街通学路"]+".jpg")
    hide 絵専
    with Dissolve(500.0/1000)

    "Ну и что, что она ушла? Ничего от этого не изменилось."
    show expression ("cg/bg/"+imagename["bg010400_1_学校校門"]+".jpg")
    with Dissolve(500.0/1000)

    "Раз на то пошло, то всё уже вернулось на круги своя."
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve(500.0/1000)

    "Аой больше нет в моей жизни."
    show expression ("cg/bg/"+imagename["bg010700_2_学校廊下"]+".jpg")
    with Dissolve(500.0/1000)

    "Вот и всё."
    show expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg")
    with Dissolve(500.0/1000)

    "Уверен, я вскоре привыкну к этому."
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    with Dissolve(500.0/1000)

    "Я к этому скоро привыкну..."
    show expression ("cg/ef/"+imagename["efbg自宅自室天井消灯"]+".jpg") as 絵背景 zorder 100 at truecenter
    show expression ("cg/bg/"+imagename["bg030200_3_自宅玄関"]+".jpg")
    with Dissolve(500.0/1000)

    "Я привыкну к этому..."
    pause (1000/1000)
    stop bgm fadeout (3000/1000)
    $ EyeCatchIn(2000.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
