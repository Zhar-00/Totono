label a5171_MAIN:
    call expression GameName
    $ persistent.imagelog["bg030201_3_自宅玄関消灯"]=True
    $ persistent.imagelog["bg030301_3_自宅リビング消灯"]=True
    $ persistent.imagelog["bg030500_3_自宅廊下２階消灯"]=True
    queue bgm "ttb18"
    $ PreGameName = GameName
    if no_call == True:
        $ GameName = "b5172.nss"
    else:
        $ GameName = "a5172.nss"
    return
label a5171:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030401_3_自宅廊下消灯"]+".jpg")
    show expression Solid("000000") as 絵色黒
    with Dissolve(0.0/1000)
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    pause (500/1000)
    $ sename = "se物体_インターホン_鳴る連打"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(1000.0/1000)
    xy "...Фух..."
    "Как только я начал спускаться по лестнице, я вздохнул с облегчением."
    "Я попытался успокоиться, но моё сердце колотилось как сумасшедшее."
    "Меня спас дверной звонок... в буквальном смысле."
    show expression ("cg/bg/"+imagename["bg030201_3_自宅玄関消灯"]+".jpg")
    $ st_timezone = "夜"
    with Dissolve(500.0/1000)
    pause (500/1000)
    "Как же хорошо, что я додумался позвать его сюда."
    "Он пришёл сюда намного быстрее, чем я того ожидал. Дружба – такая прекрасная ве—"
    show expression ("cg/bg/l/"+imagename["bg030201_3_自宅玄関消灯_l"]+".jpg") as 絵背景 zorder 100 at truecenter
    pause (1000/1000)
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]
    pause (2000/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(1000.0/1000)
    $ renpy.music.play("ttb19",channel = "bgm", if_changed = True)
    pause (1500/1000)
    xy "...А?"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    $ sename = "se物体_バット_地面叩く"
    play se sedict[sename]
    pause (700/1000)
    voice "voice/a51/7100010a01.opus"
    mx "Почему?"
    "Её бейсбольная бита упала на пол."
    voice "voice/a51/7100020a01.opus"
    mx "Почему ты здесь?"
    voice "voice/a51/7100030a01.opus"
    mx "Что ещё за «дела» у тебя вдруг «появились»?"
    voice "voice/a51/7100040a01.opus"
    mx "Ты просто пытался избежать встречи со мной?"
    xy "Нет, я вовсе не—"
    hide StC with Dissolve(0.0/1000)
    hide 絵背景
    $ sename = "se物体_バット_転がる"
    play se sedict[sename]
    with Dissolve(300.0/1000)
    pause (1000/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_病み_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/7100050a01.opus"
    mx "Эта обувь."
    xy "А?"
    "Я посмотрел вниз и увидел пару женских туфель, лежавших у порога."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/a51/7100060a01.opus"
    mx "Она принадлежит Аой."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/7100070a01.opus"
    mx "Аой наверняка здесь."
    xy "Н-нет, эм—"
    $ St("C",300,0,0,"st曽根美雪_制服_病み_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/7100080a01.opus"
    mx "Получается, ты проигнорировал мою просьбу..."
    voice "voice/a51/7100090a01.opus"
    mx "...и решил остаться здесь, вместе с Аой."
    xy "Это не то, что ты поду—"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/a51/7100100a01.opus"
    mx "Я хочу увидеть её."
    xy "Стой—"
    voice "voice/a51/7100110a01.opus"
    mx "Я захожу."
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    xy "Стой— ЭЙ! Я сказал, стой!"
    show expression ("cg/bg/"+imagename["bg030301_3_自宅リビング消灯"]+".jpg")
    with Dissolve(500.0/1000)
    stop se fadeout (1000.0/1000)
    pause (500/1000)
    voice "voice/a51/7100120a01.opus"
    mx "Аой! Где ты? Выходи!"
    play voc "a51/7100130b04"
    voice "voice/a51/7100140a01.opus"
    mx "Уйди с дороги! Давай, иди отсюда!"
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Иру попытался потереться об ногу Миюки, но она не проявила к нему интереса. Вместо этого она продолжила искать мою гостиную."
    "Я не собираюсь пытаться отговорить её от этого."
    "И вместо этого я решил рассказать ей правду."
    xy "Миюки, просто выслушай меня! Я всё объясню!"
    xy "Ты знаешь, как важен ей её телефон? В общем, дело в том, что он потерялся."
    xy "Она была напугана, говорила, что без него потеряет все свои воспоминания, и поэтому я решил помочь ей с поисками—"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/a51/7100150a01.opus"
    mx "И ты серьёзно поверил в это?"
    xy "В смысле... не совсем, но..."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/7100160a01.opus"
    mx "У нас были планы. Но ты выбрал Аой."
    xy "Ну, у неё было плохое самочувствие—"
    voice "voice/a51/7100170a01.opus"
    mx "Я не хочу это слышать."
    hide StC with Dissolve(200.0/1000)
    show expression ("cg/bg/"+imagename["bg030401_3_自宅廊下消灯"]+".jpg")
    pause (300/1000)
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    "После безуспешной попытки найти гостиную, она начала подниматься по лестнице."
    xy "Не— ЭЙ!"
    "О чёрт. Она идёт к моей комнате."
    "Аой там, скорее всего, всё ещё одевается!"
    xy "Миюки! Можешь, пожалуйста, притормозить?!"
    $ sename = "se人体_足音_階段自宅上がる01"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg030500_3_自宅廊下２階消灯"]+".jpg")
    with Dissolve(500.0/1000)
    "Я побежал за ней на второй этаж."
    stop bgm fadeout (3000.0/1000)
    pause (500/1000)
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]
    pause (1500/1000)
    voice "voice/a51/7100180a01.opus"
    mx "......"
    "И я увидел, как она молча смотрела на вход в мою комнату... стоя абсолютно неподвижно."

    "Она сдерживала свой гнев, или—?"
    voice "voice/a51/7100190a01.opus"
    mx "......"
    pause (500/1000)
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/bg/l/"+imagename["bg030100_3_自宅自室_l"]+".jpg") as 絵背景 zorder 100:
        pos (-1024,-480)
        linear 30 xpos -240
    with Dissolve(1000.0/1000)
    pause (1200/1000)
    "Я нерешительно глянул мимо неё в свою комнату."
    xy "......"
    "Там было пусто."
    "Аой пропала."
    "Она... исчезла?.."
    pause (200/1000)
    hide 絵背景
    with Dissolve(700.0/1000)
    pause (500/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(400.0/1000)
    pause (1000/1000)
    voice "voice/a51/7100200a01.opus"
    mx "Где она?"
    xy "Я... я не знаю!.."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a51/7100210a01.opus"
    mx "В смысле ты не знаешь?!"
    xy "Возможно, она ушла, чтобы найти свой телефон."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/7100220a01.opus"
    mx "Без своей обуви?"
    xy "Она была не в себе. Наверное, она обула мою обувь по ошибке, когда уходила."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a51/7100230a01.opus"
    mx "О, вот как..."
    "Миюки, похоже, такое нисколько не убедило."
    "Даже я понимаю, что это дерьмовая история для прикрытия."
    "Я просто не хочу, чтобы всё стало ещё хуже—"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
