label e1168_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ renpy.full_restart()
    return
label e1168:
    hide 絵色黒
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    if (BackFile == "e1167a.nss"):
        $ sename = "se人体_足音_歩く美雪"
        play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"fu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/6800010a01.opus"
    mx "\"Хочешь узнать, почему?\""
    $ store_say("","    999-0523-0523.");
    $ store_say("","    Всё верно. Ты ввёл его правильно.");
    $ store_say("","    Это кодовый номер Аой... номер, имеющий способность вернуть её назад.");
    $ store_say("","    Секрет, о котором должны были знать только ты и Аой.");
    $ store_say("","    Но, к твоему сожалению, я его тоже знаю.");
    $ store_say("","    Я управляю всей этой игрой, знаешь ли.");
    $ store_say("","    Я могу прочитать историю диалогов в любое время.");
    $ store_say("","    И пока я знаю этот номер, я могу с лёгкостью перенаправить его.");
    $ store_say("","    Есть также и другие кодовые номера, но что с того?");
    $ store_say("","    Даже если ты сможешь связаться с Богом и узнаешь номер... я узнаю об этом прямо вместе с тобой.");
    $ store_say("","    И потом я просто перенаправлю звонок в иное место.");
    $ store_say("","    Пока ТЫ находишься в этой игре—");
    $ store_say("","    Я НИ ЗА ЧТО не позволю ТЕБЕ вернуть Аой!");
    $ St("C",300,0,0,"fu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/6800020a01.opus"
    mx "\"Так почему бы тебе не проверить историю диалогов?\""
    $ St("C",300,0,0,"fu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/6800030a01.opus"
    mx "\"Именно так я узнала и твоё местоположение тоже.\""
    voice "voice/e11/6800040a01.opus"
    mx "\"Я отследила тебя, просмотрев записи в истории.\""
    xy "\"Что ещё за «история», чёрт побери?..\""
    "О чём она вообще говорит?"
    "Неужели и правда нет способа вернуть Аой?.."
    "И нет даже способа спасти Миюки?.."
    $ St("C",300,0,0,"fu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/6800050a01.opus"
    mx "\"Просто сдайся уже.\""
    voice "voice/e11/6800060a01.opus"
    mx "\"Ты останешься здесь, в этом мире, со мной.\""
    $ St("C",300,0,0,"fu曽根美雪_制服_病み_mad")
    voice "voice/e11/6800070a01.opus"
    mx "\"На долгие... долгие... годы...\""
    $ persistent.miyuki_noescape = False;
    $ persistent.world_recreate = True;
    python:
        if persistent.passed_world_recreate_month == None or persistent.passed_world_recreate_day == None:
            from time import strftime, localtime
            persistent.passed_world_recreate_month = int(strftime("%m",localtime()))
            persistent.passed_world_recreate_day = int(strftime("%d",localtime()))
            persistent.DIARY_COUNT += 1
    pause (16/1000)
    stop se fadeout (220.0/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
