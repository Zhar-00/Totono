label e2323b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2323b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)

    "И всё же... мне было интересно."

    "Кто такой «Бог»?"

    "Движимый своим любопытством, я коснулся экрана—"
    $ sename = "se物体_携帯_発信待機L"
    play se sedict[sename]
    pause (5000/1000)
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]
    pause (1000/1000)
    $ renpy.music.play("bgm/ttb27.opus",channel = "music", if_changed = True)
    $ renpy.music.play("ttb27_ef",channel = "bgm", if_changed = True)
    pause (16/1000)
    pause (6000/1000)

    "......Стоп, что за?"

    "Этот рингтон—"
    voice "voice/e23/23b00010a01.opus"

    mx "\"Алло?\""

    xy "\"Эм... алло?..\""
    if (persistent.meta_sex):
        $ GameName = "e2324b.nss";
    else:
        $ GameName = "e2324a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
