label e1134c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1162.nss"
    return
label e1134c:
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    with Dissolve(0.0/1000)
    scene expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    voice "voice/e11/34b00030a01.opus"

    mx "\"Ты обманул меня.\""
    voice "voice/e11/34b00040a01.opus"

    mx "\"Я изменю это.\""
    voice "voice/e11/34b00050a01.opus"

    mx "\"Я изменю этот мир так же, как и саму игру...\""

    "Её маленький зловещий шёпот звенел у меня в ушах."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (500/1000)
    show expression ("cg/bg/"+imagename["bg040400_2_街交差点"]+".jpg")
    pause (500/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (200/1000)
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_pinch")
    voice "voice/e11/34b00060b01.opus"

    xtl "\"Ха-а... ха-а... н-нгх... Господи Иисусе, чувак!\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/e11/34b00070b01.opus"

    xtl "\"Какого чёрта ты так внезапно схватил меня и побежал?!\""

    "Даже я не знаю, зачем я сделал это."

    "Я не мог придумать причину, по которой мне захотелось сбежать от Миюки."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/34b00080b01.opus"

    xtl "\"А ведь у меня только появился шанс поговорить с Сонэ-сан...\""

    xy "\"...Ты всё ещё не забыл о ней?\""

    xy "\"Почему ты не довольствуешься своей Аой?\""

    "Насколько я помню, Ютаро недавно начал играть в визуальные новеллы, чтобы пережить своё тяжкое одиночество в реальной жизни..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
