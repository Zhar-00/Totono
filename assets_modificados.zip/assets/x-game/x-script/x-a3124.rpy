label a3124_MAIN:
    call expression GameName
    $ persistent.imagelog["efevアオイの瞳"]=True
    $ persistent.imagelog["eva0113アオイ送信中b"]=True
    $ persistent.imagelog["bg010300_9_学校屋根"]=True
    $ persistent.imagelog["bg900100_9_雰囲気空渦"]=True
    queue bgm "tts_in"
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label a3124:
    hide 絵色黒
    if PreGameName == "e2324g":
        stop music
        show expression ("cg/ev/"+imagename["eva7211美雪私がバースデープレゼントa"]+".jpg") as 絵演 zorder 2010 at center
        pause .05
        show expression ("cg/ef/"+imagename["efevアオイの瞳"]+".jpg") as 絵演 zorder 2010 at center
        show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
        with Dissolve(0.0/1000)
        $ sename = "se環境_自然_風L"
        play se sedict[sename]
        show expression ("cg/ef/"+imagename["efevアオイの瞳"]+".jpg") as 絵演 zorder 1010 at center
    else:
        show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
        $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
        with Dissolve(0.0/1000)
        show expression ("cg/ef/"+imagename["efevアオイの瞳"]+".jpg") as 絵演 zorder 1010 at center
        $ sename = "se環境_自然_風L"
        play se sedict[sename]
        with Dissolve(800.0/1000)
    pause (300/1000)
    "Её глаза блестели с неземным отблеском."
    xy "А?.."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    hide 絵演
    with Dissolve(800.0/1000)
    "Внезапно что-то пошло не так."
    "Я посмотрел наверх и увидел тёмные облака, кружащиеся в небе над нами."
    "Ещё секунду назад был прекрасный солнечный день... но теперь нас окружала бушующая буря."
    "Такое чувство, будто само время засосало в потусторонний портал, от чего мы оказались в чистилище между закатом и ночью."
    "Мир начал разрушаться."
    "Защитная оболочка распадалась, а сама граница пошатывалась, грозясь раскрыть всё то, что находится за её пределами..."
    show expression ("cg/ev/l/"+imagename["eva0113アオイ送信中b_l"]+".jpg") as 絵専 zorder 800:
        align (.5,.5)
    $ sename = "se人体_動作_腕を上げる"
    play se sedict[sename]
    hide 絵演背景
    with Dissolve(800.0/1000)
    $ renpy.music.play("tts_in",channel = "bgm", if_changed = True)
    voice "voice/a31/2400010a02.opus"
    aoi "Буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп..."
    xy "Аой?.."
    xy "Что ты делаешь?"
    voice "voice/a31/2400020a02.opus"
    aoi "Буп-буп..."
    voice "voice/a31/2400030a02.opus"
    aoi "Коллекция сценок с событиями, связанных с Шиничи, собрана."
    voice "voice/a31/2400040a02.opus"
    aoi "Перезарядка завершена. Теперь Аой может передать данные Богу... а потом..."
    voice "voice/a31/2400050a02.opus"
    aoi "Вселенная получит патч с обновлением."
    "Эм... патч с обновлением?.."
    "Наподобие тех вещей, которые компьютерная программа скачивает из Интернета?"
    voice "voice/a31/2400060a02.opus"
    aoi "Если так пойдёт и дальше, сюжетная линия сломается."
    voice "voice/a31/2400070a02.opus"
    aoi "Шиничи и Миюки в итоге не будут вместе."
    voice "voice/a31/2400080a02.opus"
    aoi "А это не очень хорошо."
    voice "voice/a31/2400090a02.opus"
    aoi "Поэтому Аой попросит Бога переписать вселенную."
    voice "voice/a31/2400100a02.opus"
    aoi "Таким образом, Миюки не будет встречаться с кем-то другим."
    voice "voice/a31/2400110a02.opus"
    aoi "И следовательно, тебя никто не кинет."
    return
label a3124_SELECT:
    if not persistent.world_recreate:
        $ renpy.save("lastsel")
    $ renpy.music.play("tts_in",channel = "bgm", if_changed = True)
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    show expression ("cg/ev/l/"+imagename["eva0113アオイ送信中b_l"]+".jpg") as 絵専 zorder 800 at truecenter
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    with Dissolve(200.0/1000)
    menu:
        "Остановить её":
            $ SetChoiceSelect = 0
        "Позволить ей сделать это":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "a3124a.nss"
        $ aoi_stop = True
    elif SetChoiceSelect==1:
        $ GameName = "a3124b.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
