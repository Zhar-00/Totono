label e2202b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2202b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    pause (300/1000)

    "Похоже, моё любопытство взяло надо мной верх."

    "Я незаметно взял телефон, и—"
    if (persistent.world_recreate):
        menu:
            "Просмотреть её фотографии":
                $ SetChoiceSelect = 0
            "Просмотреть её список контактов":
                $ SetChoiceSelect = 1
    else:
        menu:
            "Просмотреть её фотографии":
                $ SetChoiceSelect = 0
            "Просмотреть её список контактов":
                $ SetChoiceSelect = 1
            "Запустить игру":
                $ SetChoiceSelect = 2
    if (SetChoiceSelect==2):
        $ GameName = "e2209a.nss";
    elif (SetChoiceSelect==0):
        $ GameName = "e2203a.nss";
    elif SetChoiceSelect==1:
        if (persistent.world_recreate):
            if (not persistent.call_known):
                $ GameName = "e2203c.nss";
            elif (persistent.meta_sex):
                $ GameName = "e2203f.nss";
            else:
                $ GameName = "e2203e.nss";
        else:
            if (persistent.call_known):
                $ GameName = "e2203e.nss";
            else:
                $ GameName = "e2203c.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
