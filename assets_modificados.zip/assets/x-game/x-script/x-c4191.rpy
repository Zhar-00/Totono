label c4191_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4201.nss"
    return
label c4191:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg040200_3_街川縁"]+".jpg")
    $ sename = "se環境_自然_川縁夜L"
    play se sedict[sename]
    with Dissolve(3000.0/1000)

    "Луна сегодня великолепна."

    "Пока я шёл по реке, вокруг стрекотали сверчки."
    show expression ("cg/bg/"+imagename["bg050100_3_バッティングセンター外正面"]+".jpg")
    with Dissolve(500.0/1000)

    "Я не возвращался на бейсбольное поле с того рокового дня."
    stop se fadeout (2000.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
