label a0122_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a0131.nss"
    return
label a0122:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    xy "Эй, ты."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200/1000)
    voice "voice/a01/2200010a02.opus"
    bm "Буп-буп?"
    "Её выражение лица было абсолютно пустым."
    "Я понятия не имею, о чём она думает."
    xy "Вся эта... неразбериха с «перезарядкой», что была раньше? Что это было?"
    voice "voice/a01/2200020a02.opus"
    bm "Перезарядка моего «Зеппи»."
    xy "Ладно, эм, что за «Зеппи»?"
    voice "voice/a01/2200030a02.opus"
    bm "Секс."
    voice "voice/a01/2200040b01.opus"
    xtl "СЕ-Е-Е-ЕКС?!"
    show expression ("cg/bg/l/"+imagename["bg010200_2_学校屋上_l"]+".jpg") as 絵演雄太郎背景 zorder 1000:
        zoom 2
        yalign .5
    show expression im.AlphaMask("cg/bu/2/"+imagename["bu曙雄太郎_制服_通常_surprise"]+".jpg","cg/bu/mask/"+imagename["bu曙雄太郎_制服_通常_surprise"]+".jpg") as 絵演雄太郎 zorder 1000 at center
    with hpunch
    $ renpy.vibrate(.3)
    $ sename = "se人体_衝撃_取り上げる"
    play se sedict[sename]
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    voice "voice/a01/2200050b01.opus"
    xtl "Вы, ребята, трахались здесь?!"
    xy "Нет!"
    hide 絵演雄太郎背景
    hide 絵演雄太郎
    voice "voice/a01/2200060a02.opus"
    bm "Почти."
    voice "voice/a01/2200070b01.opus"
    xtl "Какое ещё нахрен «почти»?!"
    show expression ("cg/bg/l/"+imagename["bg010200_2_学校屋上_l"]+".jpg") as 絵演雄太郎背景 zorder 1000:
        zoom 2
        yalign .5
    show expression im.AlphaMask("cg/bu/2/"+imagename["bu曙雄太郎_制服_通常_cry"]+".jpg","cg/bu/mask/"+imagename["bu曙雄太郎_制服_通常_cry"]+".jpg") as 絵演雄太郎 zorder 1000 at center
    with hpunch
    $ renpy.vibrate(.3)
    $ sename = "se人体_衝撃_取り上げる"
    play se sedict[sename]
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    voice "voice/a01/2200080b01.opus"
    xtl "Как это вообще работает?! Где ты проводишь черту?! Типа, если сунул только головку, то это не считается?! И это круто, когда ты вошёл только на половину?!"
    xy "Нет, это не круто!"
    show expression im.AlphaMask("cg/bu/2/"+imagename["bu曙雄太郎_制服_通常_think"]+".jpg","cg/bu/mask/"+imagename["bu曙雄太郎_制服_通常_think"]+".jpg") as 絵演雄太郎 zorder 1000
    voice "voice/a01/2200090b01.opus"
    xtl "Не круто?"
    hide 絵演雄太郎背景
    hide 絵演雄太郎
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200/1000)
    voice "voice/a01/2200100a02.opus"
    bm "Не круто?"

    "Поверить не могу, что мне придётся объяснять это..."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200/1000)
    voice "voice/a01/2200110a02.opus"
    bm "Буп-буп?.."
    voice "voice/a01/2200120a02.opus"
    bm "Ты должен активировать флаг события."
    voice "voice/a01/2200130a02.opus"
    bm "Ты должен набрать больше очков привязанности, иначе твоя затея не увенчается успехом."
    xy "Это не видеоигра."
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(200/1000)
    voice "voice/a01/2200140a02.opus"
    bm "А, поняла!"

    "Она подняла свою руку в воздух, словно антенну, которой должна была поймать радиоволны."
    voice "voice/a01/2200150a02.opus"
    bm "Аой – это романтический выбор."
    voice "voice/a01/2200160a02.opus"
    bm "А этот мир – видеоигра."
    show expression Solid("000000") as 絵演色黒 zorder 5000
    with Dissolve((200+1000)/1000)
    "Таких людей обычно называют так: «заядлый геймер»."
    "Я не совсем уверен, каким было первоначальное определение этого термина, но в последнее время мы под ним подразумеваем людей, которые не могут отличить игру от реальности."

    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(0/1000)
    hide 絵演色黒
    voice "voice/a01/2200170a02.opus"
    bm "Но..."
    voice "voice/a01/2200180a02.opus"
    bm "Твоя подруга детства с длинными тёмными волосами – главная героиня."
    voice "voice/a01/2200190a02.opus"
    bm "Рут Аой подождёт."
    voice "voice/a01/2200200a02.opus"
    bm "Пока-пока."
    $ sename = "se人体_足音_歩くアオイL"
    play se sedict[sename]
    pause 1
    hide StC
    with Dissolve(.2)
    xy "Что? Эй, стой—!"
    $ sename = "se物体_ドア鉄_閉まる02"
    play se sedict[sename]
    pause (500/1000)
    scene expression ("cg/bg/"+imagename["bg010210_2_学校屋上屋根向"]+".jpg")
    with dissolve
    "Но она проигнорировала меня и убежала вниз по лестнице."
    pause (1000/1000)
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with Dissolve(200/1000)
    voice "voice/a01/2200210b01.opus"
    xtl "Ха-а-а..."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(200/1000)
    voice "voice/a01/2200220b01.opus"
    xtl "Эта девушка всегда такая загадочная."
    xy "В каком смысле «всегда»?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200/1000)
    voice "voice/a01/2200230b01.opus"
    xtl "Что самое главное, ты должен мне всё объяснить! Почему, чёрт побери, Сонэ-сан так взбесилась?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_angry")
    with Dissolve(200/1000)
    voice "voice/a01/2200240b01.opus"
    xtl "И теперь у тебя впридачу появилась Муко? Ты паршивец! Ты норми? Ты сраный норми?!"
    xy "Секундочку..."
    xy "Ты... Ты ЗНАЕШЬ её?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with Dissolve(200/1000)
    voice "voice/a01/2200250b01.opus"
    xtl "Что? Ты серьёзно?"
    voice "voice/a01/2200260b01.opus"
    xtl "Та глупышка? Это была Аой Муко."
    voice "voice/a01/2200270b01.opus"
    xtl "Она в нашем классе учится, чувак!"
    scene expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000+1000)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
