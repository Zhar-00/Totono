label e1157_MAIN:
    call expression GameName
    $ persistent.imagelog["bg100100_2_マンション外正面"]=True
    $ PreGameName = GameName
    return
label e1157:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110200_3_マンション玄関鍵開け"]+".jpg")
    with Dissolve(500.0/1000)
    xy "\"......Стоп, какого?\""
    "Моя обувь пропала."
    $ sename = "se物体_棚_開ける"
    play se sedict[sename]
    "Я тут же начал копаться в обувных коробках в шкафу, и наконец-то нашёл её; она стояла там в самом конце."
    "Не могу поверить, что Миюки решила перейти все границы, чтобы запихать её туда..."
    "Как и всегда, она была той ещё чудачкой..."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg040400_2_街交差点"]+".jpg")
    pause (500/1000)
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    pause (500/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    "Ладно, теперь я на улице."
    "Но куда мне идти?"
    "У меня в голове не было определённого направления—"
    voice "voice/e11/5700010b01.opus"
    xtl "\"...Шиничи?\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/5700020b01.opus"
    xtl "\"Э-эй! Это же ты?! Это точно ты!\""
    xy "\"О, привет, Ютаро! Как раз вовремя!\""
    if (miyuki_chase):
        $ GameName = "e1158a.nss";
    else:
        $ GameName = "e1161.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
