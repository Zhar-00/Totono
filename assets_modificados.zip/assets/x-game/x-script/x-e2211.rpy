label e2211_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2211:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ st_timezone = "昼"
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    stop se fadeout (20000.0/1000)
    xy "\"Ладно, пошли.\""
    voice "voice/e22/1100010a01.opus"
    mx "\"......\""
    xy "\"Хм? Что-то не так?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e22/1100020a01.opus"
    mx "\"У нас дальше будет физкультура, так ведь?\""
    xy "\"Да?\""
    if persistent.miyuki[15] == 0:
        $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
        with Dissolve(200.0/1000)
        voice "voice/e22/1100030a01.opus"
        mx "\"Ненавижу волейбол.\""
    elif persistent.miyuki[15] == 1:
        $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
        with Dissolve(200.0/1000)
        voice "voice/e22/1100040a01.opus"
        mx "\"Ненавижу бег.\""
    elif persistent.miyuki[15] == 2:
        $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
        with Dissolve(200.0/1000)
        voice "voice/e22/1100050a01.opus"
        mx "\"Ненавижу теннис.\""
    xy "\"Но ты так хороша в этом!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/e22/1100060a01.opus"
    mx "\"Да, но я всё равно это ненавижу.\""
    voice "voice/e22/1100070a01.opus"
    mx "\"Я хочу пропустить урок.\""
    xy "\"......Ха-а...\""
    "Большую часть времени Миюки вела себя как прилежная ученица."
    "Но когда дело доходило до этого, это была всего лишь игра. В глубине души, она была всё такой же асоциальной, как и в начальной школе."
    xy "\"У тебя от этого могут быть большие неприятности, ты понимаешь это?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/1100080a01.opus"
    mx "\"А что насчёт тебя?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/1100090a01.opus"
    mx "\"Хочешь пропустить урок со мной?\""
    if persistent.eternal_day or persistent.eternal_day:
        $ GameName = "e2212a.nss";
    else:
        menu:
            "Пропустить урок вместе с ней":
                $ SetChoiceSelect = 0
            "Пропускать уроки - для дураков":
                $ SetChoiceSelect = 1
        if SetChoiceSelect==0:
            $ persistent.miyuki_love += 1
            $ GameName = "e2212a.nss";
        elif SetChoiceSelect==1:
            $ persistent.miyuki_love -= 1
            $ GameName = "e2212b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
