label a1132a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a1133.nss"
    return
label a1132a:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    with Dissolve((0.0)/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演葵背景 zorder 1050 at center:
        xpos (512-150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg","cg/st/mask/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg") as 絵演葵立絵 zorder 1100 at center:
        xpos (512+150)
    xy "Конечно, звучит здорово."
    pause (16/1000)
    hide 絵板写
    with Dissolve(200.0/1000)
    voice "voice/a11/32a00010a02.opus"
    aoi "Правда?"
    "Быть может, если у неё будет пара хороших друзей, с которыми можно провести время, она перестанет так вести себя."
    pause (16/1000)
    show expression im.AlphaMask("cg/st/1/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg","cg/st/mask/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg") as 絵演葵立絵 zorder 1100 at center:
        xpos (512+150)
    hide 絵板写
    with Dissolve(200.0/1000)
    xy "Но тебе не стоит рассчитывать на меня."
    xy "Говорят, что мужчина и женщина не могут быть друзьями."
    xy "Но, быть может, ты и Миюки могли бы—"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
