label e1133_MAIN:
    call expression GameName
    $ PassFile_e1133 = True;
    $ PreGameName = GameName
    return
label e1133:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110200_3_マンション玄関鍵開け"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    pause (300/1000)
    $ sename = "se物体_ドア自宅_鍵開ける02"
    play se sedict[sename]

    "Она открыла дверь и вышла наружу."

    "Я последовал за ней—"

    xy "\"Стоп... А где моя обувь?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/3300010a01.opus"

    mx "\"Ой, прости. Я поставила её в сторонку.\""
    hide StC with Dissolve(200.0/1000)
    $ sename = "se物体_靴箱_取り出す"
    play se sedict[sename]

    "Она тут же вернулась и вытащила мою обувь из шкафа."

    "Типичная Миюки... Она обожает раскладывать всё по своим местам..."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (500/1000)

    xy "\"Такая прогулка по улицам с тобой вызывает у меня ностальгию.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/3300020a01.opus"

    mx "\"Да, есть такое.\""
    hide StC with Dissolve(200.0/1000)
    $ sename = "se人体_足音_歩く複数美雪L"
    play se sedict[sename]

    "Не знаю, почему я испытывал такие чувства, но так оно и было..."

    "Моё тело было на удивление тяжёлым."

    "Наверное, мне стоит чаще тренироваться..."
    voice "voice/e11/3300030b01.opus"

    xtl "\"Хм?\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/e11/3300040b01.opus"

    xtl "\"О, привет, Шиничи! Это правда ты!\""

    "Ютаро позвал меня из толпы."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_happy")
    with Dissolve(200.0/1000)
    voice "voice/e11/3300050b01.opus"

    xtl "\"Блин... Давно не виделись! Ты ничуть не изменился!\""

    xy "\"...Давно не виделись?..\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/3300060b01.opus"

    xtl "\"Тебе уже лучше?\""

    xy "\"О чём ты говоришь?\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/e11/3300070b01.opus"

    xtl "\"А? Ты ведь был в больнице, верно?\""
    voice "voice/e11/3300080b01.opus"

    xtl "\"После той автокатастрофы?\""

    "...Какой ещё автокатастрофы?"
    voice "voice/e11/3300090a01.opus"

    mx "\"Эй, Акебоно-кун?\""
    show expression ("cg/bg/m/"+imagename["bg040300_2_街商店街_m"]+".jpg") as 絵背景 zorder 20 at truecenter
    $ St("C",300,30,0,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(500.0/1000)
    voice "voice/e11/3300100b01.opus"

    xtl "\"Да?! Чем я могу помочь тебе, Сонэ-сан?!\""
    $ St("C",300,30,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/3300110a01.opus"

    mx "\"Мы сейчас очень спешим.\""
    voice "voice/e11/3300120a01.opus"

    mx "\"Я знаю, что вы, ребята, просто умираете от желания наверстать упущенное, но разве это не может подождать?\""
    voice "voice/e11/3300130b01.opus"

    xtl "\"А, эм... конечно.\""
    hide StC
    hide StMR
    hide StML
    hide 絵背景
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with Dissolve(500.0/1000)
    pause (500/1000)
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/e11/3300140b01.opus"

    xtl "\"Слушай... С тобой всё хорошо, Сонэ-сан? Тебя давно не было в школе—\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(100.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(100.0/1000)
    voice "voice/e11/3300150a01.opus"

    mx "\"Шиничи! Мы уходим!\""

    xy "\"Стой, но—\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/e11/3300160a01.opus"

    mx "\"Давай! Поторапливайся!\""

    "Миюки начала тащить меня за собой."

    "И я решил—"
    menu:
        "Бежать с Миюки":
            $ SetChoiceSelect = 0
        "Бежать с Ютаро":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e1134a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e1134b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
