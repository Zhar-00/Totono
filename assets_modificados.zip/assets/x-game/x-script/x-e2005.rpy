label e2005_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2005:
    $ GameName = nextpreparation ;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
