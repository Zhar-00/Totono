label e2212b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2212b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(0.0/1000)

    xy "\"Не говори глупостей. Я хороший парень. Только дурак будет прогуливать уроки.\""

    "Мне надо следить за своей репутацией."

    "Если меня собираются считать достойным кандидатом на любовь Миюки, то я должен всегда производить хорошее впечатление."

    xy "\"Я дам учителю знать, что тебя не будет на занятии. Развлекайся.\""
    if (persistent.count_sabotage > 0):
        $ GameName = "e2212d.nss";
    else:
        $ GameName = "e2212c.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
