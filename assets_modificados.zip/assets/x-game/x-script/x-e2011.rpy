label e2011_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2005.nss"
    return
label e2011:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/e20/1100010a01.opus"

    mx "\"А, точно...\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e20/1100020a01.opus"

    mx "\"Сегодня особенный день для меня и ТЕБЯ...\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e20/1100030a01.opus"

    mx "\"ТЫ понимаешь, о чём я?\""

    xy "\"А? Эм...\""

    "Я посмотрел на дату на календаре, но я всё равно был без понятия..."
    $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e20/1100040a01.opus"

    mx "\"Да, я не ожидала того, что ты будешь знать, Шиничи.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e20/1100050a01.opus"

    mx "\"Сегодня исполняется ровно одна неделя с момента ТВОЕГО первого появления здесь.\""
    voice "voice/e20/1100060a01.opus"

    mx "\"Ну, как ТЕБЕ? ТЫ уже привык ко всему здесь?\""

    xy "\"Д-да, наверное...\""

    "Когда мы только начали жить в одной квартире, мне порой было довольно неловко..."

    "Но сейчас я могу сказать точно, что уже начинаю привыкать ко всему."
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e20/1100070a01.opus"

    mx "\"Хм... Поняла.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/e20/1100080a01.opus"

    mx "\"Ну что ж, думаю, у меня есть для тебя один подарок.\""

    xy "\"Подарок?\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e20/1100090a01.opus"

    mx "\"В качестве подарка за то, что ты провёл со мной целую неделю...\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e20/1100100a01.opus"

    mx "\"...Я позволю тебе поднять мой счётчик привязанности до самого потолка.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/e20/1100110a01.opus"

    mx "\"Не хочешь? Очень жаль.\""
    voice "voice/e20/1100120a01.opus"

    mx "\"И потом, Шиничи... У тебя нет причин отказываться от поцелуя своей девушки.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/e20/1100130a01.opus"

    mx "\"Я ведь права, Шиничи?\""
    hide StC with Dissolve(200.0/1000)

    "Она страстно посмотрела на меня и притянула к себе поближе."

    "Я знаю, какие у неё мягкие губы..."

    "И я вряд ли смогу отказаться."
    voice "voice/e20/1100140a01.opus"

    mx "\"Я очень люблю тебя, знаешь ли.\""
    voice "voice/e20/1100150a01.opus"

    mx "\"М-м-мф... м-м... м-м-м... м-м-мф!\""
    $ persistent.miyuki_love += 8
    pause (16/1000)
    scene expression "cg/bg/black.jpg" zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
