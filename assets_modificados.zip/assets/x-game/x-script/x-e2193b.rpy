label e2193b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2194.nss"
    return
label e2193b:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(0.0/1000)
    xy "\"На мой взгляд, коробка важнее—\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_hard")
    with Dissolve(200.0/1000)
    $ sename = "se物体_箱_潰れる02"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白
    pause (30/1000)
    hide StC
    hide StMR
    hide StML
    hide 絵色白
    with Dissolve(70.0/1000)
    voice "voice/e21/93b00010a01.opus"
    mx "\"—!!!\""
    play voc "e21/93b00020b04"
    xy "\"Что за?!\""
    "Миюки внезапно замахнулась битой..."
    "...и сломала коробку."
    xy "\"Ч-что ты наделала?!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/93b00030a01.opus"
    mx "\"Сломала коробку. Это настолько важно?\""
    xy "\"В смысле, это настолько важно?!\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    "Я поспешно открыл коробку—"
    "\"Стоп, что?..\""
    xy "—но она была пустой."
    "\"Это странно... я был уверен, что слышал мяуканье...\""
    xy "\"Тебе, наверное, послышалось.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/93b00040a01.opus"
    mx "\"Там не было никакого кота-а-а-А-АПЧХИ!\""
    voice "voice/e21/93b00050a01.opus"
    mx "\"Миюки?..\""
    xy "\"Миюки?!..\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/93b00060a01.opus"
    mx "\"Здесь не было никакой кошки, ладно?\""
    "...Почему она так уверена в этом?"
    "И если это так, то почему у неё вдруг возник приступ аллергии?"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
