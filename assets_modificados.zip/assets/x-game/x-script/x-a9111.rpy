label a9111_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a9121.nss"
    return
label a9111:
    hide 絵色黒
    scene expression Solid("000000") as 絵演色黒
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg") with dissolve
    hide 上背景

    "...И, следовательно, последнее выступление Миюки началось и закончилось."
    pause (1000/1000)
    hide 絵演
    hide 絵演色黒
    with Dissolve(1000.0/1000)
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    pause (800/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (500/1000)
    show expression ("cg/ev/"+imagename["eva0121美雪さんおはようございます"]+".jpg") as 絵専 zorder 15 at center
    with Dissolve((500.0+1000.0)/1000)
    voice "voice/a91/1100010a01.opus"
    mx "\"Доброе утро!\""

    "В ту секунду, когда она вошла в класс, она тут же привлекла внимание всех учеников. Как и всегда."

    "За исключением того, что она со мной больше не разговаривала."

    "Да и я сам с ней не общался."
    hide 絵専
    with Dissolve(500.0/1000)

    "Просто очередное утро в школе."

    "Такое же, что и всегда."

    "В конце концов, я так и не пошёл на спектакль."

    "Но мне сказали, что он получил огромный успех."

    "Я мог представить себе, как Миюки стояла на сцене и поцеловала актёра во время романтической сцены..."

    "Уверен, это был прекрасный момент."

    "Но мне было всё равно."

    "Мы с Миюки больше не друзья."

    "Мы вернулись к тому, кем были раньше."

    "И это, наверное, к лучшему."
    show expression ("cg/bg/m/"+imagename["bg010600_1_学校教室_m"]+".jpg") as 絵演背景 zorder 15:
        xcenter .5
        ypos -150
    with Dissolve((500.0+1000.0)/1000)
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a91/1100020b01.opus"

    xtl "Боже, это было близко!"

    xy "Ты о чём?"
    voice "voice/a91/1100030b01.opus"

    xtl "Какое-то мгновение от тебя за версту разило норми..."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a91/1100040b01.opus"

    xtl "Ты был о-о-о-очень близок к смерти, приятель!"

    xy "Я очень в этом сомневаюсь."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_cry")
    with Dissolve(200.0/1000)
    voice "voice/a91/1100050b01.opus"

    xtl "В атаку, ребята из РиМ! Смерть норми!"
    voice "voice/a91/1100060b01.opus"

    xtl "Пока ни одного норми не останется на этой земле..."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_gag")
    with Dissolve(200.0/1000)
    voice "voice/a91/1100070b01.opus"

    xtl "НАША РАБОТА ЕЩЁ НЕ ЗАКОНЧЕНА!"

    xy "Найди себе новую работу."
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Я не знаю, что это за \"работа\", но, пожалуйста, не втягивайте меня в это!"
    show expression Solid("000000") as 絵演色黒
    hide StC
    hide StMR
    hide StML
    with Dissolve(500.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
