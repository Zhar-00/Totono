label b5113_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5132.nss"
    return
label b5113:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg")
    show expression ("cg/bg/m/"+imagename["bg010610_1_学校教室扉前_m"]+".jpg") as 絵背景 zorder 15 at truecenter
    stop bgm fadeout (500.0/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (1000/1000)
    with Dissolve(500.0/1000)
    pause (200/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/b51/1300010b01.opus"
    xtl "\"Ах!.. Мы только заговорили об ангеле, и она уже тут как тут!\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/b51/1300020a01.opus"
    mx "\"Доброе утро!\""
    voice "voice/b51/1300030b01.opus"
    xtl "\"Утро и в самом деле доброе!\""
    "Как обычно, Ютаро поприветствовал Миюки с особым удовольствием."
    voice "voice/b51/1300040a01.opus"
    mx "\"......\""
    "Она, должно быть, чувствовала себя очень неловко."
    "И я знал об этом наверняка."
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    pause (16/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Мы двое заняли свои места, не обменявшись взглядами."
    "Я перевёл свой взгляд, и увидел—"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
