label c7131_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c7132.nss"
    return
label c7131:
    hide 絵色黒
    scene expression Solid("000000") as 絵演色黒
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    with Dissolve(0.0/1000)
    pause (500/1000)
    $ sename = "se物体_インターホン_鳴る"
    play se sedict[sename]
    pause (1200/1000)
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]
    pause (300/1000)
    voice "voice/c71/3100010b03.opus"

    c "\"Привет...\""
    voice "voice/c71/3100020a02.opus"

    aoi "\"Хару-чан!\""
    voice "voice/c71/3100030b03.opus"

    c "\"Аой-семпай...\""
    voice "voice/c71/3100040b03.opus"

    c "\"Мне только что звонил Сузуки-семпай...\""
    voice "voice/c71/3100050a02.opus"

    aoi "\"У Аой есть к тебе одна просьба.\""
    voice "voice/c71/3100060a02.opus"

    aoi "\"Займись со мной сексом.\""
    voice "voice/c71/3100070b03.opus"

    c "\"......Что?\""
    voice "voice/c71/3100080a02.opus"

    aoi "\"Займись со мной сексом, Хару-чан.\""
    voice "voice/c71/3100090b03.opus"

    c "\"Ч... что? Что произошло? А как же Сузуки-семпай?\""
    voice "voice/c71/3100100a02.opus"

    aoi "\"Аой нужно заняться с тобой сексом.\""
    voice "voice/c71/3100110b03.opus"

    c "\"Аой-семпай...\""

    "У Аой был такой уверенный голос, что он даже не мог спорить."
    voice "voice/c71/3100120b03.opus"

    c "\"...Ладно.\""
    voice "voice/c71/3100130b03.opus"

    c "\"Я не знаю, что происходит...\""
    voice "voice/c71/3100140b03.opus"

    c "\"Так что мой единственный выбор - сделать то, о чём ты просишь...\""
    voice "voice/c71/3100150b03.opus"

    c "\"Но для начала... я хочу сказать тебе о своих чувствах.\""
    voice "voice/c71/3100160b03.opus"

    c "\"Я люблю тебя, Аой-семпай.\""
    voice "voice/c71/3100170b03.opus"

    c "\"Ты мне правда нравишься. Я схожу от тебя с ума.\""
    voice "voice/c71/3100180b03.opus"

    c "\"И я знаю, что ты любишь Сузуки-семпая.\""
    voice "voice/c71/3100190b03.opus"

    c "\"Каждый раз, когда ты была со мной, я знал, что ты думаешь о нём.\""
    voice "voice/c71/3100200b03.opus"

    c "\"Но... это уже не важно.\""
    voice "voice/c71/3100210b03.opus"

    c "\"Я сделаю для тебя всё, Аой-семпай. Всё, что угодно, чтобы удовлетворить тебя.\""
    voice "voice/c71/3100220b03.opus"

    c "\"...Так что, пожалуйста...\""
    voice "voice/c71/3100230b03.opus"

    c "\"Пожалуйста, забери мою девственность! И на этот раз - по-настоящему!\""
    voice "voice/c71/3100240a02.opus"
    aoi "\"Хару-чан?..\""
    $ sename = "se人体_足音_階段自宅上がる一歩不安01"
    play se sedict[sename]
    pause (1000/1000)

    "Пол начал скрипеть."

    "Аой медленно и невесомо шла вперёд, как будто она медленно исчезала."
    voice "voice/c71/3100250a02.opus"

    aoi "\"Не плачь.\""
    voice "voice/c71/3100260a02.opus"

    aoi "\"Аой сделает так, чтобы тебе было лучше.\""
    voice "voice/c71/3100270b03.opus"

    c "\"Пожалуйста...\""
    $ sename = "se物体_ドア室内_閉まる01"
    play se sedict[sename]
    pause (2000/1000)

    "Дверь захлопнулась."
    show expression ("cg/bg/"+imagename["bg030301_3_自宅リビング消灯"]+".jpg")
    $ sename = "se物体_時計_秒針L"
    play se sedict[sename]
    pause (500/1000)
    pause (500/1000)
    hide 絵演色黒
    with Dissolve(2000.0/1000)
    pause (1000/1000)

    "И вдруг повисла тишина."

    "Лёжа в тёмной гостиной, я открыл глаза."

    "Я не мог уснуть—"
    play voc "c71/3100280b04"
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]

    xy "\"...Иру?\""

    xy "\"Как ты здесь оказался?\""
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]

    "Я, кажется, припоминаю, как закрыл его наверху, в своей спальне, чтобы у Миюки не началась аллергия во время вечеринки в честь моего дня рождения..."

    "Он сбежал, когда Аой открыла дверь?"

    "У меня почти что было такое чувство, будто он телепортировался сюда..."
    play voc "c71/3100290b04"

    "Он мило мяукнул мне."

    "Я взял его и закрыл глаза, греясь об него своими руками."
    stop se fadeout (4000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((4000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
