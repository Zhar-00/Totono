label e2162b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2163.nss"
    return
label e2162b:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg070100_2_雑貨店店内"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(0.0/1000)

    xy "\"Как насчёт этой фоторамки?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/62b00010a01.opus"

    mx "\"Хм... Конечно, почему нет? Я люблю фотографии.\""
    if persistent.miyuki[10] == 0:
        voice "voice/e21/62b00020a01.opus"

        mx "\"Всё-таки фотографии вечны.\""
    elif persistent.miyuki[10] == 1:
        voice "voice/e21/62b00030a01.opus"

        mx "\"Это простой способ увидеть то, как сильно ты изменился.\""
    elif persistent.miyuki[10] == 2:
        voice "voice/e21/62b00040a01.opus"

        mx "\"Они также помогают тебе вспомнить славные времена.\""

    "Хм... я никогда не задумывался об этом."
    voice "voice/e21/62b00050a01.opus"

    mx "\"Неплохое предложение. По крайней мере, для тебя.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/62b00060a01.opus"

    mx "\"Но...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e21/62b00070a01.opus"

    mx "\"Если я распечатаю свою фотографию, то она исчезнет. Единственная вещь, которую можно переносить - это мои данные.\""

    xy "\"Хм? Ты что-то сказала?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/62b00080a01.opus"

    mx "\"Не-а! Совсем ничего!\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
