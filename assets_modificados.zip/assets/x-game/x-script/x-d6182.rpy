label d6182_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d7111.nss"
    return
label d6182:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110300_3_マンション寝室"]+".jpg")
    with Dissolve(1000.0/1000)
    stop bgm fadeout (500.0/1000)
    pause (1000/1000)
    voice "voice/d61/8200010b03.opus"

    c "\"А?..\""

    "И тут я увидел Рюджиро, одетого в женскую форму, его член выглядывал из-под его юбки..."
    voice "voice/d61/8200020a02.opus"

    aoi "\"Буп...\""

    "И там ещё была Аой, она сосала у него."
    voice "voice/d61/8200030a02.opus"

    aoi "\"Не может быть...\""
    voice "voice/d61/8200040b03.opus"

    c "\"А-а-ах...\""
    voice "voice/d61/8200050b03.opus"

    c "\"А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-АХ!!!\""
    stop se fadeout (100.0/1000)
    stop bgm fadeout (100.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((100.0+1000.0)/1000)
    pause (3000/1000)

    "А потом всё вдруг потемнело."
    $ EyeCatchIn(0.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
