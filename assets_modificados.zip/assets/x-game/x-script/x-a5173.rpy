label a5173_MAIN:
    call expression GameName
    $ persistent.imagelog["eva5173美雪さん告白"]=True
    queue bgm "ttb24"
    $ PreGameName = GameName
    $ GameName = "a6111.nss"
    return
label a5173:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    xy "Стой, Миюки! Я сам его достану!"
    voice "voice/a51/7300010a01.opus"
    mx "В чём дело? Ты сейчас какой-то бледный."
    voice "voice/a51/7300020a01.opus"
    mx "А, я поняла. Ха-ха! Ты там прячешь что-то НЕПРИСТОЙНОЕ?"
    "Улыбка Миюки не доходила до её глаз."
    "Я молча кричал ей, чтобы она остановилась, но мои молитвы не были услышаны."
    "Она залезла под кровать... и вдруг замерла."
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    voice "voice/a51/7300030a01.opus"
    mx "Попалась."
    $ sename = "se人体_動作_起き上がる01"
    play se sedict[sename]
    hide 絵背景
    with Dissolve(500.0/1000)
    voice "voice/a51/7300040a02.opus"
    aoi "Буп-буп..."
    "Миюки вытащила Аой из-под кровати."
    show expression ("cg/ev/l/"+imagename["eva5163アオイ汗拭き_l"]+".jpg") as 絵専:
        pos (-549,-300)
    with Dissolve((800.0+1000.0)/1000)
    pause (1000/1000)
    "О боже... Она всё ещё была полуголой!.."
    voice "voice/a51/7300050a01.opus"
    mx "......Ох."
    xy "Слушай, я всё объясню—"
    voice "voice/a51/7300060a01.opus"
    mx "......!!!"
    xy "Стой!"
    show expression ("cg/bg/m/"+imagename["bg030100_3_自宅自室_m"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵専
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    with Dissolve(300.0/1000)
    "Миюки отвела свою руку в сторону, и я схватил её."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a51/7300070a01.opus"
    mx "Чего тебе надо?! Пусти меня!"
    xy "Пожалуйста, давай просто успокоимся—"
    voice "voice/a51/7300080a01.opus"
    mx "Как я могу сейчас успокоиться?!"
    "Выбравшись из моей хватки, она схватила Аой."
    voice "voice/a51/7300090a01.opus"
    mx "Я думала, ты пытаешься помочь мне! Я думала, ты хотела, чтобы я и он были вместе!"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/7300100a01.opus"
    mx "Так почему?.. Почему?! Почему ты сама к нему подкатываешь?!"
    xy "Говорю же тебе, ты всё не так поняла!"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a51/7300110a01.opus"
    mx "ЗАТКНИСЬ!"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/a51/7300120a01.opus"
    mx "Ты переживаешь за Аой больше, чем за меня, да?"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/7300130a01.opus"
    mx "Я всё поняла, ладно? Я знаю, что сделала тебе больно! Я никогда не должна была обращаться с тобой как с лабораторной мышью!"
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a51/7300140a01.opus"
    mx "Но вот это? Это уже слишком!"
    voice "voice/a51/7300150a01.opus"
    mx "Как ты мог?!.."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    voice "voice/a51/7300160a02.opus"
    aoi "Поняла."
    "Надев свою всё ещё мокрую рубашку, Аой подняла руку, чтобы заговорить впервые с тех пор, как началась ссора."
    show expression ("cg/bg/m/"+imagename["bg030100_3_自宅自室_m"]+".jpg") as 絵背景 zorder 100 at truecenter
    $ St("C",300,0,0,"bu向日アオイ電波_制服_挙手_normal")
    with Dissolve(1000.0/1000)
    pause (500/1000)
    "У неё было пустое выражение лица, от чего по моей спине прошлись мурашки."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a51/7300170a02.opus"
    aoi "Это Аой пыталась соблазнить Шиничи."
    voice "voice/a51/7300180a02.opus"
    aoi "Аой – передатчик. Пустое место."
    voice "voice/a51/7300190a02.opus"
    aoi "Такая же распутная до мозга костей, как и гласят слухи."
    voice "voice/a51/7300200a02.opus"
    aoi "И Аой пыталась заняться сексом с Шиничи."
    voice "voice/a51/7300210a01.opus"
    mx "......!!!"
    xy "Миюки!"
    hide StC with Dissolve(0.0/1000)
    hide 絵背景
    hide 絵板写
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    "Миюки снова пыталась поднять свою руку на Аой, но я едва сдерживал её."
    $ sename = "se人体_動作_暴れる"
    play se sedict[sename]
    voice "voice/a51/7300220a01.opus"
    mx "ОТПУСТИ меня!"
    xy "Просто остановись!"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    xy "И ты, Аой! С чего ты это всё взяла?!"
    voice "voice/a51/7300230a02.opus"
    aoi "Аой получила свой телефон обратно."
    voice "voice/a51/7300240a02.opus"
    aoi "Пришло время загрузить своё сохранение."
    voice "voice/a51/7300250a02.opus"
    aoi "После этого Аой исчезнет."
    voice "voice/a51/7300260a02.opus"
    aoi "И ты больше никогда меня не увидишь."
    xy "Аой? Что ты—"
    voice "voice/a51/7300270a02.opus"
    aoi "Пока-пока."
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    pause (500/1000)
    pause (2000/1000)
    "Аой вышла из комнаты и скрылась с поля моего зрения."
    "Я побежал за ней."
    show expression ("cg/bg/"+imagename["bg030500_3_自宅廊下２階消灯"]+".jpg")
    $ sename = "se人体_足音_階段自宅上がる01"
    play se sedict[sename]
    with Dissolve(200.0/1000)
    pause (500/1000)
    xy "Аой, стой!"
    voice "voice/a51/7300280a01.opus"
    mx "Ты никуда не пойдёшь!"
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    xy "Отпусти меня! Ей нездоровится!"
    voice "voice/a51/7300290a01.opus"
    mx "Мне всё равно!"
    xy "Очень жаль! А теперь отпусти меня, чёрт побери!"
    voice "voice/a51/7300300a01.opus"
    mx "Я тебя не отпущу!"
    show expression ("cg/ev/l/"+imagename["eva5173美雪さん告白_l"]+".jpg") as 絵専 zorder 1100 at truecenter:
        zoom .5
    $ sename = "se人体_動作_抱きつく01"
    play se sedict[sename]
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    "Она развернула меня, чтобы посмотреть мне в лицо."
    voice "voice/a51/7300310a01.opus"
    mx "То самое дело с лабораторной мышью... Это была лишь отговорка..."
    "Я не мог сбежать."
    voice "voice/a51/7300320a01.opus"
    mx "Но я уже готова сказать тебе это."
    "Я не мог противостоять этому."
    voice "voice/a51/7300330a01.opus"
    mx "Я готова рассказать тебе правду."
    "Мне страшно—"
    voice "voice/a51/7300340a01.opus"
    mx "Правду о своих чувствах."
    "Не надо—"
    voice "voice/a51/7300350a01.opus"
    mx "Шиничи, послушай меня."
    "Стой—"
    stop bgm fadeout .5
    voice "voice/a51/7300360a01.opus"
    mx "Я..."
    "Не договаривай эту фразу—"
    pause (1500/1000)
    $ renpy.music.play("ttb13",channel = "bgm", if_changed = True)
    voice "voice/a51/7300370a01.opus"
    mx "...влюблена в тебя."
    xy "......"
    "Я выдохнул."
    "Мои колени ослабли."
    "Мой разум опустел."
    "Я не хотел слышать это."
    "Я не хотел, чтобы она сказала это."
    "Мы оба знали, что это запрещено."
    "Негласное соглашение."
    "То, что она только что сказала..."
    "...просто уничтожит всё."
    voice "voice/a51/7300380a01.opus"
    mx "Я просто хотела, чтобы ты поцеловал меня."
    voice "voice/a51/7300390a01.opus"
    mx "Это всё, чего я правда хотела."
    voice "voice/a51/7300400a01.opus"
    mx "Я умирала от желания сказать тебе..."
    voice "voice/a51/7300410a01.opus"
    mx "Но я не могла."
    voice "voice/a51/7300420a01.opus"
    mx "Я влюблена в тебя."
    voice "voice/a51/7300430a01.opus"
    mx "Безоговорочно до беспамятства влюблена в тебя."
    voice "voice/a51/7300440a01.opus"
    mx "Шиничи... Пожалуйста..."
    show expression ("cg/ev/l/"+imagename["eva5173美雪さん告白_l"]+".jpg") as 絵専 zorder 1100 at truecenter:
        zoom .5
        linear 50 zoom 1
    "Губы Миюки медленно начали приближаться."
    "Её губы..."
    "Я хотел поцеловать их так же сильно, как и в своих снах."
    "Нас разделяли считанные миллиметры..."
    "Я мог почувствовать её учащённое, неровное дыхание."
    "И я мог учуять слабый запах её духов."
    "И поэтому я—"
    "Я—"
    pause (500/1000)
    $ st_timezone = "昼"
    stop bgm fadeout (500.0/1000)
    $ sename = "se物体_携帯_着信音03"
    play se sedict[sename]
    pause (2000/1000)
    hide 絵専
    with Dissolve(1000.0/1000)
    hide 絵動作
    pause (1000/1000)
    xy "...У меня телефон звонит."
    $ st_timezone = "夜"
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/a51/7300450a01.opus"
    mx "Шиничи!"
    xy "Это Ютаро."
    xy "Он, скорее всего, звонит по поводу Аой."
    "Я ничтожество, раз использую Аой в качестве своего оправдания. Я знаю об этом."
    "Но это мой единственный выбор."
    voice "voice/a51/7300460a01.opus"
    mx "Ты выбираешь телефонный звонок... вместо МЕНЯ?.."
    "Я мог расслышать умоляющий тон в её голосе."
    "На её глазах начали наворачиваться слёзы..."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    hide StC with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)
    pause (500/1000)
    "Но я отвернулся от неё."
    xy "Алло?"
    voice "voice/a51/7300470b01.opus"
    xtl "Шиничи, ты подонок! О чём, чёрт побери, ты думал, вышвыривая Муко вон в таком состоянии?!"
    voice "voice/a51/7300480b01.opus"
    xtl "Она всю дорогу ковыляла сюда с котёнком на руках!"
    xy "...Прости."
    voice "voice/a51/7300490b01.opus"
    xtl "Это ты ей говори, не мне. Ладно, я пока присмотрю за ней, хорошо?"
    xy "Точно присмотришь?"
    voice "voice/a51/7300500b01.opus"
    xtl "Ну, у тебя и без того полно забот, да?"
    xy "...Я правда перед тобой в долгу."
    voice "voice/a51/7300510b01.opus"
    xtl "Да без проблем. Увидимся."
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]

    show expression ("cg/bg/"+imagename["bg030500_3_自宅廊下２階消灯"]+".jpg")
    with Dissolve(1000.0/1000)
    pause (300/1000)
    "Я завершил вызов и окинул комнату взглядом."

    "Но Миюки уже ушла."
    $ EyeCatchIn(2000.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
