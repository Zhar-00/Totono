label e2225g_MAIN:
    call expression GameName
    $ MaidImpression = True;
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2225g:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    show expression Solid("000000") as 絵色黒
    pause (2000/1000)
    with Dissolve(0.0/1000)
    voice "voice/e22/25g00010a01.opus"

    mx "ТЫ опять всю меня испачкал...Тебе одного раза мало было?"
    voice "voice/e22/25g00020a01.opus"

    mx "...Ну, всё нормально."
    voice "voice/e22/25g00030a01.opus"

    mx "Если ТЕБЕ это так нравится...то ТЫ можешь кончать на меня сколько угодно раз..."
    voice "voice/e22/25g00040a01.opus"

    mx "Просто испачкай меня полностью... ладно?"
    pause (1000/1000)
    show expression Solid("000000") as 絵色黒
    pause (16/1000)
    hide 上背景
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
