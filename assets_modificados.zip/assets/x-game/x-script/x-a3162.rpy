label a3162_MAIN:
    call expression GameName
    $ persistent.imagelog["bg030200_3_自宅玄関"]=True
    $ PreGameName = GameName
    $ GameName = "a3171.nss"
    return
label a3162:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040200_3_街川縁雨"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/a31/6200010a01.opus"
    mx "Шиничи! Даже не смей игнорировать меня!"
    voice "voice/a31/6200020a01.opus"
    mx "И ты ещё называешь себя другом Аой?! Тебе не кажется, что ты должен быть рядом с ней?"

    xy "А... Точно..."
    hide 絵板写朧
    with Dissolve(800.0/1000)
    pause (500/1000)
    "Миюки вернула меня обратно в реальность."
    "Аой, «передатчик»-самоучка."
    "Аой, девушка, у которой в списке контактов всего одна запись."
    "Мы двое были её единственными друзьями..."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    pause (500/1000)
    show expression Solid("000000") as 絵色回想黒 zorder 3900
    with Dissolve((0.0+300.0)/1000)
    show expression ("cg/ev/"+imagename["eva2151美雪アオイ心一写真b"]+".jpg") as 絵覆 zorder 2100 at truecenter
    with Dissolve((500.0+0.0)/1000)
    "И прямо сейчас, мы единственные, кто может помочь ей."
    with Dissolve((500.0+1000.0)/1000)
    hide 絵色回想黒
    hide 絵覆
    hide 絵色黒
    with Dissolve(500.0/1000)
    xy "Миюки?"
    voice "voice/a31/6200030a01.opus"
    mx "Да?"
    xy "Спасибо, что помогаешь мне найти её."
    voice "voice/a31/6200031a01.opus"
    mx "Р-разумеется, я бы помогла тебе!"
    "Я каким-то образом мог представить себе её выражение лица."
    "Я знаю её, и я знаю, что ей нравится дружить с Аой."
    "Она бы ни за что не положила дружбе конец. Она грозилась «разорвать связи» лишь потому, что ей было не всё равно."
    "Иначе она бы не ходила здесь под покровом ночи – да ещё и под проливным дождём – пытаясь найти её."
    voice "voice/a31/6200032a01.opus"
    mx "Ну да ладно. Мы должны найти её."
    "Я начал копаться в своих воспоминаниях."
    "Все те дни, которые мы провели вместе с Аой..."
    "Я знаю, что наша дружба была настоящей."
    "Где-то здесь должна быть зацепка..."
    "Она должна быть здесь!.."
    $ renpy.music.set_volume(.2,channel = "rain")
    with Dissolve((300.0+1000.0)/1000)
    with Dissolve((0.0+800.0)/1000)
    show expression ("cg/ev/"+imagename["eva3151アオイ猫箱"]+".jpg") as 絵背景 zorder 100 at truecenter
    show expression ("cg/ev/"+imagename["eva0113アオイ屋上覆い被さりa"]+".jpg") as 絵背景弐 zorder 101 at truecenter
    with Dissolve((300.0+0.0)/1000)
    pause (500/1000)
    with Dissolve((300.0+1000.0)/1000)
    pause (200/1000)
    hide 絵背景弐
    with Dissolve((300.0+0.0)/1000)
    pause (500/1000)
    with Dissolve((300.0+1000.0)/1000)
    hide 絵背景
    hide 絵効果
    $ renpy.music.set_volume(.5,channel = "rain",delay=.3)
    hide 絵色白
    with Dissolve(300.0/1000)
    xy "Визуальная новелла!"
    voice "voice/a31/6200033a01.opus"
    mx "Стоп, что? Что ты только что—"
    xy "Я должен заскочить к себе домой по-быстрому. Кажется, у меня есть идея."
    voice "voice/a31/6200040a01.opus"
    mx "Да? Она хотя бы хорошая?"
    xy "Не знаю, но это явно лучше, чем пытаться искать её, выбирая места наугад."
    voice "voice/a31/6200050a01.opus"
    mx "Ну ладно. Увидимся там."
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    pause (500/1000)
    "Я завершил вызов и побежал домой."
    show expression ("cg/bg/"+imagename["bg010401_3_学校校門閉通用口開雨"]+".jpg")
    with Dissolve(800.0/1000)
    pause (300/1000)
    "В той мобильной игре, которую Ютаро одолжил мне... в ней была почти такая же сцена с бездомным котом."
    show expression ("cg/bg/"+imagename["bg040100_3_街通学路雨"]+".jpg")
    with Dissolve(600.0/1000)
    pause (300/1000)
    "Если она отыгрывает сцены из неё, то, наверное, я должен пройти игру, чтобы узнать, куда она пойдёт дальше."
    stop se fadeout (700.0/1000)
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面雨"]+".jpg")
    with Dissolve(400.0/1000)
    pause (300/1000)
    "Как только мой дом оказался в поле моего зрения, я заметил, как уже оказался на тротуаре и забежал через входную дверь."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ renpy.music.set_volume(.1,channel = "rain",delay =1)
    stop se fadeout (1000.0/1000)
    pause (1000/1000)
    $ sename = "se物体_ドア室内_閉まる01"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(500.0/1000)
    "А потом я побежал наверх по лестнице к своей комнате и схватил взятый на время телефон, который я оставил заряжаться на своей кровати."
    show expression ("cg/ef/"+imagename["efbg雄太郎のスマフォ"]+".jpg") as 絵演効果 zorder 2100 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/a31/6200060a02.opus"
    aoi "Мяу! Я – мамочка-кошка."

    "Я должен дойти до той сцены как можно скорее... от нетерпения я даже нажал на кнопку пропуска."
    "Текст начал пролистываться вперёд."
    "...Стоп..."
    "Сейчас я пролистывал «прошлое», чтобы сюжет игры совпадал с «настоящим временем» в реальном мире, но... что будет, если я пролистаю дальше?"
    "В смысле... это ведь один из тех симуляторов свиданий, верно?"
    "А это значит, что в конце протагонист, скорее всего, будет встречаться с главной героиней..."
    "То есть... получается, Аой попытается отыграть в реальности и эту часть тоже?.."
    $ sename = "se物体_インターホン_鳴る"
    play se sedict[sename]
    hide 絵演効果
    with Dissolve(150.0/1000)
    $ sename = "se人体_動作_飛び起きる"
    play se sedict[sename]
    xy "Воу!"
    "Внезапный звуковой эффект застал меня врасплох."
    "Моя рука соскользнула, и я случайно деактивировал кнопку пропуска."
    xy "Стоп... Это же—?"
    $ sename = "se物体_インターホン_鳴る連打"
    play se sedict[sename]
    xy "Иду!"
    show expression ("cg/bg/"+imagename["bg030200_3_自宅玄関"]+".jpg")
    $ st_timezone = "昼"
    $ sename = "se人体_足音_階段自宅上がる01"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    pause (300/1000)
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]
    pause (300/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a31/6200070a01.opus"
    mx "Шиничи! Ты знаешь, куда она ушла?!"
    "Спросила Миюки, пытаясь перевести дыхание... и я кивнул ей."

    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
