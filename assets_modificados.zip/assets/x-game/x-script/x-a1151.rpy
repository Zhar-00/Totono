label a1151_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010610_1_学校教室扉前"]=True
    $ PreGameName = GameName
    $ GameName = "a1161.nss"
    return
label a1151:
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve(1)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    pause (500/1000)
    $ tz(1)
    "Тот же старый класс..."
    "Та же старая болтовня..."
    "И там сидела Аой..."
    show expression ("cg/ev/"+imagename["eva1111アオイ受信中a"]+".jpg") as 絵専 zorder 1100 at center
    with Dissolve((800.0+1000.0)/1000)
    pause (500/1000)
    voice "voice/a11/5100010a02.opus"
    aoi "Буп-буп..."
    "...И она безучастно смотрела на свою парту, как и всегда."
    "Она выглядела очень скучающей."
    "Её телефон ВСЁ РАВНО не ловит?"
    "И тут я задумался над тем, что её телефон, возможно, сломался."
    voice "voice/a11/5100020b01.opus"
    xtl "Шиничи! Шиничи! Иди сюда!"
    xy "Чего тебе надо? Я как бы сейчас—"
    voice "voice/a11/5100030b01.opus"
    xtl "Умоляю тебя! Это важно!"
    xy "......"
    xy "Ладно, ладно."
    show expression ("cg/bg/m/"+imagename["bg010600_1_学校教室_m"]+".jpg") as 絵演背景 zorder 15 at center
    hide 絵専
    with Dissolve(500.0/1000)
    "Я неохотно прошёл к своей парте."
    xy "...В чём дело?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100040b01.opus"
    xtl "Мне нужен совет!"
    xy "Пф-ф! Да пожалуйста! Чего ты так разволновался?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100050b01.opus"
    xtl "Ш-ш-ш! Сбавь свой тон, болтун!"
    xy "Это настолько серьёзно?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100060b01.opus"
    xtl "Чувак, это очень важно. Наше будущее под угрозой."
    voice "voice/a11/5100070b01.opus"
    xtl "Ладно... Вот... Дело в этом."
    $ sename = "se人体_動作_ポケット探る"
    play se sedict[sename]
    pause (500/1000)
    "Ютаро открыл свою сумку и достал оттуда... пару..."
    xy "...Трусы?"
    stop se fadeout (500.0/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100080b01.opus"
    xtl "Да, именно; сама сущность мужских мечтаний!"
    xy "......"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_shy")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100090b01.opus"
    xtl "Артефакт мужских амбиций!"
    "Да, я тебя понял, спасибо."
    xy "Ты украл их?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100100b01.opus"
    xtl "Да как ты смеешь!"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100110b01.opus"
    xtl "Я их НАШЁЛ."
    xy "Ты... нашёл их..."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100120b01.opus"
    xtl "Именно."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100130b01.opus"
    xtl "Прямо у нашей парадной двери."
    xy "...Что?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100140b01.opus"
    xtl "Я нашёл мечту, лежащую прямо у нашей парадной двери..."
    xy "Ты же сказал, что вас в семье всего четверо, верно?"
    xy "Я забыл... У тебя есть старшая сестра?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100150b01.opus"
    xtl "Не-а."
    xy "Ну, а младшая сестра?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100160b01.opus"
    xtl "Нада де эсо, компадре!"
    xy "Ладно, тогда КТО у тебя есть?"
    voice "voice/a11/5100170b01.opus"
    xtl "Папа, мама, младший брат и я."
    xy "......"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100180b01.opus"
    xtl "......"
    voice "voice/a11/5100190b01.opus"
    xtl "Скажи мне, Шиничи, мой брат по мечтаниям..."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100200b01.opus"
    xtl "Что мне делать с этим артефактом?!"
    xy "Что хочешь, наверное?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_shy")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100210b01.opus"
    xtl "Могу ли я подрочить ими? Должен ли я? Стоит ли мне пойти на такое?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100220b01.opus"
    xtl "Но... есть вероятность, что это трусы моей мамы..."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_gag")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100230b01.opus"
    xtl "МОИ МЕЧТЫ РАЗРУШЕНЫ!!!"
    xy "Хреново быть тобой."
    stop bgm fadeout (1000/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    hide StC
    pause (500/1000)
    show expression Solid("FFFFFF") as 絵色白 zorder 2000
    with Dissolve((300.0+1000.0)/1000)
    show expression ("cg/ev/"+imagename["eva0121美雪さんおはようございます"]+".jpg") as 絵専 behind 絵色白 zorder 1100 at center
    hide 絵色白
    with Dissolve(500.0/1000)
    pause (100/1000)
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    voice "voice/a11/5100240a01.opus"
    mx "Доброе утро!"
    voice "voice/a11/5100250b01.opus"
    xtl "Д-доброе утро!!!"
    "После прихода Миюки, класс вдруг оживился."
    "Она правда была звездой шоу..."
    voice "voice/a11/5100260b01.opus"
    xtl "Ха-а... Сонэ-сан сегодня утром выглядит так же прекрасно, что и всегда..."
    "Ютаро очарованно смотрел на неё."
    "Опять то же самое. В классе была та же картина, что и каждое утро."
    hide 絵専
    with Dissolve(800.0/1000)
    "По крайней мере, я так думал..."
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_挙手_shout")
    voice "voice/a11/5100270a02.opus"
    aoi "Поняла!"
    voice "voice/a11/5100280a01.opus"
    mx "Муко-сан?.."
    "На этот раз Аой вскочила на ноги с поднятой рукой, её взгляд был прикован к Миюки."
    voice "voice/a11/5100290b01.opus"
    xtl "Это странно. Что с ней происходит сегодня?"
    xy "О боже."
    "У меня очень, ОЧЕНЬ плохое предчувствие на этот счёт."
    "То фото, возможно, всё ещё осталось на телефоне Аой—"
    voice "voice/a11/5100300a01.opus"
    mx "Я нужна тебе для чего-то?"
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a11/5100310a02.opus"
    aoi "Аой очень жаль за содеянное."
    $ sename = "se人体_動作_起き上がる01"
    play se sedict[sename]
    pause (500/1000)
    "Она опустила голову."
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a11/5100320a02.opus"
    aoi "Я виновата во вчерашнем."
    voice "voice/a11/5100330a01.opus"
    mx "А... точно. Это."
    "Наши одноклассники наблюдали за их разговором с лёгким недоумением."
    "И, почувствовав их озадаченность, Миюки улыбнулась."
    show expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg") as 絵演美雪背景 zorder 1010 at center
    $ St("MR",1300,30,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(300.0/1000)
    $ St("MR",1300,30,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a11/5100340a01.opus"
    mx "Не волнуйся об этом. Ты не сделала ничего такого."
    voice "voice/a11/5100350a02.opus"
    aoi "Ты простишь меня?"
    $ St("MR",1300,30,0,"st曽根美雪_制服_通常_normal")
    voice "voice/a11/5100360a01.opus"
    mx "Тебе не стоит просить прощения за то, чего ты не делала, глупышка."
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(300.0/1000)
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a11/5100370a02.opus"
    aoi "Тогда... у Аой есть одна небольшая просьба."
    voice "voice/a11/5100380a01.opus"
    mx "Просьба?"
    voice "voice/a11/5100390a02.opus"
    aoi "Аой хочет дружить с Миюки."
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a11/5100400a02.opus"
    aoi "Можно?"
    with Dissolve((0.0+1000.0)/1000)
    $ St("MR",1300,30,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(300.0/1000)
    $ St("MR",1300,30,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a11/5100410a01.opus"
    mx "Не глупи."
    "Миюки лучезарно улыбнулась."
    voice "voice/a11/5100420a01.opus"
    mx "Мы учимся в одном классе, верно? Так мы уже самые лучшие друзья на свете!"
    voice "voice/a11/5100430a02.opus"
    aoi "Друзья..."
    $ St("MR",1300,30,0,"st曽根美雪_制服_通常_normal")
    voice "voice/a11/5100440a01.opus"
    mx "Это всё, что тебе было нужно?"
    voice "voice/a11/5100450a02.opus"
    aoi "Эм... Мы можем обменяться эле—"
    $ St("MR",1300,30,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a11/5100460a01.opus"
    mx "Прости, у меня сейчас нет времени на это."
    voice "voice/a11/5100470a01.opus"
    mx "Давай потом."
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    hide StMR
    hide StML
    pause (100/1000)
    hide 絵演美雪背景
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(300.0/1000)
    $ St("ML",300,-30,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a11/5100480a02.opus"
    aoi "Буп-буп..."
    "Миюки быстро закончила разговор с ней, её улыбка была непоколебимой."
    "Моментом позже, класс вернулся в норму."
    $ sename = "se環境_ガヤ_教室ざわめくL"
    play se sedict[sename]
    hide StML
    hide StMR
    show expression ("cg/bg/m/"+imagename["bg010600_1_学校教室_m"]+".jpg") as 絵背景 zorder 15 at center
    with Dissolve(800.0/1000)
    pause (100/1000)
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a11/5100490b01.opus"
    xtl "Боже, такого я вообще не ожидал!"
    xy "Я тоже."
    show expression ("cg/ev/"+imagename["eva1111アオイ受信中a"]+".jpg") as 絵専 zorder 1100 at center
    with Dissolve((800.0+1000.0)/1000)
    "Аой вернулась к своей парте и села за неё обратно."
    "Её выражение лица было таким же пустым, что и всегда... но её взгляд был уже прикован к телефону в руках."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1500.0+1000.0)/1000)
    pause (500/1000)
    "Дело в том, что я достаточно долгое время знал Миюки."
    "Та её лучезарная улыбка?"
    "Она была абсолютно фальшивой."
    stop se fadeout (1000.0/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
