label e1135_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1135:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010210_2_学校屋上屋根向"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e11/3500010a01.opus"

    mx "\"Я не с тобой разговариваю.\""
    show expression ("cg/ev/"+imagename["eve1158a美雪ラスボス"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    pause (1000/1000)
    voice "voice/e11/3500020a01.opus"

    mx "\"Я спрашиваю ТЕБЯ.\""

    xy "\"Кого?..\""
    voice "voice/e11/3500030a01.opus"

    mx "\"Помолчи.\""

    "Я замолчал, как мне и было велено."
    voice "voice/e11/3500040a01.opus"

    mx "\"ТЫ помнишь?\""
    voice "voice/e11/3500050a01.opus"

    mx "\"Ту ночь, когда Аой спасла котёнка под дождём?\""
    if (persistent.diary_read):
        $ GameName = "e1135a.nss";
    else:
        $ GameName = "e1135b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
