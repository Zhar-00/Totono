label e2312b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2312b:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110600_2_マンション台所"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_smile")
    with Dissolve(0.0/1000)

    "Не то, чтобы я винил её за беспокойство, конечно же."

    "Но если я не вытащу её отсюда, то, в конце концов, это вряд ли будет отличаться от того, что она сделает это сама."

    "Это ради её же блага."

    xy "\"Я знаю, что ты волнуешься, но просто доверь мне это дело, ладно? Позволь мне с этим разобраться. Ты сможешь сделать это?\""
    if (persistent.world_recreate):
        $ GameName = "e2313a.nss";
    else:
        $ GameName = "e2313b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
