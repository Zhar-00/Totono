label e2209c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2209d.nss"
    return
label e2209c:
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110110_1_マンションリビングソファー"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,30,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(0.0/1000)

    xy "\"Не-а. Я сомневаюсь, что она его предаст.\""

    xy "\"Любая уважающая себя героиня не станет делать это.\""
    voice "voice/e22/09c00010a01.opus"

    mx "\"Звучит довольно наивно, на мой взгляд.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
