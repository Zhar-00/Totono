label a5112_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if no_call == True:
        $ GameName = "b5113.nss"
    else:
        $ GameName = "a5113.nss"
    return
label a5112:
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    pause (500/1000)
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve(2000.0/1000)
    xy "Доброе утро."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_happy")
    with Dissolve(200.0/1000)
    stop se fadeout (1000.0/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    voice "voice/a51/1200010b01.opus"
    xtl "ШИНИЧИ! ДОБРОЕ УТРО!!!"
    xy "Не кричи!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200020b01.opus"
    xtl "Ха-ха! В чём дело? Тебе интересно, из-за чего я так завёлся?"
    xy "Ни в малейшей степени."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200030b01.opus"
    xtl "Ну, видишь ли—"
    xy "Не игнорируй меня!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_shy")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200040b01.opus"
    xtl "Оказывается! Мой брат Рюджиро! Влюбился кое в кого!!!"
    xy "Серьёзно?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_happy")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200050b01.opus"
    xtl "Серьёзней некуда! Я только что получил электронку от него самого!"
    xy "Ну, это хорошо. Теперь у него будут более здоровые романтические отношения."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200060b01.opus"
    xtl "Да..."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200070b01.opus"
    xtl "Ты прав..."
    xy "Что? Ты разве не счастлив за него?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200080b01.opus"
    xtl "Просто... теперь, когда он ушёл... я удивлён, как мне больно от этого..."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_lost")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200090b01.opus"
    xtl "Мой печальный, фантомный роман..."
    xy "Он был твоим братом!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_cry")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200100b01.opus"
    xtl "Но ты сам подумай, Шиничи! Он был милым, и он даже признался мне! Разве такое каждый день происходит?! А вот и нет! Ни в коем разе!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200110b01.opus"
    xtl "И поэтому мне нужен какой-нибудь совет!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200120b01.opus"
    xtl "Шиничи, ты ведь подружился с Муко, да? И ты с ней, можно сказать, довольно близок?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_smile")
    with Dissolve(200.0/1000)
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_surprise")
    voice "voice/a51/1200130b01.opus"
    xtl "А Муко, в свою очередь, дружит с Сонэ-сан— Вот! Видишь это?"
    xy "Вижу что?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_shy")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200140b01.opus"
    xtl "Путь к сердцу Сонэ-сан!"
    xy "Посторонним вход воспрещён."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200150b01.opus"
    xtl "Пожалуйста, Шиничи! Умоляю тебя! Пожа-а-а-алуйста, помоги мне узнать Сонэ-сан получше! ПОЖАЛУЙСТА!"
    xy "Нет, не могу."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_gag")
    with Dissolve(200.0/1000)
    voice "voice/a51/1200160b01.opus"
    xtl "Одолжи мне свою силу, Бог снов!"
    xy "Найди себе другого Бога."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
