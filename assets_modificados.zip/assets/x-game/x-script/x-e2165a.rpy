label e2165a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2165a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg070100_2_雑貨店店内"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(200.0/1000)

    "Я взял её и побежал к кассе."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (300/1000)
    $ sename = "se物体_カウベル_鳴る"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    with Dissolve((1000.0)/1000)

    xy "\"Вот знак моей благодарности... за всё то, что ты делаешь для меня каждый день.\""
    voice "voice/e21/6500030a01.opus"

    mx "\"Хе-хе-хе...\""
    if (persistent.count_present == 10):
        $ GameName = "e2166.nss";
    else:
        $ GameName = "e2167.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
