label a1181_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a1191.nss"
    return
label a1181:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg") as 絵背景 zorder 100 at center
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    $ sename = "se物体_照明_スイッチ"
    play se sedict[sename]
    hide 絵背景
    with Dissolve(150.0/1000)
    pause (700/1000)
    $ renpy.music.play("ttb06",channel = "bgm", if_changed = True)
    pause (300/1000)
    "Сбежав из своего дома, Аой теперь жила одна в манга-кафе."
    "Бог, возможно, и существует, но это ни в коем случае не рай."
    "Просто здесь для неё должен был быть более счастливый конец."
    "Разумеется, «Бог» не являлся ни началом, ни концом чего-либо."
    show expression ("cg/ef/"+imagename["efbg自宅自室天井消灯"]+".jpg") as 絵背景 zorder 100 at center
    $ sename = "se人体_動作_座るソファー"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    pause (500/1000)
    "Может, я могу ей как-то помочь?"
    stop bgm fadeout (3000.0/1000)
    scene expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (2000/1000)
    hide 絵色黒
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
