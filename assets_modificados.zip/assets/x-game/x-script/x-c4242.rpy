label c4242_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c5111.nss"
    return
label c4242:
    hide 絵色黒
    $ sename = "se環境_自然_風モンゴルL"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")
    show expression ("cg/bg/"+imagename["bg900100_3_雰囲気空"]+".jpg") as 絵背景 zorder 1000 at truecenter
    with Dissolve(1500.0/1000)
    pause (500/1000)

    "Бледный свет освещал нас с небес, как бы благословляя наш союз."

    "Мы обнимались и смотрели на небо."

    "Я мог почувствовать её тепло своим телом."

    "Она такая маленькая и прекрасная..."

    "Я просто хочу обнимать её и всегда защищать..."

    "Но—"
    hide 絵背景
    with Dissolve(1000.0/1000)
    pause (500/1000)
    voice "voice/c42/4200010a02.opus"
    aoi "\"Буп-буп...\""

    "Чего-то не хватает."

    "Возможно, мы и были связаны физически, но у нас ещё впереди долгий путь."

    "Её взгляд был таким отдалённым, мне почти что стало интересно, смотрела ли она на что-то по ту сторону вселенной."

    xy "\"Всё то время, что я искал тебя, я размышлял кое о чём...\""

    xy "\"Я никогда не знал о тебе самого главного.\""
    voice "voice/c42/4200020a02.opus"

    aoi "\"Обо мне?..\""

    xy "\"Твои любимые вещи, нелюбимые вещи, о чём думаешь, в какие видеоигры играешь...\""

    xy "\"И в какого Бога веришь.\""
    voice "voice/c42/4200030a02.opus"
    aoi "\"Мой Бог...\""
    show expression ("cg/bg/l/"+imagename["bg900100_3_雰囲気空_l"]+".jpg") as 絵背景 zorder 1000:
        pos (-512,-576)
        linear 30 ypos 0
    with Dissolve((800.0+1000.0)/1000)

    "Аой переместила свой взгляд обратно на небо."

    "Её взгляд блуждал."

    "Как будто она смотрела на мир, который я не мог увидеть; мир, находившийся за пучиной звёзд."

    xy "\"Ты ведь расскажешь мне, верно?\""
    voice "voice/c42/4200040a02.opus"
    aoi "\"Буп-буп...\""
    stop bgm fadeout (3000.0/1000)

    "Её голос был тонким и слабым... и она даже не смотрела мне в глаза."
    show expression Solid("000000") as 絵色黒前 zorder 5000
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    $ EyeCatchIn(0.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
