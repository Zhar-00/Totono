label e3241_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e3241:
    hide 絵色黒
    pause (2000/1000)
    show expression ("cg/bg/"+imagename["bg110301_3_マンション寝室消灯"]+".jpg")
    $ st_timezone = "夜"
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_normal")
    with Dissolve(0.0/1000)
    voice "voice/e32/4100010a01.opus"
    mx "Эй, ТЫ."
    $ St("C",300,0,0,"fu曽根美雪_私服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e32/4100020a01.opus"

    mx "ТЕБЕ грустно?"
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/e32/4100030a01.opus"

    mx "Злишься?"
    $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e32/4100040a01.opus"

    mx "Может, даже... готов со зла выйти из игры?"
    $ St("C",300,0,0,"fu曽根美雪_私服_病み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e32/4100050a01.opus"

    mx "Та сцена секса была фрагментом из части рута Аой, который ТЫ никогда не видел."
    voice "voice/e32/4100060a01.opus"

    mx "Это правда о том, что произошло в той квартире."
    $ St("C",300,0,0,"fu曽根美雪_私服_病み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e32/4100070a01.opus"

    mx "ТЫ ведь не думал, что Аой говорила правду, когда сказала, что они остановились после вскрывания упаковки с презервативом, верно?"
    menu:
        "Аой трахалась с Рюджиро":
            $ SetChoiceSelect = 0
        "Она никогда не трахалась с ним":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ persistent.miyuki_love += 1
        $ GameName = "e3242a.nss";
    elif SetChoiceSelect==1:
        $ persistent.miyuki_love -= 1
        $ GameName = "e3242b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
