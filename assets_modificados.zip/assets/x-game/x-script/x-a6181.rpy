label a6181_MAIN:
    call expression GameName
    $ persistent.imagelog["eva6181アオイ挫折"]=True
    $ persistent.imagelog["bg060100_2_バッティングセンター店内"]=True
    $ persistent.imagelog["bg060200_2_バッティングセンターボックス"]=True
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label a6181:
    hide 絵色黒
    $ renpy.music.play("ttb07",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg060200_2_バッティングセンターボックス"]+".jpg")
    with Dissolve(3000.0/1000)
    "Один час спустя..."
    voice "voice/a61/8100010a02.opus"
    aoi "Буп-буп... Н-н-н... н-н-н..."
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2500/1000)
    with Dissolve((300.0+1000.0)/1000)
    voice "voice/a61/8100020a02.opus"
    aoi "—!"
    show expression ("cg/ev/l/"+imagename["eva6181アオイ挫折_l"]+".jpg") as 絵専 zorder 1100:
        pos (-400,0)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (500/1000)
    show expression Solid("FFFFFF") as 絵色白 zorder 5000 with None
    hide 絵色白
    with Dissolve((300.0)/1000)
    voice "voice/a61/8100030a02.opus"
    aoi "Ха-а... ха-а... ха-а... ха-а..."
    "Её замах был абсолютно неправильным."
    "Она даже не смогла задеть мяч битой."
    "И всё же..."
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2500/1000)
    voice "voice/a61/8100040a02.opus"
    aoi "—!"
    show expression ("cg/ev/l/"+imagename["eva6181アオイ挫折_l"]+".jpg") as 絵専 zorder 1100:
        pos (-400,0)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (500/1000)
    show expression Solid("FFFFFF") as 絵色白 zorder 5000 with None
    hide 絵色白
    with Dissolve((300.0)/1000)
    voice "voice/a61/8100050a02.opus"
    aoi "Ха-а... ха-а... ха-а... ха-а..."
    "...она продолжала махать битой."
    "Она знала, что не сможет забить хоум-ран, но всё равно пыталась."
    "Можно было подумать, что она уже сдалась, но она не сдавалась."
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2500/1000)
    with Dissolve((300.0+1000.0)/1000)
    pause (200/1000)
    show expression ("cg/ev/"+imagename["eva6181アオイ挫折"]+".jpg") as 絵専 zorder 1100:
        pos (0,0)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (500/1000)
    show expression Solid("FFFFFF") as 絵色白 zorder 5000 with None
    hide 絵色白
    with Dissolve((300.0)/1000)
    voice "voice/a61/8100060a02.opus"
    aoi "—!"
    hide 絵専
    $ sename = "se人体_衝撃_転倒01"
    play se sedict[sename]
    voice "voice/a61/8100070a02.opus"
    aoi "Н-н-н-н... н-н-н... н-н-н..."
    "Она упала на землю из-за движущей силы."
    "Исчерпав все свои силы, она была слишком уставшей, чтобы стоять."
    xy "Да ладно, Аой. Просто сдайся уже."
    voice "voice/a61/8100080a02.opus"
    aoi "Нет!"
    voice "voice/a61/8100090a02.opus"
    aoi "Аой никогда не сдастся!"
    voice "voice/a61/8100100a02.opus"
    aoi "Пока ты не... скажешь Миюки, что любишь её!"
    xy "Я же сказал тебе, я не могу."
    voice "voice/a61/8100110a02.opus"
    aoi "Да, ты можешь!"
    show expression ("cg/ev/l/"+imagename["eva6181アオイ挫折_l"]+".jpg") as 絵専:
        pos (-510,-200)
    $ sename = "se人体_動作_起き上がる02"
    play se sedict[sename]
    with Dissolve((500.0+1000.0)/1000)
    "Аой смогла поставить себя на ноги, использовав свою биту для опоры."
    voice "voice/a61/8100120a02.opus"
    aoi "Как только Аой забьёт хоум-ран, у тебя должна быть вера."
    xy "Говорю же тебе, Бога нет."
    voice "voice/a61/8100130a02.opus"
    aoi "ОН ЕСТЬ!!!"
    show expression ("cg/bg/"+imagename["bg060200_2_バッティングセンターボックス"]+".jpg")
    $ sename = "se人体_動作_バット構える01"
    play se sedict[sename]
    hide 絵専
    with Dissolve(300.0/1000)
    xy "А?"
    $ sename = "se人体_動作_バット構える02"
    play se sedict[sename]
    voice "voice/a61/8100140a02.opus"
    aoi "Он есть, он есть, ОН ЕСТЬ!"
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2500/1000)
    with Dissolve((300.0+1000.0)/1000)
    show expression ("cg/ev/"+imagename["eva6181アオイ挫折"]+".jpg") as 絵専 zorder 1100 at truecenter
    pause (200/1000)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve((400.0+0.0)/1000)
    voice "voice/a61/8100150a02.opus"
    aoi "—Н-нгх!"
    voice "voice/a61/8100160a02.opus"
    aoi "Аой лично встречалась с Богом!"
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2500/1000)
    with Dissolve((300.0+1000.0)/1000)
    pause (200/1000)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve((400.0+0.0)/1000)
    voice "voice/a61/8100170a02.opus"
    aoi "—Н-нгх!"
    voice "voice/a61/8100180a02.opus"
    aoi "И Бог может обновить вселенную!"
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2500/1000)
    with Dissolve((300.0+1000.0)/1000)
    pause (200/1000)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve((400.0+0.0)/1000)
    voice "voice/a61/8100190a02.opus"
    aoi "—Хн-нгх!"
    voice "voice/a61/8100200a02.opus"
    aoi "А это значит... что чудеса также бывают!.."
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2500/1000)
    with Dissolve((300.0+1000.0)/1000)
    pause (200/1000)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve((400.0+0.0)/1000)
    voice "voice/a61/8100210a02.opus"
    aoi "—Хг-гх!"
    voice "voice/a61/8100220a02.opus"
    aoi "Твои желания... могут исполниться!.."
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2500/1000)
    with Dissolve((300.0+1000.0)/1000)
    pause (200/1000)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve((400.0+0.0)/1000)
    pause (200/1000)
    $ sename = "se人体_衝撃_転倒01"
    play se sedict[sename]
    hide 絵専
    with Dissolve(300.0/1000)
    voice "voice/a61/8100230a02.opus"
    aoi "—Н-нгха!"
    voice "voice/a61/8100240a02.opus"
    aoi "И Аой может забить хоум-ран!"
    $ sename = "se物体_バット_転がる"
    play se sedict[sename]
    voice "voice/a61/8100250a02.opus"
    aoi "Аой... знает... Аой может... сделать это..."
    show expression ("cg/bg/l/"+imagename["bg060100_2_バッティングセンター店内_l"]+".jpg") as 絵専背景 zorder 3010:
        pos (-960,-400)
    with Dissolve(500.0/1000)
    xy "Аой!"
    voice "voice/a61/8100260a02.opus"
    aoi "Почему?.."
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    "Она потянулась вниз и подобрала бейсбольный мяч, лежащий на земле."
    $ sename = "se人体_動作_投げる"
    play se sedict[sename]
    "А потом она бросила его в сеть..."
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    "И, разумеется, он не долетел до мишени."

    voice "voice/a61/8100270a02.opus"
    aoi "Почему, почему, ПОЧЕМУ?!"
    voice "voice/a61/8100280a02.opus"
    aoi "Почему Аой не может сделать это?.."
    xy "Аой..."
    "Она вдруг сжалась."
    "Её тень колебалась на земле."
    "И она слабо прошептала."
    voice "voice/a61/8100290a02.opus"
    aoi "Слушай, Шиничи..."
    voice "voice/a61/8100300a02.opus"
    aoi "За последние несколько дней..."
    voice "voice/a61/8100310a02.opus"
    aoi "Мои телефонные звонки... они не доходили."
    voice "voice/a61/8100320a02.opus"
    aoi "И поэтому Аой не могла попросить Бога сохранить игру."
    voice "voice/a61/8100330a02.opus"
    aoi "И Аой не может даже создать патч обновления."
    voice "voice/a61/8100340a02.opus"
    aoi "Как думаешь... Бог бросил меня?.."
    voice "voice/a61/8100350a02.opus"
    aoi "Неужели Аой с самого начала не была романтическим выбором?"
    xy "......"
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵覆 zorder 5000
    show expression ("cg/ev/"+imagename["eva0113アオイ送信中d"]+".jpg") as 絵覆絵背景 zorder 3100 at truecenter
    with Dissolve((1000.0+0.0)/1000)
    "Аой не было всё это время..."
    "Я мог представить, как она поднимала руку в воздух, «передавая» тем самым «данные» Богу при помощи телефона, который не ловит сигнал."
    "Она была так сильно отдалена от реальности, её «бог» – единственная эмоциональная поддержка, которая была у неё."
    "И без неё, она—"
    with Dissolve((800.0+1000.0)/1000)
    hide 絵色回想黒下敷
    hide 絵色回想黒
    hide 絵覆絵背景
    hide 絵覆
    hide 絵専背景
    show expression ("cg/bg/"+imagename["bg060200_2_バッティングセンターボックス"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg060200_2_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15:
        pos (-100,-520)
    $ St("C",740,0,0,"bu向日アオイ電波_制服_通常_normal")
    hide 絵色黒
    with Dissolve(1000.0/1000)
    voice "voice/a61/8100360a02.opus"
    aoi "Но ты меня многому научил."
    voice "voice/a61/8100370a02.opus"
    aoi "Ты подарил мне..."
    $ St("C",740,0,0,"bu向日アオイ電波_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a61/8100380a02.opus"
    aoi "...радость..."
    $ St("C",740,0,0,"bu向日アオイ電波_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a61/8100390a02.opus"
    aoi "...восторг..."
    $ St("C",740,0,0,"bu向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a61/8100400a02.opus"
    aoi "...грусть..."
    $ St("C",740,0,0,"bu向日アオイ電波_制服_通常_pain")
    with Dissolve(200.0/1000)
    voice "voice/a61/8100410a02.opus"
    aoi "...боль..."
    $ St("C",740,0,0,"bu向日アオイ電波_制服_通常_pain")
    with Dissolve(200.0/1000)
    voice "voice/a61/8100420a02.opus"
    aoi "...и все прочие чувства в этой вселенной."
    voice "voice/a61/8100430a02.opus"
    aoi "Именно благодаря тебе, Аой сегодня такая, какая есть."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a61/8100440a02.opus"
    aoi "И теперь, Шиничи..."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a61/8100450a02.opus"
    aoi "...ты – мой новый Бог."
    "Я – её Бог?"
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a61/8100460a02.opus"
    aoi "Пожалуйста, помоги мне..."
    voice "voice/a61/8100470a02.opus"
    aoi "Аой нужно во что-то поверить..."
    voice "voice/a61/8100480a02.opus"
    aoi "Пожалуйста, скажи мне, что мои чувства имеют место быть..."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_pain")
    with Dissolve(200.0/1000)
    voice "voice/a61/8100490a02.opus"
    aoi "Помоги мне поверить в любовь!.."
    return
label a6181_SELECT:
    $ renpy.save("lastsel")
    $ renpy.music.play("ttb07",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg060200_2_バッティングセンターボックス"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg060200_2_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15:
        pos (-100,-520)
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_pain")
    with Dissolve(300.0/1000)
    menu:
        "Помочь ей поверить":
            $ SetChoiceSelect = 0
        "Подвести её":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "a6182a.nss"
    else:
        $ GameName = "a6182b.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
