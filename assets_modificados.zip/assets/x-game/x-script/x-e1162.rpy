label e1162_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1162:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040400_2_街交差点"]+".jpg")
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_sad")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/6200010b01.opus"
    xtl "\"Она у меня дома.\""
    xy "\"Что?\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/e11/6200020b01.opus"
    xtl "\"А?\""
    voice "voice/e11/6200030b01.opus"
    xtl "\"Это странно?\""
    xy "\"В каком это смысле, она... «у тебя дома»?\""
    xy "\"Она же персонаж в видеоигре, разве нет?\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/6200040b01.opus"
    xtl "\"Персонаж в видеоигре? О чём ты говоришь?\""
    xy "\"......Что?\""
    "Похоже, у нас возникло полное отсутствие взаимопонимания..."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/6200050b01.opus"
    xtl "\"Ладно, не важно. Если хочешь поговорить с Муко, просто приходи ко мне.\""
    xy "\"Л-ладно...\""
    hide StC with Dissolve(200.0/1000)
    pause (200/1000)
    $ sename = "se人体_足音_歩く01遅L"
    play se sedict[sename]
    $ sename = "se人体_足音_歩く01L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    with Dissolve(500.0/1000)
    pause (500/1000)
    voice "voice/e11/6200060b01.opus"
    xtl "\"Как твоя нога? Уже лучше?\""
    xy "\"...Моя нога?\""
    voice "voice/e11/6200070b01.opus"
    xtl "\"Ты ведь был в больнице, да?\""
    xy "\"О чём ты говоришь?\""
    voice "voice/e11/6200080b01.opus"
    xtl "\"В смысле, о чём я говорю? Учителя нам всё рассказали.\""
    voice "voice/e11/6200090b01.opus"
    xtl "\"И Сонэ-сан ещё сказала, что навещала тебя несколько раз.\""
    xy "\"А... понятно...\""
    if persistent.miyuki_sex1 and persistent.miyuki_sex2:
        $ GameName = "e1163a.nss";
    else:
        $ GameName = "e1163b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
