label a3131_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010800_3_学校体育館"]=True
    $ PreGameName = GameName
    $ GameName = "a3141.nss"
    return
label a3131:
    hide 絵色黒
    $ sename = "se物体_ドア体育_開く02"
    play se sedict[sename]
    pause (500/1000)
    scene expression ("cg/bg/"+imagename["bg010800_3_学校体育館"]+".jpg")
    with Dissolve(1000.0/1000)
    $ st_timezone = "昼"
    pause (500/1000)
    xy "Ау?.."
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb09",channel = "bgm", if_changed = True)
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_pinch")
    voice "voice/a31/3100010b03.opus"
    c "Ох... я... мне очень жаль!"
    xy "А?"
    "Как только я прошёл за дверь, передо мной спонтанным образом начала извиняться первоклашка."
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/3100020b03.opus"
    c "Я... я видела, как ты входил сюда, и это произошло так быстро, что я испугалась!.."
    xy "Я что-то не так сделал?"
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_pinch")
    with Dissolve(200.0/1000)
    voice "voice/a31/3100030b03.opus"
    c "Нет, нет... эм... В тот момент я просто запаниковала... ну, знаешь, будучи увиденной таким образом... и я не знала, что делать, и поэтому я!.."
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_pinch")
    voice "voice/a31/3100040a02.opus"
    aoi "Он на тебя пялился?"
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/3100050b03.opus"
    c "А? Нет, нет..."
    xy "Разумеется, нет! Видишь? Она знает, что я не такой страшный!"
    voice "voice/a31/3100060a02.opus"
    aoi "Может, ты ей просто не нравишься?"
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a31/3100070b03.opus"
    c "Неправда!"
    voice "voice/a31/3100080a02.opus"
    aoi "То есть, он тебе НРАВИТСЯ?"
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_pinch")
    with Dissolve(200.0/1000)
    voice "voice/a31/3100090b03.opus"
    c "Ч... что... Н-Н-Н-Н-НРАВИТСЯ?! Ещё чего! Ни в коем разе! Я ненавижу его! Да, всё верно! Я его на дух не переношу!"
    xy "Э-э-э-эм..."
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_fear")
    with Dissolve(200.0/1000)
    voice "voice/a31/3100100b03.opus"
    c "Ох... эм... а-а-а-а!.."
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_pinch")
    with Dissolve(200.0/1000)
    voice "voice/a31/3100110b03.opus"
    c "Я... ПРОСТИ МЕНЯ!!!"
    $ sename = "se人体_足音_走る01"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    "Спустя долю секунды, она вылетела, словно летучая мышь из ада."
    $ sename = "se擬音_コミカル_倒れる"
    play se sedict[sename]
    voice "voice/a31/3100120b03.opus"
    c "Ай!"
    with Dissolve(200.0/1000)
    voice "voice/a31/3100130a02.opus"
    aoi "Похоже, она упала."
    xy "Ага."
    voice "voice/a31/3100140a02.opus"
    aoi "Она просто неуклюжая."

    $ St("C",300,0,0,"st曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a31/3100150a01.opus"
    mx "ЭЙ! Вы что делаете, опять достаёте Хару-чан?!"
    xy "Мы её вовсе не доставали!"
    "Раз на то пошло, я абсолютно уверен в том, что я здесь жертва!"
    xy "Боже... Ты уверена, что такой нежный цветочек, как она, сможет участвовать в спектакле?"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/a31/3100160a01.opus"
    mx "Она правда очень талантливая. И у неё очень привлекательный вид."
    voice "voice/a31/3100170a02.opus"
    aoi "Шиничи, ты просто расстроен тем, что тебе отказали."
    xy "Она не может отклонить признание, которого я не делал!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Но тем не менее, я был бы не против увидеть её выступление..."
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
