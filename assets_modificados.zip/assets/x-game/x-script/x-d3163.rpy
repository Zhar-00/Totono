label d3163_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c3166.nss"
    return
label d3163:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    with Dissolve(200.0/1000)

    xy "\"Да, ты права.\""

    "Сколько раз я не пытался дозвониться до неё, её телефон всё так же не ловил сигнал."

    "Время уже позднее, и у нас нет каких-либо зацепок."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/d31/6300010a01.opus"

    mx "\"Давай закругляться.\""

    "Я кивнул."

    "Я чувствовал себя совершенно бессильным..."

    "Я был так рад, что смог наконец-то подружиться с ней, но в конце концов, это всё, чего мы добились?.."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/d31/6300020a01.opus"

    mx "\"Пошли уже! Не выматывай себя из-за этого!\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/d31/6300030a01.opus"

    mx "\"Я уверена, Аой просто вернулась домой к своим родителям. Она должна быть там.\""

    xy "\"Надеюсь, ты права...\""

    "Я снова неохотно кивнул."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
