label e3424d_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2203b.nss"
    return
label e3424d:
    hide 絵色黒
    $ renpy.music.play("ttb14",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)

    "Число, которое Миюки нравится больше всего."

    "Что бы это могло быть?"

    "Я отчаянно восстанавливал ход своих воспоминаний."

    "...Не то, чтобы мне было, что сказать..."
    voice "voice/e34/24d00010b02.opus"

    kmsm "\"НЕТ ПОВОДА ДЛЯ БЕСПОКОЙСТВА.\""
    voice "voice/e34/24d00020b02.opus"

    kmsm "\"МИЮКИ ЗАПИСАЛА ЭТО ЧИСЛО.\""
    voice "voice/e34/24d00030b02.opus"

    kmsm "\"ПРОСМОТРИ СОДЕРЖАНИЕ ПАПКИ С ФОТОГРАФИЯМИ НА ЕЁ СМАРТФОНЕ.\""

    "По его просьбе, я открыл Фотографии."
    $ Last_number = True;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
