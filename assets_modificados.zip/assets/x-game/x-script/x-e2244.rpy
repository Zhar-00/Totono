label e2244_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2244:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)

    "Я начал листать стопку листовок и купонов."

    "Суши... Пицца... Китайская кухня..."

    "Из всего этого, Миюки, наверное, предпочтёт—"
    if persistent.miyuki[17] == 0:

        xy "\"Тогда, наверное, я закажу суши?\""

        xy "\"Ты сказала, что не совсем умеешь делать это дома, верно?\""
    elif persistent.miyuki[17] == 1:

        xy "\"Тогда, наверное, я закажу пиццу?\""

        xy "\"Ты сказала, что не совсем умеешь делать это дома, верно?\""
    elif persistent.miyuki[17] == 2:

        xy "\"Тогда, наверное, я закажу что-нибудь из китайской кухни?\""

        xy "\"Ты сказала, что не совсем умеешь делать это дома, верно?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/e22/4400010a01.opus"

    mx "\"Оу, ты помнишь!..\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/4400020a01.opus"

    mx "\"Этот подарок ещё лучше, чем заказанная еда на дом!\""

    "Миюки лучезарно улыбнулась."

    "Эта улыбка делала заказ еды на дом абсолютно стоящим..."

    "Будучи довольным собой, я позвонил в ресторан..."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
