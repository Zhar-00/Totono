label e2322a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2322a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    xy "\"Отлично!\""
    "Я каким-то образом смог ответить на все секретные вопросы Миюки."
    "Теперь я могу проверить её список контактов."
    "Я открыл приложение, и увидел там—"
    xy "\"...Только Бог, да?\""
    "Только одна запись."
    "Наверное, все её друзья и члены семьи записаны на другом телефоне."
    "Любопытство до добра не доводит..."
    "Теперь, когда я просмотрел её список контактов, ну... мне больше нечего делать, серьёзно."
    menu:
        "Пойти спать":
            $ SetChoiceSelect = 0
        "Позвонить Богу":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e2323a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e2323b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
