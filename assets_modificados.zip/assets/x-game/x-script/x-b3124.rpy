label b3124_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a3125.nss"
    return
label b3124:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010300_2_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/b31/2400010a02.opus"
    aoi "\"Скрипт игры был переписан так, чтобы ты и Миюки могли быть вместе.\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_happy")
    with Dissolve(200.0/1000)
    voice "voice/b31/2400020a02.opus"
    aoi "\"И теперь тебя никогда, никогда не бросят.\""
    voice "voice/b31/2400030a02.opus"
    aoi "\"Так что тебе больше не о чем беспокоиться.\""
    voice "voice/b31/2400040a02.opus"
    aoi "\"Ты можешь любить Миюки столько, сколько хочешь.\""
    xy "\"А... точно.\""
    xy "\"Спасибо.\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/b31/2400050a02.opus"
    aoi "\"Не за что.\""
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Я не мог увидеть бога Аой."
    "Я могу отличить реальность от вымысла. Я не настолько сумасшедший, чтобы верить в то, что её бог действительно поможет мне."
    "Но Аой молилась за меня..."
    "И это имеет куда большее значение."
    xy "\"Ладно, пошли найдём Миюки.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
