label e3423c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3424c.nss"
    return
label e3423c:
    hide 絵色黒
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    stop bgm fadeout (2000.0/1000)
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e34/23c00010b02.opus"

    kmsm "\"ПОНЯЛ.\""
    voice "voice/e34/23c00020b02.opus"

    kmsm "\"МЫ НЕ МОЖЕМ ЗАСТАВЛЯТЬ [[ТЕБЯ].\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
