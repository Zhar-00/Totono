label a3124a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if persistent.world_recreate == True:
        $ GameName = "e3124a.nss"
    else:
        $ GameName = "a3125.nss"
    return
label a3124a:
    hide 絵色黒
    $ renpy.music.play("tts_in",channel = "bgm", if_changed = True)
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    with Dissolve(800.0/1000)
    "Полагаю, здесь и правда есть Бог."
    "Если Он может изменить мою судьбу... и сделать невозможное возможным..."
    "То что Он попросит взамен?"
    "Чем я буду вынужден пожертвовать?"
    xy "Остановись! Пожалуйста!"
    "Прокричал я в панике."
    "Что-то мне подсказывало, что я должен остановить её прежде, чем она успеет сделать необратимое."
    voice "voice/a31/24a00010a02.opus"
    aoi "Шиничи?.."
    xy "Серьёзно, пожалуйста, не делай это."
    voice "voice/a31/24a00020a02.opus"
    aoi "Буп-буп..."
    pause (500/1000)
    $ St("C",740,0,0,"st向日アオイ電波_制服_電話_other")
    with Dissolve(200.0/1000)
    pause (800/1000)
    $ sename = "se人体_動作_腕を上げる"
    play se sedict[sename]
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    pause (500/1000)
    voice "voice/a31/24a00030a02.opus"
    aoi "Ты уверен?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/24a00040a02.opus"
    aoi "Ты сейчас выходишь на плохую концовку."
    voice "voice/a31/24a00050a02.opus"
    aoi "Ты правда этого хочешь?"
    "Ничто в моей жизни не может называться «плохой концовкой»."
    "Да, в ней нет ничего особенного, но она всё такая же весёлая."
    "Мне НЕ НУЖНО встречаться с Миюки. Наша дружба уже является чем-то большим, о чём я до этого мог только мечтать."
    "И это правда, всё просто и понятно."
    "Мне не нужно думать дважды над своим ответом."
    xy "Это именно то, чего я хочу."
    xy "Я рад просто быть друзьями."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a31/24a00060a02.opus"
    aoi "Друзья..."
    "Как только это слово сошло с её губ..."
    $ sename = "se環境_自然_風モンゴルL"
    play se sedict[sename]
    $ sename = "se環境_自然_風モンゴルL"
    play se sedict[sename]
    $ sename = "se環境_自然_風モンゴルL"
    play se sedict[sename]

    scene expression "cg/bg/31bc07d4bc9a0deffecb457b246da42ed274f8d8.jpg"
    with ImageDissolve("cg/data/zzex_ogm_sky01.png", 3.0, ramplen=128, reverse=False)
    $ renpy.pause(2, hard=True)

    scene expression "cg/bg/c31ca6479ce70a4a775fa78101f95e9e9e90772f.png"
    with ImageDissolve("cg/data/zzex_ogm_sky01.png", 3.0, ramplen=128, reverse=False)
    $ renpy.pause(2, hard=True)

    scene expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    with Dissolve(800.0/1000)


    scene expression ("cg/bg/"+imagename["bg010300_2_学校屋根"]+".jpg")
    with ImageDissolve("cg/data/blind_06_00_1.png", 3.0, ramplen=128, reverse=False)
    $ renpy.pause(2, hard=True)

    stop bgm
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(0.0/1000)
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    with Dissolve(800.0/1000)
    pause (500/1000)
    "...небо сразу стало ясным, прямо у меня на глазах."
    "Было ли это действом Бога? Если честно, я не знаю."
    "Наверное, у неё и правда есть способность всё изменять."
    "Но мне не нужно какое-либо божественное чудо."
    "Я просто хочу, чтобы всё шло своим чередом так, как это было всегда."
    "...Я скажу самому себе, что это всё было обычным сном."
    "Иллюзией. Галлюцинацией."
    "В смысле, чем бы это ещё могло быть?"
    xy "Пошли искать Миюки."
    hide StC
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
