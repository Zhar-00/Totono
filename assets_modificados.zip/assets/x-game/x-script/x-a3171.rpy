label a3171_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010700_3_学校廊下"]=True
    $ PreGameName = GameName
    $ GameName = "a3181.nss"
    return
label a3171:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg030200_3_自宅玄関"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shout")
    with Dissolve(0.0/1000)

    xy "Спасибо, что пошла со мной."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_rage")
    with Dissolve(200.0/1000)
    voice "voice/a31/7100010a01.opus"
    mx "Как будто я не собиралась!"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_shout")
    with Dissolve(200.0/1000)
    voice "voice/a31/7100020a01.opus"
    mx "В смысле, Аой крайне предсказуемая, знаешь ли."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/7100030a01.opus"
    mx "Поэтому, ну, разумеется, я должна сделать ЧТО-НИБУДЬ!"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/7100040a01.opus"
    mx "Ну да ладно, ты ЗНАЕШЬ, куда она ушла, да?"
    xy "Да... По крайней мере, я в этом очень уверен."
    $ EyeCatchIn(2000.0)
    pause (1000/1000)
    show expression ("cg/bg/"+imagename["bg010401_3_学校校門閉通用口開雨"]+".jpg")
    with Dissolve(2000.0/1000)
    $ renpy.music.set_volume(.5,channel = "rain",delay =1.5)
    voice "voice/a31/7100050a01.opus"
    mx "Школа?.."
    "Я не виню её за такую скептичность."
    "Несмотря на любовь Аой к крыше, я продолжал твердить себе, что она никоим образом не могла проникнуть на территорию школы ночью."
    xy "Видишь? Смотри."
    show expression ("cg/bg/l/"+imagename["bg010401_3_学校校門閉通用口開雨_l"]+".jpg") as 絵背景 zorder 5000:
        xpos 0
        ycenter .5
    with Dissolve(500.0/1000)
    voice "voice/a31/7100060a01.opus"
    mx "О!"
    "Кто-то оставил калитку ворот для пешеходов открытой."
    voice "voice/a31/7100070a01.opus"
    mx "Я и не заметила..."
    xy "Пошли."
    $ renpy.music.set_volume(.1,channel = "rain",delay=2)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    hide 絵背景
    show expression ("cg/bg/"+imagename["bg010500_3_学校昇降口"]+".jpg")
    pause (1000/1000)
    hide 絵色黒
    with Dissolve(500.0/1000)
    "И, разумеется, входная дверь также была приоткрытой."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/7100080a01.opus"
    mx "Я почему-то сомневаюсь, что дворники могли забыть закрыть двери за собой..."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    show expression ("cg/bg/"+imagename["bg010700_3_学校廊下"]+".jpg")
    $ sename = "se人体_足音_歩く複数美雪廊下"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    "Здание школы было абсолютно пустым."
    "Как только мы переобулись в нашу сменную обувь, малейший цокот наших подошв на линолеуме раздавался эхом по всему коридору, словно выстрел из оружия."
    xy "Сюда."
    with Dissolve(200.0/1000)
    voice "voice/a31/7100090a01.opus"
    mx "Она не в классе?"
    xy "Посмотри вниз."
    "Следы от капель воды шли в противоположном направлении прямо к спортзалу."
    stop se fadeout (300.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/7100100a01.opus"
    mx "Как ты узнал?"
    xy "А?"
    voice "voice/a31/7100110a01.opus"
    mx "Ну, ты сказал, что у тебя есть идея, и побежал к себе домой. Но зачем?"
    xy "А... ну, эм..."
    "Я... если честно, был не особо уверен, как объяснить это ей."
    "Причина, по которой мы пришли сюда, заключалась в том, что в игре была сцена, где промокшая насквозь «Аой» решила укрыться в спортзале."
    "Но я знал, что Миюки не очень нравится идея объединения видеоигр с реальностью, и это только усложняло объяснение..."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/a31/7100120a01.opus"
    mx "...Всё нормально. Не волнуйся об этом сейчас."
    "Миюки вздохнула. Она, должно быть, почувствовала мою неуверенность."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/7100130a01.opus"
    mx "Расскажешь мне позже, ладно?"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
