label a1141_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a1151.nss"
    return
label a1141:
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    with Dissolve((0.0)/1000)
    $ st_timezone = "昼"
    show expression ("cg/ef/"+imagename["efbg自宅自室天井昼"]+".jpg") as 絵背景弐 zorder 100 at center
    $ sename = "se人体_動作_座るソファー"
    play se sedict[sename]
    with Dissolve((500.0+1000.0)/1000)
    pause (300/1000)
    $ renpy.music.play("ttb12",channel = "bgm", if_changed = True)
    xy "......"
    "Лёжа на своей кровати, я смотрел на свой телефон."
    "Одинокая маленькая Аой, у которой так мало друзей..."
    "Она даже не знает, кто такие друзья."
    "Наверное, это судьба."
    "Я бы хотел, чтобы она могла с кем-нибудь общаться в школе по утрам..."
    "Должен признать, что я, наверное, должен волноваться о своих делах, но я не могу ничего с этим поделать."
    "Если подумать, я так и не получил то письмо, которое пытался отправить самому себе с её телефона."
    "И я написал ей пару сообщений после занятий, но безрезультатно..."
    "В качестве эксперимента, я нажал на кнопку вызова."
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    pause (600/1000)
    $ sename = "se物体_携帯_発信待機L"
    play se sedict[sename]
    pause (3000/1000)
    $ sename = "se物体_携帯_圏外"
    play se sedict[sename]
    pause (2800/1000)
    pause (500/1000)
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    "...Она не приняла вызов."
    "Её телефон вообще не ловит сигнал сети?"
    show expression Solid("000000") as 絵色黒
    with Dissolve((1500.0+1000.0)/1000)
    show expression ("cg/ev/"+imagename["eva0113アオイ送信中d"]+".jpg") as 絵覆絵過去 zorder 2500 at center
    with Dissolve(1500.0/1000)
    "Я мог представить, как она стояла там, на крыше..."
    "Было до боли ироничным то, что только самозваная «девушка-передатчик» не могла уловить какой-либо сигнал."
    stop bgm fadeout (3000/1000)
    scene expression Solid("000000") as 絵色黒上
    with Dissolve((2000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
