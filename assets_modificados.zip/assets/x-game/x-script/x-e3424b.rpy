label e3424b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3424c.nss"
    return
label e3424b:
    hide 絵色黒
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    stop bgm fadeout (2000.0/1000)
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)

    "Мои пальцы вдруг остановились."

    "Я не понимаю, чего от меня просил Бог."

    "Какое число мне не нужно было, я не мог подумать о нём."
    voice "voice/e34/24b00010b02.opus"

    kmsm "\"[[ТЫ] ОТКАЗЫВАЕШЬСЯ ОТ [[СВОЕГО] ЖЕ НАМЕРЕНИЯ ВОССТАНОВИТЬ АОЙ?\""
    voice "voice/e34/24b00020b02.opus"

    kmsm "\"...ПОНЯЛ.\""
    voice "voice/e34/24b00030b02.opus"

    kmsm "\"МЫ НЕ МОЖЕМ ЗАСТАВЛЯТЬ [[ТЕБЯ].\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
