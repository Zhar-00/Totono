label d6151_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6152.nss"
    return
label d6151:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010801_2_学校体育館演劇準備"]+".jpg")
    $ st_timezone = "昼"
    $ sename = "se環境_ガヤ_教室ざわめくL"
    play se sedict[sename]
    with Dissolve(1000.0/1000)

    "Я отдал свой билет и вошёл в тёмный спортзал."

    "К счастью, я смог добраться сюда с кучей свободного времени в запасе."

    "Места в зрительном зале были заполнены только наполовину."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/d61/5100010a01.opus"

    mx "\"О, ты здесь!\""

    xy "\"Привет, Миюки... У вас здесь уже всё готово?\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/d61/5100020a01.opus"

    mx "\"Я уже сказала тебе, я бросила спектакль, помнишь? Мне и с самого начала не надо было приходить сюда.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/d61/5100030a01.opus"

    mx "\"Ну да ладно, где Аой?\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/d61/5100040a01.opus"

    mx "\"Ты ведь ПРИГЛАСИЛ её, верно?\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
