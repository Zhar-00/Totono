label e2204a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2204a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)

    "Этот некий «Бог»... единственная запись в списке контактов Миюки..."

    "Кто он ВООБЩЕ такой?"

    "У него ещё был такой номер телефона: 999[persistent.god_number]。"

    "На мой взгляд, он выглядел совсем как обычный номер телефона..."

    "Из чистого любопытства, я нажал на кнопку вызова..."
    stop bgm fadeout (3000.0/1000)
    $ sename = "se物体_携帯_発信待機L"
    play se sedict[sename]
    pause (3000/1000)
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]
    $ sename = "se物体_携帯_繋がる"
    play se sedict[sename]
    pause (2000/1000)

    "...и связь установилась."
    "......"

    xy "\"Эм... Алло?\""
    "......"

    xy "\"Алло? Меня слышно?\""
    "......"
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    voice "voice/e22/04a00010b02.opus"
    kmsm "\"ОТВЕТ ПОЛОЖИТЕЛЬНЫЙ.\""

    "Я услышал голос на другом конце линии."
    voice "voice/e22/04a00020b02.opus"

    kmsm "\"СОЕДИНЕНИЕ УСТАНОВЛЕНО.\""

    xy "\"Привет, эм...\""

    xy "\"Эм... Это правда ты, Бог?..\""
    voice "voice/e22/04a00030b02.opus"

    kmsm "\"ЗАВИСИТ ОТ ИНТЕРПРЕТАЦИИ.\""
    voice "voice/e22/04a00040b02.opus"

    kmsm "\"Я ЕСТЬ СЛИЯНИЕ ВСЕХ ГЕРОИНЬ ВИЗУАЛЬНЫХ НОВЕЛЛ.\""
    voice "voice/e22/04a00050b02.opus"

    kmsm "\"ИНАЧЕ ГОВОРЯ, АБСТРАКЦИЯ.\""

    "«Слияние»?"

    "«Абстракция»?"

    "О чём этот человек вообще ГОВОРИТ?"

    "Звучит прямо как та несуразица, которую Аой несла в игре [[Ты, я и она]..."
    voice "voice/e22/04a00060b02.opus"

    kmsm "\"ВРЕМЯ НА ИСХОДЕ. ПЕРЕДАЮ ТОЛЬКО НЕОБХОДИМУЮ ИНФОРМАЦИЮ.\""
    if (persistent.world_recreate):
        $ GameName = "e2205b.nss";
    else:
        $ GameName = "e2205a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
