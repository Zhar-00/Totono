label a6191_MAIN:
    call expression GameName
    $ persistent.imagelog["bg050100_2_バッティングセンター外正面"]=True
    $ PreGameName = GameName
    $ GameName = "a6201.nss"
    return
label a6191:
    hide 絵色黒
    $ renpy.music.play("ttb14",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg050100_2_バッティングセンター外正面"]+".jpg")
    $ sename = "se人体_足音_駆け出す"
    play se sedict[sename]
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]
    "У меня не было талантов."
    "Я просто бездарность. Тряпка. Ничтожество."
    "Я не принц. Я не могу забить хоум-ран."
    "И Миюки была совершенно не моего уровня."
    "Это был факт, просто и понятно."
    "И всё же..."
    "Я вспомнил, как Аой изо всех сил пыталась забить его, пока не довела себя до крайности."
    "Была ли она жалкой?"
    "Были ли её слёзы пролиты впустую?"
    "Нет."
    "Благодаря её помощи, я наконец-то нашёл в себе силы сделать замах."
    "Хоум-ран или страйк, мне было всё равно."
    "Я должен хотя бы попытаться."
    "И теперь я это понял."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((0.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    "Не важно, сколько раз я отговаривал себя бросить это..."
    "Не важно, сколько раз я делал вид, будто это всё было не наяву..."
    "Мои чувства всегда были здесь, с самого начала."
    "Я всегда любил её."
    "Она была для меня всем."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((0.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg")
    "Ну и что, что я не смог стать принцем для своей счастливой концовки? Ну и что, что реальная жизнь устроена не таким образом?"
    "Мне уже надоело врать самому себе о своих чувствах."
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg020100_2_自宅外正面"]+".jpg") as 絵背景 zorder 1001 at truecenter
    show expression ("cg/bg/"+imagename["bg030400_1_自宅廊下"]+".jpg") as 絵背景弐 zorder 1000 at truecenter
    show expression ("cg/bg/"+imagename["bg030300_2_自宅リビング"]+".jpg")
    pause (100/1000)
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒
    hide 絵背景
    pause (100/1000)
    $ sename = "se物体_ドア室内_開く02"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒
    hide 絵背景弐
    pause (100/1000)
    show expression ("cg/bg/l/"+imagename["bg030300_2_自宅リビング_l"]+".jpg") as 絵背景:
        pos (-350,-480)
    $ sename = "se物体_紙_掴む"
    play se sedict[sename]
    with Dissolve((300.0+1000.0)/1000)
    "Я забрал билет со стола."
    show expression ("cg/bg/"+imagename["bg030200_2_自宅玄関"]+".jpg")
    hide 絵背景
    with Dissolve(200.0/1000)
    "До начала шоу осталось пятнадцать минут."
    $ sename = "se物体_ドア自宅_閉まる"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]
    pause (4000/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
