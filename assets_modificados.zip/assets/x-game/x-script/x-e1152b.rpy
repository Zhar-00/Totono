label e1152b_MAIN:
    $ persistent.rlock = True
    $ _game_menu_screen = ""
    call expression GameName
    $ PreGameName = GameName
    return
label e1152b:
    hide 絵色黒
    $ renpy.music.play("ttb22",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    if (BackFile == "e1151a.nss"):
        $ St("C",300,0,0,"fu曽根美雪_制服_病み_sad")
    else:
        $ St("C",300,0,0,"fu曽根美雪_制服_恋人_ero")
    with Dissolve(0.0/1000)
    xy "\"Это слишком внезапно... я не могу поцеловать тебя здесь!..\""
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_happy")
    voice "voice/e11/52b00010a01.opus"
    mx "\"Тогда готовься к смерти.\""
    xy "\"Что?\""
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_lost")
    with Dissolve(200.0/1000)
    voice "voice/e11/52b00020a01.opus"
    mx "\"Я буду начинать этот день сначала.\""
    voice "voice/e11/52b00030a01.opus"
    mx "\"Столько раз, сколько потребуется, снова и снова, целую вечность... пока ты не поцелуешь меня.\""
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_mad")
    with Dissolve(200.0/1000)
    voice "voice/e11/52b00040a01.opus"
    mx "\"Я напишу код в бесконечном цикле, пока ты не выберешь «Поцеловать её».\""
    voice "voice/e11/52b00050a01.opus"
    mx "\"А потом ты наконец-то сдашься, так ведь?\""
    voice "voice/e11/52b00060a01.opus"
    mx "\"Ты поймёшь, что у тебя нет выбора, кроме как быть со мной...\""
    xy "\"Ч-что ты—\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ sename = "se物体_バット_取る"
    play se sedict[sename]
    pause (1000/1000)
    "Я услышал резкий металлический звук."
    $ sename = "se人体_動作_バット構える02"
    play se sedict[sename]
    "Она достала... свою бейсбольную биту."
    xy "\"М-может, ты перестанешь уже валять дурака, пожалуйста?\""
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e11/52b00070a01.opus"
    mx "\"Я знаю, ТЫ помнишь.\""
    voice "voice/e11/52b00080a01.opus"
    mx "\"И я знаю, что ТЫ знаешь, что я не шучу.\""
    voice "voice/e11/52b00090a01.opus"
    mx "\"А теперь веди себя хорошо и подчиняйся мне.\""
    hide StC with Dissolve(200.0/1000)
    $ sename = "se物体_バット_振る"
    play se sedict[sename]
    pause (500/1000)
    "Её форма была очаровательно красивой."
    $ sename = "se物体_バット_振る"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白
    pause (30/1000)
    hide 絵色白
    with Dissolve(70.0/1000)
    "Как только она замахнулась своей битой передо мной, я решил—"
    menu:
        "Сопротивляться":
            $ SetChoiceSelect = 0
        "Подчиняться":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        if (persistent.resist1):
            $ GameName = "e1154a.nss";
        else:
            $ GameName = "e1153a.nss";
    elif SetChoiceSelect==1:
        if (persistent.no_resist1):
            $ GameName = "e1154a.nss";
        else:
            $ GameName = "e1153b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
