label a2131_MAIN:
    call expression GameName
    queue bgm "ttb10"
    $ PreGameName = GameName
    $ GameName = "a2132.nss"
    return
label a2131:
    hide 絵色黒
    scene expression Solid("FFFFFF") as 絵色白
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    with Dissolve(1000.0/1000)
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    "После того, как мы закончили есть, мы решили провести остаток обеда на крыше вместе."
    show expression ("cg/bg/l/"+imagename["bg010300_1_学校屋根_l"]+".jpg") as 絵背景 zorder 100 at center
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    hide 絵色白
    with Dissolve(2000.0/1000)
    pause (300/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_smile")
    voice "voice/a21/3100010a01.opus"
    mx "Я наелась."
    xy "Я тоже."
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    voice "voice/a21/3100020a01.opus"
    mx "А теперь давайте начнём делать домашку по англи—"
    voice "voice/a21/3100030a02.opus"
    aoi "Буп-буп... буп-буп-буп..."
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    voice "voice/a21/3100040a01.opus"
    mx "Муко-сан?"
    voice "voice/a21/3100050a02.opus"
    aoi "Батарейка... садится..."
    xy "Ой-ёй. У тебя батарейка села?"
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_pride")
    voice "voice/a21/3100060a01.opus"
    mx "Перестань! Ты не готовилась к домашнему заданию, да?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/3100070a02.opus"
    aoi "...Буп-буп?"
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    voice "voice/a21/3100080a02.opus"
    aoi "Учёба отнимает много заряда батареи."
    voice "voice/a21/3100090a02.opus"
    aoi "Это так тяжело..."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    voice "voice/a21/3100100a01.opus"
    mx "Не смеши— ЭЙ!"
    voice "voice/a21/3100110a02.opus"
    aoi "Буп-буп-буп..."
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_sigh")
    voice "voice/a21/3100120a01.opus"
    mx "Не смей засыпать, дорогуша!"
    xy "Может, тебе стоит попить кофе, чтобы взбодриться?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/3100130a02.opus"
    aoi "От кофе мне хочется писать..."
    "Тебе сколько лет, пять?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    voice "voice/a21/3100140a01.opus"
    mx "Ладно, какие у нас ещё есть варианты?"
    xy "Хм... не знаю..."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_shout")
    voice "voice/a21/3100150a02.opus"
    aoi "Вот."
    "Аой достала что-то из своего кармана."
    xy "Это заколка?"
    voice "voice/a21/3100160a01.opus"
    mx "Она выглядит немного расплавленной..."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/3100170a02.opus"
    aoi "Аой использовала её, чтобы подзарядиться."
    voice "voice/a21/3100180a02.opus"
    aoi "Воткни её в розетку и БЗЫК!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(100.0/1000)
    pause (50/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_pride")
    voice "voice/a21/3100190a01.opus"
    mx "Даже НЕ ВЗДУМАЙ сделать это снова."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/3100200a02.opus"
    aoi "Но это мгновенно заряжает меня, и—"
    xy "Нет, правда. Не вздумай."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/3100210a02.opus"
    aoi "...Буп-буп..."
    pause (800/1000)
    scene expression Solid("000000") as 絵色黒 zorder 5000 with dissolve
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
