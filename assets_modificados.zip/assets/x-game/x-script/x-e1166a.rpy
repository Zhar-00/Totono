label e1166a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1166a:
    hide 絵色黒
    $ renpy.music.play("ttb23_ic",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e11/66a00010b02.opus"

    kmsm "\"НАБРАННЫЙ ВАМИ НОМЕР СЕЙЧАС НАХОДИТСЯ ВНЕ ЗОНЫ ДОСТУПА.\""

    xy "\"Да вы издеваетесь...\""
    if (input_number==99905230523):
        $ GameName = "e1167a.nss";
    else:
        $ GameName = "e1167b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
