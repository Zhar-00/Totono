label e1166b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1166b:
    hide 絵色黒
    $ renpy.music.play("ttb23_ic",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    with Dissolve(0.0/1000)
    $ sename = "se物体_携帯_発信待機L"
    play se sedict[sename]
    pause (1400/1000)
    pause (800/1000)
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]

    "Бог, так или иначе, ответил на мои молитвы."

    "Мои пальцы начали двигаться по своей воле и вводили нужный номер—"
    if (input_number_str == "08091846920"):
        $ GameName = "e1167c.nss";
    else:
        $ GameName = "e1167d.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
