label a7111_MAIN:
    call expression GameName
    $ persistent.imagelog["eve2237a美雪机の上で開脚a"]=True
    $ persistent.imagelog["eva7111美雪制服エプロン"]=True
    $ persistent.imagelog["eva7111美雪制服エプロンb"]=True
    $ persistent.imagelog["eva7111美雪制服エプロンc"]=True
    queue bgm "ttb16"
    $ PreGameName = GameName
    $ GameName = "a7121.nss"
    return
label a7111:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg030100_1_自宅自室"]+".jpg") with None
    show expression Solid("000000") as 絵色黒
    with Dissolve(2000.0/1000)
    pause (1000/1000)
    $ renpy.music.play("ttb27",channel = "bgm", if_changed = True)

    "Жизнь - это не шоссе. Жизнь - это лестница."

    "Ты просто должен продолжать подниматься вверх."

    "Иначе, если ты начнёшь задумываться, тебе будет трудно сделать следующий шаг."

    "Здесь нет никаких альтернативных путей."

    "Нет смысла сожалеть о том, чего ты не сделал."

    "Все говорят, что жизнь - это серия выборов, но это чепуха, придуманная старыми и жестокими людьми."

    "Вчерашний день ведёт к сегодняшнему, а сегодняшний - к завтрашнему."

    "Шаг за шагом."

    "Что ждёт впереди?"
    stop bgm fadeout (300/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    show expression im.AlphaMask("cg/bu/1/"+imagename["bu曙雄太郎_制服_通常_shy"]+".jpg","cg/bu/mask/"+imagename["bu曙雄太郎_制服_通常_shy"]+".jpg") as 絵覆絵演師匠:
        pos (165,120)
    pause (1000/1000)
    with Dissolve((1000.0+1000.0)/1000)
    voice "voice/a71/1100010b01.opus"

    xtl "\"ЭРОТИЗМ!\""
    with Dissolve((300.0+1000.0)/1000)
    hide 絵覆
    pause (600/1000)
    show expression ("cg/ev/"+imagename["eve2237a美雪机の上で開脚a"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/ev/"+imagename["eve2237a美雪机の上で開脚a"]+".jpg") as 絵専上 zorder 1100 at truecenter
    hide 絵色黒
    hide 絵色白
    with Dissolve(500.0/1000)
    pause (1000/1000)

    "А, точно! Эротизм. Спасибо, капитан."

    "...Стоп, что?"

    "Это же нелепица—"
    voice "voice/a71/1100020a01.opus"

    mx "Ты ПРАВДА хочешь увидеть, м-м?"
    voice "voice/a71/1100030a01.opus"

    mx "Понятно... полагаю, вы, парни, всё равно ничего не можете с этим поделать..."

    "А. Теперь я понял."

    "...Чёрт побери, я ведь тоже парень!"
    voice "voice/a71/1100040a01.opus"

    mx "Для тебя я сделаю особое исключение, ладно?"

    "Я почувствовал, как мой здравый смысл начал распадаться..."

    "...и чистые эмоции начали вытекать наружу."
    voice "voice/a71/1100050a01.opus"

    mx "Что за— Шиничи!"
    voice "voice/a71/1100060a01.opus"

    mx "Успокойся!"
    show expression im.AlphaMask("cg/bu/1/"+imagename["bu曙雄太郎_制服_通常_smile"]+".jpg","cg/bu/mask/"+imagename["bu曙雄太郎_制服_通常_smile"]+".jpg") as 絵覆絵演師匠 zorder 4100:
        pos (-155,30)
    with Dissolve(800.0/1000)
    voice "voice/a71/1100070b01.opus"

    xtl "Не забудь быть нежным!"
    hide 絵覆
    with Dissolve(2000.0/1000)

    "Я знаю, капитан!"

    "Я обещал, что больше не буду себе врать."

    "Теперь пришло время взять инициативу на себя, и—"
    voice "voice/a71/1100080a01.opus"

    mx "Перестань, Шиничи! Хватит вести себя как сумасшедший! Проснись уже, чёрт побери!"

    xy "Я не сумасшедший."

    xy "Я люблю тебя, Миюки."
    voice "voice/a71/1100090a01.opus"

    mx "Ах... эм... спасибо..."

    xy "И, конечно же... я люблю и твои трусики тоже..."
    voice "voice/a71/1100100a01.opus"

    mx "Что?!"

    xy "И я люблю всё то, что под ними..."
    voice "voice/a71/1100110a01.opus"

    mx "Т-ты извращенец! Хватит уже!"

    xy "Давай займёмся сексом!.."
    voice "voice/a71/1100120a01.opus"
    mx "\"—?!\""
    voice "voice/a71/1100130a01.opus"

    mx "Д... Д..."
    voice "voice/a71/1100140a01.opus"

    mx "ДЕРЖИ СЕБЯ В РУКАХ!!!"
    stop bgm fadeout (0/1000)
    scene expression Solid("FFFFFF") as 絵色白 with None
    $ sename = "se人体_衝撃_叩くおたま"
    $ renpy.vibrate(.3)
    play se sedict[sename]
    show expression ("cg/ef/"+imagename["efbg自宅自室天井昼消灯"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵専
    show expression ("cg/bg/"+imagename["bg030100_1_自宅自室"]+".jpg")
    hide 絵色白
    with Dissolve(200.0/1000)

    xy "Ай, ай, ай, ай!"

    xy "......А?"

    xy "Это... реальность?.."
    voice "voice/a71/1100150a01.opus"

    mx "А сам как думаешь, гений?!"
    $ sename = "se人体_動作_起き上がる01"
    play se sedict[sename]
    show expression ("cg/ev/l/"+imagename["eva7111美雪制服エプロン_l"]+".jpg") as 絵専 zorder 1100:
        xpos -730
        ypos -576
        linear .5 pos (-290,-90)
    with Dissolve((500.0+1000.0)/1000)
    hide 絵背景
    pause (1000/1000)
    $ renpy.music.play("ttb16",channel = "bgm", if_changed = True)
    voice "voice/a71/1100160a01.opus"

    mx "А теперь давай, вылезай из-под моей юбки! Придурок!"

    xy "А... я спал?.."
    show expression ("cg/ev/l/"+imagename["eva7111美雪制服エプロン_l"]+".jpg") as 絵専 zorder 1100:
        pos (-290,-90)
    with Dissolve(300.0/1000)
    voice "voice/a71/1100170a01.opus"

    mx "Ты сказал, что любишь мои трусики!"

    xy "Прости..."
    show expression ("cg/ev/"+imagename["eva7111美雪制服エプロンb"]+".jpg") as 絵専下 zorder 1000 at truecenter
    hide 絵専
    with Dissolve(800.0/1000)

    "Я проклинаю своё подсознание."

    "Из всех тех вещей, которые я хотел бы сказать ей в лицо, этого в списке ЯВНО нет!"

    "Мне сейчас было так стыдно, но и впечатляло не меньше!"

    "Я не удивлён, что это было настолько реалистично..."

    "Что ж, теперь, когда я проснулся—"
    show expression ("cg/ev/"+imagename["eva7111美雪制服エプロンc"]+".jpg") as 絵専下 zorder 1000 at truecenter
    with Dissolve(200.0/1000)
    voice "voice/a71/1100180a01.opus"

    mx "Ч-что за?! Почему твой... твой пионер стоит на посту?!"

    xy "А? ОЙ."

    "Похоже, моя промежность... была полна мужских амбиций..."

    "О боже, теперь я разговариваю как Ютаро!"

    "Это всё ЕГО вина... Да, пусть будет так..."
    show expression ("cg/ev/"+imagename["eva7111美雪制服エプロンb"]+".jpg") as 絵専下 zorder 1000 at truecenter
    with Dissolve(200.0/1000)
    voice "voice/a71/1100190a01.opus"

    mx "Это то, что мысли обо мне делают с тобой?!"

    xy "Н-нет, ты всё не так поняла! Утренний стояк является нормой у всех парней, только и всего!"

    xy "У меня не было таких фантазий о тебе!"
    show expression ("cg/ev/"+imagename["eva7111美雪制服エプロンc"]+".jpg") as 絵専下 zorder 1000 at truecenter
    with Dissolve(200.0/1000)
    voice "voice/a71/1100200a01.opus"

    mx "У т-тебя их не было?"

    "Она выглядела смущённой, но сказала это немного разочарованным тоном..."

    xy "Ну, в смысле... эм... они не СОВСЕМ связаны..."
    voice "voice/a71/1100210a01.opus"

    mx "Я... я не хочу, чтобы ты подумал, что я не польщена, конечно же! Потому что я правда польщена! Я признаю это!"
    voice "voice/a71/1100220a01.opus"

    mx "Но для подобных вещей есть свои время и место! Мне ещё нужно время, чтобы морально подготовиться к этому..."

    xy "Ты абсолютно права."
    show expression ("cg/ev/"+imagename["eva7111美雪制服エプロンb"]+".jpg") as 絵専下 zorder 1000 at truecenter
    with Dissolve(200.0/1000)
    voice "voice/a71/1100230a01.opus"

    mx "И в наказание, сегодня у тебя не будет никакого завтрака."

    xy "Мне очень, очень жаль! Пожалуйста, простите меня, госпожа!"
    voice "voice/a71/1100240a01.opus"

    mx "Хо-хо? Ты ПРАВДА хочешь отведать моей стряпни, м-м?"

    xy "Я сделаю всё что угодно!"

    "Не каждый день выдаётся возможность начать свой день с какой-нибудь вкусной домашней стряпни Миюки..."

    "Я даже готов упасть вниз лицом, если придётся!"
    show expression ("cg/ev/"+imagename["eva7111美雪制服エプロン"]+".jpg") as 絵専下 zorder 1000 at truecenter
    with Dissolve(200.0/1000)
    voice "voice/a71/1100250a01.opus"

    mx "Ну, раз ты так сильно её хочешь, думаю, я могу пересмотреть своё решение."

    xy "Правда?!"
    voice "voice/a71/1100260a01.opus"

    mx "Но при одном условии."

    xy "При каком?"
    voice "voice/a71/1100270a01.opus"

    mx "Ну, в общем..."
    show expression ("cg/ev/"+imagename["eva7111美雪制服エプロンb"]+".jpg") as 絵専下 zorder 1000 at truecenter
    with Dissolve(200.0/1000)
    voice "voice/a71/1100280a01.opus"
    mx "......"

    xy "...Да?.."
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    voice "voice/a71/1100290a01.opus"

    mx "......Поцелуй меня."
    show expression ("cg/ev/"+imagename["eva7111美雪制服エプロンc"]+".jpg") as 絵専下 zorder 1000 at truecenter
    with Dissolve(200.0/1000)
    voice "voice/a71/1100300a01.opus"

    mx "Я хочу утренний поцелуй!"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
