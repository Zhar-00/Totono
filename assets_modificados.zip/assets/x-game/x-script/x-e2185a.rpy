label e2185a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2185a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_sigh")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/85a00010a01.opus"
    mx "\"Раз ты настаиваешь на том, что так сильно ненавидишь настоящих девушек...\""
    voice "voice/e21/85a00020a01.opus"
    mx "\"...то мне придётся реабилитировать тебя.\""
    xy "\"Как реабилитировать?..\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/85a00030a01.opus"
    mx "\"Я воплощу твои самые смелые мечты в реальность!\""
    xy "\"П-правда?..\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/85a00040a01.opus"
    mx "\"Конечно.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ St("C",350,0,0,"fu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/85a00050a01.opus"
    mx "\"Я дам тебе всё, что захочешь, и даже больше.\""
    voice "voice/e21/85a00060a01.opus"
    mx "\"Просто подожди, и ты сам всё увидишь...\""
    "Либо воображение так играло со мной, либо... я почувствовал, как за её улыбкой прячется что-то зловещее?.."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    $ temp_miyuki_sex_promise2 = True;
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
