label a3125a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a3125.nss"
    return
label a3125a:
    scene expression ("cg/bg/"+imagename["bg010300_2_学校屋根"]+".jpg") with dissolve
    pause (1000/1000)
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    xy "Стоп... на твоём телефоне проигрывается какое-то странное видео..."
    xy "Эй, Аой!"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a31/25a00010a02.opus"
    aoi "Буп-буп... Шиничи?"
    xy "Ты опять выронила свой телефон!"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/25a00020a02.opus"
    aoi "Ох..."
    xy "Если ты не хочешь рисковать потерять его, ты должна крепко держать его!"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
