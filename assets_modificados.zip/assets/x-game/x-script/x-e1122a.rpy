label e1122a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1122a.nss";
    return
label e1122a:
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    if (PreGameName=="e1122a"):
        $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    else:
        $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")

    xy "\"Конечно могу.\""

    xy "\"Я буду всегда любить тебя.\""
    if not persistent.love_roop_accept_count:
        $ persistent.love_roop_accept_count = 0
    $ persistent.love_roop_accept_count += 1
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e11/22a00010a01.opus"

    mx "\"Спасибо... Это многое значит...\""
    voice "voice/e11/22a00020a01.opus"

    mx "\"Можешь сказать это ещё раз?\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
