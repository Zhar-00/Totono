label a5164a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5165.nss"
    return
label a5164a:
    hide 絵色黒
    $ renpy.music.play("ttb07",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    show expression ("cg/ev/"+imagename["eva5163アオイ汗拭き"]+".jpg") as 絵専 at truecenter
    with Dissolve(0.0/1000)
    "Твой «бог» ненастоящий, Аой."
    "Вся эта неразбериха с батареями и передатчиками? Это просто твоя выдуманная фантазия."
    "Видеоигры – не то же самое, что и реальная жизнь."
    "Ты просто заблуждаешься."
    "...Если бы только я мог сказать ей это всё."
    show expression ("cg/ev/l/"+imagename["eva5163アオイ汗拭き_l"]+".jpg") as 絵専弐:
        pos (-490,-185)
    $ sename = "se人体_動作_衣擦れ02"
    play se sedict[sename]
    with Dissolve((500.0+1000.0)/1000)
    voice "voice/a51/64a00010a02.opus"
    aoi "Шиничи..."
    "Слёзы скатывались по её щекам, от чего я застыл на месте."
    "Я мог почувствовать её тепло своей кожей."
    "Взгляд в её глазах пронизывал меня до глубины души."
    "Я не мог заставить себя отстраниться."
    xy "Аой..."
    "Я наклонился поближе—"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
