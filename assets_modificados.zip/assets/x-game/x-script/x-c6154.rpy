label c6154_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if cat_wave == False:
        $ GameName = "d6161.nss"
    else:
        $ GameName = "c6161.nss"
    return
label c6154:
    hide 絵色黒
    $ sename = "se環境_ガヤ_教室ざわめくL"
    play se sedict[sename]
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010801_2_学校体育館演劇準備"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    $ sename = "se物体_携帯_着信音切れる"
    play se sedict[sename]
    pause (300/1000)

    "Спустя несколько гудков, я завершил вызов."
    xy "\"Ей очень нездоровилось, когда я видел её в последний раз, так что она, скорее всего— Миюки?\""
    voice "voice/c61/5400010a01.opus"
    mx "\"Я так и знала. Они вместе.\""

    "Я заметил, что Миюки она также не ответила."
    voice "voice/c61/5400020a01.opus"
    mx "\"Поняла. Ладно. Я пойду туда сейчас же.\""
    $ sename = "se物体_携帯_着信音切れる"
    play se sedict[sename]
    pause (300/1000)
    xy "\"Уже закончила свой звонок?\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c61/5400030a01.opus"
    mx "\"Похоже, Аой не взяла трубку, м-м?\""
    xy "\"Скорее всего, она просто уснула.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c61/5400040a01.opus"
    mx "\"А что, если она с кем-то встречается?\""
    voice "voice/c61/5400050a01.opus"
    mx "\"Что, если она таким образом отказалась от свидания с тобой, чтобы пойти на него с кем-то другим?\""
    xy "\"...О чём ты говоришь?\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c61/5400060a01.opus"
    mx "\"Пошли со мной.\""
    $ sename = "se人体_足音_歩く体育館"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Не сказав более ни слова, Миюки пошла к выходу."

    xy "\"Стой! А как же игра?\""
    stop se fadeout (150.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c61/5400070a01.opus"
    mx "\"Я же сказала тебе, я отказалась от главной роли.\""
    xy "\"Но ты не поленилась достать для меня эти билеты—\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c61/5400080a01.opus"
    mx "\"Я знаю тебя лучше кого-либо.\""
    voice "voice/c61/5400090a01.opus"
    mx "\"Я знаю, какой ты добрый и смелый... и что самое главное...\""
    $ St("C",300,0,0,"st曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c61/5400100a01.opus"
    mx "\"Я знаю твою ревнивую сторону.\""

    "Мою... ревнивую сторону?.."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c61/5400110a01.opus"
    mx "\"Ты должен посмотреть правде в глаза.\""
    voice "voice/c61/5400120a01.opus"
    mx "\"А теперь пошли со мной.\""
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1100/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
