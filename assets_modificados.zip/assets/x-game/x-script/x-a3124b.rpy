label a3124b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if persistent.world_recreate == True:
        $ GameName = "e2324h.nss"
    else:
        $ persistent.root_recreate = True
        $ temp_root_recreate = True
        $ GameName = "a3125a.nss"
    return
label a3124b:
    $ renpy.music.play("tts_in",channel = "bgm", if_changed = True)
    hide 絵色黒
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    show expression ("cg/ev/l/"+imagename["eva0113アオイ送信中b_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    "Я попытался зашевелиться, но вдруг застыл на месте."
    "Что со мной происходит?"
    "Я..."
    "Я правда верю в Бога Аой?.."
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]
    pause (5000/1000)
    stop bgm fadeout (300/1000)
    "Раздался звонок..."
    "...и Бог взял трубку."
    voice "voice/a31/24b00010a02.opus"
    aoi "Мой сигнал прошёл."
    xy "Что—?!"



    "В ткани пространства возник разрыв..."
    "Он появился из ниоткуда..."
    "...и начал увеличиваться..."
    "Тени исчезают..."
    "Цвета тускнеют..."
    "Наброски искажаются..."
    "Линии пропадают..."
    "Весь мир..."
    "...начал глючить!.."


    scene expression "cg/bg/f812dc0f1592bf34afdb053b73e7fd4d5b0fa1cb.jpg"
    with ImageDissolve("cg/data/zzex_mosaic_01_00_1.png", 1)
    $ St("C",300,0,0,"bu向日アオイ電波_制服_見上げ_think")




    voice "voice/a31/24b00020a02.opus"
    aoi "Скрипт игры был переписан так, чтобы ты и Миюки могли быть вместе."
    voice "voice/a31/24b00030a02.opus"
    aoi "И теперь тебя никогда, никогда не бросят."
    voice "voice/a31/24b00040a02.opus"
    aoi "Далее пропатченная игра будет синхронизирована со вселенной."
    voice "voice/a31/24b00050a02.opus"
    aoi "После этого обновление будет завершено."
    xy "Завязывай уже с этой бессмыслицей..."



    $ St("C",300,0,0,"bu向日アオイヘアピン_制服_通常_normal")

    voice "voice/a31/24b00060a02.opus"
    aoi "Но это правда."

    scene expression Solid("FFFFFF") as 絵色白
    with ImageDissolve("cg/data/zzex_mosaic_01_00_1.png", 1)
    $ St("C",300,0,0,"bu向日アオイヘアピン_制服_通常_normal")

    voice "voice/a31/24b00070a02.opus"
    aoi "Этот мир – видеоигра."


    hide StC
    with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png", 1)

    show expression ("cg/bg/"+imagename["bg010300_2_学校屋根"]+".jpg")
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with ImageDissolve("cg/data/zzex_mosaic_01_00_1.png", 1)
    hide 上背景
    pause (400/1000)
    hide 絵色白
    with Dissolve(1600.0/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
