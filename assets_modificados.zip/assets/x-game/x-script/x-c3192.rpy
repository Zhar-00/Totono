label c3192_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c3201.nss"
    return
label c3192:
    hide 絵色黒
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010402_3_学校校門閉"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010402_3_学校校門閉_l"]+".jpg") as 絵背景 zorder 100:
        pos (-160,-410)
    with Dissolve(2000.0/1000)
    pause (300/1000)
    xy "\"Ладно, теперь залезай мне на плечи, и—\""
    voice "voice/c31/9200010a02.opus"
    aoi "\"Буп-буп?.. Они закрыты?\""
    xy "\"Разумеется, они закрыты. Сейчас ночь.\""
    voice "voice/c31/9200020a02.opus"
    aoi "\"Но Аой открывала их раньше.\""
    xy "\"Что? Ты их никоим образом не можешь открыть—\""
    $ sename = "se人体_動作_ピッキング"
    play se sedict[sename]
    pause (200/1000)
    show expression ("cg/bg/"+imagename["bg010401_3_学校校門閉通用口開"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010401_3_学校校門閉通用口開_l"]+".jpg") as 絵背景 zorder 100:
        pos (-160,-410)
    $ sename = "se物体_ドア鉄_開く01"
    play se sedict[sename]
    pause (1400/1000)
    with Dissolve(500.0/1000)
    pause (500/1000)
    voice "voice/c31/9200030a02.opus"
    aoi "\"Вот.\""
    xy "\"...Что?\""
    "Как и следовало ожидать, замок вдруг вскрылся."
    voice "voice/c31/9200040a02.opus"
    aoi "\"Эта штучка мне очень пригодилась.\""
    "Она держала в руке кошачью заколку, которую я подарил ей."
    "Когда она сказала мне, что будет носить её с собой в кармане ради безопасности, я и подумать не мог, что она использует её для чего-то вроде ЭТОГО!"
    xy "\"Получается, ты так же вскрыла и дверь прохода на крышу?\""
    voice "voice/c31/9200050a02.opus"
    aoi "\"Ага.\""
    "Её детская невинность и правда делала это довольно пугающим."
    stop bgm fadeout (500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
