label e2222c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2223.nss"
    return
label e2222c:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(0.0/1000)

    xy "\"Такое чувство, будто я проснусь и всё исчезнет—\""
    $ St("C",300,0,0,"bu曽根美雪_私服_病み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/22c00010a01.opus"

    mx "\"Это не произойдёт.\""

    "Губы Миюки скривились в злой ухмылке."
    voice "voice/e22/22c00020a01.opus"

    mx "\"Это не сон. Это реальность, нравится тебе это или нет.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
