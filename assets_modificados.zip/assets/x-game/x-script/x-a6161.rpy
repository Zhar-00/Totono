label a6161_MAIN:
    call expression GameName
    $ persistent.imagelog["bg020100_1_自宅外正面"]=True
    $ persistent.imagelog["bg030400_1_自宅廊下"]=True
    $ persistent.imagelog["bg040200_1_街川縁"]=True
    $ persistent.imagelog["bg040300_1_街商店街"]=True
    $ PreGameName = GameName
    $ GameName = "a6171.nss"
    return
label a6161:
    hide 絵色黒
    $ sename = "se物体_時計_秒針L"
    play se sedict[sename]
    pause (500/1000)
    scene expression ("cg/bg/"+imagename["bg030300_1_自宅リビング"]+".jpg")
    scene expression ("cg/bg/l/"+imagename["bg030300_1_自宅リビング_l"]+".jpg") as 絵背景 at truecenter
    with Dissolve(1000.0/1000)
    pause (500/1000)
    "Я пытался поиграть в видеоигры, но не мог сосредоточиться."
    "Я пытался посмотреть телевизор, но его звуки терзали мои уши."
    "Я лёг на диван в гостиной."
    "Я мог расслышать тиканье часов."
    "Время шло, секунда за секундой."
    "Было бы намного проще, если бы я мог просто потерять сознание."
    "Но сон упорно избегал меня."
    "Я чувствовал только то, как во мне накапливалась злость."
    $ sename = "se人体_動作_立ち上がる"
    play se sedict[sename]
    pause (500/1000)
    "Чем дольше я лежал здесь, ничего не делая, тем больше у меня складывалось такое чувство, будто я скоро сойду с ума."
    "Я схватил свой телефон и встал на ноги."
    show expression ("cg/bg/"+imagename["bg030400_1_自宅廊下"]+".jpg")
    $ sename = "se物体_ドア室内_開く01"
    play se sedict[sename]
    pause (1200/1000)
    with Dissolve(300.0/1000)
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    "А потом подошёл к двери, и—"
    show expression ("cg/bg/"+imagename["bg030200_1_自宅玄関"]+".jpg")
    stop se fadeout (300.0/1000)
    with Dissolve(300.0/1000)
    xy "......"
    "Я остановился на месте прежде, чем успел выйти из дома."
    "Билет всё ещё лежал на журнальном столике, где я его и оставил."
    "Осталось всего два часа до начала шоу."

    show expression Solid("000000") as 絵色黒 zorder 5000
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]
    with Dissolve((300.0+1000.0)/1000)
    "Я решил не возвращаться и не брать его."
    "Вместо этого я отправился в город."
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg020100_1_自宅外正面"]+".jpg")
    pause (500/1000)
    hide 絵背景
    hide 絵色黒
    with Dissolve(500.0/1000)
    pause (500/1000)
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]
    pause (3000/1000)
    $ sename = "se物体_携帯_繋がる"
    play se sedict[sename]
    xy "Эй, Ютаро? Ты не занят?"
    xy "Не хочешь прогуляться?"
    voice "voice/a61/6100010b01.opus"
    xtl "Мне надо работать сегодня вечером. Я отрабатываю смену Рюджиро."
    voice "voice/a61/6100020b01.opus"
    xtl "Прости!"
    xy "Да не, всё нормально. Я просто так спросил."
    voice "voice/a61/6100030b01.opus"
    xtl "Стоп... Разве выступление Сонэ-сан не—"
    xy "Ладно, поговорим позже!"
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    pause (1000/1000)
    xy "...Чёрт."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1200.0+1000.0)/1000)
    "Ютаро не был виноват в этом."
    "Я знаю это."
    "Я бездумно блуждал по улицам."
    "Но куда бы я не пошёл..."
    scene expression ("cg/bg/"+imagename["bg040100_1_街通学路"]+".jpg")
    $ sename = "se人体_足音_歩く01L"
    play se sedict[sename]
    with Dissolve((1000.0+0.0)/1000)
    pause (1000/1000)
    with Dissolve((1000.0+1000.0)/1000)
    "Каждая улица..."
    scene expression ("cg/bg/"+imagename["bg010400_1_学校校門"]+".jpg")
    with Dissolve((1000.0+0.0)/1000)
    pause (1000/1000)
    with Dissolve((1000.0+1000.0)/1000)
    "Каждый уголок..."
    scene expression ("cg/bg/"+imagename["bg040300_1_街商店街"]+".jpg")
    with Dissolve((1000.0+0.0)/1000)
    pause (1000/1000)
    with Dissolve((1000.0+1000.0)/1000)
    "Каждый магазин..."
    scene expression ("cg/bg/"+imagename["bg040200_1_街川縁"]+".jpg")
    with Dissolve((1000.0+0.0)/1000)
    pause (1000/1000)
    with Dissolve((1000.0+1000.0)/1000)
    stop se fadeout (5000.0/1000)
    pause (1000/1000)
    "Всё это было омрачено моими воспоминаниями о Миюки и Аой."
    "Я не мог выкинуть их из головы."
    "Тем временем, моё негодование только росло."
    "Мне нужно выпустить пар... но как?.."
    stop se fadeout (3000.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
