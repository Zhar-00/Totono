label c4202_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label c4202:
    hide 絵色黒
    $ renpy.music.play("ttb12",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15 at truecenter
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_ero")
    with Dissolve(0.0/1000)
    stop bgm fadeout (500.0/1000)
    pause (500/1000)
    play voc "c42/0200010b04"

    xy "\"—А?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/c42/0200020a01.opus"

    mx "\"...В чём дело?\""

    xy "\"Я что-то слышал...\""

    "До боли знакомое мяуканье."

    "Я тут же обернулся в направлении звука."
    show expression ("cg/bg/"+imagename["bg060100_3_バッティングセンター店内"]+".jpg")
    hide 絵背景
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    play voc "c42/0200030b04"

    xy "\"Иру!\""

    "Как и следовало ожидать, это был котёнок Аой, он мяукал под скамейкой."

    "Как ты добрался досюда от моего дома, маленький комок шерсти?"
    play voc "c42/0200040b04"

    xy "\"Ты хочешь, чтобы я пошёл за тобой или что-то ещё?\""
    play voc "c42/0200050b04"

    "Аой называла Иру \"котом-передатчиком\"."

    "Хотя, возможно, это было одним из её заблуждений."

    "Но этот котёнок каким-то образом смог выбраться из моего дома и прошёл весь этот путь, чтобы найти меня."

    xy "\"Иру...\""
    voice "voice/c42/0200060a01.opus"
    mx "\"Шиничи!\""
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15 at truecenter
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(500.0/1000)

    "И прежде, чем я успел подойти к нему, Миюки позвала меня."

    "Её голос дрожал... а руки - были сжаты в кулаки."
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_fear")
    with Dissolve(200.0/1000)
    voice "voice/c42/0200070a01.opus"

    mx "\"...Ты уходишь?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c42/0200080a01.opus"

    mx "\"Прямо в середине нашего... разговора?\""
    return
    return
label c4202_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15 at truecenter
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(0.0/1000)
    menu:
        "Остаться с Миюки":
            $ SetChoiceSelect = 0
        "Идти за Иру":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "d4203.nss";
    elif SetChoiceSelect==1:
        $ GameName = "c4203.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
