label a2194_MAIN:
    call expression GameName
    $ persistent.imagelog["eva2194アオイヘアピン"]=True
    $ persistent.imagelog["bg040300_3_街商店街"]=True
    $ PreGameName = GameName
    $ GameName = "a2201.nss"
    return
label a2194:
    hide 絵色黒
    $ renpy.music.play("ttb08",channel = "bgm", if_changed = True)
    scene expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    hide 上背景
    hide 絵色黒
    with Dissolve(800.0/1000)
    voice "voice/a21/9400010a02.opus"
    aoi "Шиничи!"
    xy "Хм?"
    show expression Solid("FFFFFF") as 絵色白 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/ev/"+imagename["eva2194アオイヘアピン"]+".jpg") as 絵専 zorder 1000 at center
    show expression ("cg/ev/l/"+imagename["eva2194アオイヘアピン_l"]+".jpg") as 絵専弐 zorder 1100:
        pos (-800,-130)
        linear 20 xpos 0
    hide 絵色白
    with Dissolve(2000.0/1000)
    pause (2000/1000)
    hide 絵専弐
    with Dissolve(800.0/1000)
    voice "voice/a21/9400020a02.opus"
    aoi "Что думаешь?.."
    xy "......"
    voice "voice/a21/9400030a02.opus"
    aoi "Буп-буп?.."
    xy "......"
    voice "voice/a21/9400040a02.opus"
    aoi "Шиничи?"
    xy "А-а, эм, да, выглядит прекрасно! Абсолютно!"
    voice "voice/a21/9400050a02.opus"
    aoi "Ты такой милый... Спасибо."
    "Улыбка Аой была невероятно очаровательной..."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shock")
    with Dissolve(0.0/1000)
    hide 絵専
    with Dissolve(1000.0/1000)
    pause (300/1000)
    "Я тут же отвёл свой взгляд и начал искать подкрепление."
    xy "Так ведь, Миюки?"
    voice "voice/a21/9400060a01.opus"
    mx "......"
    xy "Миюки!"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/a21/9400070a01.opus"
    mx "Д-да... А какой был вопрос?"
    "Аой тебя тоже очаровала, я так и понял."
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg040300_3_街商店街"]+".jpg")
    pause (2000/1000)
    hide 絵色黒
    with Dissolve(2000.0/1000)
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    pause (500/1000)
    xy "Ну да ладно, на улице уже начинает смеркаться."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a21/9400080a01.opus"
    mx "Да... Нам лучше разойтись по домам."
    voice "voice/a21/9400090a02.opus"
    aoi "Тогда до скорого."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_sad")
    voice "voice/a21/9400100a01.opus"
    mx "А, точно."
    "Если подумать, манга-кафе было совсем рядом."
    xy "Стоп, а почему ты сняла свою заколку?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/a21/9400110a02.opus"
    aoi "Я приберегу её для особенных моментов."
    xy "Особенных в каком плане?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_smile")
    voice "voice/a21/9400120a02.opus"
    aoi "Для моментов, которые многое для меня значат."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_happy")
    voice "voice/a21/9400130a02.opus"
    aoi "Ну а пока, она полежит в моём кармане для сохранности."
    "Я был очень польщён тем, что она захотела так хорошо заботиться о моём подарке."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a21/9400140a02.opus"
    aoi "Пока-пока."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a21/9400150a01.opus"
    mx "Спасибо за сегодня."
    xy "Увидимся завтра!"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    voice "voice/a21/9400160a02.opus"
    aoi "Поняла!"
    xy "В чём дело?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_挙手_smile")
    voice "voice/a21/9400170a02.opus"
    aoi "Это твой отличный шанс признаться в любви."
    show expression ("cg/bg/m/"+imagename["bg040300_3_街商店街_m"]+".jpg") as 絵背景 zorder 1010:
        pos (-512,-258)
    $ St("X",1300,0,0,"bu曽根美雪_制服_通常_angry")
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_angry")
    with Dissolve(150.0/1000)
    voice "voice/a21/9400180a01.opus"
    mx "......?!"
    hide StX
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    hide StML with Dissolve(0.0/1000)
    "Она застала нас обоих врасплох."
    xy "Аой! Перестань дурачиться—{nw=1}"
    hide 絵背景
    with Dissolve(500.0/1000)
    xy "—Стоп, что за? Куда она делась?"
    hide 絵板写
    show expression ("cg/bg/m/"+imagename["bg040300_3_街商店街_m"]+".jpg") as 絵背景 zorder 1000:
        pos (-256,-144)
        linear 9 xpos 0
    with Dissolve((500.0+1000.0)/1000)
    hide StMR with Dissolve(0.0/1000)
    "Я оглянулся вокруг, но она как будто испарилась."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(0.0/1000)
    hide 絵背景
    with Dissolve(500.0/1000)
    xy "Ха-а... Ну и чудачка..."
    voice "voice/a21/9400190a01.opus"
    mx "......"
    xy "Миюки?"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/a21/9400200a01.opus"
    mx "А? А-а, точно. Извини, что?"
    "Судя по всему, Миюки меня не слушала."
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1500.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
