label e1167a_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010610_9_学校教室扉前"]=True
    $ BackFile = "e1167a.nss";
    $ PreGameName = GameName
    $ GameName = "e1168.nss"
    return
label e1167a:
    hide 絵色黒
    $ renpy.music.play("ttb23_ic",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    with Dissolve(0.0/1000)

    "Я был уверен, что ввожу правильный номер..."

    "...но мой звонок не доходил."

    "Аой не возвращалась."

    "И всё же—"
    stop bgm fadeout (150.0/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    xy "\"Почему?..\""
    show expression ("cg/bg/"+imagename["bg010610_9_学校教室扉前"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(1000.0/1000)
    pause (1500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
