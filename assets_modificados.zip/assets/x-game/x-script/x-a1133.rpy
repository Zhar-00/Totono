label a1133_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a1141.nss"
    return
label a1133:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    with Dissolve((0.0)/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演美雪背景 zorder 50 at center:
        xpos (512+150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st曽根美雪_制服_腕組み_normal"]+".jpg","cg/st/mask/"+imagename["st曽根美雪_制服_腕組み_normal"]+".jpg") as 絵演美雪立絵 zorder 100 at center:
        xpos (512-150)
    with Dissolve((0.0+1000.0)/1000)
    show expression im.AlphaMask("cg/st/1/"+imagename["st曽根美雪_制服_通常_pride"]+".jpg","cg/st/mask/"+imagename["st曽根美雪_制服_通常_pride"]+".jpg") as 絵演美雪立絵 zorder 100 at center:
        xpos (512-150)
    voice "voice/a11/3300010a01.opus"
    mx "Я отказываюсь."
    show expression im.AlphaMask("cg/st/1/"+imagename["st曽根美雪_制服_通常_normal"]+".jpg","cg/st/mask/"+imagename["st曽根美雪_制服_通常_normal"]+".jpg") as 絵演美雪立絵 zorder 100 at center:
        xpos (512-150)
    with Dissolve(200.0/1000)
    voice "voice/a11/3300020a01.opus"
    mx "Мне кажется, ты и я в корне несовместимы."
    "Это было похоже на жёсткое «нет»."
    "Но всё же она права. Я не могу представить себе, как они обе хорошо ладят."
    pause (16/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演葵背景 zorder 1050 at center:
        xpos (512-150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st向日アオイ電波_制服_電話_other"]+".jpg","cg/st/mask/"+imagename["st向日アオイ電波_制服_電話_other"]+".jpg") as 絵演葵立絵 zorder 1100 at center:
        xpos (512+150)
    with Dissolve(200.0/1000)
    voice "voice/a11/3300030a02.opus"
    aoi "Поняла! План Б."
    "Муко подняла свой телефон ввысь."
    $ sename = "se物体_携帯_写真撮るスマフォ"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白 zorder 9900
    pause (30/1000)
    hide 絵色白
    with Dissolve(200.0/1000)
    xy "Какого?.."
    voice "voice/a11/3300040a01.opus"
    mx "Ты что только что сделала?"
    pause (16/1000)
    show expression im.AlphaMask("cg/st/1/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg","cg/st/mask/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg") as 絵演葵立絵 zorder 1100 at center:
        xpos (512+150)
    with Dissolve(200.0/1000)
    voice "voice/a11/3300050a02.opus"
    aoi "Фото-миссия."
    voice "voice/a11/3300060a02.opus"
    aoi "Я отправлю эту фотографию всему классу."
    xy "...Ты шантажируешь нас?"
    pause (16/1000)
    show expression im.AlphaMask("cg/st/1/"+imagename["st向日アオイ電波_制服_通常_think"]+".jpg","cg/st/mask/"+imagename["st向日アオイ電波_制服_通常_think"]+".jpg") as 絵演葵立絵 zorder 1100 at center:
        xpos (512+150)
    with Dissolve(200.0/1000)
    voice "voice/a11/3300070a02.opus"
    aoi "Буп-буп?"
    pause (16/1000)
    show expression im.AlphaMask("cg/st/1/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg","cg/st/mask/"+imagename["st向日アオイ電波_制服_通常_normal"]+".jpg") as 絵演葵立絵 zorder 1100 at center:
        xpos (512+150)
    with Dissolve(200.0/1000)
    voice "voice/a11/3300080a02.opus"
    aoi "Это плохо?"
    "Выражение её лица было абсолютно невинным."
    xy "Давай, Миюки, объясни ей—"
    pause (16/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演美雪背景 zorder 9950 at center:
        xpos (512+150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st曽根美雪_制服_通常_pride"]+".jpg","cg/st/mask/"+imagename["st曽根美雪_制服_通常_pride"]+".jpg") as 絵演美雪立絵 zorder 10000 at center:
        xpos (512-150)
    with Dissolve((0.0+1000.0)/1000)
    with Dissolve(200.0/1000)
    voice "voice/a11/3300090a01.opus"
    mx "Флаг тебе в руки, Муко-сан."
    xy "...Ты серьёзно?"
    voice "voice/a11/3300100a01.opus"
    mx "В смысле, это правда, что мы с Шиничи встречаемся здесь вместе."
    pause (16/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演美雪背景 zorder 9950 at center:
        xpos (512+150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st曽根美雪_制服_通常_normal"]+".jpg","cg/st/mask/"+imagename["st曽根美雪_制服_通常_normal"]+".jpg") as 絵演美雪立絵 zorder 10000 at center:
        xpos (512-150)
    with Dissolve((0.0+1000.0)/1000)
    with Dissolve(200.0/1000)
    voice "voice/a11/3300110a01.opus"
    mx "Возможно, некоторые люди поймут это неправильно, но я смогу им всё объяснить без проблем."
    pause (16/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演美雪背景 zorder 9950 at center:
        xpos (512+150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st曽根美雪_制服_通常_hard"]+".jpg","cg/st/mask/"+imagename["st曽根美雪_制服_通常_hard"]+".jpg") as 絵演美雪立絵 zorder 10000 at center:
        xpos (512-150)
    with Dissolve((0.0+1000.0)/1000)
    with Dissolve(200.0/1000)
    voice "voice/a11/3300120a01.opus"
    mx "Раз уж на то пошло, дружить с таким человеком, как ТЫ, было бы куда более неловко."
    voice "voice/a11/3300130a01.opus"
    mx "Знаешь, что? Позволь мне объяснить тебе две вещи."
    voice "voice/a11/3300140a01.opus"
    mx "Первое..."
    pause (16/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演美雪背景 zorder 9950 at center:
        xpos (512+150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st曽根美雪_制服_通常_pride"]+".jpg","cg/st/mask/"+imagename["st曽根美雪_制服_通常_pride"]+".jpg") as 絵演美雪立絵 zorder 10000 at center:
        xpos (512-150)
    with Dissolve((0.0+1000.0)/1000)
    with Dissolve(200.0/1000)
    voice "voice/a11/3300150a01.opus"
    mx "Ты можешь пробовать всё, что захочешь, но пока ты не сделаешь серьёзные изменения, у тебя никогда не будет шанса завести друзей."
    pause (16/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演美雪背景 zorder 9950 at center:
        xpos (512+150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st曽根美雪_制服_通常_normal"]+".jpg","cg/st/mask/"+imagename["st曽根美雪_制服_通常_normal"]+".jpg") as 絵演美雪立絵 zorder 10000 at center:
        xpos (512-150)
    with Dissolve((0.0+1000.0)/1000)
    with Dissolve(200.0/1000)
    voice "voice/a11/3300160a01.opus"
    mx "Второе..."
    pause (16/1000)
    show expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵演美雪背景 zorder 9950 at center:
        xpos (512+150)
    show expression im.AlphaMask("cg/st/1/"+imagename["st曽根美雪_制服_通常_normal"]+".jpg","cg/st/mask/"+imagename["st曽根美雪_制服_通常_normal"]+".jpg") as 絵演美雪立絵 zorder 10000 at center:
        xpos (512-150)
    with Dissolve((0.0+1000.0)/1000)
    with Dissolve(200.0/1000)
    voice "voice/a11/3300170a01.opus"
    mx "Не называй меня Миюки."
    voice "voice/a11/3300180a01.opus"
    mx "Это всё."
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    hide 絵演美雪立絵
    with Dissolve(200.0/1000)
    pause (2000/1000)
    $ sename = "se物体_ドア鉄_閉まる01"
    play se sedict[sename]
    pause (300/1000)
    "После этого Миюки ушла к двери и спустилась вниз по лестнице."
    "Между тем, я чувствовал себя разомкнутым. Я знаю, что она кричала не на меня, но всё же."
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    with Dissolve((0.0)/1000)
    scene expression ("cg/bg/m/"+imagename["bg010200_1_学校屋上_m"]+".jpg") as 絵葵背景 at center:
        xpos (512-150)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(0.0/1000)
    voice "voice/a11/3300190a02.opus"
    aoi "Она такая классная."
    xy "Ты, эм... правда шагаешь под бой своих барабанов, да?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300200a02.opus"
    aoi "Буп-буп?"
    "Муко наклонила голову."
    "Она выглядела озадаченной; для неё это было обычным явлением."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300210a02.opus"
    aoi "Пока-пока."
    xy "Ты куда это?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300220a02.opus"
    aoi "В класс."
    "Она серьёзно собирается показать всем ту фотографию?.."
    xy "Миюки разозлится ведь, знаешь ли."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300230a02.opus"
    aoi "Почему?"
    voice "voice/a11/3300240a02.opus"
    aoi "Она разрешила."
    xy "Ха-а..."
    "Она серьёзно ничего не понимает, да?"
    xy "Почему ты вообще пытаешься свести меня и Миюки вместе?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300250a02.opus"
    aoi "Протагонист должен быть вместе с главной героиней."
    voice "voice/a11/3300260a02.opus"
    aoi "Иначе это было бы бессмысленно."
    voice "voice/a11/3300270a02.opus"
    aoi "Так что Аой запросит патч до новой версии."
    xy "И ты опять начинаешь нести свою пургу про симуляторы свиданий..."
    voice "voice/a11/3300280a02.opus"
    aoi "Мне пора идти—"
    xy "Стой!"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300290a02.opus"
    aoi "Буп-буп?.."
    "Выражение лица Муко слегка изменилось, практически незаметно."
    "Но в то же время я был немного шокирован тем, что я крикнул ей вслед."
    "Разумеется, я не хотел, чтобы она показала то фото кому-либо."
    "Не тогда, когда я наконец-то начал наслаждаться своей жизнью как классный тихоня."
    "Если по школе пройдут слухи, что какой-то жалкий и никчёмный человек, как я, пытался признаться королеве Миюки в любви..."
    "Одна лишь мысль об этом вывела меня из себя."
    "Наверное, поэтому я и крикнул Муко вслед; чтобы не дать этому произойти."
    "...Так ведь?"
    xy "Слушай... Разве ты СЕЙЧАС не просила её стать твоей подругой?"
    xy "Разве это не то, чего ты хотела?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300300a02.opus"
    aoi "Подругой?.."
    "Она снова наклонила голову так, будто рассматривала понятие этого слова."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300310a02.opus"
    aoi "Аой правда не знает... кто такие друзья."
    "И тут я вспомнил её список контактов с одной единственной записью."
    xy "Ладно, смотри сюда."
    $ sename = "se人体_動作_ポケット探る"
    play se sedict[sename]
    "Я достал телефон из своего кармана."
    xy "Давай обменяемся электронками."
    xy "Это первый шаг к тому, чтобы завести друзей. Неплохо, да?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300320a02.opus"
    aoi "Обменяться... электронками?.."
    xy "Ты готова?"
    voice "voice/a11/3300330a02.opus"
    aoi "А как это делается?"
    xy "...А, точно."
    "Было очевидно, что она не делала это раньше."
    xy "По-моему, здесь..."
    $ sename = "se物体_携帯_アドレス交換"
    play se sedict[sename]
    pause (500/1000)
    xy "...Какого?"
    "Я пытался отправить самому себе электронку, используя её телефон, но она не отправлялась."
    xy "У тебя здесь сигнал не ловит? Странно. У моего телефона есть все палки..."
    voice "voice/a11/3300340a02.opus"
    aoi "Получается... мы не сможем обменяться?"
    "По какой-то причине я почувствовал грусть в её безэмоциональной речи. Пораскинув мозгами, я обнадёживающе улыбнулся ей."
    xy "Не волнуйся. Мы можем сделать это вручную. Смотри."
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    pause (500/1000)
    "Я переписал её номер телефона и адрес электронной почты в свой список контактов."
    "А потом я показал переписанную информацию ей, на всякий случай."
    xy "Всё правильно?"
    voice "voice/a11/3300350a02.opus"
    aoi "Угу."
    "На какое-то время между нами повисла тишина, пока её взгляд метался между нашими телефонами."
    xy "...Что-то не так?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300360a02.opus"
    aoi "Поняла!"
    "Она подняла руку."
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_normal")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300370a02.opus"
    aoi "Это делает нас друзьями?"
    xy "Да, можно и так сказать."
    xy "Как только ваши контакты записаны друг у друга в телефонах, вы, в основном, уже являетесь друзьями."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300380a02.opus"
    aoi "Шиничи... и Аой... друзья?"
    xy "Ага. Ты и я теперь официально друзья."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300390a02.opus"
    aoi "Друзья..."
    "Муко озадаченно смотрела на новую запись в своём списке контактов."
    "Прошло ещё какое-то время."
    "Мне начало казаться, будто время вокруг нас остановилось."
    pause (1000/1000)
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    pause (1000/1000)
    xy "Нам, наверное, пора идти на занятия..."
    xy "...Эм, Земля вызывает Муко? Ты слышишь меня?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300400a02.opus"
    aoi "Поняла!"
    "И она снова подняла свою руку ввысь."
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_normal")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300410a02.opus"
    aoi "Теперь, когда мы друзья, ты должен называть меня Аой."
    "Воу, воу... я не совсем уверен насчёт этого..."
    "Это казалось мне слишком личным, она сильно торопится..."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a11/3300420a02.opus"
    aoi "Это плохо?"
    "Гха... Я не могу сказать «нет» ей в лицо..."
    xy "Ладно."
    "Чувствуя себя неловко, я прокашлялся."
    xy "Пошли, Аой."
    voice "voice/a11/3300430a02.opus"
    aoi "Хорошо, Шиничи."
    stop bgm fadeout (3000/1000)
    scene expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    "В конечном счёте, Аой никому не показала ту фотографию."
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    hide 絵色黒
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
