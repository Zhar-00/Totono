label a0112_MAIN:
    call expression GameName
    $ persistent.imagelog["efbgアオイのスマフォ"]=True
    $ persistent.imagelog["efbgアオイのスマフォ操作着信"]=True
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label a0112:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    play se sedict["se物体_携帯_着信音01L"]
    pause (1000/1000)
    xy "Хм?"
    show expression ("cg/ef/"+imagename["efbgアオイのスマフォ"]+".jpg") as 絵演効果 at center
    with ImageDissolve("cg/data/slide_04_00_1.png",1)
    pause (500/1000)
    "Я посмотрел вниз."
    "Рядом с дверью чей-то телефон лежал экраном вниз."
    "Кто его обронил?"
    hide 絵演効果 with Dissolve(.8)
    "Я нагнулся и подобрал его."
    show expression ("cg/ef/"+imagename["efbgアオイのスマフォ操作着信"]+".jpg") as 絵演効果 at center
    with dissolve
    xy "......"
    "Входящий звонок от «Бога»."
    "...От Бога???"
    stop se fadeout .05
    hide 絵演効果 with Dissolve(.3)
    "Не успел я ответить, как вызов уже завершился."
    "Должен признаться, мне немного полегчало."
    "Серьёзно, чей это телефон?"
    return
label a0112_SELECT:
    $ renpy.save("lastsel")
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg") as 上背景
    play se sedict["se環境_ガヤ_学校屋上放課後L"]
    menu:
        "Позвонить по телефону":
            $ SetChoiceSelect = 0
        "Проверить историю вызовов":
            $ SetChoiceSelect = 1
    if (SetChoiceSelect==0):
        $ GameName = "a0113t.nss";
    elif (SetChoiceSelect==1):
        $ GameName = "a0113.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
