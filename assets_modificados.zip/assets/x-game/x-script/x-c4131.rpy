label c4131_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4141.nss"
    return
label c4131:
    hide 絵色黒
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    scene expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    hide 上背景

    "Во время обеда—"
    hide 絵色黒
    with Dissolve(1000.0/1000)
    voice "voice/c41/3100010a01.opus"

    mx "\"А-а... а-а...\""
    voice "voice/c41/3100020a01.opus"

    mx "\"А-АПЧХИ!!!\""
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100030a01.opus"

    mx "\"Пф-ф-ф-ф-ф-ф...\""

    xy "\"Ты в порядке?\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100040a01.opus"

    mx "\"...У меня просто аллергия.\""

    "Мы сидели на крыше."

    "У меня с Миюки был личный разговор."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100050a01.opus"

    mx "\"Хорошо, я поняла.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100060a01.opus"

    mx "\"Я и не знала, что у тебя тоже сильная игровая зависимость.\""

    xy "\"Ни в коем разе!\""

    xy "\"Да брось, сама на них посмотри.\""
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    hide StC
    hide StMR
    hide StML
    with Dissolve(500.0/1000)
    voice "voice/c41/3100070a02.opus"

    aoi "\"Иди сюда, Иру!\""
    play voc "c41/3100080b04"
    voice "voice/c41/3100090a02.opus"

    aoi "\"Буп-буп? Куда это ты?\""
    play voc "c41/3100100b04"

    "Я показал пальцем на Аой, она сейчас играла вместе с Иру."

    "Всё же лучше один раз увидеть, чем сто раз услышать."

    "И это, возможно, была конкретная причина, по которой я сделал всё возможное, чтобы принести Иру с нами в школу."
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)

    xy "\"Какие чувства ты испытываешь, когда видишь, как они играют?\""
    voice "voice/c41/3100110a01.opus"
    mx "\"......\""

    xy "\"...Миюки?\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_gag")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100120a01.opus"
    mx "......"

    xy "\"Эм... у тебя слюна потекла.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100130a01.opus"

    mx "\"АХ!\""

    xy "\"Ты в порядке?\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100140a01.opus"

    mx "\"Т-ты слепой?! Разумеется, я не в порядке!\""

    xy "\"Аой и Иру выглядят такими счастливыми вместе, тебе так не кажется?\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100150a01.opus"

    mx "\"М-м... наверное.\""

    xy "\"Этого бы не произошло, если бы Аой не спасла это маленькое создание вчера ночью.\""

    xy "\"И я считаю, что она правильно поступила.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100160a01.opus"

    mx "\"Ну да, они счастливы, но это не такая уж и насущная проблема.\""
    voice "voice/c41/3100170a01.opus"

    mx "\"Сейчас, возможно, всё в порядке, но рано или поздно у них начнутся проблемы.\""

    "Миюки была такой же упрямой, что и всегда, понятно..."

    "Но к счастью, я это предвидел."

    "И у меня есть козырь в рукаве."

    xy "\"Слушай, Миюки?\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100180a01.opus"
    mx "\"Хм?..\""
    $ sename = "se人体_動作_起き上がる02"
    play se sedict[sename]

    "Я показал ей экран своего телефона; но лишь на мгновение."
    $ sename = "se人体_動作_奪い取る"
    play se sedict[sename]

    "А потом я убрал его."
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100190a01.opus"

    mx "\"Какого?! Что ЭТО было?\""

    xy "\"Хочешь посмотреть?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100200a01.opus"

    mx "\"Разумеется, хочу! Покажи мне! Это была—?!\""

    xy "\"Очень редкая фотография спящего Иру? Конечно.\""

    xy "\"Если хочешь посмотреть на неё...\""

    xy "\"...ты должна уладить дела с Аой.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100210a01.opus"

    mx "\"Т-ты серьёзно думаешь, что можешь подкупить меня ЭТИМ?\""

    xy "\"О, на этой фотографии на Аой надета кошачья пижама.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_gag")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100220a01.opus"

    mx "\"Меня не подкупить... меня не подкупить!..\""

    xy "\"Да бро-о-ось, ты знаешь, что хо-о-о-очешь этого...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100230a01.opus"
    mx "\"......!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100240a01.opus"

    mx "\"Т-ты ЖУЛИК!!!\""

    xy "\"Жулик, игроман, не важно. Можешь называть меня как хочешь.\""

    xy "\"Я просто хочу снова провести время с двумя своими хорошими друзьями.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100250a01.opus"

    mx "\"Ты думаешь, я куплюсь на такую выходку?\""

    xy "\"Прости. Я просто дурачился.\""

    xy "\"Но насчёт последнего я серьёзно.\""

    "Я посмотрел прямо в глаза Миюки."
    stop bgm fadeout (500.0/1000)
    $ sename = "se人体_動作_抱きつく02"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((300.0+1000.0)/1000)
    hide StC with Dissolve(0.0/1000)

    xy "\"Пожалуйста, умоляю тебя!\""

    xy "\"Аой нуждается в тебе! Пожалуйста, будь рядом с ней!\""

    "Я смиренно преклонился перед ней."

    "И ждал."

    "И ждал... и ждал..."

    "...А ответа так и не последовало."
    voice "voice/c41/3100260a01.opus"

    mx "\"Слушай...\""
    voice "voice/c41/3100270a01.opus"

    mx "\"...Зачем ты всё это делаешь?\""

    xy "\"В смысле, зачем?\""
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_sigh")
    hide 絵色黒
    with Dissolve(500.0/1000)

    "Я посмотрел вверх и увидел, как Миюки смотрела на меня с прищуром."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100280a01.opus"

    mx "\"Ты испытываешь к ней чувства?\""

    xy "\"Конечно же нет!\""

    "И тут я вдруг вспомнил ощущение дыхания на своей коже..."

    xy "\"Она для меня не более, чем подруга!!!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100290a01.opus"
    mx "\"Шиничи.\""
    voice "voice/c41/3100300a01.opus"

    mx "\"Она тебя слышит, знаешь ли.\""
    xy "\"Оу...\""
    hide StC with Dissolve(200.0/1000)

    "Моя кровь застыла в жилах."

    "Я тут же посмотрел на Аой..."
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    with Dissolve(500.0/1000)
    voice "voice/c41/3100310a02.opus"

    aoi "\"Смотри! Кошачьи ушки!\""
    voice "voice/c41/3100320a02.opus"

    aoi "\"Так мило!\""
    play voc "c41/3100330b04"
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100340a01.opus"

    mx "\"Ты ведь рад узнать, что она тебя не слышала?\""

    xy "\"Н-нет, это не—\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100350a01.opus"

    mx "\"Ну ладно уж. Учитывая твою искренность, я налажу с ней отношения.\""

    xy "\"Ты серьёзно?!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100360a01.opus"

    mx "\"Я всё равно собиралась поговорить с ней.\""
    xy "\"Спасибо!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shout")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100370a01.opus"

    mx "\"Но при одном условии!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100380a01.opus"

    mx "\"Я хочу, чтобы ты скинул мне все свои фотки с Иру.\""
    xy "\"Будет сделано.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100390a01.opus"

    mx "\"Обещай мне!\""

    xy "\"Обещаю!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100400a01.opus"

    mx "\"Отправь их мне сейчас же!\""
    hide StC with Dissolve(200.0/1000)

    "Боже, она просто с ума сходит от этих фоток с котами..."
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]

    "Я тут же отправил ей по электронной почте все свои фотографии с Иру и Аой."

    xy "\"Отправил.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100410a01.opus"

    mx "\"Спасибо!\""
    pause (200/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100420a01.opus"

    mx "\"Оу... оу... оу!..\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_gag")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100430a01.opus"

    mx "\"О боже, как МИЛО!..\""
    voice "voice/c41/3100440a01.opus"

    mx "\"Не могу поверить, что такое прекрасное маленькое создание существует на этой Земле...\""

    "И, разумеется, Миюки начала с восторгом просматривать фотографии..."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100450a01.opus"
    mx "\"О...\""

    "...Как вдруг..."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100460a01.opus"

    mx "\"Стоп, эм?\""

    "...она наклонила голову."
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100470a01.opus"

    mx "\"Мне кажется, я узнаю этот фон...\""

    "Вот дерьмо."

    xy "\"А? О, это же, эм... наверное, она слишком тёмная, чтобы сказать точно, но это... по-моему, кладовка в школе?..\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shout")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100480a01.opus"

    mx "\"Аой!\""

    "Миюки проигнорировала меня и позвала Аой."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100490a01.opus"

    mx "\"Где была сделана эта фотография?\""
    hide StC
    hide StMR
    hide StML
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg") as 絵背景 zorder 100 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/c41/3100500a02.opus"

    aoi "\"Дома у Шиничи.\""

    xy "\"Эй!\""

    "Не говори ей просто так!"
    voice "voice/c41/3100510a01.opus"

    mx "\"Ты была у него дома вчера?\""
    voice "voice/c41/3100520a02.opus"

    aoi "\"Угу. Я провела там всю ночь.\""
    voice "voice/c41/3100530a01.opus"
    mx "\"—?!\""
    voice "voice/c41/3100540a01.opus"

    mx "\"В-в каком смысле, провела там всю ночь?!\""
    voice "voice/c41/3100550a02.opus"

    aoi "\"Мы спали в одном доме вчера ночью.\""
    hide 絵背景
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_通常_cool")
    with Dissolve(500.0/1000)
    voice "voice/c41/3100560a01.opus"
    mx "\"......!\""

    xy "\"Не делай из мухи слона. Она спала на диване, ясно? В смысле, что я ещё должен был делать, позволить ей спать на улице?\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100570a01.opus"

    mx "\"...Ладно, вполне справедливо...\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_shout")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100580a01.opus"

    mx "\"Как всё прошло, Аой? Он пытался что-нибудь сделать? Ты хорошо выспалась?\""
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    hide StC
    hide StMR
    hide StML
    with Dissolve(500.0/1000)
    voice "voice/c41/3100590a02.opus"

    aoi "\"Вообще не могла уснуть...\""
    voice "voice/c41/3100600a01.opus"

    mx "\"Ты не могла уснуть?\""
    voice "voice/c41/3100610a02.opus"

    aoi "\"Дом Шиничи просто пахнет им.\""
    voice "voice/c41/3100620a02.opus"

    aoi "\"Это внушает беспокойство.\""
    voice "voice/c41/3100630a02.opus"

    aoi "\"Заставляет моё сердце колотиться.\""
    voice "voice/c41/3100640a01.opus"

    mx "\"И это не давало тебе спать всю ночь?\""
    voice "voice/c41/3100650a02.opus"

    aoi "\"Это странно...\""
    voice "voice/c41/3100660a02.opus"

    aoi "\"Всё моё тело было возбуждено...\""
    voice "voice/c41/3100670a02.opus"

    aoi "\"Неужели... неужели Аой заболела?\""
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    hide StC
    hide StMR
    hide StML
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(500.0/1000)
    voice "voice/c41/3100680a01.opus"
    mx "\"Ха-а...\""

    "Миюки громко вздохнула."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c41/3100690a01.opus"

    mx "\"Позволь мне ввести тебя в курс дела, Аой.\""
    voice "voice/c41/3100700a02.opus"
    aoi "\"Буп-буп?\""
    voice "voice/c41/3100710a01.opus"

    mx "\"Те чувства, которые ты испытываешь? Это не дружеские чувства.\""
    show expression ("cg/bg/l/"+imagename["bg010300_1_学校屋根_l"]+".jpg") as 絵背景 zorder 15:
        pos (-1050,-800)
        zoom 1.5
    hide StC
    hide StMR
    hide StML
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(500.0/1000)
    $ renpy.music.play("ttb12",channel = "bgm", if_changed = True)
    voice "voice/c41/3100720a01.opus"

    mx "\"...Это любовь.\""
    voice "voice/c41/3100730a01.opus"

    mx "\"Ты влюблена в Шиничи.\""
    show expression ("cg/bg/l/"+imagename["bg010200_1_学校屋上_l"]+".jpg") as 絵背景 zorder 15:
        pos (-490,-700)
        zoom 1.5
    hide StC
    hide StMR
    hide StML
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_surprise")
    with Dissolve(500.0/1000)
    voice "voice/c41/3100740a02.opus"

    aoi "\"Любовь?..\""

    "Аой уставилась в никуда."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_lost")
    voice "voice/c41/3100750a02.opus"

    aoi "\"Аой... влюблена... в Шиничи...\""
    voice "voice/c41/3100760a02.opus"

    aoi "\"Аой... влюблена... в Шиничи?..\""
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_よろけ_normal")
    voice "voice/c41/3100770a02.opus"

    aoi "\"Чт... Что за?\""
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_よろけ_sad")
    voice "voice/c41/3100780a02.opus"

    aoi "\"Аой заглючило?\""
    show expression Solid("000000") as 絵色黒 zorder 30000
    with Dissolve((4000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
