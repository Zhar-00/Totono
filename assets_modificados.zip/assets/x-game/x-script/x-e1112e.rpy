label e1112e_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2000.nss"
    return
label e1112e:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_病み_hard")
    with Dissolve(200.0/1000)
    voice "voice/e11/12e00010a01.opus"
    mx "\"Ты обещал мне, помнишь?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/12e00020a01.opus"
    mx "\"А это значит, что ты должен делать именно то, что я тебе говорю.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_rage")
    with Dissolve(200.0/1000)
    voice "voice/e11/12e00030a01.opus"
    mx "\"Так ты будешь счастливее!\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/12e00040a01.opus"
    mx "\"Разве ты не согласен?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/12e00050a01.opus"
    mx "\"Умоляю тебя... Пожалуйста, не смотри на других женщин.\""
    hide StC with Dissolve(200.0/1000)
    "Уклонившись от её вопроса, я решил отхлебнуть немного её домашнего мисо супа."
    show expression Solid("000000") as 絵色黒 zorder 1000
    with Dissolve((0.0+800.0)/1000)
    "И тут тёмный занавес повис перед моими глазами."
    "Это... мои волосы?.."
    "Не помню, чтобы я позволял им так сильно отрасти..."
    scene expression "cg/bg/black.jpg" zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause 1
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
