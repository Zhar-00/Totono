label a3223_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a3224.nss"
    return
label a3223:
    hide 絵色黒
    $ renpy.music.play("ttb07",channel = "bgm", if_changed = True)
    $ sename = "se人体_足音_歩く01遅L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040200_3_街川縁"]+".jpg")
    show expression ("cg/ev/"+imagename["eva3222アオイおんぶ"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    voice "voice/a32/2300010a02.opus"
    aoi "Тебя никто не кинет, Шиничи."
    xy "Прошу прощения?"
    voice "voice/a32/2300020a02.opus"
    aoi "Аой уже пропатчила вселенную, чтобы убедиться в этом."
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵色回想黒 zorder 3900
    with Dissolve((0.0+300.0)/1000)
    show expression ("cg/ev/l/"+imagename["eva0113アオイ送信中b_l"]+".jpg") as 絵覆絵専弐 zorder 2100 at truecenter
    with Dissolve(1000.0/1000)
    "Стоя наверху, на крыше... в центре всего мира..."
    "Аой «обновила» вселенную."
    "Но это она всего лишь отыгрывала одну сцену из той игры..."
    "Верно?"
    hide 絵専
    hide 絵覆絵専弐
    hide 絵色回想黒
    with Dissolve(400.0/1000)
    pause (300/1000)
    voice "voice/a32/2300030a02.opus"
    aoi "Шиничи..."
    voice "voice/a32/2300040a02.opus"
    aoi "Ты станешь принцем Миюки."
    xy "Её... принцем?.."
    "Не могу поверить в то, что я услышал это."
    "Меня можно было описать разными словами, но только не «принцем»."
    stop bgm fadeout (4000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
