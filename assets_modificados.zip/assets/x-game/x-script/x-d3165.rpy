label d3165_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c3166.nss"
    return
label d3165:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(0.0/1000)

    xy "\"Пешеходные ворота перед школой!\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/d31/6500010a01.opus"

    mx "\"Чего?..\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/d31/6500020a01.opus"

    mx "\"Стоп... Шиничи?!\""
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040400_3_街交差点"]+".jpg")
    hide StC with Dissolve(0.0/1000)
    with Dissolve(300.0/1000)

    "Не успел я и опомниться, как уже бежал на полной скорости."

    "Я прошёл мимо школьных ворот, чтобы проверить картонную коробку."

    "В обычной ситуации, это была небольшая, ничем не примечательная деталь—"
    show expression ("cg/bg/"+imagename["bg040100_3_街通学路"]+".jpg")
    with Dissolve(300.0/1000)

    "Но сейчас я почему-то был очень уверен в этом."

    "Я помню, как они были открыты—"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((300.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010402_3_学校校門閉"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010402_3_学校校門閉_l"]+".jpg") as 絵背景 zorder 500:
        pos (-150,-410)
    stop se fadeout (300.0/1000)
    pause (600/1000)
    hide 絵色黒
    with Dissolve(300.0/1000)
    $ sename = "se物体_校門_揺れる02"
    play se sedict[sename]

    xy "\"Они заперты?!\""

    "Я что-то не так запомнил?"

    "Нет, не может быть..."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    voice "voice/d31/6500030a01.opus"

    mx "\"Слушай, Шиничи...\""
    with Dissolve((300.0+0.0)/1000)

    "Миюки догнала меня, полностью запыхавшись."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/d31/6500040a01.opus"

    mx "\"Я уже проверила школьные ворота. Они заперты.\""
    xy "\"Но—!\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/d31/6500050a01.opus"

    mx "\"Я не говорю, что ты что-то не так запомнил.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/d31/6500060a01.opus"

    mx "\"Наверное... О, знаю. Наверное, они были открыты, когда ты видел их в последний раз, но к тому времени, когда я пришла сюда, они уже были закрыты.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/d31/6500070a01.opus"

    mx "\"Кто бы не был на территории школы до этого, он, скорее всего, уже ушёл.\""
    voice "voice/d31/6500080a01.opus"

    mx "\"В этом есть смысл, не так ли?\""
    xy "......"

    "Я не могу сделать вид, что не вижу здесь логики."

    "Но..."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/d31/6500090a01.opus"

    mx "\"Что? Ты всё ещё не уверен?\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/d31/6500100a01.opus"

    mx "\"Ты хочешь проникнуть туда?\""
    with Dissolve((500.0+1000.0)/1000)

    "Я посмотрел на высокие ворота, возвышавшиеся над нами."

    "Проникнуть на территорию школы ночью?"

    "Даже мне не хватило бы уверенности для ТАКОГО."
    hide 絵背景
    with Dissolve(300.0/1000)

    xy "\"Прости, что так запаниковал.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/d31/6500110a01.opus"

    mx "\"Нет, всё нормально.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/d31/6500120a01.opus"

    mx "\"А теперь пошли домой.\""
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    pause (500/1000)

    "Мы молча отвернулись от ворот."
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
