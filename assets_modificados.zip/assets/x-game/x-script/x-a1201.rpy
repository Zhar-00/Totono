label a1201_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a1202.nss"
    return
label a1201:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve(1500.0/1000)
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    pause (5000/1000)
    stop se fadeout (10000.0/1000)
    $ tz(1)
    xy "Эй, Ютаро! Давай пообе—"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_cry")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    voice "voice/a12/0100010b01.opus"
    xtl "Н-н-н-н-нг-г-г-гх-х-х-х-х-х..."
    voice "voice/a12/0100020b01.opus"
    xtl "Я не голодный..."
    xy "В чём дело? Тебя тошнит?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a12/0100030b01.opus"
    xtl "Это из-за трусиков..."
    xy "Ты... съел их?.."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a12/0100040b01.opus"
    xtl "Нет!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a12/0100050b01.opus"
    xtl "Я узнал, чьи они."
    xy "А... понятно..."
    "Я не совсем был уверен, хочу ли я знать ответ, но..."
    xy "И чьи они были?"
    voice "voice/a12/0100060b01.opus"
    xtl "Рюджиро."
    xy "......"
    xy "Твоего... брата?.."
    voice "voice/a12/0100070b01.opus"
    xtl "Да."
    voice "voice/a12/0100080b01.opus"
    xtl "Судя по всему, он купил их в интернете. Чтобы носить."
    voice "voice/a12/0100090b01.opus"
    xtl "Он сказал, что ему... нравится носить бабскую одежду."
    xy "Ну... это... что-то с чем-то."
    voice "voice/a12/0100100b01.opus"
    xtl "......"
    xy "......"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_cry")
    with Dissolve(200.0/1000)
    voice "voice/a12/0100110b01.opus"
    xtl "Шиничи... я, эм... мог на них пере—"
    xy "Стой. Не... не договаривай эту фразу."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_lost")
    with Dissolve(200.0/1000)
    voice "voice/a12/0100120b01.opus"
    xtl "Ха-ха... Ха-ха-ха-ха-ха-ха..."
    voice "voice/a12/0100130b01.opus"
    xtl "Мои мечты... мои мечты разрушены..."
    xy "Всё будет хорошо, капитан. Я уверен, ты вскоре найдёшь свою новую мечту."
    xy "Ну а пока... можешь немного погоревать."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_cry")
    with Dissolve(200.0/1000)
    voice "voice/a12/0100140b01.opus"
    xtl "Спасибо, Шиничи... Спасибо!.."
    hide StC with Dissolve(200.0/1000)
    "Ютаро кивнул в слезах."
    "Я понятия не имел, что мне с этим делать. Думаю, я просто похлопаю его по плечу."
    stop bgm fadeout (2000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010700_1_学校廊下"]+".jpg")
    pause (1000/1000)
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(1000.0/1000)
    "Пока я возвращался обратно из столовой со своим бутербродом, я задумался над возвращением в класс... но я не мог себе представить, что кому-то из нас понравится сидеть там в тишине вместе."
    "Вместо этого я пошёл к своему любимому месту."
    stop se fadeout (2000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
