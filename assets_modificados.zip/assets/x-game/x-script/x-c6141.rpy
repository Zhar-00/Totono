label c6141_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6151.nss"
    return
label c6141:
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg040400_2_街交差点"]+".jpg")
    $ sename = "se人体_足音_歩く01L"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve(1000.0/1000)
    pause (500/1000)
    "Я побежал вниз по дороге, оказавшись под красными лучами заката."
    "Если я буду бежать, то я ещё успею на спектакль."
    "Стоит признать, что я сильно отклонился от маршрута, но я хотя бы разобрался с этим недоразумением!"
    "Боже, мне так стыдно за то, что я вообще сомневался в Аой или Ютаро."
    "Но, разумеется, я всё ещё хочу знать, почему Аой вышла из дома."
    "Особенно учитывая то, что она сделала это за моей спиной..."
    show expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg")
    with Dissolve(500.0/1000)
    pause (500/1000)
    xy "\"Я уверен, на то должна быть веская причина... верно?..\""
    "Хару-чан состоит в театральном клубе."
    "Я не могу отрицать возможность того, что они работают над каким-нибудь сюрпризом к моему дню рождения."
    "Наверное, я должен сделать вид, что я ничего не видел."
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
