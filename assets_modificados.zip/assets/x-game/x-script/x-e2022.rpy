label e2022_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2005.nss"
    return
label e2022:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    show expression Solid("000000") as 絵演色黒
    call eroute_bgm
    voice "voice/e20/2200010a01.opus"
    mx "\"...Шиничи?\""

    xy "\"Н-н... н-н-н... н-н...\""
    show expression Solid("FFFFFF") as 絵色白 zorder 1090
    show expression ("cg/bg/l/"+imagename["bg110100_1_マンションリビング_l"]+".jpg") as 絵背景 zorder 100:
        pos (0,-1024)
    with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(600.0/1000))
    pause (200/1000)
    hide 絵色白
    with Dissolve(2000.0/1000)
    pause (500/1000)
    hide 絵演色黒
    $ sename = "se人体_動作_衣擦れ04"
    play se sedict[sename]
    pause (15/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_normal")
    hide 絵背景
    with Dissolve(500.0/1000)

    xy "\"Ч... что за?.. Миюки?\""
    voice "voice/e20/2200020a01.opus"

    mx "\"Ты не выспался? Поверить не могу, что ты вырубился сразу же после завтрака.\""

    xy "\"А?.. Это всё... было во сне?..\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_smile")
    with Dissolve(200.0/1000)
    mx "\"Тебе приснился сексуальный сон со мной или что-то в таком духе?\""

    xy "\"А? Н-нет, конечно же нет!\""
    voice "voice/e20/2200040a01.opus"

    mx "\"А, и правда...\""

    "Она посмотрела на мою промежность и ухмыльнулась."

    "Естественно, у меня стояк был твёрже алмазов."
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e20/2200050a01.opus"

    mx "\"Ну ладно. Давай.\""
    voice "voice/e20/2200060a01.opus"

    mx "\"Пришло время для нашей ежедневной деятельности.\""

    xy "\"Л-ладно...\""
    pause (16/1000)
    scene expression "cg/bg/black.jpg" zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
