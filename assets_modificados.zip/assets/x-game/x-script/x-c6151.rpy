label c6151_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6152.nss"
    return
label c6151:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010801_2_学校体育館演劇準備"]+".jpg")
    $ st_timezone = "昼"
    $ sename = "se環境_ガヤ_教室ざわめくL"
    play se sedict[sename]
    with Dissolve(1000.0/1000)

    "Я отдал кассиру свой билет и вошёл в тёмный спортзал."

    "Спектакль пока не начался, но большинство мест было уже занято."

    "Осталось только дождаться момента, когда занавес раскроется."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/c61/5100010a01.opus"

    mx "\"Шиничи! Ты опоздал!\""

    xy "\"Да, я знаю. Просто кое-что произошло.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c61/5100020a01.opus"

    mx "\"Вижу, Аой не с тобой. С ней что-то произошло?\""

    "Если даже Миюки удивлена, то я, наверное, не должен копаться в том, что я только что видел..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
