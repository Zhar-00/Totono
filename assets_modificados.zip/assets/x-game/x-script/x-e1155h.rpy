label e1155h_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1155h:
    hide 絵色黒
    $ renpy.music.play("ttb22",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_ero")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/55h00010a01.opus"
    mx "\"Я умоляю тебя...\""
    voice "voice/e11/55h00020a01.opus"
    mx "\"Ты разве не видишь, в каком я отчаянии?\""
    voice "voice/e11/55h00030a01.opus"
    mx "\"И всё же... ты всё равно отказываешься?..\""
    voice "voice/e11/55h00040a01.opus"
    mx "\"Ты правда... так сильно хочешь быть с Аой?..\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    voice "voice/e11/55h00050a01.opus"
    mx "\"Что ж, в таком случае...\""
    $ St("C",300,0,0,"st曽根美雪_制服_病み_hard")
    with Dissolve(200.0/1000)
    voice "voice/e11/55h00060a01.opus"
    mx "\"Если ты испытываешь именно такие чувства, то мы посмотрим, чья возьмёт.\""
    voice "voice/e11/55h00070a01.opus"
    mx "\"Я изменю это!\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_rage")
    with Dissolve(200.0/1000)
    voice "voice/e11/55h00080a01.opus"
    mx "\"Я изменю этот мир так же, как и игру!!!\""
    voice "voice/e11/55h00090a01.opus"
    mx "\"И я сотру Аой!!! Навсегда!!!\""
    $ sename = "se人体_足音_階段自宅上がる01"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    xy "\"Эм... Миюки?..\""
    stop bgm fadeout (100.0/1000)
    stop se fadeout (150.0/1000)
    $ sename = "se物体_ドアマンション_閉まる"
    play se sedict[sename]
    "Миюки проигнорировала меня и выбежала из дома."
    "Что с ней происходит? Почему это она вдруг разревелась?"
    "Ничего из того, что она сказала мне, не имело никакого смысла..."
    "И я решил—"
    menu:
        "Пойти искать Миюки":
            $ SetChoiceSelect = 0
        "Пойти искать Аой":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e1156a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e1156b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
