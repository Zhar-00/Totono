label e1132b_MAIN:
    call expression GameName
    $ persistent.imagelog["bg110100_2_マンションリビング"]=True
    $ PreGameName = GameName
    $ GameName = "e1133.nss"
    return
label e1132b:
    scene expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg") behind 絵色黒
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)

    xy "\"Я ненавипфу тепфя...\""
    voice "voice/e11/32b00010a01.opus"

    mx "\"Извини, что ты сказал?\""

    "Она прижала холодное металлическое лезвие к моей коже."

    "Что-то начало стекать по моей шее..."
    voice "voice/e11/32b00020a01.opus"

    mx "\"Я спрошу тебя ещё раз.\""
    voice "voice/e11/32b00030a01.opus"

    mx "\"Ты любишь меня?\""

    xy "\"Д-да! Конечно!\""
    hide 絵色黒
    with Dissolve(200.0/1000)
    pause (100/1000)
    hide 絵色白
    with Dissolve(600.0/1000)
    pause (300/1000)
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_smile")

    "От моего крика полотенце начало трястись."

    xy "\"Я просто пошутил насчёт—\""
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e11/32b00040a01.opus"

    mx "\"Я знаю.\""
    $ St("C",300,0,0,"fu曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/32b00050a01.opus"

    mx "\"Не важно, какие чувства испытывают другие люди, пока ты в этом мире со мной, ты будешь любить меня.\""
    voice "voice/e11/32b00060a01.opus"

    mx "\"Вот как всё и должно быть. Ожидать иного было бы странно.\""
    $ St("C",300,0,0,"fu曽根美雪_制服_病み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/32b00070a01.opus"

    mx "\"Если только я не перепишу игру, конечно.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
