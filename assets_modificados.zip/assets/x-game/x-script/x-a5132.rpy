label a5132_MAIN:
    call expression GameName
    $ persistent.imagelog["eva1111アオイ受信中c"]=True
    $ PreGameName = GameName
    $ GameName = "a5141.nss"
    return
label a5132:
    hide 絵色黒
    $ sename = "se環境_ガヤ_教室授業中L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    show expression ("cg/ev/l/"+imagename["eva1111アオイ受信中c_l"]+".jpg") as 絵専弐 zorder 1110:
        pos (-360,-230)
    with Dissolve(500.0/1000)
    pause (500/1000)
    xy "Ох..."
    "Парта Аой была пустой."
    "Ей всё так же нездоровится со вчерашнего дня?"
    stop se fadeout (2000.0/1000)
    $ EyeCatchIn(2000.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
