label e1165b_MAIN:
    call expression GameName
    $ persistent.imagelog["eva0121美雪初めてのチューe"]=True
    $ persistent.imagelog["bg010210_9_学校屋上屋根向"]=True
    queue bgm "ttb23"
    $ PreGameName = GameName
    $ GameName = "e1165c.nss"
    return
label e1165b:
    show expression ("cg/bg/"+imagename["bg010210_9_学校屋上屋根向"]+".jpg")
    with Dissolve(800.0/1000)
    hide 上背景
    show expression ("cg/ev/"+imagename["eve1158a美雪ラスボスb"]+".jpg") as 絵専 zorder 1010 at truecenter
    with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    voice "voice/e11/6500470a01.opus"
    mx "\"Извини, но...\""
    voice "voice/e11/6500480a01.opus"
    mx "\"Это мой единственный выбор...\""
    voice "voice/e11/6500490a01.opus"
    mx "\"Только так мы сможем быть счастливы вместе...\""
    xy "\"Да разве?\""
    voice "voice/e11/6500500a01.opus"
    mx "\"Что?\""
    xy "\"Это для тебя счастье?\""
    voice "voice/e11/6500510a01.opus"
    mx "\"Ну, разумеется! В смысле—\""
    xy "\"Врёшь.\""
    xy "\"Твои актёрские навыки на мне не сработают.\""
    voice "voice/e11/6500520a01.opus"
    mx "\"Шиничи?..\""
    xy "\"Твой голос дрожит.\""
    voice "voice/e11/6500530a01.opus"
    mx "\"Вовсе нет!\""
    xy "\"А вот и да.\""
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    pause (500/1000)
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    $ St("C",740,0,0,"st曽根美雪_制服_病み_sad")
    hide 絵専
    hide 絵色黒
    with Dissolve(800.0/1000)
    stop se fadeout .3
    pause (300/1000)
    "Я молча взбирался по лестнице."
    "Миюки отвела свой взгляд."
    "Я начал идти прямо к ней."
    "Я не знаю, чему верить."
    "Я не мог разглядеть правду."
    "Но есть одна вещь, которую я знаю."
    show expression ("cg/ev/"+imagename["eva0121美雪初めてのチューe"]+".jpg") as 絵専 zorder 1010 at center
    with Dissolve((800.0+1000.0)/1000)
    pause (300/1000)
    xy "\"Миюки.\""
    "Шаг за шагом, я приближался к ней."
    voice "voice/e11/6500540a01.opus"
    mx "\"Шиничи?..\""
    "Ещё один шаг. А потом ещё один."
    voice "voice/e11/6500550a01.opus"
    mx "\"О чём ты думаешь?..\""
    "Я не хочу, чтобы моё сердце внезапно начало бешено колотиться."
    voice "voice/e11/6500560a01.opus"
    mx "\"Шин... ичи?..\""
    $ sename = "se人体_動作_衣擦れ04"
    play se sedict[sename]
    "Я нежно подтянул её к себе поближе."
    voice "voice/e11/6500570a01.opus"
    mx "\"......Ладно.\""
    voice "voice/e11/6500580a01.opus"
    mx "\"Продолжай.\""
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (500/1000)
    "Миюки закрыла глаза..."
    hide StC
    hide StMR
    hide StML
    hide 絵専
    hide 絵色黒
    $ sename = "se人体_動作_奪い取る"
    play se sedict[sename]
    $ sename = "se人体_衝撃_取り上げる"
    play se sedict[sename]
    $ renpy.music.play("ttb23_ic",channel = "bgm", if_changed = True)
    "...и я вырвал телефон из её руки."
    hide StC with Dissolve(0.0/1000)
    xy "\"—!!!\""
    $ sename = "se人体_足音_駆け出す"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010200_9_学校屋上"]+".jpg")
    with Dissolve(150.0/1000)
    "Пора бежать отсюда!"
    $ sename = "se人体_足音_駆け出す"
    play se sedict[sename]
    "Быстро, пока она ещё стоит с закрытыми глазами!"
    "Я буду бежать, пока она не потеряет мой след!!!"
    $ sename = "se物体_ドア鉄_閉まる01"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010100_9_学校階段"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010100_9_学校階段_l"]+".jpg") as 絵背景 zorder 100:
        pos (-512,-140)
    with Dissolve(150.0/1000)
    "Пока я в мыслях извинялся перед Миюки..."
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]
    pause (16/1000)
    "...я на всех парах побежал вниз по лестнице."
    $ sename = "se人体_衝撃_叩く机02"
    play se sedict[sename]
    $ sename = "se物体_ドア鉄_開く02"
    play se sedict[sename]
    $ persistent.miyuki_decision4 = True;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
