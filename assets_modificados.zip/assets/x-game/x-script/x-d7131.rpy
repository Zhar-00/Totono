label d7131_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d7141.nss"
    return
label d7131:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/bg/l/"+imagename["bg020100_3_自宅外正面_l"]+".jpg") as 絵演背景 zorder 110:
        pos (-715,-450)
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    with Dissolve(500.0/1000)
    pause (500/1000)
    "Вечерний воздух был спокойным, но холодным."
    "На небе - ни облачка; уличные фонари растягивали тень Аой по всей земле."
    "Во всём мире было тихо, за исключением нас... как будто весь шум засосало в другое измерение."
    xy "\"Ладно, увидимся.\""
    "И в этот момент я должен был закрыть дверь и запереть засов."
    "Но как только я начал закрывать дверь—"
    $ St("C",300,0,0,"bu向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/d71/3100010a02.opus"
    aoi "\"Поняла.\""
    "Аой подняла свою руку в воздух."
    "Её взгляд был таким же пустым, что и всегда."
    "У меня было такое чувство, будто она смотрела не на меня."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/d71/3100020a02.opus"
    aoi "\"Шиничи.\""
    voice "voice/d71/3100030a02.opus"
    aoi "\"Все сохранения Аой исчезнут.\""
    voice "voice/d71/3100040a02.opus"
    aoi "\"Они все исчезнут.\""
    voice "voice/d71/3100050a02.opus"
    aoi "\"Но...\""
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/d71/3100060a02.opus"
    aoi "\"Аой правда было очень приятно быть твоей подругой.\""
    voice "voice/d71/3100070a02.opus"
    aoi "\"И Аой рада тому, что родилась в этом мире.\""
    voice "voice/d71/3100080a02.opus"
    aoi "\"Даже если все меня здесь забудут...\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (500/1000)
    $ St("C",300,0,0,"fu向日アオイ電波_制服_密着_normal")
    with Dissolve(400.0/1000)
    pause (500/1000)
    voice "voice/d71/3100090a02.opus"
    aoi "\"ТЫ будешь помнить меня, верно?\""
    "Её слова походили на какое-то проклятие."
    "Я не какой-то персонаж в видеоигре."
    "Я не могу просто удалить свои воспоминания и начать сначала."
    "Но прежде, чем мои набухшие эмоции успели принять форму..."
    stop se fadeout (150.0/1000)
    stop bgm fadeout (150.0/1000)
    $ sename = "se物体_ドア自宅_閉まる"
    play se sedict[sename]
    scene expression Solid("000000") as 絵色黒
    pause (1000/1000)
    "...я закрыл дверь."
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
