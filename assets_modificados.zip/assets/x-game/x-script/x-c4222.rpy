label c4222_MAIN:
    call expression GameName
    $ persistent.imagelog["evc4221アオイ眠り姫b"]=True
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label c4222:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")
    show expression ("cg/ev/l/"+imagename["evc4221アオイ眠り姫a_l"]+".jpg") as 絵専上上 zorder 1250:
        pos (-30,-30)
    with Dissolve(500.0/1000)

    "Она не дышит."

    "Я ещё ни разу не проходил практику по оказанию первой помощи, поэтому я, в основном, просто импровизировал на ходу, но—"
    $ sename = "se人体_動作_衣擦れ02"
    play se sedict[sename]

    xy "\"Ха-а-а-а-а!..\""

    "Я сделал глубокий вдох..."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)

    xy "\"Пф-ф-ф-ф-ф-ф-ф!..\""

    "...и прижался губами к её губам."

    "По мне прошёлся разряд статического электричества."

    "Надеясь на чудо, я выдохнул в неё весь воздух, который набрал в лёгкие."




    hide 絵色黒
    with Dissolve(1000.0/1000)

    "Пожалуйста, проснись, Аой! Пожалуйста!"

    "Есть кое-что, чего я тебе ещё не сказал!"

    "Я не хочу, чтобы всё так закончилось!"

    xy "\"М-м-м?.. М-м-мн?! М-м-мн-н-н!\""
    voice "voice/c42/2200010a02.opus"

    aoi "\"М-м... м-мнг... м-м-м...\""

    "Я почувствовал, как что-то прошлось по моим губам."

    "Аой моргнула."

    "И её грудь наконец-то начала подниматься и опускаться вновь."
    show expression ("cg/ev/l/"+imagename["evc4221アオイ眠り姫b_l"]+".jpg") as 絵専 zorder 2100:
        anchor (0,0)
        pos (-30,-30)
    with dissolve
    pause (1000/1000)
    voice "voice/c42/2200020a02.opus"

    aoi "\"Буп... буп-буп?..\""

    xy "\"Э-эй! Аой! Это я! Слышишь меня?\""
    voice "voice/c42/2200030a02.opus"

    aoi "\"Шин... ичи?..\""

    xy "\"Да! Это я, Шиничи!\""
    voice "voice/c42/2200040a02.opus"

    aoi "\"Почему... ты... здесь?..\""

    xy "\"Я уловил твою передачу данных!\""
    voice "voice/c42/2200050a02.opus"

    aoi "\"Мою передачу данных?..\""
    play voc "c42/2200060b04"

    "Иру мяукнул ей в ухо."
    voice "voice/c42/2200070a02.opus"
    aoi "\"Ох...\""
    voice "voice/c42/2200080a02.opus"

    aoi "\"Моя передача... дошла до тебя... а не до Бога?..\""

    xy "\"Судя по всему, да.\""
    voice "voice/c42/2200090a02.opus"

    aoi "\"Моё тело... всё... такое возбуждённое...\""
    voice "voice/c42/2200100a02.opus"

    aoi "\"Ты... перезарядил меня?..\""

    xy "\"Что ты имеешь в виду?\""
    voice "voice/c42/2200110a02.opus"

    aoi "\"Батарейка Аой... села...\""

    xy "\"А... понятно...\""

    "Я рад, что она пришла в сознание, но пока ещё рано расслабляться."
    show expression ("cg/ev/"+imagename["evc4221アオイ眠り姫b"]+".jpg") as 絵専上 zorder 1200 at center
    with Dissolve((500.0+1000.0)/1000)

    "Я достал свой телефон—"
    voice "voice/c42/2200120a02.opus"

    aoi "\"Нет смысла звонить в скорую.\""

    xy "\"Что значит, нет смысла?\""
    voice "voice/c42/2200130a02.opus"

    aoi "\"Просто побудь со мной.\""
    voice "voice/c42/2200140a02.opus"

    aoi "\"Таким образом Аой сможет перезарядиться.\""
    return
    return
label c4222_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/ev/"+imagename["evc4221アオイ眠り姫b"]+".jpg") as 絵専 zorder 2200 at truecenter
    with dissolve
    menu:
        "Всё равно позвонить в скорую":
            $ SetChoiceSelect = 0
        "Поговорить с Аой":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "d4223.nss"
    else:
        $ GameName = "c4223.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
