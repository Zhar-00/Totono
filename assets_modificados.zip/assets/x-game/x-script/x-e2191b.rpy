label e2191b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2194.nss"
    return
label e2191b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(0.0/1000)

    xy "\"...Нет, постой.\""

    xy "\"Здесь только что была кошка?..\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/e21/91b00010a01.opus"

    mx "\"Кошка? Здесь?\""

    xy "\"Да, такая маленькая и чёрная.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/91b00020a01.opus"

    mx "\"Тебе, наверное, померещилось.\""

    xy "\"Нет, я очень уверен—\""
    voice "voice/e21/91b00030a01.opus"

    mx "\"А, я тут вспомнила!\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
