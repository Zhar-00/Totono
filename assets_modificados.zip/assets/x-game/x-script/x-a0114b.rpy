label a0114b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a0121.nss"
    return
label a0114b:
    $ renpy.music.play("ttb01",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    "...Ладно, давай сделаем глубокий вдох и успокоимся."
    "Чего именно хочет от меня эта девушка?"
    "И кто она ВООБЩЕ такая?"
    "Стоп... Разве это не то, что только что случилось в той игре?.."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
