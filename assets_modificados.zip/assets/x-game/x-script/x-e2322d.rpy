label e2322d_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1111.nss"
    return
label e2322d:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    "Ничего не вышло..."
    "Экран заблокировался, и я тяжело вздохнул."
    "Похоже, я знаю Миюки не так хорошо, как я думал..."
    "Я молча посмотрел на неё. Будучи рядом со мной, её спокойный сон продолжался без перерыва."
    "Если бы только она была романтическим выбором в видеоигре... Тогда я мог бы просто выйти в интернет и посмотреть прохождение..."
    "Но это реальность."
    "Я не смогу узнать ответы на все эти вопросы, пока не начну уделять больше внимания всему тому, что она говорит."
    "Я так многого о ней не знаю..."
    xy "\"...Ха-а...\""
    "А вот и ненависть к себе..."
    "Вот и всё. Я пойду спать."
    $ try_times = 0;
    pause (16/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),1.5)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
