label e1211_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1212.nss"
    return
label e1211:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    $ persistent.meta_date += 1

    xy "\"Пожалуйста, верни Аой!\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/e12/1100010a01.opus"

    mx "\"Хо-хо? Ты так сильно хочешь увидеть Аой, да?\""

    xy "\"Да! Пожалуйста! Умоляю тебя!\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e12/1100020a01.opus"

    mx "\"...Думаю, раз ты уже так отчаялся... я позволю тебе потом повидаться с ней.\""

    xy "\"Правда?!\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/e12/1100030a01.opus"

    mx "\"Разве я стану тебе врать? А теперь доедай свой завтрак.\""

    "Она вежливо предупредила меня, и я сделал то, что она мне сказала."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
