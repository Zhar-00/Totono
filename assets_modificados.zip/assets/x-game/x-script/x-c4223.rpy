label c4223_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4231.nss"
    return
label c4223:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    scene expression ("cg/ev/"+imagename["evc4221アオイ眠り姫b"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    xy "\"...Ладно.\""
    "Если это то, чего она хочет, я не буду спорить."
    "У меня было такое чувство, будто... если я не дам ей то, чего она хочет, то она исчезнет и появится в каком-нибудь отдалённом мире."
    voice "voice/c42/2300010a02.opus"
    aoi "\"Буп-буп...\""
    voice "voice/c42/2300020a02.opus"
    aoi "\"Аой чувствует... твоё электричество...\""
    voice "voice/c42/2300030a02.opus"
    aoi "\"Заряд... заряд...\""
    voice "voice/c42/2300040a02.opus"
    aoi "\"Аой... так долго... хотела перезарядиться...\""
    voice "voice/c42/2300050a02.opus"
    aoi "\"Заряд... заряд...\""
    xy "\"Да, готов поспорить.\""
    xy "\"Перезаряжайся столько, сколько тебе надо.\""
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
