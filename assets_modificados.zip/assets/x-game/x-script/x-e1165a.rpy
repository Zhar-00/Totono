label e1165a_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010600_9_学校教室"]=True
    $ PreGameName = GameName
    return
label e1165a:
    hide 絵色黒
    $ renpy.music.play("ttb23_ic",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    with Dissolve(0.0/1000)

    xy "\"Ну же, работай!!!\""
    if (persistent.ejaculation > 99):
        $ persistent.ejaculation = 100;
    $ call_number_check = 99900000000 + persistent.god_number - input_number + persistent.ejaculation;
    if (input_number_str=="08091846920" or call_number_check==34302111 or call_number_check==29197057 or call_number_check==36562211 or call_number_check==15432729 or call_number_check==13273415 or call_number_check==52194054 or call_number_check==23113911 or call_number_check==49153011 or call_number_check==25403221 or call_number_check==52301936 or call_number_check==12502633 or call_number_check==31511813 or call_number_check==52293011 or call_number_check==55193213 or call_number_check==17332932 or call_number_check==50167033 or call_number_check==39591822 or call_number_check==12405417 or call_number_check==39415512 or call_number_check==40121927 or call_number_check==54344570 or call_number_check==22222251 or call_number_check==46121332 or call_number_check==19504612 or call_number_check==36454044 or call_number_check==34404649 or call_number_check==11315237 or call_number_check==35547283 or call_number_check==22351410 or call_number_check==17132712 or call_number_check==15125531):
        $ GameName = "e1166b.nss";
    else:
        $ GameName = "e1166a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
