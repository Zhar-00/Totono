label e2000_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2000:
    $ persistent.meta_date += 1
    python:
        from random import randrange
        jump_num = randrange(15)
        for i in range(15):
            if jump_num == i:
                nextpreparation = "e"+str(2111+10*i)+".nss"
    if persistent.eternal_day:
        $ GameName = "e2005.nss";
    elif persistent.meta_date == 7:
        $ GameName = "e2011.nss";
    elif persistent.meta_date == 30:
        $ GameName = "e2021.nss";
    elif persistent.meta_date >183:
        $ GameName = "e2031.nss";
    else:
        $ GameName = "e2005.nss";
    stop bgm fadeout 1
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
