label a2134_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a2135.nss"
    return
label a2134:
    hide 絵色黒 with dissolve
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010300_1_学校屋根_l"]+".jpg") as 絵背景 zorder 100 at center with Dissolve(1500.0/1000)
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a21/3400010a02.opus"
    aoi "Аой сегодня купила кучу пирожных."
    xy "И для чего ты их купила?"
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/3400020a02.opus"
    aoi "У них не было бутербродов."
    xy "Продолжай в том же духе, и Миюки собьёт с тебя всю спесь. Я ведь прав, Миюки?"
    hide StC with Dissolve(200.0/1000)
    pause (200/1000)
    $ sename = "se擬音_コミカル_キュピーン"
    play se sedict[sename]
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a21/3400030a01.opus"
    mx "......"
    xy "А-а-ай!"
    "У Миюки был такой взгляд, будто она уже собиралась отвести меня к гильотине."
    voice "voice/a21/3400040a01.opus"
    mx "......"
    "Она была крайне серьёзной."
    voice "voice/a21/3400050a02.opus"
    aoi "Миюки, из твоих глаз летят искры."
    xy "Ты опять на нас злишься?"
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shout")
    with Dissolve(200.0/1000)
    voice "voice/a21/3400060a01.opus"
    mx "Я НЕ злюсь!"
    "Кстати о дежавю... у меня также было такое чувство, будто однажды было то же самое..."
    "А, точно. Она расстроилась в тот день, когда Аой попросила её сгонять за мороженым."
    "…………"
    xy "Эй, эм..."
    xy "Ты, случаем... не на диете?"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a21/3400070a01.opus"
    mx "Ох, прошу прощения, у тебя какие-то ПРОБЛЕМЫ с тем, как я решила следить за своей фигурой?"
    "Было куда страшнее, когда она говорила таким идеально ровным тоном..."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a21/3400080a01.opus"
    mx "Ну да ладно, я не хотела показаться раздражённой."
    voice "voice/a21/3400090a01.opus"
    mx "Мне просто надо сделать кучу дел перед следующим выступлением. Разумеется, я хочу следить за своей фи—"
    voice "voice/a21/3400100a02.opus"
    aoi "Миюки, тебе нельзя есть сладости?"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a21/3400110a01.opus"
    mx "Не называй меня та—"
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    with Dissolve((0.0+0.0)/1000)
    with Dissolve(500.0/1000)
    $ sename = "se人体_動作_奪い取る"
    play se sedict[sename]
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/3400120a02.opus"
    aoi "Поняла!"
    "Аой встала на ноги и подняла руку в воздух."
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/a21/3400130a02.opus"
    aoi "Хья!"
    $ sename = "se擬音_コミカル_投げる"
    play se sedict[sename]
    voice "voice/a21/3400140a01.opus"
    mx "Что... Что ты, чёрт побери, делаешь?!"
    "Она просто скинула все свои пирожные с крыши!"
    "Мешок пролетел по идеальной дуге и скрылся с поля зрения."
    with Dissolve((500.0+1000.0)/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    voice "voice/a21/3400150a01.opus"
    mx "Т-ты понимаешь, насколько РАСТОЧИТЕЛЬНЫМ—"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/3400160a02.opus"
    aoi "Аой не будет это есть."
    voice "voice/a21/3400170a02.opus"
    aoi "Аой разделит твою боль. Для этого и нужны друзья."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_shout")
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_sigh")
    voice "voice/a21/3400180a01.opus"
    mx "Я же сказала, мы не... Ха-а."
    "Миюки вздохнула и покачала головой... но потом она улыбнулась."
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_smile")
    voice "voice/a21/3400190a01.opus"
    mx "Ладно, не важно."
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_pride")
    voice "voice/a21/3400200a01.opus"
    mx "Но если я опять увижу, как ты выбрасываешь еду, я буду ОЧЕНЬ недовольна, слышишь меня?"
    voice "voice/a21/3400210a02.opus"
    aoi "Буп-буп..."
    pause (800/1000)
    scene expression Solid("000000") as 絵色黒 zorder 5000 with dissolve
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
