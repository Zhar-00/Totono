label e0115_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label e0115:
    hide 絵色黒
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg900200_2_雰囲気街並み_l"]+".jpg") as 絵演遠投背景 zorder 1000 at truecenter
    show expression ("cg/ef/"+imagename["efbg屋上フェンス"]+".png") as 絵演遠投網 zorder 1010 at truecenter
    with Dissolve(0.0/1000)
    "Телефон пролетел сквозь воздух."
    "Он летел по абсолютно прямой, игнорирующей гравитацию линии, пока наконец не исчез с поля зрения."
    voice "voice/e01/1500010a01.opus"
    mx "\"Это был довольно хороший бросок, а?\""
    xy "\"Да...\""
    "Пока он летел с такой скоростью, я почти что подумал, что он сейчас разрушит ткань вселенной..."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    hide 絵演遠投背景
    hide 絵演遠投網
    with Dissolve(200.0/1000)
    voice "voice/e01/1500020a01.opus"
    mx "\"Ну а теперь, пошли домой?\""
    xy "\"Но Ютаро сказал—\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/e01/1500030a01.opus"
    mx "\"Мне придётся ему отказать.\""
    voice "voice/e01/1500040a01.opus"
    mx "\"Всё-таки это он пригласил меня сюда.\""
    xy "\"А... понятно...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e01/1500050a01.opus"
    mx "\"И мы так и не сказали остальным в классе, что мы встречаемся.\""
    "Миюки застенчиво посмотрела на пол."
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e01/1500060a01.opus"
    mx "\"Или о том, что мы живём вместе.\""
    if persistent.miyuki[1] == 0:
        voice "voice/e01/1500070a01.opus"
        mx "\"И прошла уже целая неделя.\""
    elif persistent.miyuki[1] == 1:
        voice "voice/e01/1500080a01.opus"
        mx "\"А потом прошло уже целых две недели.\""
    elif persistent.miyuki[1] == 2:
        voice "voice/e01/1500090a01.opus"
        mx "\"А потом - и целых три недели.\""
    xy "\"Нам всё равно придётся рассказать им об этом, наверное...\""
    voice "voice/e01/1500100a01.opus"
    mx "\"Я просто надеюсь, что я для тебя достаточно хороша...\""
    return
    return
label e0115_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(0.0/1000)
    menu:
        "Конечно":
            $ SetChoiceSelect = 0
        "Вовсе нет":
            $ SetChoiceSelect = 1
    if SetChoiceSelect == 0:
        $ persistent.miyuki_love += 1
        $ GameName = "e0116a.nss";
    elif SetChoiceSelect == 1:
        $ persistent.miyuki_love -= 1
        $ GameName = "e0116b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
