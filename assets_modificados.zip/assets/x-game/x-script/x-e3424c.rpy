label e3424c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e3424c:
    hide 絵色黒
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e34/24c00010b02.opus"

    kmsm "\"НО ВСЁ ЖЕ, [[ТЫ] НАХОДИШЬСЯ В ЦЕНТРЕ ВСЕЛЕННОЙ.\""
    voice "voice/e34/24c00020b02.opus"

    kmsm "\"ЕСЛИ [[ТЫ] ПОДТВЕРЖДАЕШЬ СВОЁ НАМЕРЕНИЕ, [[ТЫ] МОЖЕШЬ ПЕРЕДАТЬ [[СВОЙ] СИГНАЛ В ЛЮБОЕ ВРЕМЯ.\""
    voice "voice/e34/24c00030b02.opus"

    kmsm "\"...ЕСЛИ СУБЪЕКТ САМ ТОГО ПОЖЕЛАЕТ.\""
    $ sename = "se物体_携帯_繋がる"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")
    pause (2000/1000)
    $ sename = "se物体_携帯_圏外"
    play se sedict[sename]
    pause (2000/1000)
    play voc "e34/24c00040b04"
    xy "......"

    xy "\"...Похоже, они завершили вызов.\""
    show expression ("cg/ef/"+imagename["efbg空汎用満月"]+".jpg") as 絵演月背景 zorder 1010 at truecenter
    show expression ("cg/ef/"+imagename["efbg空汎用満月_雲"]+".png") as 絵演月背景雲:
        pos (1010,-400)
        linear 50 xpos 0
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    pause (300/1000)

    "Опустив плечи, я безнадёжно уставился на ночное небо."

    "Луна спокойно освещала меня."

    "В том телефонном звонке не было смысла."

    "Господи, Я ни черта не понимаю. Что я вообще делаю?"

    "И всё же, что-то в моей голове подсказывало мне, что я должен—"
    $ sename = "se物体_ドア鉄_開く02"
    play se sedict[sename]
    pause (800/1000)
    hide 絵演月背景
    hide 絵演月背景雲
    show expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")
    with Dissolve(500.0/1000)
    voice "voice/e34/24c00050a01.opus"
    mx "\"......!!!\""

    xy "\"А?..\""
    voice "voice/e34/24c00060a01.opus"

    mx "\"Шиничи—!!!\""
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]
    voice "voice/e34/24c00070a01.opus"

    mx "\"Ха-а, ха-а, ха-а!..\""

    "Тяжело дыша, Миюки взбиралась по лестнице—"
    stop se fadeout (150.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb02",channel = "bgm", if_changed = True)
    voice "voice/e34/24c00080a01.opus"
    mx "\"Шиничи!!!\""
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)

    xy "\"Воу!!!\""

    "Она так быстро заключила меня в свои объятия, что чуть было не повалила меня с ног."

    xy "\"Осторожнее! Успокойся, балда!\""
    voice "voice/e34/24c00090a01.opus"

    mx "\"Спасибо!..\""
    voice "voice/e34/24c00100a01.opus"

    mx "\"Спасибо, спасибо, спасибо!!!..\""
    voice "voice/e34/24c00110a01.opus"

    mx "\"Спасибо, что остался!\""
    voice "voice/e34/24c00120a01.opus"

    mx "\"За то, что остался здесь... в этом мире со мной...\""
    voice "voice/e34/24c00130a01.opus"

    mx "\"Спасибо... Спасибо тебе большое!..\""

    xy "\"В-воу, успокойся! Не плачь— М-м-мф?!\""
    voice "voice/e34/24c00140a01.opus"

    mx "\"М-м-м— м-м-мф— м-м— м-м-м-м—!\""
    voice "voice/e34/24c00150a01.opus"

    mx "\"Я люблю ТЕБЯ— правда люблю—! М-м-м-м— м-мф— м-м— м-м-м—!\""
    voice "voice/e34/24c00160a01.opus"

    mx "\"Я люблю ТЕБЯ— очень, очень сильно—!\""
    voice "voice/e34/24c00170a01.opus"

    mx "\"Так что, пожалуйста— умоляю ТЕБЯ— не бросай меня—!\""
    voice "voice/e34/24c00180a01.opus"

    mx "\"Останься со мной— на веки вечные— М-м-мф!\""
    with Dissolve(500.0/1000)

    "Она страстно целовала меня под звёздным небом."

    "Это мгновение длилось, казалось бы, целую вечность..."

    "Вечность между нами двумя."
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (2000/1000)
    if (persistent.aoi_call_miss == True):
        $ GameName = "e3424f.nss";
    else:
        $ GameName = "e3424g.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
