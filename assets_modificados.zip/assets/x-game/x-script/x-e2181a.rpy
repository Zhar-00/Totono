label e2181a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2181a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    $ sename = "se人体_動作_投球02"
    play se sedict[sename]
    $ sename = "se人体_動作_バッティング02"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白
    pause (50/1000)
    hide 絵色白
    with Dissolve(600.0/1000)

    "Как и следовало ожидать."

    "Бейсбольный мяч столкнулся с моей битой и взлетел, нарисовав бледную арку в ночном небе."
    $ sename = "se物体_ネット_ホームラン"
    play se sedict[sename]
    pause (800/1000)
    xy "\"О да!\""
    voice "voice/e21/81a00010a01.opus"

    mx "\"Хоум-ран?..\""

    "Он попал прямо в центр мишени."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/e21/81a00020a01.opus"

    mx "\"Как ты узнал, что я запланировала для последнего мяча?\""

    xy "\"Я тебя тогда учил такой подаче, помнишь?\""

    xy "\"И я подумал, что ты пойдёшь таким путём, чтобы заставить меня нанести удар.\""
    voice "voice/e21/81a00030a01.opus"

    mx "\"Ты помнишь...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/81a00040a01.opus"

    mx "\"...Ну ладно.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e21/81a00050a01.opus"

    mx "\"Ты выиграл, честно и справедливо. Я сделаю всё, что ты попросишь.\""
    voice "voice/e21/81a00060a01.opus"

    mx "\"Так чего ты хочешь от меня?\""

    "Чего я попрошу, хм?"

    "Ну, это БЫЛА маленькая победа..."

    "Разумеется, мне сойдёт с рук попросить что-то немного дерзкое..."

    "И в таком случае, мне на ум приходило только одно..."
    menu:
        "Я хочу Миюки":
            $ SetChoiceSelect = 0
        "Я хочу Аой":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ persistent.miyuki_love += 1
        $ GameName = "e2182a.nss";
    elif SetChoiceSelect==1:
        $ persistent.miyuki_love -= 1
        $ GameName = "e2182b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
