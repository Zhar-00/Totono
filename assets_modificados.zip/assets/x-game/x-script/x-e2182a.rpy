label e2182a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2182a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(0.0/1000)

    xy "\"Я хочу тебя, Миюки.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/e21/82a00010a01.opus"
    mx "\"А?..\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/e21/82a00020a01.opus"

    mx "\"М-меня?..\""
    $ sename = "se人体_動作_たたらを踏む"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Её лицо залилось краской, и она начала колебаться."

    xy "\"В-воу... Ты в порядке?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/82a00030a01.opus"

    mx "\"П-прости... Просто ты застал меня врасплох, только и всего.\""

    xy "\"А... Прости за это. Я беру свои слова обратно—\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/e21/82a00040a01.opus"

    mx "\"Н-нет!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e21/82a00050a01.opus"

    mx "\"Я... я, наверное, подумала о том же, так что...\""

    xy "\"О-ох...\""

    "От её едва слышимого признания я даже сильно вдохнул."

    "Я знаю, что она сейчас нервничает, но поверьте, я и сам нервничаю."
    xy "\"Миюки..\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e21/82a00060a01.opus"
    mx "\"Шиничи?..\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Я подошёл поближе—"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/e21/82a00070a01.opus"

    mx "\"М-мы не можем! Не здесь!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/e21/82a00080a01.opus"

    mx "\"Мне нужно время, чтобы эмоционально подготовиться к этому... да и к тому же, я вся потная, и—\""
    voice "voice/e21/82a00090a01.opus"

    mx "\"—и хозяин сейчас здесь!\""

    xy "\"А-а, да... Точно...\""

    "Она такая милая, я чуть было не потерял контроль... но она права. Мы не можем заниматься этим здесь."

    "...Ну и ладно."
    if (persistent.world_recreate or persistent.miyuki_sex1 or persistent.EmotionalMusic > 3 ):
        $ GameName = "e2183a.nss";
    else:
        $ GameName = "e2183b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
