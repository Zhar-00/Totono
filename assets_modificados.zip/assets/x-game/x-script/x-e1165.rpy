label e1165_MAIN:
    call expression GameName
    $ persistent.imagelog["eve1165アオイサヨナラa"]=True
    $ persistent.imagelog["eve1165アオイサヨナラb"]=True
    $ PreGameName = GameName
    $ GameName = "e1165b.nss"
    $ roof = False;
    return
label e1165:
    scene expression ("cg/bg/"+imagename["bg010200_9_学校屋上"]+".jpg")
    xy "\"Аой?..\""
    xy "\"Аой! АО-О-О-ОЙ—!!!\""
    "Мой крик раздавался эхом, но напрасно."
    "Она просто... исчезла."
    $ persistent.miyuki_decision3 = True;
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
