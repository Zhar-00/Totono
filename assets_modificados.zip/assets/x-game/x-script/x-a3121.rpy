label a3121_MAIN:
    call expression GameName
    $ persistent.imagelog["eva0113アオイ送信中a"]=True
    $ persistent.imagelog["bg010300_2_学校屋根"]=True
    if persistent.sim_stolen == True:
        $ GameName = "b3122b.nss"
    else:
        $ GameName = "a3122a.nss"
    return
label a3121:
    scene 絵色黒
    hide 絵色黒
    $ sename = "se人体_足音_階段学校上がる01"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010100_2_学校階段"]+".jpg")
    with Dissolve(2000.0/1000)
    "После занятий, я поднялся на крышу, чтобы встретиться с остальными."
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    $ sename = "se物体_ドア屋上_鍵開ける01"
    play se sedict[sename]
    pause (1000/1000)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    with Dissolve(500.0/1000)
    pause (500/1000)
    voice "voice/a31/2100010a02.opus"
    aoi "Буп-буп..."
    show expression ("cg/ev/"+imagename["eva0113アオイ送信中a"]+".jpg") as 絵専 zorder 1100 at center
    with Dissolve(1000.0/1000)
    pause (500/1000)
    "Я развернулся, и, разумеется, Аой сидела там наверху и снова «обменивалась данными»."
    "Я поднялся по лестнице."
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    hide 絵専
    pause (500/1000)
    show expression ("cg/bg/"+imagename["bg010300_2_学校屋根"]+".jpg")
    hide 絵色黒
    with Dissolve(500.0/1000)
    stop se fadeout (500.0/1000)
    xy "Бог вообще отвечает на твои звонки?"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
