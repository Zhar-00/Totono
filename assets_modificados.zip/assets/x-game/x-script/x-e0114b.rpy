label e0114b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e0115.nss"
    return
label e0114b:
    hide 絵色黒
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_恋人_happy")
    with Dissolve(0.0/1000)

    xy "\"О чём ты говоришь? Просто сдай его в ломбард.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e01/14b00010a01.opus"

    mx "\"Я хочу избавиться от него как можно скорее.\""

    xy "\"Не сме— Эй, стой!\""
    hide StC with Dissolve(200.0/1000)
    $ sename = "se人体_動作_奪い取る"
    play se sedict[sename]

    "Она забрала телефон у меня—"
    voice "voice/e01/14b00020a01.opus"

    mx "\"ХЬЯ-А!!!\""
    $ sename = "se人体_動作_投げる"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白
    pause (30/1000)
    show expression ("cg/bg/l/"+imagename["bg900200_2_雰囲気街並み_l"]+".jpg") as 絵演遠投背景 zorder 1000 at truecenter
    show expression ("cg/ef/"+imagename["efbg屋上フェンス"]+".png") as 絵演遠投網 zorder 1010 at truecenter
    hide 絵色白
    with Dissolve(1500.0/1000)
    pause (300/1000)

    "—и швырнула его через ограждение."

    xy "\"...О боже...\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
