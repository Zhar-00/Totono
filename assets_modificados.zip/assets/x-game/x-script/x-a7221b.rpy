label a7221b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a7222.nss"
    return
label a7221b:
    hide 絵色黒
    $ renpy.music.play("ttb08",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030301_3_自宅リビング消灯"]+".jpg")
    show expression Solid("000000") as 絵演色黒
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    voice "voice/a72/21b00010a01.opus"

    mx "\"Всё-таки эта наша судьба.\""

    xy "\"Судьба?..\""
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Наверное, можно и так сказать..."
    hide 絵演色黒
    with Dissolve(1000.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
