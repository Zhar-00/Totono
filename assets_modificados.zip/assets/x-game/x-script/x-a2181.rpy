label a2181_MAIN:
    call expression GameName
    $ persistent.imagelog["bg040300_2_街商店街"]=True
    $ persistent.imagelog["bg070100_2_雑貨店店内"]=True
    if no_call == True and persistent.a_route == True:
        $ GameName = "c2182.nss"
    else:
        $ GameName = "a2182.nss"
    return
label a2181:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg040300_2_街商店街_l"]+".jpg") as 絵背景 zorder 100:
        pos (-600,-330)
    with Dissolve(1000.0/1000)
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/a21/8100010a02.opus"
    aoi "Мы пришли."
    hide StC with Dissolve(200.0/1000)
    "Она остановилась у магазина на окраине торгового района за железнодорожным вокзалом."
    "«Кошачья мята», сувенирный магазин для любителей котов."
    "На витрине можно было разглядеть кошачьи статуэтки, плюшевых котов, часы в виде котов, занавески с кошачьим принтом... и так далее, и так далее."
    "Вдобавок к сувенирам в кошачьей стилистике, они, похоже, продают также и принадлежности для владельцев котов. Игрушки, корм и прочее."
    xy "Здесь просто изобилие кошек, да?"
    "Мне уже интересно, как это здание выглядит изнутри..."
    "И как только я протянул руку к дверной ручке в форме хвоста..."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a21/8100020a02.opus"
    aoi "Буп-буп... Миюки?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/a21/8100030a01.opus"
    mx "......"
    voice "voice/a21/8100040a02.opus"
    aoi "Миюки, ты идёшь?"
    voice "voice/a21/8100050a01.opus"
    mx "......"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a21/8100060a02.opus"
    aoi "Она не слышит..."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/a21/8100070a02.opus"
    aoi "Что-то не так?"
    xy "Н-не спрашивай меня..."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    show expression Solid("000000") as 絵色黒上 zorder 4900
    with Dissolve((0.0+300.0)/1000)
    pause (200/1000)
    hide 絵色黒
    with Dissolve(800.0/1000)
    $ St("MR",2300,30,0,"bu曽根美雪_制服_腕組み_sad")
    voice "voice/a21/8100080a01.opus"
    mx "Я сейчас должна сосредоточиться на своём выступлении. Простите, но мне надо идти."
    $ St("ML",2300,-30,0,"bu向日アオイ電波_制服_通常_sad")
    voice "voice/a21/8100090a02.opus"
    aoi "...Буп-буп..."
    xy "То есть, ты хочешь, чтобы мы с Аой зашли туда одни?"
    $ St("MR",2300,30,0,"bu曽根美雪_制服_腕組み_shy")
    voice "voice/a21/8100100a01.opus"
    mx "Д-делайте, что хотите! Мне без разницы!"
    $ St("ML",2300,-30,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/8100110a02.opus"
    aoi "Это не хорошо. Мы все должны идти вместе."
    xy "А куда именно мы идём, кстати говоря?"
    $ St("ML",2300,-30,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/8100120a02.opus"
    aoi "В магазин под названием «Кошачья мята»."
    xy "Ни разу не слышал о нём."
    $ St("ML",2300,-30,0,"bu向日アオイ電波_制服_通常_shout")
    voice "voice/a21/8100130a02.opus"
    aoi "Он открылся на прошлой неделе. Они там продают кучу кошачьих вещей."
    $ St("MR",2300,30,0,"bu曽根美雪_制服_通常_normal")
    voice "voice/a21/8100140a01.opus"
    mx "Пошли."
    xy "Стоп, что? А как же твоя сосредоточенность на—"
    $ St("MR",2300,30,0,"bu曽根美雪_制服_通常_shout")
    voice "voice/a21/8100150a01.opus"
    mx "ПОШЛИ!"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    hide 絵色黒上
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg040300_2_街商店街_l"]+".jpg") as 絵背景 zorder 100:
        pos (-600,-330)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    hide 絵色黒
    with Dissolve(800.0/1000)
    xy "Должно быть, ей очень нравятся коты, а?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/8100160a02.opus"
    aoi "Похоже на то."
    hide StC with Dissolve(200.0/1000)
    voice "voice/a21/8100170a01.opus"
    mx "......"
    "Миюки очарованно смотрела на витрину... это была её поразительно женственная сторона, которую она обычно никому не показывала."
    xy "Земля вызывает Миюки!"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_fear")
    with Dissolve(200.0/1000)
    voice "voice/a21/8100180a01.opus"
    mx "А-а!"
    voice "voice/a21/8100190a01.opus"
    mx "Т-ты напугал меня!"
    xy "Мы заходим внутрь!"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_angry")
    with Dissolve(200.0/1000)
    voice "voice/a21/8100200a01.opus"
    mx "Стой! Я ещё эмоционально не подготовилась!"
    xy "Очень жаль. А теперь пошли!"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a21/8100210a01.opus"
    mx "Ай! Эй! Притормози!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Я схватил Миюки за рукав и затянул её в магазин следом за Аой."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg070100_2_雑貨店店内"]+".jpg")
    $ st_timezone = "昼"
    $ sename = "se物体_カウベル_鳴る"
    play se sedict[sename]
    pause (1000/1000)
    hide 絵背景
    hide 絵色黒
    with Dissolve(800.0/1000)
    voice "voice/a21/8100220a02.opus"
    aoi "Буп-буп... Поразительно..."
    with Dissolve((800.0+1000.0)/1000)
    "Как только мы зашли внутрь, Аой пошла прямиком к полкам."
    "Как и следовало ожидать, в «Кошачьей мяте» было полным полно всевозможных вещей в кошачьей стилистике."
    "Плюшевые игрушки, статуэтки, настенные часы, светильники на потолке, и даже напольная плитка... в поле моего зрения были сплошные коты."
    "Звон колокольчика, который раздался над нами, как только мы зашли внутрь, возможно, взялся из кошачьего ошейника или ещё что."
    hide 絵背景
    with Dissolve(1000.0/1000)
    xy "Они здесь и правда постарались на славу..."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_gag")
    with Dissolve(200.0/1000)
    voice "voice/a21/8100230a01.opus"
    mx "...Я так счастлива..."
    xy "Эй, Миюки, ты там в порядке?"
    voice "voice/a21/8100240a01.opus"
    mx "Кажется, у меня закружилась голова..."
    voice "voice/a21/8100250a01.opus"
    mx "Я... не знаю, смогу ли я с этим совладать..."
    xy "Воу-воу, успокойся! С каких это пор ты так помешалась на котах?"
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a21/8100260a01.opus"
    mx "Я ничего не могу с этим поделать..."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_gag")
    with Dissolve(200.0/1000)
    voice "voice/a21/8100270a01.opus"
    mx "...Они просто очаровательны..."
    voice "voice/a21/8100280a02.opus"
    aoi "Миюки тоже очаровательна."
    "Согласен."
    "В последнее время мне только доводилось видеть её в режиме «королева пчёл», но эта её манера поведения была ближе к той Миюки, которую я знал раньше."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    voice "voice/a21/8100290a02.opus"
    aoi "Поняла!"
    with Dissolve((800.0+1000.0)/1000)
    xy "В чём дело?"
    $ sename = "se擬音_コミカル_ヒョコ"
    play se sedict[sename]
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_密着_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/8100300a02.opus"
    aoi "Как тебе такое?"
    xy "Воу!"
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_normal")
    with Dissolve(200.0/1000)
    "Аой выскочила из-за занавески примерочной, надев на себя... кошачью пижаму?.."
    xy "Ничего себе, подруга. Она на тебе ПРЕКРАСНО смотрится."
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a21/8100310a02.opus"
    aoi "А что ты думаешь, Миюки?"
    hide 絵背景
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_think")
    $ St("MR",300,0,0,"st曽根美雪_制服_病み_ero")
    with Dissolve(500.0/1000)
    voice "voice/a21/8100320a01.opus"
    mx "......"
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_think")
    voice "voice/a21/8100330a02.opus"
    aoi "Миюки?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_sad")
    voice "voice/a21/8100340a01.opus"
    mx "П-прости! Ты сейчас перегрузила мне мозг!"
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_密着_normal")
    voice "voice/a21/8100350a02.opus"
    aoi "Чем?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_sad")
    voice "voice/a21/8100360a01.opus"
    mx "Эй! Перестань! Не смотри на меня так!"
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_think")
    voice "voice/a21/8100370a02.opus"
    aoi "Буп-буп?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_angry")
    voice "voice/a21/8100380a01.opus"
    mx "А-а-ах!"
    "И после этого Неко-Аой нанесла финишный удар."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_sad")
    voice "voice/a21/8100390a02.opus"
    aoi "Тебе больно? Аой тебе поможет."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_gag")
    voice "voice/a21/8100400a01.opus"
    mx "О боже... я умираю..."
    voice "voice/a21/8100410a01.opus"
    mx "Я... мертва..."
    hide StMR with Dissolve(200.0/1000)
    "Тело Миюки качалось из стороны в сторону..."
    $ sename = "se物体_棚_倒れる"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_surprise")
    pause (500/1000)
    voice "voice/a21/8100420a02.opus"
    aoi "Миюки?"
    xy "Вот дерьмо!"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1500.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    pause (500/1000)
    "...И она упала, снеся вместе с собой полку."
    "По крайней мере, она отрубилась с улыбкой, наверное..."
    pause (500/1000)
    hide 絵色黒
    with Dissolve(1500.0/1000)
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_sad")
    voice "voice/a21/8100430a01.opus"
    mx "Я... мне очень жаль... я не знаю, о чём я думала..."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_sad")
    voice "voice/a21/8100440a02.opus"
    aoi "Аой тоже жаль..."
    "Внимание: Кошачья пижама всё ещё была на ней."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_angry")
    voice "voice/a21/8100450a01.opus"
    mx "Я... я говорила тебе, эта одежда опасна!"
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_normal")
    voice "voice/a21/8100460a02.opus"
    aoi "Тогда Аой не купит её."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_normal")
    voice "voice/a21/8100470a01.opus"
    mx "Но ты должна."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_surprise")
    voice "voice/a21/8100480a02.opus"
    aoi "А? Но—"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_shout")
    voice "voice/a21/8100490a01.opus"
    mx "Не волнуйся за меня. Просто купи её!"
    xy "Похоже, Миюки очень понравилась эта пижама."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_think")
    voice "voice/a21/8100500a02.opus"
    aoi "Правда?"
    xy "Абсолютно."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_shy")
    voice "voice/a21/8100510a02.opus"
    aoi "Хорошо. Тогда Аой КУПИТ её!"
    $ sename = "se擬音_コミカル_走る"
    play se sedict[sename]
    hide StML with Dissolve(200.0/1000)
    "И после этого она побежала к кассе."
    show expression ("cg/bg/m/"+imagename["bg070100_2_雑貨店店内_m"]+".jpg") as 絵背景 zorder 100:
        pos (-440,-170)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)
    xy "Вот те раз. Ты и правда с ума сходишь от котов, да?"
    voice "voice/a21/8100520a01.opus"
    mx "......"
    xy "М-м? В чём дело, Миюки?"
    voice "voice/a21/8100530a01.opus"
    mx "Смотри."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Миюки показала пальцем на заколку в форме кота, лежащую на витрине."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
