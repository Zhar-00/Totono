label a2135_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a2136.nss"
    return
label a2135:
    hide 絵色黒
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010300_1_学校屋根_l"]+".jpg") as 絵背景 zorder 100 at center with Dissolve(1500.0/1000)
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    $ St("C",300,0,0,"bu向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/a21/3500010a02.opus"
    aoi "До дна!"
    hide StC with Dissolve(200.0/1000)
    $ sename = "se物体_缶_開ける"
    play se sedict[sename]
    pause (1000/1000)
    voice "voice/a21/3500020a02.opus"
    aoi "Гл-л-л-л... гл-л-л-л... гл-л-л-л..."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a21/3500030a02.opus"
    aoi "Фух!.."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/3500040a02.opus"
    aoi "Вот и всё."
    xy "Не пойми меня неправильно, я рад, что этот напиток тебе очень нравится, но..."
    show expression ("cg/ef/"+imagename["efbgヤバトマ"]+".jpg") as 絵画像 zorder 1000 at center
    with Dissolve((800.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    xy "Это всё, что ты принесла с собой на обед?"
    voice "voice/a21/3500050a02.opus"
    aoi "Ага."
    "Аой принесла с собой на обед только одну банку Ябалея."
    hide 絵画像
    with Dissolve(500.0/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    voice "voice/a21/3500060a01.opus"
    mx "Твои родители не дают тебе карманных денег, чтобы взять что-нибудь в школе?"
    voice "voice/a21/3500070a02.opus"
    aoi "Не-а."
    xy "Она в последнее время живёт в манга-кафе."
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    voice "voice/a21/3500080a01.opus"
    mx "Манга-кафе?!"
    voice "voice/a21/3500090a02.opus"
    aoi "Ага."
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    voice "voice/a21/3500100a01.opus"
    mx "Я и понятия не имела..."
    "Миюки затихла и упала на землю."
    "Она, похоже, что-то обдумывала."
    "Не то, чтобы я винил её за это. Проблемы в семье Аой были довольно серьёзными."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/3500110a02.opus"
    aoi "Буп-буп?.."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    voice "voice/a21/3500120a02.opus"
    aoi "Шиничи, Миюки сердится на меня?"
    xy "М-м, сомневаюсь, но—"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_shout")
    voice "voice/a21/3500130a01.opus"
    mx "Муко-сан! Если у тебя будут какие-нибудь проблемы, я бы хотела, чтобы ты пришла поговорить со мной."
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_normal")
    voice "voice/a21/3500140a01.opus"
    mx "Не знаю, будет ли у меня решение этой проблемы, но... я хотя бы буду рада выслушать тебя."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/3500150a02.opus"
    aoi "Выслушать меня?"
    voice "voice/a21/3500160a01.opus"
    mx "Я даже дам тебе какой-нибудь совет."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    voice "voice/a21/3500170a02.opus"
    aoi "Буп-буп... буп-буп... буп-буп-буп..."
    xy "Но тебе не стоит говорить об этом, если не хочешь."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_挙手_shout")
    voice "voice/a21/3500180a02.opus"
    aoi "Поняла! Я просто вспомнила кое-что."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/3500190a02.opus"
    aoi "Однажды Аой чуть было не выгнали из кафе."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    voice "voice/a21/3500200a01.opus"
    mx "Ого, ну и козлы! А что случилось?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/3500210a02.opus"
    aoi "Отключение электроэнергии."
    voice "voice/a21/3500220a01.opus"
    mx "У них электричество отключилось?"
    voice "voice/a21/3500230a02.opus"
    aoi "Потому что Аой вставила заколку в розетку."
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_shout")
    voice "voice/a21/3500240a02.opus"
    aoi "БЗЫК!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_sigh")
    voice "voice/a21/3500250a01.opus"
    mx "...Звучит так, будто ты это заслужила."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/3500260a02.opus"
    aoi "Буп-буп?.."
    "О боже, она сделала это в КАФЕ?.."
    pause (800/1000)
    scene expression Solid("000000") as 絵色黒 zorder 5000 with dissolve
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
