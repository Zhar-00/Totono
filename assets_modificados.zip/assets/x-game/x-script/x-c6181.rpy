label c6181_MAIN:
    call expression GameName
    $ persistent.imagelog["bg100200_2_マンション外廊下"]=True
    $ persistent.imagelog["bg110200_3_マンション玄関鍵開け"]=True
    $ PreGameName = GameName
    if cat_wave == False:
        $ GameName = "d6182.nss"
    else:
        $ GameName = "c6182.nss"
    return
label c6181:
    hide 絵色黒
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg100200_2_マンション外廊下"]+".jpg")
    $ st_timezone = "昼"
    $ sename = "se物体_エレベーター_開く"
    play se sedict[sename]
    pause (600/1000)
    hide 上背景
    hide 絵色黒
    with Dissolve(500.0/1000)
    pause (1000/1000)
    "Лифт остановился, и двери распахнулись."
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    "В коридоре было тихо и безжизненно, за исключением нас."
    "Мы пробирались по коридору, стараясь не издавать лишний шум."
    "А потом Ютаро остановил нас перед одной дверью."
    "Квартира 804."
    pause (500/1000)
    $ sename = "se物体_鍵束_鳴る"
    play se sedict[sename]
    pause (1000/1000)
    $ St("C",300,0,0,"st曙雄太郎_私服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c61/8100010b01.opus"
    xtl "\"Теперь ты за главного.\""
    "Ключ от двери свисал с его пальца."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(500.0/1000)
    voice "voice/c61/8100020a01.opus"
    mx "\"Слушай очень внимательно, Шиничи.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c61/8100030a01.opus"
    mx "\"Ещё не слишком поздно. Мы всё ещё можем вернуться.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c61/8100040a01.opus"
    mx "\"В общем... Ты уверен, что хочешь этого?\""
    with Dissolve(0.0/1000)
    hide StC with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)
    pause (500/1000)
    "Я хотел верить в Аой."
    "Её словам..."
    "Её слезам..."
    "Чёрт, я всё ещё отчаянно верю ей."
    "Но Миюки права."
    "Я ревнивый парень."
    "Я не могу позволить любимой женщине изменять мне с кем-то другим."
    $ sename = "se物体_鍵束_受け取る"
    play se sedict[sename]
    pause (300/1000)
    "Я взял ключ у Ютаро."
    "Он был холодным и тяжёлым, и он прилип к моей коже."
    "Моя рука тряслась."
    "Но обратной дороги уже нет."
    "Что бы меня не ждало за этой дверью..."
    "Смогу ли я принять реальность того, что я там увижу, или нет..."
    "Возложив все свои надежды и страхи на ключ, я вставил его в замок."
    "Я медленно и спокойно провернул ключ."
    $ sename = "se物体_ドアマンション_鍵開ける03"
    play se sedict[sename]
    pause (3500/1000)
    $ sename = "se物体_ドアマンション_開く"
    play se sedict[sename]
    pause (1500/1000)
    "И замок так же медленно и спокойно открылся."
    pause (1000/1000)
    show expression ("cg/bg/"+imagename["bg110200_3_マンション玄関鍵開け"]+".jpg")
    with Dissolve(800.0/1000)
    pause (1000/1000)
    xy "\"......\""
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    "Мы молча вошли в квартиру."
    show expression ("cg/bg/"+imagename["bg110600_3_マンション台所"]+".jpg")
    with Dissolve(800.0/1000)
    pause (1000/1000)
    "Слабое перемещение наших шагов звучало оглушительным образом."
    stop se fadeout (150.0/1000)
    "Я затаил дыхание, схватился за грудь, и позволил своим ногам нести меня вперёд—"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
