label e2167_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2167:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/6700010a01.opus"

    mx "\"Я буду хранить её.\""

    xy "\"Ты её не будешь носить?\""
    voice "voice/e21/6700020a01.opus"

    mx "\"Нет, на мне бы она не очень смотрелась. Но с другой стороны...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e21/6700030a01.opus"

    mx "\"Я просто рада, что ты решил купить для меня что-нибудь.\""

    "Её улыбка была чертовски милой..."
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    $ GameName = "e3111.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
