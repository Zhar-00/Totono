label c4153_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4161.nss"
    return
label c4153:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    with Dissolve(1000.0/1000)

    xy "\"...Эй, Иру?\""

    xy "\"В конце концов, я к этому привыкну, верно?\""
    play voc "c41/5300010b04"

    "Но котёнок Аой просто спокойно лакал своё молоко."
    stop bgm fadeout (3000.0/1000)
    $ EyeCatchIn(2000.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
