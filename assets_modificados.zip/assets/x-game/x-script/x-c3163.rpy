label c3163_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label c3163:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(0.0/1000)

    xy "\"Мы сейчас говорим об Аой. Она бы ни за что не пошла домой к своим родителям.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/c31/6300010a01.opus"

    mx "\"Ну, а у тебя есть ещё идеи, где искать? Мы можем бесцельно бродить по городу, сколько захотим, но это только будет пустой тратой времени.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/c31/6300020a01.opus"

    mx "\"Мы должны просто разойтись.\""
    return
    return
label c3163_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(0.0/1000)
    menu:
        "Сдаться":
            $ SetChoiceSelect = 0
        "Не сдаваться":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "d3163.nss"
    elif SetChoiceSelect==1:
        $ GameName = "c3164.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
