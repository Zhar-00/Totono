label a1121_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a1122.nss"
    return
label a1121:
    $ sename = "se環境_ガヤ_教室授業中L"
    play se sedict[sename]
    pause (1000/1000)
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    "Во время урока..."
    show expression ("cg/ef/"+imagename["efbg雄太郎のスマフォ"]+".jpg") as 絵演効果 zorder 100 at center
    with Dissolve((0.0+1000.0)/1000)
    "Используя свою тетрадь как прикрытие, я незаметно достал телефон брата Ютаро и запустил игру."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
