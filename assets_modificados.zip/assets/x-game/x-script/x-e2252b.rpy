label e2252b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2253.nss"
    return
label e2252b:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg090100_3_コンビニ店内"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(0.0/1000)

    xy "\"Я правда сомневаюсь, что мы должны...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/e22/52b00010a01.opus"

    mx "\"А, понимаю... Слишком неловко, да?\""

    xy "\"Дело не в этом, просто...\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (200/1000)
    $ St("C",300,0,0,"st曙雄太郎_バイト_通常_cry")
    with Dissolve(200.0/1000)
    voice "voice/e22/52b00020b01.opus"

    xtl "\"Умри... УМРИ... Хмф! Хмф! ХМ-М-МФ!!!\""

    "Мне вряд ли хватит смелости взять её за руку, когда Ютаро так пилит меня своим взглядом..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
