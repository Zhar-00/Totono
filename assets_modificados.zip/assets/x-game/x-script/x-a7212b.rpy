label a7212b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a7213.nss"
    return
label a7212b:
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    with Dissolve(0.0/1000)
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失e"]+".jpg") as 絵捏造窓絵専上 zorder 1105 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/12b00010a01.opus"
    mx "\"А теперь... трахнешь ли ты меня снова?\""
    xy "\"Снова?\""
    voice "voice/a72/12b00020a01.opus"
    mx "\"Не важно. Забудь, что я сказала.\""
    voice "voice/a72/12b00030a01.opus"
    mx "\"Просто наполни меня своим семенем...\""
    "По её просьбе, я взял свой член одной рукой и подвёл его к её проходу."
    "А потом я начал входить в неё—"
    voice "voice/a72/12b00040a01.opus"
    mx "\"Расслабься, Шиничи.\""
    xy "\"А?..\""
    voice "voice/a72/12b00050a01.opus"
    mx "\"Чуть повыше.\""
    xy "\"А-а... Ладно...\""
    "Всякий раз, когда я где-то лажаю... мне становится неловко..."
    voice "voice/a72/12b00060a01.opus"
    mx "\"Нервничаешь, да?\""
    xy "\"Ну, да, конечно...\""
    voice "voice/a72/12b00070a01.opus"
    mx "\"Поцелуй меня.\""
    "Её шёпот соблазнял меня."
    voice "voice/a72/12b00080a01.opus"
    mx "\"Поцелуй меня, и я постараюсь всё уладить.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
