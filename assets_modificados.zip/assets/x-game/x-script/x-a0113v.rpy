label a0113v_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ AllSaveDelete()
    $ persistent.complete = True
    $ renpy.quit(relaunch=True)
label a0113v:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename['bg010200_2_学校屋上']+".jpg")
    $ sename = "se物体_携帯_発信待機L"
    play se sedict[sename]
    pause (1400/1000)
    pause (800/1000)
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]
    pause (5000/1000)
    $ sename = "se物体_携帯_繋がる"
    play se sedict[sename]
    image 絵板世界改変 = im.MatrixColor("cg/bg/"+imagename['bg010200_2_学校屋上']+".jpg",im.matrix.invert())
    show 絵板世界改変:
        zoom 1.02
    $ renpy.pause(delay = 0.2)
    hide 絵板世界改変
    $ renpy.pause(delay = 0.3)
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    voice "voice/a01/13v00010b02.opus"
    bm "ЧИТ-КОД ПОДТВЕРЖДЁН."
    "И тут я услышал голос на другом конце линии."
    voice "voice/a01/13v00020b02.opus"
    bm "ПОДГОТОВКА К ПРИНУДИТЕЛЬНОМУ ОБНОВЛЕНИЮ ВСЕЛЕННОЙ."
    xy "Обновлению... вселенной?.."
    voice "voice/a01/13v00030b02.opus"
    bm "ЭТО ОБНОВЛЕНИЕ НЕОБРАТИМО. ПОСЛЕ ЕГО ЗАВЕРШЕНИЯ ОБЫЧНАЯ ИГРА СТАНЕТ НЕДОСТУПНОЙ."
    voice "voice/a01/13v00040b02.opus"
    bm "ВНИМАНИЕ. ЕСЛИ СУБЪЕКТ ЖЕЛАЕТ ИСПЫТАТЬ МИР ТАК, КАК И ЗАДУМЫВАЛОСЬ, НЕМЕДЛЕННО ЗАКРОЙТЕ ИГРУ."
    xy "Извини, что? О чём ты говоришь?"
    voice "voice/a01/13v00050b02.opus"
    bm "ПОВТОРЯЮ, НАСТОЯТЕЛЬНО РЕКОМЕНДУЕТСЯ ЗАКРЫТЬ ИГРУ."
    voice "voice/a01/13v00060b02.opus"
    bm "НАЧИНАЮ ОТСЧЁТ."
    voice "voice/a01/13v00070b02.opus"
    bm "ДЕСЯТЬ.{w=1}{nw}"
    voice "voice/a01/13v00080b02.opus"
    bm "ДЕВЯТЬ.{w=1}{nw}"
    voice "voice/a01/13v00090b02.opus"
    bm "ВОСЕМЬ.{w=1}{nw}"
    voice "voice/a01/13v00100b02.opus"
    bm "СЕМЬ.{w=1}{nw}"
    voice "voice/a01/13v00110b02.opus"
    bm "ШЕСТЬ.{w=1}{nw}"
    voice "voice/a01/13v00120b02.opus"
    bm "ПЯТЬ.{w=1}{nw}"
    voice "voice/a01/13v00130b02.opus"
    bm "ЧЕТЫРЕ.{w=1}{nw}"
    voice "voice/a01/13v00140b02.opus"
    bm "ТРИ.{w=1}{nw}"
    voice "voice/a01/13v00150b02.opus"
    bm "ДВА.{w=1}{nw}"
    voice "voice/a01/13v00160b02.opus"
    bm "ОДИН.{w=1}{nw}"
    voice "voice/a01/13v00170b02.opus"
    bm "НОЛЬ.{w=1}{nw}"
    stop bgm fadeout (0/1000)
    pause (16/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
