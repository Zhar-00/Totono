label a0113w_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "f1111.nss"
    return
label a0113w:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    $ sename = "se物体_携帯_発信待機L"
    play se sedict[sename]
    pause (1400/1000)
    pause (800/1000)
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]
    pause (5000/1000)
    $ sename = "se物体_携帯_繋がる"
    play se sedict[sename]
    pause (1000/1000)
    xy "Эм... алло?"
    "О боже, я набрал случайный номер, и там взяли трубку!"
    xy "Эм..."
    $ sename = "se環境_雰囲気_世界改変01小L"
    play se sedict[sename]
    voice "voice/a01/13w00010a02.opus"
    bm "Шиничи..."
    voice "voice/a01/13w00020a02.opus"
    bm "Мы желаем тебе всего наилучшего."
    xy "Чего?"
    voice "voice/a01/13w00030a02.opus"
    bm "Пока-пока."
    $ sename = "se物体_携帯_繋がる"
    play se sedict[sename]
    $ renpy.music.set_volume(0.5,channel="se")
    pause (1000/1000)
    $ sename = "se物体_携帯_圏外"
    play se sedict[sename]
    pause (4000/1000)
    "После этого связь прервалась."
    "Кто это был?"
    "И откуда она знает моё имя?"
    stop se fadeout 2
    "В смысле, этот телефон даже не мой!"
    "Какого чёрта?.."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
