label a7213_MAIN:
    call expression GameName
    $ persistent.imagelog["eva7211美雪さん処女喪失b"]=True
    $ persistent.imagelog["eva7211美雪さん処女喪失c"]=True
    $ persistent.imagelog["eva7211美雪さん処女喪失d"]=True
    $ persistent.imagelog["eva7211美雪さん処女喪失e"]=True
    $ persistent.imagelog["eva7211美雪さん処女喪失f"]=True
    $ PreGameName = GameName
    $ persistent.ejaculation += 1
    $ PreGameName = GameName
    $ persistent.non_virgin = True
    python:
        if persistent.passed_non_virgin_month == None or persistent.non_virgin_day == None:
            from time import strftime, localtime
            persistent.passed_non_virgin_month = int(strftime("%m",localtime()))
            persistent.passed_non_virgin_day = int(strftime("%d",localtime()))
            persistent.DIARY_COUNT += 1
    if RECO_PLAY == 1 and persistent.complete:
        $ bukkake = False
        $ GameName = "a7214b.nss"
    elif persistent.c_route == True:
        if RECO_PLAY == 1 and persistent.library_scene1_out:
            $ bukkake = False
            if persistent.library_scene1_in and persistent.library_scene1_out:
                $ GameName = "a7214b.nss"
            else:
                $ GameName = "a7214a.nss"
        else:
            $ GameName = "a7214b.nss"
    else:
        $ GameName = "a7214a.nss"
        $ persistent.library_scene1_in = True
    return
label a7213:
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/bg/l/"+imagename["bg030300_3_自宅リビング_l"]+".jpg") as 絵背景 zorder 15:
        pos (620,-410)
    with Dissolve(1000.0/1000)

    "Затуманенный взгляд Миюки был прикован к моим глазам."
    with Dissolve(500.0/1000)

    "Как только наши губы слились в поцелуе, наши тела расслабились."
    voice "voice/a72/1300010a01.opus"

    mx "М-м... м-мф... м-м-мф... М-м... м-м... м-м-м-м!!!"

    "И на середине поцелуя я начал входить в неё."
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失b"]+".jpg") as 絵専 zorder 1010
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    $ persistent.non_virgin = True
    python:
        if persistent.non_virgin_month == None or persistent.non_virgin_day == None:
            from time import strftime, localtime
            persistent.non_virgin_month = int(strftime("%m",localtime()))
            persistent.non_virgin_day = int(strftime("%d",localtime()))
            persistent.DIARY_COUNT += 1
    voice "voice/a72/1300020a01.opus"

    mx "Н-нха-а! Н-нха-а-а-а-ах! М-м... м-мф... м-м-мф... М-м-мхн-н-н-н-н-н-н!!!.."

    "Сантиметр за сантиметром, мой член погружался в неё."

    "Кровь перемешалась с её жидкостью, окрасив её в бледно-красный цвет."

    "Я ещё никогда не чувствовал что-то подобное..."

    "Это было так приятно, что я даже мог сейчас потерять сознание!.."
    voice "voice/a72/1300030a01.opus"

    mx "Н-н... н-н-н-н... н-н-н... н-н-н-н-н!.. О боже... а-ах... Он так глубоко... н-н... н-н-н-н!!!.."
    voice "voice/a72/1300040a01.opus"

    mx "Шиничи... притормози... а-а-а-ах!.. Это слишком!.."
    xy "Л-ладно!"

    "Призвав своё быстро потерявшееся самообладание, я заставил себя остановиться на полпути."

    "Взглянув Миюки в глаза, я улыбнулся."

    xy "Тебе было больно?"
    show expression ("cg/ev/l/"+imagename["eva7211美雪さん処女喪失a_l"]+".jpg") as 絵専 zorder 1010:
        anchor (0,0)
        pos (-330,-50)
    with Dissolve(500.0/1000)
    voice "voice/a72/1300050a01.opus"

    mx "Д-да... самую малость... но... более того... это как-то странно..."
    voice "voice/a72/1300060a01.opus"

    mx "Мысль о том, что... м-м-м... твой член внутри меня... делает меня очень счастливой..."
    voice "voice/a72/1300070a01.opus"

    mx "И поэтому я подумала... что это не так уж и плохо. Я могу с этим совладать..."

    "От боли у неё наворачивались слёзы на глазах, но она смогла выдавить из себя эти слова."

    xy "Ладно. Мы сейчас на половине пути... сможешь принять остальное?"
    voice "voice/a72/1300080a01.opus"
    mx "\"Что?\""

    "Будучи верным своему слову, я пока вошёл в неё не полностью."
    voice "voice/a72/1300090a01.opus"

    mx "Ты... собираешься войти ещё глубже? Серьёзно? Но ты и так уже глубоко—"
    voice "voice/a72/1300100a01.opus"

    mx "А?.. О господи... он переполняет меня..."
    voice "voice/a72/1300110a01.opus"

    mx "Если так пойдёт и дальше, ты заполнишь меня полностью!.."

    xy "Прости, Миюки—!"

    "Её восторженные шёпоты добили мой самоконтроль."

    "Мой член погружался в неё всё глубже и глубже."
    show expression ("cg/ev/l/"+imagename["eva7211美雪さん処女喪失b_l"]+".jpg") as 絵専 zorder 1010:
        anchor (0,0)
        pos (-330,-50)
    with Dissolve(500.0/1000)
    voice "voice/a72/1300120a01.opus"

    mx "Н-н-нг-г-г-г-гх-х-х-х!!! Н-н-н-н... н-н-н... н-н-н-н-н-н-н!!!"

    "Вспоминая все те годы, что мы провели вместе..."
    voice "voice/a72/1300130a01.opus"

    mx "Ха-а... ха-а... ха-а... н-нг-г-г!!! Хн-н-н... а-а-а-а-ах... а-ах... А-А-А-А-АХ!!!"

    "...я вошёл в неё по самое основание."
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失c"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    voice "voice/a72/1300140a01.opus"

    mx "Н-н-н... Это... так странно... Хн-н-н! Я не могу... поверить, что это реально происходит..."
    voice "voice/a72/1300150a01.opus"

    mx "Это так напряжённо... мне больно... и трудно дышать..."
    voice "voice/a72/1300160a01.opus"

    mx "Но... зная о том, что ты внутри меня... я будто чувствую каждый сантиметр... Н-н-нг!"
    voice "voice/a72/1300170a01.opus"

    mx "Я... очень... люблю... тебя..."
    voice "voice/a72/1300180a01.opus"

    mx "Тебе это тоже очень нравится?"

    xy "Ты просто шикарна, Миюки... но я..."
    voice "voice/a72/1300190a01.opus"

    mx "...Всё нормально. Продолжай."

    "С согласия Миюки, я медленно начал двигаться."
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失b"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/a72/1300200a01.opus"

    mx "Н-нгха-а!"
    voice "voice/a72/1300210a01.opus"

    mx "М-мф!.. А-ах... а-а-а-ах!.. Н-н... н-нг-гх-х... н-н... н-н-нг-г!"

    voice "voice/a72/1300220a01.opus"

    mx "А-ах... а-ах... н-н-н... н-н-н-н... н-нг-гх-х... н-н-н... н-н... н-н-н-нг-г-г!"
    voice "voice/a72/1300230a01.opus"

    mx "Н-нгха-а... Погоди! Стой! А-а-а-ах! Погоди! Притормози! Н-н-нг-г!!!"

    "Моё тело говорило мне долбить её и выпустить своё семя как можно скорее..."

    "...но я сдержал свои плотские порывы и сбавил темп."
    voice "voice/a72/1300240a01.opus"

    mx "Н-нха-а-а-а-а! Н-н-н... н-н-нг... н-н-нг-г-гх-х-х-х!!! Ха-а... ха-а... ха-а... н-н-н-нг-г-г-г!!!"
    voice "voice/a72/1300250a01.opus"

    mx "Н-нха-а! А-ах! А-ах! А-ах! О боже! Я чувствую... как ты скользишь туда и обратно... Н-н-нг-г!!!"
    voice "voice/a72/1300260a01.opus"

    mx "Н-н-н... не могу... поверить... н-н-н-нг-г... что это... происходит... А-ах! Н-н-н!"
    voice "voice/a72/1300270a01.opus"

    mx "Но... Н-н-нг! Шиничи? Тебе ведь тоже приятно, верно?"
    voice "voice/a72/1300280a01.opus"

    mx "Тебе... приятно находиться во мне?"
    show expression ("cg/ev/l/"+imagename["eva7211美雪さん処女喪失b_l"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(500.0/1000)

    "Голос Миюки перемешивался с болью."

    "Но я чувствовал лёгкий сдвиг."

    "Да, небольшой такой сдвиг..."

    "Настолько крохотный, что его мог заметить только я..."
    voice "voice/a72/1300290a01.opus"

    mx "Н-нх-х-х... н-н... н-н-н-нг... а-а-а-а-ах!.. П-погоди, Шиничи..."
    voice "voice/a72/1300300a01.opus"

    mx "Ты уже давно сдерживаешься... и я это прекрасно вижу..."
    voice "voice/a72/1300310a01.opus"

    mx "Ты разве не хочешь насладиться этим сполна? Тебе не надо сбавлять темп ради моего же блага..."
    voice "voice/a72/1300320a01.opus"

    mx "Просто... Н-н... г-гх-х... еби меня так, как тебе хочется!.."

    xy "Врёшь..."
    voice "voice/a72/1300330a01.opus"
    mx "А?"

    xy "Тебе не нужно притворяться... просто скажи мне то, чего ты на самом деле хочешь."
    voice "voice/a72/1300340a01.opus"

    mx "Я... я вовсе не притво—"

    xy "Просто... будь честной со мной!.."

    xy "Я люблю настоящую тебя, несмотря ни на что!"
    voice "voice/a72/1300350a01.opus"
    mx "\"Шиничи...\""

    "Её защитная внешняя оболочка начала разрушаться окончательно."
    show expression ("cg/ev/l/"+imagename["eva7211美雪さん処女喪失c_l"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    voice "voice/a72/1300360a01.opus"

    mx "Слушай... эм... Это мой первый раз... И это определённо больно..."
    voice "voice/a72/1300370a01.opus"

    mx "Но я обожаю твой член... правда... это всё, о чём я могу думать сейчас, и..."
    voice "voice/a72/1300380a01.opus"

    mx "Это просто... потрясающе..."
    voice "voice/a72/1300390a01.opus"

    mx "Я обожаю ощущение того, что твой член внутри меня... я просто... я на седьмом небе от счастья!.."
    voice "voice/a72/1300400a01.opus"

    mx "Отдай это мне... люби меня всем тем, что у тебя есть..."
    voice "voice/a72/1300410a01.opus"

    mx "Просто порази меня, ладно?"

    xy "—Сейчас будет!"
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失b"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/a72/1300420a01.opus"

    mx "\"......!!!\""
    voice "voice/a72/1300430a01.opus"

    mx "Н-нха-а! А-ах! А-ах! Ох, блядь! О боже! Он... он так глубоко!.."
    voice "voice/a72/1300440a01.opus"

    mx "Я чувствую— твой толстый член— Хн-н-н!!! Он... он заполняет меня!!!"

    "Пока я двигался всё быстрее и быстрее, киска Миюки дёргалась и извивалась так, будто она внезапно ожила."

    "После всего того времени, что я сдерживал себя, я быстро дошёл до предела."

    "Комнату наполнил звук плоти, сталкивающейся вместе—"
    voice "voice/a72/1300450a01.opus"

    mx "А-А-АХ! О боже! Я не могу! Это... это так интенсивно... Н-н-н... я сейчас сломаюсь!.."
    voice "voice/a72/1300460a01.opus"

    mx "Ха-а! А-ах! А-а-а-ах! А-а-ах! А? Что за? Я чувствую, как он— разбухает—"

    xy "Прости— я сейчас кончу—!"
    voice "voice/a72/1300470a01.opus"

    mx "А? Что?! Серьёзно?! П-постой! Притормози— Если ты кончишь в меня—!"
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/bg/l/"+imagename["bg030300_3_自宅リビング_l"]+".jpg") as 絵背景 zorder 15 at truecenter
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失b"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    show expression Solid("FFFFFF") as 絵演色白
    pause (16/1000)
    hide 絵演色白
    with Dissolve(150.0/1000)
    pause (50/1000)
    show expression Solid("FFFFFF") as 絵演色白
    pause (16/1000)
    hide 絵演色白
    with Dissolve(150.0/1000)
    pause (200/1000)
    show expression Solid("FFFFFF") as 絵演色白 zorder 5000
    with Dissolve((100.0+1000.0)/1000)
    pause (500/1000)
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失d"]+".jpg") as 絵専 zorder 1100 at truecenter
    hide 絵演色白
    with Dissolve(1500.0/1000)
    pause (1000/1000)
    voice "voice/a72/1300480a01.opus"

    mx "Чт?.. Стой! Н-н-н... н-н-н-нг-г! А-ах! О боже— Я чувствую— Я чувствую твоё семя во мне!"
    voice "voice/a72/1300490a01.opus"

    mx "Ох, блядь... оно наполняет меня! Я просто наполнена твоей спермой— А-А-АХ! Н-н-н... н-н-нг-г!!!"

    "Пока я выплёскивал своё семя, киска Миюки дёргалась в ответ."
    voice "voice/a72/1300500a01.opus"

    mx "А-а-а-ах! Она... она такая тёплая... я чувствую... как она течёт во мне... Н-н-н-н!.."
    voice "voice/a72/1300510a01.opus"

    mx "О боже... она просачивается в каждый уголок... я чувствую тебя во мне..."
    hide 絵専
    with Dissolve(1000.0/1000)
    pause (1000/1000)

    xy "Миюки... я... эм..."
    voice "voice/a72/1300520a01.opus"

    mx "Шиничи... ты просто не мог сдерживаться, м-м?"

    xy "...Прости..."
    voice "voice/a72/1300530a01.opus"

    mx "А, да? И как ты загладишь передо мной свою вину?"

    xy "Н-ну, если ты забеременеешь, я буду мужчиной, и—"
    voice "voice/a72/1300540a01.opus"

    mx "Я не это имела в виду!"
    $ sename = "se人体_動作_衣擦れ濡れ場02"
    play se sedict[sename]
    pause (300/1000)
    show expression ("cg/ev/l/"+imagename["eva7211美雪さん処女喪失e_l"]+".jpg") as 絵専 zorder 1100:
        pos (-545,-350)
    show expression ("cg/ev/l/"+imagename["eva7211美雪さん処女喪失c_l"]+".jpg") as 絵専上 zorder 1100:
        pos (-545,-350)
    with Dissolve(1000.0/1000)
    pause (500/1000)
    pause (1000/1000)
    xy "А?.."

    "Без раздумий, я отошёл, чтобы вытащить член, но Миюки обхватила своими длинными ногами мои бёдра."
    show expression ("cg/ev/l/"+imagename["eva7211美雪さん処女喪失c_l"]+".jpg") as 絵専 zorder 1010:
        pos (-150,60)
    with Dissolve(800.0/1000)
    pause (500/1000)
    voice "voice/a72/1300550a01.opus"

    mx "...Мы ещё не закончили."

    xy "Что ты имеешь в виду?"
    voice "voice/a72/1300560a01.opus"

    mx "А сам как думаешь?! Боже!"
    voice "voice/a72/1300570a01.opus"

    mx "Я... я ещё не кончила, так что!.."

    "Лицо Миюки залилось краской."
    voice "voice/a72/1300580a01.opus"

    mx "Так что заставь меня кончить!"
    xy "\"......!!!\""

    "Мой вялый член внезапно оживился."
    show expression ("cg/ev/l/"+imagename["eva7211美雪さん処女喪失d_l"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1300590a01.opus"

    mx "Так-так-так... Ты только что кончил, и всё же..."
    voice "voice/a72/1300600a01.opus"

    mx "...У кое-кого снова встал, да?"

    "Она обхватила мой член так, будто пыталась поддерживать его наполнение кровью."

    "Естественно, я был всё ещё чувствительным после оргазма, и моё тело рефлекторно согнулось."


    xy "Э... это очень больно..."
    show expression ("cg/ev/l/"+imagename["eva7211美雪さん処女喪失e_l"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1300610a01.opus"

    mx "Смирись с этим."
    voice "voice/a72/1300620a01.opus"

    mx "Мне было больно, когда ты долбил меня тем образом, но ты не слышал МОИ жалобы!"

    xy "Да, потому что тебе это очень нравилось!"
    voice "voice/a72/1300630a01.opus"

    mx "И? Тебе ведь тоже!"
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失e"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(500.0/1000)

    "Она ловко двигала своими бёдрами."

    xy "Воу! Эй!"
    voice "voice/a72/1300640a01.opus"

    mx "Ох, ого... я слышу, как сперма хлюпает там..."
    voice "voice/a72/1300650a01.opus"

    mx "Это так грязно... Н-н-н... Шиничи... Ты грязный мальчик..."
    voice "voice/a72/1300660a01.opus"

    mx "Нх-х-х... я могу даже почувствовать её запах... наши жидкости перемешались вместе с кровью..."
    voice "voice/a72/1300670a01.opus"

    mx "Ты чувствуешь, как ты становишься твёрже внутри меня? Я чувствую, как он дёргается..."
    voice "voice/a72/1300680a01.opus"

    mx "Но тебе лучше не кончать так же быстро, как и в тот раз—"

    xy "У этого поезда нет тормозов, понимаешь?"
    voice "voice/a72/1300690a01.opus"

    mx "Хорошо."
    voice "voice/a72/1300700a01.opus"

    mx "Просто еби меня так, словно я - твоя игрушка."

    "В ответ я начал двигаться ещё быстрее."
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失b"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1300710a01.opus"

    mx "Хн-н-н! Н-н-н.... н-н-нг-г-г-г!!!"
    voice "voice/a72/1300720a01.opus"

    mx "А-А-А-АХ! А-АХ! Твой член опять стал твёрдым— Он почти что— разделяет меня напополам—!"
    voice "voice/a72/1300730a01.opus"

    mx "О боже— Твой член такой толстый— Он загоняет всю сперму в мою матку!"
    voice "voice/a72/1300740a01.opus"

    mx "А-а-а-ах! А-ах! А-ах! А, блядь— Это так— интенсивно— А-А-А-АХ!"
    voice "voice/a72/1300750a01.opus"

    mx "Ахах! Ты буришь меня— ещё сильнее, чем— в прошлый раз!"
    voice "voice/a72/1300760a01.opus"

    mx "Это— Это так интенсивно— Как будто ты— Как будто ты изменяешь форму моей киски своим членом!"

    "Её стенки подчинялись мне так, будто свежее покрытие из спермы сняло напряжение."

    "Это было так интенсивно, что мои ранее притупленные чувства кричали мне, когда я снова довёл себя до крайности."

    "Но я не могу отступить. Не сейчас."

    "Желая успокоиться, я оттащил свои бёдра назад—"
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失d"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1300770a01.opus"

    mx "А?.. Ты вытаскиваешь?"

    xy "Конечно же нет."

    "Её ноги крепче обхватили меня, не желая отпускать."
    $ sename = "se人体_動作_衣擦れ濡れ場03"
    play se sedict[sename]

    "Я расслабился и опустил свои бёдра. А потом я медленно начал двигать своей головкой туда-сюда в её проходе."
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失f"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    voice "voice/a72/1300780a01.opus"

    mx "А? О, воу... Это очень странно..."
    voice "voice/a72/1300790a01.opus"

    mx "А-а-а-ах... это совершенно другое ощущение... это трудно объяснить... это немного напрягает, в какой-то мере?.."
    voice "voice/a72/1300800a01.opus"

    mx "А-ах! А-ах! А-ах! Что за?.. Нежные толчки... заставляют меня расслабиться..."
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失b"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1300810a01.opus"

    mx "Ха-а-ах! А-ах! А-а-а-ах! А-ах! Это намного— намного— А-А-А-АХ!!!"

    "Тело Миюки извивалось в такт моего темпа."
    hide 絵捏造窓
    with Dissolve(400.0/1000)
    voice "voice/a72/1300820a01.opus"

    mx "Шиничи— А-ах! Н-н-н! Пожалуйста—!"
    voice "voice/a72/1300830a01.opus"

    mx "Возьми меня за руку— Возьмись за неё— И не отпускай—!"

    "Она звала меня слабым голосом."

    "Я скрестил её пальцы со своими."
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失b"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1300840a01.opus"

    mx "Ха-а-а-ах! А-ах! А-ах, а-ах, а-ах! О боже— Я— Н-н-нг! Н-н-н-н!!!"
    voice "voice/a72/1300850a01.opus"

    mx "Почему-то— когда мы держимся за руки— я чувствую себя— совершенно иначе—!!!"
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失c"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1300860a01.opus"

    mx "Я словно— в раю— Н-н-н-нг!!!"
    voice "voice/a72/1300870a01.opus"

    mx "Я так— рада, что я— влюбилась в тебя!"
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失f"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1300880a01.opus"

    mx "А-ах! О боже! Что-то— Что-то происходит— Внутри меня что-то нарастает—"
    voice "voice/a72/1300890a01.opus"

    mx "А-а-ах! А-ах! А-ах! А-ах! А-ах! А-А-А-А-А-А-АХ—"
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失b"]+".jpg") as 絵捏造窓絵専上 zorder 1010 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1300900a01.opus"

    mx "Н-нха-а-А-А-А-А-А-А-А-А-А-АХ!"
    hide 絵板写
    pause (16/1000)
    show expression Solid("FFFFFF") as 絵演色白 zorder 5000
    with Dissolve((200.0+800.0)/1000)
    with Dissolve((250.0+1000.0)/1000)
    pause (500/1000)
    hide 絵板写
    hide 絵捏造窓
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失g"]+".jpg") as 絵専 zorder 1010 at truecenter
    hide 絵演色白
    with Dissolve(1500.0/1000)
    pause (2000/1000)
    voice "voice/a72/1300910a01.opus"

    mx "А-ах... н-нха-а... н-н-н!.. Н-нг-гх... Хн-н... н-н-н... н-н-н-н... н-нха-ах!"
    show expression ("cg/ev/"+imagename["eva7211美雪さん処女喪失f"]+".jpg") as 絵専 zorder 1010 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/a72/1300920a01.opus"

    mx "Ха-а... ха-а... ха-а... А-агх... н-н-н! Ш-Шиничи... А-А-А-А-АХ?!"

    "Несмотря на то, что она дошла до своего предела, я продолжал долбить её сильнее, чем раньше."
    voice "voice/a72/1300930a01.opus"

    mx "Хн-н-н-н!.. А-ах... Шин... ичи!!!.. Я не могу... я... уже... кончила!.."
    voice "voice/a72/1300940a01.opus"

    mx "От звука... и запаха... у меня... голова идёт кругом... я так... счастлива... и возбуждена!.."
    voice "voice/a72/1300950a01.opus"

    mx "А-а-а-ах... а-а-а-ах... а-ах... а-ах!.. Как же приятно... у меня сейчас... башню снесёт!.."

    xy "Давай, дай волю своим чувствам. Я держу тебя."
    voice "voice/a72/1300960a01.opus"

    mx "Ладно... Спасибо!.."

    "Она улыбнулась мне, будучи почти что очарованной. Боже, она такая милая, я не могу сдержаться!"

    "Это финишная прямая... я долбил её изо всех сил."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
