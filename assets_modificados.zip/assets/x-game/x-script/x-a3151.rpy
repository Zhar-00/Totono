label a3151_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if aoi_stop == False:
        $ GameName = "a3152a.nss"
    else:
        $ GameName = "a3152b.nss"
    return
label a3151:
    hide 絵色黒
    $ sename = "se環境_自然_川縁夜L"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg040200_3_街川縁"]+".jpg")
    $ sename = "se人体_足音_歩く複数３人"
    play se sedict[sename]
    $ sename = "se環境_自然_川縁夜L"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve(1000.0/1000)
    xy "Да ладно тебе, не злись."
    voice "voice/a31/5100010a01.opus"
    mx "Я не злюсь."
    xy "То есть, это ты так сейчас не злишься?"
    voice "voice/a31/5100020a01.opus"
    mx "Слушай, я всё поняла, ладно? Я знаю, что Аой чувствует себя неважно."
    show expression ("cg/bg/l/"+imagename["bg040200_3_街川縁_l"]+".jpg") as 絵背景 zorder 150:
        pos (-1040,-290)
    hide StC with Dissolve(0.0/1000)
    $ St("MR",300,-90,0,"bu向日アオイ電波_制服_よろけ_sad")
    with Dissolve(500.0/1000)
    voice "voice/a31/5100030a02.opus"
    aoi "Буп-буп-буп... буп..."
    "Здесь, под звёздным небом, походка Аой была ещё более неустойчивой, чем обычно."
    hide 絵背景
    hide StMR
    hide StMR with Dissolve(0.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(500.0/1000)
    voice "voice/a31/5100040a01.opus"
    mx "Ладно, не важно."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/5100050a01.opus"
    mx "Я перестану быть злой... ЕСЛИ..."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/a31/5100060a01.opus"
    mx "...ты дашь мне один совет."
    "У меня было очень плохое предчувствие на этот счёт."
    xy "Это насчёт... того, что было в прошлом?"
    voice "voice/a31/5100070a01.opus"
    mx "Где-то на этом бейсбольном стадионе, наверное."
    voice "voice/a31/5100080a02.opus"
    aoi "Проблемы с парнями?"
    "Аой вмешалась в разговор."
    "Миюки вздрогнула от тревоги."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a31/5100090a01.opus"
    mx "Н-нет! Это насчёт ИГРЫ!"
    voice "voice/a31/5100100a02.opus"
    aoi "Насчёт поцелуя?"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/a31/5100110a01.opus"
    mx "Стоп, что?!"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_shout")
    with Dissolve(200.0/1000)
    voice "voice/a31/5100120a01.opus"
    mx "Шиничи, ты РАССКАЗАЛ ей?"
    xy "Ах, э-э-э-эм..."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a31/5100130a01.opus"
    mx "Разве ты не обещал, что никому не расскажешь?"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a31/5100140a01.opus"
    mx "Как ты мог? Я доверяла тебе!"
    xy "Прости... я просто... подумал, что в этом нет ничего страшного, поскольку мы все друзья."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a31/5100150a01.opus"
    mx "......!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Миюки выглядела так, будто уже была готова взорваться."
    "Я в отчаянии начал просить помощи у Аой."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
