label a6182a_MAIN:
    call expression GameName
    queue bgm "ttb14"
    $ PreGameName = GameName
    $ GameName = "a6191.nss"
    return
label a6182a:
    hide 絵色黒
    $ renpy.music.play("ttb07",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg060200_2_バッティングセンターボックス"]+".jpg")
    with Dissolve(500.0/1000)
    pause (500/1000)
    "Я подошёл и посмотрел на биту, лежащую на земле."
    "На рукояти, за которую держалась Аой, были следы крови."
    stop bgm fadeout (1000.0/1000)
    pause (1500/1000)
    $ sename = "se物体_バット_取る"
    play se sedict[sename]
    "Я медленно взял её..."
    voice "voice/a61/82a00010a02.opus"
    aoi "Шиничи?"
    show expression ("cg/bg/m/"+imagename["bg060200_2_バッティングセンターボックス_m"]+".jpg") as 絵背景参 zorder 102:
        xpos 0
        yalign -576
    show expression ("cg/bg/m/"+imagename["bg060200_2_バッティングセンターボックス_m"]+".jpg") as 絵背景参 zorder 102:
        xcenter .5
        yalign -280
    show expression ("cg/bg/l/"+imagename["bg060200_2_バッティングセンターボックス_l"]+".jpg") as 絵背景参 zorder 100:
        pos (-100,-500)
    $ sename = "se人体_動作_バット構える01"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    "...и встал на место отбивающего."
    hide 絵背景
    with Dissolve(500.0/1000)
    "Я встал в свою позу отбивающего."
    "А потом сосредоточил всю свою энергию на всём том, что было передо мной."
    "Что на меня нашло?"
    "Даже я не совсем уверен."
    "Обычно я никогда не захожу так далеко."
    "Вместо этого, я бы нашёл способ выбраться из этого."
    "И всё же я здесь."
    "Наверное, мне стоит поблагодарить Аой за это."
    "Я мог почувствовать, как моё сердце бешено колотилось."
    "Я давно ничего подобного не чувствовал."
    show expression Solid("000000") as 絵色黒 zorder 500
    with Dissolve((800.0+1000.0)/1000)
    pause (500/1000)
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵色黒
    show expression ("cg/ev/m/"+imagename["eva1211美雪バッティングa_m"]+".jpg") as 絵覆 zorder 2100:
        pos (-70,-130)
    with Dissolve((800.0+0.0)/1000)
    pause (500/1000)
    "Подающая машина выпустила мяч, и с идеальной формой, наравне с формой Миюки, я отправил его обратно..."
    "...и попал прямо в мишень хоум-рана."
    with Dissolve((800.0+1000.0)/1000)
    hide 絵背景参
    hide 絵背景
    hide 絵色黒
    hide 絵覆
    pause (500/1000)
    hide 絵色黒
    with Dissolve(1500.0/1000)
    "У меня где-то тысячу раз была такая фантазия."
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2300/1000)
    "Подающая машина выпустила ещё один мяч."
    "Пока всё идёт неплохо..."
    xy "Миюки—!"
    show expression Solid("FFFFFF") as 絵色白 zorder 6000
    $ sename = "se人体_動作_バットスイング03"
    play se sedict[sename]
    pause (150/1000)
    with Dissolve((300.0+1000.0)/1000)
    show expression ("cg/bg/m/"+imagename["bg060200_2_バッティングセンターボックス_m"]+".jpg") as 絵背景弐 zorder 101:
        xcenter .5
        ypos -100
        linear 20 ypos 0
    pause (500/1000)
    stop se fadeout (1000.0/1000)
    hide 絵色白
    with Dissolve(1500.0/1000)
    pause (1000/1000)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (1000/1000)
    "Моя бита пролетела мимо мяча."
    show expression ("cg/bg/m/"+imagename["bg060200_2_バッティングセンターボックス_m"]+".jpg") as 絵背景弐 zorder 101:
        xcenter .5
        ypos 0
        linear .3 ypos -288
    show expression Solid("000000") as 絵色黒 zorder 2000
    with Dissolve((200.0+1000.0)/1000)
    hide 絵背景弐
    hide 絵色白
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ sename = "se人体_衝撃_転倒01"
    play se sedict[sename]
    "Я тут же рухнул на землю."
    xy "Ха-ха!"
    xy "Ха-ха-ха! Ха-ха... ха-ха-ха-ха-ха-ха!"
    voice "voice/a61/82a00020a02.opus"
    aoi "Шиничи!"
    "Срань господня."
    "Я не мог перестать смеяться."
    "У меня не было оправданий для такого постыдного представления."
    "Я не смог забить хоум-ран."
    "Я не смог позволить чуду произойти."
    "И всё же..."
    show expression ("cg/bg/"+imagename["bg900100_2_雰囲気空"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵色黒
    with Dissolve(2000.0/1000)
    pause (500/1000)
    "У меня почему-то было такое чувство, будто я оказался на девятом небе."
    voice "voice/a61/82a00030a02.opus"
    aoi "Шиничи?"
    xy "Спасибо, Аой."
    xy "С твоей помощью, я наконец-то начал махать битой снова."
    xy "Теперь я могу начать всё сначала."
    $ sename = "se人体_動作_奪い取る"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg060200_2_バッティングセンターボックス"]+".jpg")
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    with Dissolve(300.0/1000)
    $ renpy.music.play("ttb14",channel = "bgm", if_changed = True)
    xy "Поезд ещё не ушёл, верно?"
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a61/82a00040a02.opus"
    aoi "А..."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_happy")
    with Dissolve(200.0/1000)
    voice "voice/a61/82a00050a02.opus"
    aoi "Точно!"
    xy "Прости, но мне нужно пойти кое-куда."
    xy "Я должен повидаться с Миюки!"
    xy "И на этот раз, я расскажу ей о своих чувствах!"
    hide StC with Dissolve(0.0/1000)
    $ sename = "se人体_足音_駆け出す"
    play se sedict[sename]
    with Dissolve(200.0/1000)
    voice "voice/a61/82a00060a02.opus"
    aoi "Поняла!"
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    "Как только я уже собирался уйти, Аой подняла руку."
    voice "voice/a61/82a00070a02.opus"
    aoi "Шиничи, ты такой классный!"
    xy "Да брось!"
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_smile")
    with Dissolve(200.0/1000)
    voice "voice/a61/82a00080a02.opus"
    aoi "Нет, правда! Ты круче всех!"
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/a61/82a00090a02.opus"
    aoi "До новых встреч..."
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_smile")
    with Dissolve(200.0/1000)
    voice "voice/a61/82a00100a02.opus"
    aoi "Совершенно новая Аой будет ждать тебя в другом руте!"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((200.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
