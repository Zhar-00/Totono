label e2237h_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2237j.nss"
    return
label e2237h:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)
    xy "\"Может, тебе стоит надеть свою спортивную форму?..\""
    voice "voice/e22/37h00010a01.opus"
    mx "\"Да...\""
    "К счастью, в нашей школе всё ещё обязывают носить те старомодные шорты с высоким разрезом..."
    xy "\"Ладно, сейчас я их для тебя до—\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e22/37h00020a01.opus"
    mx "\"Стоп!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/e22/37h00030a01.opus"
    mx "\"Ты? Достанешь мою спортивную форму?\""
    xy "\"...Ладно, намёк понят.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/37h00040a01.opus"
    mx "\"Я лучше поговорю с Хару-чан и попрошу её принести мою форму.\""
    "Да... наверное, для неё было бы не так странно войти в женскую раздевалку..."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Миюки достала свой телефон и настрочила электронку по-быстрому."
    "От скуки я начал проверять свои уведомления—"
    $ sename = "se物体_携帯_開く"
    play se sedict[sename]
    xy "\"О, мне пришло сообщение от Ютаро.\""
    voice "voice/e22/37h00050a01.opus"

    mx "\"Акебоно-кун?! Чёрт, совсем забыла!..\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
