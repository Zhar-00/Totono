label e1155e_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1155e:
    hide 絵色黒
    $ renpy.music.play("ttb22",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_ero")
    with Dissolve(0.0/1000)
    voice "voice/e11/55e00010a01.opus"

    mx "\"Да ладно, не будь таким...\""
    voice "voice/e11/55e00020a01.opus"

    mx "\"Пожалуйста... Умоляю тебя!.. Просто... ПОЦЕЛУЙ МЕНЯ!!!..\""
    menu:
        "Поцеловать её":
            $ SetChoiceSelect = 0
        "Не целовать её":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e1152a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e1155f.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
