label e3414a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e3414a:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    $ sename = "se環境_水音_シャワーL"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg110600_3_マンション台所"]+".jpg")
    with Dissolve(0.0/1000)
    xy "\"Я услышал кошачье мяуканье, и подумал, что мог бы пойти и сделать пару фотографий—\""
    voice "voice/e34/14a00010a01.opus"
    mx "\"Не уходи!\""
    "Её голос резко раздался эхом повсюду."
    "Похоже, она странно и слишком серьёзно к этому относится."
    "Я ведь просто собирался поздороваться с котиком!"
    "И я подумал, что ей очень понравятся милые фотки!"
    "Что произошло с помешанной на котах Миюки?"
    "Серьёзно, что плохого в том, что я выйду на пару секунд, чтобы сделать фотографию?"
    voice "voice/e34/14a00020a01.opus"
    mx "\"Не бросай меня...\""
    menu:
        "Не уходить":
            $ SetChoiceSelect = 0
        "Взять кошку":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e3415b.nss";
    elif SetChoiceSelect==1:
        $ persistent.cat_tracking +=1;
        if (persistent.cat_tracking == 2):
            $ GameName = "e3415c.nss";
        elif (persistent.cat_tracking > 2):
            $ GameName = "e3415d.nss";
        else:
            $ GameName = "e3415a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
