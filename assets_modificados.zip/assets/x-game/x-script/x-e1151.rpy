label e1151_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1151:
    hide 絵色黒
    stop bgm
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    show expression Solid("000000") as 絵演色黒
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    $ persistent.meta_date += 1
    voice "voice/e11/5100010a01.opus"
    mx "\"Эй, Шиничи?..\""
    xy "\"Хм?.. Миюки?..\""
    pause (16/1000)
    show expression Solid("FFFFFF") as 絵色白
    show expression ("cg/bg/l/"+imagename["bg110100_1_マンションリビング_l"]+".jpg") as 絵背景 zorder 100:
        pos (-1024,0)
    with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(600.0/1000))
    pause (200/1000)
    hide 絵色白
    with Dissolve(2000.0/1000)
    pause (500/1000)
    hide 絵演色黒
    "Внезапно я пришёл в сознание."
    "Уже был вечер, и солнце начало заходить."
    "Что я здесь делал?.."
    voice "voice/e11/5100020a01.opus"
    mx "\"Почему?\""
    $ sename = "se人体_動作_衣擦れ04"
    play se sedict[sename]
    pause (15/1000)
    $ St("C",300,0,0,"fu曽根美雪_制服_病み_sad")
    hide 絵背景
    with Dissolve(500.0/1000)
    $ renpy.music.play("ttb22",channel = "bgm", if_changed = True)
    voice "voice/e11/5100030a01.opus"
    mx "\"Почему ТЫ предал меня?\""
    voice "voice/e11/5100040a01.opus"
    mx "\"Почему ТЫ так сильно меня ненавидишь?\""
    xy "\"Что? Я не ненавижу тебя...\""
    $ St("C",300,0,0,"fu曽根美雪_制服_腕組み_rage")
    with Dissolve(200.0/1000)
    voice "voice/e11/5100050a01.opus"
    mx "\"Я не тебя спрашиваю!\""
    "...Что?"
    "На кого она тогда злится?"
    $ St("C",300,0,0,"fu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/5100060a01.opus"
    mx "\"Я умоляю тебя.\""
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/e11/5100070a01.opus"
    mx "\"Просто... поцелуй меня.\""
    xy "\"Ты хочешь, чтобы я поцеловал тебя?..\""
    $ St("C",300,0,0,"fu曽根美雪_制服_病み_ero")
    with Dissolve(200.0/1000)
    voice "voice/e11/5100080a01.opus"
    mx "\"Если ты поцелуешь меня прямо здесь и сейчас, я закрою глаза на твои недавние проблемы в отношениях.\""
    voice "voice/e11/5100090a01.opus"
    mx "\"Давай сбросим счётчик привязанности, удалим все флаги событий и начнём новую игру... ладно?\""
    voice "voice/e11/5100100a01.opus"
    mx "\"Вернёмся к началу, вон там, на крыше... Да, я удалю всех ненужных второстепенных персонажей, и тогда мы будем только вдвоём...\""
    "Счётчик привязанности?"
    "Флаги событий?"
    "Новую игру?"
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/e11/5100110a01.opus"
    mx "\"Ну? Ты поцелуешь меня или нет?\""
    $ persistent.minus_choice = True ;
    menu:
        "Поцеловать её":
            $ SetChoiceSelect = 0
        "Не целовать её":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e1152a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e1152b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
