label e1156c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1157.nss"
    return
label e1156c:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)

    xy "\"А-аргх! Чёрт побери!\""

    "Почему я так себя чувствую?!"

    "Я знаю, что просто трачу своё время."

    "И всё же... я чувствовал это странное, навязчивое желание пойти искать Аой!.."

    "Это было абсолютно бессмысленно... но я всё равно чувствовал, что обязан сделать это!"

    "Ладно, не важно! Я пойду и куплю фигурку, наверное!"

    "Мой единственный выбор - найти Аой как можно быстрее!"

    "Я сделал глубокий вдох, а потом вышел за дверь—"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
