label c4221_MAIN:
    call expression GameName
    $ persistent.imagelog["eva0113アオイ送信中c"]=True
    $ persistent.imagelog["evc4221アオイ眠り姫a"]=True
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label c4221:
    hide 絵色黒
    scene expression ("cg/bg/l/"+imagename["bg010100_3_学校階段_l"]+".jpg") as 絵背景:
        pos (-515,-190)
    with Dissolve(0.0/1000)
    $ sename = "se物体_ドア屋上_鍵開ける01"
    play se sedict[sename]
    pause (1200/1000)
    stop bgm fadeout (2500/1000)
    show expression Solid("000000") as 絵色白 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    $ sename = "se環境_自然_風モンゴルL"
    play se sedict[sename]
    show expression Solid("000000") as 絵色白
    show expression ("cg/bg/"+imagename["bg010200_3_学校屋上"]+".jpg")
    hide 上背景
    hide 絵色白
    with Dissolve(2000.0/1000)
    pause (1000/1000)
    play voc "c42/2100010b04"

    "Иру метнулся вперёд."
    xy "\"......\""
    show expression ("cg/ef/"+imagename["efbg屋上フェンス"]+".png") as 絵演覆
    show expression ("cg/bg/"+imagename["bg900200_3_雰囲気街並み"]+".jpg") as 絵背景 zorder 1005 at truecenter
    with Dissolve(800.0/1000)
    pause (500/1000)

    "Я впервые увидел крышу ночью."

    "На какой-то миг ночной пейзаж перехватил мой дух."

    "На первый взгляд, крыша была безлюдной."

    "Но я знаю, что если обернусь, то увижу—"
    show expression ("cg/ev/"+imagename["eva0113アオイ送信中c"]+".jpg") as 絵専下 zorder 1100 at center
    show expression ("cg/ev/l/"+imagename["eva0113アオイ送信中c_l"]+".jpg") as 絵専 zorder 1105:
        zoom 2
        xpos -1024
        ypos -1700
        linear 3 ypos -688
    with Dissolve((1000.0+1000.0)/1000)
    hide 絵演覆
    hide 絵背景
    hide 絵色黒
    pause (800/1000)
    with Dissolve((0.0+1000.0)/1000)
    hide 絵専
    with Dissolve(1000.0/1000)
    pause (2000/1000)
    xy "\"А?..\""

    "...Аой даже на верхней части крыши не было."
    xy "\"Она не здесь?..\""
    xy "\"Она... должна была быть здесь...\""

    "Аой раньше проводила здесь каждый день, уставившись на небо."

    "Она поднимала свой сломанный телефон ввысь и звонила Богу."

    "Но её нигде не было видно."
    play voc "c42/2100020b04"

    "Иру посмотрел на лестницу и мяукнул, как бы подталкивая меня пойти туда."

    "Но с каким усердием я не пытался посмотреть туда, я—"
    voice "voice/c42/2100030a02.opus"
    aoi "\"......\""
    xy "\"Хм? Аой?\""
    voice "voice/c42/2100040a02.opus"
    bm "\"Буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп...\""
    xy "\"Аой?! Ты там?!\""

    "Я уловил её сигнал, пусть даже и очень слабый."
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 2000
    with Dissolve((500.0+1000.0)/1000)
    hide 絵専
    show expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")

    "Я поспешно залез наверх по лестнице."
    pause (300/1000)
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    hide 絵色黒
    scene expression ("cg/ev/m/"+imagename["evc4221アオイ眠り姫a_m"]+".jpg") as 絵専上:
        pos (-500,-170)
        linear 2 pos (-60,-20)
    with Dissolve((1500.0+1000.0)/1000)
    pause (800/1000)
    show expression ("cg/ev/"+imagename["evc4221アオイ眠り姫a"]+".jpg") as 絵専 zorder 1100 at truecenter with dissolve
    pause (1000/1000)
    xy "\"Воу...\""
    xy "\"Аой?..\""

    "Вот она где... она лежала на верхней части крыши."
    xy "\"Аой?! Эй!\""

    "Я заключил её в свои объятия."

    "Она была абсолютно холодной."

    "Она... не дышит."

    "Её глаза были закрыты."

    "Так кому она сейчас \"звонила\"?"
    show expression ("cg/ev/l/"+imagename["evc4221アオイ眠り姫a_l"]+".jpg") as 絵専上 zorder 1105:
        pos (-460,-320)
    with Dissolve((500.0+1000.0)/1000)
    voice "voice/c42/2100050a02.opus"
    aoi "\"У меня батарейка села.\""

    "Смартфон Аой лежал рядом с ней."

    "На его экране я мог разглядеть игровую версию \"Аой\"."
    with Dissolve((300.0+0.0)/1000)

    xy "\"Эй! Аой! АОЙ! В чём дело?! Ответь мне!\""
    xy "\"Именно тогда, когда я наконец-то нашёл тебя... чёрт побери!!!\""

    "Я должен что-то сделать."

    "Но что?"
    voice "voice/c42/2100060a02.opus"
    aoi "\"Мне нужна перезарядка.\""
    voice "voice/c42/2100070a02.opus"
    bm "\"Не хочешь... подзарядиться?\""
    return
    return
label c4221_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/ev/"+imagename["evc4221アオイ眠り姫a"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    menu:
        "Сделать искусственное дыхание":
            $ SetChoiceSelect = 0
        "Позвонить в скорую":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "c4222.nss"
    elif SetChoiceSelect==1:
        $ GameName = "d4222.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
