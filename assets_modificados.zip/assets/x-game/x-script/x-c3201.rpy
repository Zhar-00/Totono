label c3201_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c3211.nss"
    return
label c3201:
    hide 絵色黒
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/l/"+imagename["bg010401_3_学校校門閉通用口開_l"]+".jpg") as 絵背景 zorder 100:
        pos (-160,-410)
    show expression ("cg/bg/"+imagename["bg010401_3_学校校門閉通用口開"]+".jpg")
    with Dissolve(0.0/1000)
    play voc "c32/0100010b04"
    hide 絵背景
    with Dissolve(300.0/1000)
    xy "\"М-м? В чём дело?\""
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_密着_think")
    with Dissolve(200.0/1000)
    voice "voice/c32/0100020a02.opus"

    aoi "\"Ты проголодался?\""
    play voc "c32/0100030b04"

    xy "\"Всё-таки он ЕЩЁ котёнок... должны ли мы дать ему молока?\""

    xy "\"Но все магазины, скорее всего, уже закрыты...\""
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c32/0100040a02.opus"

    aoi "\"Может, стоит заглянуть в магазин за углом?\""

    xy "\"Стоп... а разве котятам можно пить то же молоко, что и людям?\""
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c32/0100050a02.opus"

    aoi "\"Буп-буп... не знаю.\""

    "Так или иначе, этому маленькому созданию всё равно захочется кушать."

    xy "\"Хм... ладно, пошли в угловой.\""
    stop bgm fadeout (3000/1000)
    show expression Solid("000000") as 絵色黒 zorder 30000
    with Dissolve((800.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
