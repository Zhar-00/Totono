label a2111_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a2121.nss"
    return
label a2111:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve(2000.0/1000)
    pause (300/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100010b01.opus"
    xtl "Мне надо поговорить с тобой насчёт моих мечтаний!"
    "В тот момент, когда я прошёл за дверь, Ютаро побежал ко мне."
    xy "Что? Я думал, твои мечты разрушены или ещё что."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100020b01.opus"
    xtl "В тот момент, когда человек беспокоится из-за того, что его мечта разрушена... Именно тогда ты и осознаёшь, что это правда."
    xy "Эм, ладно. Поверю тебе на слово."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100030b01.opus"
    xtl "Загляни в свою душу!"
    xy "Не могу. Так в чём дело?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100040b01.opus"
    xtl "Это насчёт... той мечты, которую я нашёл снаружи."
    "Трусы его брата в синюю полосочку. Точно."
    voice "voice/a21/1100050b01.opus"
    xtl "У меня после этого была целая беседа с Рюджиро... И выяснилось, что..."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100060b01.opus"
    xtl "Он «кроссплеер», что бы это не значило."
    xy "То есть, ему нравится косплеить персонажей в женской одежде?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100070b01.opus"
    xtl "Да. Скорее всего, они называют таких людей «отоконоко»? Или «фембой»? Что-то в таком духе."

    $ St("C",300,0,0,"st曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100080b01.opus"
    xtl "Загляни в свою душу!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100090b01.opus"
    xtl "...Если серьёзно, я не совсем понимаю."
    voice "voice/a21/1100100b01.opus"
    xtl "Ну да ладно, что мне делать-то?"
    xy "Делать? Ты о чём?"
    "Я ещё ни разу не видел, как Ютаро испытывал противоречивые чувства из-за чего-либо. Я вздохнул."
    xy "Так что ты ХОЧЕШЬ сделать?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100110b01.opus"
    xtl "Он работает моделью в одном журнале, и он правда выглядит весьма фотогенично. Хотя он не столько «сексуальный», сколько «симпатичный»..."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100120b01.opus"
    xtl "Это просто... довольно странно, не находишь?"
    xy "В смысле... это определённо необычно..."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100130b01.opus"
    xtl "То есть, я хочу поддержать его жизненный выбор и всё такое... я пытаюсь быть в курсе всех событий, понимаешь?"
    voice "voice/a21/1100140b01.opus"
    xtl "Но когда это касается семьи, мне просто... мне трудно принять это сразу."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100150b01.opus"
    xtl "Боже, я чувствую себя таким глупым. Я не понимаю самое главное, что в нём есть..."
    "Ютаро с трудом подбирал слова."
    "И пока вы не спросили, да, он всегда такой напряжённый. Он такой, какой есть."
    xy "Эм, лично я на твоём месте не стал бы из-за этого рвать волосы на голове."
    xy "Он держал это в себе уже более десяти лет, верно? А ты узнал об этом, ну, где-то через день. Разумеется, ты ничего не поймёшь сразу."
    xy "Посмотри на это с такой стороны... тебе нужно лишь немного времени."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100160b01.opus"
    xtl "Ты... ты так думаешь?"
    stop bgm fadeout (1000.0/1000)
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (800/1000)
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    pause (200/1000)
    show expression ("cg/ev/"+imagename["eva0121美雪さんおはようございます"]+".jpg") as 絵専 zorder 2100 at center
    hide StC
    hide StMR
    hide StML
    hide 絵色白
    with Dissolve(1600.0/1000)
    pause (300/1000)
    voice "voice/a21/1100170a01.opus"
    mx "Доброе утро!"
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    show expression ("cg/bg/m/"+imagename["bg010600_1_学校教室_m"]+".jpg") as 絵演葵背景:
        pos (-425,-150)
    hide 絵専
    with Dissolve(500.0/1000)
    pause (100/1000)
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_挙手_shout")
    voice "voice/a21/1100180a02.opus"
    aoi "Доброе утро, Миюки."
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_挙手_normal")
    voice "voice/a21/1100190a02.opus"
    aoi "Хорошая погода сегодня."
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve((0.0+0.0)/1000)
    with Dissolve(500.0/1000)
    pause (100/1000)
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100200b01.opus"
    xtl "Бедная Муко... Сонэ-сан не даёт ей ни минуты покоя. На это довольно трудно смотреть..."
    xy "Никогда не знаешь наверняка. Сегодня всё может быть иначе."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100210b01.opus"
    xtl "Насколько иначе?.."
    hide StC with Dissolve(200.0/1000)
    show expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg")
    $ St("MR",300,15,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    pause (300/1000)
    voice "voice/a21/1100220a01.opus"
    mx "Слушай, Муко-сан... Ты ещё не закончила своё домашнее задание по математике?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    with Dissolve((0.0+1000.0)/1000)
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100230a02.opus"
    aoi "Домашнее задание?"
    voice "voice/a21/1100240a01.opus"
    mx "С урока математики, да."
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a21/1100250a02.opus"
    aoi "Ещё нет."
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg") as 絵演美雪背景 at center
    $ St("MR",1300,15,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100260a01.opus"
    mx "Ты ведь не занята в обед, верно? Давай решим её вместе?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    with Dissolve((0.0+0.0)/1000)
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100270a02.opus"
    aoi "Буп-буп?.."
    "Аой застыла на месте так, будто время для неё остановилось."
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    with Dissolve((0.0+1000.0)/1000)
    $ St("MR",1300,15,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100280a01.opus"
    mx "Да или нет?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    with Dissolve((0.0+0.0)/1000)
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_通常_surprise")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb04",channel = "bgm", if_changed = True)
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_挙手_shout")
    voice "voice/a21/1100290a02.opus"
    aoi "П-поняла! Давай сделаем её!"
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_挙手_shout")
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a21/1100300a02.opus"
    aoi "Пожалуйста, учи меня!"
    voice "voice/a21/1100310a01.opus"
    mx "Сразу говорю, я не дам тебе у меня списывать."
    $ St("ML",300,-15,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/a21/1100320a02.opus"
    aoi "Поняла!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    hide 絵演葵背景
    hide 絵演美雪背景
    with Dissolve(500.0/1000)
    "После этого я почувствовал, как настроение в классе изменилось."
    "До этого момента, Миюки всячески отгоняла от себя Аой; и остальные ученики просто смирились с этим."
    "Но теперь, когда Миюки изменила свой настрой, есть вероятность, что так поступит и остальная часть класса тоже."
    stop bgm fadeout (1000.0/1000)
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    voice "voice/a21/1100330b01.opus"
    xtl "Точно! Ответ всё это время был передо мной!"
    xy "В чём дело, Ютаро?"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_happy")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100340b01.opus"
    xtl "Люди могут прийти к взаимопониманию, если попытаются!"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100350b01.opus"
    xtl "Я ведь прав, Шиничи?!"
    xy "К-конечно... можно и так посмотреть на это... наверное..."
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100360b01.opus"
    xtl "Я просто должен дать этому все сто десять процентов!"
    $ St("C",300,0,0,"bu曙雄太郎_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a21/1100370b01.opus"
    xtl "Если я смогу понять то, что чувствует Рюджиро, то это будет означать, что я тоже должен начать одеваться как—"
    xy "Ага-а-а-а, удачи тебе с этим."
    stop bgm fadeout (3000.0/1000)
    scene expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
