label e2235a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2236.nss"
    return
label e2235a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    $ St("C",740,0,0,"bu曽根美雪_制服_恋人_shy")
    with Dissolve(0.0/1000)

    xy "\"А, точно... Это.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
