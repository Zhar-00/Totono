label e2181f_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2181b.nss"
    return
label e2181f:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    $ sename = "se人体_動作_投球02"
    play se sedict[sename]
    pause (400/1000)
    stop se fadeout (100.0/1000)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (200/1000)

    xy "\"А?!\""

    "Я моргнул."

    xy "\"Мяч только что исчез?!\""
    $ St("C",300,0,0,"st曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/81f00010a01.opus"

    mx "\"Это исчезающий демонический мяч.\""
    $ St("C",300,0,0,"st曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e21/81f00020a01.opus"

    mx "\"Очень здорово, да?\""

    "Ладно, теперь ты на меня просто давишь..."

    "Но должен признать, это было ОЧЕНЬ круто..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
