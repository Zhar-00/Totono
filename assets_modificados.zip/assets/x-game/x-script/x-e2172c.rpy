label e2172c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2173.nss"
    return
label e2172c:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(0.0/1000)

    "Книгу «Кулинария-101»."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/e21/72c00010a01.opus"

    mx "\"Опять?\""

    xy "\"А?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/e21/72c00020a01.opus"

    mx "\"Ты на днях покупал такую же книгу!\""

    xy "\"Серьёзно? Ха-ха-ха-ха-ха...\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
