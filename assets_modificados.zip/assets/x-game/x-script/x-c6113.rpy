label c6113_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6121.nss"
    $ cat_wave = True;
    return
label c6113:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030200_2_自宅玄関"]+".jpg")
    with Dissolve(0.0/1000)

    xy "\"Наверное...\""

    "Иру - кот-передатчик."

    "Аой рассказывала мне о его предполагаемых способностях предсказания."

    "Я знаю, что, наверное, должен принять это всё с долей скептицизма, но в то же время... именно Иру и помог мне найти её на крыше школы той ночью."
    $ sename = "se物体_携帯_開く"
    play se sedict[sename]

    "Я проверил время на телефоне."

    "До начала шоу тридцать минут."

    "Мне не очень хотелось подозревать её, но должен признать, что в её поведении меня что-то беспокоило."
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]
    play voc "c61/1300010b04"
    xy "\"...Ладно.\""
    show expression ("cg/bg/l/"+imagename["bg020100_2_自宅外正面_l"]+".jpg") as 絵背景 zorder 110:
        pos (-2,-561)
    show expression ("cg/bg/"+imagename["bg020100_2_自宅外正面"]+".jpg")
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    $ sename = "se物体_ドア自宅_閉まる"
    play se sedict[sename]

    "Мой инстинкт побудил меня к действию."
    $ sename = "se物体_ビニル袋_鳴る"
    play se sedict[sename]

    "Я решил спрятаться в кустах и ждать."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
