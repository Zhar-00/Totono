label e2232a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2233a.nss"
    return
label e2232a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(0.0/1000)
    xy "\"Согласен.\""

    "Население нашего города сокращалось, и общее число учеников во всех классах также постепенно уменьшалось."

    "Я сомневаюсь, что эта парта когда-нибудь понадобится снова."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
