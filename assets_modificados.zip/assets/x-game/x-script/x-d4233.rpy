label d4233_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d4241.nss"
    return
label d4233:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    hide 上背景
    with Dissolve(500.0/1000)
    $ sename = "se物体_携帯_発信待機L"
    play se sedict[sename]
    pause (1000/1000)

    "Я тут же набрал 911."
    stop se fadeout (150.0/1000)
    xy "\"Алло?\""
    xy "\"Мне нужна скорая помощь. Мы находимся—\""

    "...Должен ли я им сказать, что мы находимся на крыше школы?"

    "Или мне придётся попросить Аой спуститься со мной к воротам?"
    play voc "d42/3300010b04"

    xy "\"Иру, погоди секунду—\""
    xy "\"......Что за?\""
    $ sename = "se物体_携帯_落ちる01"
    play se sedict[sename]

    "Все силы начали уходить из моих пальцев."

    "Мой мозг с трудом пытался переварить то, что я увидел."

    "Мяуканье Иру вернуло меня обратно в реальность—"
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
