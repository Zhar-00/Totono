label c5132_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c5141.nss"
    return
label c5132:
    hide 絵色黒
    $ sename = "se環境_ガヤ_教室授業中L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/c51/3200010a02.opus"
    aoi "\"Буп-буп...\""

    "—Я заметил, как Аой смотрела на меня."
    stop se fadeout (2000.0/1000)
    $ EyeCatchIn(2000.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
