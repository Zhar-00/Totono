label a9122a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if persistent.a_route == True:
        $ no_call = False
        $ miyuki_plot = False
        $ GameName = "b1121.nss"
        $ GameContiune = 1
        return
    elif aoi_stop == True:
        $ aoi_stop = False
        $ GameName = "a9201.nss"
    else:
        $ GameCircle=False
    return
label a9122a:
    hide 絵色黒
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    show expression ("cg/ef/"+imagename["efbg空汎用西日"]+".jpg") as 絵専 zorder 15 at truecenter
    with Dissolve(0.0/1000)
    $ sename = "se物体_携帯_開く"
    play se sedict[sename]
    show expression ("cg/ev/"+imagename["eva2151美雪アオイ心一写真c"]+".jpg") as 絵専 at truecenter
    with Dissolve(500.0/1000)
    pause (1000/1000)

    xy "\"Именно то, что я и заслужил, не правда ли?\""

    "Пробормотал я фотографии с того дня."

    "Нет нужды говорить о том, что она мне так и не ответила."
    stop bgm fadeout (5000.0/1000)
    show expression Solid("000000") as 絵演色黒
    with Dissolve(4000.0/1000)
    pause (3000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
