label a7216_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if persistent.c_route == True:
        $ GameName = "e2022.nss"
    else:
        $ GameName = "a7221.nss"
    $ persistent.library_scene1 = True
    if RECO_PLAY == 1:
        $ GameCircle=False
    return
label a7216:
    hide 絵色黒
    hide 和谐的黑色 onlayer hexie
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    with Dissolve(0.0/1000)
    voice "voice/a72/1600010a01.opus"

    mx "\"Эй, Шиничи? Я...\""
    voice "voice/a72/1600020a01.opus"

    mx "\"Я очень хочу провести с тобой остаток своей жизни.\""

    "Её улыбка была искренней, как и тогда, когда мы ещё были детьми."
    stop bgm fadeout (3000/1000)
    pause (3000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
