label a0114a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a0121.nss"
    return
label a0114a:
    $ renpy.music.play("ttb01",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    show expression ("cg/ev/l/"+imagename["eva0113アオイ屋上覆い被さりa_l"]+".jpg") as 絵専上二 with Dissolve(1.8):
        zoom 1.5
        align (0.3,0.3)
        pos (512-228, 288-90)
    "Что-то прошлось от её тела по всей моей коже, спалив тем самым всякое чувство здравого смысла."
    "Будучи притянутым, словно магнит, мои губы прижались к её губам."


    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
