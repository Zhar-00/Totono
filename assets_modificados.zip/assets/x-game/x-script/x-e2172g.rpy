label e2172g_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2173.nss"
    return
label e2172g:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(0.0/1000)

    "Книгу «Кулинария-101»."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/e21/72g00010a01.opus"

    mx "\"Слушай...\""
    voice "voice/e21/72g00020a01.opus"

    mx "\"Почему бы тебе не попробовать что-то новое и не купить порножурнал или что-то в таком духе?\""

    xy "\"Что?! Не говори глупостей!\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
