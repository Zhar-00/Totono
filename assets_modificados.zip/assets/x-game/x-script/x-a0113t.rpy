label a0113t_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label a0113t:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    if persistent.sim_stolen == True and persistent.aoi_true == False and persistent.miyuki_true == False:
        call screen aoi_phone
        $ input_number = _return
        $ GameName = "a0113u.nss"
    else:
        call screen aoi_phone
        $ input_number = _return
        if input_number =="08091846920":
            $ GameName = "a0113v.nss"
        elif input_number=="99905230523" and persistent.miyuki_true == True:
            $ GameName = "a0113w.nss"
        elif input_number=="99956116886" and persistent.gflf_aoi == True:
            $ GameName = "a0113x.nss"
        elif input_number=="707078181":
            $ GameName = "a0113u.nss"
        else:
            $ GameName = "a0113u.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
