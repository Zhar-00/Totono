label e2183a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2184a.nss"
    return
label e2183a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_shy")
    with Dissolve(0.0/1000)
    voice "voice/e21/83a00010a01.opus"

    mx "\"Н-но!..\""
    voice "voice/e21/83a00020a01.opus"

    mx "\"Эм... В общем...\""
    voice "voice/e21/83a00030a01.opus"

    mx "\"Знаешь ту пустую парту в классе?\""

    xy "\"Да?\""

    "Я, кажется, ПРИПОМИНАЮ, что в классе была одна парта, которая никем не использовалась..."
    voice "voice/e21/83a00040a01.opus"

    mx "\"Они сказали мне переместить её на крышу. И я подумала, что ты мог бы помочь мне.\""
    voice "voice/e21/83a00050a01.opus"

    mx "\"Так что, если ты хочешь заняться этим...\""

    "Миюки начала бормотать себе под нос, опустив свой взгляд на пол, её лицо было красным."

    "На данный момент я вряд ли смогу отказать ей."
    voice "voice/e21/83a00060a01.opus"

    mx "\"В общем, да... эм...\""
    $ persistent.miyuki_sex_promise = True;
    $ temp_miyuki_sex_promise = True;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
