label e2112c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2113.nss"
    return
label e2112c:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040100_1_街通学路"]+".jpg")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/12c00010a01.opus"

    mx "\"Ну же, не стесняйся.\""
    voice "voice/e21/12c00020a01.opus"

    mx "\"Да и не похоже, что у тебя вообще был выбор.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se人体_動作_握る"
    play se sedict[sename]

    "Я пытался убрать свою руку в сторону, но она схватила её—"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
