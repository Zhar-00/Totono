label a5122_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5131.nss"
    return
label a5122:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010800_1_学校体育館"]+".jpg")
    show expression ("cg/bg/m/"+imagename["bg010800_1_学校体育館_m"]+".jpg") as 絵背景 zorder 100 at truecenter
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(0.0/1000)
    voice "voice/a51/2200010a01.opus"
    mx "......"
    "Мы были одни на этой площадке."
    "Миюки смотрела мне прямо в глаза."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    show expression ("cg/ef/"+imagename["efev美雪のキス"]+".jpg") as 絵美雪接吻 zorder 120 with fade
    voice "voice/a22/1100010a01.opus"
    mx "Сейчас должен быть..."
    voice "voice/a22/1100020a01.opus"
    play voc "a22/1100030a01"
    pause .5
    play sound "voice/a22/1100040a01.opus"
    pause .5
    play voc "a22/1100050a01"
    pause .5
    play sound "voice/a22/1100060a01.opus"
    pause .5
    extend " поцелуй."
    hide 絵美雪接吻
    with Dissolve(800.0/1000)
    pause (200/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200080a01.opus"
    mx "Шиничи..."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    voice "voice/a51/2200090a01.opus"
    mx "Ты что-то скрываешь от меня по поводу Аой, не так ли?"
    xy "Я? Скрываю что-то?"
    "Ладно, значит дело не во вчерашнем инциденте, я так и понял..."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200100a01.opus"
    mx "Той ночью!"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200110a01.opus"
    mx "Той ночью, под дождём, когда мы нашли Аой здесь... Ты ведь как-то выяснил это, верно? Зачем ты тогда побежал к себе домой?"
    xy "А? ...А, точно!"
    "Боже... если я расскажу ей, что искал подсказки в видеоигре, то она надерёт мне задницу..."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200120a01.opus"
    mx "Скажи мне, сейчас же!"
    xy "...Я ушёл, чтобы поиграть в видеоигру."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200130a01.opus"
    mx "Видеоигру?"
    xy "Аой отыгрывает сцены из мобильной игры. Она делает это ещё с тех пор, как мы впервые познакомились."
    voice "voice/a51/2200140a01.opus"
    mx "То есть, ты использовал ту игру, чтобы предсказать будущее?"
    xy "Я вовсе не ожидал того, что она окажется здесь! Я думал, что она ПРАВДА привязана к скрипту игры."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200150a01.opus"
    mx "Ха-а..."
    "Миюки тяжело вздохнула."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200160a01.opus"
    mx "И в игре она тоже приютила кота?"
    xy "Да. Ты знаешь, когда мы нашли Иру? Я могу поклясться, что это была почти что репродукция один-в-один—"
    voice "voice/a51/2200170a01.opus"
    mx "Цитировать строки – это одно. А кошачьи уши не так уж и трудно найти."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200180a01.opus"
    mx "Но что насчёт кота?"
    xy "А?"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200190a01.opus"
    mx "Котёнок. Иру."
    xy "А, ну, я переживал из-за оставления этого маленького создания у себя дома, поэтому я и взял его с собой в школу. Я пока позволил ему позависать на крыше, и—"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200200a01.opus"
    mx "Да не это!"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200210a01.opus"
    mx "Я хотела спросить, как она «по воле случая» смогла найти брошенного кота?"
    voice "voice/a51/2200220a01.opus"
    mx "Она решила пойти и взять одного котёнка из приюта, чтобы разыграть ту сцену из игры?"
    xy "А... ну..."
    "Она права."
    "Я не мог себе представить, что Аой могла зайти так далеко."
    xy "Может, это было совпадение?.."
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_hard")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200230a01.opus"
    mx "Совпадение? Серьёзно?"
    xy "Может, Бог отвечает на её молитвы?.."
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_fear")
    with Dissolve(200.0/1000)
    voice "voice/a51/2200240a01.opus"
    mx "......!"
    $ sename = "se人体_足音_走る美雪去る"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    xy "Миюки, стой! Куда ты—"
    voice "voice/a51/2200250a01.opus"
    mx "Домой."
    voice "voice/a51/2200260a01.opus"
    mx "Мне надо проверить кое-что. Я потом тебе позвоню."
    xy "Когда это «потом»?"
    hide 絵背景
    $ sename = "se物体_ドア体育_閉まる01"
    play se sedict[sename]
    with Dissolve(300.0/1000)
    pause (500/1000)
    xy "...Что она задумала, чёрт побери?"
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
