label e2242b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2244.nss"
    return
label e2242b:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(0.0/1000)

    xy "\"Почему бы нам не заказать еду на дом?\""
    voice "voice/e22/42b00010a01.opus"

    mx "\"В этом нет необходимости! Я приготовлю что-ни—\""

    xy "\"Я просто чувствую себя ужасно, заставляя тебя всё время готовить для меня.\""

    xy "\"Да и я сам никогда в жизни не готовил, так что...\""
    voice "voice/e22/42b00020a01.opus"

    mx "\"Точно...\""
    voice "voice/e22/42b00030a01.opus"

    mx "\"Ну ладно, думаю, я воспользуюсь твоим предложением.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
