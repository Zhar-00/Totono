label e1151a_MAIN:
    call expression GameName
    $ BackFile = "e1151a.nss";
    $ PreGameName = GameName
    return
label e1151a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    pause (16/1000)
    pause (16/1000)
    $ EmotionalNoMusic = True;
    scene expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ St("C",300,0,0,"fu曽根美雪_制服_病み_sad")
    pause (16/1000)
    $ persistent.meta_date += 1
    $ renpy.music.play("ttb22",channel = "bgm", if_changed = True)
    voice "voice/e11/51a00010a01.opus"

    mx "\"...Эй!\""
    voice "voice/e11/51a00011a01.opus"

    mx "\"Ты правда думаешь, что можешь сбежать от меня?\""
    voice "voice/e11/51a00020a01.opus"

    mx "\"А теперь целуй меня.\""
    voice "voice/e11/51a00030a01.opus"

    mx "\"Мы начнём всё с самого начала.\""
    menu:
        "Поцеловать её":
            $ SetChoiceSelect = 0
        "Не целовать её":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e1152a.nss";
    elif SetChoiceSelect==1:
        if (persistent.waste):
            $ GameName = "e1155.nss";
        else:
            $ GameName = "e1152b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
