label e1141b_MAIN:
    call expression GameName
    $ LF_e1141b_FirstPass = True;
    $ PassFile_e2318a = False;
    $ LF_NoLoadPassedFile_e1168=False;
    $ PreGameName = GameName
    $ GameName = "e2000.nss"
    return
label e1141b:
    $ persistent.imagelog["$LF_e1141b_FirstPass"]=True
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    hide 絵色黒
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    pause (500/1000)
    $ LF_NoLoadPassedFile_e1168=False;
    scene expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    call eroute_bgm
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/41b00010a01.opus"

    mx "\"Этот мир был модифицирован.\""
    voice "voice/e11/41b00020a01.opus"

    mx "\"Твои желания больше не имеют значения.\""
    voice "voice/e11/41b00030a01.opus"

    mx "\"Ты будешь жить здесь, в моём мире...\""
    voice "voice/e11/41b00040a01.opus"

    mx "\"...отныне и во веки веков.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/41b00050a01.opus"

    mx "\"Да... Всю вечность...\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
