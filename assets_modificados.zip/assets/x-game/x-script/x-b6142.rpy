label b6142_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a6143.nss"
    return
label b6142:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    $ sename = "se物体_携帯_開く"
    play se sedict[sename]
    pause (300/1000)
    show expression ("cg/ev/"+imagename["eva2151美雪アオイ心一写真b"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(500.0/1000)

    "Если закрыть глаза, я могу себе это представить..."

    "Воспоминания о дружбе, которую я уже не смогу вернуть."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
