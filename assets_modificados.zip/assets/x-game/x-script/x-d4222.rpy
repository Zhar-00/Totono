label d4222_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d4233.nss"
    return
label d4222:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010300_3_学校屋根"]+".jpg")
    show expression ("cg/ev/"+imagename["evc4221アオイ眠り姫a"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)

    "Я понятия не имел, как помочь ей. Я должен просто вызвать скорую."
    $ sename = "se人体_動作_ポケット探る"
    play se sedict[sename]

    "Я достал телефон из кармана."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
