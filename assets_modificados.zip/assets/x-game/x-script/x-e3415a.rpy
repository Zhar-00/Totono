label e3415a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3421.nss"
    return
label e3415a:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    $ sename = "se環境_水音_シャワーL"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg110600_3_マンション台所"]+".jpg")
    with Dissolve(0.0/1000)
    xy "......"
    show expression ("cg/bg/"+imagename["bg110200_3_マンション玄関鍵開け"]+".jpg")
    with Dissolve(1000.0/1000)
    pause (500/1000)
    show expression ("cg/bg/l/"+imagename["bg110200_3_マンション玄関鍵開け_l"]+".jpg") as 絵背景:
        pos (-70,-350)
    with Dissolve((1000.0+1000.0)/1000)
    pause (500/1000)
    $ sename = "se物体_ドア自宅_鍵開ける02"
    play se sedict[sename]
    pause (1000/1000)
    voice "voice/e34/15a00010a01.opus"

    mx "\"Стой!\""

    "Нет."
    $ sename = "se物体_ドアマンション_開く"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((800.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
