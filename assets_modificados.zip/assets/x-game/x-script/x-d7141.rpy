label d7141_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d7142.nss"
    return
label d7141:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg030200_3_自宅玄関"]+".jpg")
    pause (500/1000)
    $ sename = "se物体_ドア自宅_鍵開ける02"
    play se sedict[sename]
    pause (500/1000)
    hide 上背景
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (1000/1000)

    "...Всё кончено."

    "Мне больше не нужно мучиться из-за предательства своей девушки."

    "Я отомстил ей. Я доволен собой."

    "Наконец-то всё закончилось."

    "Всё."

    "Я приковылял в свой дом на своих дрожащих ногах."
    pause (500/1000)
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(800.0/1000)
    pause (1000/1000)
    $ St("C",300,0,0,"st曽根美雪_私服_病み_sad")
    with Dissolve(400.0/1000)
    pause (1000/1000)
    $ renpy.music.play("ttb24",channel = "bgm", if_changed = True)
    voice "voice/d71/4100010a01.opus"
    mx "\"Шиничи...\""

    xy "\"Миюки? Я даже не подозревал, что ты всё ещё здесь...\""

    "Я думал, что в гостиной уже никого нет..."

    "...и всё же она здесь, стоит и ждёт меня."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
