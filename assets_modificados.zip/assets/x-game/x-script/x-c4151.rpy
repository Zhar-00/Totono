label c4151_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4152.nss"
    return
label c4151:
    hide 絵色黒
    scene expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    hide 上背景
    "Это был последний раз, когда я видел Аой перед тем, как она исчезла."
    "И она оставила после себя только одного котёнка."
    "Это просто было так... внезапно."
    show expression Solid("000000") as 絵色黒上 zorder 10050
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010800_1_学校体育館"]+".jpg")
    with Dissolve(2000.0/1000)
    pause (300/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c41/5100010a01.opus"
    mx "\"Думаю, она хотела порвать с нами связи.\""
    "Пробормотала Миюки себе под нос."
    "И именно тогда я и подумал, что мы всё уже уладили."
    "Зачем Аой нас так мучить?"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c41/5100020a01.opus"
    mx "\"Ты не знаешь, где она может быть?\""
    "Конечно же нет."
    "У меня даже первой зацепки нет."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
