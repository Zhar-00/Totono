label e3423a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e3423a:
    hide 絵色黒
    $ renpy.music.play("ttb14",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e34/23a00010b02.opus"
    kmsm "\"ПРИГОТОВЬ МЕТОД ЗАПИСИ.\""
    voice "voice/e34/23a00020b02.opus"
    kmsm "\"РУЧКА С ЛИСТКОМ БУМАГИ, ТЕКСТОВЫЙ РЕДАКТОР, ЧЕГО УГОДНО БУДЕТ ВПОЛНЕ ДОСТАТОЧНО.\""
    voice "voice/e34/23a00030b02.opus"
    kmsm "\"[[ТЫ] ГОТОВ?\""
    "В смысле, я не знаю, что происходит, но допустим?"
    voice "voice/e34/23a00040b02.opus"
    kmsm "\"ЗАПИСЫВАЙ НОМЕР ТЕЛЕФОНА БОГА.\""
    "Я запустил приложение контактов."
    "Номер телефона Бога..."

    "999[persistent.god_number]。"
    voice "voice/e34/23a00050b02.opus"
    kmsm "\"ВОЗЬМИ ЭТОТ НОМЕР И ВЫЧТИ ИЗ НЕГО ВОСЬМИЗНАЧНОЕ ЧИСЛО СУБЪЕКТА.\""
    voice "voice/e34/23a00060b02.opus"

    kmsm "\"А ПОТОМ ПРИБАВЬ ПЕРЕМЕННУЮ МИЮКИ.\""

    xy "\"У Миюки есть своя переменная?\""
    voice "voice/e34/23a00070b02.opus"
    kmsm "\"ОТВЕТ ПОЛОЖИТЕЛЬНЫЙ.\""
    voice "voice/e34/23a00080b02.opus"
    kmsm "\"ЭТО ПОСЛЕДНИЙ БАРЬЕР, ПРЕПЯТСТВУЮЩИЙ ВОССТАНОВЛЕНИЮ АОЙ.\""
    voice "voice/e34/23a00090b02.opus"
    kmsm "\"И ЭТО ЧИСЛО, КОТОРОЕ НРАВИТСЯ МИЮКИ БОЛЬШЕ ВСЕГО.\""
    xy "\"В каком смысле, нравится больше всего?\""
    voice "voice/e34/23a00100b02.opus"
    kmsm "\"ДОБАВЬ ЕЁ ПЕРЕМЕННУЮ, И ЧИСЛО В РЕЗУЛЬТАТЕ ОКАЖЕТСЯ ИМЕННО ТЕМ, ЧЕГО [[ТЫ] ХОЧЕШЬ.\""
    voice "voice/e34/23a00110b02.opus"
    kmsm "\"ЭТО БУДЕТ КОДОВЫЙ НОМЕР, КОТОРЫЙ ДОЛЖЕН ВОССТАНОВИТЬ АОЙ.\""
    voice "voice/e34/23a00120b02.opus"
    kmsm "\"ЗАПРАШИВАЮ ОТКЛИК.\""
    $ active_time-=1 ;
    menu:
        "Ввести его":
            $ SetChoiceSelect = 0
        "Не вводить его":
            $ SetChoiceSelect = 1
        "Я не знаю переменную Миюки":
            $ SetChoiceSelect = 2
    if SetChoiceSelect==0:
        $ GameName = "e3424a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e3424b.nss";
    elif (SetChoiceSelect==2):
        $ GameName = "e3424d.nss";
    if (active_time <= 0):
        $ GameName = "e3424h.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
