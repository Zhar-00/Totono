label e2225c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2225c:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    show expression Solid("000000") as 絵色黒
    pause (2000/1000)
    with Dissolve(0.0/1000)
    voice "voice/e22/25c00010a01.opus"

    mx "А-ах... н-н-н... н-нг-гх-х... н-н... Каждый раз, когда ты кончаешь в меня..."
    voice "voice/e22/25c00020a01.opus"

    mx "Я чувствую себя такой уверенной... когда нахожусь здесь... Нахожусь рядом с тобой..."
    voice "voice/e22/25c00030a01.opus"

    mx "Всё кажется таким правильным..."
    voice "voice/e22/25c00040a01.opus"

    mx "Я ТЕБЯ никогда не отпущу..."
    pause (1000/1000)
    show expression Solid("000000") as 絵色黒
    pause (16/1000)
    hide 上背景
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
