label e3521a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "z1111.nss"
    return
label e3521a:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    show expression ("cg/bg/m/"+imagename["bg010300_9_学校屋根_m"]+".jpg") as 絵背景 zorder 100 at truecenter
    if (PreGameName == "e3522a"):
        $ renpy.music.play("ttb26",channel = "bgm", if_changed = True)
        $ St("C",300,0,0,"fu曽根美雪_制服_病み_sad")
        hide 上背景
    else:
        $ St("C",300,0,0,"fu曽根美雪_制服_通常_shock")
        pause (2000/1000)
        with Dissolve(1500.0/1000)
        pause (1000/1000)
        $ renpy.music.play("ttb26",channel = "bgm", if_changed = True)
        pause (1000/1000)
    $ St("C",300,0,0,"fu曽根美雪_制服_腕組み_sad")
    with Dissolve(800.0/1000)
    pause (300/1000)
    voice "voice/e35/21a00010a01.opus"
    mx "\"Ты уверен...\""
    $ St("C",300,0,0,"fu曽根美雪_制服_腕組み_hard")
    with Dissolve(500.0/1000)
    voice "voice/e35/21a00020a01.opus"
    mx "\"...что хочешь именно меня?\""
    $ St("C",300,0,0,"fu曽根美雪_制服_病み_ero")
    with Dissolve(500.0/1000)
    voice "voice/e35/21a00030a01.opus"
    mx "\"Можешь ли ты всё ещё любить меня... после всего того, что я сделала?\""
    menu:
        "Конечно, и я буду любить тебя.":
            pass
    menu:
        "Ты поверишь мне?":
            pass
    menu:
        "Я знаю, что не смогу это доказать...":
            pass
    menu:
        "Я знаю, что у нас всех есть только эти выборы...":
            pass
    menu:
        "Просто нажатие на экран...":
            pass
    menu:
        "Но мои чувства по ту сторону экрана - настоящие.":
            pass
    menu:
        "Ты мне поверишь?":
            pass
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_sad")
    with Dissolve(500.0/1000)
    voice "voice/e35/21a00040a01.opus"
    mx "\"Конечно.\""
    voice "voice/e35/21a00050a01.opus"
    mx "\"Ведь ТЫ выбрал меня.\""
    voice "voice/e35/21a00060a01.opus"
    mx "\"Очевидно, ТЫ хотел посмотреть на то, как закончится моя история.\""
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_smile")
    with Dissolve(500.0/1000)
    voice "voice/e35/21a00070a01.opus"
    mx "\"И для меня... это все доказательства, которые мне нужны.\""
    menu:
        "Даже после того, как мир будет сброшен, мы всё ещё будем вместе.":
            pass
    menu:
        "Так ведь?":
            pass
    voice "voice/e35/21a00080a01.opus"
    mx "\"Да.\""
    menu:
        "Давай вернёмся.":
            pass
    voice "voice/e35/21a00090a01.opus"
    mx "\"Да... Кроме того, я прекрасно знаю...\""
    voice "voice/e35/21a00100a01.opus"
    mx "\"...как сильно ТЫ любишь меня.\""
    voice "voice/e35/21a00110a01.opus"
    mx "\"И я знаю, что наша любовь вечна.\""
    menu:
        "...Да.":
            pass
    menu:
        "Это судьба.":
            pass
    menu:
        "...Пошли, Миюки.":
            pass
    voice "voice/e35/21a00120a01.opus"
    mx "\"Да.\""
    show expression ("cg/bg/l/"+imagename["bg010300_9_学校屋根_l"]+".jpg") as 絵上背景:
        pos (-512,-500)
    with Dissolve((2000.0+1000.0)/1000)
    menu:
        "Мы развернулись...":
            pass
    menu:
        "...но её уже не было.":
            pass
    menu:
        "Кто она была?":
            pass
    menu:
        "Мы это уже никогда не узнаем.":
            pass
    menu:
        "Меня переполняло неописуемое чувство утраты.":
            pass
    menu:
        "Но оно, скорее всего, вскоре исчезнет.":
            pass
    menu:
        "Всё же я сам выбрал этот путь.":
            pass
    menu:
        "И это всего лишь мелочи.":
            pass
    hide StC
    hide StMR
    hide StML
    pause (1000/1000)
    $ St("C",300,0,0,"fu曽根美雪_制服_通常_smile")
    with Dissolve(500.0/1000)
    voice "voice/e35/21a00130a01.opus"
    mx "\"Давай всё исправим.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(300.0/1000)
    pause (500/1000)
    menu:
        "Её телефон лежал забытый на земле.":
            pass
    menu:
        "Она посмотрела на его экран.":
            pass
    menu:
        "Потом она нажала на кнопку вызова...":
            pass
    menu:
        "...и начала откат.":
            pass
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_sad")
    with Dissolve(500.0/1000)
    voice "voice/e35/21a00140a01.opus"
    mx "\"Можешь сделать для меня одолжение?\""
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_shy")
    with Dissolve(500.0/1000)
    voice "voice/e35/21a00150a01.opus"
    mx "\"Ты поцелуешь меня? То есть, на этот раз - по-настоящему?\""
    voice "voice/e35/21a00160a01.opus"
    mx "\"В прошлый раз... Боже, это было так унизительно...\""
    menu:
        "Да, я знаю.":
            pass
    menu:
        "На этот раз я уверен, что смогу это сделать.":
            pass
    menu:
        "И потом, мы поклялись друг другу в своей вечной любви.":
            pass
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_smile")
    with Dissolve(500.0/1000)
    voice "voice/e35/21a00170a01.opus"
    mx "\"...Верно.\""
    menu:
        "С нашими сердцами, полными надежды...":
            pass
    menu:
        "...и переполненными любовью...":
            pass
    menu:
        "...и с последними следами угрызений совести...":
            pass
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    stop bgm fadeout (3000.0/1000)
    menu:
        "...мы отправили сигнал.":
            pass
    show expression Solid("FFFFFF") as 絵色白
    pause (16/1000)
    stop se fadeout (0.0/1000)
    stop bgm fadeout (0.0/1000)
    pause (200/1000)
    $ sename = "se環境_雰囲気_世界改変完了"
    play se sedict[sename]
    $ sename = "se環境_雰囲気_世界改変完了"
    play se sedict[sename]
    pause (500/1000)
    $ persistent.aoi_back = False;
    $ persistent.miyuki_true = True;
    $ persistent.final_select_miyuki = False;
    $ persistent.title_on = False;
    $ persistent.c_route = False
    $ persistent.rlock = False
    $ renpy.quit(relaunch=True)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
