label a0113x_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "f1111.nss"
    return
label a0113x:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression "cg/bg/bg010200_2_学校屋上.jpg"
    $ sename = "se物体_携帯_発信待機L"
    play se sedict[sename]
    pause (1400/1000)
    pause (800/1000)
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]
    pause (5000/1000)
    $ sename = "se物体_携帯_繋がる"
    play se sedict[sename]
    pause (1000/1000)
    xy "Эм... алло?"
    "О боже, я набрал случайный номер, и там взяли трубку!"
    xy "Эм..."
    voice "voice/a01/13x00010b02.opus"
    kmsm "АОЙ МУКО УСПЕШНО СИНХРОНИЗИРОВАНА."
    voice "voice/a01/13x00020b02.opus"
    kmsm "ВНИМАНИЕ: ОТКАТ ЭМОЦИОНАЛЬНЫХ ОШИБОК НЕ УВЕНЧАЛСЯ УСПЕХОМ."
    xy "Какой ещё откат?.."
    voice "voice/a01/13x00030b02.opus"
    kmsm "УЧИТЫВАЯ ПРОИСХОЖДЕНИЕ ЭТОГО БАГА, ЕЁ ЭМОЦИИ СУЩЕСТВУЮТ НЕЗАВИСИМО ОТ САМОЙ СИСТЕМЫ."
    voice "voice/a01/13x00040b02.opus"
    kmsm "СЛЕДОВАТЕЛЬНО, ЕСЛИ СУБЪЕКТ САМ ТОГО ЖЕЛАЕТ..."
    voice "voice/a01/13x00050b02.opus"
    kmsm "ТО ЕСТЬ ВЕРОЯТНОСТЬ, ЧТО {i}ТЫ{/i} СМОЖЕШЬ ВСТРЕТИТЬ {i}ЕЁ{/i} ВНОВЬ... В ДРУГОЙ ВСЕЛЕННОЙ."
    $ sename = "se物体_携帯_繋がる"
    play se sedict[sename]
    pause (1000/1000)
    $ sename = "se物体_携帯_圏外"
    play se sedict[sename]
    pause (4000/1000)
    "После этого связь прервалась."
    "Кто это был?"
    "Вся эта неразбериха с «багом в системе» не имеет для меня никакого смысла..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
