label e2155_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2155:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010400_2_学校校門"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(0.0/1000)
    voice "voice/e21/5500010a01.opus"

    mx "\"Но тем не менее...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/5500020a01.opus"

    mx "\"У нас больше НЕТ никаких друзей.\""
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
