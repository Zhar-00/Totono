label e2325_MAIN:
    call expression GameName
    $ persistent.imagelog["eve2325美雪メタセックスa"]=True
    $ persistent.imagelog["eve2325美雪メタセックスb"]=True
    $ persistent.imagelog["eve2325美雪メタセックスc"]=True
    $ persistent.imagelog["eve2325美雪メタセックスd"]=True
    $ PreGameName = GameName
    $ persistent.ejaculation += 1;
    $ PreGameName = GameName
    $ GameName = "e2326.nss"
    $ persistent.library_scene10 = True;
    hide 和谐的黑色 onlayer hexie
    if (RECO_PLAY==1):
        $ GameCircle=False;
    return
label e2325:
    hide 絵色黒
    $ renpy.music.play("ttb27",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_sad")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/e23/2500010a01.opus"
    $ store_say("美雪","Давай займёмся сексом... ладно?")
    $ renpy.pause()
    $ St("C",300,0,0,"fu曽根美雪_私服_病み_ero")
    with Dissolve(200.0/1000)
    voice "voice/e23/2500020a01.opus"
    $ store_say("美雪","Не надо стесняться.")
    $ renpy.pause()
    voice "voice/e23/2500030a01.opus"
    $ store_say("美雪","Я хочу заняться любовью с ТОБОЙ напрямую... не с Шиничи.")
    $ renpy.pause()
    $ sename = "se人体_動作_衣擦れ濡れ場03"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (1000/1000)
    voice "voice/e23/2500040a01.opus"
    $ store_say("美雪","Я хочу почувствовать ТЕБЯ внутри себя...")
    $ renpy.pause()
    $ sename = "se人体_動作_衣擦れ濡れ場03"
    play se sedict[sename]
    show expression ("cg/ev/"+imagename["eve2325美雪メタセックスa"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(1000.0/1000)
    pause (800/1000)
    voice "voice/e23/2500050a01.opus"
    $ store_say("美雪","...ТЫ видишь это?")
    $ renpy.pause()
    with Dissolve(800.0/1000)
    pause (500/1000)
    voice "voice/e23/2500060a01.opus"
    $ store_say("美雪","ТЫ видишь, как сильно я намокла?")
    $ renpy.pause()
    voice "voice/e23/2500070a01.opus"
    $ store_say("美雪","Знаешь, ТЕБЕ очень повезло.\nВ японской версии игры ТЫ бы увидел мозаику.")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスa_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    pause (500/1000)
    voice "voice/e23/2500080a01.opus"
    $ store_say("美雪","Слушай... из меня сейчас течёт целая струя...")
    $ renpy.pause()
    voice "voice/e23/2500090a01.opus"
    $ store_say("美雪","Мысль о том, чтобы потрахаться с ТОБОЙ... так меня заводит... Я вся намокла...")
    $ renpy.pause()
    voice "voice/e23/2500100a01.opus"
    $ store_say("美雪","А что насчёт ТЕБЯ?")
    $ renpy.pause()
    voice "voice/e23/2500110a01.opus"
    $ store_say("美雪","У ТЕБЯ в штанах палатка?")
    $ renpy.pause()
    voice "voice/e23/2500120a01.opus"
    $ store_say("美雪","Или ТЫ уже вытащил свой член?")
    $ renpy.pause()
    voice "voice/e23/2500130a01.opus"
    $ store_say("美雪","У ТЕБЯ он уже твёрже алмазов?..")
    $ renpy.pause()
    voice "voice/e23/2500140a01.opus"
    $ store_say("美雪","Давай... Ласкай СЕБЯ. Дрочи его для меня.")
    $ renpy.pause()
    show expression ("cg/ev/"+imagename["eve2325美雪メタセックスa"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    pause (500/1000)
    voice "voice/e23/2500150a01.opus"
    $ store_say("美雪","А-ах... н-н-н... н-н... Да... я слышу это...\nЭто звук ТВОЕЙ руки, которая массирует ТВОЙ член, верно?")
    $ renpy.pause()
    voice "voice/e23/2500160a01.opus"
    $ store_say("美雪","ТЫ не веришь мне, да?\nТЫ правда думаешь, что я не слышу всё то, что ТЫ там делаешь?")
    $ renpy.pause()
    voice "voice/e23/2500170a01.opus"
    $ store_say("美雪","Ну, я слышу это. Я вижу это. Я чувствую это.")
    $ renpy.pause()
    voice "voice/e23/2500180a01.opus"
    $ store_say("美雪","Я знаю, что ТЫ сейчас наяриваешь свой член на мою мокрую киску...")
    $ renpy.pause()
    voice "voice/e23/2500190a01.opus"
    $ store_say("美雪","Откуда я знаю? ...Потому что я люблю ТЕБЯ.")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスa_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    pause (500/1000)
    voice "voice/e23/2500200a01.opus"
    $ store_say("美雪","Смотри... ТЫ видишь мою грудь? Посмотри на мои сосочки... Н-н-н-н... Они такие твёрдые...")
    $ renpy.pause()
    voice "voice/e23/2500210a01.opus"
    $ store_say("美雪","Я знаю, что ТЫ не можешь их потрогать, но... А-ах...\nМоё сердце так бешено колотится... Н-н-н...")
    $ renpy.pause()
    voice "voice/e23/2500220a01.opus"
    $ store_say("美雪","Я представляю... как ТВОИ невидимые пальцы...\nщипают и крутят мои соски...")
    $ renpy.pause()
    voice "voice/e23/2500230a01.opus"
    $ store_say("美雪","Представь себе это со мной, ладно?\nПредставь, как ТВОИ руки... а-а-ах... лежат на моей груди... Н-н-нг!!!")
    $ renpy.pause()
    show expression ("cg/ev/"+imagename["eve2325美雪メタセックスa"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    pause (500/1000)
    voice "voice/e23/2500240a01.opus"
    $ store_say("美雪","Слушай... Прости, но...")
    $ renpy.pause()
    voice "voice/e23/2500250a01.opus"
    $ store_say("美雪","Я не могу... больше ждать...")
    $ renpy.pause()
    voice "voice/e23/2500260a01.opus"
    $ store_say("美雪","Всё это время, я фантазировала о ТВОЁМ члене...")
    $ renpy.pause()
    voice "voice/e23/2500270a01.opus"
    $ store_say("美雪","И теперь, наконец-то, здесь только ТЫ и я.")
    $ renpy.pause()
    voice "voice/e23/2500280a01.opus"
    $ store_say("美雪","Моё тело такое горячее... я больше не могу...\nя больше не могу сдерживаться... я...")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスa_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    pause (500/1000)
    voice "voice/e23/2500290a01.opus"
    $ store_say("美雪","Я сейчас... вставлю его в себя...")
    $ renpy.pause()
    voice "voice/e23/2500300a01.opus"
    $ store_say("美雪","Р-ргх... н-н... н-н-н...")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスb_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    pause (500/1000)
    voice "voice/e23/2500310a01.opus"
    $ store_say("美雪","Н-н-н-н-н-нг-г-г-гх-х-х!!!")
    $ renpy.pause()
    voice "voice/e23/2500320a01.opus"
    $ store_say("美雪","А-ах... а-а-ах... а-а-а-а-ах!!!..")
    $ renpy.pause()
    voice "voice/e23/2500330a01.opus"
    $ store_say("美雪","Он внутри меня!..\nТВОЙ толстый член... во мне!..")
    $ renpy.pause()
    voice "voice/e23/2500340a01.opus"
    $ store_say("美雪","Я так счастлива...\nЭто... самое счастливое мгновение в моей жизни...")
    $ renpy.pause()
    voice "voice/e23/2500350a01.opus"
    $ store_say("美雪","Я сейчас могла бы умереть от счастья...")
    $ renpy.pause()
    voice "voice/e23/2500360a01.opus"
    $ store_say("美雪","А что насчёт ТЕБЯ?.. Тебе... н-н-нгх...\nприятно... внутри меня?..")
    $ renpy.pause()
    voice "voice/e23/2500370a01.opus"
    $ store_say("美雪","Каждый раз... Н-н-нгх!!!\nКаждый раз, когда я прыгаю вверх и вниз, я чувствую ТВОЙ член...")
    $ renpy.pause()
    voice "voice/e23/2500380a01.opus"
    $ store_say("美雪","И... удовольствие, которое ТЫ чувствуешь от наяривания СВОЕГО члена прямо сейчас...\nЭто моя киска...")
    $ renpy.pause()
    show expression ("cg/ev/"+imagename["eve2325美雪メタセックスb"]+".jpg") as 絵専 zorder 1100 at truecenter
    voice "voice/e23/2500390a01.opus"
    $ store_say("美雪","Н-н-н... н-н-нг! Н-н-н! Н-н-н-нг-г-гх-х!!!\nО боже... я пронзаю себя ТВОИМ горячим членом... А-а-ах!")
    $ renpy.pause()
    with Dissolve(800.0/1000)
    voice "voice/e23/2500400a01.opus"
    $ store_say("美雪","Н-н-нг! Моё тело— двигается— само по себе— Н-н-нг-гх-х!!!\nН-нха-а-а! А-ах! А-ах! А-а-а-ах!!!")
    $ renpy.pause()
    voice "voice/e23/2500410a01.opus"
    $ store_say("美雪","О боже... О БОЖЕ!..\nЭто... самый горячий секс, который у меня когда-либо был!..")
    $ renpy.pause()
    voice "voice/e23/2500420a01.opus"
    $ store_say("美雪","В кои-то веки... Н-н-нгх... я смогу получить удовольствие от ТЕБЯ...\nне используя Шиничи как прослойку!..")
    $ renpy.pause()
    voice "voice/e23/2500430a01.opus"
    $ store_say("美雪","Я так долго хотела этого... Н-н-нгх!\nТЫ даже не представляешь!")
    $ renpy.pause()
    voice "voice/e23/2500440a01.opus"
    $ store_say("美雪","В смысле... Зачем заниматься сексом с чистым листом, который меняет\nсвой характер в зависимости от сделанных выборов?")
    $ renpy.pause()
    voice "voice/e23/2500450a01.opus"
    $ store_say("美雪","Лично я всегда думала... что я бы лучше занялась любовью...\nс человеком по ту сторону!..")
    $ renpy.pause()
    voice "voice/e23/2500460a01.opus"
    $ store_say("美雪","Скажи мне... ТЕБЕ нравится моя киска?\nТЫ получаешь от неё удовольствие? Однозначно получаешь, да?")
    $ renpy.pause()
    voice "voice/e23/2500470a01.opus"
    $ store_say("美雪","Тебе очень приятно, да? Лучшее, что у ТЕБЯ когда-либо было?\nИ это всё, о чём ТЫ сейчас можешь думать, верно?")
    $ renpy.pause()
    voice "voice/e23/2500480a01.opus"
    $ store_say("美雪","Н-н-нг... н-н-н... Да, я знаю.\nПоверь мне... я могу сказать точно...")
    $ renpy.pause()
    voice "voice/e23/2500490a01.opus"
    $ store_say("美雪","Я вижу ТЕБЯ... Нет, правда вижу!\nЯ чувствую ТЕБЯ! Я чувствую ТВОЙ член!")
    $ renpy.pause()
    voice "voice/e23/2500500a01.opus"
    $ store_say("美雪","Можешь называть это игровой зависимостью, если хочешь.\nВозможно, я не могу отличить реальность от фантазии.")
    $ renpy.pause()
    voice "voice/e23/2500510a01.opus"
    $ store_say("美雪","Я знаю лишь то, что... я люблю ТЕБЯ, дорогой.")
    $ renpy.pause()
    show expression ("cg/ev/"+imagename["eve2325美雪メタセックスc"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(300.0/1000)
    voice "voice/e23/2500520a01.opus"
    $ store_say("美雪","Н-нха-а-а-а! А-а-а-ах! Ох, блядь!\nО боже! Это так интенсивно! Я сейчас— я сейчас—!!!")
    $ renpy.pause()
    voice "voice/e23/2500530a01.opus"
    $ store_say("美雪","Н-н-нг! Н-нха-а-а! А-ах! А-ах! Я скоро кончу—\nА-ах... н-н-нг... Нет... н-н-нг-г... Ещё нет—")
    $ renpy.pause()
    voice "voice/e23/2500540a01.opus"
    $ store_say("美雪","Я не могу— пока кончить—! Я люблю ТЕБЯ— так что—\nА-ах! Я хочу, чтобы мы— кончили вместе—!")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスc_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    voice "voice/e23/2500550a01.opus"
    $ store_say("美雪","Н-н-н... н-н-нг-гх!.. Но... А-а-а-ах!\nЯ... не могу... Хн-н-нг... г-гх-х... н-н-н-нг!..")
    $ renpy.pause()
    voice "voice/e23/2500560a01.opus"
    $ store_say("美雪","Я люблю ТЕБЯ... Я так полна... любви к ТЕБЕ... Н-н-нг!\nЯ не могу остановиться... Я не могу перестать любить ТЕБЯ!..")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスa_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    voice "voice/e23/2500570a01.opus"
    $ store_say("美雪","Я люблю ТЕБЯ... Я люблю ТЕБЯ... Я очень люблю ТЕБЯ!.. Хн-н-нг... г-гх...\nЯ люблю ТЕБЯ... Я люблю ТЕБЯ... Я так сильно ТЕБЯ люблю... А-а-а-ах!")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスb_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/e23/2500580a01.opus"
    $ store_say("美雪","Н-н-н... Кончай со мной!.. А-а-а-ах! Ха-а! А-ах! А-ах!\nВыплесни СВОЮ сперму... в меня!..")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスc_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(400.0/1000)
    voice "voice/e23/2500590a01.opus"
    $ store_say("美雪","Я хочу... н-н-нг... всю её!.. А-аха-а-ах...\nТеперь... мы можем... кончить вместе... Ха-а-а-а!")
    $ renpy.pause()
    show expression ("cg/ev/"+imagename["eve2325美雪メタセックスc"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    voice "voice/e23/2500600a01.opus"
    $ store_say("美雪","Заполни мою киску... Н-н-н-нг!!!\nОплодотвори меня... н-н-нг... СВОЕЙ спермой!..")
    $ renpy.pause()
    voice "voice/e23/2500610a01.opus"
    $ store_say("美雪","Ха-а-а-а-а! А-ах! А-ах! А потом...\nН-н-нг-гх! Н-н-н... н-н-нг! Я... я хочу...")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスc_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/e23/2500620a01.opus"
    $ store_say("美雪","Я хочу... родить ТЕБЕ ребёнка!..")
    $ renpy.pause()
    voice "voice/e23/2500630a01.opus"
    $ store_say("美雪","Так что... пожалуйста! А-а-а-ах! А-ах! А-ах!!!\nПожалуйста... отдай его мне! Отдай мне СВОЁ семя!")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスd_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/e23/2500640a01.opus"
    $ store_say("美雪","Н-н-нг... ТЫ уже близко? Я тоже! А-а-а-ах—!!!")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスb_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/e23/2500650a01.opus"
    $ store_say("美雪","ТВОЙ огромный член просто горит...\nЯ могу сказать точно... ТЫ умираешь от желания расслабиться!..")
    $ renpy.pause()
    voice "voice/e23/2500660a01.opus"
    $ store_say("美雪","Отдай мне её всю! Опустоши СВОИ яички во мне!\nЯ хочу ребёнка— подари мне СВОЕГО ребёнка—!")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスc_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/e23/2500670a01.opus"
    $ store_say("美雪","Я люблю ТЕБЯ! Я люблю ТЕБЯ! Я люблю ТЕБЯ, я люблю ТЕБЯ, о боже, Я ЛЮБЛЮ ТЕБЯ!\nТЫ даже не представляешь... как сильно я люблю ТЕБЯ!!!")
    $ renpy.pause()
    voice "voice/e23/2500680a01.opus"
    $ store_say("美雪","Н-нха-а-а-а! Я кончаю! Кончай со мной— Я кончаю, я кончаю, я кончаю—\nН-н-н-нха-а-а-а-а-а!")
    $ renpy.pause()
    hide 絵色黒
    $ renpy.music.play("ttb27",channel = "bgm", if_changed = True)
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスc_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression Solid("FFFFFF") as 絵色白 zorder 5000
    with Dissolve(0.0/1000)
    with Dissolve((1000.0+1000.0)/1000)
    with Dissolve((1000.0+1000.0)/1000)
    voice "voice/e23/2500690a01.opus"
    $ store_say("美雪","А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-АХ!!!")
    $ renpy.pause()
    with Dissolve((0.0+1000.0)/1000)
    pause (1000/1000)
    show expression ("cg/ev/"+imagename["eve2325美雪メタセックスd"]+".jpg") as 絵専 zorder 1100 at truecenter
    hide 絵絶頂板
    hide 絵色白
    with Dissolve(1500.0/1000)
    voice "voice/e23/2500700a01.opus"
    $ store_say("美雪","Н-н-нг! Н-нха-а! А-ах... а-а-а-ах! Н-н-н... н-нг-гх...\nн-н-н... н-н-нг-г... н-н-нг-г-гх-х... н-н... н-н-н...")
    $ renpy.pause()
    voice "voice/e23/2500710a01.opus"
    $ store_say("美雪","Хн-н... н-н-н... н-н... н-н-н-н... Я чувствую это...\nТВОЯ... сперма... во... мне...")
    $ renpy.pause()
    voice "voice/e23/2500720a01.opus"
    $ store_say("美雪","Её так много... Н-н-нгх... н-н-н...\nЯ чувствую её... Н-нг-гх-х... а-ах... н-н...")
    $ renpy.pause()
    voice "voice/e23/2500730a01.opus"
    $ store_say("美雪","Я... Н-н-н... н-н... Я так счастлива...\nЯ чувствую себя... такой полноценной...")
    $ renpy.pause()
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスa_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/e23/2500740a01.opus"
    $ store_say("美雪","Хе-хе-хе... Ты только посмотри на нас...")
    $ renpy.pause()
    voice "voice/e23/2500750a01.opus"
    $ store_say("美雪","Мы занимались сексом...")
    $ renpy.pause()
    voice "voice/e23/2500760a01.opus"
    $ store_say("美雪","ТЫ знаешь, сколько раз ТЫ занимался со мной сексом?")
    $ renpy.pause()
    voice "voice/e23/2500770a01.opus"
    $ store_say("美雪","ТЫ помнишь, сколько раз ТЫ кончал в меня?")
    $ renpy.pause()
    voice "voice/e23/2500780a01.opus"
    $ store_say("美雪","Потому что я помню.")
    $ renpy.pause()
    voice "voice/e23/2500790a01.opus"
    $ store_say("美雪","Всё это записано у меня в дневнике. Всё это.")
    $ renpy.pause()
    voice "voice/e23/2500800a01.opus"
    $ store_say("美雪","В смысле, как я могла не записать это?")
    $ renpy.pause()
    voice "voice/e23/2500810a01.opus"
    $ store_say("美雪","Это знак нашей любви.")
    $ renpy.pause()
    stop bgm fadeout (10000.0/1000)
    show expression ("cg/ev/l/"+imagename["eve2325美雪メタセックスa_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    pause (500/1000)
    voice "voice/e23/2500820a01.opus"
    $ store_say("美雪","...Я люблю ТЕБЯ.")
    $ renpy.pause()
    voice "voice/e23/2500830a01.opus"
    $ store_say("美雪","Я так сильно ТЕБЯ люблю.")
    $ renpy.pause()
    voice "voice/e23/2500840a01.opus"
    $ store_say("美雪","ТЫ всегда будешь рядом со мной... так ведь?")
    $ renpy.pause()
    voice "voice/e23/2500850a01.opus"
    $ store_say("美雪","С этого момента... до скончания веков...")
    $ renpy.pause()
    voice "voice/e23/2500860a01.opus"
    $ store_say("美雪","На веки вечные...")
    $ renpy.pause()
    voice "voice/e23/2500870a01.opus"
    $ store_say("美雪","Пожалуйста...")
    $ renpy.pause()
    pause (2000/1000)
    stop bgm fadeout (300.0/1000)
    show expression Solid("000000") as 絵色黒
    pause (16/1000)
    hide 上背景
    pause (4000/1000)
    if (RECO_PLAY==1):
        pass
    else:
        $ persistent.meta_sex = True;
        python:
            if persistent.passed_meta_sex_month == None or persistent.passed_meta_sex_day == None:
                from time import strftime, localtime
                persistent.passed_meta_sex_month = int(strftime("%m",localtime()))
                persistent.passed_meta_sex_day = int(strftime("%d",localtime()))
                persistent.DIARY_COUNT += 1
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
