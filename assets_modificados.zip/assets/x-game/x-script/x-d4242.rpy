label d4242_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d6111.nss"
    return
label d4242:
    hide 絵色黒
    $ renpy.music.play("ttb12",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15 at truecenter
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(0.0/1000)
    xy "\"Миюки.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/d42/4200010a01.opus"

    mx "\"Д-да?..\""

    xy "\"Я уже давно отрицал это... И постоянно обходил этот вопрос стороной...\""

    xy "\"Но с помощью Аой, я наконец-то встретился лицом к лицу со своими чувствами.\""

    "Я сделал глубокий вдох."

    "Эти слова изменят нашу жизнь навсегда."

    xy "\"Я люблю тебя.\""

    xy "\"Я всегда любил тебя.\""
    xy "\"И я хочу быть с тобой!\""
    $ sename = "se人体_動作_抱きつく02"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((300.0+1000.0)/1000)

    xy "\"Пожалуйста, будь моей!\""

    "Я склонил перед ней голову..."

    "...и ждал."

    "Я ждал... и ждал... и ждал... пока я больше не мог ждать."
    hide StC with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_ero")
    hide 絵色黒
    with Dissolve(500.0/1000)
    voice "voice/d42/4200020a01.opus"

    mx "\"......Шиничи.\""

    "Миюки стояла там, она не скрывалась за какой-либо личностью и была абсолютно уязвимой."
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/d42/4200030a01.opus"

    mx "\"Я ждала этого всё время...\""

    "По её щеке скатилась слеза."

    "Мы оба знали..."

    "...это слеза счастья."
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/d42/4200040a01.opus"

    mx "\"...Эй, Шиничи?\""
    voice "voice/d42/4200050a01.opus"

    mx "\"Если ты правда любишь меня...\""
    voice "voice/d42/4200060a01.opus"

    mx "\"...то поцелуешь меня?\""

    "Я мог почувствовать её дыхание."

    "Её глаза были в паре сантиметров от моих."

    "Воспоминания, которые когда-то удерживали меня, теперь разлетались по ветру, словно пепел."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1500.0+1000.0)/1000)
    pause (1000/1000)

    "Они говорят, что жизнь - это череда выборов."

    "Но это просто чушь собачья."

    "Бог не играет в кости."

    "Никаких «что, если» не существует."

    "Именно синапсы в нашем мозгу делают за нас выбор."

    "Это всё, что есть."

    "Всё это - судьба."

    "И нам ещё с самого начала было суждено быть вместе."
    hide 絵色黒
    with Dissolve(2000.0/1000)
    pause (1000/1000)
    xy "\"Миюки—!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/d42/4200070a01.opus"
    mx "\"Шиничи...\""
    hide StC with Dissolve(200.0/1000)
    $ sename = "se人体_動作_起き上がる02"
    play se sedict[sename]

    "Я нежно обнял её своими руками..."

    "...и поцеловал её в губы."
    stop bgm fadeout (4000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)

    "И после этого, наши сердца наконец-то стали единым целым."
    $ EyeCatchIn(2000.0)
    show expression Solid("FFFFFF") as 絵色白 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
