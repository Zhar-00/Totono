label e2226_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2226:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)

    xy "\"Давай вернёмся к тому, как всё было.\""
    voice "voice/e22/2600010a01.opus"

    mx "\"Это ещё что должно означать?\""

    "Голос Миюки в одно мгновение вернулся в норму."

    xy "\"Просто... я хочу, чтобы мы вернулись к нашей обычной жизни. Так будет лучше.\""

    xy "\"В смысле, я знаю, что ты находишь наряд горничной унизительным. Так что я не буду против, если ты будешь носить свою нормальную о—\""
    $ sename = "se物体_照明_スイッチ"
    play se sedict[sename]
    hide 絵色黒
    pause (30/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_hard")
    hide 絵色白
    with Dissolve(1600.0/1000)
    pause (500/1000)
    call eroute_bgm
    pause (1500/1000)
    voice "voice/e22/2600020a01.opus"

    mx "\"Понятно.\""
    xy "\"А?..\""

    xy "\"Ты всё-таки не надела его?..\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e22/2600030a01.opus"

    mx "\"Если ты так думаешь, я не буду тебя заставлять.\""
    voice "voice/e22/2600040a01.opus"

    mx "\"Хочешь побыть упрямым? Флаг тебе в руки.\""

    xy "\"Я вовсе не упрямый—\""
    $ St("C",300,0,0,"bu曽根美雪_私服_病み_normal")
    voice "voice/e22/2600050a01.opus"

    mx "\"Но ты пожалеешь об этом. Это я тебе обещаю.\""
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
