label a1191_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010400_2_学校校門"]=True
    $ persistent.imagelog["bg010500_2_学校昇降口"]=True
    $ persistent.imagelog["bg040100_2_街通学路"]=True
    $ persistent.imagelog["efbg空汎用満月"]=True
    $ PreGameName = GameName
    $ GameName = "a1201.nss"
    return
label a1191:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010500_1_学校昇降口"]+".jpg")
    with Dissolve(1000.0/1000)
    voice "voice/a11/9100010a02.opus"
    aoi "Доброе утро, Миюки."
    voice "voice/a11/9100020a02.opus"
    aoi "Сегодня очередной ветреный день."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((750.0+1000.0)/1000)
    hide StC with Dissolve(0.0/1000)
    pause (750/1000)
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    hide 絵色黒
    with Dissolve(750.0/1000)
    voice "voice/a11/9100030a02.opus"
    aoi "Миюки, хочешь посмотреть на мой обед?"
    voice "voice/a11/9100040a02.opus"
    aoi "От этой конфетки твой язык раскрашивается в весёлые цвета."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((750.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010700_1_学校廊下"]+".jpg")
    pause (750/1000)
    hide 絵色黒
    with Dissolve(750.0/1000)
    voice "voice/a11/9100050a02.opus"
    aoi "Миюки, хочешь поиграть со мной в эту игру?"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((750.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010600_2_学校教室"]+".jpg")
    pause (750/1000)
    hide 絵色黒
    with Dissolve(750.0/1000)
    voice "voice/a11/9100060a02.opus"
    aoi "Миюки, давай убираться вме—"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((750.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010500_2_学校昇降口"]+".jpg")
    pause (750/1000)
    hide 絵色黒
    with Dissolve(750.0/1000)
    voice "voice/a11/9100070a02.opus"
    aoi "Миюки, хочешь пойти домой—"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((750.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010400_2_学校校門"]+".jpg")
    pause (750/1000)
    hide 絵色黒
    with Dissolve(750.0/1000)
    voice "voice/a11/9100080a02.opus"
    aoi "Миюки, стой—!"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((750.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg")
    pause (750/1000)
    hide 絵色黒
    with Dissolve(750.0/1000)
    voice "voice/a11/9100090a02.opus"
    aoi "Миюки—!"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((750.0+1000.0)/1000)
    show expression ("cg/ef/"+imagename["efbg空汎用満月_雲"]+".png") as 絵背景上 zorder 110 at center
    with Dissolve((0.0+950.0)/1000)
    show expression ("cg/ef/"+imagename["efbg空汎用満月"]+".jpg") as 絵背景 zorder 100 at center
    pause (750/1000)
    hide 絵色黒
    with Dissolve(750.0/1000)
    voice "voice/a11/9100100a02.opus"
    aoi "Миюки..."
    pause (300/1000)
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 10050
    $ EyeCatchIn(2000.0)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
