label a5131_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if aoi_sex0 == True:
        $ GameName = "c5132.nss"
    else:
        $ GameName = "a5132.nss"
    return
label a5131:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve(1000.0/1000)
    xy "Простите за опоздание."
    $ sename = "se環境_ガヤ_教室授業中L"
    play se sedict[sename]
    "К тому времени, когда я вернулся, первый урок уже начался."
    $ sename = "se人体_動作_起き上がる02"
    play se sedict[sename]
    "Я извинился перед учителем и сел за свою парту обратно."
    $ sename = "se物体_紙_取り出す"
    play se sedict[sename]
    xy "Хм?"
    voice "voice/a51/3100010b01.opus"
    xtl "......! ......!"
    "Ютаро передал мне записку с улыбкой."
    "—Она тебя отшила? Она отшила тебя, да?!"
    xy "Ха-а..."
    "Я вздохнул и смял записку в шарик."
    "И как только я поднял свой взгляд—"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
