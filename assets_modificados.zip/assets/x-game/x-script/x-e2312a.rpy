label e2312a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2312a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110600_2_マンション台所"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_smile")
    with Dissolve(0.0/1000)

    xy "\"Ха-а... Ладно.\""

    xy "\"Я сам не настолько уверен в себе, так что наблюдай за мной, ладно?\""
    if (persistent.world_recreate):
        $ GameName = "e2313c.nss";
    else:
        $ GameName = "e2313b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
