label c6173_MAIN:
    call expression GameName
    $ persistent.imagelog["bg100100_3_マンション外正面"]=True
    $ PreGameName = GameName
    $ GameName = "c6181.nss"
    return
label c6173:
    hide 絵色黒
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg080100_3_コンビニ外正面"]+".jpg")
    $ St("MR",300,0,0,"st曙雄太郎_バイト_通常_hard")
    with Dissolve(0.0/1000)
    $ St("MR",300,0,0,"st曙雄太郎_バイト_通常_sad")
    voice "voice/c61/7300010b01.opus"

    xtl "\"Мне кажется, в глубине души, я знал об этом.\""

    "Ютаро выдавливал из себя слова."
    $ St("MR",300,0,0,"st曙雄太郎_バイト_通常_hard")
    voice "voice/c61/7300020b01.opus"

    xtl "\"Помнишь, я говорил тебе о том, что у Рюджиро появилась девушка?\""
    voice "voice/c61/7300030b01.opus"

    xtl "\"Оглядываясь назад, это произошло именно тогда, когда Муко начала заглядывать в магазин.\""
    $ St("MR",300,0,0,"st曙雄太郎_バイト_通常_sad")
    voice "voice/c61/7300040b01.opus"

    xtl "\"В последнее время, они проводят много времени вместе.\""
    xy "......"

    "Аой часто заглядывала в Кошачью мяту с другом..."
    $ St("MR",300,0,0,"st曙雄太郎_バイト_通常_think")
    voice "voice/c61/7300050b01.opus"

    xtl "\"А Рюджиро - большой фанат визуальных новелл, игр и прочего, поэтому у них всегда были весьма оживлённые беседы...\""
    xy "......"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    pause (300/1000)
    voice "voice/c61/7300060a01.opus"

    mx "\"Шиничи! Возьми себя в руки!\""
    xy "\"Миюки?!..\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/c61/7300070a01.opus"

    mx "\"Аой соврала тебе и разорвала твои планы на свидание, чтобы встретиться с другим парнем. Но это всё, что мы знаем точно.\""
    stop bgm fadeout (300.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 3000
    with Dissolve((100.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    voice "voice/c61/7300080a01.opus"

    mx "\"У нас нет доказательств того, что она тебе на самом деле изменяет.\""
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Изменяет."

    "У меня всё начало плыть перед глазами."

    "Наверное, слухи оказались правдой."

    "Она обманула меня... предала меня... и теперь встречается с другим парнем..."
    show expression ("cg/ev/"+imagename["evc5241アオイ懇願"]+".jpg") as 絵専 zorder 2000 at truecenter
    show expression ("cg/ev/"+imagename["evc5241アオイ懇願"]+".jpg") as 絵専2 zorder 2000 at center
    with Dissolve((0.0+500.0)/1000)
    hide 絵色黒
    with Dissolve(500.0/1000)
    voice "voice/c61/7300090a02.opus"
    aoi "\"Аой нужно, чтобы ты поверил во всё.\""
    hide 絵専
    hide 絵専2
    with Dissolve(500.0/1000)

    xy "\"Этого... этого не может быть...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c61/7300100a01.opus"

    mx "\"Твои чувства могут подождать, пока ты не узнаешь правду.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c61/7300110a01.opus"
    mx "\"Пошли.\""
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    $ sename = "se人体_足音_歩く複数美雪L"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 4000
    with Dissolve((5000.0+1000.0)/1000)

    "Будучи ослеплённый отчаянием, голос Миюки был единственным путеводным светом, оставшимся в моей тьме."

    "Схватившись за эту слабую надежду, я пошёл вниз по дороге."
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg100100_3_マンション外正面"]+".jpg")
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (500/1000)
    voice "voice/c61/7300120b01.opus"

    xtl "\"Рюджиро не отвечает на звонки, так что это единственное место, которое приходит мне на ум.\""
    voice "voice/c61/7300130b01.opus"

    xtl "\"Он делит здесь квартиру с одним из своих друзей-моделей. Это их «гардероб», или что-то в таком духе...\""
    voice "voice/c61/7300140a01.opus"

    mx "\"Здесь?\""
    voice "voice/c61/7300150b01.opus"

    xtl "\"Да. Судя по всему, его друг на пике популярности.\""
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    pause (500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
