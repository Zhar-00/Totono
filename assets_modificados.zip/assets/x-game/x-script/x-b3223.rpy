label b3223_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a3224.nss"
    return
label b3223:
    hide 絵色黒
    $ renpy.music.play("ttb07",channel = "bgm", if_changed = True)
    $ sename = "se人体_足音_歩く01遅L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040200_3_街川縁"]+".jpg")
    show expression ("cg/ev/l/"+imagename["eva3222アオイおんぶ_l"]+".jpg") as 絵専 zorder 1100:
        pos (-730,-150)
    with Dissolve(0.0/1000)
    voice "voice/b32/2300010a02.opus"
    aoi "\"Этот мир - ВИДЕОИГРА.\""
    voice "voice/b32/2300020a02.opus"
    aoi "\"И Аой может попросить Бога создать патч обновления.\""
    voice "voice/b32/2300030a02.opus"
    aoi "\"Это решит все твои проблемы.\""
    voice "voice/b32/2300040a02.opus"
    aoi "\"Или, по крайней мере... так и должно было быть...\""
    voice "voice/b32/2300050a02.opus"
    aoi "\"Но у моего телефона нет сигнала... он никак не может подключиться.\""
    voice "voice/b32/2300060a02.opus"
    aoi "\"...Прости...\""
    xy "\"Да ладно тебе, не извиняйся.\""
    xy "\"Я что-нибудь придумаю, с или без Бога.\""
    voice "voice/b32/2300070a02.opus"
    aoi "\"Ты не можешь \"что-нибудь придумать\".\""
    voice "voice/b32/2300080a02.opus"
    aoi "\"Ты скоро станешь принцем Миюки.\""
    "Я не мог поверить в то, что только что услышал."
    "Меня можно было описать любым словом, но только не \"принцем\"."
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
