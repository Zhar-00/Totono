label e0116a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    $ roof = False
    return
label e0116a:
    hide 絵色黒
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(0.0/1000)

    xy "\"Ну, разумеется! Ты достаточно хороша.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/e01/16a00010a01.opus"

    mx "\"Ты правда так думаешь?\""

    xy "\"Конечно.\""
    voice "voice/e01/16a00020a01.opus"

    mx "\"...Ладно.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e01/16a00030a01.opus"
    mx "\"Спасибо.\""
    stop bgm fadeout 1
    scene expression "cg/bg/black.jpg" with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),.11)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
