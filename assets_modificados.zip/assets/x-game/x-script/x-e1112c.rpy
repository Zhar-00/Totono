label e1112c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2000.nss"
    return
label e1112c:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/e11/12c00010a01.opus"

    mx "\"Ты правда так сильно хочешь иметь возможность выбора?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/12c00020a01.opus"

    mx "\"Ну, ты не волнуйся.\""
    voice "voice/e11/12c00030a01.opus"

    mx "\"В конце концов ты, похоже, понимаешь меня.\""
    voice "voice/e11/12c00040a01.opus"

    mx "\"Я буду хорошо заботиться о тебе.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/12c00050a01.opus"

    mx "\"...Эй, Шиничи?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/12c00060a01.opus"

    mx "\"Я дам тебе всё, что захочешь. Ладно?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/e11/12c00070a01.opus"
    mx "\"И поэтому...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e11/12c00080a01.opus"

    mx "\"Я приготовила это блюдо со всей своей любовью, так что лучше не оставляй ничего на тарелке.\""

    "Именно поэтому её мисо суп такой вкусный?.. Потому что она приготовила его со своей любовью?.."
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause 1
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
