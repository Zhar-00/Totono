label d6172_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6173.nss"
    return
label d6172:
    hide 絵色黒
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg080100_3_コンビニ外正面"]+".jpg")
    $ St("ML",300,0,0,"st曽根美雪_制服_通常_normal")
    $ St("MR",300,0,0,"st曙雄太郎_バイト_通常_sad")
    with Dissolve(0.0/1000)
    xy "\"Ну да, и?\""
    xy "\"А вдруг Хару-чан - и есть Рюджиро?\""
    $ St("ML",300,0,0,"st曽根美雪_制服_病み_sad")
    voice "voice/d61/7200010a01.opus"
    mx "\"У меня были такие подозрения, когда Хару-чан не пришла помочь мне за кулисами, как мы договаривались.\""
    $ St("ML",300,0,0,"st曽根美雪_制服_通常_normal")
    voice "voice/d61/7200020a01.opus"
    mx "\"И как потом оказалось, Аой и Хару-чан вышли из магазина вместе.\""
    "...Что?"
    "О чём она говорит?"
    "Я не понимаю."
    xy "\"Здесь, должно быть, какая-то ошибка.\""
    $ St("MR",300,0,0,"st曙雄太郎_バイト_通常_hard")
    voice "voice/d61/7200030b01.opus"
    xtl "\"Я работал на кассе, чувак. Я видел их.\""
    voice "voice/d61/7200040b01.opus"
    xtl "\"Они вместе выбежали за дверь.\""
    xy "\"Но Аой у меня дома!\""
    "...Нет, уже не дома."
    "Я пытался дозвониться до неё, но она не ответила."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
