label c5231_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c5241.nss"
    return
label c5231:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    show expression ("cg/bg/"+imagename["bg900100_1_雰囲気空"]+".jpg") as 絵背景 zorder 1010 at truecenter
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    pause (1000/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    hide 絵背景
    with Dissolve(1000.0/1000)
    voice "voice/c52/3100010a01.opus"
    mx "\"Ты подозреваешь Акебоно-куна?\""

    xy "\"Что?\""

    "Это было первое, что Миюки сказала мне после того, как я рассказал ей, что произошло сегодня утром."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/c52/3100020a01.opus"

    mx "\"Ты думаешь, он пытается забрать Аой себе, да?\""

    xy "\"Вряд ли. Он больше заинтересован в те—\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c52/3100030a01.opus"

    mx "\"Я уже отшила его. Причём довольно давно.\""

    "Она права. Какой привлекательной она не была бы, нет никакой гарантии, что он будет гоняться за ней и дальше."

    "Многие люди, скорее всего, попытались бы найти кого-нибудь другого."

    xy "\"Но почему Аой?\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/c52/3100040a01.opus"

    mx "\"Кто знает? У людей свои причины.\""

    xy "\"Но он всё это время помогал мне найти её!\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c52/3100050a01.opus"

    mx "\"Разве не из-за этого ты подозреваешь его?\""

    xy "\"Что?..\""
    show expression Solid("000000") as 絵色黒 zorder 1000
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵色黒上
    with Dissolve((0.0+500.0)/1000)
    with Dissolve(1000.0/1000)
    $ St("C",1740,0,0,"bu曙雄太郎_制服_通常_normal")
    with Dissolve(500.0/1000)

    "Я думал, что это просто доказательство того, что я ему небезразличен..."

    "Неужели Миюки права? Мог ли у него быть скрытый мотив?"

    "Да ладно... Быть того не—"

    xy "\"......Ох.\""
    show expression Solid("000000") as 絵色黒上
    with Dissolve((0.0+300.0)/1000)
    show expression ("cg/bg/"+imagename["bg080100_2_コンビニ外正面"]+".jpg") as 絵演背景 zorder 1010 at truecenter
    hide StC
    hide StMR
    hide StML
    with Dissolve(1000.0/1000)

    "В тот день, когда я вернулся домой в пустой дом, Аой пришла с молоком, которое купила в магазине за углом."

    "Семейный магазин Ютаро."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    hide 絵色黒
    hide 絵色黒上
    hide 絵演背景
    with Dissolve(500.0/1000)
    voice "voice/c52/3100060a01.opus"

    mx "\"Ты выглядишь не очень хорошо.\""

    xy "\"...Нет, я в порядке.\""
    voice "voice/c52/3100070a01.opus"

    mx "\"Правда? Потому что ты выглядишь неважно с моей точки зрения.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c52/3100080a01.opus"

    mx "\"Вот, возьми.\""
    $ sename = "se物体_紙_取り出す"
    play se sedict[sename]

    "Она передала мне билеты на спектакль."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/c52/3100090a01.opus"

    mx "\"Вместо того, чтобы корить этим себя и дальше, ты мог бы что-нибудь с этим сделать. Это всё может оказаться простым недоразумением.\""
    voice "voice/c52/3100100a01.opus"

    mx "\"Ты лучше не парься из-за своих чувств, а пригласи её на свидание.\""
    hide StC with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    with Dissolve(500.0/1000)
    voice "voice/c52/3100110a02.opus"

    aoi "\"Кошачья атака! Мяу!\""
    play voc "c52/3100120b04"
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]
    voice "voice/c52/3100130a02.opus"

    aoi "\"Мяу! Мяу! Мяу!\""

    "Тем временем, Аой практиковала свою «кошачью атаку» с Иру."

    "Между нами сейчас всё было довольно неловко..."

    "Как я вообще смогу пригласить её на свидание?"
    hide StC with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c52/3100140a01.opus"

    mx "\"Может, тебе стоит сохраниться?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/c52/3100150a01.opus"

    mx "\"Если ты вдруг облажаешься, ты сможешь попробовать ещё раз.\""

    "Я знаю, что она просто пошутила, но... это заставило меня задуматься."

    "Если бы только я мог «сохранить свой прогресс» в реальной жизни... Всё было бы намного легче..."

    "Я бы смог просто загрузиться со своего файла и попробовать ещё раз..."

    "А имея такую способность, как эта, мне бы никогда не пришлось колебаться."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/c52/3100160a01.opus"

    mx "\"Ну ладно, мне надо идти.\""

    xy "\"А? Воу, погоди минутку!\""

    "Не успел я и отреагировать, как Миюки уже начала уходить, оставив меня с билетами."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c52/3100170a01.opus"

    mx "\"Не думай дважды. Просто сделай это.\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/c52/3100180a01.opus"

    mx "\"Если ты вдруг облажаешься, у тебя будет ещё один шанс.\""
    hide StC with Dissolve(200.0/1000)
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]

    "После этого она слезла вниз по лестнице."
    voice "voice/c52/3100190a02.opus"

    aoi "\"Миюки, куда это ты?\""
    voice "voice/c52/3100200a01.opus"

    mx "\"Прости... у меня сегодня встреча комитета.\""
    voice "voice/c52/3100210a01.opus"

    mx "\"Увидимся позже.\""
    voice "voice/c52/3100220a02.opus"
    aoi "\"Пока-пока.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
