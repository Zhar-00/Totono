label c6152_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if cat_wave == False:
        $ GameName = "d6153.nss"
    else:
        $ GameName = "c6153.nss"
    return
label c6152:
    hide 絵色黒
    $ sename = "se環境_ガヤ_教室ざわめくL"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010801_2_学校体育館演劇準備"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)

    xy "\"Ей сегодня нездоровится.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/c61/5200010a01.opus"

    mx "\"Она заболела?!\""

    xy "\"Не волнуйся. Ничего страшного не случилось.\""

    "Выражение лица Миюки слегка изменилось, но я отмахнулся от её беспокойства."

    xy "\"Просто небольшая лихорадка. Ну, знаешь, она в последнее время сама не своя.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c61/5200020a01.opus"

    mx "\"Ты должен попробовать позвонить ей.\""

    xy "\"Но её телефон вообще не ловит сигнал.\""
    voice "voice/c61/5200030a01.opus"

    mx "\"Позвони тогда на свой домашний.\""

    xy "\"Серьёзно, тебе незачем волнова—\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c61/5200040a01.opus"
    mx "\"Пожалуйста.\""

    "Взгляд в её глазах был предельно серьёзным."

    "Странно... Почему она так настаивает на этом?"

    "Ну ладно. Это всего лишь один ничтожный звонок, наверное."
    $ sename = "se物体_携帯_開く"
    play se sedict[sename]

    "По её просьбе, я достал свой телефон."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
