label e1155i_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ persistent.miyuki_decision = true;
    return
label e1155i:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))

    "Стоп, что?"

    "Что я только что делал?.."
    "......"

    "А, точно!"

    "Я собирался пойти наружу, чтобы—"
    menu:
        "Пойти искать Миюки":
            $ SetChoiceSelect = 0
        "Пойти искать Аой":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e1156a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e1156b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
