label b5162_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5163.nss"
    return
label b5162:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    with Dissolve(0.0/1000)

    "Как бы мы не старались искать..."

    "...телефон Аой нигде не было видно."
    xy "\"Я уже начинаю думать, что ты его могла где-нибудь обронить.\""
    play voc "b51/6200010b04"
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_sad")
    with Dissolve(200.0/1000)
    voice "voice/b51/6200020a02.opus"
    aoi "\"Но Аой... уже искала везде...\""
    play voc "b51/6200030b04"
    xy "\"Иру, притаись на секунду!\""
    play voc "b51/6200040b04"
    xy "\"Ты только что поужинала, верно?\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/b51/6200050a02.opus"
    aoi "\"Нет... дело не в этом.\""
    play voc "b51/6200060b04"

    "Внезапно Иру прибежал из гостиной."
    hide StC
    hide StMR
    hide StML
    show expression ("cg/bg/"+imagename["bg030201_3_自宅玄関消灯"]+".jpg") as 絵背景追加１ zorder 100 at truecenter
    with Dissolve(500.0/1000)
    pause (200/1000)
    $ sename = "se動物_ネコ_ひっかく01"
    play se sedict[sename]
    pause (1000/1000)
    "Встревоженный, я пошёл за котёнком к входной двери, и он начал царапать её когтями, как сумасшедший, чтобы выбраться наружу."

    aoi "\"Он... там?\""
    stop se fadeout (500.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    $ sename = "se物体_ドア自宅_鍵開ける02"
    play se sedict[sename]
    with Dissolve((500.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]
    pause (1200/1000)

    "Я осторожно открыл дверь."
    pause (500/1000)
    show expression ("cg/bg/l/"+imagename["bg020100_3_自宅外正面_l"]+".jpg") as 絵背景追加２ zorder 100 at truecenter
    with Dissolve((500.0+0.0)/1000)
    $ sename = "se人体_動作_衣擦れ04"
    play se sedict[sename]
    $ sename = "se人体_動作_衣擦れ02"
    play se sedict[sename]
    pause (500/1000)

    "Далее Иру нырнул прямо в кусты."

    "Я тут же пошёл за ним."
    xy "\"А! Вот он где!\""

    "Телефон Аой оказался прямо под кустарником."

    "Если подумать..."

    "Мне кажется, именно там Аой чуть было не уснула вчера ночью..."
    $ sename = "se物体_ドア自宅_閉まる"
    play se sedict[sename]
    with Dissolve((500.0+1000.0)/1000)
    hide 絵背景追加１
    hide 絵背景追加２
    pause (300/1000)
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    pause (1200/1000)
    hide 絵色黒
    with Dissolve(500.0/1000)
    pause (300/1000)
    xy "\"Эй, Аой! Это ведь твой телефон?\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/b51/6200080a02.opus"

    aoi "\"Да! В этом нет никаких сомнений, он точно мой...\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/b51/6200090a02.opus"
    aoi "\"Ты молодец, Иру.\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_sad")
    with Dissolve(200.0/1000)
    voice "voice/b51/6200100a02.opus"
    aoi "\"Спасибо... тебе...\""
    hide StC with Dissolve(200.0/1000)
    xy "\"В-воу... Аой?\""

    xy "\"Аой, ты в порядке? Ты бледная, как лист бумаги!\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_sad")
    with Dissolve(200.0/1000)
    voice "voice/b51/6200110a02.opus"
    aoi "\"Аой в порядке...\""
    voice "voice/b51/6200120a02.opus"
    aoi "\"Пока... у Аой есть этот телефон...\""
    voice "voice/b51/6200130a02.opus"
    aoi "\"Аой может... получать данные... от Бога.\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_normal")
    with Dissolve(200.0/1000)
    voice "voice/b51/6200140a02.opus"
    aoi "\"Аой не... забудет.\""
    voice "voice/b51/6200150a02.opus"
    aoi "\"И теперь Бог... сможет дозвониться...\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Она начала звонить."
    voice "voice/b51/6200160a02.opus"
    aoi "\"Буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп...\""
    voice "voice/b51/6200170a02.opus"
    aoi "\"Буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп...\""
    $ sename = "se物体_携帯_圏外"
    play se sedict[sename]

    "Но, похоже, \"Бог\" даже не собирался брать трубку."

    "Её телефон всё так же был вне зоны доступа."

    "Её сигнал попросту не проходил."
    $ St("C",300,0,0,"st向日アオイ電波_制服_見上げ_normal")
    with Dissolve(200.0/1000)
    voice "voice/b51/6200180a02.opus"
    aoi "\"Возьми...\""
    $ St("C",300,0,0,"st向日アオイ電波_制服_見上げ_think")
    with Dissolve(200.0/1000)
    voice "voice/b51/6200190a02.opus"
    aoi "\"Возьми трубку, Бог!..\""

    "Я рад, что мы нашли её телефон."

    "Но, как мы и обсуждали вчера по дороге домой, ей это не принесёт никакой просьбы, пока Бог не начнёт отвечать на её звонки."

    "По крайней мере, именно в это она и верила."
    stop se fadeout (1000.0/1000)
    hide StC with Dissolve(200.0/1000)

    "Что я могу сделать, чтобы помочь ей?"

    "Как я могу помочь ей жить долго и счастлив"

    "...Стоп... долго и счастливо?.."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
