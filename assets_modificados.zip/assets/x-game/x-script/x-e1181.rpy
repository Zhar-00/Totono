label e1181_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2000.nss"
    return
label e1181:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg") behind 絵色黒
    hide 絵色黒
    with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/8100010a01.opus"

    mx "\"Нам нечего бояться...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/8100020a01.opus"

    mx "\"Мы с тобой проведём здесь вечность вместе...\""
    voice "voice/e11/8100030a01.opus"

    mx "\"На веки вечные...\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
