label e2162c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2162b.nss"
    return
label e2162c:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg070100_2_雑貨店店内"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(0.0/1000)

    "Думаю, я подарю ей фоторамку..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
