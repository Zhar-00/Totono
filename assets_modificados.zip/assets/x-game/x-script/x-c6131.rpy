label c6131_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6141.nss"
    return
label c6131:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg080100_2_コンビニ外正面"]+".jpg")
    with Dissolve(500.0/1000)
    $ sename = "se物体_チャイム_入店"
    play se sedict[sename]
    pause (1000/1000)
    "...направилась в магазин за углом."
    xy "\"...Она просто пошла за покупками... верно?\""
    "У неё, должно быть, закончилось лекарство от простуды."
    "Или, наверное, Иру нужно больше молока."
    "Или... точно! Возможно, ей невзначай понадобилось воспользоваться туалетом!"
    "Или, наверное, она просто тоскует по Ябалею!"
    "Или... или..."
    $ st_timezone = "昼"
    $ St("C",2010,0,0,"bu曙雄太郎_制服_通常_think")
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵覆
    with Dissolve(500.0/1000)
    voice "voice/c61/3100010b01.opus"
    xtl "\"Думаешь, она тебе изменяет?\""
    pause (200/1000)
    hide StC
    hide 絵演背景
    hide 絵覆
    with Dissolve(500.0/1000)
    pause (1500/1000)
    show expression ("cg/bg/"+imagename["bg900100_1_雰囲気空"]+".jpg") as 絵演背景 zorder 7010 at truecenter
    show expression Solid("000000") as 絵色回想黒 zorder 3900
    with Dissolve((0.0+300.0)/1000)
    with Dissolve(500.0/1000)
    voice "voice/c61/3100020a01.opus"
    mx "\"Ты подозреваешь Акебоно-куна?\""
    hide 絵演背景
    hide 絵色回想黒
    with Dissolve(500.0/1000)
    xy "\"Он мой друг...\""
    "Слова звучали до боли фальшиво, даже для меня."
    "Моя грудь наполнилась подавленным гневом и невыносимой виной."
    show expression ("cg/ev/"+imagename["evc5241アオイ懇願"]+".jpg") as 絵専 zorder 2000 at truecenter
    show expression ("cg/ev/"+imagename["evc5241アオイ懇願"]+".jpg") as 絵専2 zorder 2000 at center
    with Dissolve((0.0+500.0)/1000)
    with Dissolve(500.0/1000)
    voice "voice/c61/3100030a02.opus"
    aoi "\"Аой нужно, чтобы ты поверил во всё.\""
    hide 絵専
    hide 絵専2
    with Dissolve(500.0/1000)
    "Я помню, как она умоляла меня."
    "Но что она имела в виду под этим?"
    "Неужели она зашла так далеко, чтобы обмануть меня?"
    $ sename = "se物体_チャイム_入店"
    play se sedict[sename]
    "Автоматические двери распахнулись со знакомым звоном магазина за углом."
    hide 絵背景
    with Dissolve(300.0/1000)
    xy "\"...Ох...\""
    voice "voice/c61/3100040a02.opus"
    aoi "\"Буп-буп...\""
    stop bgm fadeout (1000.0/1000)
    pause (500/1000)
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_normal")
    with Dissolve(300.0/1000)
    pause (1000/1000)
    voice "voice/c61/3100050b03.opus"
    c "\"Аой-семпай... Ты в порядке?\""
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    "Это же... Хару-чан..."
    "Я даже забыл о том, что она работает здесь..."
    "Мои опасения тут же исчезли."
    "Аой просто пришла проведать её."
    "Она пришла сюда вовсе не из-за Ютаро."
    "Она не изменяет мне!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ St("ML",300,0,0,"st曙龍二郎_制服_通常_surprise")
    $ St("MR",300,0,0,"st向日アオイ_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c61/3100060a02.opus"
    aoi "\"Хару-чан, нам надо поторопиться.\""
    $ St("ML",300,0,0,"st曙龍二郎_制服_通常_sad")
    voice "voice/c61/3100070b03.opus"
    c "\"Х-хорошо!..\""
    $ sename = "se人体_足音_歩く複数アオイL"
    play se sedict[sename]
    stop se fadeout (5000.0/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(400.0/1000)
    pause (2000/1000)
    xy "\"Ха-ха... ха-ха-ха-ха...\""
    "Я посмеялся про себя и смотрел им вслед."
    $ EyeCatchIn(2000.0)
    show expression Solid("FFFFFF") as 絵色白 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
