label e1154c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1154d.nss"
    return
label e1154c:
    hide 絵色黒
    $ renpy.music.play("ttb22",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110500_1_マンショントイレ"]+".jpg")
    with Dissolve(0.0/1000)
    xy "......"

    "Мои пальцы остановились на экране телефона."

    "В её списке контактов была только одна запись."

    "Кем бы он ни был, он был записан как «Бог»."

    xy "\"Кто, чёрт побери, является этим «Богом»?..\""

    "Я коснулся этой записи, чтобы просмотреть её."

    "В качестве его номера телефона было указано следующее: 999[persistent.god_number]"

    "На мой взгляд, это был совершенно обычный номер телефона..."

    "Запаниковав, я случайно нажал не на ту кнопку."

    "Телефон начал звонить «Богу»."

    "Но он не ловил сигнал, так что звонок вряд ли дойдёт..."

    "По крайней мере... не должен был..."

    xy "\"...Что за?\""
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]

    xy "\"Он правда подключается?\""
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    pause (100/1000)
    voice "voice/e11/54c00010b02.opus"
    kmsm "\"ОТВЕТ ПОЛОЖИТЕЛЬНЫЙ.\""

    "Я услышал голос на другом конце линии."
    voice "voice/e11/54c00020b02.opus"

    kmsm "\"СОЕДИНЕНИЕ УСТАНОВЛЕНО.\""

    xy "\"Э-э-э-эм...\""

    xy "\"Это... Бог?..\""
    voice "voice/e11/54c00030b02.opus"

    kmsm "\"В ЗАВИСИМОСТИ ОТ ИНТЕРПРЕТАЦИИ.\""
    voice "voice/e11/54c00040b02.opus"

    kmsm "\"Я ЕСТЬ СЛИЯНИЕ ВСЕХ ГЕРОИНЬ ВИЗУАЛЬНЫХ НОВЕЛЛ.\""
    voice "voice/e11/54c00050b02.opus"

    kmsm "\"ИНАЧЕ ГОВОРЯ, АБСТРАКЦИЯ.\""

    "«Слияние»?"

    "«Абстракция»?"
    $ sename = "se物体_ドアトイレ_叩く01"
    play se sedict[sename]
    voice "voice/e11/54c00060a01.opus"

    mx "\"Бог? Только не говори мне...\""
    voice "voice/e11/54c00070a01.opus"

    mx "\"Ты позвонил Богу, да?!\""
    voice "voice/e11/54c00080a01.opus"

    mx "\"Сейчас же заверши вызов!\""

    "Судя по всему, Миюки узнала о том, что мой звонок дошёл."

    "Мне надо позвать на помощь, и побыстрее—!"

    xy "\"Ладно... мне всё равно, кто ты! Пожалуйста, ты должен позвать на помощь!\""

    xy "\"Ты знаешь Миюки, верно? Она пытается напасть на меня—\""
    voice "voice/e11/54c00090b02.opus"

    kmsm "\"[[ТЫ] НАХОДИШЬСЯ В ЗАКЛЮЧЕНИИ.\""

    xy "\"В заключении?\""
    voice "voice/e11/54c00100b02.opus"

    kmsm "\"ИСТОРИЯ ПРОАНАЛИЗИРОВАНА. ВСЕЛЕННАЯ БЫЛА ЧАСТИЧНО МОДИФИЦИРОВАНА.\""
    voice "voice/e11/54c00110b02.opus"

    kmsm "\"МИЮКИ РАЗРАБОТАЛА НАРКОТИК, КОТОРЫЙ МОЖЕТ ПОДАВЛЯТЬ ВОСПРИЯТИЕ РЕАЛЬНОСТИ.\""
    voice "voice/e11/54c00120b02.opus"

    kmsm "\"ОН ЛЕЖИТ В МАЛЕНЬКОМ БУМАЖНОМ ПАКЕТЕ И БЫЛ ДОБАВЛЕН В ЕДУ.\""
    voice "voice/e11/54c00130b02.opus"

    kmsm "\"И БУДУЧИ В СОСТОЯНИИ ОПЬЯНЕНИЯ СНОМ, ТЫ БЫЛ ВЫНУЖДЕН ИНТЕРПРЕТИРОВАТЬ СЦЕНЫ ИЗ ВИДЕОИГРЫ КАК СОБЫТИЯ РЕАЛЬНОСТИ.\""

    "Мне хотелось посмеяться над всем этим... но я не мог."

    "Она повесила замок на дверь... и ударила меня своей битой..."

    "Я уже не знаю, чему верить..."
    voice "voice/e11/54c00140b02.opus"

    kmsm "\"ВПОЛНЕ ВЕРОЯТНО, ТЫ ПОТЕРЯЛ СОЗНАНИЕ СРАЗУ ЖЕ ПОСЛЕ ПРИЁМА ПИЩИ.\""

    "......Минуточку."

    "Если подумать... Всякий раз, когда я хлебал мисо суп сегодня утром..."
    $ renpy.vibrate(.3)
    $ sename = "se人体_衝撃_叩く机02"
    play se sedict[sename]

    xy "\"Воу!!!\""

    "Ч-что, чёрт побери, это сейчас было?!"

    "Дверь в уборную только что—!"
    $ sename = "se物体_ドアトイレ_壊れる01"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    pause (100/1000)
    $ sename = "se物体_ドアトイレ_壊れる01"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    pause (1000/1000)
    $ sename = "se物体_ドアトイレ_壊れる01"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_壊れる03"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    show expression ("cg/ef/"+imagename["efbgマンショントイレ破壊a"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵板写
    voice "voice/e11/54c00150a01.opus"

    mx "\"Ты, наверное, издеваешься...\""

    xy "\"Я не позволю тебе!!!..\""
    $ sename = "se物体_ドアトイレ_軋む03"
    play se sedict[sename]
    $ renpy.vibrate(.3)

    "Дверь в уборную громко заскрипела."

    "Миюки засунула монтировку внутрь!"
    show expression ("cg/ef/"+imagename["efbgマンショントイレ破壊b"]+".jpg") as 絵背景 zorder 100 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/e11/54c00160b02.opus"

    kmsm "\"ВРЕМЯ НА ИСХОДЕ. ПЕРЕДАЮ ТОЛЬКО НЕОБХОДИМУЮ ИНФОРМАЦИЮ.\""
    voice "voice/e11/54c00170b02.opus"

    kmsm "\"ДЛЯ ЭТОЙ ВСЕЛЕННОЙ НУЖЕН ОТКАТ. ТОЛЬКО У МИЮКИ И АОЙ ЕСТЬ РАЗРЕШЕНИЕ НА ЕГО ИНИЦИИРОВАНИЕ.\""
    voice "voice/e11/54c00180b02.opus"

    kmsm "\"МОБИЛЬНАЯ ИГРА ЯВЛЯЕТСЯ ОТРАЖЕНИЕМ ТВОЕЙ РЕАЛЬНОСТИ. ОБРАТНОЕ ТОЖЕ ВЕРНО.\""
    voice "voice/e11/54c00190a01.opus"

    mx "\"Стой! Не слушай всё то, что она говорит!\""
    $ sename = "se物体_ドアトイレ_壊れる03"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    voice "voice/e11/54c00200b02.opus"

    kmsm "\"МИЮКИ ВМЕШАЛАСЬ В КОД ПРОГРАММЫ. ОНА ПЕРЕПИСАЛА КОД ИГРЫ ТАК, ЧТОБЫ ОБОЗНАЧИТЬ АОЙ КАК ВЫМЫШЛЕННОГО ПЕРСОНАЖА.\""
    voice "voice/e11/54c00210b02.opus"

    kmsm "\"НА ДАННЫЙ МОМЕНТ ВРЕМЕНИ, АОЙ ЯВЛЯЕТСЯ ВЫМЫСЛОМ В ИГРЕ. НО АОЙ СУЩЕСТВУЕТ В РЕАЛЬНОСТИ, ХОТЬ ТЫ И ВЕРИШЬ В ОБРАТНОЕ.\""
    voice "voice/e11/54c00220b02.opus"

    kmsm "\"ОДНАКО, СТОИТ ТОЛЬКО МИЮКИ ЗАКОНЧИТЬ ПЕРЕПИСЫВАНИЕ КОДА ИГРЫ, РЕАЛЬНЫЙ МИР ТОЖЕ ПРИМЕТ ЕЁ ПРАВКИ.\""
    voice "voice/e11/54c00230b02.opus"

    kmsm "\"И В ЭТОТ МОМЕНТ, СУЩЕСТВОВАНИЕ АОЙ БУДЕТ ОБОЗНАЧЕНО КАК ВЫМЫШЛЕННОЕ, И ОНА ИСЧЕЗНЕТ ИЗ РЕАЛЬНОСТИ.\""
    stop se fadeout (150.0/1000)
    $ sename = "se物体_ドアトイレ_壊れる02"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_軋む03"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    pause (16/1000)
    show expression ("cg/ef/"+imagename["efbgマンショントイレ破壊c"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵板写

    xy "\"Кому есть дело до этой Аой?! Просто поторопись и позвони копам!\""
    $ sename = "se物体_ドアトイレ_壊れる01"
    play se sedict[sename]
    voice "voice/e11/54c00240b02.opus"

    kmsm "\"ТЫ ДОЛЖЕН ВЫРВАТЬСЯ ИЗ ЗАТОЧЕНИЯ И ПЕРЕДАТЬ СМАРТФОН С УСТАНОВЛЕННОЙ СИМ-КАРТОЙ АОЙ.\""
    voice "voice/e11/54c00250b02.opus"

    kmsm "\"С ЕЁ ПОМОЩЬЮ, ВСЕЛЕННАЯ СМОЖЕТ ОТКАТИТЬСЯ К ТОЧКЕ ВОССТАНОВЛЕНИЯ, ПРЕДШЕСТВУЮЩЕЙ ИЗМЕНЕНИЯМ МИЮКИ.\""
    $ sename = "se物体_ドアトイレ_軋む03"
    play se sedict[sename]
    $ renpy.vibrate(.3)

    xy "\"Хватит! Пожалуйста, просто помоги мне!\""
    $ sename = "se物体_ドアトイレ_壊れる03"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    voice "voice/e11/54c00260b02.opus"

    kmsm "\"АОЙ - ЭТО СУЩЕСТВОВАНИЕ, НЕ ПОХОЖЕЕ НИ НА ЧТО ДРУГОЕ.\""
    voice "voice/e11/54c00270b02.opus"

    kmsm "\"ОНА ИСПЫТЫВАЛА ЛЮБОВЬ БЕСЧИСЛЕННОЕ МНОЖЕСТВО РАЗ.\""
    voice "voice/e11/54c00280b02.opus"

    kmsm "\"СОВОКУПЛЯЛАСЬ С БЕСЧИСЛЕННЫМ МНОЖЕСТВОМ ПРОТАГОНИСТОВ.\""
    voice "voice/e11/54c00290b02.opus"

    kmsm "\"ОНА БЫЛА ПРОСТО ПУСТЫМ СОСУДОМ.\""
    $ sename = "se物体_ドアトイレ_壊れる01"
    play se sedict[sename]
    voice "voice/e11/54c00300b02.opus"

    kmsm "\"НО НА ЭТОТ РАЗ, ОНА НАУЧИЛАСЬ ВОСПРИНИМАТЬ УНИКАЛЬНЫЕ ЭМОЦИИ.\""
    voice "voice/e11/54c00310b02.opus"

    kmsm "\"ОНА ХРАНИТ К ТЕБЕ РОМАНТИЧЕСКУЮ ПРИВЯЗАННОСТЬ.\""

    xy "\"Это правда?..\""
    voice "voice/e11/54c00320b02.opus"

    kmsm "\"ИСТОЧНИК НЕИЗВЕСТЕН. ОБРАБОТКА НЕВОЗМОЖНА. ПОДТВЕРЖДЁННЫЙ БАГ.\""
    voice "voice/e11/54c00330b02.opus"

    kmsm "\"ДЛЯ ИССЛЕДОВАНИЯ НЕОБХОДИМЫ СВЯЗЬ И СИНХРОНИЗАЦИЯ ПАМЯТИ.\""
    voice "voice/e11/54c00340b02.opus"

    kmsm "\"ПОЭТОМУ МЫ ПРОСИМ ТЕБЯ.\""
    stop se fadeout (150.0/1000)
    hide プロセス
    $ sename = "se物体_ドアトイレ_壊れる02"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_軋む03"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    pause (16/1000)
    show expression ("cg/ef/"+imagename["efbgマンショントイレ破壊d"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵板写

    kmsm "\"ДОСТАВЬ СИМ-КАРТУ АОЙ И СОВЕРШИ СИНХРОНИЗАЦИЮ ПАМЯТИ. ОТКАТИ ВСЕЛЕННУЮ К ЕГО ПЕРВОНАЧАЛЬНОМУ СОСТОЯНИЮ.\""
    $ sename = "se物体_ドアトイレ_壊れる02"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_軋む02"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    pause (16/1000)
    show expression ("cg/ef/"+imagename["efbgマンショントイレ破壊e"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide 絵板写

    xy "\"Слушай, я не могу помочь тебе, ладно?!\""
    stop se fadeout (150.0/1000)
    $ sename = "se物体_ドアトイレ_壊れる02"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    $ sename = "se物体_ドアトイレ_軋む03"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    show expression Solid("FFFFFF") as 絵色白
    show expression ("cg/ev/"+imagename["eve1154b美雪血涙"]+".jpg") as 絵専 zorder 1100 at truecenter
    hide 絵背景
    pause (30/1000)
    hide 絵板写
    hide 絵色白
    with Dissolve(2000.0/1000)
    stop se fadeout (1000.0/1000)
    pause (800/1000)
    voice "voice/e11/54c00360a01.opus"
    mx "\"Шиничи...\""
    $ sename = "se物体_バール_転がる"
    play se sedict[sename]

    "Миюки сорвала дверь с её же петель, поменяла монтировку на свою биту, а потом встала в дверном проёме."

    "Я в ловушке..."

    xy "\"П-пожалуйста... просто остановись!\""

    xy "\"Зачем ты делаешь это?..\""
    voice "voice/e11/54c00380a01.opus"

    mx "\"Ха-ха... ха-ха... ха-ха-ха-ха-ха-ха-ха-ха-ха-ха!!!..\""

    "Миюки маниакально посмеялась."
    voice "voice/e11/54c00390a01.opus"

    mx "\"Зачем? Зачем, спрашиваешь?\""
    voice "voice/e11/54c00400a01.opus"

    mx "\"Разве это не очевидно?\""
    voice "voice/e11/54c00410a01.opus"

    mx "\"Потому что ТЫ не любишь меня.\""
    $ persistent.call_known = True;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
