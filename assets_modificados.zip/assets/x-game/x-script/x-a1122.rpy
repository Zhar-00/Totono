label a1122_MAIN:
    call expression GameName
    $ persistent.imagelog["eva3151アオイ猫箱"]=True
    $ persistent.imagelog["bg040200_3_街川縁"]=True
    $ persistent.imagelog["ef雄太郎スマフォプレイ中エンディング"]=True
    $ persistent.imagelog["ef雄太郎スマフォプレイ中エンディングb"]=True
    $ PreGameName = GameName
    $ GameName = "a1131.nss"
    return
label a1122:
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    show expression ("cg/ef/"+imagename["efbg雄太郎のスマフォ"]+".jpg") as 絵演効果 zorder 100 at center
    scene expression ("cg/ef/"+imagename["efgaゲーム画面ロード"]+".jpg") as 絵場面推移 at center
    with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1.5)
    pause 1
    image 絵効果 = im.MatrixColor(("cg/ef/"+imagename["effiテレビ画面用効果フィルター"]+".jpg"),im.matrix.invert())
    show 絵効果 behind 絵場面推移 zorder 2000:
        alpha 0.2
    show expression ("cg/ev/"+imagename["eva0113アオイ屋上覆い被さりa"]+".jpg") as 絵専 behind 絵場面推移, 絵効果 at center
    hide 絵場面推移 with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1)
    show expression ("cg/ev/"+imagename["eva0113アオイ屋上覆い被さりa"]+".jpg") as 絵専 zorder 1100 at center

    stop se
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    voice "voice/a11/2200010a02.opus"
    aoi "Буп-буп?.."
    xy "......"
    show expression ("cg/ev/l/"+imagename["eva0113アオイ屋上覆い被さりa_l"]+".jpg") as 絵専上:
        pos (-285,-120)
    with Dissolve((800.0+1000.0)/1000)
    "Её взгляд был прикован ко мне."
    voice "voice/a11/2200020a02.opus"
    aoi "У меня батарейка села."
    xy "Какая ещё батарейка?.."
    voice "voice/a11/2200030a02.opus"
    aoi "Мне нужна перезарядка."
    show expression ("cg/ev/l/"+imagename["eva0113アオイ屋上覆い被さりa_l"]+".jpg") as 絵専上二:
        pos (-181,-54)
    with Dissolve((800.0+1000.0)/1000)
    voice "voice/a11/2200040a02.opus"
    aoi "Не хочешь... подзарядиться?"
    hide 絵専
    hide 絵効果
    hide 絵専上
    scene expression ("cg/ef/"+imagename["efgaゲーム画面ロード"]+".jpg") as 絵場面推移 at center
    with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1.5)
    pause 1
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg") behind 絵場面推移 with None
    hide 絵専上二 with None
    hide 絵場面推移 with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1)
    "Да, это определённо та самая игра, которую я видел вчера."
    "Сам разговор в игре проходил немного иначе, но по большей части он повторял точь-в-точь всё то, что происходило на крыше."
    "Такой уровень ювелирной точности не может быть совпадением."
    "Она, скорее всего, намеренно пыталась дословно воссоздать сцену."
    "Я правда... так сильно заинтересовал её?.."
    xy "Воу-воу, приятель."
    "Пробормотал я себе под нос."
    "Слишком рано делать какие-либо выводы."
    "До вчерашнего дня, мы с Муко никогда не общались."
    "Желая сохранить свой рассудок, я возобновил игру."
    scene expression ("cg/ef/"+imagename["efgaゲーム画面ロード"]+".jpg") as 絵場面推移 at center
    with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1.5)
    pause 1
    image 絵効果 = im.MatrixColor(("cg/ef/"+imagename["effiテレビ画面用効果フィルター"]+".jpg"),im.matrix.invert())
    show 絵効果 behind 絵場面推移 zorder 2000:
        alpha 0.2
    show expression ("cg/bg/"+imagename["bg040200_3_街川縁"]+".jpg") as 絵専 behind 絵場面推移, 絵効果 at center
    hide 絵場面推移 with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1)
    show expression ("cg/bg/"+imagename["bg040200_3_街川縁"]+".jpg") as 絵専 zorder 1100 at center
    voice "voice/a11/2200050a02.opus"
    aoi "Стой!"
    xy "Ты что делаешь, чёрт побери?"
    show expression ("cg/ev/"+imagename["eva3151アオイ猫箱"]+".jpg") as 絵専 zorder 1100 at center
    with Dissolve((500.0+1000.0)/1000)
    voice "voice/a11/2200060a02.opus"
    aoi "Я мамочка-кошка."
    xy "Хорошая попытка. Кошки не разговаривают. Они мяукают."
    voice "voice/a11/2200070a02.opus"
    aoi "Буп-буп..."
    "Аой нахмурилась на какое-то время."
    voice "voice/a11/2200080a02.opus"
    aoi "Мяу! Я мамочка-кошка."
    hide 絵専
    hide 絵効果
    hide 絵専上
    scene expression ("cg/ef/"+imagename["efgaゲーム画面ロード"]+".jpg") as 絵場面推移 at center
    with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1.5)
    pause 1
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg") as bg behind 絵場面推移 zorder 1000 with None
    hide 絵専上二 with None
    hide 絵場面推移 with ImageDissolve("cg/data/zzex_mosaic_01_00_0.png",1)
    $ sename = "se環境_ガヤ_教室授業中L"
    play se sedict[sename]
    xy "Здесь концовка поменялась, что ли?"
    "Эта сцена показалась мне до боли знакомой."
    "По крайней мере, она определённо отражает то, что может сказать настоящая Муко."
    "И зная её склонность к странным выходкам, я не могу быть уверен в том, что она бы не стала делать что-то подобное в реальности."

    "......"
    "Я посмотрел вдаль на «реальную» Муко."
    hide bg
    show expression ("cg/ev/l/"+imagename["eva1111アオイ受信中b_l"]+".jpg") as 絵専 zorder 1001:
        pos (-1500,-800)
        zoom 2
        linear 8 xpos -1250
    with ImageDissolve("cg/data/slide_01_00_1.png",2)
    voice "voice/a11/2200090a02.opus"
    aoi "...Буп-буп..."
    "Она опять приняла свою фирменную позу."
    "Она не делала никаких заметок. По сути дела, её, похоже, сам урок и вовсе не интересовал. Вместо этого она просто сидела с поднятой рукой и смотрела в никуда."
    stop bgm fadeout (3000/1000)
    stop se fadeout (3000/1000)
    scene expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
