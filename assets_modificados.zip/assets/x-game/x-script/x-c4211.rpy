label c4211_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010100_3_学校階段"]=True
    $ persistent.imagelog["bg040100_3_街通学路"]=True
    $ PreGameName = GameName
    $ GameName = "c4221.nss"
    return
label c4211:
    hide 絵色黒
    $ renpy.music.play("ttb14",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg050100_3_バッティングセンター外正面"]+".jpg")
    with Dissolve(800.0/1000)
    play voc "c42/1100010b04"
    "Я заметил, как Иру сидел у входа в здание."
    "Я был искренне поражён тем, что маленький комок шерсти смог проделать весь путь досюда на своих маленьких лапках."
    "Как только я взял котёнка на руки, его вибриссы поднялись вверх."
    xy "\"Аой звонит сейчас, да?\""
    play voc "c42/1100020b04"
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040200_3_街川縁"]+".jpg")
    with Dissolve(300.0/1000)
    xy "\"Дай угадаю... нам сюда?\""
    play voc "c42/1100030b04"
    "Иру мяукнул мне в ответ так, будто он понял мой вопрос."
    "Мои ноги непоколебимо понесли меня вперёд."
    show expression ("cg/bg/"+imagename["bg040400_3_街交差点"]+".jpg")
    with Dissolve(300.0/1000)
    "Я уже несколько дней не видел Аой."
    "По какой-то причине мои данные не доходили до неё."
    show expression ("cg/bg/"+imagename["bg040100_3_街通学路"]+".jpg")
    with Dissolve(300.0/1000)
    "Наша связь была, в лучшем случае, слабой... но она, по крайней мере, была здесь."
    "Это судьба? Или..."
    show expression ("cg/bg/"+imagename["bg010401_3_学校校門閉通用口開"]+".jpg")
    with Dissolve(300.0/1000)
    xy "\"Она здесь?\""
    "Ответ был очевиден."
    show expression ("cg/bg/m/"+imagename["bg010401_3_学校校門閉通用口開_m"]+".jpg") as 絵背景:
        pos (0,-210)
    with Dissolve((800.0+1000.0)/1000)
    "Всё-таки пешеходные ворота были открыты."
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg010500_3_学校昇降口"]+".jpg")
    hide 絵背景
    with Dissolve(800.0/1000)
    pause (500/1000)
    hide 絵色黒
    with Dissolve(800.0/1000)
    "И только она знала, как взломать замок."
    show expression ("cg/bg/"+imagename["bg010700_3_学校廊下"]+".jpg")
    with Dissolve(800.0/1000)
    "И, собственно, прямо как и в тот роковой день..."
    show expression ("cg/bg/"+imagename["bg010100_3_学校階段"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010100_3_学校階段_l"]+".jpg") as 絵背景 zorder 1010:
        pos (-515,-190)
    with Dissolve(800.0/1000)
    "...проход на крышу также был открыт."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
