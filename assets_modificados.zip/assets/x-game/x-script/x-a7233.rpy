label a7233_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010400_3_学校校門"]=True
    $ persistent.imagelog["bg010402_3_学校校門閉雨"]=True
    $ persistent.imagelog["bg010610_2_学校教室扉前"]=True
    $ persistent.imagelog["bg010802_2_学校体育館演劇中椅子無し"]=True
    $ persistent.imagelog["bg030311_3_自宅リビングカーテン開消灯"]=True
    $ persistent.imagelog["bg030500_1_自宅廊下２階"]=True
    $ persistent.imagelog["bg040400_3_街交差点雨"]=True
    $ persistent.imagelog["bg040400_9_街交差点"]=True
    $ persistent.imagelog["bg050100_1_バッティングセンター外正面"]=True
    queue bgm "tts_op"
    $ PreGameName = GameName
    show expression Solid("FFFFFF") as 絵演色黒 with dissolve
    if persistent.a_route == False:
        $ persistent.a_route = True
        python:
            if persistent.passed_a_route_month == None or persistent.passed_a_route_day == None:
                from time import strftime, localtime
                persistent.passed_a_route_month = int(strftime("%m",localtime()))
                persistent.passed_a_route_day = int(strftime("%d",localtime()))
                persistent.DIARY_COUNT += 1
        $ GameCircle = False
        $ renpy.full_restart()
    elif no_call == True:
        python:
            if persistent.passed_a_route_month == None or persistent.passed_a_route_day == None:
                from time import strftime, localtime
                persistent.passed_a_route_month = int(strftime("%m",localtime()))
                persistent.passed_a_route_day = int(strftime("%d",localtime()))
                persistent.DIARY_COUNT += 1
        $ GameCircle = False
    else:
        $ GameName = "b1121.nss"
    return
label a7233:
    hide 絵色黒
    $ st_timezone = "昼"
    stop bgm fadeout (3000.0/1000)
    show expression ("cg/bg/"+imagename["bg060100_3_バッティングセンター店内"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_hard")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a72/3300010a01.opus"

    mx "\"Боюсь, извинения тебе не помогут.\""

    xy "\"В каком смысле не помогут? И чего тогда ты от меня хочешь?\""
    voice "voice/a72/3300020a01.opus"

    mx "\"В качестве твоего наказания... я хочу, чтобы ты забил хоум-ран, стоя на моём месте.\""

    xy "\"А?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a72/3300030a01.opus"

    mx "\"Тебе лучше сделать замах этой битой, пока сам не получил ею.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/a72/3300040a01.opus"

    mx "\"Или ты слишком напуган, чтобы сделать удар?\""
    xy "\"Ладно, намёк понят.\""

    xy "\"Ты не можешь называть меня какой-то курицей, не так ли?\""
    $ sename = "se人体_動作_立ち上がる"
    play se sedict[sename]
    pause (100/1000)
    hide StC with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    hide 絵写板
    with Dissolve(500.0/1000)

    "Я неохотно встал со скамейки."

    "Миюки передала мне металлическую бейсбольную биту."
    $ renpy.music.play("tts_op_loop",channel = "bgm", if_changed = True)
    $ renpy.music.play("tts_op",channel = "bgm", if_changed = True)

    xy "\"Готовься к хорошему уроку!\""
    $ sename = "se人体_動作_バットスイング01"
    play se sedict[sename]
    pause (1500/1000)
    $ sename = "se人体_動作_バットスイング01"
    play se sedict[sename]
    pause (500/1000)

    "Я сделал пару пробных замахов битой."

    "Я знаю, что моя стойка отбивающего не была идеальной."

    "Особенно по сравнению с её стойкой."
    voice "voice/a72/3300050a01.opus"

    mx "\"Классно выглядишь, Шиничи!\""

    xy "\"Вряд ли!\""
    voice "voice/a72/3300060a01.opus"

    mx "\"Нет, правда! Ты круче всех!\""
    pause (500/1000)
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵専:
        pos (-410,-23)
        linear 30 pos (-620,-23)
    with Dissolve((1500.0+1000.0)/1000)
    pause (1000/1000)

    "В смысле, я делаю всё возможное..."

    "Но остальное зависело от удачи."

    "Всё, что я могу сделать - это собрать в себе всю силу..."

    "...и сделать замах."

    xy "\"Ладно, поехали!!!\""
    hide 絵専
    with Dissolve(500.0/1000)
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2500/1000)
    voice "voice/a72/3300070a01.opus"

    mx "\"Ты сможешь!\""
    xy "\"......!!!\""
    $ sename = "se人体_動作_バッティング02"
    $ renpy.vibrate(.3)
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵演色白 zorder 15000 with None
    hide 絵演色白 with Dissolve(1.5)
    pause (1800/1000)

    "Я знаю, что это прозвучит нелепо..."

    "Но поверьте мне, я сам с трудом верю в это."

    "И, верите или нет, когда я ударил по тому мячу..."

    "...он приземлился прямо в центре точки хоум-рана с первой же попытки."

    "Как будто сам Бог дал этому произойти, чтобы подшутить надо мной."
    show expression Solid("000000") as 絵演色黒 zorder 15000
    with Dissolve(5)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
