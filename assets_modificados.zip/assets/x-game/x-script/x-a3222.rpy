label a3222_MAIN:
    call expression GameName
    $ persistent.imagelog["eva3222アオイおんぶ"]=True
    $ PreGameName = GameName
    $ persistent.sim_stolen = True
    if no_call == True:
        $ GameName = "b3223.nss"
    else:
        $ GameName = "a3223.nss"
    python:
        if persistent.sim_stolen_month == None or persistent.passed_sim_stolen_day == None:
            from time import strftime, localtime
            persistent.passed_sim_stolen_month = int(strftime("%m",localtime()))
            persistent.passed_sim_stolen_day = int(strftime("%d",localtime()))
            persistent.DIARY_COUNT += 1
    return
label a3222:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    scene expression ("cg/bg/l/"+imagename["bg020100_3_自宅外正面_l"]+".jpg") as 絵演背景 zorder 100:
        pos (-640,-500)
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    with Dissolve(1000.0/1000)
    $ st_timezone = "夜"
    pause (500/1000)
    $ sename = "se物体_ドア自宅_閉まる"
    play se sedict[sename]
    with Dissolve(1000.0/1000)
    pause (500/1000)
    $ sename = "se人体_動作_たたらを踏む"
    play se sedict[sename]
    pause (300/1000)
    voice "voice/a32/2200010a02.opus"
    aoi "А-ах!.."
    xy "Аой!"
    "В ту секунду, когда мы вышли наружу, Аой потеряла равновесие."
    "Действуя быстро, я положил её руку себе на плечо, чтобы она могла стоять прямо."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    hide 絵演背景
    with Dissolve(500.0/1000)
    voice "voice/a32/2200020a01.opus"
    mx "Стой! Я помогу тебе вернуть её в—"
    xy "Не сегодня. Прости."
    voice "voice/a32/2200030a01.opus"
    mx "......"
    xy "Увидимся завтра."
    voice "voice/a32/2200040a02.opus"
    aoi "Пока-пока... Миюки..."
    voice "voice/a32/2200050a01.opus"
    mx "......"
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Я ушёл вместе с Аой, оставив Миюки наедине с тишиной."
    $ sename = "se人体_動作_抱きつく01"
    play se sedict[sename]
    "Держась одной рукой за мои плечи, Аой ковыляла по улице в уже высохшей форме."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg040400_3_街交差点"]+".jpg")
    pause (1000/1000)
    $ sename = "se人体_足音_歩く複数アオイL"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (300/1000)
    xy "Ты уверена, что хочешь вернуться в манга-кафе?"
    xy "Ты всегда можешь остаться на пару ночей у меня дома, знаешь ли."
    voice "voice/a32/2200060a02.opus"
    aoi "Это активирует флаг рискового события."
    xy "Ладно, тогда, может, в больницу?"
    voice "voice/a32/2200070a02.opus"
    aoi "Аой нужна перезарядка."
    voice "voice/a32/2200080a02.opus"
    aoi "Больница ей с этим не поможет."
    xy "Тогда позволь мне хотя бы вызвать для тебя такси."
    voice "voice/a32/2200090a02.opus"
    aoi "С Аой всё будет хорошо."
    "Серьёзно, как только она начинает о чём-то думать, она отказывается идти на уступки..."
    "К счастью, у неё, вроде как, не было лихорадки, так что это, наверное, не так серьёзно... но если она опять вызовет у меня сердечный приступ, то я определённо вызову ей такси."
    show expression ("cg/bg/"+imagename["bg040200_3_街川縁"]+".jpg")
    $ sename = "se環境_自然_川縁夜L"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    pause (1000/1000)
    voice "voice/a32/2200100a02.opus"
    aoi "Шиничи..."
    xy "Хм? В чём дело?"
    voice "voice/a32/2200110a02.opus"
    aoi "Почему ты подружился со мной?"
    xy "А... ну..."
    "Я пытался восстановить свои воспоминания... о том дне, когда я впервые обменялся адресами электронной почты с Аой."
    "В тот день мы официально стали «друзьями»."
    "А потом она сделала фотографию, где мы с Миюки стояли вместе, и..."
    xy "Я не хотел, чтобы ты распространила ту фотографию."
    voice "voice/a32/2200120a02.opus"
    aoi "Это была вся твоя причина?"
    xy "Ну, в смысле, я должен был хоть ЧТО-ТО сделать, верно?"
    voice "voice/a32/2200130a02.opus"
    aoi "Но у тебя нет терпения иметь дело с другими людьми."
    show expression ("cg/ev/"+imagename["eva1111アオイ受信中a"]+".jpg") as 絵画像 zorder 1000 at center
    show expression ("cg/ev/"+imagename["eva1131美雪過去の面影"]+".jpg") as 絵画像弐 zorder 1001 at center
    with Dissolve((500.0+1000.0)/1000)
    with Dissolve((0.0+1000.0)/1000)
    "Она права."
    "Аой Муко можно было с лёгкостью назвать самой раздражительной девушкой в нашем классе. Даже просто разговаривать с ней было утомительно."
    "Но я всё равно пошёл и сделал это."
    hide 絵画像弐
    with Dissolve(500.0/1000)
    xy "Думаю... ты напомнила мне Миюки."
    xy "Когда мы были маленькими, Миюки тоже с трудом вписывалась в коллектив класса. Она была одинокой, прямо как ты."
    hide 絵画像
    with Dissolve(500.0/1000)
    voice "voice/a32/2200140a02.opus"
    aoi "Миюки..."
    voice "voice/a32/2200150a02.opus"
    aoi "Так вот, в чём дело... Ты хотел помочь Миюки..."
    voice "voice/a32/2200160a02.opus"
    aoi "Буп-буп..."
    $ sename = "se人体_動作_起き上がる01"
    play se sedict[sename]
    hide 絵背景
    $ sename = "se人体_衝撃_転倒02"
    play se sedict[sename]
    pause (500/1000)
    xy "А?"
    "В какой-то момент её ноги запутались между собой, из-за чего она упала на землю."
    xy "Т-ты в порядке?!"
    voice "voice/a32/2200170a02.opus"
    aoi "Да..."
    xy "Погоди секунду!"
    $ sename = "se物体_携帯_開く"
    play se sedict[sename]
    pause (300/1000)
    "Я достал телефон, чтобы позвонить в—"
    voice "voice/a32/2200180a02.opus"
    aoi "Не надо, спасибо."
    voice "voice/a32/2200190a02.opus"
    aoi "Именно здесь мы и попрощаемся."
    xy "Я не собираюсь бросать тебя здесь!"
    voice "voice/a32/2200200a02.opus"
    aoi "Всё нормально."
    show expression ("cg/bg/l/"+imagename["bg040200_3_街川縁_l"]+".jpg") as 絵向日背景 zorder 1000:
        pos (-340,-175)
    $ St("C",1100,0,0,"bu向日アオイ電波_制服_見上げ_normal")
    with Dissolve(700.0/1000)
    "Аой говорила мягким голосом, её взгляд устремился куда-то вдаль."
    voice "voice/a32/2200210a02.opus"
    aoi "Как только ты вышел на рут, другие девушки отойдут на второй план."
    voice "voice/a32/2200220a02.opus"
    aoi "Так что ты вскоре забудешь обо мне."
    voice "voice/a32/2200230a02.opus"
    aoi "И ты забудешь о том, что оставил меня здесь."
    xy "Только через мой труп!"
    hide 絵向日
    hide StC
    hide StMR
    hide StML
    $ sename = "se人体_動作_抱きつく01"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    "Вздохнув, я присел на обочине дороги."
    xy "Залезай."
    voice "voice/a32/2200240a02.opus"
    aoi "Буп-буп?!.."
    xy "Я понесу тебя."
    voice "voice/a32/2200250a02.opus"
    aoi "Зачем?"
    xy "Ну, ты не даёшь мне вызвать для тебя такси!"
    xy "Но с другой стороны, дойти дотуда пешком будет быстрее. А теперь залезай."
    voice "voice/a32/2200260a02.opus"
    aoi "Но Аой—"
    xy "Я сказал, залезай!"
    xy "В смысле, для чего ещё нужны друзья?"
    voice "voice/a32/2200270a02.opus"
    aoi "Друзья..."
    voice "voice/a32/2200280a02.opus"
    aoi "...Ладно."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    $ renpy.music.play("ttb07",channel = "bgm", if_changed = True)
    pause (300/1000)
    show expression ("cg/ev/"+imagename["eva3222アオイおんぶ"]+".jpg") as 絵専弐 zorder 1000 at truecenter
    pause (300/1000)
    $ sename = "se人体_足音_歩く01遅L"
    play se sedict[sename]
    pause (300/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (300/1000)
    "Аой залезла мне на спину, и мы отправились под лунным светом."
    "Она такая мягкая... и тёплая... и маленькая..."
    hide 絵専
    with Dissolve(500.0/1000)
    xy "Ого, ты почти что невесомая. Ты точно ешь?"
    voice "voice/a32/2200290a02.opus"
    aoi "Аой пьёт много Ябалея."
    xy "Тебе нужно что-нибудь более калорийное! Просто если так пойдёт и дальше, то от тебя останутся только кожа да кости."
    voice "voice/a32/2200300a02.opus"
    aoi "Но в нём есть любовь."
    xy "Любовь?"
    voice "voice/a32/2200310a02.opus"
    aoi "Аой было так весело каждый день."
    voice "voice/a32/2200320a02.opus"
    aoi "Все те давно забытые эмоции нахлынули на меня."
    voice "voice/a32/2200330a02.opus"
    aoi "И всё это благодаря тебе."
    show expression ("cg/ev/l/"+imagename["eva3222アオイおんぶ_l"]+".jpg") as 絵専:
        pos (-730,-150)
    with Dissolve((500.0+1000.0)/1000)
    voice "voice/a32/2200340a02.opus"
    aoi "Ты мне нравишься, Шиничи."
    voice "voice/a32/2200350a02.opus"
    aoi "Ты мне очень нравишься. Я люблю тебя."
    xy "......"
    voice "voice/a32/2200360a02.opus"
    aoi "Шиничи, у тебя всё лицо красное."
    voice "voice/a32/2200370a02.opus"
    aoi "Аой сейчас похожа на твою девушку?"
    xy "Н-нет..."
    voice "voice/a32/2200380a02.opus"
    aoi "Аой сейчас так счастлива."
    voice "voice/a32/2200390a02.opus"
    aoi "Очень счастлива."
    voice "voice/a32/2200400a02.opus"
    aoi "Быть твоей подругой – лучшая вещь на свете."

    hide 絵専
    with Dissolve(1000.0/1000)
    voice "voice/a32/2200410a02.opus"
    aoi "Возможно... мог бы даже начаться рут Аой."
    voice "voice/a32/2200420a02.opus"
    aoi "Но не сейчас."
    voice "voice/a32/2200430a02.opus"
    aoi "Это рут Миюки."
    xy "Я же сказал тебе, перестань говорить так, будто мы в ви—"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
