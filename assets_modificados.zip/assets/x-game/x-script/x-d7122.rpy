label d7122_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d7123.nss"
    return
label d7122:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    "Я вряд ли смогу поверить в её историю."
    "Она отказывалась брать на себя ответственность за всё то, что натворила."
    "Вместо этого, она переложила всю вину на какого-то вымышленного бога."
    "Разговаривать с ней - пустая трата времени."
    "Теперь я просто хочу стереть все следы нашей совместной жизни."
    "И поэтому..."
    "...я вернулся в свою спальню, чтобы собрать её вещи."
    $ sename = "se物体_ドア室内_開く01"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg030400_3_自宅廊下"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    pause (300/1000)
    $ St("C",300,0,0,"st曽根美雪_私服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/d71/2200010a01.opus"
    mx "\"Похоже, ты уже всё решил.\""
    xy "\"...Что ты до сих пор здесь делаешь?\""
    "Я думал, она уже пошла к себе домой..."
    $ St("C",300,0,0,"st曽根美雪_私服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/d71/2200020a01.opus"
    mx "\"Прости... я просто не могла не забеспокоиться.\""
    xy "\"Ну, тебе не стоит беспокоиться. Больше нет.\""
    "Я прошёл мимо неё в свою комнату."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
