label e2204b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2204b:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)

    "Любопытство до добра не доводит..."
    show expression ("cg/bg/"+imagename["bg110110_1_マンションリビングソファー"]+".jpg")
    with Dissolve(500.0/1000)

    "Я осторожно положил телефон на стол и вернулся к своей домашней работе."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
