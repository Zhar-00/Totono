label e2193a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2194.nss"
    return
label e2193a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    with Dissolve(0.0/1000)

    "Миюки, однозначно."

    "Я не совсем уверен, почему она так настаивала на том, чтобы я не заглядывал в эту коробку, но..."
    xy "\"Ладно, твоя взяла.\""

    "Я отошёл от коробки, и мы вместе пошли домой."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
