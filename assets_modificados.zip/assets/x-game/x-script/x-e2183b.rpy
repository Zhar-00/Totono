label e2183b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2184a.nss"
    return
label e2183b:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_shy")
    with Dissolve(0.0/1000)
    voice "voice/e21/83b00010a01.opus"

    mx "\"В смысле, я польщена, но...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/83b00020a01.opus"

    mx "\"Я просто... мне просто нужно ещё немного времени, прежде чем я смогу доверять тебе.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
