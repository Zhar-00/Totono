label e3124a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a3124b.nss"
    return
label e3124a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    pause (16/1000)
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
    pause (16/1000)
    scene expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    stop bgm fadeout (0.0/1000)
    hide 絵色黒
    $ renpy.music.play("ttb27",channel = "bgm", if_changed = True)
    $ renpy.music.play("bgm/ttb27_ef.opus",channel = "music", if_changed = True)
    pause (16/1000)
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
    hide 上背景
    pause (200/1000)
    voice "voice/e31/24a00010a01.opus"

    mx "\"Да, если бы только это был выбранный тобой рут.\""
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e31/24a00020a01.opus"

    mx "\"Но это оказалось не так, верно?\""
    voice "voice/e31/24a00030a01.opus"

    mx "\"Проклятье было вызвано...\""
    voice "voice/e31/24a00040a01.opus"

    mx "\"...вот этим выбором.\""
    pause (16/1000)
    pause (16/1000)
    stop bgm fadeout (150.0/1000)
    hide StC
    hide StMR
    hide StML
    show expression ("cg/ev/l/"+imagename["eva0113アオイ送信中b_l"]+".jpg") as 絵演背景 zorder 1000 at truecenter
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    pause (500/1000)
    menu:
        "Позволить ей сделать это":
            pass
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
