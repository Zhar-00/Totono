label a6121_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a6131.nss"
    return
label a6121:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    show expression Solid("000000") as 絵色黒
    hide 上背景
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (500/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100010b01.opus"
    xtl "Доброе утро, Шиничи!"
    xy "Как там Аой?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100020b01.opus"
    xtl "Какое несчастье... Прошлая ночь была безумной!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100030b01.opus"
    xtl "У неё явно было плохое самочувствие, поэтому я пытался отвести её в больницу, но она наотрез отказывалась! Говорила, что время уже позднее!"
    voice "voice/a61/2100040b01.opus"
    xtl "А потом она сказала, что собиралась вернуться в манга-кафе, но мой старик был КАТЕГОРИЧЕСКИ ПРОТИВ, ты себе можешь такое представить?!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100050b01.opus"
    xtl "И в итоге всю ночь она провела у нас дома."
    xy "А потом что было?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100060b01.opus"
    xtl "Ну, сегодня утром она была в полном порядке."
    xy "Что? Правда?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100070b01.opus"
    xtl "Да. Думаю, с ней пока всё хорошо."
    voice "voice/a61/2100080b01.opus"
    xtl "Но я сказал ей, чтобы она сегодня осталась дома и отдыхала, на всякий случай."
    xy "С-серьёзно?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100090b01.opus"
    xtl "А что, думаешь, капитан клуба «Ребята и Мечты» будет врать тебе?"
    xy "Нет, нет... Конечно же нет. Большое тебе спасибо, чувак. Я реально по гроб тебе должен."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100100b01.opus"
    xtl "Слушай, эм, Шиничи?"
    "Ютаро неловко почесал затылок."
    voice "voice/a61/2100110b01.opus"
    xtl "Ты думаешь, Муко и её семья?.."
    xy "Да-а-а, судя по всему, они пока не особо ладят. Именно поэтому она часто спит в манга-кафе."
    xy "Хотя она особо ничего и не говорила об этом."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100120b01.opus"
    xtl "В таком случае, может, нам стоит оставить её у нас ещё на какое-то время?"
    xy "Да?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100130b01.opus"
    xtl "Видишь ли, мой отец сказал, что хотел бы держать её подальше от улиц. И он к чему-либо подобному относится со всей серьёзностью, так что вот, сам понимаешь..."
    "В общем, Ютаро, похоже, был очень доволен такой перспективой."
    "Лично я, наверное, предпочёл бы, чтобы она осталась с ними, нежели в манга-кафе, но..."
    xy "А ты уверен, что это хорошая идея, ты и она под одной крышей?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_happy")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100140b01.opus"
    xtl "Что?.. Ха-ха-ха-ха! Я тебя умоляю! Это ещё что должно означать?"
    xy "Ты знаешь, о чём я. Ты парень, а она – девушка—"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100150b01.opus"
    xtl "Хмф! Вы меня обижаете, сэр! Моё сердце принадлежит только Сонэ-сан!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100160b01.opus"
    xtl "В смысле, Муко... ну, понимаешь... Она не... как бы сказать... я не вижу её такой. Раз на то пошло, она для меня как младшая сестра!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_shy")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100170b01.opus"
    xtl "Ах, жить вместе со своей младшей сестрой... если честно, об этом мечтает любой мужчина!.."
    xy "......"
    "Ну, раз его отец присматривает за ними, думаю, волноваться не о чем."
    "Я просто рад, что ей уже лучше."
    show expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg")
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(500.0/1000)
    voice "voice/a31/8100190a01.opus"
    mx "......"
    "Я почувствовал, как на меня кто-то смотрел, и медленно развернулся."
    "Миюки молча смотрела в мою сторону."
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    voice "voice/a61/2100190b01.opus"
    xtl "Воу... Какого?.."
    hide StC with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_think")
    $ St("ML",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(500.0/1000)
    "Она не только не поздоровалась с другими учениками, но и прошла вперёд."
    $ St("MR",300,0,0,"st曙雄太郎_制服_通常_shy")
    voice "voice/a61/2100200b01.opus"
    xtl "С-Сонэ-сан!!!"
    voice "voice/a61/2100210b01.opus"
    xtl "Доброе у—!"
    show expression ("cg/bg/l/"+imagename["bg010600_1_学校教室_l"]+".jpg") as 絵背景 zorder 100 at truecenter
    hide StC
    hide StMR
    hide StML
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    $ sename = "se人体_動作_衣擦れ01"
    play se sedict[sename]
    with Dissolve(400.0/1000)
    voice "voice/a61/2100220a01.opus"
    mx "Шиничи."
    xy "......"
    $ sename = "se物体_紙_手紙開く"
    play se sedict[sename]
    "Она передала мне конверт."
    "Её пальцы дрожали."
    voice "voice/a61/2100230a01.opus"
    mx "Вот билет на спектакль."

    voice "voice/a61/2100240a01.opus"
    mx "Я буду ждать."

    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100250a01.opus"
    mx "Пожалуйста."
    hide StC
    hide StMR
    hide StML
    hide 絵背景
    with Dissolve(500.0/1000)
    pause (700/1000)
    $ sename = "se環境_ガヤ_教室ざわめくL"
    play se sedict[sename]
    "Она положила конверт на мою парту, а потом грациозно закружилась на месте, как будто покидала сцену..."
    "...а весь класс был нашей аудиторией."
    "В воздухе начали витать странные слухи."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_cry")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100260b01.opus"
    xtl "Чёрт побери!"
    voice "voice/a61/2100270b01.opus"
    xtl "Я всегда подозревал это, но теперь я вижу правду! Ты и Сонэ-сан—!"
    xy "Да. Она вчера призналась мне в любви."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100280b01.opus"
    xtl "Что?"
    xy "Это всё, что произошло."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100290b01.opus"
    xtl "И всё?!"
    xy "Меня не интересуют отношения с ней."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100300b01.opus"
    xtl "Ч... ч... ч..."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/a61/2100310b01.opus"
    xtl "ЧТО-О-О-О-О-О-О-О-О-О-О-О-О?!"
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    stop se fadeout (1500.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    pause (1000/1000)
    $ sename = "se環境_ガヤ_学校屋上授業中"
    play se sedict[sename]
    pause (500/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    "Если бы я только мог сказать, что меня она не привлекает."
    "Но я даже соврать ей не могу."
    "Господи, лучше бы уж я помер."
    "...Но, разумеется, я не собираюсь умирать."
    "Пока я затягивал со своим решением, время шло..."
    "...пока Миюки наконец не исчезла из моей жизни в очередной раз."
    pause (500/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
