label b5172_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5173.nss"
    return
label b5172:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_病み_normal")
    voice "voice/b51/7200010a01.opus"
    mx "\"Кстати...\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    voice "voice/b51/7200020a01.opus"
    mx "\"Что это за игра?\""
    xy "\"А, эм...\""

    "Миюки протянула руку и взяла что-то с моего стола."

    "Это был тот телефон, который я одолжил у Ютаро."

    "Визуальная новелла, которую я видел ранее, всё ещё отображалась на его экране."
    $ St("C",300,0,0,"st曽根美雪_制服_病み_hard")
    with Dissolve(200.0/1000)
    voice "voice/b51/7200030a01.opus"

    mx "\"Стоп... Разве этот персонаж не похож на Аой?\""
    voice "voice/b51/7200040a01.opus"
    mx "\"И её диалог—\""
    xy "\"С-стой! Отдай его!\""
    $ St("C",300,0,0,"st曽根美雪_制服_病み_smile")
    with Dissolve(200.0/1000)
    voice "voice/b51/7200050a01.opus"
    mx "\"Чего это ты так перепугался?\""
    xy "\"Не трогай его! Я его у своего друга взял!\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/b51/7200060a01.opus"
    mx "\"Ну, ладно. Если ты не хочешь, чтобы я его трогала, можешь забрать его обратно.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/b51/7200070a01.opus"
    mx "\"Упс!\""
    $ sename = "se物体_携帯_落ちる01"
    play se sedict[sename]
    pause (300/1000)
    voice "voice/b51/7200080a02.opus"

    aoi "\"А-а-ах!\""

    "И прежде, чем она успела передать его мне в руки, он выскользнул у неё из рук, покатился по полу и исчез под кроватью."

    "Аой пискнула от удивления."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/b51/7200090a01.opus"

    mx "\"Это странно. Ты что-то сказал?\""

    xy "\"А? Н-нет, а что? Может, тебе послышалось?\""
    $ St("C",300,0,0,"st曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/b51/7200100a01.opus"
    mx "\"Ха-ха-ха! Скорее всего, раз уж Аой ОПРЕДЕЛЁННО не здесь.\""
    pause (200/1000)
    $ sename = "se人体_動作_衣擦れ01"
    play se sedict[sename]
    hide StC with Dissolve(500.0/1000)
    with Dissolve(800.0/1000)
    pause (500/1000)

    "Сказав это игривым тоном, Миюки нагнулась ниже, чтобы достать телефон."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
