label e2225f_MAIN:
    call expression GameName
    $ MaidImpression = True;
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2225f:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    show expression Solid("000000") as 絵色黒
    pause (2000/1000)
    with Dissolve(0.0/1000)
    voice "voice/e22/25f00010a01.opus"

    mx "Поверить не могу, что ТЫ устроил такой бардак...и ещё весь мой костюм для косплея обкончал..."
    voice "voice/e22/25f00020a01.opus"

    mx "ТЫ, наверное, маленький извращенец, хм?"
    voice "voice/e22/25f00030a01.opus"

    mx "Но... всё нормально..."
    voice "voice/e22/25f00040a01.opus"

    mx "Я всё равно буду любить ТЕБЯ..."
    pause (1000/1000)
    show expression Solid("000000") as 絵色黒
    pause (16/1000)
    hide 上背景
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
