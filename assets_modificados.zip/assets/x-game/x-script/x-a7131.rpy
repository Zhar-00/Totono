label a7131_MAIN:
    call expression GameName
    $ persistent.imagelog["eva7131美雪手繋ぎ登校"]=True
    $ persistent.imagelog["bg040400_1_街交差点"]=True
    $ PreGameName = GameName
    if hamonjo == True:
        $ GameName = "d7132.nss"
    else:
        $ GameName = "a7132.nss"
    return
label a7131:
    hide 絵色黒
    $ renpy.music.play("ttb16",channel = "bgm", if_changed = True)
    scene expression ("cg/bg/"+imagename["bg040400_1_街交差点"]+".jpg")
    with Dissolve(800.0/1000)
    voice "voice/a71/3100010a01.opus"
    mx "\"Доброе утро!\""
    voice "voice/a71/3100020a01.opus"

    mx "Доброе у— Эй! Иди сюда!"
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    show expression ("cg/ev/"+imagename["eva7131美雪手繋ぎ登校"]+".jpg") as 絵専 zorder 1100 at center
    with Dissolve((500.0+1000.0)/1000)
    pause (1000/1000)
    show expression ("cg/ev/l/"+imagename["eva7131美雪手繋ぎ登校_l"]+".jpg") as 絵専上:
        pos (-670,-560)
    show expression ("cg/ev/l/"+imagename["eva7131美雪手繋ぎ登校_l"]+".jpg") as 絵専上上:
        pos (-20,-20)

    xy "М-мы не должны делать это, знаешь ли..."
    voice "voice/a71/3100030a01.opus"

    mx "Но ты мой парень!"
    voice "voice/a71/3100040a01.opus"

    mx "Почему бы нам не пойти в школу вместе?"
    with Dissolve((500.0+1000.0)/1000)

    "Она потянула меня за руку."
    xy "......"
    with Dissolve((500.0+1000.0)/1000)
    hide 絵専
    hide 絵専上

    "Я больше не мог с ней спорить."
    $ sename = "se人体_足音_歩く複数美雪L"
    play se sedict[sename]

    "Пока мы проходили через толпы людей по пути в школу, я мог почувствовать странную ауру от всех, с кем мы столкнулись."

    "Миюки, возможно, и влюблена в меня, но это не меняет сам факт того, что она объективно не моего уровня."
    show expression ("cg/bg/"+imagename["bg040100_1_街通学路"]+".jpg")
    with Dissolve(500.0/1000)

    xy "Ты на удивление спокойна, как погляжу."
    voice "voice/a71/3100050a01.opus"

    mx "Это всего лишь притворство. Внутри меня сердце колотится как сумасшедшее."

    "Сказала как настоящая драмактриса."

    "Только актриса её калибра может так хорошо скрывать своё волнение."

    xy "Но я не такой хороший актёр."
    voice "voice/a71/3100060a01.opus"

    mx "Ой, смирись уже с этим."
    show expression ("cg/bg/"+imagename["bg010400_1_学校校門"]+".jpg")
    with Dissolve((500.0)/1000)
    with Dissolve(500.0/1000)
    stop se fadeout (200.0/1000)

    "Бок о бок, мы дошли до ворот."

    "На данный момент, я уже пережил это."
    show expression ("cg/bg/"+imagename["bg010500_1_学校昇降口"]+".jpg")
    with Dissolve(500.0/1000)

    "Хейтеры могут злиться сколько им влезет."

    "Ничто не может меня напугать..."
    show expression ("cg/bg/"+imagename["bg010700_1_学校廊下"]+".jpg")
    with Dissolve(500.0/1000)

    xy "Я не могу. Я не могу сделать это!"

    "...Ладно, видимо, я соврал."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    show expression ("cg/bg/m/"+imagename["bg010700_1_学校廊下_m"]+".jpg") as 絵演背景 zorder 15:
        pos (-400,-170)
    with Dissolve(500.0/1000)
    voice "voice/a71/3100070a01.opus"

    mx "Но мы должны сделать это, чтобы утереть всем нос, помнишь?"

    xy "Я... я знаю, но я эмоционально не готов—!"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a71/3100080a01.opus"

    mx "Не будь таким ребёнком. Пошли уже!"
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (2000/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (300/1000)
    $ sename = "se人体_衝撃_突き飛ばす"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白
    pause (30/1000)
    hide 絵色白
    with Dissolve(70.0/1000)

    xy "Воу!"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((300.0+1000.0)/1000)
    hide 絵板写
    hide 絵演背景
    pause (200/1000)
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    hide 絵色黒
    with Dissolve(500.0/1000)

    xy "Не так быстро!.."

    "Я приковылял в класс."

    "После этого она вошла после меня."
    $ St("MR",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(500.0/1000)
    voice "voice/a71/3100090a01.opus"
    mx "\"Доброе утро!!\""
    hide StMR
    hide StML

    "Она непринуждённо поприветствовала класс, как и всегда."

    "Один за другим, наши одноклассники поприветствовали её таким же образом."

    "Я мог расслышать озадаченность в их голосах... но тем не менее, они, как обычно, столпились вокруг своей королевы."
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve(500.0/1000)

    "Очевидно, весь класс уже слышал новость о том, что мы вместе ходили в школу; я чувствовал любопытные взгляды, направленные в мою сторону."

    "И я заметил, как мои одноклассники ухмыльнулись мне; некоторые из них, в обычной ситуации, даже не заметили бы, что я вообще существую."

    "Некоторые из них даже подошли поближе, чтобы похлопать меня по спине..."
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg") as 絵揺れ背景 zorder 1120 at truecenter
    $ sename = "se擬音_コミカル_攻撃複数L"
    play se sedict[sename]
    with Dissolve((100.0+0.0)/1000)
    pause (100/1000)
    with Dissolve((0.0+1000.0)/1000)
    with Dissolve((100.0+0.0)/1000)
    pause (100/1000)
    with Dissolve((0.0+1000.0)/1000)
    with Dissolve((100.0+0.0)/1000)

    xy "Ай! Больно ведь! Ребят, перестаньте!"

    "Я заметил, как некоторые из них решили использовать такую возможность, чтобы выразить свою зависть..."

    xy "А-ай! Ха-ха-ха... Д-да ладно вам, ребята, дайте мне передохнуть!"

    "Но я знаю, что они, по большей части, просто шутили. Кроме того, я подумал, что они как-нибудь ещё поиздеваются надо мной."

    "Но должен признать, что я был немного разочарован тем, как быстро они пришли в себя."

    "Если бы только каждый день мог быть таким—"
    stop bgm fadeout (2000/1000)
    xy "......"

    "И вдруг я получил весьма неприятный тревожный звонок."

    "Одинокий клочок бумаги ждал меня на моей парте."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
