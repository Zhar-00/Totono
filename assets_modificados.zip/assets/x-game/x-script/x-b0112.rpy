label b0112_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    $ no_call = True;
    $ roof = False;
    return
label b0112:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    with Dissolve(0.0/1000)
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    xy "\"Хм-м-м?\""
    show expression ("cg/ef/"+imagename["efbgアオイのスマフォ"]+".jpg") as 絵演効果 zorder 100 at center
    with Dissolve((0.0+1000.0)/1000)
    pause (500/1000)

    "Я посмотрел вниз."

    "Чей-то телефон валялся на земле у двери экраном вниз."

    "Кто его обронил?"
    hide 絵演効果
    with Dissolve(500.0/1000)
    return
    return
label b0112_SELECT:
    $ renpy.save("lastsel")
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    with Dissolve(0.0/1000)
    menu:
        "Позвонить по телефону":
            $ SetChoiceSelect = 0
        "Проверить историю вызовов":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "a0113t.nss"
    elif SetChoiceSelect==1:
        if persistent.aoi_true or persistent.miyuki_true:
            $ GameName = "f1111.nss"
        else:
            if persistent.c_route == True:
                $ GameName = "e0113.nss";
            else:
                $ GameName = "a0113.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
