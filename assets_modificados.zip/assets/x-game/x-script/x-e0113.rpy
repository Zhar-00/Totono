label e0113_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    $ roof = True
    return
label e0113:
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    $ roof = True
    with Dissolve(0.0/1000)
    "И прежде, чем я успел проверить историю вызовов—"
    $ sename = "se物体_ドア屋上_鍵開ける01"
    play se sedict[sename]
    pause (3000/1000)
    voice "voice/e01/1300010a01.opus"
    mx "\"Это мой.\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    pause (500/1000)
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    "Дверь распахнулась. Это была Миюки."
    xy "\"Правда? Не знал, что у тебя есть смартфон.\""
    "Я думал, у неё одна из тех старых раскладушек..."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e01/1300020a01.opus"
    mx "\"Я нашла его у тебя дома.\""
    xy "\"Что? Ты нашла его?\""
    with Dissolve(200.0/1000)
    voice "voice/e01/1300030a01.opus"
    mx "\"Наверное, ты забыл. Всё-таки это давно было.\""
    if persistent.miyuki[0] == 0:
        $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
        with Dissolve(200.0/1000)
        voice "voice/e01/1300040a01.opus"
        mx "\"Но он немного старый, понимаешь?\""
    elif persistent.miyuki[0] == 1:
        $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
        with Dissolve(200.0/1000)
        voice "voice/e01/1300050a01.opus"
        mx "\"И выглядит немного безвкусно, смекаешь?\""
    elif persistent.miyuki[0] == 2:
        $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
        with Dissolve(200.0/1000)
        voice "voice/e01/1300060a01.opus"
        mx "\"Да и с ним связано так много плохих воспоминаний, понимаешь?\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e01/1300070a01.opus"
    mx "\"Поэтому я и приобрела себе новый.\""
    show expression ("cg/ef/"+imagename["efbg美雪のスマフォ"]+".jpg") as 絵演効果 zorder 1000 at center
    $ sename = "se人体_動作_衣擦れ02"
    play se sedict[sename]
    with Dissolve((1000.0+1000.0)/1000)
    "Она достала яркий, новый смартфон из своего кармана."
    "Это была последняя модель с самым большим экраном."
    $ St("C",300,0,0,"st曽根美雪_制服_恋人_smile")
    voice "voice/e01/1300080a01.opus"
    mx "\"Пока у меня есть сим-карта, этот старый смартфон мне не нужен.\""
    hide 絵演効果
    with Dissolve(800.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e01/1300090a01.opus"
    mx "\"Ты не мог бы выбросить его за меня?\""
    xy "\"Что, выкинуть его прямо с крыши?\""
    $ St("C",300,0,0,"st曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e01/1300100a01.opus"
    mx "\"Да. Просто выкинь его прямо с крыши.\""
    return
    return
label e0113_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    $ renpy.music.play("ttb10",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_恋人_happy")
    with Dissolve(0.0/1000)
    menu:
        "Выбросить его":
            $ SetChoiceSelect = 0
        "Не выбрасывать его":
            $ SetChoiceSelect = 1
    if SetChoiceSelect == 0:
        $ persistent.miyuki_love += 1
        $ GameName = "e0114a.nss";
    elif SetChoiceSelect == 1:
        $ persistent.miyuki_love -= 1
        $ GameName = "e0114b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
