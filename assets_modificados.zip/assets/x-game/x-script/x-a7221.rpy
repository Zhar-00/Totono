label a7221_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if persistent.a_route == True:
        $ GameName = "a7221b.nss"
    else:
        $ GameName = "a7222.nss"
    return
label a7221:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg030301_3_自宅リビング消灯"]+".jpg")
    show expression Solid("000000") as 絵演色黒
    $ sename = "se人体_動作_食事01L"
    play se sedict[sename]
    hide 上背景
    "Мы сидели бок о бок на диване, прислонившись друг к другу, и ели наш торт."
    $ renpy.music.play("ttb08",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030301_3_自宅リビング消灯"]+".jpg")
    pause (800/1000)
    hide 絵演色黒
    with Dissolve(1000.0/1000)
    stop se fadeout (150.0/1000)
    voice "voice/a72/2100010a01.opus"
    mx "\"Спасибо.\""
    xy "\"Нет, тебе спасибо.\""
    voice "voice/a72/2100020a01.opus"
    mx "\"Я буду помнить этот день до конца своей жизни.\""
    voice "voice/a72/2100030a01.opus"
    mx "\"И остаток своей следующей жизни - тоже, если она ещё будет.\""
    voice "voice/a72/2100040a01.opus"
    mx "\"Клянусь, я его никогда, НИКОГДА не забуду.\""
    xy "\"Ладно, теперь ты просто преувеличиваешь.\""
    voice "voice/a72/2100050a01.opus"
    mx "\"Вовсе нет!\""
    "Миюки надулась."
    voice "voice/a72/2100060a01.opus"
    mx "\"В смысле, ты... ты украл мою девственность!..\""
    voice "voice/a72/2100070a01.opus"
    mx "\"Разумеется, я никогда не забуду свой первый раз!\""
    voice "voice/a72/2100080a01.opus"
    mx "\"Так что теперь, каждый год на твой день рождения, я всегда буду вспоминать о нашей первой встрече.\""
    xy "\"Хм... понятно.\""
    voice "voice/a72/2100090a01.opus"
    mx "\"А что, это проблема?\""
    xy "\"Вовсе нет.\""
    voice "voice/a72/2100100a01.opus"
    mx "\"Хорошо. Спасибо.\""
    voice "voice/a72/2100110a01.opus"
    mx "\"И я не отпущу тебя, мистер.\""
    "Её слова заставили меня улыбнуться против моей воли."
    "На данный момент я был самым счастливым парнем на свете."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
