label c5201_MAIN:
    call expression GameName
    $ persistent.imagelog["evc5201アオイモーニングフェラa"]=True
    $ persistent.imagelog["evc5201アオイモーニングフェラb"]=True
    $ PreGameName = GameName
    $ GameName = "c5211.nss"
    $ persistent.library_scene3 = True
    hide 和谐的黑色 onlayer hexie
    if RECO_PLAY == 1:
        $ GameCircle=False
    return
label c5201:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    scene expression ("cg/bg/"+imagename["bg030100_1_自宅自室"]+".jpg") with fade
    $ sename = "se人体_動作_衣擦れ濡れ場02"
    play se sedict[sename]
    show expression ("cg/ev/"+imagename["evc5201アオイモーニングフェラa"]+".jpg") as 絵専 zorder 1100 at truecenter
    show expression ("cg/ev/l/"+imagename["evc5201アオイモーニングフェラa_l"]+".jpg") as 絵専上 zorder 1200:
        pos (-480,-190)
    hide 上背景
    voice "voice/c52/0100010a02.opus"

    aoi "\"М-мф... хл-л-л-люп... хл-л-л-люп... м-мл-лп-п... хл-л-люп... хл-л-л-л-л-л-л-люп!..\""

    "...М-м-м?.."

    "Что это за звук?.."
    hide 絵色黒
    with Dissolve(800.0/1000)
    pause (500/1000)
    with Dissolve(1600.0/1000)
    pause (500/1000)
    hide 絵専上 with dissolve
    voice "voice/c52/0100020a02.opus"

    aoi "\"Хл-л-люп... м-мл-лп-п... м-мх... м-мх... м-мф... хл-л-люп... р-рп-п... р-рп-п-п!!!\""
    pause (1000/1000)
    show expression ("cg/ev/"+imagename["evc5201アオイモーニングフェラb"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(500.0/1000)
    voice "voice/c52/0100030a02.opus"

    aoi "\"М-мл-лп-п... Буп-буп?\""
    voice "voice/c52/0100040a02.opus"

    aoi "\"Шиничи? Ты проснулся?\""

    xy "\"Что ты делаешь?\""
    voice "voice/c52/0100050a02.opus"

    aoi "\"Лижу твой член.\""
    show expression ("cg/ev/"+imagename["evc5201アオイモーニングフェラa"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    voice "voice/c52/0100060a02.opus"

    aoi "\"М-м-мф... м-мл-л-лп-п-п... хл-л-л-люп... м-мх... хл-л-л-люп!\""
    voice "voice/c52/0100070a02.opus"

    aoi "\"М-мл-лп-п... Ты такой твёрдый...\""

    "Она водила свой язык вверх и вниз по всей длине моего ствола, периодически останавливаясь, чтобы обхватить его своими губами."

    "Моё возбуждение тут же начало нарастать."

    "Но чем больше она мне посасывала, тем сильнее мой здравый смысл начинал действовать."
    voice "voice/c52/0100080a02.opus"

    aoi "\"М-мл-лп-п... м-мл-лп-п... хл-л-л-л-л-люп! М-мл-лп-п... хл-л-л-люп... хл-л-л-л-л-л-люп!\""
    voice "voice/c52/0100090a02.opus"

    aoi "\"Хл-л-л-люп... хл-л-люп... хл-л-люп! М-м-м... Фха-а! Он такой вкусный!\""

    xy "\"Ты снова перезаряжаешься?\""
    show expression ("cg/ev/"+imagename["evc5201アオイモーニングフェラb"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(800.0/1000)
    voice "voice/c52/0100100a02.opus"

    aoi "\"Не-а.\""
    voice "voice/c52/0100110a02.opus"

    aoi "\"Просто захотела сделать это... потому что Аой любит тебя.\""

    xy "\"...Прости.\""
    $ sename = "se人体_動作_起き上がる02"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg030100_1_自宅自室"]+".jpg")
    hide 絵専
    with Dissolve(500.0/1000)

    "Я нежно отпихнул её от себя и сел на кровать."

    "Аой потеряла равновесие и чуть не свалилась."

    xy "\"На мой взгляд, пока ещё рановато настраиваться на такой лад.\""
    $ St("C",300,0,0,"st向日アオイ_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c52/0100120a02.opus"
    aoi "\"Почему?..\""
    voice "voice/c52/0100130a02.opus"

    aoi "\"Мы с того дня вообще ни разу не занимались сексом.\""
    $ St("C",300,0,0,"st向日アオイ_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c52/0100140a02.opus"

    aoi "\"Я тебе уже не нравлюсь?\""

    xy "\"Дело не в этом.\""
    $ St("C",300,0,0,"st向日アオイ_制服_密着_pain")
    with Dissolve(200.0/1000)
    voice "voice/c52/0100150a02.opus"

    aoi "\"А в чём тогда?\""

    "Я не знаю."

    "Мне кажется, я всё ещё люблю её."

    "Мне кажется, я всё ещё доверяю ей."

    "Но мои чувства просто не складываются."

    xy "\"Давай собираться в школу.\""
    $ St("C",300,0,0,"st向日アオイ_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/c52/0100160a02.opus"
    aoi "\"Буп-буп...\""
    hide StC with Dissolve(200.0/1000)

    "Проигнорировав Аой, я соскочил с кровати и начал свою утреннюю рутину."

    "Я чувствовал себя слишком отвратительно - и виновато - чтобы посмотреть ей в глаза."
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
