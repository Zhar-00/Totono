label a7222_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a7231.nss"
    return
label a7222:
    hide 絵色黒
    $ renpy.music.play("ttb08",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030301_3_自宅リビング消灯"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/a72/2200010a01.opus"

    mx "\"А, точно! Чуть не забыла про твой подарок!\""
    voice "voice/a72/2200020a01.opus"

    mx "\"...Не то, чтобы он нам теперь нужен.\""

    xy "\"Что ты имеешь в виду?\""
    voice "voice/a72/2200030a01.opus"

    mx "\"Ну, помнишь, как ты в классе говорил о том, что формы горничной были твоей мечтой или что-то в таком духе?\""
    voice "voice/a72/2200040a01.opus"

    mx "\"Ну... я купила одну такую сегодня, и...\""
    voice "voice/a72/2200050a01.opus"

    mx "\"Я подумала, что подарю её тебе на день рождения.\""
    voice "voice/a72/2200060a01.opus"

    mx "\"Но потом я внезапно оказалась под влиянием момента... и теперь мой подарок пропадёт впустую—\""
    show expression ("cg/bg/l/"+imagename["bg030301_3_自宅リビング消灯_l"]+".jpg") as 絵演背景 zorder 15 at truecenter
    $ St("C",300,0,30,"bu曽根美雪_私服_通常_shock")
    hide 絵板写
    $ sename = "se人体_動作_掴む胸倉"
    play se sedict[sename]
    $ sename = "se人体_動作_飛び起きる"
    play se sedict[sename]
    hide 絵板写上

    xy "\"Нет, он не пропадёт!\""
    voice "voice/a72/2200070a01.opus"

    mx "\"А? Но Шиничи, мы уже—\""
    $ sename = "se人体_動作_押し倒す"
    play se sedict[sename]
    show expression Solid("000000") as 絵演色黒
    with Dissolve(100.0/1000)
    hide StC
    hide StMR
    hide StML
    voice "voice/a72/2200080a01.opus"

    mx "\"Что за— А-А-АХ! Шин... ичи?..\""

    xy "\"Для тебя я могу поднять его столько раз, сколько потребуется!\""
    voice "voice/a72/2200090a01.opus"

    mx "\"Боже, как это мило с твоей стороны...\""
    xy "\"Миюки!\""

    xy "\"Я без ума от тебя! Не больше, не меньше!\""
    voice "voice/a72/2200100a01.opus"

    mx "\"О боже... какой же ты дурак!\""
    $ sename = "se人体_動作_起き上がる01"
    play se sedict[sename]
    pause (1000/1000)
    hide 絵演色黒
    with Dissolve(800.0/1000)
    $ St("C",300,0,30,"bu曽根美雪_私服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/a72/2200110a01.opus"

    mx "\"Я тебя поняла, хорошо? Я поняла тебя!\""
    $ St("C",300,0,30,"bu曽根美雪_私服_恋人_shy")
    with Dissolve(200.0/1000)
    voice "voice/a72/2200120a01.opus"

    mx "\"Я... я пойду надену её... П-просто жди меня здесь.\""
    $ St("C",300,0,30,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/a72/2200130a01.opus"

    mx "\"Понятно, х-хозяин?..\""
    stop bgm fadeout (4000/1000)
    $ EyeCatchIn(2000.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
