label e2316a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2316a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    voice "voice/e23/16a00010a01.opus"

    mx "\"...Как вкусно!\""

    xy "\"Да?\""
    voice "voice/e23/16a00020a01.opus"

    mx "\"Знаешь, что я думаю?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e23/16a00030a01.opus"

    mx "\"Мне кажется, этот десерт ты тоже сделал с любовью.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e23/16a00040a01.opus"

    mx "\"......Просто шучу.\""

    xy "\"Т-точно!\""

    xy "\"Нет, да, вполне... вероятно!\""

    "Отчаянно пытаясь скрыть своё смущение, я кивнул слишком восторженно."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(110.0/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
