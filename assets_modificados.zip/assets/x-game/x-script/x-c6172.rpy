label c6172_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6173.nss"
    return
label c6172:
    hide 絵色黒
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg080100_3_コンビニ外正面"]+".jpg")
    $ St("ML",300,0,0,"st曽根美雪_制服_通常_normal")
    $ St("MR",300,0,0,"st曙雄太郎_バイト_通常_hard")
    with Dissolve(0.0/1000)
    $ St("ML",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/c61/7200010a01.opus"

    mx "\"Аой выбросила свидание с тобой в мусорку, чтобы встретиться с другим парнем.\""

    "Миюки бросила холодную, суровую реальность мне в лицо."

    "Насколько бессмысленным это не было бы, я по-прежнему пытался спрятать свою голову в песок."

    xy "\"Наверное, они сейчас работают над сюрпризом к моему дню рождения! Ну, знаешь, небольшой и весёлый—\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
