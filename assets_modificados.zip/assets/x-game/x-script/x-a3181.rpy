label a3181_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010801_3_学校体育館消灯"]=True
    $ PreGameName = GameName
    $ GameName = "a3191.nss"
    return
label a3181:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010801_3_学校体育館消灯"]+".jpg")
    with Dissolve(3000.0/1000)
    $ st_timezone = "夜"
    $ sename = "se物体_ドア体育_開く02"
    play se sedict[sename]
    pause (2000/1000)
    voice "voice/a31/8100010a01.opus"
    mx "Аой, где же ты?"
    stop se fadeout (150.0/1000)
    show expression ("cg/bg/m/"+imagename["bg010801_3_学校体育館消灯_m"]+".jpg") as 絵背景弐 zorder 200 at truecenter
    show expression ("cg/bg/m/"+imagename["bg010801_3_学校体育館消灯_m"]+".jpg") as 絵背景 zorder 1001:
        xpos 0
        ycenter .5
        linear 20 xpos -200
    with Dissolve(800.0/1000)
    "Голос Миюки раздавался эхом и затухал во мраке."
    "В спортзале была кромешная тьма."
    "В такой час здесь обычно нет ни единой души."
    xy "Я знаю, что ты здесь, Аой!"
    play sound "voice/a31/8100430b04.opus"
    pause 1
    hide 絵背景
    with Dissolve(200.0/1000)
    voice "voice/a31/8100020a02.opus"
    aoi "Стой!"
    with Dissolve((500.0+0.0)/1000)
    xy "Ты слышала это?"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/8100030a01.opus"
    mx "Да, это определённо была она."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a31/8100040a01.opus"
    mx "Мы знаем, что ты здесь! Пожалуйста, поговори с нами!"
    pause (2000/1000)
    "...Тишина."
    "Аой ничего не ответила."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/8100050a01.opus"
    mx "Почему ты прячешься?"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_shout")
    with Dissolve(200.0/1000)
    voice "voice/a31/8100060a01.opus"
    mx "Давай, Аой, вылезай оттуда!"
    with Dissolve((500.0+1000.0)/1000)
    hide StC with Dissolve(0.0/1000)
    "Миюки кричала в темноту."
    "Но Аой не хотела отвечать."
    "Вместо этого, мы слышали..."
    voice "voice/a31/8100070a02.opus"
    aoi "...Хн-н..."
    "...приглушённые всхлипы."
    "Она плакала."
    voice "voice/a31/8100080a01.opus"
    mx "Аой, что-то не так?"
    voice "voice/a31/8100090a02.opus"
    aoi "Отстань!"
    voice "voice/a31/8100100a02.opus"
    aoi "Не... хн-н... приближайся..."
    voice "voice/a31/8100110a01.opus"
    mx "Почему ты плачешь?"
    voice "voice/a31/8100120a02.opus"
    aoi "Хн-н... н-н-н... н-н-н-н... А-Аой... ничего не может поделать с этим... потому что..."
    voice "voice/a31/8100130a02.opus"
    aoi "Аой... ослушалась!.."
    voice "voice/a31/8100140a01.opus"
    mx "Ты о чём?"
    voice "voice/a31/8100150a02.opus"
    aoi "Миюки... сказала мне не делать это, но... Аой... не могла перестать думать об этом..."
    voice "voice/a31/8100160a02.opus"
    aoi "Не могла... бросить котёнка... Хотела... стать героем..."
    voice "voice/a31/8100170a02.opus"
    aoi "Но теперь... Миюки... порвёт со мной связи... и перестанет дружить со мной..."
    "Ну, она точно грозилась так сделать..."

    with Dissolve((500.0+0.0)/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/8100180a01.opus"
    mx "Она именно поэтому и не хочет выходить?.."
    xy "Наверное."
    xy "Она уже однажды выбрала тебя, а не котёнка."
    $ St("C",300,0,0,"st曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/8100190a01.opus"
    mx "......"
    xy "Давай, Миюки."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/8100200a01.opus"
    mx "Я всё поняла, ладно?!"
    "Миюки раздражённо вздохнула."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb08",channel = "bgm", if_changed = True)
    voice "voice/a31/8100210a01.opus"
    mx "Я забираю слова назад, ладно? Я забираю все те свои слова назад!"
    voice "voice/a31/8100220a02.opus"
    aoi "Хн-н... н-н-н... Ты... забираешь свои слова назад?.."
    voice "voice/a31/8100230a01.opus"
    mx "Я не хочу разрывать с тобой связи! Я хочу остаться друзьями! А теперь, пожалуйста, выйди наружу и поговори с нами, Аой!"
    voice "voice/a31/8100240a02.opus"
    aoi "Ты... ты уверена, что не разорвёшь со мной связи?"
    "Сомневающийся голос Аой прошёл сквозь тьму."
    voice "voice/a31/8100250a02.opus"
    aoi "Ты обещаешь, что заберёшь те свои слова назад?"
    voice "voice/a31/8100260a01.opus"
    mx "А зачем мне ещё идти искать тебя посреди ночи, особенно когда на улице льёт как из ведра?"
    voice "voice/a31/8100270a01.opus"
    mx "Я бы не стала это делать, если бы не переживала за тебя. Это же очевидно."
    voice "voice/a31/8100280a02.opus"
    aoi "Ты серьёзно?.."
    voice "voice/a31/8100290a01.opus"
    mx "Я бы не стала врать тебе о чём-то подобном."
    voice "voice/a31/8100300a01.opus"
    mx "В смысле, мы ведь друзья, так ведь?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    with Dissolve((500.0+1000.0)/1000)
    voice "voice/a31/8100310a02.opus"
    aoi "С... С..."
    voice "voice/a31/8100320a02.opus"
    aoi "Спасибо тебе большое!"
    $ sename = "se擬音_コミカル_歩く"
    play se sedict[sename]
    "Аой выбежала из мрака..."
    $ sename = "se擬音_コミカル_ヒョコ"
    play se sedict[sename]
    $ St("C",1300,0,0,"st向日アオイ電波_着ぐるみ_通常_pain")
    with Dissolve(200.0/1000)
    pause (500/1000)
    voice "voice/a31/8100330a01.opus"
    mx "Мамочка-кошка?!"
    "...в надетой кошачьей пижаме."
    $ St("C",1300,0,0,"st向日アオイ電波_着ぐるみ_密着_happy")
    with Dissolve(200.0/1000)
    voice "voice/a31/8100340a02.opus"
    aoi "Миюки! Ты лучшая!"
    $ sename = "se擬音_コミカル_走る"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    hide 絵背景
    hide 絵背景弐
    with Dissolve(500.0/1000)
    pause (300/1000)
    stop se fadeout (1000.0/1000)
    $ sename = "se人体_動作_抱きつく02"
    play se sedict[sename]
    pause (500/1000)
    voice "voice/a31/8100350a01.opus"
    mx "С... Спасибо. Я просто рада, что с тобой всё хорошо."
    "Я мог расслышать маленький писк в голосе Миюки, когда Аой набросилась на неё и начала обнимать, из-за чего они чуть было не упали на пол."

    xy "Стоп... а где котёнок?"
    show expression ("cg/bg/m/"+imagename["bg010801_3_学校体育館消灯_m"]+".jpg") as 絵背景 zorder 100 at truecenter
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"bu向日アオイ電波_着ぐるみ_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/8100360a02.opus"
    aoi "Он рядом со мной."
    voice "voice/a31/8100370a02.opus"
    aoi "Иди сюда, Иру."
    $ sename = "se人体_動作_衣擦れ02"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    "Словно по команде, котёнок высунул свою голову из нагрудного кармана пижамы."
    "Господи, уровень милоты просто зашкаливает... Они даже заставили меня улыбаться."
    hide 絵背景
    with Dissolve(500.0/1000)
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_gag")
    voice "voice/a31/8100390a01.opus"
    mx "Я... я умру счастливой..."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_normal")
    voice "voice/a31/8100400a02.opus"
    aoi "Буп-буп! Миюки?!"
    hide StMR with Dissolve(200.0/1000)
    $ sename = "se人体_衝撃_転倒01"
    $ renpy.vibrate(0.5)
    play se sedict[sename]
    "Миюки упала на пол с мечтательной улыбкой на лице."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (2000/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    hide 絵色黒
    with Dissolve(2000.0/1000)
    pause (300/1000)
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_sad")
    voice "voice/a31/8100410a02.opus"
    aoi "Миюки... Аой очень жаль..."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_shout")
    voice "voice/a31/8100420a02.opus"
    aoi "Иру тоже извиняется."
    play sound "voice/a31/8100430b04.opus"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_fear")
    voice "voice/a31/8100440a01.opus"
    mx "Хватит! Я поняла! Это уже слишком! Просто остановись!"
    voice "voice/a31/8100450a01.opus"
    mx "Не приближайся! Мы ведь не хотим, чтобы то, что случилось в прошлый раз, повторилось!"
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_normal")
    voice "voice/a31/8100460a02.opus"
    aoi "Но Иру хочет тебя обнять!"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_angry")
    voice "voice/a31/8100470a01.opus"
    mx "Обнять меня?! Ну... думаю, если мне придётся!.."
    xy "А как же повторение того, что случилось в прошлый раз?!"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_shout")
    voice "voice/a31/8100480a01.opus"
    mx "История всегда будет повторяться, вне зависимости от обстоятельств! Шиничи, у тебя есть маска?"
    xy "А зачем мне она?"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_angry")
    voice "voice/a31/8100490a01.opus"
    mx "А почему бы и НЕТ?!"
    xy "Не кричи на меня!"
    "Когда дело доходит до кошек, я могу на полном серьёзе сказать, что эта девушка перестаёт ясно мыслить..."
    xy "И Аой, не раззадоривай её! Почему ты вообще это надела?!"
    voice "voice/a31/8100500a02.opus"
    aoi "Ну, моя одежда промокла насквозь."
    xy "А что произошло с тем зонтом, который я дал тебе?"
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_think")
    voice "voice/a31/8100510a02.opus"
    aoi "Ой!"
    "Да уж, она совсем забыла про него..."
    "И я почему-то даже не удивлён..."
    stop bgm fadeout (4000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
