label e2171_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2171:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/7100010a01.opus"

    mx "\"Извини, что притащила тебя сюда.\""

    xy "\"Да не, всё нормально.\""

    "Сделав свои покупки, мы встретились возле книжного магазина."

    xy "\"Я всё равно хотел купить одну книгу.\""
    voice "voice/e21/7100020a01.opus"

    mx "\"И что ты взял?\""
    $ sename = "se物体_紙_探る"
    play se sedict[sename]

    "Я сунул руку в свой пакет и достал оттуда—"
    if persistent.eternal_day:
        $ persistent.cook_book = True;
        $ persistent.count_cook_book += 1
        if (persistent.count_cook_book == 1):
            $ GameName = "e2172a.nss";
        elif (persistent.count_cook_book == 2):
            $ GameName = "e2172c.nss";
        elif (persistent.count_cook_book == 3):
            $ GameName = "e2172d.nss";
        elif (persistent.count_cook_book == 4):
            $ GameName = "e2172e.nss";
        elif (persistent.count_cook_book == 5):
            $ GameName = "e2172f.nss";
        elif (persistent.count_cook_book == 6):
            $ GameName = "e2172g.nss";
        elif (persistent.count_cook_book == 7):
            $ GameName = "e2172h.nss";
        elif (persistent.count_cook_book > 7):
            $ GameName = "e2172i.nss";
    else:
        menu:
            "Кулинария-101":
                $ SetChoiceSelect = 0
            "Руководство для владельца котов":
                $ SetChoiceSelect = 1
        if SetChoiceSelect==0:
            $ persistent.miyuki_love += 1
            $ persistent.cook_book = True;
            $ persistent.count_cook_book  += 1
            if (persistent.count_cook_book == 1):
                $ GameName = "e2172a.nss";
            elif (persistent.count_cook_book == 2):
                $ GameName = "e2172c.nss";
            elif (persistent.count_cook_book == 3):
                $ GameName = "e2172d.nss";
            elif (persistent.count_cook_book == 4):
                $ GameName = "e2172e.nss";
            elif (persistent.count_cook_book == 5):
                $ GameName = "e2172f.nss";
            elif (persistent.count_cook_book == 6):
                $ GameName = "e2172g.nss";
            elif (persistent.count_cook_book == 7):
                $ GameName = "e2172h.nss";
            elif (persistent.count_cook_book > 7):
                $ GameName = "e2172i.nss";
        elif SetChoiceSelect==1:
            $ persistent.miyuki_love -= 1
            $ GameName = "e2172b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
