label a3224_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5111.nss"
    return
label a3224:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg040300_3_街商店街"]+".jpg")
    with Dissolve(1000.0/1000)
    pause (500/1000)
    "Шаг за шагом, мы медленно шли по тёмному городу, но вскоре мы пришли к манга-кафе."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a32/2400010a02.opus"
    aoi "Шиничи, спасибо."
    "Аой спрыгнула с моей спины."
    xy "Ты уверена, что тебе не надо в больницу?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a32/2400020a02.opus"
    aoi "Зеппи перезарядил мои батареи."
    voice "voice/a32/2400030a02.opus"
    aoi "И всё благодаря сценке события."
    "О какой ещё сценке она говорит?"
    "Но хорошая новость в том, что она уже не испытывала такое сильное головокружение, как тогда, когда мы были около моего дома."
    xy "Побольше отдыхай, слышишь меня?"
    xy "Я присмотрю за Иру."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a32/2400040a02.opus"
    aoi "Хорошо."
    $ sename = "se人体_動作_衣擦れ01"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    "Аой помахала мне рукой."
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_smile")
    with Dissolve(200.0/1000)
    voice "voice/a32/2400050a02.opus"
    aoi "Пока-пока."
    xy "Спокойной ночи."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "После этого она медленно скрылась в кафе."
    "Я наблюдал то, как она уходила, пока двери лифта не закрылись."
    stop se fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒
    with Dissolve((1000.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    with Dissolve(1000.0/1000)
    $ renpy.music.play("ttb06",channel = "bgm", if_changed = True)
    pause (500/1000)
    "Оглядываясь назад, это был адский день."
    "Мне всё ещё надо было разобраться с некоторыми вещами."
    "Но..."
    play voc "a31/52a00040b04"
    xy "Привет, дружочек. Не хочешь поспать у меня на кровати?"
    show expression ("cg/ef/"+imagename["efbg自宅自室天井消灯"]+".jpg") as 絵演背景 zorder 1010 at truecenter
    $ sename = "se人体_動作_座るソファー"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    pause (300/1000)
    "Мы с Иру ускользнули под одеяло."
    "Я мог почувствовать, как усталость утяжеляла каждый сантиметр моего тела."
    "Я очень сильно устал, чтобы думать сейчас о чём-либо."
    stop bgm fadeout (3000.0/1000)
    pause (2000/1000)
    "И всё же в сон меня почему-то не клонило."
    $ EyeCatchIn(0.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
