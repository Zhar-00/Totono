label e2205b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2206.nss"
    return
label e2205b:
    hide 絵色黒
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e22/05a00030b02.opus"

    kmsm "\"МИЮКИ РАЗРАБОТАЛА НАРКОТИК, КОТОРЫЙ МОЖЕТ ПОДАВЛЯТЬ ВОСПРИЯТИЕ РЕАЛЬНОСТИ.\""
    voice "voice/e22/05b00010b02.opus"

    kmsm "\"ОН ЛЕЖИТ В МАЛЕНЬКОМ БУМАЖНОМ ПАКЕТЕ И БЫЛ ДОБАВЛЕН В ЕДУ, ИЗ-ЗА ЧЕГО ТЫ НЕСПОСОБЕН ОТЛИЧИТЬ ФАКТЫ ОТ ВЫМЫСЛА.\""
    voice "voice/e22/05b00020b02.opus"

    kmsm "\"НО ЭТА ВСЕЛЕННАЯ УЖЕ БЫЛА ИЗМЕНЕНА.\""
    voice "voice/e22/05b00030b02.opus"

    kmsm "\"СУЩЕСТВОВАНИЕ АОЙ БЫЛО ПОЧТИ ПОЛНОСТЬЮ СТЁРТО.\""

    xy "\"Кого... Что?..\""

    "О ком она говорит?"

    "Я не знаю никакую Аой..."
    voice "voice/e22/05b00040b02.opus"

    kmsm "\"ФРАГМЕНТ ЕЁ СОЗНАНИЯ ПРОДОЛЖАЕТ ЖИТЬ В ФОРМЕ ЭЛЕКТРОМАГНИТНЫХ ВОЛН.\""
    voice "voice/e22/05b00050b02.opus"

    kmsm "\"НО АОЙ ДОЛЖНА БЫТЬ ВОЗВРАЩЕНА, ЧТОБЫ ИНИЦИИРОВАТЬ ОТКАТ ДЛЯ ЭТОЙ ВСЕЛЕННОЙ.\""


    "О чём эта дама, чёрт побери, болтает?"
    "Она, должно быть, высокого о себе мнения, раз называет себя Богом..."
    voice "voice/e22/05b00060b02.opus"

    kmsm "\"Её... номер?..\""

    xy "\"МЫ ПРОСИМ СУБЪЕКТА НАЙТИ ЕЁ НОМЕР.\""
    voice "voice/e22/05b00070b02.opus"
    kmsm "\"ОТВЕТ ПОЛОЖИТЕЛЬНЫЙ.\""
    voice "voice/e22/05b00080b02.opus"

    kmsm "\"ЕСТЬ ОДНА КОМБИНАЦИЯ ИЗ ЦИФР, КОТОРАЯ МОЖЕТ ВОССТАНОВИТЬ ЕЁ—\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
