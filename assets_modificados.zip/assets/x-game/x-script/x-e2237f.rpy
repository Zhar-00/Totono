label e2237f_MAIN:
    call expression GameName
    $ persistent.imagelog["eve2237a美雪さん立ちバックf"]=True
    $ PreGameName = GameName
    $ GameName = "e2237g.nss"
    return
label e2237f:
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    show expression ("cg/ev/"+imagename["eve2237a美雪さん立ちバックc"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    show expression Solid("FFFFFF") as 絵演色白
    pause (16/1000)
    hide 絵演色白
    with Dissolve(150.0/1000)
    pause (50/1000)
    show expression Solid("FFFFFF") as 絵演色白
    pause (16/1000)
    hide 絵演色白
    with Dissolve(150.0/1000)
    pause (200/1000)
    show expression Solid("FFFFFF") as 絵演色白 zorder 5000
    with Dissolve((200.0+800.0)/1000)
    with Dissolve((250.0+1000.0)/1000)
    pause (500/1000)
    hide 絵絶頂板
    show expression ("cg/ev/"+imagename["eve2237a美雪さん立ちバックf"]+".jpg") as 絵専 zorder 1100 at truecenter
    hide 絵演色白
    with Dissolve(1500.0/1000)
    pause (1000/1000)
    voice "voice/e22/37f00010a01.opus"

    mx "\"Н-н-нг-гх-х... н-нха-а-а-а... н-нха-а... н-н-н-н... н-н-н!.. Н-н-н... н-н-нг... н-нха-а... а-а-а-ах! А-ах!\""
    voice "voice/e22/37f00020a01.opus"

    mx "\"Я чувствую это... Хн-н-н! Н-н-н... ТВОЯ... горячая сперма... выплёскивается... на меня... Н-нха-а-а!!!\""
    voice "voice/e22/37f00030a01.opus"

    mx "\"А-а-а-ах! Ты кончаешь... так сильно... Н-н-нг-гх... н-н-н... н-н... н-н-н-нг... н-н-н...\""

    "Миюки радостно улыбалась, всё её тело извивалось."

    "С каждой каплей, которая попадала на неё, её задница напрягалась."

    "Я расплескал по всей её задней части всё то, что было в моих яичках."
    voice "voice/e22/37f00040a01.opus"

    mx "\"Н-н-н-нг... Ого... Ты много кончил... И ты всё не перестаёшь...\""
    voice "voice/e22/37f00050a01.opus"

    mx "\"Хе-хе-хе... Это, наверное, означает... н-н-нг... моя киска... наверное, доставила тебе неземное удовольствие...\""
    voice "voice/e22/37f00060a01.opus"

    mx "\"А-ах... н-н-н... я чувствую, как она... течёт...\""
    stop bgm fadeout (3000.0/1000)

    "Сперма стекала вниз по её мягким изгибам."
    xy "\"Ох...\""

    "Как только я всё выплеснул, я пришёл в чувства."

    xy "\"Э-эм... Прости, Миюки...\""
    voice "voice/e22/37f00070a01.opus"

    mx "\"За что ты извиняешься?..\""
    hide 絵専
    with Dissolve(500.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
