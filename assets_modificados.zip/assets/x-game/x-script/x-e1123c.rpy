label e1123c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1124.nss"
    return
label e1123c:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(0.0/1000)
    voice "voice/e11/23c00010a01.opus"

    mx "\"...Это был вопрос, который я задала тебе.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/23c00020a01.opus"

    mx "\"Но ты дал мне совершенно противоречивый ответ.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/e11/23c00030a01.opus"

    mx "\"Ты помнишь это, верно?\""

    xy "\"Разве?..\""

    "О чём она вообще говорит?"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
