label a2121_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a2131.nss"
    return
label a2121:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve(1000.0/1000)
    show expression ("cg/bg/l/"+imagename["bg010100_1_学校階段_l"]+".jpg") as 絵背景:
        xanchor .5
        xpos .5
        ypos -170
    with Dissolve(1000.0/1000)
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    pause (5000/1000)
    pause (500/1000)
    stop se fadeout (10000.0/1000)
    "Во время обеда..."
    $ sename = "se物体_ドア屋上_鍵開ける01"
    play se sedict[sename]
    pause (600/1000)
    show expression Solid("FFFFFF") as 絵色白
    with Dissolve((800.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg") behind 絵色白
    pause (500/1000)
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    hide 絵背景
    hide 絵色白
    with Dissolve(1600.0/1000)
    pause (500/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/a21/2100010a02.opus"
    aoi "Снаружи так тепло и приятно."
    $ sename = "se人体_足音_歩くアオイL"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    stop se fadeout (4000.0/1000)
    pause (500/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/a21/2100020a01.opus"
    mx "...Я согласилась помочь тебе с домашкой, не более. Я, безусловно, не помню, как соглашалась пообедать с тобой."
    xy "Да ладно, не веди себя так."
    "И вот мы здесь, стояли на крыше со своей едой."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a21/2100030a01.opus"
    mx "Как мы будем здесь заниматься?"
    xy "А ты предпочитаешь делать это в классе? Со мной и ней? Перед всеми?"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/2100040a01.opus"
    mx "......"
    "Миюки привлекала к себе достаточно внимания одним лишь разговором с Аой."
    "И если бы меня добавили в эту гремучую смесь, завтра утром однозначно прошлись бы слухи."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/2100050a01.opus"
    mx "Мне здесь не очень нравится."
    xy "Это место напоминает тебе о том, как ты призналась мне в своей ложной любви, да?"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_angry")
    with Dissolve(200.0/1000)
    voice "voice/a21/2100060a01.opus"
    mx "......?! Т-ты должен забыть о том, что это вообще происходило!"
    voice "voice/a21/2100070a01.opus"
    mx "Я сделала это лишь потому, что Муко-сан вела себя так—"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a21/2100080a01.opus"
    mx "...Стоп, что за? Где она?"
    xy "Вон там."
    voice "voice/a21/2100090a02.opus"
    aoi "Буп-буп..."
    "Аой стояла на крыше и смотрела на горизонт."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/a21/2100100a01.opus"
    mx "Что она делает?"
    xy "Наверное, ты должна подняться туда и выяснить это."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/a21/2100110a01.opus"
    mx "Дым поднимется, и дураки полезут за ним ввысь, как говорится."
    xy "Хватит уже пословиц. Пошли."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se人体_動作_梯子のぼる一歩"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 2000
    with Dissolve((500.0+1000.0)/1000)
    "Миюки неохотно приложила руку к первой ступеньке лестницы."
    voice "voice/a21/2100120a01.opus"
    mx "Не смей подглядывать."
    xy "И не собирался!"
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]
    pause (1000/1000)
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    "Я отвёл свой взгляд и поднялся следом за ней."
    show expression ("cg/bg/l/"+imagename["bg900200_1_雰囲気街並み_l"]+".jpg") as 絵演背景:
        pos (0,-150)
        linear 90 xpos -1024
    stop se fadeout (2000.0/1000)
    stop se fadeout (150.0/1000)
    pause (500/1000)
    hide 絵色黒
    with Dissolve(150.0/1000)
    $ renpy.music.play("ttb11",channel = "bgm", if_changed = True)
    pause (300/1000)
    hide 絵色白
    with Dissolve(2000.0/1000)
    voice "voice/a21/2100130a01.opus"
    mx "......"
    "Как только Миюки поднялась наверх, она тут же была очарована видом."
    "Я вовсе не виню её за это."
    "Я видел его далеко не в первый раз, но от него у меня всё так же перехватывало дыхание."
    hide 絵演背景
    with Dissolve(800.0/1000)
    xy "Довольно здорово, да?"
    $ St("ML",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/a21/2100140a01.opus"
    mx "Он не похож на всё то, что я когда-либо видела!.."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"st向日アオイ電波_制服_見上げ_think")
    voice "voice/a21/2100150a02.opus"
    aoi "Это особенное место."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"st曽根美雪_制服_腕組み_sad")
    voice "voice/a21/2100160a01.opus"
    mx "...Прости. Я должна извиниться за то, что смеялась над тобой."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a21/2100170a02.opus"
    aoi "Буп-буп?"
    voice "voice/a21/2100180a02.opus"
    aoi "А когда это было?"
    "Старая-добрая Аой."
    $ sename = "se人体_擬音_空腹音"
    play se sedict[sename]
    pause (500/1000)
    $ St("MR",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a21/2100190a02.opus"
    aoi "Аой проголодалась. Пора есть."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a21/2100200a01.opus"
    mx "Хм... Хорошее решение."
    $ sename = "se人体_動作_衣擦れ濡れ場03"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Сейчас явно нет времени на то, чтобы погружаться в свои мысли."
    "Мы начали распаковывать свои обеды."
    show expression ("cg/bg/l/"+imagename["bg010300_1_学校屋根_l"]+".jpg") as 絵背景:
        xalign .5
        ypos -300
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_normal")
    with Dissolve(500.0/1000)
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_shout")
    voice "voice/a21/2100210a02.opus"
    aoi "Пора перекусить!"
    hide StC
    hide StR
    hide StL
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("L",300,10,0,"bu曽根美雪_制服_腕組み_shout")
    voice "voice/a21/2100220a01.opus"
    mx "Погоди!"
    $ St("L",300,10,0,"bu曽根美雪_制服_腕組み_sad")
    voice "voice/a21/2100230a01.opus"
    mx "Что, позволь спросить, это ТАКОЕ?"
    hide StC
    hide StMR
    hide StML
    hide StR
    hide StL
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/2100240a02.opus"
    aoi "Коала Манч."
    voice "voice/a21/2100250a01.opus"
    mx "А ЭТО?"
    voice "voice/a21/2100260a02.opus"
    aoi "Пирожки в виде кроличьего ушка."
    voice "voice/a21/2100270a01.opus"
    mx "А ЭТО?"
    voice "voice/a21/2100280a02.opus"
    aoi "Грибные монстры."
    xy "С небольшим добавлением шоколада, да?"
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/2100290a02.opus"
    aoi "А что насчёт тебя?"
    xy "Кого, меня? Так, посмотрим... у меня есть бутерброд с картофельным салатом, джамбо-крокет, пара засахаренных бататов..."
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/2100300a02.opus"
    aoi "Слишком много картофеля."
    xy "Ты права! Но я ничего не могу с этим поделать. Картошка – лучшая."
    voice "voice/a21/2100310a02.opus"
    aoi "Аой правда нравится шоколад."
    hide StC
    hide StMR
    hide StML
    hide StR
    hide StL
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("L",300,10,0,"bu曽根美雪_制服_通常_sigh")
    voice "voice/a21/2100320a01.opus"
    mx "Но ты должна есть его в меру!"
    voice "voice/a21/2100330a02.opus"
    aoi "Не волнуйся."
    $ sename = "se物体_缶_置く"
    play se sedict[sename]
    show expression ("cg/ef/"+imagename["efbgヤバトマ"]+".jpg") as 絵画像 zorder 1000 at center
    with Dissolve((300.0+1000.0)/1000)
    pause (300/1000)
    voice "voice/a21/2100340a02.opus"
    aoi "У Аой есть Ябалей!"
    voice "voice/a21/2100350a01.opus"
    mx "Томатный сок?.."
    hide 絵画像
    with Dissolve(500.0/1000)
    voice "voice/a21/2100360a02.opus"
    aoi "Проблема решена."
    $ St("L",300,10,0,"bu曽根美雪_制服_通常_pride")
    voice "voice/a21/2100370a01.opus"
    mx "От одного вида таких блюд у меня скручивает живот."
    voice "voice/a21/2100380a02.opus"
    aoi "Миюки, не хочешь попробовать?"
    $ St("L",300,10,0,"bu曽根美雪_制服_腕組み_normal")
    voice "voice/a21/2100390a01.opus"
    mx "Нет, спасибо."
    voice "voice/a21/2100400a02.opus"
    aoi "Но это вкусно."
    hide StC
    hide StMR
    hide StML
    hide StR
    hide StL
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_shout")
    voice "voice/a21/2100410a02.opus"
    aoi "Оно заводит тебя и перезаряжает твои батареи."
    hide StC
    hide StMR
    hide StML
    hide StR
    hide StL
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("L",300,10,0,"bu曽根美雪_制服_腕組み_sad")
    $ St("L",300,10,0,"bu曽根美雪_制服_腕組み_normal")
    voice "voice/a21/2100420a01.opus"
    mx "Я сказала нет, спасибо! И вообще, у меня вот здесь есть очень хороший обед! Видишь?"
    $ sename = "se人体_動作_ポケット探る"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    hide StR
    hide StL
    with Dissolve(200.0/1000)
    pause (500/1000)
    "Миюки открыла крышку своего упакованного обеда, чтобы показать это..."
    xy "Воу..."
    voice "voice/a21/2100430a02.opus"
    aoi "Осьминожьи хот-доги!"
    voice "voice/a21/2100440a02.opus"
    aoi "Яблочные кролики!"
    voice "voice/a21/2100450a02.opus"
    aoi "Она лучшая подруга детства..."
    $ St("L",300,10,0,"bu曽根美雪_制服_通常_pride")
    voice "voice/a21/2100460a01.opus"
    mx "Да ладно. Именно так и должен выглядеть НОРМАЛЬНЫЙ обед. Вы двое должны привести себя в порядок."
    xy "Ты всё это приготовила сама, да?"
    $ St("L",300,10,0,"bu曽根美雪_制服_通常_normal")
    voice "voice/a21/2100470a01.opus"
    mx "Конечно."
    voice "voice/a21/2100480a02.opus"
    aoi "Буп-буп... Еда Миюки такая милая..."
    $ St("L",300,10,0,"bu曽根美雪_制服_通常_angry")
    voice "voice/a21/2100490a01.opus"
    mx "И-и что?! Что плохого в добавлении милых вещей в мой обед?!"
    "Щёки Миюки залились краской."
    xy "......"
    voice "voice/a21/2100500a02.opus"
    aoi "......"
    $ St("L",300,10,0,"bu曽根美雪_制服_腕組み_sad")
    voice "voice/a21/2100510a01.opus"
    mx "Ч-что с вами такое?"
    xy "Поправь меня, если ошибаюсь, но... тебя до этого не называли милой, так ведь?"
    $ St("L",300,10,0,"bu曽根美雪_制服_腕組み_angry")
    voice "voice/a21/2100520a01.opus"
    mx "В-возможно! Но ты сам виноват в том, что—"
    voice "voice/a21/2100530a02.opus"
    aoi "Миюки такая милая, когда смущается."
    $ St("L",300,10,0,"bu曽根美雪_制服_通常_angry")
    voice "voice/a21/2100540a01.opus"
    mx "П-перестань смеяться надо мной!"
    xy "И когда зли—"
    $ St("L",300,10,0,"bu曽根美雪_制服_通常_pride")
    voice "voice/a21/2100550a01.opus"
    mx "Ладно, теперь ты перегибаешь палку."
    xy "И-извини."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    pause (500/1000)
    hide StC
    hide StMR
    hide StML
    hide StR
    hide StL
    with Dissolve(0.0/1000)
    hide 絵色黒
    with Dissolve(500.0/1000)
    voice "voice/a21/2100560a02ex.opus"
    bm "Налетаем, народ.\" \"Звучит отлично.\" \"Ура, еда!"
    voice "voice/a21/2100580a02.opus"
    aoi "Ням-ням... ням-ням-ням..."
    voice "voice/a21/2100590a02.opus"
    aoi "Буп-буп?.."
    xy "Что-то не так, Аой?"
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/2100600a02.opus"
    aoi "...Это странно."
    voice "voice/a21/2100610a02.opus"
    aoi "У него другой вкус."
    voice "voice/a21/2100620a01.opus"
    mx "У него срок годности кончился или что?"
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/2100630a02.opus"
    aoi "Нет..."
    voice "voice/a21/2100640a02.opus"
    aoi "На этот раз он ещё вкуснее."
    voice "voice/a21/2100650a01.opus"
    mx "Что? Этого попросту не может—"
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/2100660a02.opus"
    aoi "Может! Очень даже может быть!"
    "Тон голоса Аой был на удивление уверенным."
    xy "Возможно потому, что ты ешь его вместе со своими друзьями."
    voice "voice/a21/2100670a01.opus"
    mx "Во множественном числе? Чтоб ты знал, я на это не соглашалась."
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_sad")
    voice "voice/a21/2100680a02.opus"
    aoi "...Да..."
    "Аой печально опустила голову."
    "Боже... и это именно тогда, когда я подумал, что всё шло хорошо..."
    xy "Да брось, Миюки—"
    voice "voice/a21/2100690a01.opus"
    mx "Л-ладно! Не важно!"
    "Миюки ёрзала на месте."
    hide StC
    hide StMR
    hide StML
    hide StR
    hide StL
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("L",300,10,0,"bu曽根美雪_制服_腕組み_normal")
    voice "voice/a21/2100700a01.opus"
    mx "...Наверное..."
    $ St("L",300,10,0,"bu曽根美雪_制服_腕組み_smile")
    voice "voice/a21/2100710a01.opus"
    mx "В смысле, вид здесь и правда очень особенный. Может, он придаёт красок твоей еде, ну, понимаешь?"
    hide StC
    hide StMR
    hide StML
    hide StR
    hide StL
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_normal")
    voice "voice/a21/2100720a02.opus"
    aoi "Правда?"
    voice "voice/a21/2100730a01.opus"
    mx "Самую малость."
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/2100740a02.opus"
    aoi "А что насчёт тебя, Шиничи?"
    xy "Вкуснятина, пять баллов."
    $ St("R",300,-10,0,"bu向日アオイ電波_制服_通常_normal")
    "Должен признать, мне всё так же было немного неловко."
    "Наверное, пока ещё рано называть это «дружбой»."
    "Но это был только первый шаг... а для Аой этот шаг был самым большим."
    stop bgm fadeout (3000.0/1000)
    stop se fadeout (3000.0/1000)
    $ EyeCatchIn(2000.0)
    show expression Solid("FFFFFF") as 絵色白 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
