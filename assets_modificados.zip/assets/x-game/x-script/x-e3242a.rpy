label e3242a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1111.nss"
    return
label e3242a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110301_3_マンション寝室消灯"]+".jpg")
    $ st_timezone = "夜"
    $ St("C",300,0,0,"fu曽根美雪_私服_病み_smile")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"fu曽根美雪_私服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e32/42a00010a01.opus"

    mx "Хорошо."
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e32/42a00020a01.opus"

    mx "Я буду хорошо заботиться о ТЕБЕ, так что будь со мной, ладно?"
    voice "voice/e32/42a00030a01.opus"

    mx "Мы будем жить здесь, в этом мире, во веки веков."
    pause (1000/1000)
    $ persistent.aoi_peace = True;
    show expression Solid("000000") as 絵色黒
    pause (16/1000)
    hide 上背景
    pause (1500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
