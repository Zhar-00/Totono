label c3221_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c4111.nss"
    return
label c3221:
    show expression Solid("000000") as 絵色黒
    scene expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ sename = "se物体_ドア室内_閉まる01"
    play se sedict[sename]
    hide 上背景
    hide 絵色黒
    with Dissolve(500.0/1000)
    $ renpy.music.play("ttb06",channel = "bgm", if_changed = True)

    xy "\"Ха-а... ха-а... ха-а...\""

    "Я не могу дышать."

    "Моё сердце колотилось как сумасшедшее."

    "...Наверное, это от того, что я бежал по лестнице."

    "Мы просто друзья..."

    "...по крайней мере, я так думаю..."

    "...я ведь прав?"

    "Так почему я всё ещё чувствую её дыхание на своей коже?"

    "Всякий раз, когда я закрывал свои глаза, я видел её розоватые щёки..."

    "Воспоминания об этом заставляли мой пульс учащаться вновь."

    "Между нами ничего не изменилось..."

    "...и всё же всё казалось совершенно другим."

    "Получается?.."
    $ sename = "se物体_照明_スイッチ"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    with Dissolve(500.0/1000)
    pause (500/1000)

    xy "\"...Успокойся, приятель.\""
    $ sename = "se人体_動作_座るソファー"
    play se sedict[sename]
    show expression ("cg/ef/"+imagename["efbg自宅自室天井消灯"]+".jpg") as 絵背景 zorder 15 at truecenter
    with Dissolve(500.0/1000)
    pause (500/1000)

    "Если я буду зацикливаться на этом, то я этим только всё усложню."

    "Прямо сейчас, у меня была более насущная проблема: разногласия между Миюки и Аой."

    "Думаю, они встретятся завтра в школе."

    "И как я объясню сегодняшние события Миюки?"

    "Мне нужно придумать какой-то способ помочь им восстановить их дружбу..."

    "И с этим, я поспешно вернул свой ход мыслей в правильное русло, пока он не пошёл под откос окончательно."
    stop bgm fadeout (3000/1000)
    $ EyeCatchIn(2000.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
