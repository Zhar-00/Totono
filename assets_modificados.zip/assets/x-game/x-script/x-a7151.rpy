label a7151_MAIN:
    call expression GameName
    $ persistent.imagelog["evc7141美雪ハッピーバースデーc"]=True
    $ PreGameName = GameName
    $ GameName = "a7161.nss"
    return
label a7151:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    scene expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg") with dissolve
    hide 上背景

    "Дни пролетали незаметно."

    "С Миюки на моей стороне, я чувствовал себя полноценным."

    "Вы знаете, я бы никогда не подумал, что всё обернётся таким образом."

    "Иногда у меня было такое чувство, будто это всё сон..."
    stop bgm fadeout (1000/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    xy "......"

    "Но чего-то не хватает."

    "Что-то здесь не так..."

    "Но что?"
    $ sename = "se物体_インターホン_鳴る"
    play se sedict[sename]
    pause (500/1000)
    xy "\"Кого принесло сюда в такой час?..\""
    $ sename = "se物体_インターホン_鳴る連打"
    play se sedict[sename]

    xy "Успокойся! Я тебя с первого раза услышал!"
    show expression ("cg/bg/"+imagename["bg030200_3_自宅玄関"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    stop se fadeout (150.0/1000)
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]
    pause (500/1000)
    show expression ("cg/ev/"+imagename["evc7141美雪ハッピーバースデーc"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")

    xy "Миюки? Это... это букет?"
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    $ renpy.music.play("ttb16",channel = "bgm", if_changed = True)
    voice "voice/a71/5100010a01.opus"
    mx "\"С днём рождения!\""
    xy "\"...А, точно.\""
    xy "Спасибо.."
    voice "voice/a71/5100020a01.opus"
    mx "......"
    hide 絵専
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_sad")
    with Dissolve(800.0/1000)
    voice "voice/a71/5100030a01.opus"
    mx "\"Что это за неловкое молчание?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/a71/5100040a01.opus"
    mx "\"Ты забыл, когда у тебя день рождения?\""
    xy "\"Ха-ха-ха-ха-ха...\""

    "Ну конечно!"
    xy "\"Да, легко потерять счёт времени, когда я сам по себе.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/a71/5100050a01.opus"
    mx "\"Тогда мне лучше быть рядом, м-м?\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/a71/5100060a01.opus"
    mx "\"Вот, давай устроим небольшую вечеринку!\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "После этого, она вошла внутрь с большой коробкой."
    show expression Solid("000000") as 絵演色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
