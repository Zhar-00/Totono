label a0001_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ persistent.imagelog["bg010100_2_学校階段"]=True
    $ GameName = "a0111.nss"
    if persistent.c_route == True and persistent.e_route_first == False:
        $ persistent.meta_date += 1
    return
label a0001:
    $ tz(2)
    queue bgm "ttb27"
    image bg black = Solid("000000")
    scene bg black with fade
    image bg onbg bg010100_2 学校階段 = "cg/bg/"+imagename["bg010100_2_学校階段"]+".jpg"
    scene bg onbg bg010100_2 学校階段 zorder 10
    $ sename = sedict["se人体_足音_階段学校上がる01"]
    play se sename
    $ nextimage = "cg/bg/l/"+imagename["bg010100_2_学校階段_l"]+".jpg"
    scene expression nextimage as 絵背景 zorder 10:
        anchor (0,0)
        pos (-768,-576)
        linear 20 xpos -1024
    with Fade(0,0,4)
    "Жизнь – словно лестница."
    "Ты просто должен продолжать подниматься вверх."
    "Иначе, если ты начнёшь задумываться, тебе будет трудно сделать следующий шаг."
    scene expression nextimage as 絵背景 zorder 10 with Fade(1.5,1,1.5):
        anchor (0,0)
        pos (-512,-360)
        pause 1
        linear 20 pos (-512,-140)
    play se sename
    "Здесь нет никаких альтернативных путей."
    "Нет смысла сожалеть о том, чего ты не сделал."
    "Все говорят, что жизнь – это серия выборов, но это чепуха, придуманная старыми и жестокими людьми."
    "Вчерашний день ведёт к сегодняшнему, а сегодняшний – к завтрашнему."
    "Шаг за шагом."
    "Что ждёт впереди?"
    "Никогда не узнаешь, пока не окажешься там."
    stop se
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
