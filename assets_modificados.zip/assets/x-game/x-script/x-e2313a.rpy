label e2313a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2313a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110600_2_マンション台所"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e23/13a00010a01.opus"
    mx "\"...Да, хорошо.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e23/13a00020a01.opus"

    mx "\"Ладно. Я доверяю тебе.\""

    xy "\"Хорошо. Спасибо.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e23/13a00030a01.opus"

    mx "\"Так, что у нас есть в меню?\""
    if persistent.miyuki[19] == 0:

        xy "\"Окономияки.\""
    elif persistent.miyuki[19] == 1:

        xy "\"Гёдза.\""
    elif persistent.miyuki[19] == 2:

        xy "\"Отбивная.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/e23/13a00040a01.opus"

    mx "\"Я помню, как ты однажды приготовил это для меня, когда мы были детьми.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/e23/13a00050a01.opus"

    mx "\"По крайней мере, ты ПЫТАЛСЯ приготовить это...\""

    xy "\"Заткнись! Я покажу тебе! Я уже не маленький ребёнок!\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e23/13a00060a01.opus"

    mx "\"Хорошо, дорогой. Жду этого с нетерпением.\""
    hide StC with Dissolve(200.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (800/1000)
    $ sename = "se人体_動作_料理L"
    play se sedict[sename]
    stop se fadeout (500.0/1000)
    pause (800/1000)
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    hide 絵色黒
    with Dissolve(1000.0/1000)
    pause (500/1000)
    voice "voice/e23/13a00070a01.opus"

    mx "\"М-м— м-м-м! Вкусно!\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e23/13a00080a01.opus"

    mx "\"Шиничи, это правда невероятно! Какой твой секретный ингредиент?\""

    xy "\"А? У меня его нет.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e23/13a00090a01.opus"

    mx "\"Врёшь. Ты не скроешь это от меня.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    voice "voice/e23/13a00100a01.opus"

    mx "\"Мне стоило только откусить один кусочек... и я уже могу сказать точно, что это ты приготовил со своей любовью.\""
    xy "......"

    "Я не знаю, как она может говорить это с серьёзным лицом..."
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e23/13a00110a01.opus"

    mx "\"О-о-о, ты покраснел! Я тебя смутила?\""

    xy "\"Н-нет!\""

    xy "\"Я сейчас вернусь!\""
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg110600_2_マンション台所"]+".jpg") as 絵背景 at center
    with Dissolve((500.0+1000.0)/1000)
    hide StC with Dissolve(0.0/1000)

    "Как только я побежал на кухню, Миюки поддразнивающе ухмыльнулась мне."
    $ sename = "se物体_冷蔵庫_開ける"
    play se sedict[sename]

    "Я открыл холодильник и достал оттуда коробку с клубникой."

    "В качестве расплаты, я сделаю её любимый десерт!"

    "Раздавить клубнику..."

    "Потом покрыть её сливками..."

    "И, наконец, добавить сахара—"

    xy "\"А?..\""

    "Похоже, сахарница пуста."

    "Где она там хранит сахар, ещё раз?.."
    $ sename = "se物体_棚_開ける"
    play se sedict[sename]

    xy "\"Вон там, внизу?..\""

    "Я открыл ящик своей ногой."

    "Внутри него лежал большой бумажный пакет, на котором было написано «САХАР» красными буквами... рядом с ним лежал бумажный пакет поменьше, но без метки."

    "Я протянул руку и взял—"
    if (persistent.call_known):
        menu:
            "Большой пакет":
                $ SetChoiceSelect = 0
            "Маленький пакет":
                $ SetChoiceSelect = 1
        if SetChoiceSelect==0:
            $ GameName = "e2314a.nss";
        elif SetChoiceSelect==1:
            $ GameName = "e2314b.nss";
    else:
        $ GameName = "e2314a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
