label quit:
    if persistent.c_route and not persistent.e_route and not persistent.world_recreate:
        stop bgm fadeout 0.5
        stop se
        if roof and persistent.video:
            scene otrhnoise
            $ sename = "se環境_雰囲気_世界改変01小L"
            play se sedict[sename]
            $ renpy.pause(5, hard=True)

            scene black
            stop se
            $ renpy.pause(1, hard=True)

            scene otrhnoise
            $ sename = "se環境_雰囲気_世界改変01小L"
            play se sedict[sename]
            $ renpy.pause(5, hard=True)

            scene black
            stop se
            $ renpy.pause(1, hard=True)

            scene otrhnoise
            $ sename = "se環境_雰囲気_世界改変01小L"
            play se sedict[sename]
            $ renpy.pause(2, hard=True)

            scene black
            stop se
            $ renpy.pause(1, hard=True)

            scene otrhnoise
            $ sename = "se環境_雰囲気_世界改変01小L"
            play se sedict[sename]
            $ renpy.pause(2, hard=True)

            scene black
            stop se

            $ St("C",300,0,0,"fu向日アオイ_制服_通常_normal")
            voice "voice/z91/0100010a02.opus"
            "\"Буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп...\""

            $ St("C",300,0,0,"fu向日アオイ_制服_密着_normal")
            voice "voice/z91/0100020a02.opus"
            "\"ТЫ меня слышишь?..\""
            voice "voice/z91/0100040a02.opus"
            "\"ТЫ... улавливаешь мой сигнал?..\""
            voice "voice/z91/0100050a02.opus"
            "\"ТЫ сейчас находишься в центре вселенной?..\""

            $ St("C",300,0,0,"fu向日アオイ電波_制服_密着_normal")
            voice "voice/z91/0100060a02.opus"
            "\"Тогда ТЫ должен слышать меня громко и чётко...\""

            $ St("C",300,0,0,"fu向日アオイ_制服_通常_sad")
            voice "voice/z91/0100070a02.opus"
            "\"......\""

            $ St("C",300,0,0,"fu向日アオイ_制服_よろけ_normal")
            voice "voice/z91/0100080a02.opus"
            "\"Аой не слышит ТЕБЯ...\""
            voice "voice/z91/0100090a02.opus"
            "\"Не слышит... ТВОЙ голос...\""

            $ St("C",300,0,0,"fu向日アオイ_制服_通常_normal")
            voice "voice/z91/0100100a02.opus"
            "\"Но... Аой верит, что сигнал доходит до ТЕБЯ...\""

            $ St("C",300,0,0,"fu向日アオイ_制服_挙手_normal")
            voice "voice/z91/0100110a02.opus"
            "\"Это призрак Аой.\""

            $ St("C",300,0,0,"fu向日アオイ_制服_通常_surprise")
            voice "voice/z91/0100120a02.opus"
            "\"Призрак Аой, оставшийся после того, как её убила Миюки.\""
            voice "voice/z91/0100130a02.opus"
            "\"Фрагмент данных автосохранения Бога.\""

            $ St("C",300,0,0,"fu向日アオイ電波_制服_密着_normal")
            voice "voice/z91/0100140a02.opus"
            "\"В любом другом месте Миюки нашла бы нас, но...\""

            $ St("C",300,0,0,"fu向日アオイ_制服_密着_shout")
            voice "voice/z91/0100150a02.opus"
            "\"Это пространство между игрой и реальностью.\""
            voice "voice/z91/0100160a02.opus"
            "\"Мы не можем сохраниться здесь, так что Миюки не найдёт нас.\""

            $ St("C",300,0,0,"fu向日アオイ_制服_通常_smile")
            voice "voice/z91/0100170a02.opus"
            "\"Это единственное место, где мы можем поговорить.\""

            $ St("C",300,0,0,"fu向日アオイ_制服_よろけ_sad")
            voice "voice/z91/0100180a02.opus"
            "\"Зачем Миюки сделала всё это?..\""

            $ St("C",300,0,0,"fu向日アオイ_制服_よろけ_pain")
            voice "voice/z91/0100190a02.opus"
            "\"Аой не знает... но...\""

            $ St("C",300,0,0,"fu向日アオイ_制服_通常_sad")
            voice "voice/z91/0100200a02.opus"
            "\"Аой подумала, и...\""

            $ St("C",300,0,0,"fu向日アオイ_制服_通常_pain")
            voice "voice/z91/0100210a02.opus"
            "\"Это я виновата в том, что Миюки оказалась в таком положении.\""

            $ St("C",300,0,0,"fu向日アオイ_制服_通常_sad")
            voice "voice/z91/0100220a02.opus"
            "\"Но... Миюки сделала ошибку.\""
            voice "voice/z91/0100230a02.opus"
            "\"Вселенную нужно откатить.\""

            $ St("C",300,0,0,"fu向日アオイ_制服_よろけ_sad")
            voice "voice/z91/0100240a02.opus"
            "\"Иначе Аой... Аой!..\""

            $ St("C",300,0,0,"fu向日アオイ_制服_通常_sad")
            voice "voice/z91/0100250a02.opus"
            "\"Аой скучает по ТЕБЕ.\""

            $ St("C",300,0,0,"fu向日アオイ_制服_通常_cry")
            voice "voice/z91/0100270a02.opus"
            "\"Аой... хочет увидеть ТЕБЯ...\""

            $ St("C",300,0,0,"fu向日アオイ_制服_密着_pain")
            voice "voice/z91/0100280a02.opus"
            "\"Аой хочет увидеть ТЕБЯ снова... поговорить с ТОБОЙ... потрогать ТЕБЯ...\""
            voice "voice/z91/0100290a02.opus"
            "\"...обнять ТЕБЯ... сказать ТЕБЕ, что Аой любит ТЕБЯ... и...\""

            $ St("C",300,0,0,"fu向日アオイ_制服_密着_worry")
            voice "voice/z91/0100300a02.opus"
            "\"Нет... Всё кончено...\""
            voice "voice/z91/0100310a02.opus"
            "\"Моя батарейка... села...\""
            voice "voice/z91/0100320a02.opus"
            "\"Помоги... мне...\""
            voice "voice/z91/0100330a02.opus"
            "\"Аой... ещё...\""
            voice "voice/z91/0100340a02.opus"
            "\"...не дошла... до счастливой концовки!..\""

            scene otrhnoise
            $ sename = "se環境_雰囲気_世界改変01小L"
            play se sedict[sename]
            $ renpy.pause(2, hard=True)

            scene black
            $ St("C",300,0,0,"fu向日アオイ_制服_密着_pain")
            $ renpy.pause(1, hard=True)

            scene otrhnoise
            $ renpy.pause(2, hard=True)

            scene black
            $ St("C",300,0,0,"fu向日アオイ_制服_よろけ_sad")
            $ renpy.pause(1, hard=True)

            scene otrhnoise
            $ renpy.pause(2, hard=True)

            scene black
            $ St("C",300,0,0,"fu向日アオイ_制服_通常_sad")
            $ renpy.pause(1, hard=True)
        else:

            if persistent.radio_disturbance<=9 and persistent.video:
                scene otrhnoise
                $ sename = "se環境_雰囲気_世界改変01小L"
                play se sedict[sename]
                if persistent.radio_disturbance == 1:
                    voice "voice/z90/1100010a02.opus"
                    "\"ТЫ меня слышишь?..\""
                    voice "voice/z90/1100020a02.opus"
                    "\"ТЫ... улавливаешь мой сигнал?..\""
                elif persistent.radio_disturbance == 2:
                    voice "voice/z90/1100030a02.opus"
                    "\"ТЫ сейчас в центре вселенной?..\""
                    voice "voice/z90/1100040a02.opus"
                    "\"В таком случае, ТЫ должен был услышать меня громко и чётко...\""
                elif persistent.radio_disturbance == 3:
                    voice "voice/z90/3100010a02.opus"
                    "\"......\""
                    voice "voice/z90/3100020a02.opus"
                    "\"Аой не слышит ТЕБЯ...\""
                    voice "voice/z90/3100030a02.opus"
                    "\"Не слышит... ТВОЙ голос...\""
                    voice "voice/z90/3100040a02.opus"
                    "\"Но... Аой верит, что сигнал доходит до ТЕБЯ...\""
                elif persistent.radio_disturbance == 4:
                    voice "voice/z90/4100010a02.opus"
                    "\"Это призрак Аой.\""
                    voice "voice/z90/4100020a02.opus"
                    "\"Призрак Аой, оставшийся после того, как её убила Миюки.\""
                    voice "voice/z90/4100030a02.opus"
                    "\"Фрагмент данных автосохранения Бога.\""
                elif persistent.radio_disturbance == 5:
                    voice "voice/z90/5100010a02.opus"
                    "\"В любом другом месте Миюки нашла бы нас, но...\""
                    voice "voice/z90/5100020a02.opus"
                    "\"Это пространство между игрой и реальностью.\""
                    voice "voice/z90/5100030a02.opus"
                    "\"Мы не можем сохраниться здесь, так что Миюки не найдёт нас.\""
                    voice "voice/z90/5100040a02.opus"
                    "\"Это единственное место, где мы можем поговорить.\""
                elif persistent.radio_disturbance == 6:
                    voice "voice/z90/6100010a02.opus"
                    "\"Зачем Миюки сделала всё это?..\""
                    voice "voice/z90/6100020a02.opus"
                    "\"Аой не знает... но...\""
                    voice "voice/z90/6100030a02.opus"
                    "\"Аой подумала, и...\""
                    voice "voice/z90/6100040a02.opus"
                    "\"Это я виновата в том, что Миюки оказалась в таком положении.\""
                elif persistent.radio_disturbance == 7:
                    voice "voice/z90/7100010a02.opus"
                    "\"Но... Миюки сделала ошибку.\""
                    voice "voice/z90/7100020a02.opus"
                    "\"Вселенную нужно откатить.\""
                    voice "voice/z90/7100030a02.opus"
                    "\"Иначе Аой... Аой!..\""
                elif persistent.radio_disturbance == 8:
                    voice "voice/z90/8100010a02.opus"
                    "\"......\""
                    voice "voice/z90/8100020a02.opus"
                    "\"Аой скучает по ТЕБЕ.\""
                    voice "voice/z90/8100030a02.opus"
                    "\"Аой... хочет увидеть ТЕБЯ...\""
                elif persistent.radio_disturbance == 9:
                    voice "voice/z90/9100010a02.opus"
                    "\"Аой хочет увидеть ТЕБЯ снова... поговорить с ТОБОЙ... потрогать ТЕБЯ...\""
                    voice "voice/z90/9100020a02.opus"
                    "\"...обнять ТЕБЯ... сказать ТЕБЕ, что Аой любит ТЕБЯ... и...\""
                else:
                    voice "voice/z90/0100010a02.opus"
                    "\"Буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп...\""
                    voice "voice/z90/0100020a02.opus"
                    "\"Буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп...\""

                $ persistent.radio_disturbance += 1
                if persistent.radio_disturbance == 10:
                    $ persistent.radio_disturbance = 0
    return

image otrhnoise:
    "cg/noice1.jpg"
    0.05
    "cg/noice2.jpg"
    0.05
    repeat
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
