label a3191_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010401_3_学校校門閉通用口開"]=True
    $ PreGameName = GameName
    $ GameName = "a3201.nss"
    return
label a3191:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010500_3_学校昇降口"]+".jpg")
    $ st_timezone = "夜"
    with Dissolve(2000.0/1000)
    stop rain fadeout 0.5
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    xy "Дождь уже закончился?"
    "Когда мы подошли к главному входу, я заметил, что на улице было уже не так дождливо."
    xy "Наверное, теперь мы должны пойти домой, пока у нас ещё есть такая возможность."
    $ St("C",300,0,0,"st向日アオイ電波_着ぐるみ_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/a31/9100010a02.opus"
    aoi "Поняла! Миюки пропала!"
    xy "...Стоп, что?"
    hide StC with Dissolve(200.0/1000)
    "Я осмотрелся вокруг."
    "Как и следовало ожидать, рядом с обувными шкафчиками её не было видно."
    "Она серьёзно решила войти в здание школы? Ночью? Одна?"
    $ sename = "se物体_自販機_動作"
    play se sedict[sename]
    hide 絵背景
    with Dissolve(300.0/1000)
    pause (700/1000)
    xy "А-А-А-А-А-А!!!"
    xy "Ч-ч-что это был за звук?!"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/a31/9100020a01.opus"
    mx "Ой, упс. Я напугала тебя?"
    "Миюки вышла из коридора с ухмылкой."
    "И, похоже, она что-то держала в руках."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_think")
    voice "voice/a31/9100030a02.opus"
    aoi "Кукурузная похлёбка?"
    voice "voice/a31/9100040a01.opus"
    mx "Сегодня холодно. Выпей это, чтобы согреться."
    voice "voice/a31/9100050a02.opus"
    aoi "Это мне?"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a31/9100060a01.opus"
    mx "Конечно. Это знак нашей возрождённой дружбы."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_shy")
    voice "voice/a31/9100070a02.opus"
    aoi "С-спасибо!"
    $ sename = "se物体_缶_開ける"
    play se sedict[sename]
    pause (700/1000)
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_shout")
    voice "voice/a31/9100080a02.opus"
    aoi "Аой сейчас выпьет её всю!"
    voice "voice/a31/9100090a02.opus"
    aoi "Гл-л-л-л... гл-л-л-л... гл-л-л-л..."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_shy")
    voice "voice/a31/9100100a02.opus"
    aoi "М-м-м... она такая вкусная и тёплая..."
    voice "voice/a31/9100110a02.opus"
    aoi "Я даже полностью согрелась."
    "Аой довольно улыбнулась."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_think")
    voice "voice/a31/9100120a02.opus"
    aoi "А, точно!"
    $ sename = "se擬音_コミカル_走る"
    play se sedict[sename]
    hide StML with Dissolve(200.0/1000)
    xy "Хм? Аой, куда это ты?"
    $ sename = "se物体_自販機_動作"
    play se sedict[sename]
    pause (800/1000)
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_挙手_shout")
    voice "voice/a31/9100130a02.opus"
    aoi "Поняла!"
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_挙手_smile")
    voice "voice/a31/9100140a02.opus"
    aoi "У Аой тоже есть знак дружбы для тебя!"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_sad")
    voice "voice/a31/9100150a01.opus"
    mx "Ябалей?"
    xy "Просто возьми её, Миюки."

    voice "voice/a31/9100160a01.opus"
    mx "Что? Нет, я—"
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_sad")
    voice "voice/a31/9100170a02.opus"
    aoi "Это потому, что ты меня ненавидишь?"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_angry")
    voice "voice/a31/9100180a01.opus"
    mx "Конечно же нет!"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a31/9100190a01.opus"
    mx "...Ладно. Я с радостью приму этот знак твоей любви."
    $ sename = "se物体_缶_開ける"
    play se sedict[sename]
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_normal")
    "Она посмотрела на открытую банку с томатным соком."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_shout")
    voice "voice/a31/9100200a01.opus"
    mx "До дна!"
    voice "voice/a31/9100210a01.opus"
    mx "Гл-л-л-л... гл-л-л-л... гл-л-л-л... гл-л-л-л!.."
    voice "voice/a31/9100220a01.opus"
    mx "Гл-л-л-л... гл-л-л-л... м-м... м-м-м?.."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_sad")
    voice "voice/a31/9100230a01.opus"
    mx "Стоп... Это и правда вкусно?"
    xy "Серьёзно?"
    voice "voice/a31/9100240a01.opus"
    mx "Да! По крайней мере, намного лучше, чем я того ожидала..."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_smile")
    voice "voice/a31/9100250a02.opus"
    aoi "Ну конечно!"
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_shy")
    voice "voice/a31/9100260a02.opus"
    aoi "Он полон моей любви!"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a31/9100270a01.opus"
    mx "Да, похоже на то... Хе-хе!"
    "Миюки и Аой ухмыльнулись друг другу."
    "Я невольно начал чувствовать себя здесь брошенным..."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    stop rain
    show expression ("cg/bg/"+imagename["bg010401_3_学校校門閉通用口開"]+".jpg")
    pause (1000/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_normal")
    voice "voice/a31/9100280a01.opus"
    mx "Я тут вспомнила. Мы должны взять немного еды."
    xy "Да! Я умираю с голоду после всей этой беготни вокруг—"
    play voc "a31/9100290b04"
    xy "А. Ты имела в виду... для кота. Точно."
    xy "Хотя он ВСЁ ЕЩЁ котёнок... Должны ли мы дать ему молока?"
    xy "А, но «Кошачья мята», скорее всего, закрыта в такой поздний час..."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_think")
    voice "voice/a31/9100300a02.opus"
    aoi "Может, заглянуть в магазин за углом?"
    xy "Стоп... А котятам разве можно пить то же молоко, что и людям?"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a31/9100310a01.opus"
    mx "Им можно, да."
    voice "voice/a31/9100320a01.opus"
    mx "Если оно пастеризованное, оно безопасно."
    xy "О, правда?"
    voice "voice/a31/9100330a01.opus"
    mx "Я прочитала об этом в Интернете."
    $ St("ML",300,0,0,"st向日アオイ電波_着ぐるみ_通常_normal")
    voice "voice/a31/9100340a02.opus"
    aoi "Признай это, Миюки. Ты хочешь завести кота, верно?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_shy")
    voice "voice/a31/9100350a01.opus"
    mx "Н-нет... Дело не в этом..."
    "Я не могу представить себе ДРУГУЮ причину, по которой ты бы интересовалась такими вещами, но да ладно."
    xy "Ладно, где там у нас самый ближайший магазин за углом?.."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
