label e1135a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1135c.nss"
    return
label e1135a:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010210_2_学校屋上屋根向"]+".jpg")
    show expression ("cg/ev/l/"+imagename["eve1158a美雪ラスボス_l"]+".jpg") as 絵専 zorder 1100 at truecenter:
        zoom .5
    with Dissolve(0.0/1000)
    voice "voice/e11/35a00010a01.opus"

    mx "\"ТЫ читал мой дневник, так что ТЫ определённо должен помнить.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
