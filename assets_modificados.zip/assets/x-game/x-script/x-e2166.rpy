label e2166_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2167.nss"
    return
label e2166:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/6600010a01.opus"

    mx "\"Мы должны это отпраздновать. Ты мне подарил уже десятый подарок.\""

    xy "\"Стоп... Правда? Так много?\""
    voice "voice/e21/6600020a01.opus"

    mx "\"Да, правда. Я веду все записи в своём дневнике.\""

    "Понятно. Ей определённо нравилось записывать в него каждую мелочь..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
