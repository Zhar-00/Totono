label e1123a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1124.nss"
    return
label e1123a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/23a00010a01.opus"

    mx "\"...Забавно.\""
    voice "voice/e11/23a00020a01.opus"

    mx "\"А раньше ты говорил, что не сможешь.\""

    xy "\"Хм?..\""

    "Я попытался всё вспомнить."

    "Странно... я не помню, чтобы когда-нибудь говорил ей «нет»..."
    $ persistent.roop_accept_count = 0
    $ persistent.roop_reject_count = 0
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
