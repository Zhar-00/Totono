label c3181_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010402_3_学校校門閉"]=True
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label c3181:
    hide 絵色黒
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    show expression Solid("000000") as 絵演色黒
    scene expression ("cg/bg/"+imagename["bg010402_3_学校校門閉"]+".jpg")
    hide 上背景
    hide 絵演色黒
    with Dissolve(1000.0/1000)

    "—Двадцать минут спустя..."

    "Я стоял перед школьными воротами."

    "Они были полностью закрыты; замок висел даже на пешеходных воротах."

    "Туда никак нельзя было протиснуться."

    "Но если эта игра была приближенной к реальной жизни, то Аой определённо там."

    "Это мой последний шанс вернуться."
    show expression ("cg/bg/l/"+imagename["bg010402_3_学校校門閉_l"]+".jpg") as 絵背景:
        pos (-350,-380)
    with Dissolve((500.0+1000.0)/1000)

    "Я остановился у входа и сделал глубокий вдох."
    return
    return
label c3181_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010402_3_学校校門閉"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010402_3_学校校門閉_l"]+".jpg") as 絵背景 zorder 100:
        pos (-350,-380)
    with Dissolve(0.0/1000)
    menu:
        "Прокрасться в школу":
            $ SetChoiceSelect = 0
        "Сдаться и пойти домой":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "c3182.nss"
    elif SetChoiceSelect==1:
        $ GameName = "d3182.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
