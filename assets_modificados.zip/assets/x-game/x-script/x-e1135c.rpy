label e1135c_MAIN:
    call expression GameName
    $ persistent.imagelog["eve1158a美雪ラスボス"]=True
    $ persistent.imagelog["eve1158a美雪ラスボスb"]=True
    $ persistent.imagelog["efev美雪の口元"]=True
    $ persistent.imagelog["bg010210_9_学校屋上屋根向"]=True
    $ PreGameName = GameName
    $ GameName = "e1139.nss"
    return
label e1135c:
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010210_2_学校屋上屋根向"]+".jpg")
    show expression ("cg/ev/l/"+imagename["eve1158a美雪ラスボス_l"]+".jpg") as 絵専 zorder 4100 at truecenter:
        zoom .5
        linear 20 zoom 1.5

    "Она печально на меня посмотрела..."

    "...и мой взгляд вдруг был прикован к её глазам."
    voice "voice/e11/35c00010a01.opus"

    mx "\"Той ночью...\""
    show expression ("cg/ef/"+imagename["efev美雪の口元"]+".jpg") as 絵背景 zorder 3010 at truecenter:
        zoom 1.1
    hide 絵専
    with Dissolve(1000.0/1000)
    pause (2000/1000)
    hide StC with Dissolve(0.0/1000)
    voice "voice/e11/35c00020a01.opus"

    mx "\"...я узнала, как модифицировать вселенную.\""
    show expression ("cg/bg/"+imagename["bg010210_9_学校屋上屋根向"]+".jpg")
    $ sename = "se環境_自然_風L"
    play se sedict[sename]
    hide 絵背景
    with Dissolve(1000.0/1000)

    "Внезапно поднялся порыв ветра."

    "Я посмотрел наверх и заметил, как тёмные штормовые облака кружили над нами в небе, хотя поначалу там был обычный закат."
    show expression ("cg/ev/"+imagename["eve1158a美雪ラスボスb"]+".jpg") as 絵専 zorder 1100 at truecenter
    hide 絵背景空
    with Dissolve(1000.0/1000)
    pause (500/1000)
    voice "voice/e11/35c00030a01.opus"

    mx "\"Это был мой первый раз, когда я программировала что-либо.\""
    voice "voice/e11/35c00040a01.opus"

    mx "\"И мне нужно было время, чтобы разобраться во всём.\""
    voice "voice/e11/35c00050a01.opus"

    mx "\"И поэтому я начала с того, чтобы взять тебя в плен.\""

    xy "\"Ты что?..\""

    "Я не мог понять то, что она говорила."

    "Стоп..."

    "Неужели Миюки начала стирать свои границы между вымыслом и реальностью?.."
    voice "voice/e11/35c00060a01.opus"

    mx "\"С помощью Бога, я создала препарат, который стирает границы между вымыслом и реальностью.\""
    voice "voice/e11/35c00070a01.opus"

    mx "\"Помнишь все те моменты, когда ты внезапно чувствовал сонливость?\""
    voice "voice/e11/35c00080a01.opus"

    mx "\"Ты путал события игры с событиями в реальной жизни.\""
    voice "voice/e11/35c00090a01.opus"

    mx "\"И ты был уверен в том, что Аой - всего лишь персонаж в видеоигре.\""

    "Это полный бред."

    "В обычной ситуации я бы просто посмеялся."

    "Но... что-то здесь не так."

    "Что-то... происходит."

    "Что-то за гранью моего понимания—"
    voice "voice/e11/35c00100a01.opus"

    mx "\"Мы можем быть счастливы вместе, только мы вдвоём.\""
    voice "voice/e11/35c00110a01.opus"

    mx "\"Нам нечего бояться.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
