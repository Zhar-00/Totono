label e1152a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ renpy.full_restart()
    return
label e1152a:
    hide 絵色黒
    stop bgm fadeout (3000.0/1000)
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_ero")
    with Dissolve(200.0/1000)
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_ero")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e11/52a00010a01.opus"
    mx "\"...Спасибо.\""
    $ St("C",300,0,0,"fu曽根美雪_制服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/e11/52a00020a01.opus"

    mx "\"Я так понимаю, ТЫ помнишь...\""
    voice "voice/e11/52a00030a01.opus"

    mx "\"Наш первый поцелуй на крыше...\""
    voice "voice/e11/52a00040a01.opus"

    mx "\"Тот вечный поцелуй, который мы разделили...\""
    hide StC with Dissolve(200.0/1000)

    "Миюки подошла поближе, её глаза сверкали от любви."

    "Я не мог сбежать, но мне это и не нужно было."
    scene expression "cg/bg/black.jpg" as 絵色黒
    with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),.6)

    "Я просто молча закрыл глаза..."

    "...и поцеловал её."
    pause (1000/1000)
    $ MetaFlagReset();
    $ persistent.rlock = False
    $ persistent.minus_choice = False;
    $ persistent.e_route_first = False;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
