label c3162_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label c3162:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040200_3_街川縁雨"]+".jpg")
    with Dissolve(0.0/1000)

    "Миюки тоже затихла."

    "В какой-то момент, никто из нас не говорил ни слова."
    hide 絵板写朧
    with Dissolve(2000.0/1000)

    xy "\"Есть идеи, где она может быть?..\""
    voice "voice/c31/6200010a01.opus"

    mx "\"Мне-то откуда знать?\""
    voice "voice/c31/6200020a01.opus"

    mx "\"Она ни за что не поднялась бы на крышу школы, особенно когда на улице льёт как из ведра. Она даже не должна быть в состоянии пройти через ворота.\""

    xy "\"Полагаю, мы просто должны искать её везде.\""
    voice "voice/c31/6200030a01.opus"

    mx "\"Наверное.\""
    voice "voice/c31/6200040a01.opus"

    mx "\"Ты ищи её на юге. А я пойду на север.\""

    xy "\"В таком случае, мы можем встретиться у меня дома.\""
    voice "voice/c31/6200050a01.opus"

    mx "\"Конечно. Звучит как план.\""

    "После этого мы с Миюки разделились и пошли обыскивать тёмный город."
    show expression ("cg/bg/"+imagename["bg900100_3_雰囲気空雨"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(500.0/1000)
    $ sename = "se人体_足音_走る雨01L"
    play se sedict[sename]
    pause (300/1000)

    "Куда она могла привести маленькое животное в такой поздний час?"

    "Ничего на ум не приходит."

    "Привокзальная площадь..."

    "Торговый район..."

    "Парк..."

    "Дороги, ведущие к школе..."

    "Магазин за углом..."

    "Различные кафе быстрого питания..."
    show expression Solid("000000") as 絵演色黒
    hide 絵専
    with Dissolve(1000.0/1000)

    "Без каких-либо зацепок, мы всё искали, искали, и искали..."
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    stop rain
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    hide 絵演色黒

    "Прошёл уже час."

    "В какой-то момент, во время поисков Аой, дождь закончился."
    pause (1000/1000)
    with Dissolve(1000.0/1000)

    xy "\"Ты нашла её?\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c31/6200060a01.opus"

    mx "\"Я так понимаю, ты её тоже не нашёл.\""

    "Я заметил, что Миюки ждала меня снаружи моего дома."

    "По выражению её лица можно было сказать, что она уже полностью сдалась."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c31/6200070a01.opus"

    mx "\"Тогда, получается, мы больше ничего не можем поделать.\""
    xy "\"Но—\""
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c31/6200080a01.opus"

    mx "\"Она, скорее всего, ушла домой к своим родителям.\""
    voice "voice/c31/6200090a01.opus"

    mx "\"Теперь, когда дождь прекратился, давай закончим на сегодня.\""
    return
    return
label c3162_SELECT:
    $ renpy.save("lastsel")
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg020100_3_自宅外正面"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(0.0/1000)
    menu:
        "Сдаться":
            $ SetChoiceSelect = 0
        "Не сдаваться":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "d3163.nss"
    elif SetChoiceSelect==1:
        $ GameName = "c3163.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
