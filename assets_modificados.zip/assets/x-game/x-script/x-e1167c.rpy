label e1167c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ DeleteAllSave()
    $ persistent.complete = True;
    $ renpy.quit(relaunch = True)
    return
label e1167c:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    with Dissolve(0.0/1000)
    stop bgm fadeout (1000.0/1000)
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    voice "voice/e11/67c00010b02.opus"

    kmsm "\"ЧИТ-КОД ПОДТВЕРЖДЁН.\""
    voice "voice/e11/67c00020b02.opus"

    kmsm "\"ПОДГОТОВКА К ПРИНУДИТЕЛЬНОМУ ОБНОВЛЕНИЮ ВСЕЛЕННОЙ.\""

    xy "\"Обновлению... вселенной?..\""
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    pause (2000/1000)
    show expression ("cg/bg/"+imagename["bg010610_9_学校教室扉前"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shock")
    with Dissolve(500.0/1000)
    voice "voice/e11/67c00030a01.opus"

    mx "\"Что—?!\""
    voice "voice/e11/67c00040a01.opus"

    mx "\"Что ты СДЕЛАЛ?!\""
    voice "voice/e11/67c00050b02.opus"

    kmsm "\"ЭТО ОБНОВЛЕНИЕ НЕОБРАТИМО. ПОСЛЕ ЕГО ЗАВЕРШЕНИЯ ОБЫЧНАЯ ИГРА СТАНЕТ НЕДОСТУПНОЙ.\""
    $ St("C",300,0,0,"st曽根美雪_制服_病み_fear")
    with Dissolve(200.0/1000)
    voice "voice/e11/67c00060a01.opus"

    mx "\"Не может быть—\""
    voice "voice/e11/67c00070b02.opus"

    kmsm "\"ВНИМАНИЕ. ЕСЛИ СУБЪЕКТ ЖЕЛАЕТ ИСПЫТАТЬ МИР ТАК, КАК И ЗАДУМЫВАЛОСЬ, НЕМЕДЛЕННО ЗАКРОЙТЕ ИГРУ.\""
    $ St("C",300,0,0,"st曽根美雪_制服_病み_hard")
    with Dissolve(200.0/1000)
    voice "voice/e11/67c00080a01.opus"

    mx "\"Ты ввёл чит-код?\""
    voice "voice/e11/67c00090b02.opus"

    kmsm "\"ПОВТОРЯЮ, НАСТОЯТЕЛЬНО РЕКОМЕНДУЕТСЯ ЗАКРЫТЬ ИГРУ.\""
    $ sename = "se人体_足音_歩く美雪"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"fu曽根美雪_制服_腕組み_rage")
    with Dissolve(200.0/1000)
    voice "voice/e11/67c00100a01.opus"

    mx "\"Ой, да ладно, блядь!..\""
    stop bgm fadeout (1000.0/1000)
    $ sename = "se人体_衝撃_バットで殴る04"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白 zorder 1000
    pause (30/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_rage")
    with Dissolve((0.0+900.0)/1000)
    with Dissolve((0.0+1000.0)/1000)
    $ renpy.vibrate(.3)
    $ sename = "se人体_衝撃_転倒03"
    play se sedict[sename]
    hide 絵色白

    "Что-то ударило меня по черепу..."
    voice "voice/a01/13v00060b02.opus"

    kmsm "Обратный отсчет начался"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/e11/67c00120a01.opus"

    mx "Вот и всё! Протагонист мёртв!"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_rage")
    with Dissolve(200.0/1000)
    voice "voice/e11/67c00160a01.opus"

    mx "А теперь закрывай игру! Быстрее!"
    voice "voice/e11/67c00180a01.opus"

    mx "Сделай это! Сейчас же!"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_fear")
    with Dissolve(200.0/1000)
    voice "voice/e11/67c00200a01.opus"

    mx "Пожалуйста! Зачем ТЫ делаешь это?!"
    $ St("C",300,0,0,"st曽根美雪_制服_病み_hard")
    with Dissolve(200.0/1000)
    voice "voice/e11/67c00220a01.opus"

    mx "Если бы я знала, что ТЫ меня так предашь—"
    voice "voice/e11/67c00240a01.opus"

    mx "Если бы я знала, что ТЫ сдашься на половине истории—"
    voice "voice/e11/67c00260a01.opus"

    mx "Если бы я знала, что потеряю свои воспоминания—"
    $ St("C",300,0,0,"st曽根美雪_制服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/67c00280a01.opus"

    mx "То я предпочла бы, чтобы ТЫ просто—"
    voice "voice/e11/67c00300a01.opus"

    mx "—НЕНАВИДЕЛ МЕНЯ ДО МОЗГА КОСТЕЙ!!!"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
