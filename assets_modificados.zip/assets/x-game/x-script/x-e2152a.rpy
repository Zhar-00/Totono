label e2152a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2153.nss"
    return
label e2152a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010400_2_学校校門"]+".jpg")
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
    with Dissolve(0.0/1000)

    xy "\"А ты уверена, что не растолстеешь?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/52a00010a01.opus"

    mx "\"Я могу есть столько мороженого, сколько захочу. У меня высокий метаболизм.\""

    xy "\"...Правда? С каких пор?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e21/52a00020a01.opus"

    mx "\"С недавних.\""

    xy "\"А как так вышло?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/52a00030a01.opus"

    mx "\"А, я просто узнала, как можно обмануть систему.\""

    "Это на какой странной диете она сидит?.."

    xy "\"И сколько ты сейчас весишь?\""
    if persistent.miyuki[8] == 0:
        $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
        with Dissolve(200.0/1000)
        voice "voice/e21/52a00040a01.opus"

        mx "\"Ага, вот прям взяла и сказала тебе об этом!\""

        xy "\"Понял...\""

        "Вес женщины - это очень большой секрет, о котором не должен знать ни один мужчина на свете... Наверное..."
    elif persistent.miyuki[8] == 1:
        $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
        with Dissolve(200.0/1000)
        voice "voice/e21/52a00050a01.opus"

        mx "\"А ты ПРАВДА хочешь узнать?\""

        xy "\"Н-не, обойдусь.\""

        "Я прогнулся под напряжённостью её взгляда."
    elif persistent.miyuki[8] == 2:
        $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shout")
        with Dissolve(200.0/1000)
        voice "voice/e21/52a00060a01.opus"

        mx "\"Хороший вопрос! Наверное, я должна сжечь немного КАЛОРИЙ!\""
        hide StC
        hide StMR
        hide StML
        with Dissolve(200.0/1000)
        $ sename = "se人体_動作_バットスイング01"
        play se sedict[sename]

        "Миюки внезапно начала оттачивать свой бейсбольный замах... в моём направлении—!!!"

        xy "\"Э-это же бессмысленно! Серьёзно, ты такая стройная, я не вижу в этом необходимости!\""

        "Я уже успел подумать, что она собиралась ударить меня по лицу..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
