label a2191_MAIN:
    call expression GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label a2191:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    with Dissolve(1000.0/1000)
    "После того, как кассир упаковал мою покупку, я вышел из магазина."
    "Две длинные тени тянулись по асфальту, после чего Миюки и Аой подошли ко мне."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)

    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/a21/9100010a01.opus"
    mx "Шиничи, ты ведь знаешь, что делать, да?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/a21/9100020a02.opus"
    aoi "Шиничи, пожалуйста..."
    "Их взгляд был прикован ко мне."
    "Улыбнувшись, я достал из кармана аккуратно сложенный кошелёк."
    return
label a2191_SELECT:
    $ renpy.save("lastsel")
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(0.0/1000)
    menu:
        "Отдать его Миюки":
            $ SetChoiceSelect = 0
        "Отдать его Аой":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "a2192a.nss"
    elif SetChoiceSelect==1:
        $ GameName = "a2192b.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
