label c5122_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5131.nss"
    python:
        if persistent.passed_c5122_month == None or persistent.passed_c5122_day == None:
            from time import strftime, localtime
            persistent.passed_c5122_month = int(strftime("%m",localtime()))
            persistent.passed_c5122_day = int(strftime("%d",localtime()))
            persistent.DIARY_COUNT += 1
    return
label c5122:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010800_1_学校体育館"]+".jpg")
    show expression ("cg/bg/m/"+imagename["bg010800_1_学校体育館_m"]+".jpg") as 絵背景 zorder 15 at truecenter
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200010a01.opus"

    mx "\"Ты знаешь, в чём дело, верно?\""

    xy "\"Э-эм... А должен?..\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200020a01.opus"

    mx "\"Я вчера говорила тебе, что буду ждать тебя.\""
    xy "\"А, да...\""
    hide StC with Dissolve(200.0/1000)

    "Всё случилось так внезапно той ночью, что я совсем забыл об этом..."

    "Перед тем, как оставить Миюки одну на бейсбольном поле, она сказала мне..."
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵専 zorder 2100:
        xcenter .5
        ypos -340
    show expression im.AlphaMask("cg/bg/black.jpg","cg/data/circle_02_00_0.png") as 絵色回想黒 zorder 2390
    $ St("C",2400,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(500.0/1000)
    pause (500/1000)
    voice "voice/c51/2200030a01.opus"
    mx "\"Это обещание, слышишь меня?! Я буду ждать!\""
    hide 絵専
    hide 絵覆
    hide 絵色回想黒
    hide 上背景
    hide StC
    with Dissolve(400.0/1000)
    pause (300/1000)

    "И теперь я вспомнил."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200040a01.opus"

    mx "\"Я ждала тебя всю ночь. Целыми ЧАСАМИ.\""

    xy "\"Прости...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    $ sename = "se物体_バット_地面叩く"
    play se sedict[sename]
    pause (500/1000)
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    voice "voice/c51/2200050a01.opus"

    mx "\"Что произошло?\""
    hide StC with Dissolve(200.0/1000)

    "Миюки крепко схватилась за рукоять своей бейсбольной биты..."

    "...и направила её мне прямо в лицо."

    xy "\"Ха-ха... ха-ха-ха... Эм, Миюки?..\""

    "Я улыбнулся ей."

    "Но она не улыбнулась мне в ответ. Совсем нисколько."

    "Бита дрожала в её руке."

    "А потом воспоминания вспыхнули у меня в голове... слухи о том, что Миюки якобы избила одного ученика до полусмерти."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    mx "\"Ши-и-ини-и-ичи-и-и?..\""

    xy "\"Ладно, ладно. Смотри. Сначала я нашёл Аой на крыше школы.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200070a01.opus"

    mx "\"На крыше?..\""

    "Её выражение лица слегка изменилось."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200080a01.opus"

    mx "\"А потом?\""

    xy "\"А?\""
    voice "voice/c51/2200090a01.opus"

    mx "\"Это всё?\""

    xy "\"Ну, нет, эм...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200100a01.opus"

    mx "\"Ты обещал мне, помнишь?\""
    voice "voice/c51/2200110a01.opus"

    mx "\"Ты обещал мне, что выслушаешь меня.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200120a01.opus"

    mx "\"Разве нет?\""

    "Она права. Я обещал ей."

    "И я, так или иначе, должен рассказать ей всё, если хочу, чтобы они поладили."

    "Так что я мог бы сказать ей об этом раньше, а не позже."
    xy "\"......\""

    "Я сделал глубокий вдох."

    "Ладно. Сейчас я расскажу ей всю правду."

    xy "\"Я признался Аой в своих чувствах.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200130a01.opus"
    mx "......"
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200140a01.opus"

    mx "\"...А потом?\""

    xy "\"Что?\""
    voice "voice/c51/2200150a01.opus"

    mx "\"Что она имела в виду под \"мы подзарядились\"?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200160a01.opus"
    mx "\"Это была её очередная несуразица? Или...\""


    "Она подслушивала?"

    "Ну ладно. Назвался груздем - полезай в кузов."

    xy "\"Мы занимались сексом.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    stop bgm fadeout (300.0/1000)
    $ sename = "se物体_バット_転がる"
    play se sedict[sename]
    pause (1500/1000)
    $ sename = "se人体_衝撃_ビンタ"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵演色白 zorder 5000
    pause (30/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    hide 絵演色白
    with Dissolve(300.0/1000)
    voice "voice/c51/2200170a01.opus"
    mx "\"......!!!\""

    "Искры вспыхнули под моими веками."

    "В какой-то момент я не понимал, что только что произошло."

    "А потом, с запозданием, я почувствовал боль от удара."

    "А. Я понял."

    "Миюки дала мне пощёчину."

    "—Стоп, что?"

    "За что она дала мне пощёчину?"

    "Я лишь сказал ей, что влюбился в Аой."

    "Ну, не только это, но ещё и про сам факт того, что мы занимались сексом."

    "Только эти две вещи, не более."

    "Так почему, чёрт побери, она так разозлилась?"
    $ sename = "se人体_足音_歩く美雪体育館"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)

    xy "\"Эй! Стой!\""
    stop se fadeout (200.0/1000)

    "Прежде, чем я смог всё переварить, Миюки начала уходить."

    xy "\"Мне очень жаль, что я забыл про тебя, ладно?! Но я ничего такого не сделал, чтобы ты ударила меня!\""

    xy "\"Сначала ты привела меня сюда, а потом ударила без причины, и теперь ты думаешь, что можешь уйти без каких-либо объяснений—?!\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_hard")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200180a01.opus"
    mx "\"......!!!\""

    "Она развернулась, на её лице было ясно видно злость..."

    "И всё же, по какой-то причине, из её глаз шли слёзы—"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_rage")
    with Dissolve(200.0/1000)
    voice "voice/c51/2200190a01.opus"

    mx "\"—Ненавижу тебя!\""
    $ sename = "se人体_足音_走る美雪去る"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Она взбесилась прямо как школьница, закатившая истерику."

    "Её поспешные шаги вскоре стали неслышимыми в спортзале."
    xy "......"

    "И в этот момент, я мог только провожать её взглядом."
    stop bgm fadeout (2000/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
