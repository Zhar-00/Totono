label b1121_MAIN:
    call expression GameName
    $ persistent.imagelog["ef雄太郎スマフォプレイ中エンディング"]=True
    $ persistent.imagelog["ef雄太郎スマフォプレイ中エンディングb"]=True
    $ PreGameName = GameName
    $ GameName = "a1122.nss"
    $ no_call = True;
    return
label b1121:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    pause (1000/1000)
    $ sename = "se環境_ガヤ_教室授業中L"
    play se sedict[sename]
    pause (2000/1000)
    hide 上背景
    hide 絵色黒
    with Dissolve(2000.0/1000)

    "...Хм? К-какого?.."
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")

    "Я... в классе?"

    "Тогда что это всё было?"

    xy "\"......Ох.\""
    show expression ("cg/ef/"+imagename["ef雄太郎スマフォプレイ中エンディング"]+".jpg") as 絵背景 zorder 1010 at center
    show expression ("cg/ef/"+imagename["ef雄太郎スマフォプレイ中エンディングb"]+".jpg") as 絵背景 zorder 1010 at center
    with Dissolve((800.0+1000.0)/1000)
    pause (500/1000)

    "Сначала я поставил режим авточтения, а потом меня вернули на главное меню."

    "Наверное, я потерял сознание, играя в игру."
    stop se fadeout (500.0/1000)

    "Мои воспоминания были довольно смутные..."

    "Встряхнувшись, я нажал на \"Новая игра\"."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
