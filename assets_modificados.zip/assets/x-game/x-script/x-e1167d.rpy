label e1167d_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ DeleteAllSave();
    $ persistent.complete = True;
    $ renpy.full_restart()
    return
label e1167d:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    with Dissolve(0.0/1000)
    stop bgm fadeout (5000.0/1000)

    "Мои молитвы дошли до самых дальних уголков неба..."
    "Появился разрыв в ткани вселенной..."
    "Он открылся в случайном месте..."
    "...и начал засасывать всё в себя..."
    "Тени исчезли..."
    "Цвета пропали..."
    "Наброски перекосились..."
    "Линии испарились..."
    "Весь мир..."
    "...начало глючить—!"
    "Программа запустилась автоматически."

    scene expression "cg/bg/aec793d93eda52af7ada2e1e606c6ce772b248c7.jpg"
    with dissolve
    $ St("C",300,0,0,"st曽根美雪_制服_通常_sigh")

    voice "voice/e11/67d00010a01.opus"
    mx "\"Что—?!\""
    "Дверь открылась, и Миюки забежала в класс."
    "От её самообладания не осталось и следа."

    $ St("C",300,0,0,"st曽根美雪_制服_病み_sad")
    voice "voice/e11/67d00020a01.opus"
    mx "\"Не может быть!..\""

    scene expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    "Она толкнула меня и забрала телефон."

    $ St("C",300,0,0,"bu曽根美雪_制服_病み_fear")
    voice "voice/e11/67d00030a01.opus"
    mx "\"Как?!.. Почему?!..\""
    hide StC with dissolve

    "Миюки прищурилась. И она, несомненно, увидела запущенную программу прямо на его экране."
    voice "voice/e11/67d00040a01.opus"
    mx "\"Этого... не может быть... я изменила код игры так, чтобы этого не произошло!..\""
    voice "voice/e11/67d00050a01.opus"
    mx "\"ТЫ никоим образом не мог достать ту информацию в этой игре!!!\""

    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    "Она посмотрела на меня налитыми кровью глазами."

    $ St("C",300,0,0,"bu曽根美雪_制服_通常_cool")
    voice "voice/e11/67d00060a01.opus"
    mx "\"Это просто совпадение?.. Быть того не может!\""
    voice "voice/e11/67d00070a01.opus"
    mx "\"В кодовом номере Аой её день рождения указан дважды.\""
    voice "voice/e11/67d00080a01.opus"
    mx "\"Четвёртым числом там, по-моему, является либо 0, либо 1.\""
    voice "voice/e11/67d00090a01.opus"
    mx "\"И ТЕБЕ говорили об этом снова и снова...\""
    voice "voice/e11/67d00100a01.opus"
    mx "\"Так что ТЫ никоим образом не мог по чистой случайности ввести этот номер.\""
    "Она печально опустила свой взгляд."

    $ St("C",300,0,0,"fu曽根美雪_制服_病み_sad")
    voice "voice/e11/67d00110a01.opus"
    mx "\"Это ТВОЁ второе прохождение?\""
    voice "voice/e11/67d00120a01.opus"
    mx "\"Или ТЫ прочитал прохождение в Интернете?\""
    voice "voice/e11/67d00130a01.opus"

    $ St("C",300,0,0,"fu曽根美雪_制服_病み_fear")
    mx "\"В конце концов... ТЫ предал меня?\""
    xy "\"Что?..\""
    "Как я мог «предать» её?"
    "Я просто хочу, чтобы она поступила правильно—"

    $ St("C",300,0,0,"fu曽根美雪_制服_病み_lost")
    voice "voice/e11/67d00140a01.opus"
    mx "\"ТЫ обманывал меня всё это время, да?\""
    xy "\"Миюки?..\""
    voice "voice/e11/67d00150a01.opus"
    mx "\"Потому что я всего лишь какой-то персонаж в видеоигре? Ты просто хотел увидеть, как я на это отреагирую, да?\""
    voice "voice/e11/67d00160a01.opus"
    mx "\"И поэтому ты решил поморочить мне голову?\""
    xy "\"Что? Это вовсе не—\""

    $ St("C",300,0,0,"fu曽根美雪_制服_病み_mad")
    voice "voice/e11/67d00170a01.opus"
    mx "\"Я тебе это никогда не прощу!!!\""

    hide StC with dissolve
    "Миюки замахнулась своей битой."
    "Взгляд в её глазах был до боли серьёзным."
    "Она правда собирается убить меня."
    "Я инстинктивно зажмурил глаза."

    show expression ("cg/bg/"+imagename["bg010600_9_学校教室"]+".jpg")
    "Я прикрыл свою голову руками и сжался на месте."
    pause (100/1000)
    "Но..."
    $ sename = "se環境_衝撃_電気"
    play se sedict[sename]
    voice "voice/e11/67d00180a01.opus"
    mx "\"......!!!\""
    $ sename = "se物体_バット_転がる"
    play se sedict[sename]
    pause (800/1000)
    $ sename = "se人体_衝撃_転倒03"
    play se sedict[sename]
    pause (1000/1000)
    "Раздался удар током, и что-то упало на пол."
    "Я больше не чувствовал присутствие Миюки."
    "Мои глаза снова открылись."
    hide 絵色白
    hide 絵色黒
    with Dissolve(1500.0/1000)
    pause (500/1000)
    xy "\"Аой?\""
    $ St("C",300,0,0,"st向日アオイヘアピン_制服_よろけ_normal")
    with Dissolve(500.0/1000)
    pause (300/1000)
    $ renpy.music.play("ttb01",channel = "bgm", if_changed = True)
    voice "voice/e11/67d00190a02.opus"
    aoi "\"Буп-буп...\""
    $ sename = "se人体_足音_走るアオイ"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    "Миюки рухнула на пол..."
    "...и кто-то выбежал из комнаты."
    xy "\"Аой—?!\""
    "Я проверил Миюки. Похоже, она просто без сознания."
    $ sename = "se人体_動作_座るソファー"
    play se sedict[sename]
    "Я прижал её к стене, а потом побежал за Аой."
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]
    scene expression ("cg/bg/"+imagename["bg010700_9_学校廊下"]+".jpg")
    with Dissolve(250.0/1000)
    $ sename = "se人体_足音_走るアオイ"
    play se sedict[sename]
    "Аой бежала по всему коридору, и я гнался за ней вслед."
    "И в своей руке она держала телефон Миюки..."
    xy "\"Я так рад, что ты вернулась!\""
    voice "voice/e11/67d00200a02.opus"
    aoi "\"......\""
    xy "\"Эм, Аой? Ты слышишь меня?\""
    voice "voice/e11/67d00210a02.opus"
    aoi "\"......\""
    scene expression ("cg/bg/"+imagename["bg010500_9_学校昇降口"]+".jpg")
    with Dissolve(250.0/1000)
    xy "\"Стой!\""
    voice "voice/e11/67d00220a02.opus"
    aoi "\"......\""
    xy "\"Я сделал это ради тебя, знаешь ли!\""
    voice "voice/e11/67d00230a02.opus"
    aoi "\"......\""
    show expression ("cg/bg/"+imagename["bg010100_9_学校階段"]+".jpg")
    with Dissolve(250.0/1000)
    pause (1000/1000)
    $ sename = "se物体_ドア鉄_開く01"
    play se sedict[sename]
    pause (1200/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010200_9_学校屋上"]+".jpg")
    pause (500/1000)
    hide 絵色黒
    with Dissolve(500.0/1000)
    pause (500/1000)
    xy "\"Могла бы и спасибо сказать!\""
    voice "voice/e11/67d00240a02.opus"
    aoi "\"......\""
    xy "\"Аой!\""
    voice "voice/e11/67d00250a02.opus"
    aoi "\"......\""
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((250.0+1000.0)/1000)
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    hide 絵色黒
    with Dissolve(250.0/1000)
    pause (1000/1000)
    $ St("C",300,0,0,"fu向日アオイヘアピン_制服_通常_cry")
    with Dissolve(200.0/1000)
    "Аой обернулась; с её глаз капали слёзы."
    xy "\"......Аой?\""
    voice "voice/e11/67d00260a02.opus"
    aoi "\"Аой грустно.\""
    voice "voice/e11/67d00270a02.opus"
    aoi "\"Это слёзы печали.\""
    xy "\"Тебе грустно?..\""
    voice "voice/e11/67d00280a02.opus"
    aoi "\"Аой прошла через множество других рутов.\""
    voice "voice/e11/67d00290a02.opus"
    aoi "\"И поэтому Аой понимает, что чувствует Миюки.\""
    voice "voice/e11/67d00300a02.opus"
    aoi "\"И Аой понимает боль предательства.\""
    voice "voice/e11/67d00310a02.opus"
    aoi "\"ТЫ сжульничал.\""
    voice "voice/e11/67d00320a02.opus"
    aoi "\"ТЫ растоптал все наши чувства.\""
    voice "voice/e11/67d00330a02.opus"
    aoi "\"И теперь... ТЫ будешь наказан.\""
    xy "\"Наказан?\""
    $ St("C",300,0,0,"fu向日アオイヘアピン_制服_よろけ_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/67d00340a02.opus"
    aoi "\"У Аой есть к тебе просьба.\""
    voice "voice/e11/67d00350a02.opus"
    aoi "\"Пока ещё не слишком поздно.\""
    voice "voice/e11/67d00360a02.opus"
    aoi "\"Если ТЫ правда случайно ввёл этот код...\""
    voice "voice/e11/67d00380a02.opus"
    aoi "\"То начни игру сначала.\""
    $ St("C",300,0,0,"fu向日アオイヘアピン_制服_よろけ_cry")
    with Dissolve(200.0/1000)
    voice "voice/e11/67d00390a02.opus"
    aoi "\"Пожалуйста.\""
    "Я не понимаю, чего она от меня просит."
    "И я не знаю, чего она ждёт."
    "Прошла одна минута."
    $ St("C",300,0,0,"fu向日アオイヘアピン_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/67d00400a02.opus"
    aoi "\"Ладно.\""
    voice "voice/e11/67d00410a02.opus"
    aoi "\"Значит, таков ТВОЙ ответ.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(500.0/1000)
    pause (300/1000)
    "Аой пробормотала про себя."
    $ sename = "se人体_動作_ポケット探る"
    play se sedict[sename]
    pause (2000/1000)
    "Потом она протянула руку и сняла свою заколку."
    stop bgm fadeout (5000.0/1000)
    $ sename = "se人体_動作_腕を上げる"
    play se sedict[sename]
    show expression ("cg/ev/l/"+imagename["eva0113アオイ送信中b_l"]+".jpg") as 絵専 zorder 1100 at truecenter
    hide StC with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)
    pause (1000/1000)
    voice "voice/e11/67d00420a02.opus"
    aoi "\"Какая жалость.\""
    "Она подняла свой телефон в воздух..."
    "...и нажала на кнопку вызова."
    voice "voice/e11/67d00430b02.opus"
    kmsm "\"ЧИТ-КОД ПОДТВЕРЖДЁН.\""
    voice "voice/e11/67d00440b02.opus"
    kmsm "\"ПОДГОТОВКА К ПРИНУДИТЕЛЬНОМУ ОБНОВЛЕНИЮ ВСЕЛЕННОЙ.\""
    xy "\"Обновлению... вселенной?..\""
    voice "voice/e11/67d00450b02.opus"
    kmsm "\"ЭТО ОБНОВЛЕНИЕ НЕОБРАТИМО. ПОСЛЕ ЕГО ЗАВЕРШЕНИЯ ОБЫЧНАЯ ИГРА СТАНЕТ НЕДОСТУПНОЙ.\""
    voice "voice/e11/67d00460b02.opus"
    kmsm "\"ВНИМАНИЕ. ЕСЛИ СУБЪЕКТ ЖЕЛАЕТ ИСПЫТАТЬ МИР ТАК, КАК И ЗАДУМЫВАЛОСЬ, НЕМЕДЛЕННО ЗАКРОЙТЕ ИГРУ.\""
    voice "voice/e11/67d00470b02.opus"
    kmsm "\"ПОВТОРЯЮ, НАСТОЯТЕЛЬНО РЕКОМЕНДУЕТСЯ ЗАКРЫТЬ ИГРУ.\""
    voice "voice/a01/13v00060b02.opus"
    kmsm "\"НАЧИНАЮ ОТСЧЁТ.\""
    voice "voice/a01/13v00070b02.opus"
    bm "\"ДЕСЯТЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00080b02.opus"
    bm "\"ДЕВЯТЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00090b02.opus"
    bm "\"ВОСЕМЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00100b02.opus"
    bm "\"СЕМЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00110b02.opus"
    bm "\"ШЕСТЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00120b02.opus"
    bm "\"ПЯТЬ.\"{w=1}{nw}"
    voice "voice/a01/13v00130b02.opus"
    bm "\"ЧЕТЫРЕ.\" {w=1}{nw}"
    voice "voice/a01/13v00140b02.opus"
    bm "\"ТРИ.\"{w=1}{nw}"
    voice "voice/a01/13v00150b02.opus"
    bm "\"ДВА.\"{w=1}{nw}"
    voice "voice/a01/13v00160b02.opus"
    bm "\"ОДИН.\"{w=1}{nw}"
    voice "voice/a01/13v00170b02.opus"
    bm "\"НОЛЬ.\"{w=1}{nw}"
    stop bgm fadeout (0/1000)
    pause (16/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
