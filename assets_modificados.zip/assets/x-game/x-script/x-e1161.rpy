label e1161_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1162.nss"
    return
label e1161:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040400_2_街交差点"]+".jpg")
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(0.0/1000)

    xy "\"Эй, слушай! Знаю, это, наверное, странный вопрос—\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/e11/6100010b01.opus"

    xtl "\"Поверь мне, ты и сам ведёшь себя не менее странно...\""

    xy "\"Ты нигде не видел Аой?\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/e11/6100020b01.opus"

    xtl "\"Муко?\""

    xy "\"Да. Аой Муко.\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
