label e2313c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2313c:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110600_2_マンション台所"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e23/13c00010a01.opus"

    mx "\"Не будь таким скрягой.\""
    voice "voice/e23/13c00020a01.opus"

    mx "\"Ну же, давай готовить вместе.\""

    xy "\"Что? Но это ведь идёт вразрез с моей целью—\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e23/13c00030a01.opus"

    mx "\"Ой, да какая разница!\""
    hide StC with Dissolve(200.0/1000)

    "После этого мы с Миюки провели приятный вечер, готовя на кухне вместе..."

    "Всё прошло не так, как я планировал, но Миюки выглядела счастливой, так что, думаю, это мелочи."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
