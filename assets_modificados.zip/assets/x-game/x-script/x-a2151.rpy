label a2151_MAIN:
    call expression GameName
    $ persistent.imagelog["eva2151美雪アオイ心一写真a"]=True
    $ persistent.imagelog["eva2151美雪アオイ心一写真b"]=True
    $ PreGameName = GameName
    $ GameName = "a2152.nss"
    return
label a2151:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    $ sename = "se物体_学校_チャイム"
    play se sedict[sename]
    show expression Solid("000000") as 絵演色黒
    with Dissolve(0.0/1000)
    voice "voice/a21/5100010a01.opus"
    mx "Шиничи! Держи глаза закрытыми, понял?!"
    xy "Знаю я, знаю..."
    xy "Это не было бы проблемой, если бы я залез наверх первым, знаешь ли..."
    voice "voice/a21/5100020a01.opus"
    mx "Р-разумеется, я понимаю это. Это вопрос вежливости! Дамы вперёд!"
    voice "voice/a21/5100030a02.opus"
    aoi "Показываешь свою легкомысленную сторону?"
    voice "voice/a21/5100040a01.opus"
    mx "Нет!"
    $ sename = "se人体_動作_梯子のぼる"
    play se sedict[sename]
    "Я даже с закрытыми глазами мог сказать, что Миюки сейчас покраснела."
    pause (2000/1000)
    voice "voice/a21/5100050a02.opus"
    aoi "Ладно, Миюки уже поднялась."
    voice "voice/a21/5100060a02.opus"
    aoi "Шиничи, твоя очередь."
    xy "Круто."
    $ sename = "se人体_動作_梯子のぼる一歩"
    play se sedict[sename]
    "Продолжая держать глаза закрытыми, я приложил руку к первой ступеньке и начал медленно подниматься."

    show expression ("cg/bg/"+imagename["bg900200_1_雰囲気街並み"]+".jpg") behind 絵演色黒
    show expression ("cg/bg/l/"+imagename["bg900200_1_雰囲気街並み_l"]+".jpg") as 絵背景 behind 絵演色黒:
        pos (0,-100)
        linear 60 xpos -1024
    stop se fadeout (150.0/1000)
    "Как только я забрался наверх, я открыл глаза."
    show expression Solid("FFFFFF") as 絵色白 zorder 2000
    hide 絵演色黒
    with Dissolve(800.0/1000)
    pause (400/1000)
    $ renpy.music.play("ttb11",channel = "bgm", if_changed = True)
    hide 絵色白
    with Dissolve(1600.0/1000)
    pause (300/1000)
    xy "......"
    "Вид был и вправду захватывающий."
    "Я уже знал, что будет меня там ждать, но он всё так же меня очаровывал."
    "То же и с Миюки..."
    show expression ("cg/bg/"+imagename["bg010300_1_学校屋根"]+".jpg")
    hide 絵背景
    with Dissolve(1000.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/a21/5100070a01.opus"
    mx "......"
    "Похоже, она чувствовала то же самое."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a21/5100080a01.opus"
    mx "Как красиво..."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/a21/5100090a01.opus"
    mx "Я чувствую себя немного глупой из-за того, что говорю очевидную вещь, но я не могу с этим ничего поделать."
    xy "Мы правда должны поблагодарить Аой за то, что она привела нас сюда."
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/l/"+imagename["bg010300_1_学校屋根_l"]+".jpg") as 絵背景 zorder 100 at center
    with Dissolve(500.0/1000)
    pause (200/1000)
    $ St("C",300,0,0,"bu向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/a21/5100100a02.opus"
    aoi "Поняла!"
    voice "voice/a21/5100110a02.opus"
    aoi "Аой сделает фотографию."
    xy "Фотографию?"
    hide StC with Dissolve(0.0/1000)
    hide 絵背景
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    $ St("ML",300,0,0,"st向日アオイ電波_制服_挙手_normal")
    with Dissolve(500.0/1000)
    voice "voice/a21/5100120a01.opus"
    mx "О, звучит отлично. Давайте сделаем совместное селфи втроём."
    xy "Не, я пас. Я лучше буду фотографом."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_pride")
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/5100130a01.opus"
    play voc "a21/5100140a02"
    bm "Нет.\" \"Нет."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a21/5100150a02.opus"
    aoi "...Буп-буп?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/a21/5100160a01.opus"
    mx "Похоже, мы на одной волне."
    xy "Ха-а... Ладно, не важно."
    "Если они обе абсолютно уверены в этом, то, получается, спорить здесь бессмысленно."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/ev/"+imagename["eva2151美雪アオイ心一写真a"]+".jpg") as 絵専 zorder 1100 at center
    pause (500/1000)
    $ sename = "se人体_動作_衣擦れ01"
    play se sedict[sename]
    hide 絵色黒
    with Dissolve(500.0/1000)
    voice "voice/a21/5100170a01.opus"
    mx "О, у твоего телефона есть фронтальная камера?"
    voice "voice/a21/5100180a02.opus"
    aoi "Ага."
    voice "voice/a21/5100190a01.opus"
    mx "Немного узкий обзор, да?"
    voice "voice/a21/5100200a02.opus"
    aoi "У меня слишком короткая рука..."
    voice "voice/a21/5100210a01.opus"
    mx "Шиничи, встань поближе!"
    xy "Не знаю, смогу ли я..."
    $ sename = "se人体_動作_衣擦れ03"
    play se sedict[sename]
    hide 絵専参
    with Dissolve(500.0/1000)
    "Миюки прижалась ко мне, дабы попасть в кадр, и, ого, она такая мягкая..."
    "Очень... мягкая..."
    voice "voice/a21/5100220a02.opus"
    aoi "Шиничи, ты сильно давишь."
    "Могла и не говорить об этом."
    hide 絵専弐
    with Dissolve(1000.0/1000)
    voice "voice/a21/5100230a01.opus"
    mx "Хм... Это должно сработать, да?"
    xy "Поторопись, пожалуйста..."
    voice "voice/a21/5100240a02.opus"
    aoi "Ладно."
    voice "voice/a21/5100250a02.opus"
    aoi "Три..."
    voice "voice/a21/5100260a02.opus"
    aoi "Два..."
    voice "voice/a21/5100270a02.opus"
    aoi "Один..."
    show expression Solid("FFFFFF") as 絵色白 zorder 5000
    stop bgm fadeout (3000.0/1000)
    $ sename = "se物体_携帯_写真撮るスマフォ"
    play se sedict[sename]
    with Dissolve((200.0+1000.0)/1000)
    pause (200/1000)
    show expression ("cg/ev/"+imagename["eva2151美雪アオイ心一写真b"]+".jpg") as 絵専 zorder 1101 at center
    show expression ("cg/ev/l/"+imagename["eva2151美雪アオイ心一写真b_l"]+".jpg") as 絵専弐:
        pos (-225,-210)
    hide 絵色白
    with Dissolve(800.0/1000)
    pause (500/1000)
    voice "voice/a21/5100280a02.opus"
    aoi "Готово."
    voice "voice/a21/5100290a01.opus"
    mx "Дай-ка взглянуть..."
    with Dissolve((0.0+1000.0)/1000)
    with Dissolve(500.0/1000)
    pause (500/1000)
    voice "voice/a21/5100300a01.opus"
    mx "Здорово! Очень даже неплохо."
    xy "Хотя можно сказать, что я протиснулся между вами..."
    xy "...Стоп, что за?"
    with Dissolve((0.0+1000.0)/1000)
    hide 絵専
    with Dissolve(800.0/1000)
    pause (500/1000)
    $ renpy.music.play("ttb08",channel = "bgm", if_changed = True)
    xy "Аой на этой фотографии УЛЫБАЕТСЯ?"
    voice "voice/a21/5100310a01.opus"
    mx "О... Ты абсолютно прав. Так и есть."
    voice "voice/a21/5100320a02.opus"
    aoi "Улыбается?.."
    xy "Видишь? Посмотри на свой рот вот здесь. Это, должно быть, улыбка."
    hide 絵専弐
    with dissolve
    $ St("ML",300,-30,0,"bu向日アオイ電波_制服_通常_normal")
    $ St("MR",300,30,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(500.0/1000)
    voice "voice/a21/5100330a02.opus"
    aoi "Как так вышло?"
    voice "voice/a21/5100340a01.opus"
    mx "Возможно, потому, что ты чувствовала себя счастливой?"
    $ St("ML",300,-30,0,"bu向日アオイ電波_制服_通常_think")
    voice "voice/a21/5100350a02.opus"
    aoi "...Счастливой?"
    voice "voice/a21/5100360a02.opus"
    aoi "Аой... чувствовала себя счастливой?.."
    "Аой пробормотала себе под нос, размышляя над самой концепцией этого."
    show expression ("cg/ev/"+imagename["eva2151美雪アオイ心一写真b"]+".jpg") as 絵背景 zorder 1100 at center
    with Dissolve((500.0+1000.0)/1000)
    pause (500/1000)
    "Глядя на эту фотографию, у меня было такое чувство, будто она наконец-то начала переходить из своего мира в наш... и её улыбка была заразительной."
    pause (1500/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    hide 絵背景
    with Dissolve(1000.0/1000)
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a21/5100370a01.opus"
    mx "Эй, Аой? Можешь отправить эту фотографию мне на телефон?"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_shock")
    voice "voice/a21/5100380a01.opus"
    mx "А, погоди, я ведь так и не сказала тебе свой адрес электронной почты, да? Ладно, раз уж об этом зашла речь, я дам тебе свой номер и—"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    voice "voice/a21/5100390a02.opus"
    aoi "Адрес электронной почты?!"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/a21/5100400a02.opus"
    aoi "Давай обменяемся!"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a21/5100410a01.opus"
    mx "Хорошо."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se物体_携帯_アドレス交換"
    play se sedict[sename]
    pause (500/1000)
    voice "voice/a21/5100420a01.opus"
    mx "Ладно, теперь ты дай мне свою почту."
    $ sename = "se物体_携帯_アドレス交換"
    play se sedict[sename]
    pause (500/1000)
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/a21/5100430a01.opus"
    mx "Вот, готово."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_挙手_normal")
    voice "voice/a21/5100440a02.opus"
    aoi "Отлично!"
    voice "voice/a21/5100450a02.opus"
    aoi "Миюки?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a21/5100460a02.opus"
    aoi "Это ведь делает нас... друзьями?"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_shock")
    voice "voice/a21/5100470a01.opus"
    mx "Хм?"
    xy "Ах да, насчёт этого..."
    xy "Для Аой, обмен адресами электронной почты является неким... знаком дружбы, если можно так выразиться..."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a21/5100480a01.opus"
    mx "О-о-о... так вот, почему она так рьяно хотела сделать это."
    xy "Именно."
    "Мы оба хихикнули."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/a21/5100490a02.opus"
    aoi "Мы... не друзья?"
    "Спросила Аой тихим голосом."
    "Миюки наклонилась к ней поближе."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a21/5100500a01.opus"
    mx "Мы всё это время были друзьями, глупышка."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_happy")
    voice "voice/a21/5100510a02.opus"
    aoi "Оу!"
    "После этого на лице Аой возникла очередная заразительная улыбка."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/a21/5100520a01.opus"
    mx "Попробуй сейчас позвонить мне."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a21/5100530a02.opus"
    aoi "Буп-буп..."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/a21/5100540a02.opus"
    aoi "Уже звоню."
    "Между нами на какое-то мгновение повисла тишина."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/a21/5100550a01.opus"
    mx "......"
    voice "voice/a21/5100560a01.opus"
    mx "Мне... судя по всему, не поступает твой звонок."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a21/5100570a02.opus"
    aoi "Буп-буп?.."
    voice "voice/a21/5100580a01.opus"
    mx "Но у меня есть все палки... Шиничи, можешь попробовать позвонить мне?"
    xy "Что? У меня даже твоего номера нет."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_shock")
    voice "voice/a21/5100590a01.opus"
    mx "Что, серьёзно?"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_normal")
    voice "voice/a21/5100600a01.opus"
    mx "Ну ладно, раз уж такое дело, держи."
    xy "А?.."
    "Миюки резко поставила свой телефон передо мной."
    xy "Эм... И что я должен с этим делать?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_shy")
    voice "voice/a21/5100610a01.opus"
    mx "У тебя нет моего адреса электронной почты, верно? Давай обменяемся."
    xy "Что? Это, конечно, здорово... но мы не должны..."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a21/5100620a02.opus"
    aoi "Но..."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a21/5100630a02.opus"
    aoi "Шиничи, Миюки и Аой... Мы все друзья."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/a21/5100640a02.opus"
    aoi "Верно?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/a21/5100650a01.opus"
    mx "...Ты слышал её."
    xy "Ха-а..."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    "Громко вздохнув, я открыл свой список контактов."
    $ sename = "se物体_携帯_アドレス交換"
    play se sedict[sename]
    pause (500/1000)
    "И после этого её номер уже был записан в память моего телефона."
    "В качестве проверки, я решил набрать её номер."
    $ renpy.music.set_volume(.001,delay = 2,channel="bgm")
    play sound "bgm/ttb27_ef.opus"
    pause (2000/1000)
    show expression ("cg/bg/m/"+imagename["bg010300_1_学校屋根_m"]+".jpg") as 絵演背景 zorder 200 at center
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    pause (500/1000)
    xy "...У тебя стоит довольно девчачий рингтон."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_angry")
    with Dissolve(200.0/1000)
    voice "voice/a21/5100660a01.opus"
    mx "И-и что с того?!"
    "Миюки залилась краской."
    stop sound fadeout .15
    $ sename = "se物体_携帯_着信音切れる"
    play se sedict[sename]
    $ renpy.music.set_volume(1,delay=3,channel="bgm")
    pause (500/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_angry")
    hide 絵演背景
    with Dissolve(500.0/1000)
    pause (100/1000)
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/a21/5100670a01.opus"
    mx "Ладно, перейдём к делу! Этим мы подтвердили, что мой номер ещё действителен."
    xy "В таком случае, вполне вероятно—"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_電話_other")
    voice "voice/a21/5100680a02.opus"
    aoi "Буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп!.."
    voice "voice/a21/5100690a02.opus"
    aoi "Буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп-буп... Буп-буп..."
    "Аой печально покачала головой."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/a21/5100700a02.opus"
    aoi "Всё ещё нет сигнала..."
    xy "...Да, у меня было предчувствие, что дело в этом."
    voice "voice/a21/5100710a02.opus"
    aoi "Как раз тогда, когда мы наконец-то стали друзьями по-настоящему..."
    voice "voice/a21/5100720a02.opus"
    aoi "Если Бог не ответит на звонок, Аой не сможет сохраниться..."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_normal")
    voice "voice/a21/5100730a01.opus"
    mx "Как сохраниться?"
    "...И она снова начала нести геймерскую пургу."
    "Впрочем, если эта реальность была для неё игрой, то я не виню её за то, что она хочет сохраниться здесь и увековечить память о рождении нашей дружбы."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_sigh")
    voice "voice/a21/5100740a01.opus"
    mx "Твои звонки никогда не доходят... Может, здесь сигнал слабый?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a21/5100750a02.opus"
    aoi "Дело явно не в этом."
    voice "voice/a21/5100760a02.opus"
    aoi "Школа является начальной точкой вселенной."
    voice "voice/a21/5100770a02.opus"
    aoi "А это – центральная точка школы."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_shout")
    voice "voice/a21/5100780a02.opus"
    aoi "Следовательно, это – центр вселенной."
    xy "Хм..."
    "Многие люди посмеялись бы над её безумной речью."
    "Боже, а ведь до недавнего времени я был одним из них."
    "Но теперь... я начал задумываться над тем, что она может быть права."
    "И, судя по всему, Миюки думала о том же."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/a21/5100790a01.opus"
    mx "...Ну, мне определённо так кажется."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a21/5100800a02.opus"
    aoi "Это правда."
    voice "voice/a21/5100810a02.opus"
    aoi "Всё начинается здесь."
    voice "voice/a21/5100820a02.opus"
    aoi "А потом, в конечном счёте, всё заканчивается здесь."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/a21/5100830a01.opus"
    mx "Очередная видеоигровая ерунда?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a21/5100840a02.opus"
    aoi "Нет, речь идёт о Боге."
    stop bgm fadeout (3000.0/1000)
    stop se fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((3000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
