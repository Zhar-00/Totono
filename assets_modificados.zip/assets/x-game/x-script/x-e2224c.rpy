label e2224c_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2225a.nss"
    return
label e2224c:
    hide 絵色黒
    show expression Solid("000000") as 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e22/24c00010a01.opus"

    mx "\"События из прошлого больше не имеют значения.\""
    voice "voice/e22/24c00020a01.opus"

    mx "\"Вы теперь в новом мире.\""
    voice "voice/e22/24c00030a01.opus"

    mx "\"Я хочу, чтобы мы начали всё сначала и выразили нашу любовь друг к другу так, будто это наш первый раз.\""
    voice "voice/e22/24c00040a01.opus"

    mx "\"Пожалуйста... Просто следуйте зову сердца.\""

    "Думаю, мне придётся сделать то, что она просит..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
