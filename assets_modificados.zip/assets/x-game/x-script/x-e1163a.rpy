label e1163a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1164.nss"
    return
label e1163a:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg040200_2_街川縁"]+".jpg")
    $ sename = "se人体_足音_歩く01遅L"
    play se sedict[sename]
    $ sename = "se人体_足音_歩く01L"
    play se sedict[sename]
    with Dissolve(0.0/1000)

    "Мы с Миюки жили вместе, но я определённо не помню, когда успел попасть в больницу."

    "Да и у Ютаро была склонность рассказывать безумные истории в школе..."

    "Быть может, его воспоминания просто перемешались?"

    "Я уже начинаю думать, что вся эта неразбериха с «Аой у меня дома» - тоже полный бред..."

    "В смысле, Аой ведь вымышленный персонаж..."
    voice "voice/e11/63a00010b01.opus"

    xtl "\"В чём дело, Шиничи?\""

    xy "\"А? А... Да ни в чём.\""

    "Ошеломлённый, я неохотно последовал за ним."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
