label e1121_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e1121:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    $ persistent.meta_date += 1
    $ St("C",300,0,0,"bu曽根美雪_私服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/2100010a01.opus"

    mx "\"...Посмотрим.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e11/2100020a01.opus"

    mx "\"Для начала я бы хотела проверить тебя.\""

    xy "\"Как проверить?..\""
    voice "voice/e11/2100030a01.opus"

    mx "\"Дело в том, что я не люблю лжецов. Так что...\""
    voice "voice/e11/2100040a01.opus"

    mx "\"Я хочу, чтобы ты сказал мне, какие чувства ты правда испытываешь.\""
    $ St("C",300,0,0,"bu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e11/2100050a01.opus"

    mx "\"Так что скажи мне, Шиничи. Ты любишь меня, верно?\""
    voice "voice/e11/2100060a01.opus"

    mx "\"Можешь ли ты доказать свою вечную любовь ко мне?\""
    if persistent.love_conflict:
        $ GameName = "e1123c.nss";
    else:
        menu:
            "Да":
                $ SetChoiceSelect=0
            "Нет":
                $ SetChoiceSelect=1
        if SetChoiceSelect == 0:
            if persistent.love_roop_reject:
                $ GameName = "e1123a.nss";
                $ persistent.love_conflict = True
            else:
                $ GameName = "e1122a.nss";
                $ persistent.love_roop_accept = True
        elif SetChoiceSelect == 1:
            if persistent.love_roop_accept:
                $ GameName = "e1123b.nss";
                $ persistent.love_conflict = True
            else:
                $ GameName = "e1122b.nss";
                $ persistent.love_roop_reject = True
        return
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
