label a3126_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a3131.nss"
    return
label a3126:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010100_2_学校階段"]+".jpg")
    $ st_timezone = "消灯"
    with Dissolve(500.0/1000)
    $ sename = "se物体_携帯_バイブレーションL"
    play se sedict[sename]
    pause (1000/1000)
    xy "Хм?.."
    "По дороге в спортзал я заметил непрочитанное письмо в своём списке входящих."
    $ sename = "se物体_携帯_開く"
    play se sedict[sename]
    "Я открыл его, и увидел там..."
    xy "О, смотри-ка, это же то групповое фото, которое мы сделали раньше!"
    xy "Помнишь? Та фотография с тобой, мной и Миюки?"
    show expression ("cg/ev/"+imagename["eva2151美雪アオイ心一写真b"]+".jpg") as 絵画像 zorder 1010 at truecenter
    with Dissolve(500.0/1000)
    pause (500/1000)
    "Какое-то мгновение назад Аой утверждала, что отправила эту фотографию мне по электронной почте, но по какой-то причине я получил её только сейчас."
    "С того момента прошло столько времени, что я даже забыл об этом."
    voice "voice/a31/2600010a02.opus"
    aoi "Должно быть, она отправилась, когда у меня появился сигнал."
    xy "А, точно."
    "Полагаю, её телефон И ПРАВДА работает от случая к случаю."
    "Но не так часто, чтобы быть полезным..."
    hide 絵画像
    with Dissolve(500.0/1000)
    pause (100/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/2600020a02.opus"
    aoi "Аой также сделала и новый файл сохранения."
    voice "voice/a31/2600030a02.opus"
    aoi "Теперь нам не надо будет переживать из-за каких-либо плохих концовок."
    xy "А... Точно..."
    "Я вздохнул про себя."
    "Судя по всему, её игровая зависимость никуда так быстро не денется."
    $ EyeCatchIn(2000.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
