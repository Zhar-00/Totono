label e2202a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2202a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    pause (300/1000)

    "Лишь потому, что мы близки, ещё не значит, что у меня есть право копаться в её вещах."

    "Я положил её телефон на стол и вернулся к учёбе."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
