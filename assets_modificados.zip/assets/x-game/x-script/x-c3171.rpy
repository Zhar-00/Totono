label c3171_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label c3171:
    hide 絵色黒
    show expression Solid("000000") as 絵演色黒
    show expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    hide 上背景
    pause (1000/1000)
    $ sename = "se物体_時計_秒針L"
    play se sedict[sename]
    pause (2000/1000)
    show expression ("cg/ef/"+imagename["efbg自宅自室天井消灯"]+".jpg") as 絵演背景 zorder 15 at truecenter
    hide 絵演色黒
    with Dissolve(3000.0/1000)

    "—но я не мог уснуть."

    "Мой мозг попросту не мог перестать думать об этом."

    "Телефон, взятый мной во временное пользование, стоял на зарядке за моей подушкой."

    "Я не играл на нём с того дня во время уроков..."

    "Быть может, я узнаю что-нибудь полезное об Аой, если достигну определённого прогресса в игре?.."
    return
    return
label c3171_SELECT:
    $ renpy.save("lastsel")
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030101_3_自宅自室消灯"]+".jpg")
    show expression ("cg/ef/"+imagename["efbg自宅自室天井消灯"]+".jpg") as 絵演背景 zorder 15 at truecenter
    with Dissolve(0.0/1000)
    menu:
        "Поиграть в игру":
            $ SetChoiceSelect = 0
        "Заставить себя уснуть":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "c3172.nss"
    elif SetChoiceSelect==1:
        $ GameName = "d3172.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
