label a2192b_MAIN:
    call expression GameName
    if miyuki_plot == True:
        $ GameName = "c2193.nss"
    else:
        $ GameName = "a2193.nss"
    return
label a2192b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(0.0/1000)
    show expression ("cg/bg/m/"+imagename["bg040300_2_街商店街_m"]+".jpg") as 絵背景 zorder 1010 at center
    $ St("X",1300,0,0,"bu向日アオイ電波_制服_通常_sad")
    with Dissolve(800.0/1000)
    $ renpy.music.play("ttb08",channel = "bgm", if_changed = True)
    xy "Вот, это тебе."
    $ sename = "se物体_ビニル袋_鳴る"
    play se sedict[sename]
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_surprise")
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    $ St("X",1300,0,0,"bu向日アオイ電波_制服_通常_surprise")
    "Я передал Аой её подарок."
    voice "voice/a21/92b00010a02.opus"
    aoi "Аой не может принять это."
    hide 絵背景
    hide StX with Dissolve(0.0/1000)
    with Dissolve(400.0/1000)
    pause (200/1000)
    voice "voice/a21/92b00020a01.opus"
    mx "Всё нормально. Я хочу, чтобы она была у тебя."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
