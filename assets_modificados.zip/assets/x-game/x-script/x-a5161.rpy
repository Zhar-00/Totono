label a5161_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if no_call == True:
        $ GameName = "b5162.nss"
    else:
        $ GameName = "a5162.nss"
    return
label a5161:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg030300_2_自宅リビング"]+".jpg")
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    $ sename = "se物体_携帯_操作音メール作成L"
    play se sedict[sename]
    pause (500/1000)
    with Dissolve(2000.0/1000)
    "—У меня появились дела."
    "—Прости, но я немного опоздаю."
    "Я знаю, что должен буду потом объяснить ей всё должным образом, но у меня попросту нет времени."
    "Теперь, когда моё сообщение было отправлено, пора узнать у Аой больше подробностей."
    xy "Где ты потеряла его?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_normal")
    with Dissolve(200.0/1000)
    voice "voice/a51/6100010a02.opus"
    aoi "Не знаю..."
    voice "voice/a51/6100020a02.opus"
    aoi "Обычно каждый раз, когда Аой роняет телефон, Бог замечает это и начинает звонить."
    voice "voice/a51/6100030a02.opus"
    aoi "И тогда Аой слышит рингтон."
    xy "Бог правда тебе звонит?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_pain")
    with Dissolve(200.0/1000)
    voice "voice/a51/6100040a02.opus"
    aoi "Но на этот раз этого не произошло."
    xy "Ладно, когда он был у тебя в руках в последний раз?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_normal")
    with Dissolve(200.0/1000)
    voice "voice/a51/6100050a02.opus"
    aoi "Перед тем, как мы пошли на бейсбольное поле, Аой решила проверить время."
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_sad")
    with Dissolve(200.0/1000)
    voice "voice/a51/6100060a02.opus"
    aoi "Он потерялся где-то после этого момента."
    xy "И когда ты обнаружила пропажу?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_normal")
    with Dissolve(200.0/1000)
    voice "voice/a51/6100070a02.opus"
    aoi "Сегодня утром."
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_pain")
    with Dissolve(200.0/1000)
    voice "voice/a51/6100080a02.opus"
    aoi "Аой пыталась искать везде... Манга-кафе, бейсбольное поле, и все дороги между ними."
    "Теперь понятно, почему она не появилась в школе сегодня."
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_normal")
    with Dissolve(200.0/1000)
    voice "voice/a51/6100090a02.opus"
    aoi "Осталось только у тебя дома посмотреть."
    "И в этом есть смысл, учитывая то, что она приходила ко мне вчера ночью."
    "Большую часть времени она игралась с Иру, так что велика вероятность, что она выронила его где-то там."
    xy "Ладно, давай проследим наши шаги. Вчера ночью... мы сначала разогрели молоко..."
    hide StC
    hide StMR
    hide StML
    show expression ("cg/bg/l/"+imagename["bg030400_3_自宅廊下_l"]+".jpg") as 絵美雪背景 zorder 1950:
        pos (-300,-320)
    show expression im.AlphaMask("cg/bu/1/"+imagename["bu曽根美雪_制服_恋人_ero"]+".jpg","cg/bu/mask/"+imagename["bu曽根美雪_制服_恋人_ero"]+".jpg") as 絵美雪弐 zorder 2301 at center
    with Dissolve((500.0+0.0)/1000)
    "Некоторые воспоминания всё ещё блуждали у меня в голове: например, тот момент, когда Миюки сказала мне поцеловать её."

    "И прямо сейчас, она ждала меня..."
    voice "voice/a51/6100100a02.opus"
    aoi "Буп-буп..."
    hide 絵色黒
    hide 絵色回想黒
    hide 絵美雪弐
    hide 絵美雪背景
    with Dissolve(300.0/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_pain")
    with Dissolve(200.0/1000)
    "...Я потом буду беспокоиться об этом."
    "Подавив свои эмоции, я сосредоточил свою энергию на поисках телефона Аой."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    hide StC with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    pause (2000/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    "...Его нигде не было."
    "Куда он, чёрт побери, подевался?"
    "Он вообще здесь, или валяется где-нибудь в канаве?"
    "Или его нашёл кто-то другой?"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
