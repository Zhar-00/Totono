label a3123_MAIN:
    call expression GameName
    $ persistent.imagelog["bg900100_2_雰囲気空"]=True
    $ persistent.imagelog["bg900200_2_雰囲気街並み"]=True
    queue bgm "ttb13"
    $ PreGameName = GameName
    if persistent.root_recreate == True:
        $ GameName = "b3124.nss"
    else:
        $ GameName = "a3124.nss"
    return
label a3123:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010300_2_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)

    xy "Не изнуряй себя."
    "Как и сегодня утром, она всё ещё была не в себе."

    xy "И что ты будешь делать, если Он ответит?"
    pause (16/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    with Dissolve(0.0/1000)
    with Dissolve(184.0/1000)
    voice "voice/a31/2300010a02.opus"
    aoi "Сохраню игру."
    xy "А, точно. Всё-таки ты наконец-то подружилась с Миюки."
    voice "voice/a31/2300020a02.opus"
    aoi "Угу."
    "Я не в восторге от её видеоигровой чуши, но я рад, что Миюки ей небезразлична."
    xy "Что ж, надеюсь, Он ответит."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_happy")
    with Dissolve(200.0/1000)
    voice "voice/a31/2300030a02.opus"
    aoi "Бог ответит. Аой чувствует это."
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/m/"+imagename["bg900100_2_雰囲気空_m"]+".jpg") as 絵背景 zorder 1000:
        pos (-256,-144)
        linear 30 ypos 0
    with Dissolve(1000.0/1000)
    pause (800/1000)
    "Её взгляд проходил через алое небо – за самые дальние уголки этого мира – и на какое-то мгновение я осознал, что завидую ей."
    voice "voice/a31/2300040a02.opus"
    aoi "Шиничи, что не так с тобой сегодня?"
    xy "О чём это ты?"
    voice "voice/a31/2300050a02.opus"
    aoi "Ты избегал Миюки."
    voice "voice/a31/2300060a02.opus"
    aoi "Она отшила тебя вчера ночью?"
    xy "Я ей даже не признавался!"
    xy "Мы с Миюки просто друзья, и—"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    with Dissolve(0.0/1000)
    hide 絵背景
    with Dissolve(800.0/1000)
    voice "voice/a31/2300070a02.opus"
    aoi "Ты врёшь. Аой знает правду."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_happy")
    with Dissolve(200.0/1000)
    voice "voice/a31/2300080a02.opus"
    aoi "Шиничи нравится Миюки."
    voice "voice/a31/2300090a02.opus"
    aoi "А Миюки нравится Шиничи."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/2300100a02.opus"
    aoi "Так что вы двое должны быть вместе. Не быть вместе было бы глупо."
    xy "......"
    "Когда я был с Аой наедине, мне по какой-то причине было проще открыться."
    "Это потому, что мы стояли в «центре вселенной»?"
    "Мне казалось, что, будучи другом Миюки, с Аой было не так опасно разговаривать."
    $ renpy.music.play("ttb13",channel = "bgm", if_changed = True)
    show expression ("cg/bg/l/"+imagename["bg900200_2_雰囲気街並み_l"]+".jpg") as 絵背景 zorder 1010:
        pos (0,-200)
        linear 160 pos (-1024,-200)
    with Dissolve(1000.0/1000)
    pause (800/1000)
    xy "Она сказала, что будет поцелуй."
    voice "voice/a31/2300110a02.opus"
    aoi "А?"
    xy "В спектакле."
    xy "Если бы я был её парнем, я бы сильно разозлился. Но мы просто друзья, так что это не так важно."
    voice "voice/a31/2300120a02.opus"
    aoi "Ты уверен?"
    xy "В смысле, она совершенно не моего уровня."
    xy "Раз уж она известная, то она найдёт того, кто её заслуживает. Кого-нибудь в разы лучше меня."
    xy "Зачем сидеть и ждать, когда меня бросят, когда я мог бы просто... не влюбляться в неё с самого начала?"
    xy "Я ещё давно как принял такое решение."
    "Я понимаю, что немного фаталистично отношусь к этому."
    "Но я не могу ничего поделать со своими чувствами."
    "Именно по этой причине я и держался от неё на расстоянии всё это время."
    "Отношения с ней только навредят нам обоим."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(0.0/1000)
    hide 絵背景
    with Dissolve(800.0/1000)
    pause (200/1000)
    voice "voice/a31/2300130a02.opus"
    aoi "Буп-буп?.."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a31/2300140a02.opus"
    aoi "Шиничи, ты боишься, что тебя кинут?"
    xy "Прошу прощения?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_電話_other")
    with Dissolve(200.0/1000)
    voice "voice/a31/2300150a02.opus"
    aoi "Поняла!"
    "Аой подняла свою руку ввысь."
    "Красные лучи заката отражались от экрана её телефона."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/2300160a02.opus"
    aoi "Не волнуйся."
    stop bgm fadeout (3000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
