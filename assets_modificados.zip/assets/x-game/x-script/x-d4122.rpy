label d4122_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "d4151.nss"
    return
label d4122:
    hide 絵色黒
    stop bgm fadeout (1000/1000)
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    $ sename = "se物体_ドア教室_開く01"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010610_1_学校教室扉前"]+".jpg") as 絵演背景 zorder 15 at truecenter
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    $ sename = "se環境_ガヤ_教室L"
    play se sedict[sename]
    voice "voice/d41/2200010a01.opus"
    mx "\"Доброе утро!\""
    hide StC
    hide StMR
    hide StML
    hide 絵演背景
    with Dissolve(500.0/1000)

    "Миюки вошла в класс, и все ученики тут же оживились."

    "Как обычно, она быстро привлекала толпу."

    "Она обвела комнату взглядом... и её взгляд остановился на пустой парте Аой."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/d41/2200020a01.opus"
    mx "\"......\""



    "Она вопросительно посмотрела на меня."

    "Но мне нечего было ей ответить."
    stop se fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 30000
    with Dissolve((1500.0+1000.0)/1000)
    hide 上背景
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
