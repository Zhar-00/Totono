label a3122a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a3123.nss"
    return
label a3122a:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010300_2_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/22a00010a02.opus"
    aoi "Пока нет... но..."
    voice "voice/a31/22a00020a02.opus"
    aoi "Сегодня хороший день."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
