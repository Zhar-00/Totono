label a3125_MAIN:
    call expression GameName
    $ PreGameName = GameName
    if temp_root_recreate == False:
        show expression Solid("000000") as 絵色黒 zorder 5000
        with Dissolve((1000.0+1000.0)/1000)
        pause (500/1000)
        $ GameName = "a3131.nss";
    else:
        show expression Solid("000000") as 絵色黒 zorder 5000
        with Dissolve((500.0+1000.0)/1000)
        $ GameName = "a3126.nss";
    return
label a3125:
    hide 絵色黒
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010300_2_学校屋根"]+".jpg")
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_happy")
    with Dissolve(0.0/1000)
    with Dissolve(200.0/1000)
    voice "voice/a31/2500010a02.opus"
    aoi "Ладно."
    "И как только Аой улыбнулась..."
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_worry")
    with Dissolve(200.0/1000)
    voice "voice/a31/2500020a02.opus"
    aoi "Буп-буп?.."
    $ sename = "se人体_動作_たたらを踏む"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    xy "Воу!"
    $ sename = "se人体_動作_掴む"
    play se sedict[sename]
    "Её тело начало качаться из стороны в сторону."
    xy "Ты в порядке?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_worry")
    with Dissolve(400.0/1000)
    voice "voice/a31/2500030a02.opus"
    aoi "А?.."
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/2500040a02.opus"
    aoi "У меня батарейка села?"
    xy "Я бы не сказал, что тебе очень жарко. Давай отменим наши планы, и—"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/2500050a02.opus"
    aoi "С Аой всё хорошо."
    voice "voice/a31/2500060a02.opus"
    aoi "Давай пойдём на бейсбольное поле."
    xy "......"
    "В её взгляде не было ни доли сомнения."
    "Она САМА говорила о том, что была очень рада пойти туда... настолько рада, что даже толком не спала..."
    xy "Ладно... Но если вдруг почувствуешь недомогание, сразу говори мне, ладно?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/2500070a02.opus"
    aoi "Поняла."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Она кивнула и начала рассеяно спускаться по лестнице."
    voice "voice/a31/2500080a02.opus"
    aoi "Давай поторопимся и найдём Миюки."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
