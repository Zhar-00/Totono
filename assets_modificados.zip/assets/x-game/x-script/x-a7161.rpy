label a7161_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ persistent.count_birthday += 1
    $ PreGameName = GameName
    $ GameName = "a7211.nss";
    return
label a7161:
    hide 絵色黒
    $ renpy.music.play("ttb16",channel = "bgm", if_changed = True)
    show expression Solid("000000") as 絵演色黒
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg") behind 絵演色黒
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    voice "voice/a71/6100010a01.opus"

    mx "\"Happy Birthday·To·You\""
    voice "voice/a71/6100020a01.opus"

    mx "\"Happy Birthday·To·You\""
    voice "voice/a71/6100030a01.opus"

    mx "\"Happy Birthday·To·You\""
    voice "voice/a71/6100040a01.opus"

    mx "\"Happy Birthday·To·You\""
    $ sename = "se人体_動作_拍手01"
    play se sedict[sename]
    pause (2200/1000)
    show expression ("cg/bg/l/"+imagename["bg030300_3_自宅リビング_l"]+".jpg") as 絵演背景 zorder 15:
        pos (20,-290)
    $ St("C",300,0,30,"bu曽根美雪_私服_恋人_happy")
    $ sename = "se物体_照明_スイッチ"
    play se sedict[sename]
    hide 絵演色黒
    with Dissolve(100.0/1000)
    show expression ("cg/bg/l/"+imagename["bg030300_3_自宅リビング_l"]+".jpg") as 絵演背景 zorder 15:
        pos (20,-290)
    $ St("C",300,0,30,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(0.0/1000)
    pause (500/1000)
    voice "voice/a71/6100050a01.opus"

    mx "С днём рождения, зайка."
    xy "Спасибо."

    "Мы сидели друг напротив друга за столом."

    "И между нами стоял именинный торт, который Миюки испекла сама."

    "Учитывая то, что мы были здесь только вдвоём, это нельзя было назвать \"вечеринкой\", но это всё, о чём я только мог мечтать."

    xy "Боже, как много времени прошло с тех пор, как мы в последний раз праздновали мой день рождения вместе?"
    $ St("C",300,0,30,"bu曽根美雪_私服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/a71/6100060a01.opus"

    mx "Ещё с начальной школы, по крайней мере."
    voice "voice/a71/6100070a01.opus"

    mx "Но всё уже наконец-то вернулось в норму."

    xy "Я бы сказал, что всё теперь куда ЛУЧШЕ, чем обычно."
    $ St("C",300,0,30,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/a71/6100080a01.opus"
    mx "\"...Да...\""

    "Тогда мы были просто друзьями..."

    "...но сейчас мы влюблены друг в друга."

    "Это всё ещё слишком хорошо, чтобы быть правдой."
    hide StMR
    hide StML
    $ St("C",300,0,30,"bu曽根美雪_私服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/a71/6100090a01.opus"

    mx "А теперь, давай резать торт!"

    "Миюки достала нож для торта из своей сумки."

    xy "...А этот торт не слишком большой для нас двоих?"
    $ St("C",300,0,30,"bu曽根美雪_私服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/a71/6100100a01.opus"

    mx "Ой, да всё нормально! Именинного торта много не бывает!"

    xy "...Ты наверняка сделала его для себя..."
    $ St("C",300,0,30,"bu曽根美雪_私服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a71/6100110a01.opus"

    mx "Что ты сказал?"

    xy "Н-ничего!"

    "Наверное, я не должен злить её, пока она держит в руке нож..."
    hide StMR
    hide StML
    hide StMR
    hide StML
    with Dissolve(200.0/1000)

    "Тем временем, она разложила два отдельных куска торта по нашим тарелкам."
    xy "\"Ого, выглядит здорово...\""
    $ St("C",300,0,30,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/a71/6100120a01.opus"

    mx "Давай, налетай!"
    stop bgm fadeout (2000/1000)

    xy "Ням-ням... гл-л-л-л... м-м-м..."
    xy "......"
    $ St("C",300,0,30,"bu曽根美雪_私服_恋人_sad")
    with Dissolve(200.0/1000)
    voice "voice/a71/6100130a01.opus"

    mx "Хм?"
    voice "voice/a71/6100140a01.opus"

    mx "Шиничи, что-то не так?"
    voice "voice/a71/6100150a01.opus"

    mx "Он... не очень вкусный или что?"

    xy "Нет, он вкусный. Очень вкусный! Я просто..."

    xy "Просто мне кажется, будто я сейчас сплю."
    $ St("C",300,0,30,"bu曽根美雪_私服_恋人_sad")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb02",channel = "bgm", if_changed = True)
    voice "voice/a71/6100160a01.opus"

    mx "...Ты ведь не проснёшься и не изменишь своё мнение, верно?"
    voice "voice/a71/6100170a01.opus"

    mx "Мы будем вместе до конца своих дней, так ведь?"
    voice "voice/a71/6100180a01.opus"

    mx "На веки вечные?"

    "У неё было очень серьёзное выражение лица."

    "Как будто она и правда верит в ту школьную легенду..."

    "...или она не может отличить вымысел от реальности."

    "Но я сделаю всё, что есть в моих силах, чтобы помочь ей чувствовать себя в безопасности."
    $ St("C",300,0,30,"bu曽根美雪_私服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/a71/6100190a01.opus"
    mx "\"Поцелуй меня...\""

    "Прошептала она мне на ушко."
    voice "voice/a71/6100200a01.opus"

    mx "Твой поцелуй всегда успокаивает меня..."
    voice "voice/a71/6100210a01.opus"

    mx "Заставляет меня забыть все свои заботы, понимаешь?.."
    stop bgm fadeout (3000/1000)
    show expression Solid("000000") as 絵演色黒 zorder 1000
    with Dissolve((2000.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    pause (1000/1000)

    "Мои губы притянулись к её губам, словно магнит."

    "Я и не знал, что поцелуй на день рождения может быть таким сладким."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
