label a3141_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a3151.nss"
    return
label a3141:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg050100_3_バッティングセンター外正面"]+".jpg")
    with Dissolve(1000.0/1000)
    $ renpy.music.play("ttb05",channel = "bgm", if_changed = True)
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a31/4100010a02.opus"
    aoi "Так вот, где находится бейсбольное поле?"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_normal")
    voice "voice/a31/4100020a01.opus"
    mx "Конечно."
    show expression ("cg/bg/"+imagename["bg060100_3_バッティングセンター店内"]+".jpg")
    $ st_timezone = "昼"
    hide StC
    hide StMR
    hide StML
    with Dissolve(500.0/1000)
    pause (500/1000)
    voice "voice/a31/4100030a02.opus"
    aoi "Правда, оно совсем потрёпанное."
    xy "Оно было таким ещё с тех пор, как мы были детьми."
    voice "voice/a31/4100040a01.opus"
    mx "Если подумать, то это правда."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    voice "voice/a31/4100050a02.opus"
    aoi "Поняла!"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_挙手_normal")
    voice "voice/a31/4100060a02.opus"
    aoi "Вы двое раньше ходили сюда вместе, когда были детьми?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/a31/4100070a01.opus"
    mx "Скорее это Шиничи тащил меня сюда, но да."
    xy "Да, думаю, можно и так сказать."
    "У нас всегда заканчивались карманные деньги, но мы понравились тому парню, который был на смене, и он время от времени разрешал нам играть на поле бесплатно."
    "И после этого бейсбольное поле стало нашим обычным местом встречи."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a31/4100080a01.opus"
    mx "А теперь давайте начнём!"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    voice "voice/a31/4100090a02.opus"
    aoi "Хорошо!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(1000.0/1000)
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2500/1000)
    voice "voice/a31/4100100a02.opus"
    aoi "Хья—!"
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    pause (1000/1000)
    voice "voice/a31/4100110a02.opus"
    aoi "...Буп-буп?"
    "Бита прошла сквозь воздух."
    "Аой озадаченно наклонила голову."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a31/4100120a02.opus"
    aoi "Аой промахнулась?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/a31/4100130a01.opus"
    mx "Вот, смотри на меня. Я покажу тебе, как это делается."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (500/1000)
    $ sename = "se人体_動作_バットスイング01"
    play se sedict[sename]
    pause (500/1000)
    $ sename = "se人体_動作_バットスイング01"
    play se sedict[sename]
    pause (500/1000)
    "Миюки взяла биту у Аой и прошла к месту отбивающего. И после двух пробных замахов, мяч полетел в неё..."
    pause (300/1000)
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (3000/1000)
    $ sename = "se人体_動作_バッティング02"
    $ renpy.vibrate(.3)
    play se sedict[sename]
    pause (800/1000)
    voice "voice/a31/4100140a02.opus"
    aoi "Ого!.."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "...И через секунду она отправила его прямо в защитную сетку."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/a31/4100150a01.opus"
    mx "Ты можешь сказать, что я делаю по-другому?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a31/4100160a02.opus"
    aoi "Буп-буп..."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a31/4100170a02.opus"
    aoi "Миюки, ты такая классная..."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/a31/4100180a02.opus"
    aoi "Аой не такая классная."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_sad")
    voice "voice/a31/4100190a01.opus"
    mx "Ха-а..."
    "Миюки вздохнула."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/a31/4100200a01.opus"
    mx "Ладно, хорошо, чего тебе, по-твоему, не хватает?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a31/4100210a02.opus"
    aoi "Рост. Аой слишком низкая."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_密着_normal")
    voice "voice/a31/4100220a02.opus"
    aoi "Она ни за что не сравнится с красотой Миюки."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_angry")
    voice "voice/a31/4100230a01.opus"
    mx "Это не конкурс!"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_normal")
    voice "voice/a31/4100240a01.opus"
    mx "Шиничи, помоги мне!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg060100_3_バッティングセンター店内"]+".jpg")
    with Dissolve(500.0/1000)
    xy "Хм... Посмотрим..."
    xy "Для начала, постарайся сосредоточить свой взгляд на мяче."
    voice "voice/a31/4100250a02.opus"
    aoi "Сосредоточить свой взгляд на мяче?.."
    xy "Ты не смотришь на него, когда делаешь замах битой. Постарайся на этот раз смотреть на него, а там уже посмотрим, что произойдёт."
    voice "voice/a31/4100260a02.opus"
    aoi "Буп-буп..."
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    $ sename = "se物体_バット_取る"
    play se sedict[sename]
    with Dissolve(500.0/1000)
    "Аой взяла биту и прошла к месту отбивающего."
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (3500/1000)
    $ sename = "se人体_動作_バット空振り"
    play se sedict[sename]
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100270a02.opus"
    aoi "...Я смотрела на него."
    voice "voice/a31/4100280a01.opus"
    mx "Ты должна была делать не только это, балда!"
    xy "Нет, это хороший первый шаг. Мы хотим, чтобы она привыкла к мячу."
    xy "Можешь теперь перейти к ударам? Просто держи биту перед собой."
    $ sename = "se人体_動作_起き上がる01"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    voice "voice/a31/4100290a02.opus"
    aoi "Вот так?"
    xy "Всё правильно. Следи за мячом и бей битой по траектории его полёта."
    voice "voice/a31/4100300a02.opus"
    aoi "Следить за мячом..."
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (300/1000)
    voice "voice/a31/4100310a02.opus"
    aoi "Бить по траектории..."
    pause (1000/1000)
    $ sename = "se人体_動作_バッティング03"
    play se sedict[sename]
    $ renpy.vibrate(.5)
    pause (1500/1000)
    voice "voice/a31/4100320a02.opus"
    aoi "Буп-буп!"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_surprise")
    voice "voice/a31/4100330a02.opus"
    aoi "Ох... А-Аой ударила по нему..."
    "Это было сложно назвать «ударом» – это было больше похоже на самый слабый в мире граунд бол – но я приму это."
    xy "Видишь? Ну и что я тебе говорил?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    voice "voice/a31/4100340a02.opus"
    aoi "Поняла!"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_挙手_smile")
    voice "voice/a31/4100350a02.opus"
    aoi "Шиничи, ты отличный тренер!"
    xy "С-спасибо, наверное."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    voice "voice/a31/4100360a02.opus"
    aoi "Дай-ка ещё раз попробую."
    $ sename = "se人体_動作_衣擦れ01"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    voice "voice/a31/4100370a02.opus"
    aoi "Сосредоточить свой взгляд на мяче..."
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (2500/1000)
    voice "voice/a31/4100380a02.opus"
    aoi "Буп-буп!!!"
    $ sename = "se人体_動作_バッティング03"
    play se sedict[sename]
    pause (800/1000)
    voice "voice/a31/4100390a02.opus"
    aoi "Потрясающе... Ещё один удар..."
    xy "Как насчёт того, что ты на этот раз попробуешь сделать замах?"
    stop bgm fadeout (3000/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (3000/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    $ sename = "se人体_動作_バッティング04"
    $ renpy.vibrate(.7)
    play se sedict[sename]
    voice "voice/a31/4100400a02.opus"
    aoi "Буп-буп!"
    "Мяч слегка отлетел от её неуклюжего замаха. Это был фол-бол."
    "Но всё же, она определённо добивалась успехов."
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg060100_3_バッティングセンター店内"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100410a01.opus"
    mx "Ты всегда был прекрасным учителем, знаешь ли."
    xy "Эм, я бы не сказал, что я особенный."
    voice "voice/a31/4100420a01.opus"
    mx "Ты обладаешь таким талантом ещё с начальной школы."
    xy "Ты так думаешь?"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100430a01.opus"
    mx "Поверь мне, я всё помню."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100440a01.opus"
    mx "Я бесчисленное множество раз перечитывала свой дневник."
    hide StC with Dissolve(200.0/1000)
    "По правде говоря, я тоже это помню."
    "И глядя на неё сейчас, я бы никогда так не подумал... но когда Миюки только училась играть в бейсбол, у неё это получалось куда хуже, чем у Аой."
    "И это я научил её тому, как надо замахиваться битой."
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    voice "voice/a31/4100450a02.opus"
    aoi "Буп-буп!"
    $ sename = "se人体_動作_バッティング05"
    $ renpy.vibrate(.3)
    play se sedict[sename]
    pause (1000/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100460a02.opus"
    aoi "Он улетел?.."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_happy")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100470a02.opus"
    aoi "Он улетел!"
    xy "Определённо! Я видел это своими глазами."
    "Улыбка Аой была искренней и яркой."
    "Я смутно помню, как Миюки улыбалась подобным образом в то время."
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg060100_3_バッティングセンター店内"]+".jpg")
    hide 絵背景
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100480a01.opus"
    mx "Если бы ты тогда не научил меня играть здесь в бейсбол, я бы никогда не заслужила ту роль."
    xy "Эй, да брось. Ты получила ту роль благодаря своим же усилиям."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100490a01.opus"
    mx "Неправда."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100500a01.opus"
    mx "Это ты дал мне такую возможность. Как и обычно."
    "Годы усердного труда, и вы только посмотрите, где она сейчас."
    "Возможно, мы и начали на равных условиях, но теперь мы были в считанных километрах друг от друга."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100510a01.opus"
    mx "Вижу, это старьё всё ещё здесь, хм?"
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 1000:
        xcenter .5
        ypos -70
    with Dissolve((500.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    $ renpy.music.play("ttb12",channel = "bgm", if_changed = True)
    pause (500/1000)
    "Она показала на защитную сетку."
    "Сама сетка была украшена разными мишенями: «Попадание», «Дабл», «Трипл» и «Хоумран»."
    "Попади по всем этим целям, и ты выиграешь купоны на бесплатную игру."
    "Боже, это навевает воспоминания..."
    "Когда мы были детьми, мы с Миюки всегда бросали друг другу вызов в этой игре."
    "Тот, кто не попадал по мишеням больше всего, тащил на себе обе сумки по дороге домой."
    "И стоит отметить, что мы почти что ни разу не попадали по этим мишеням..."
    "Но это не мешало нам продолжать пытаться."
    hide 絵背景
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100520a01.opus"
    mx "Я бы очень хотела посмотреть на то, как ты делаешь замах, прямо как в старые времена."
    "Она сбавила тон своего голоса до шёпота."
    "Но я не ответил ей."
    "Просто это не моё."
    "Вместо этого я молча смотрел вдаль."
    "В глубине души, что-то подсказывало мне..."
    "...если я отвечу на такую просьбу, это уничтожит всё то, чего мы добились втроём."
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    hide StC with Dissolve(0.0/1000)
    pause (2000/1000)
    hide 絵色黒
    with Dissolve(2000.0/1000)
    $ sename = "se人体_動作_投球01"
    play se sedict[sename]
    pause (3500/1000)
    $ sename = "se人体_動作_バッティング05"
    play se sedict[sename]
    pause (500/1000)
    voice "voice/a31/4100530a02.opus"
    aoi "Буп-буп!"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_smile")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100540a01.opus"
    mx "...Ты очень быстро учишься, м-м?"
    voice "voice/a31/4100550a02.opus"
    aoi "Это всё благодаря моему опытному тренеру."
    xy "Думаю, теперь у тебя есть шанс сойтись один на один с Миюки."
    voice "voice/a31/4100560a02.opus"
    aoi "Сойтись с ней? В драке?"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100570a01.opus"
    mx "Почему бы нам не сделать небольшую ставку?"
    show expression ("cg/bg/l/"+imagename["bg060200_3_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 1000:
        xcenter .5
        ypos -200
    with Dissolve((500.0+1000.0)/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    pause (500/1000)
    "Миюки показала на мишени битой."
    voice "voice/a31/4100580a01.opus"
    mx "Мы будем по очереди отбивать мяч битой, и тот, чей мяч окажется ближе всего к мишени, говорит другим двум, что делать."
    voice "voice/a31/4100590a01.opus"
    mx "Мы можем поставить гандикап на скорость полёта мяча, чтобы всё было по-честному."
    voice "voice/a31/4100600a01.opus"
    mx "Как насчёт этого? Не хочешь попробовать?"
    $ st_timezone = "昼"
    hide 絵背景
    with Dissolve(500.0/1000)
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100610a02.opus"
    aoi "Да!"
    voice "voice/a31/4100620a02.opus"
    aoi "Если Аой выиграет, Шиничи и Миюки будут вме—"
    xy "Нет."
    "Я неодобрительно посмотрел на неё."
    xy "Аой, ты не устала после всего этого?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100630a02.opus"
    aoi "Буп-буп?.."
    xy "Я знаю, что ты сегодня чувствовала себя неважно. Давай закончим на сегодня и пойдём домой—"
    voice "voice/a31/4100640a01.opus"
    mx "Ты что, цыплёнок? Вижу, ты придумал ещё одно удобное оправдание, чтобы выпутаться из этого."
    xy "Ладно, не важно, пусть будет так."
    voice "voice/a31/4100650a01.opus"
    mx "Нет, это ВАЖНО!"
    xy "А?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/m/"+imagename["bg060100_3_バッティングセンター店内_m"]+".jpg") as 絵背景 zorder 100:
        pos (-140,-250)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)
    "Миюки ещё никогда так не кричала."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100660a01.opus"
    mx "Знаешь, ты никогда не был таким."
    voice "voice/a31/4100670a01.opus"
    mx "Шиничи, чего ты так боишься?"
    xy "Я ничего не «боюсь»."
    xy "Мне просто не нравятся бессмысленные конфликты."
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100680a01.opus"
    mx "Врёшь."
    "Она была абсолютно права."
    "Я даже не могу найти в себе силы разозлиться."
    hide 絵背景
    hide StC
    hide StMR
    hide StML
    show expression ("cg/bg/"+imagename["bg060200_3_バッティングセンターボックス"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    xy "Дело в том, что Аой сейчас не очень хорошо себя чувствует."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100690a02.opus"
    aoi "Это не— буп-буп?"
    $ sename = "se人体_動作_たたらを踏む"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    pause (800/1000)
    "Аой пыталась доказать обратное, но начала качаться из стороны в сторону."
    xy "Видишь? Вот, о чём я и говорил."
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_sad")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100700a02.opus"
    aoi "Буп-буп-буп-буп..."
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    show expression ("cg/bg/"+imagename["bg060100_3_バッティングセンター店内"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(500.0/1000)
    "Она нахмурилась самой себе."
    xy "Ладно, пошли отсюда."
    voice "voice/a31/4100710a02.opus"
    aoi "Хорошо."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/a31/4100720a01.opus"
    mx "......"
    stop bgm fadeout (3000/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1000.0+1000.0)/1000)
    pause (1000/1000)
    "Миюки, похоже, всё ещё сомневалась в этом, но я проигнорировал её и вышел из здания."
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
