label e2173_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2173:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg040300_2_街商店街"]+".jpg")
    with Dissolve(0.0/1000)
    xy "\"Ну, а что ты купила?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/e21/7300010a01.opus"

    mx "\"Я? А, да ничего особенного...\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se物体_紙_探る"
    play se sedict[sename]
    if persistent.miyuki[11] == 0:
        "Она достала книгу «Фокусы-101»."
    elif persistent.miyuki[11] == 1:
        "Она достала «Путеводитель ведьмы по чёрной магии»."
    elif persistent.miyuki[11] == 2:
        "Она достала «Фотоальбом Всемирного наследия»."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e21/7300020a01.opus"
    mx "\"Просто ещё одна книга для коллекции! Ха-ха...\""
    xy "\"......\""
    "Звучит немного странно, но ладно..."
    "Я и понятия не имел, что она этим увлекается."
    "У меня было почти что такое чувство, будто она от меня что-то скрывала..."
    "Но тем не менее, по размеру её пакета я мог сказать точно, что она купила не одну книгу..."
    xy "\"А что это за книга?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e21/7300030a01.opus"
    mx "\"А, точно. Это?\""
    voice "voice/e21/7300040a01.opus"
    mx "\"«Программирование для чайников».\""
    xy "\"Делаешь свою видеоигру или что-то ещё?\""
    voice "voice/e21/7300050a01.opus"
    mx "\"Да, что-то в таком духе!\""
    xy "\"Ладно, а что посередине?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shout")
    with Dissolve(200.0/1000)
    voice "voice/e21/7300060a01.opus"
    mx "\"Ничего!\""
    voice "voice/e21/7300070a01.opus"
    mx "\"Я там ничего не прячу!\""
    "Хм... И какую же книгу она пытается спрятать от кассира?"
    xy "\"А, я тут вспомнил. Ты однажды упоминала о чём-то в классе...\""
    xy "\"Вроде бы что-то про выпуск одного журнала за этот месяц, в котором имеется коллекция сексуальных фотографий—\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_rage")
    with Dissolve(200.0/1000)
    voice "voice/e21/7300080a01.opus"
    mx "\"Нет!\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e21/7300090a01.opus"
    mx "\"Я бы ни за что не купила что-то подобное!!!\""
    xy "\"Конечно же нет! Ты бы никогда не купила что-то подобное.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_angry")
    with Dissolve(200.0/1000)
    voice "voice/e21/7300100a01.opus"
    mx "\"......!\""
    "Лицо Миюки залилось краской, и она затихла."
    "Я милосердный человек, так что я отпущу её с крючка."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "И тут Миюки отвернулась и неодобрительно пробормотала, причём так громко, чтобы я мог её расслышать..."
    voice "voice/e21/7300110a01.opus"
    mx "\"Клянусь, в следующий раз...\""
    voice "voice/e21/7300120a01.opus"
    mx "\"Я выебу тебе мозги.\""
    "О нет... Что угодно, но только не это..."
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
