label e1153a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    while True:
        " "
    return
label e1153a:
    hide 絵色黒
    $ renpy.music.play("ttb22",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_1_マンションリビング"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e11/53a00010a01.opus"

    mx "\"Бороться со мной бесполезно.\""
    $ sename = "se人体_衝撃_バットで殴る04"
    $ renpy.vibrate(.3)
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白
    pause (30/1000)
    hide 絵色白
    with Dissolve(70.0/1000)
    pause (200/1000)
    $ persistent.resist1 = True;
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
