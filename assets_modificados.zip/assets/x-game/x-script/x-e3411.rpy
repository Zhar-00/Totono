label e3411_MAIN:
    call expression GameName
    $ BackFile = "e3411.nss";
    $ PreGameName = GameName
    return
label e3411:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg110301_3_マンション寝室消灯"]+".jpg")
    $ st_timezone = "夜"
    with Dissolve(0.0/1000)
    $ sename = "se物体_首輪_鳴る"
    play se sedict[sename]
    pause (3000/1000)

    xy "\"Н-н-н... н-нргх...\""
    $ sename = "se環境_水音_シャワーL"
    play se sedict[sename]
    with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(2000.0/1000))

    "Я проснулся посреди ночи."

    "Кажется, я что-то слышал..."
    xy "\"......Что за?\""
    $ sename = "se人体_動作_起き上がる01"
    play se sedict[sename]
    hide 絵背景
    with Dissolve(500.0/1000)

    "Я осмотрелся вокруг, но Миюки нигде не было видно."

    "Я мог услышать слабые звуки работающего душа, но этого было недостаточно для того, чтобы разбудить меня."

    "Это её телефон звонит?"
    menu:
        "Пойти спать":
            $ SetChoiceSelect = 0
        "Взять её телефон":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e3412b.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e3412a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
