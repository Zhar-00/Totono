label e1158a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1135.nss"
    return
label e1158a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040400_2_街交差点"]+".jpg")
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_normal")
    with Dissolve(0.0/1000)

    xy "\"Ты нигде не видел Миюки?!\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/e11/58a00010b01.opus"

    xtl "\"Сонэ-сан? Я только что видел её перед школой—\""

    xy "\"Школа! Точно! Спасибо, приятель!\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/e11/58a00020b01.opus"

    xtl "\"Чт... ЭЙ! Шиничи! А как же твои травмы?!\""

    xy "\"Какие травмы? Я здоров как бык!\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/e11/58a00030b01.opus"

    xtl "\"А как же автокатастрофа—?!\""

    xy "\"Прости! Потом наверстаем упущенное!\""
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_angry")
    with Dissolve(200.0/1000)
    voice "voice/e11/58a00040b01.opus"

    xtl "\"Э-эй—!\""
    $ sename = "se人体_足音_走る01L"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    hide StC with Dissolve(0.0/1000)
    pause (300/1000)

    "Сейчас нет времени на разговоры!"
    show expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg")
    hide 絵色黒
    with Dissolve(500.0/1000)
    pause (200/1000)

    "Я прошёл мимо других учеников на своём пути, и некоторые из них даже косо посмотрели на меня."
    show expression ("cg/bg/"+imagename["bg010400_2_学校校門"]+".jpg")
    with Dissolve(500.0/1000)

    "Должен признать, я, наверное, не должен быть настолько запыхавшимся..."
    show expression ("cg/bg/"+imagename["bg010500_2_学校昇降口"]+".jpg")
    with Dissolve(500.0/1000)
    stop se fadeout (300.0/1000)

    "Мне надо начать делать физические упражнения или что-то в таком духе..."
    show expression ("cg/bg/"+imagename["bg010700_2_学校廊下"]+".jpg")
    $ sename = "se人体_足音_走る01"
    play se sedict[sename]
    with Dissolve(300.0/1000)

    "Как только солнце зашло, я побежал по коридору в класс..."
    show expression ("cg/bg/"+imagename["bg010600_2_学校教室"]+".jpg")
    $ sename = "se物体_ドア教室_開く02"
    play se sedict[sename]
    with Dissolve(500.0/1000)

    "...но её там не было."

    "А это значит—"
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((1500.0+1000.0)/1000)
    pause (1000/1000)
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    $ sename = "se物体_ドア鉄_開く01"
    play se sedict[sename]
    pause (1000/1000)
    $ sename = "se環境_ガヤ_学校屋上"
    play se sedict[sename]
    with Dissolve((2000.0+0.0)/1000)
    hide 絵色黒
    with Dissolve(1000.0/1000)
    $ roof = True;
    xy "\"МИЮКИ!\""

    "Я открыл дверь, ведущую на крышу."

    xy "\"Вот ты где...\""
    show expression ("cg/bg/"+imagename["bg010210_2_学校屋上屋根向"]+".jpg")
    with Dissolve(500.0/1000)
    voice "voice/e11/58a00050a01.opus"

    mx "\"Ты пришёл за мной?\""
    voice "voice/e11/58a00060a01.opus"

    mx "\"Или...\""
    voice "voice/e11/58a00070a01.opus"

    mx "\"Ты здесь только ради ЭТОГО?..\""
    show expression ("cg/ef/"+imagename["efbg美雪のスマフォ屋根"]+".jpg") as 絵背景 zorder 1100 at center
    with Dissolve((1000.0+1000.0)/1000)
    pause (500/1000)

    "Миюки держала свой телефон."
    hide 絵背景
    with Dissolve(500.0/1000)
    pause (500/1000)

    xy "\"Миюки... что на тебя нашло?\""

    xy "\"Ты ведёшь себя довольно странно—\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
