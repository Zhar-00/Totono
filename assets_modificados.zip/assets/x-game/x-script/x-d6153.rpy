label d6153_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6154.nss"
    return
label d6153:
    hide 絵色黒
    $ sename = "se環境_ガヤ_教室ざわめくL"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010801_2_学校体育館演劇準備"]+".jpg")
    with Dissolve(0.0/1000)
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]
    pause (4000/1000)

    xy "\"...Какого?\""

    "Аой сейчас должна быть дома, но она не отвечает."

    "А телефон всё гудел, и гудел, и гудел."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
