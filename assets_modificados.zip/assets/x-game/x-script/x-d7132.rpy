label d7132_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a7133.nss"
    return
label d7132:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010600_1_学校教室"]+".jpg")
    with Dissolve(0.0/1000)

    xy "\"Только не опять...\""

    "Я узнаю этот листок."

    "—ПИСЬМО ОБ ИЗГНАНИИ."

    "Хотя, по-моему, меня уже «изгнали»..."

    "Но всё же, я прекрасно знаю, какие чувства он испытывает к Миюки."

    "Я должен собраться с силами и объясниться."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
