label a5162_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5163.nss"
    return
label a5162:
    hide 絵色黒
    $ renpy.music.play("ttb18",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    play voc "a51/6200010b04"
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_sad")
    with Dissolve(200.0/1000)
    voice "voice/a51/6200020a02.opus"
    aoi "Всё нормально. Аой продолжит поиски."
    xy "Но ты чувствуешь себя неважно, разве нет? Мне кажется, ты должна передохнуть, и—"
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_normal")
    with Dissolve(200.0/1000)
    voice "voice/a51/6200030a02.opus"
    aoi "Аой продолжит поиски."
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_pain")
    with Dissolve(200.0/1000)
    voice "voice/a51/6200040a02.opus"
    aoi "Аой... должна продолжать искать..."
    xy "......"
    hide StC
    hide StMR
    hide StML
    hide 絵背景
    with Dissolve(500.0/1000)
    "Я так и знал. Она так и не оправилась."
    "Но она отказывалась следовать моему совету."
    "Думаю, мне оставалось только поторопиться и найти её телефон—"
    "Стоп... Телефон?.."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
