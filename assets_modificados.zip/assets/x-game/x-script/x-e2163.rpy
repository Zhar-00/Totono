label e2163_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2163:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg070100_2_雑貨店店内"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",740,0,0,"bu曽根美雪_制服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e21/6300010a01.opus"

    mx "\"О-о-о! Она такая милая!\""

    "Миюки показала на заколку в форме кошки на витрине у окна."
    if persistent.eternal_day or persistent.eternal_day:
        $ GameName = "e2163b.nss";
    else:
        $ GameName = "e2163a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
