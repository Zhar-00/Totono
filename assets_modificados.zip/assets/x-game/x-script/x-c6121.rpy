label c6121_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6131.nss"
    return
label c6121:
    hide 絵色黒
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    show expression ("cg/bg/l/"+imagename["bg020100_2_自宅外正面_l"]+".jpg") as 絵背景 zorder 110:
        pos (-750,-470)
    show expression ("cg/bg/"+imagename["bg020100_2_自宅外正面"]+".jpg")
    with Dissolve(0.0/1000)

    "Дело в том, что Аой последние пару дней была будто сама не своя."

    "Её искра полностью исчезла. Она как будто... выживала каждый день, от одного момента к другому."

    "Я предположил, что она была физически больна, но..."
    $ sename = "se物体_ドア自宅_開く"
    play se sedict[sename]
    pause (500/1000)
    xy "\"......!!!\""

    "Звук открывающейся двери заставил меня вздрогнуть."
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    voice "voice/c61/2100010a02.opus"
    aoi "\"Буп-буп!\""

    "Аой вышла наружу, её лицо по-прежнему было красным."

    "Я сказал ей остаться дома и отдохнуть."

    "Но вот она здесь, нарушает наше обещание."

    "Она посмотрела на кошачью заколку в своей руке."
    $ St("C",300,0,0,"st向日アオイ_制服_よろけ_sad")
    with Dissolve(200.0/1000)
    voice "voice/c61/2100020a02.opus"
    aoi "\"Шиничи...\""
    $ St("C",300,0,0,"st向日アオイ_制服_よろけ_pain")
    with Dissolve(200.0/1000)
    voice "voice/c61/2100030a02.opus"

    aoi "\"Пожалуйста, прости меня...\""
    $ sename = "se人体_足音_歩く01遅L"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    stop se fadeout (2000.0/1000)
    pause (2000/1000)

    "Прошептав это, она продолжила слоняться по улице в приступе лихорадки."
    xy "......"

    "Болезненная мольба Аой не переставала звучать в моих ушах."

    "Прикусив губу, я принял решение."

    "Я не могу пропустить эту небольшую экскурсию."
    show expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg")
    hide 絵背景
    with Dissolve(500.0/1000)
    pause (500/1000)

    "Я вылез из кустов и начал идти за ней."
    voice "voice/c61/2100040a02.opus"

    aoi "\"Буп-буп... буп...\""
    show expression ("cg/bg/"+imagename["bg040400_2_街交差点"]+".jpg")
    with Dissolve(500.0/1000)
    pause (500/1000)

    "Она ковыляла так, будто шла по облакам."

    "Как будто она шла по невидимому сигналу."

    "А потом она ушла с дороги к школе, и..."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
