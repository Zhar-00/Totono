label e3432a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e3432a:
    hide 絵色黒
    $ renpy.music.play("ttb14",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg010300_9_学校屋根"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e34/32a00010b02.opus"

    kmsm "\"ТРЕБУЕТСЯ ПОДТВЕРЖДЕНИЕ.\""
    voice "voice/e34/32a00020b02.opus"

    kmsm "\"[[ТЫ] ПРАВДА ХОЧЕШЬ ЗАВЕРШИТЬ ИГРУ?\""
    menu:
        "Завершить игру":
            $ SetChoiceSelect = 0
        "Не важно":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "e3433a.nss";
    elif SetChoiceSelect==1:
        $ GameName = "e3432b.nss";
    if (active_time <= 0):
        $ GameName = "e3424h.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
