label e2233a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2233a:
    hide 絵色黒
    call eroute_bgm
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    with Dissolve(0.0/1000)
    voice "voice/e22/33a00010a01.opus"
    mx "\"Н-нгх...\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "Миюки поднялась, чтобы сесть на верх парты, и скрестила ноги."
    "Это был, эм... очень сексуальный вид, если можно так выразиться."
    "Её юбка приподнялась под дуновением ветра, и я почувствовал, как мой взгляд притянулся к её ногам, словно магнитом..."
    voice "voice/e22/33a00020a01.opus"
    mx "\"Красивый вид, да?\""
    xy "\"Я не подсматривал!\""
    voice "voice/e22/33a00030a01.opus"
    mx "\"...Какой «вид», по-твоему, я имела в виду?\""
    xy "\"А? А, эм... Ха-ха-ха-ха-ха...\""
    voice "voice/e22/33a00040a01.opus"
    mx "\"Ну да ладно.\""
    if (persistent.miyuki_sex_promise):
        $ GameName = "e2234b.nss";
    else:
        $ GameName = "e2234a.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
