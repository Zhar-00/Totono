label a5165_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a5171.nss"
    return
label a5165:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    show expression ("cg/ev/"+imagename["eva5163アオイ汗拭き"]+".jpg") as 絵専 zorder 1000 at truecenter
    $ sename = "se物体_インターホン_鳴る"
    play se sedict[sename]
    with Dissolve(200.0/1000)
    pause (2000/1000)
    "И вдруг зазвенел дверной звонок, от чего мы оба замерли словно олени в свете фонарей."
    xy "...Прости. Кажется, у нас гости."
    $ sename = "se人体_動作_起き上がる02"
    play se sedict[sename]
    hide 絵専
    with Dissolve(500.0/1000)
    xy "Я позвал сюда Ютаро. Мы вдвоём поможем тебе, ладно?"
    xy "Вот, надень это. Я знаю, что она тебе слишком великовата, но тебе придётся!"
    xy "Обязательно надень её перед моим возвращением, ладно? Можешь пообещать мне это?"
    xy "Просто надень её, ладно?"
    "Я отдал ей одну из своих старых футболок и быстро вышел из комнаты."
    $ sename = "se物体_ドア室内_閉まる01"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    pause (500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
