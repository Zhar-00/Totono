label a0121_MAIN:
    call expression GameName
    $ persistent.imagelog["eva0121美雪さんおはようございます"]=True
    $ persistent.imagelog["eva0121美雪バット突きつけa"]=True
    $ persistent.imagelog["eva0121美雪バット突きつけb"]=True
    $ persistent.imagelog["eva0121美雪初めてのチューa"]=True
    $ persistent.imagelog["eva0121美雪初めてのチューb"]=True
    $ persistent.imagelog["bg010210_2_学校屋上屋根向"]=True
    $ PreGameName = GameName
    $ GameName = "a0122.nss"
    return
label a0121:
    scene expression ("cg/bg/"+imagename["bg010210_2_学校屋上屋根向"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg010210_2_学校屋上屋根向_l"]+".jpg") as 絵背景:
        pos (-920,-390)
    stop bgm fadeout (200/1000)
    $ sename = "se物体_ドア鉄_閉まる01"
    play se sedict[sename]
    $ sename = "se物体_ドア鉄_開く02"
    play se sedict[sename]
    voice "voice/a01/2100010a01.opus"
    mx "Ого. Для вас нет ничего святого?"
    show expression ("cg/ev/l/"+imagename["eva0121美雪バット突きつけa_l"]+".jpg") as 絵専:
        pos (-1141,-319)
    show expression ("cg/ev/l/"+imagename["eva0121美雪バット突きつけa_l"]+".jpg") as 絵専:
        pos (-1141,-319)
    $ sename = "se物体_バット_振る"
    play se sedict[sename]
    pause (500/1000)
    show expression Solid("FFFFFF") as 絵色白
    pause (100/1000)
    hide 絵色白 with Dissolve(70/1000)
    show expression ("cg/ev/l/"+imagename["eva0121美雪バット突きつけa_l"]+".jpg") as 絵専:
        pos (-1141,-319)
        zoom 1.2
    show expression ("cg/ev/l/"+imagename["eva0121美雪バット突きつけa_l"]+".jpg") as 絵専:
        pos (-1141,-319)
        zoom 1.2
        pause 0.5
        linear .4 pos (-202,-105)
    pause (200/1000)
    voice "voice/a01/2100020a01.opus"
    mx "Чем это вы занимаетесь на крыше нашей почитаемой академии?"
    xy "М-Миюки?"
    xy "Чем я занимаюсь? Ну..."
    show expression ("cg/ev/l/"+imagename["eva0113アオイ屋上覆い被さりa_l"]+".jpg") as 絵専上:
        pos (-156,-178)
    with Dissolve(1.5)
    with Dissolve((500+1000)/1000)
    voice "voice/a01/2100030a02.opus"
    bm "Перезарядка."
    voice "voice/a01/2100040a01.opus"
    mx "Что?"
    voice "voice/a01/2100050a02.opus"
    bm "Мы занимаемся сексом."
    voice "voice/a01/2100060a01.opus"
    mx "Что?!"
    xy "Что?!"
    voice "voice/a01/2100070a02.opus"
    bm "Поцелуй активировал флаг события."
    $ sename = "se物体_バット_振る"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白
    pause (30/1000)
    with Dissolve((0+0)/1000)
    hide 絵専上
    hide 絵色白 with Dissolve(70/1000)
    voice "voice/a01/2100080a01.opus"
    mx "Я услышала достаточно!"
    "Миюки замахнулась своей бейсбольной битой."
    voice "voice/a01/2100090a01.opus"
    mx "Не обращайся с Шиничи как со своей игрушкой!"
    xy "Д-да! Я тебе не игрушка!"
    voice "voice/a01/2100100a01.opus"
    mx "Ш-Шиничи... он... Он!.."
    show expression ("cg/ev/l/"+imagename["eva0121美雪バット突きつけb_l"]+".jpg") as 絵専差分:
        pos (-202,-105)
        zoom 1.2
    with Dissolve(1.8)
    with Dissolve((800+1000)/1000)
    pause (500/1000)
    voice "voice/a01/2100110a01.opus"
    mx "Он мой парень!"
    pause (500/1000)
    xy "......Что?"
    show expression ("cg/ev/m/"+imagename["eva0121美雪さんおはようございます_m"]+".jpg") as 絵専上上:
        pos (-276,-102)
        linear 15 pos (-190,-102)
    with Dissolve(1.5)
    with Dissolve((500+1000)/1000)
    $ renpy.music.play("ttb12",channel = "bgm", if_changed = True)
    "Я дружил с Миюки Сонэ ещё с самого детства."
    "В начальной школе мы всё время играли вместе, но мы отдалились друг от друга, когда повзрослели. Такое со многими происходит."
    "В то время как я скитался всю свою жизнь без каких-либо увлечений, она очень быстро доказала, что может освоить всё, за что только возьмётся."
    "Учитывая её внешность, ум, спортивные навыки и природный талант к актёрству, она почти что мгновенно стала королевой школы."
    "Ходят слухи, что она получила свыше десятка признаний в любви в течение своего первого месяца в этой школе."
    "Можно было сказать, что два слуха распространились от девушек, а один из них – даже от учителя."
    "И она, вроде бы, отшила их всех."
    "Но ещё поговаривают, что один из парней отказался принимать «нет» как ответ... и она была вынуждена отбиваться от него бейсбольной битой."
    "Она довольно известная, местные ученики, похоже, не могут перестать говорить о ней."
    "А ещё есть я... абсолютно неизвестный человек."
    "Я был невидимым для всех и почти что смешивался с воздухом."
    "Мягкий, безобидный, и двух минут нигде не может продержаться."
    "Легко забываемый неиграбельный персонаж в ролевой игре под названием «жизнь»."
    "Я едва ли даже достоин дышать тем же воздухом, что и она."
    "От одного лишь пребывания рядом с ней я начинаю нервничать."
    "В общем, да, я типа очень далёкий от—"
    show expression ("cg/ev/"+imagename["eva0121美雪バット突きつけb"]+".jpg") as 絵専差分 zorder 1120 at center
    with Dissolve(1)
    xy "Твой... парень?.."
    voice "voice/a01/2100120a01.opus"
    mx "Замолчи!"
    voice "voice/a01/2100130a01.opus"
    mx "М-мы с Шиничи состоим в отношениях. Боюсь, у тебя нет шансов с ним."
    voice "voice/a01/2100140a01.opus"
    mx "Так ты можешь уйти уже?"
    show expression ("cg/ev/"+imagename["eva0113アオイ屋上覆い被さりa"]+".jpg") as 絵専上上上 zorder 1130 at center
    with Dissolve(1.5)
    with Dissolve((500+1000)/1000)
    voice "voice/a01/2100150a02.opus"
    bm "Это неправда."
    voice "voice/a01/2100160a02.opus"
    bm "Вы не встречаетесь."
    voice "voice/a01/2100170a01.opus"
    mx "Прошу прощения? Откуда ты зна—"
    voice "voice/a01/2100180a02.opus"
    bm "Я передатчик."
    voice "voice/a01/2100190a02.opus"
    bm "Бог отправил мне радиопередачу за пределами вселенной."
    "Э-э-э-эм..."
    "Это одна из тех так называемых радиоволновых систем?"
    hide 絵専
    hide 絵専上
    hide 絵専上上
    hide 絵専上上上
    hide 絵専差分
    show expression ("cg/bg/"+imagename["bg010200_2_学校屋上"]+".jpg")
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with dissolve
    voice "voice/a01/2100200a01.opus"
    mx "Ну да ладно. Разговор с тобой – пустая трата воздуха."
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_shout")
    with dissolve
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_shout")
    with Dissolve(.2)
    voice "voice/a01/2100210a01.opus"
    mx "Слушай сюда: мы с Шиничи давно знаем друг друга. И поэтому, как его подруга—"
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with dissolve
    voice "voice/a01/2100220a02.opus"
    bm "Я поняла!"
    "Она подняла свою руку, прервав тем самым Миюки."
    voice "voice/a01/2100230a02.opus"
    bm "Ты персонаж, который является подругой детства."
    voice "voice/a01/2100240a02.opus"
    bm "Твои истинные чувства – загадка."
    voice "voice/a01/2100250a02.opus"
    bm "Основное звено визуальных новелл."
    voice "voice/a01/2100260a01.opus"
    mx "Визуальных новелл?.."
    xy "А, ты имеешь в виду такие новеллы, как эта?"
    "Я показал телефон, который нашёл раньше."
    $ sename = "se環境_衝撃_電気"
    play se sedict[sename]
    $ renpy.vibrate(.3)
    show expression Solid("FFFFFF") as 絵色白
    pause (30/1000)
    pause (20/1000)
    hide 絵色白 with Dissolve(100/1000)
    xy "Воу!"
    $ sename = "se物体_携帯_落ちる01"
    play se sedict[sename]
    "Я только что почувствовал статическое электричество?!"
    $ St("C",300,0,0,"st向日アオイ電波_制服_密着_normal")
    with dissolve
    voice "voice/a01/2100270a02.opus"
    bm "Ворюга."
    "Телефон выпал из моих уже онемевших пальцев. Она ловко поймала его и посмотрела на меня с презрением."
    xy "Я не крал его. Он лежал вон там."
    voice "voice/a01/2100280a02.opus"
    bm "Вон там?"
    xy "Да."
    voice "voice/a01/2100290a02.opus"
    bm "......"
    pause (100/1000)
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    with dissolve
    voice "voice/a01/2100300a02.opus"
    bm "То есть, я перед тобой в долгу?"
    xy "Ну, я бы так не сказал, но—"
    $ St("C",300,0,0,"bu向日アオイ電波_制服_挙手_shout")
    with dissolve
    voice "voice/a01/2100310a02.opus"
    bm "Я заглажу перед тобой свою вину."
    xy "Э-эм?.."
    $ sename = "se人体_動作_衣擦れ01"
    play se sedict[sename]
    show expression ("cg/ev/m/"+imagename["eva0113アオイ屋上覆い被さりa_m"]+".jpg") as 絵専 zorder 1100 at center
    with Dissolve(1.2)
    voice "voice/a01/2100320a02.opus"
    bm "Давай подзарядимся."
    stop bgm fadeout (200/1000)
    voice "voice/a01/2100330a01.opus"
    mx "А ну стоять!"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with Dissolve(0/1000)
    hide 絵専 with dissolve
    "Миюки явно дрожала от ярости."
    voice "voice/a01/2100340a01.opus"
    mx "Как ты меня там назвала? Персонаж, который является подругой детства?"
    voice "voice/a01/2100350a01.opus"
    mx "Ты серьёзно сравниваешь меня с персонажем в видеоигре?"
    voice "voice/a01/2100360a02.opus"
    bm "Ага."
    $ sename = "se物体_バット_地面叩く"
    play se sedict[sename]
    pause (1000/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_shout")
    with dissolve
    voice "voice/a01/2100370a01.opus"
    mx "Окстись!"
    "Она ударила своей битой по бетонной крыше."
    voice "voice/a01/2100380a01.opus"
    mx "Жизнь – это не видеоигра!"
    voice "voice/a01/2100390a01.opus"
    mx "Ты слышишь меня? Мои чувства вполне реальны. Меня невозможно сравнить с каким-то персонажем из видеоигры—"
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_shout")
    with dissolve
    voice "voice/a01/2100400a02.opus"
    bm "А, поняла!"
    "Тон голоса Миюки уже был полон гнева, но девушка подняла свою руку так, будто не замечала этого."
    voice "voice/a01/2100410a02.opus"
    bm "Можешь поцеловать его?"
    voice "voice/a01/2100420a01.opus"
    mx "......Чего?"
    voice "voice/a01/2100430a02.opus"
    bm "Если вы правда встречаетесь, то ты можешь поцеловать его, верно?"
    voice "voice/a01/2100440a01.opus"
    mx "Чт... Это ведь не имеет никакого отношения к—"
    voice "voice/a01/2100450a02.opus"
    aoi "Поцелуй его. Прямо сейчас."
    $ St("C",300,0,0,"st向日アオイ電波_制服_挙手_normal")
    with dissolve
    voice "voice/a01/2100460a02.opus"
    bm "Это должно быть легко, верно?"
    voice "voice/a01/2100470a01.opus"
    mx "......!!!"
    "Лицо Миюки стало настолько красным, что оно выделялось даже на фоне заката."
    $ St("C",300,0,0,"st曽根美雪_制服_通常_angry")
    with dissolve
    voice "voice/a01/2100480a01.opus"
    mx "Л-ладно!"
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_shy")
    with dissolve
    voice "voice/a01/2100490a01.opus"
    mx "Что значит поцелуй между любовниками?"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with dissolve
    voice "voice/a01/2100500a01.opus"
    mx "П-практически ничего..."
    voice "voice/a01/2100510a01.opus"
    mx "......"
    voice "voice/a01/2100520a01.opus"
    mx "Я смогу... я смогу поцеловать его... Но если мы... Н-н-н..."
    xy "Слушай, если ты против, то мы правда не должны—"
    $ St("C",300,0,0,"st曽根美雪_制服_通常_angry")
    with dissolve
    voice "voice/a01/2100530a01.opus"
    mx "Я вовсе не против!"
    $ sename = "se物体_バット_転がる"
    play se sedict[sename]
    show expression ("cg/ev/"+imagename["eva0121美雪初めてのチューa"]+".jpg") as 絵専 zorder 1100 at center
    with Dissolve(2)
    with Dissolve((1000+1000)/1000)
    pause (1500/1000)
    $ renpy.music.play("ttb02",channel = "bgm", if_changed = True)
    voice "voice/a01/2100540a01.opus"
    mx "По правде говоря... я всегда ждала этого момента."
    "В детстве мы были как два сапога пара."
    "Но когда мы расстались?"
    "Почему я начал отдаляться?"
    voice "voice/a01/2100550a01.opus"
    mx "Я очень рада, что ты попросил встретиться со мной здесь."
    xy "Миюки?.."
    "Она почти что прошептала это."
    voice "voice/a01/2100560a01.opus"
    mx "Это будет мой первый поцелуй..."
    voice "voice/a01/2100570a01.opus"
    mx "Но я подарю..."
    voice "voice/a01/2100580a01.opus"
    mx "...его..."
    voice "voice/a01/2100590a01.opus"
    mx "......"
    voice "voice/a01/2100600a01.opus"
    mx "......Н-н-н..."
    show expression ("cg/ev/"+imagename["eva0121美雪初めてのチューb"]+".jpg") as 絵専差分 zorder 1105 at center
    with Dissolve((500+1000)/1000)
    voice "voice/a01/2100610a01.opus"
    mx "Н-н-н-н-нг-г-гх-х-х-х!"
    stop bgm fadeout (200/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_恋人_angry")
    with Dissolve(0/1000)
    $ sename = "se人体_動作_衣擦れ01"
    play se sedict[sename]
    hide 絵専
    hide 絵専差分
    with Dissolve(200/1000)
    voice "voice/a01/2100620a01.opus"
    mx "Я не могу! Это слишком неловко!"
    voice "voice/a01/2100630a02.opus"
    aoi "Мило."
    voice "voice/a01/2100640a01.opus"
    mx "Я просто предпочитаю держать личные отношения в тайне, только и всего! Публичные проявления любви слишком бесстыдны!"
    voice "voice/a01/2100650a01.opus"
    mx "Скажи ей, Шиничи! Мы двое ведь в-в-встречаемся, так ведь?!"
    xy "Что? Я вовсе не—"
    voice "voice/a01/2100660a01.opus"
    mx "Разъясни это ей! Всё-таки ты сам позвал меня сюда!"
    voice "voice/a01/2100670a01.opus"
    mx "Твои действия заставили меня собраться с мыслями, и..."
    "Стоп, что?"
    xy "А что я сделал?"
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_angry")
    with dissolve
    voice "voice/a01/2100680a01.opus"
    mx "Не изображай тупицу! Я знаю, что это ты написал!"
    $ sename = "se物体_紙_取り出す"
    play se sedict[sename]
    pause (300/1000)
    "Миюки достала письмо из своего кармана."
    "—Кому: Мисс Миюки Сонэ"
    "—Я буду ждать тебя на крыше после занятий."
    "Подписи у самого письма не было."
    "Я такое письмо впервые вижу."
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with dissolve
    voice "voice/a01/2100690a01.opus"
    mx "Стоп... что? Стоп..."
    voice "voice/a01/2100700a01.opus"
    mx "Как только я посмотрела на него, это... не твой почерк..."
    $ sename = "se物体_ドア鉄_閉まる01"
    play se sedict[sename]
    stop bgm fadeout (500/1000)
    hide StC with None
    voice "voice/a01/2100710b01.opus"
    xtl "Простите за опоздание!"
    show expression ("cg/bg/l/"+imagename["bg010210_2_学校屋上屋根向_l"]+".jpg") as 絵演背景:
        pos (-920,-290)
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_pride")
    with Dissolve(0/1000)
    $ renpy.music.play("ttb03",channel = "bgm", if_changed = True)
    voice "voice/a01/2100720b01.opus"
    xtl "Я пришёл как раз вовремя! Ютаро Акебоно, капитан клуба «Ребята и мечты»!"
    "Ну конечно."
    "Это был тот идиот."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_smile")
    with dissolve
    voice "voice/a01/2100730b01.opus"
    xtl "Признание на крыше! Легендарный поцелуй! Два человека обменяются вечными любовными клятвами!"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_shy")
    with dissolve
    voice "voice/a01/2100740b01.opus"
    xtl "Да, вот она, мечта моей жизни! Я – галантный принц, а ты – прекрасная дева— а?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with dissolve
    voice "voice/a01/2100750b01.opus"
    xtl "Сонэ-сан?.."
    hide 絵板写 with Dissolve(500/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_hard")
    with dissolve
    voice "voice/a01/2100760a01.opus"
    mx "......!!!"
    "Пытаясь сдержаться изо всех сил, Миюки подошла к двери..."
    $ sename = "se物体_ドア鉄_閉まる01"
    play se sedict[sename]
    stop bgm fadeout (150/1000)
    stop bgm
    hide StC
    "...И захлопнула её за собой."
    $ sename = "se環境_ガヤ_学校屋上放課後L"
    play se sedict[sename]
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_angry")
    with dissolve
    voice "voice/a01/2100770b01.opus"
    xtl "ПОЧЕМУ-У-У?!"
    xy "Потрясающий ход, гений."
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_think")
    with dissolve
    voice "voice/a01/2100780b01.opus"
    xtl "Что? Неужели я что-то не так сказал?"
    $ St("C",300,0,0,"st曙雄太郎_制服_通常_angry")
    with dissolve
    voice "voice/a01/2100790b01.opus"
    xtl "Чёрт! Я должен был позволить всем своим мечтам остаться у меня в голове!"
    xy "Да-а-а, я сомневаюсь, что дело в этом..."
    "Забудем об этом. Я лучше оставлю объяснение на потом, иначе мы простоим здесь всю ночь."
    hide StC
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
