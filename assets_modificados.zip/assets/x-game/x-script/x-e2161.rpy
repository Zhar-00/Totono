label e2161_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2161:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg070100_2_雑貨店店内"]+".jpg") with ImageDissolve("cg/data/zzex_eyelid_01_00_0.png",(110.0/1000))
    $ st_timezone = "昼"
    $ sename = "se物体_カウベル_鳴る"
    play se sedict[sename]
    pause (300/1000)
    xy "\"М-м-м...\""

    xy "\"Кто бы не владел этим местом, он ОПРЕДЕЛЁННО обожает котов.\""
    voice "voice/e21/6100010a01.opus"

    mx "\"...Хе-хе...\""

    xy "\"Эм, Миюки? Твоё лицо?\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_gag")
    with Dissolve(200.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_angry")
    voice "voice/e21/6100020a01.opus"

    mx "\"А? Ох!\""

    xy "\"Знаешь, всякий раз, когда мы приходим сюда, ты будто становишься совсем другим человеком...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_shy")
    with Dissolve(200.0/1000)
    voice "voice/e21/6100030a01.opus"

    mx "\"...И?\""

    xy "\"Разве ты не покупала здесь что-нибудь на днях?\""
    if persistent.miyuki[24] == 0:
        voice "voice/e21/6100040a01.opus"

        mx "\"А, только сборник видео с котами на DVD...\""
    elif persistent.miyuki[24] == 1:
        voice "voice/e21/6100050a01.opus"

        mx "\"А, только компакт-диск с кошачьим ASMR...\""
    elif persistent.miyuki[24] == 2:
        voice "voice/e21/6100060a01.opus"

        mx "\"А, только игрушку, которая переводит с кошачьего на человеческий...\""
    xy "\"Ясно...\""

    xy "\"Ты всегда была настолько помешанной на котах?\""

    xy "\"Да и что вообще такого хорошего в них?\""
    if persistent.miyuki[9] == 0:
        $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
        with Dissolve(200.0/1000)
        voice "voice/e21/6100070a01.opus"

        mx "\"Их маленькие подушечки на пальцах! Они такие милые!\""

        xy "\"Должен признать, я ещё ни разу не трогал кошачьи лапы.\""
        voice "voice/e21/6100080a01.opus"

        mx "\"Я тоже.\""

        "Тогда зачем говорить об этом?!"
    elif persistent.miyuki[9] == 1:
        $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
        with Dissolve(200.0/1000)
        voice "voice/e21/6100090a01.opus"

        mx "\"Я не знаю, как объяснить это... Они просто... элегантные, понимаешь?\""

        xy "\"...Да, оно и видно.\""

        "У котов есть эта неприметная, независимая атмосфера, которая прекрасно подходила Миюки."
    elif persistent.miyuki[9] == 2:
        $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
        with Dissolve(200.0/1000)
        voice "voice/e21/6100100a01.opus"

        mx "\"И ещё эти их маленькие мяуканья! Я таю, словно масло, когда слышу их!\""

        xy "\"Понятно...\""

        "Интересно..."

    "Ну ладно, мы пришли сюда за подарком для Миюки."

    "Уверен, она будет в восторге, что бы я не выбрал."

    "Но... что мне выбрать?.."
    if persistent.eternal_day or persistent.eternal_day:
        $ GameName = "e2162c.nss";
    else:
        menu:
            "Кошачью пижаму":
                $ SetChoiceSelect = 0
            "Фоторамку":
                $ SetChoiceSelect = 1
        if SetChoiceSelect==0:
            $ persistent.miyuki_love -= 1
            $ GameName = "e2162a.nss";
        elif SetChoiceSelect==1:
            $ persistent.miyuki_love += 1
            $ GameName = "e2162b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
