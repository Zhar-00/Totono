label e3231_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e1111.nss"
    return
label e3231:
    hide 絵色黒
    pause (2000/1000)
    show expression ("cg/bg/"+imagename["bg110301_3_マンション寝室消灯"]+".jpg")
    $ st_timezone = "夜"
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_normal")
    with Dissolve(0.0/1000)
    voice "voice/e32/3100010a01.opus"
    mx "Эй, ТЫ."
    voice "voice/e32/3100020a01.opus"
    mx "ТЫ на меня сейчас злишься?"
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/e32/3100030a01.opus"
    mx "ТЫ считаешь, что Аой является нечто большим, чем просто вымышленный персонаж в видеоигре?"
    voice "voice/e32/3100040a01.opus"
    mx "ТЫ считаешь, что Аой - настоящий человек?"
    voice "voice/e32/3100050a01.opus"
    mx "И ТЫ думаешь, что кто-то намеренно испортил весь этот мир?"
    $ St("C",300,0,0,"fu曽根美雪_私服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/e32/3100060a01.opus"
    mx "Это то, во что ТЫ веришь?"
    voice "voice/e32/3100070a01.opus"
    mx "И ТЫ думаешь, что влюбиться в персонажа из видеоигры вполне возможно."
    $ St("C",300,0,0,"fu曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e32/3100080a01.opus"
    mx "ТЫ правда так думаешь, да?"
    voice "voice/e32/3100090a01.opus"
    mx "Поэтому ТЫ и сделал эти выборы, так ведь?"
    $ St("C",300,0,0,"fu曽根美雪_私服_病み_ero")
    with Dissolve(200.0/1000)
    voice "voice/e32/3100100a01.opus"
    mx "Ну, знаешь, что... я в это тоже верю."
    voice "voice/e32/3100110a01.opus"
    mx "Я верю, что ТЫ можешь влюбиться в меня."
    $ St("C",300,0,0,"fu曽根美雪_私服_恋人_ero")
    with Dissolve(200.0/1000)
    voice "voice/e32/3100120a01.opus"
    mx "ТЫ точно можешь, верно?"
    pause (1000/1000)
    $ persistent.aoi_unreal = True
    scene expression Solid("000000") as 絵色黒
    pause (16/1000)
    hide 上背景
    pause (1500/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
