label e2132b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2133.nss"
    return
label e2132b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    show expression ("cg/ef/"+imagename["efbgヤバトマ"]+".jpg") as 絵演効果 zorder 100 at truecenter
    with Dissolve(0.0/1000)

    xy "\"Наверное, чай.\""
    pause (16/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    hide 絵演効果
    with Dissolve(600.0/1000)
    voice "voice/e21/32b00010a01.opus"

    mx "\"Так я и думала. Я знала, что ты терпеть не можешь томатный сок.\""

    xy "\"Эм, но я всё ещё могу его выпить.\""
    $ sename = "se物体_缶_開ける"
    play se sedict[sename]
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    voice "voice/e21/32b00020a01.opus"
    mx "\"Гл-л-л-л... гл-л-л-л... гл-л-л-л...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_hard")
    with Dissolve(200.0/1000)
    voice "voice/e21/32b00030a01.opus"

    mx "\"Ага... На вкус как томат, ладно...\""

    "Миюки состроила гримасу от отвращения."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
