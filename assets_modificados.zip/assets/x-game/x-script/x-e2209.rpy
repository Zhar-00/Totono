label e2209_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3111.nss"
    return
label e2209:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_2_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    voice "voice/e22/0900010a01.opus"

    mx "\"Дай угадаю... Ты думаешь, она говорит правду?\""

    xy "\"Конечно же нет! Я ни за что не поверю в такую бредятину!\""

    xy "\"Она сказала мне, что я не могу отличить реальность от вымысла... Что Аой на самом деле настоящая... Пф-ф...\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/e22/0900020a01.opus"

    mx "\"Ну, я не удивлена, что ты так думаешь.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/0900030a01.opus"

    mx "\"В таком случае, я спущу тебя с крючка на этот раз.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_normal")
    with Dissolve(200.0/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_sad")
    voice "voice/e22/0900040a01.opus"

    mx "\"Но... Посмотрим...\""

    "Миюки отвернулась и начала бормотать себе под нос, её взгляд был прикован к какому-то далёкому миру, который был виден только ей."
    $ St("C",300,0,0,"bu曽根美雪_制服_病み_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/0900050a01.opus"

    mx "\"Теперь, когда ТЫ узнал об этом, я должна придумать контрмеру.\""
    pause (16/1000)
    scene expression "cg/bg/black.jpg" as 絵色黒 zorder 1000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(1100/1000))
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
