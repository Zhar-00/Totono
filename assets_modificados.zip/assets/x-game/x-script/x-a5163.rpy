label a5163_MAIN:
    call expression GameName
    $ persistent.imagelog["eva5163アオイ汗拭き"]=True
    $ persistent.imagelog["bg030401_3_自宅廊下消灯"]=True
    $ PreGameName = GameName
    $ SelectGameName = GameName+"_SELECT"
    call expression SelectGameName
    return
label a5163:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    with Dissolve(0.0/1000)
    xy "Эй, Аой? Я скоро вернусь."
    show expression Solid("000000") as 絵色黒 zorder 5000
    $ renpy.music.play("ttb17",channel = "bgm", if_changed = True)
    with Dissolve((1000.0+1000.0)/1000)
    pause (500/1000)
    $ sename = "se人体_足音_階段自宅上がる01"
    play se sedict[sename]
    pause (500/1000)
    "Я поднялся по лестнице в свою комнату."
    "У меня всё ещё был тот телефон, который я одолжил у Ютаро."
    "И та визуальная новелла помогла мне отследить местоположение Аой пару дней назад."
    "В тот момент я думал, что Аой просто отыгрывала сцены из неё."
    "Но что, если игра и правда предсказывает те события, которые произойдут в реальной жизни?"
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    $ st_timezone = "昼"
    show expression ("cg/ef/"+imagename["efbg雄太郎のスマフォ"]+".jpg") as 絵演出 zorder 100 at truecenter
    $ sename = "se物体_ドア室内_閉まる01"
    play se sedict[sename]
    pause (500/1000)
    hide 絵色黒
    with Dissolve(800.0/1000)
    "Я знаю... Похоже, у меня самого уже начала развиваться сильная игровая зависимость."
    "Но это всё, что мне сейчас нужно."
    "По крайней мере, попробовать стоит."
    "Я включил телефон и загрузил игру."
    "Мой файл сохранения привёл меня к тому моменту, где «Аой» обнимала котёнка в спортзале."
    "Я незамедлительно нажал на кнопку пропуска."
    "Другие сцены начали быстро пролетать..."
    "Одна за другой..."
    hide 絵演出
    $ sename = "se物体_ドア室内_開く03"
    play se sedict[sename]
    pause (700/1000)
    with Dissolve(300.0/1000)
    voice "voice/a51/6300010a02.opus"
    aoi "Это бесполезно..."
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_sad")
    with Dissolve(200.0/1000)
    "Я оглянулся и увидел, как Аой держалась за стену, отчаянно пытаясь устоять на ногах."
    voice "voice/a51/6300020a02.opus"
    aoi "Этого события нет... в скрипте игры..."
    $ St("C",300,0,0,"st向日アオイ電波_制服_よろけ_pain")
    with Dissolve(200.0/1000)
    voice "voice/a51/6300030a02.opus"
    aoi "Произошёл глюк... во вселенной..."
    $ sename = "se人体_衝撃_転倒02"
    play se sedict[sename]
    hide StC with Dissolve(200.0/1000)
    xy "Воу! Аой! Ты в порядке?!"
    voice "voice/a51/6300040a02.opus"
    aoi "У меня батарейка... села..."
    voice "voice/a51/6300050a02.opus"
    aoi "Одной простой сценки... не... достаточно..."
    xy "Что ты там бормочешь?! Погоди, сейчас я вызову скорую—"
    voice "voice/a51/6300060a02.opus"
    aoi "Это не... обычная болезнь. Без своего телефона... Аой не сможет... сохранить игру..."
    voice "voice/a51/6300070a02.opus"
    aoi "Бог... бросил меня... Вот и всё... Всё кончено..."
    xy "Это ещё НЕ конец!"
    voice "voice/a51/6300080a02.opus"
    aoi "Буп... буп?.."
    xy "Если твой бог тебе не помогает, то я помогу тебе! Ты не можешь решить, когда всё закончится!"
    xy "В смысле... для чего ещё нужны друзья?"
    voice "voice/a51/6300090a02.opus"
    aoi "Др... у... зья..."
    voice "voice/a51/6300100a02.opus"
    aoi "Мы... друзья?.."
    xy "Ясен хрен!"
    "Аой какое-то время смотрела на пол и неразборчиво бормотала себе под нос так, будто наслаждалась самой концепцией этого."
    "А потом она подняла голову и посмотрела мне прямо в глаза."
    voice "voice/a51/6300110a02.opus"
    aoi "...Холодно."
    xy "А, точно. Мы должны вытереть пот с твоего лица."
    xy "Сейчас вернусь."
    $ sename = "se人体_足音_階段自宅上がる01"
    play se sedict[sename]
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((500.0+1000.0)/1000)
    pause (300/1000)
    "Я не мог закрыть глаза на её состояние."
    "Должен же быть какой-то способ доставить её к врачу..."
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    hide 絵色黒
    with Dissolve(500.0/1000)
    "Но мне нужна помощь."
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]
    "В такие моменты, есть только один человек, на которого я могу положиться."
    $ sename = "se物体_携帯_繋がる"
    play se sedict[sename]
    pause (300/1000)
    voice "voice/a51/6300120b01.opus"
    xtl "Привет, чел! Как проходит твоя ночь?"
    voice "voice/a51/6300130b01.opus"
    xtl "Стоп, только не говори мне... Ты нашёл новый артефакт мужских амб—"
    xy "Извини, но я сейчас в плохом положении. Аой нездоровится."
    voice "voice/a51/6300140b01.opus"
    xtl "Муко? Что случилось?"
    xy "Я не могу это объяснить, но мне нужна твоя помощь."
    voice "voice/a51/6300150b01.opus"
    xtl "Где мы встретимся?"
    xy "У меня дома. Нормально будет?"
    voice "voice/a51/6300160b01.opus"
    xtl "Ну да, разумеется! Как твой капитан, я обязан протянуть тебе руку помощи в трудные времена!"
    xy "Спасибо. Я правда перед тобой в долгу."
    voice "voice/a51/6300170b01.opus"
    xtl "Просто предоставь это мне!"
    $ sename = "se物体_携帯_操作音01"
    play se sedict[sename]
    pause (300/1000)
    "Ютаро просто так взял и согласился помочь мне, без каких-либо вопросов."
    "Порой он бывает откровенно несносным, но он всегда доводит дело до конца, когда это имеет большое значение; именно за это он мне и нравится."
    "Ладно, теперь, когда помощь уже в пути... что дальше?"
    show expression ("cg/bg/"+imagename["bg030401_3_自宅廊下消灯"]+".jpg")
    with Dissolve(500.0/1000)
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    "Я взял полотенце и вернулся в свою комнату."
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    with Dissolve(300.0/1000)
    stop se fadeout (150.0/1000)
    stop bgm fadeout (3000.0/1000)
    show expression ("cg/bg/l/"+imagename["bg030100_3_自宅自室_l"]+".jpg") as 絵背景:
        pos (-1024,-576)
    xy "Я вернул... {nw=2}"
    $ sename = "se人体_動作_抱きつく02"
    play se sedict[sename]
    with Dissolve((100.0+1000.0)/1000)
    extend "ся..."
    voice "voice/a51/6300180a02.opus"
    aoi "Привет."
    "Я тут же отвёл свой взгляд."
    "Аой сняла верхнюю часть своей одежды, обнажив свою фарфорово-белую кожу."
    voice "voice/a51/6300190a02.opus"
    aoi "Вытри меня всю..."
    voice "voice/a51/6300200a02.opus"
    aoi "Пожалуйста..."
    xy "Х-хорошо..."
    $ sename = "se人体_足音_歩く自宅床"
    play se sedict[sename]
    "Продолжая отводить свой взгляд, я подошёл к ней."
    "Я мог услышать её затруднённое дыхание."
    "И я чувствовал, как мой взгляд притягивается к ней, словно магнит."
    "Борясь с желанием посмотреть на неё, я осторожно расправил полотенце."
    xy "Л-ладно, поехали..."
    voice "voice/a51/6300210a02.opus"
    aoi "Прости, Миюки."
    xy "А? Ты что-то ска—"
    voice "voice/a51/6300220a02.opus"
    aoi "Шиничи, посмотри на меня."
    xy "А?.."
    voice "voice/a51/6300230a02.opus"
    aoi "Посмотри на меня!"
    "Я мог услышать отчаяние в её голосе."
    "Я спокойно выполнил её просьбу."
    $ renpy.music.play("ttb07",channel = "bgm", if_changed = True)
    hide 絵背景
    show expression ("cg/ev/"+imagename["eva5163アオイ汗拭き"]+".jpg") as 絵専 zorder 1000 at truecenter
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    "Её оголённая кожа была буквально покрыта потом."
    "У неё тряслись плечи."
    "И я мог увидеть набухание её маленькой, стройной груди."
    pause (500/1000)
    voice "voice/a51/6300240a02.opus"
    aoi "Прикоснись ко мне."
    xy "Стоп... Прикоснуться к тебе?!.."
    voice "voice/a51/6300250a02.opus"
    aoi "У Аой села батарейка."
    voice "voice/a51/6300260a02.opus"
    aoi "Не хватает заряда."
    voice "voice/a51/6300270a02.opus"
    aoi "Аой была создана для того, чтобы собирать сценки событий."
    voice "voice/a51/6300280a02.opus"
    aoi "Без них батарейка Аой будет разряжена в ноль."
    voice "voice/a51/6300290a02.opus"
    aoi "А потом Аой исчезнет навсегда."
    "На ум пришли два слова: игровая зависимость."

    "Но я выкинул эту мысль из головы."
    "Чувства Аой были настоящими."
    "И она сейчас страдает."
    voice "voice/a51/6300300a02.opus"
    aoi "Аой... не хочет... исчезать..."
    voice "voice/a51/6300310a02.opus"
    aoi "Особенно после знакомства с тобой..."
    voice "voice/a51/6300320a02.opus"
    aoi "Пожалуйста, не отбирай у меня эти воспоминания..."
    voice "voice/a51/6300330a02.opus"
    aoi "Мы не должны быть больше, чем друзьями..."
    voice "voice/a51/6300340a02.opus"
    aoi "Пожалуйста, просто... подзаряди меня своей «перезарядкой»..."
    return
label a5163_SELECT:
    $ renpy.save("lastsel")
    $ renpy.music.play("ttb07",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030100_3_自宅自室"]+".jpg")
    show expression ("cg/ev/"+imagename["eva5163アオイ汗拭き"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    menu:
        "Подзарядить её":
            $ SetChoiceSelect = 0
        "Не подзаряжать":
            $ SetChoiceSelect = 1
    if SetChoiceSelect==0:
        $ GameName = "a5164a.nss"
    else:
        $ GameName = "a5164b.nss"
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
