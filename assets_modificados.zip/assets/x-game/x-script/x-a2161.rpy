label a2161_MAIN:
    call expression GameName
    $ persistent.imagelog["bg010800_2_学校体育館"]=True
    queue bgm "ttb09"
    $ PreGameName = GameName
    $ GameName = "a2171.nss"
    return
label a2161:
    hide 絵色黒
    scene expression ("cg/bg/"+imagename["bg010800_2_学校体育館"]+".jpg")
    with Dissolve(1000.0/1000)
    $ st_timezone = "昼"
    $ sename = "se物体_ドア体育_開く01"
    play se sedict[sename]
    with Dissolve(1000.0/1000)
    xy "Простите, что прерываю..."
    stop se fadeout (1000.0/1000)
    "Я выглянул за дверь."
    "В спортзале не было ни души."
    "Репетиция уже закончилась?"
    "Единственный слышимый здесь звук – слабый гул сценического освещения."
    xy "Эм... Миюки?"
    voice "voice/a21/6100010a02.opus"
    aoi "Я чувствую прилив сил... Миюки вон там."
    $ sename = "se人体_足音_歩く美雪体育館"
    play se sedict[sename]
    xy "Что за?! Аой, ты что делаешь?!"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a21/6100020a02.opus"
    aoi "Буп-буп... Шиничи, ты тоже идёшь?"
    xy "Д-да! Конечно!"
    hide StC with Dissolve(200.0/1000)
    "Её выражение лица было всё таким же пустым, но она выглядела необычайно энергичной..."
    show expression ("cg/bg/l/"+imagename["bg010800_2_学校体育館_l"]+".jpg") as 絵背景 zorder 100:
        pos (-1520,-1200)
        zoom 2
    with Dissolve(500.0/1000)
    "Я побежал за ней следом за кулисы."
    $ sename = "se物体_ドア鉄_開く01"
    play se sedict[sename]
    pause (1000/1000)
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_surprise")
    with Dissolve(200.0/1000)
    voice "voice/a21/6100030b03.opus"
    bm "......?!"
    xy "О, привет."
    "Кто-то вышел из кладовки с реквизитом."
    xy "Прости за беспокойство. Мы тут ищем—"
    $ St("C",300,0,0,"st曙龍二郎_制服_通常_pinch")
    with Dissolve(200.0/1000)
    $ renpy.music.play("ttb09",channel = "bgm", if_changed = True)
    voice "voice/a21/6100040b03.opus"
    bm "А-А-А-А-А-А-А-А-А-А-А-А-А!!!"
    hide StC
    hide StMR
    hide StML
    with Dissolve(100.0/1000)
    $ sename = "se物体_ドア鉄_閉まる01"
    play se sedict[sename]
    pause (500/1000)
    "Она тут же заскочила обратно и закрыла дверь."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/6100050a02.opus"
    aoi "Она убежала."
    xy "Я что-то не так сказал?.."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_think")
    with Dissolve(200.0/1000)
    voice "voice/a21/6100060a02.opus"
    aoi "Ты расстроен?"
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    "А кто бы тут не расстроился? Милая девушка только что посмотрела на меня и убежала, крича!"
    $ sename = "se物体_ドア鉄_回す"
    play se sedict[sename]
    pause (600/1000)
    voice "voice/a21/6100070b03.opus"
    bm "Эм... А-а-а..."
    xy "О. Ещё раз привет."
    voice "voice/a21/6100080a02.opus"
    aoi "Она вернулась!"
    "Она выглядывала через щель в двери."
    voice "voice/a21/6100090b03.opus"
    bm "Мне... мне очень жаль! Я просто довольно стеснительная, и поэтому, увидев знакомое лицо, тут же испугалась..."
    voice "voice/a21/6100100b03.opus"
    bm "Вы ищете Сонэ-семпай, верно? Я... я отведу вас к ней."
    $ sename = "se物体_ドア鉄_閉まる02"
    play se sedict[sename]
    "После этого она исчезла в кладовке с реквизитом, осторожно закрыв дверь за собой."
    "Какая робкая девушка... Стоп, что?"
    "Она узнала меня в лицо?"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/a21/6100110a02.opus"
    aoi "Новый романтический выбор. Тебе лучше не мухлевать."
    xy "Что? Я вовсе не—"
    $ sename = "se物体_ドア鉄_開く02"
    play se sedict[sename]
    pause (300/1000)
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_cool")
    with Dissolve(200.0/1000)
    voice "voice/a21/6100120a01.opus"
    mx "Да как тебе не стыдно, Шиничи!"
    $ sename = "se物体_バット_振る"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白 zorder 5000
    with Dissolve((0.0)/1000)
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shout")
    with Dissolve(0.0/1000)
    hide 絵色白
    with Dissolve(200.0/1000)
    voice "voice/a21/6100130a01.opus"
    mx "Что ты сделал с бедной Хару-чан?! Я слышала, как она кричала здесь!"
    xy "Я ничего не де—"
    voice "voice/a21/6100140a02.opus"
    aoi "Он бабник!"
    $ sename = "se物体_バット_地面叩く"
    play se sedict[sename]
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    with Dissolve(200.0/1000)
    voice "voice/a21/6100150a01.opus"
    mx "Бабник?!"
    xy "Нет!"
    xy "Как я могу изменять девушке, которой у меня нет?!"
    $ St("C",300,0,0,"bu曽根美雪_制服_腕組み_sad")
    with Dissolve(200.0/1000)
    voice "voice/a21/6100160a01.opus"
    mx "Ну, думаю, тут ты прав..."
    hide StC
    hide StMR
    hide StML
    with Dissolve(0.0/1000)
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_normal")
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    hide 絵背景
    hide 絵演板
    with Dissolve(500.0/1000)
    xy "Ну да ладно, репетиция уже закончилась?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/a21/6100170a01.opus"
    mx "М-мхм-м. Закончилась всего пару минут назад."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/a21/6100180a02.opus"
    aoi "Аой хотела посмотреть..."
    voice "voice/a21/6100190a01.opus"
    mx "Не будем портить сюрприз. Как только дебютное выступление начнётся..."
    $ sename = "se人体_動作_バットスイング01"
    play se sedict[sename]
    show expression Solid("FFFFFF") as 絵色白 zorder 5000
    with Dissolve((50.0)/1000)
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    pause (100/1000)
    hide 絵色白
    with Dissolve(200.0/1000)
    voice "voice/a21/6100200a01.opus"
    mx "...Я позволю тебе увидеть мой славный замах во всей красе."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_smile")
    voice "voice/a21/6100210a02.opus"
    aoi "Ты такая крутая..."
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_smile")
    voice "voice/a21/6100220a01.opus"
    mx "Хе-хе!"
    "Увидев практику замаха Миюки, Аой потеряла дар речи."
    "В это время Миюки, похоже, была в хорошем настроении."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a21/6100230a01.opus"
    mx "Хочешь попробовать помахать ею вокруг себя?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a21/6100240a02.opus"
    aoi "А можно?"
    voice "voice/a21/6100250a01.opus"
    mx "Конечно."
    xy "В таком случае, почему бы нам не пройти на бейсбольное поле?"
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_think")
    voice "voice/a21/6100260a02.opus"
    aoi "Бейсбольное поле?"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_sad")
    voice "voice/a21/6100270a01.opus"
    mx "Ну не знаю... В смысле, всё их оборудование там изношено. Туда, наверное, будет не очень весело идти группой..."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_sad")
    voice "voice/a21/6100280a02.opus"
    aoi "Ну пожалуйста? Аой хочет пойти!"
    xy "Пошли, Миюки? Только на этот раз?"
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_sigh")
    voice "voice/a21/6100290a01.opus"
    mx "Боже... ЛАДНО! Не важно! Давайте все заскочим туда завтра."
    $ St("ML",300,0,0,"st向日アオイ電波_制服_通常_smile")
    voice "voice/a21/6100300a02.opus"
    aoi "Спасибо, Миюки!"
    $ St("MR",300,0,0,"st曽根美雪_制服_腕組み_normal")
    voice "voice/a21/6100310a01.opus"
    mx "Пустяки. Не стоит благодарностей."
    $ St("MR",300,0,0,"st曽根美雪_制服_通常_smile")
    voice "voice/a21/6100320a01.opus"
    mx "Ладно, пошли. Нам пора домой!"
    stop bgm fadeout (3000.0/1000)
    stop se fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (1000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
