label e2221a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    return
label e2221a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_happy")
    with Dissolve(200.0/1000)
    voice "voice/e22/21a00010a01.opus"

    mx "\"С этого момента, мы можем праздновать день рождения столько, сколько захочешь.\""

    xy "\"С-спасибо...\""

    "Её слова подразумевали то, что она останется со мной до конца моих дней, и от этого у меня всё сжалось в груди."

    xy "\"Боже... Такое чувство, будто я сплю или ещё что...\""
    $ St("C",300,0,0,"bu曽根美雪_私服_恋人_smile")
    with Dissolve(200.0/1000)
    voice "voice/e22/21a00020a01.opus"

    mx "\"Почему?\""

    xy "\"Трудно объяснить...\""
    if persistent.eternal_day:
        $ GameName = "e2222a.nss";
    else:
        menu:
            "Я всегда надеялся, что всё так обернётся":
                $ SetChoiceSelect = 0
            "Такое чувство, будто я проснусь и всё исчезнет":
                $ SetChoiceSelect = 1
        if SetChoiceSelect==0:
            $ persistent.miyuki_love += 1
            $ GameName = "e2222a.nss";
        elif SetChoiceSelect==1:
            if (persistent.world_recreate == True):
                $ GameName = "e2222c.nss";
            else:
                $ persistent.miyuki_love -= 1
                $ GameName = "e2222b.nss";
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
