label e2132a_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e2133.nss"
    return
label e2132a:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg010200_1_学校屋上"]+".jpg")
    show expression ("cg/ef/"+imagename["efbgヤバトマ"]+".jpg") as 絵演効果 zorder 100 at truecenter
    with Dissolve(0.0/1000)

    xy "\"Я возьму томатный сок.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_shock")
    hide 絵演効果
    with Dissolve(600.0/1000)
    voice "voice/e21/32a00010a01.opus"

    mx "\"Я думала, ты его ненавидишь!\""

    xy "\"Но я всё ещё могу его выпить. И тебе, наверное, он тоже пойдёт на пользу.\""
    $ St("C",300,0,0,"bu曽根美雪_制服_通常_pride")
    with Dissolve(200.0/1000)
    voice "voice/e21/32a00020a01.opus"

    mx "\"Понятно... Пытаешься быть здоровым, да?\""
    $ sename = "se物体_缶_開ける"
    play se sedict[sename]
    xy "\"Гл-л-л-л... гл-л-л-л... гл-л-л-л...\""

    xy "\"Фух!\""

    "Я состроил гримасу от его вкуса."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
