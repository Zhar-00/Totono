label d6161_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6162.nss"
    return
label d6161:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg040100_2_街通学路"]+".jpg")
    $ sename = "se人体_足音_歩く複数美雪L"
    play se sedict[sename]
    pause (500/1000)
    $ sename = "se環境_ガヤ_交通少L"
    play se sedict[sename]
    with Dissolve(1000.0/1000)
    pause (300/1000)
    voice "voice/d61/6100010a01.opus"
    mx "\"......\""
    xy "\"......\""
    "Мы молча шли по дороге, на улице начинало смеркаться."
    "Миюки бросила выступление лишь ради того, чтобы потащить меня за собой."
    "Она была довольно серьёзной, мне даже казалось неправильным сказать какую-нибудь шутку."
    show expression ("cg/bg/"+imagename["bg040400_2_街交差点"]+".jpg")
    with Dissolve(500.0/1000)
    "Куда, чёрт побери, она меня тащит?"
    "Мы немного отклонились от моего обычного маршрута—"
    show expression ("cg/bg/"+imagename["bg080100_3_コンビニ外正面"]+".jpg")
    with Dissolve(1000.0/1000)
    pause (1000/1000)
    $ St("C",300,0,0,"st曽根美雪_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/d61/6100020a01.opus"
    mx "\"Мы пришли.\""
    xy "\"Семейный магазин за углом Ютаро?..\""
    $ St("C",300,0,0,"st曽根美雪_制服_腕組み_normal")
    with Dissolve(200.0/1000)
    voice "voice/d61/6100030a01.opus"
    mx "\"Он ведь не один там работает, знаешь ли.\""
    xy "\"...А, точно. Там ведь Хару-чан, или как её там.\""
    xy "\"Она в твоём клубе, верно?\""
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
