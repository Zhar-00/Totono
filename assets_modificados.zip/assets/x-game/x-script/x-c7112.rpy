label c7112_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c7121.nss"
    return
label c7112:
    hide 絵色黒
    $ renpy.music.play("ttb19",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg030300_3_自宅リビング"]+".jpg")
    $ st_timezone = "昼"
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(0.0/1000)
    pause (500/1000)
    xy "\"Слушай, просто будь честной со мной.\""
    xy "\"Скажи мне настоящую причину, по которой ты изменила мне.\""
    xy "\"Пожалуйста, просто... помоги мне понять это.\""
    hide StC with Dissolve(200.0/1000)
    "Я знаю, что это выглядело жалко, но я был в отчаянии."
    "Я так сильно люблю её. Я не могу просто забыть об этом."
    "Она потеряла ко мне интерес?"
    "Неужели Рюджиро так хорош в постели?"
    "Мне просто нужны объяснения. Мне всё равно, в чём дело."
    "Я просто хочу понять, почему."
    $ St("C",300,0,0,"st向日アオイ電波_制服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c71/1200010a02.opus"
    aoi "\"Буп-буп...\""
    "Аой смотрела на меня пустым взглядом, что для неё было вполне обычным делом."
    voice "voice/c71/1200020a02.opus"
    aoi "\"Мы можем поговорить наедине?\""
    "Она тихо пробормотала это."
    "С виду она говорила нормально."
    "Но я мог сказать точно."
    "Она была полностью разбитой."
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    pause (100/1000)
    $ St("ML",300,0,0,"st曙龍二郎_私服_通常_shy")
    $ St("MR",300,0,0,"st曙雄太郎_私服_通常_hard")
    with Dissolve(300.0/1000)
    xy "\"...Ребята?\""
    voice "voice/c71/1200030a01.opus"
    mx "\"......\""
    $ St("MR",300,0,0,"st曙雄太郎_私服_通常_smile")
    voice "voice/c71/1200040b01.opus"
    xtl "\"Ладно.\""
    "Миюки молчала, но Ютаро вышел впереди неё."
    $ St("MR",300,0,0,"st曙雄太郎_私服_通常_hard")
    voice "voice/c71/1200050b01.opus"
    xtl "\"Давай, Рюджиро, пошли!\""
    $ St("ML",300,0,0,"st曙龍二郎_私服_通常_surprise")
    voice "voice/c71/1200060b03.opus"
    c "\"Э-эм—\""
    $ St("ML",300,0,0,"st曙龍二郎_私服_通常_sad")
    voice "voice/c71/1200070b03.opus"
    c "\"Сузуки-семпай... я правда не знаю, что сказать... я...\""
    xy "\"Я не хочу это слышать.\""
    $ St("ML",300,0,0,"st曙龍二郎_私服_通常_pinch")
    voice "voice/c71/1200080b03.opus"
    c "\"Хорошо, но... Вы должны мне поверить!\""
    $ St("ML",300,0,0,"st曙龍二郎_私服_通常_sad")
    voice "voice/c71/1200090b03.opus"
    c "\"Да, мы пошли в мою комнату, но я клянусь, Аой-семпай правда ушла прежде, чем что-либо произошло... Честно... Так что...\""
    voice "voice/c71/1200100b03.opus"
    c "\"Я очень уверен... она никогда не переставала любить вас, Сузуки-семпай...\""
    xy "\"......\""
    $ St("MR",300,0,0,"st曙雄太郎_私服_通常_sad")
    voice "voice/c71/1200110b01.opus"
    xtl "\"Рюджиро.\""
    "Ютаро нежно положил руку на дрожащее плечо Рюджиро."
    $ St("MR",300,0,0,"st曙雄太郎_私服_通常_hard")
    voice "voice/c71/1200120b01.opus"
    xtl "\"Пошли.\""
    $ St("ML",300,0,0,"st曙龍二郎_私服_通常_shy")
    voice "voice/c71/1200130b03.opus"
    c "\"...Пока.\""
    hide StC
    hide StMR
    hide StML
    with Dissolve(200.0/1000)
    $ sename = "se物体_ドア室内_閉まる02"
    play se sedict[sename]
    pause (1000/1000)
    stop bgm fadeout (3000.0/1000)
    "Братья Акебоно вышли из гостиной."
    $ sename = "se物体_時計_秒針L"
    play se sedict[sename]
    pause (1000/1000)
    hide StC
    hide StMR
    hide StML
    $ St("ML",300,0,0,"bu曽根美雪_私服_病み_sad")
    with Dissolve(1500.0/1000)
    pause (1000/1000)
    hide StC
    hide StMR
    hide StML
    show expression ("cg/bg/l/"+imagename["bg030300_3_自宅リビング_l"]+".jpg") as 絵上背景 zorder 15 at truecenter
    $ St("MR",300,0,0,"bu向日アオイ電波_制服_通常_normal")
    with Dissolve(1500.0/1000)
    pause (1000/1000)
    hide 絵上背景
    hide StC
    hide StMR
    hide StML
    with Dissolve(1500.0/1000)
    pause (1000/1000)
    "Остались только я, Аой и Миюки."
    "Секунды шли медленно и ровно."
    pause (1000/1000)
    xy "\"Миюки...\""
    xy "\"Пожалуйста.\""
    $ St("C",300,0,0,"st曽根美雪_私服_通常_sigh")
    with Dissolve(200.0/1000)
    voice "voice/c71/1200140a01.opus"
    mx "\"Ладно.\""
    $ St("C",300,0,0,"st曽根美雪_私服_通常_normal")
    with Dissolve(200.0/1000)
    voice "voice/c71/1200150a01.opus"
    mx "\"Я оставлю вас двоих наедине... но пообещай мне кое-что.\""
    voice "voice/c71/1200160a01.opus"
    mx "\"Только не психуй.\""
    xy "\"Не буду.\""
    "Миюки тяжело вздохнула."
    $ St("C",300,0,0,"st曽根美雪_私服_病み_normal")
    with Dissolve(200.0/1000)
    voice "voice/c71/1200170a01.opus"
    mx "\"Я тогда дала себе обещание.\""
    $ St("C",300,0,0,"st曽根美雪_私服_病み_sad")
    with Dissolve(200.0/1000)
    voice "voice/c71/1200180a01.opus"
    mx "\"Все совершают ошибки. Я могу простить и забыть... но только на первый раз.\""
    voice "voice/c71/1200190a01.opus"
    mx "\"НО...\""
    $ St("C",300,0,0,"st曽根美雪_私服_病み_hard")
    with Dissolve(200.0/1000)
    voice "voice/c71/1200200a01.opus"
    mx "\"Помяни мои слова... Надеюсь, второго раза не будет.\""
    voice "voice/c71/1200210a01.opus"
    mx "\"Любовь вечна. Не разрушай её.\""
    xy "\"Что?..\""
    $ St("C",300,0,0,"st曽根美雪_私服_通常_smile")
    with Dissolve(200.0/1000)
    voice "voice/c71/1200220a01.opus"
    mx "\"Увидимся.\""
    hide StC with Dissolve(200.0/1000)
    $ sename = "se物体_ドア室内_閉まる02"
    play se sedict[sename]
    pause (2000/1000)
    "Миюки вышла из комнаты."
    "К несчастью, я был не в том настроении, чтобы верить в вечную любовь."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
