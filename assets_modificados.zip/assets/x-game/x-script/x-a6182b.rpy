label a6182b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "a9111.nss"
    return
label a6182b:
    hide 絵色黒
    show expression ("cg/bg/"+imagename["bg060200_2_バッティングセンターボックス"]+".jpg")
    show expression ("cg/bg/l/"+imagename["bg060200_2_バッティングセンターボックス_l"]+".jpg") as 絵背景 zorder 15:
        pos (-100,-520)
    $ St("C",740,0,0,"bu向日アオイ電波_制服_通常_pain")
    with Dissolve(0.0/1000)
    stop bgm fadeout (1000.0/1000)
    xy "Прости."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_sad")
    with Dissolve(200.0/1000)
    voice "voice/a61/82b00010a02.opus"
    aoi "Шиничи?"
    xy "Я просто не могу сделать это."
    xy "В конце концов, я не могу изменить себя."
    xy "Знаю, я просто смешон, но... я не хочу вмешиваться в мечты Миюки."
    xy "Я сумасшедший ревнивец, сама знаешь. Я бы никогда не позволил ей поцеловать другого парня."
    xy "И поэтому я не могу позволить себе влюбиться в неё."
    xy "Я был бы просто обузой для неё."
    $ St("C",300,0,0,"bu向日アオイ電波_制服_通常_pain")
    with Dissolve(200.0/1000)
    voice "voice/a61/82b00020a02.opus"
    aoi "Ты не прав—"
    hide 絵背景
    hide StC with Dissolve(0.0/1000)
    with Dissolve(500.0/1000)
    xy "Чудес не бывает."
    xy "И богов тоже."
    xy "Всё это... всё это – вымысел."
    xy "Ты ведь знаешь это, верно?"
    show expression ("cg/bg/"+imagename["bg060200_2_バッティングセンターボックス"]+".jpg") as 絵背景 zorder 1000 at truecenter
    with Dissolve(800.0/1000)
    pause (800/1000)
    "Я повернулся, чтобы посмотреть на неё..."

    show expression ("cg/bg/l/"+imagename["bg060200_2_バッティングセンターボックス_l"]+".jpg") as 絵背景弐:
        pos (0,-550)
    with Dissolve((500.0+1000.0)/1000)
    hide 絵背景
    "...но здесь уже никого не было."
    "Я был здесь совершенно один."
    "Всё это было у меня в голове."
    hide 絵背景弐
    with Dissolve(1000.0/1000)
    xy "Какое несчастье. И с кем я сейчас разговаривал?"
    $ sename = "se物体_バット_転がる"
    play se sedict[sename]
    "Пробормотав это себе под нос, я пнул биту, лежащую на земле."
    "Я не мог заставить себя замахнуться ею снова."
    "И я, скорее всего, никогда не буду замахиваться ей до конца своих дней."
    "Не то, чтобы я ожидал каких-либо перемен."
    $ EyeCatchIn(2000.0)
    show expression Solid("000000") as 絵色黒 zorder 10050
    with Dissolve((3000.0+1000.0)/1000)
    pause (2000/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
