label c6153_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "c6154.nss"
    return
label c6153:
    hide 絵色黒
    $ sename = "se環境_ガヤ_教室ざわめくL"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg010801_2_学校体育館演劇準備"]+".jpg")
    with Dissolve(0.0/1000)
    xy "......"

    "Это часть сюрприза на день рождения?"

    "Озадаченный, я позвонил в свой пустой дом."
    hide StC with Dissolve(200.0/1000)
    $ sename = "se物体_携帯_通話待ちL"
    play se sedict[sename]
    pause (3000/1000)

    "Я знаю, что Аой сейчас не там, поэтому мне никто и не ответит."
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
