label e3415b_MAIN:
    call expression GameName
    $ PreGameName = GameName
    $ GameName = "e3412b.nss"
    return
label e3415b:
    hide 絵色黒
    $ renpy.music.play("ttb25",channel = "bgm", if_changed = True)
    $ sename = "se環境_水音_シャワーL"
    play se sedict[sename]
    show expression ("cg/bg/"+imagename["bg110600_3_マンション台所"]+".jpg")
    with Dissolve(0.0/1000)
    xy "\"Ладно.\""

    "Раз она так сильно отчаялась, то, ну, я правда не вижу смысла спорить об этом."

    "Я развернулся."
    show expression ("cg/bg/"+imagename["bg110301_3_マンション寝室消灯"]+".jpg")
    $ st_timezone = "夜"
    with Dissolve(500.0/1000)
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
