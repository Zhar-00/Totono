label e2225b_MAIN:
    call expression GameName
    $ persistent.imagelog["eve2225a美雪男の浪漫メイドe"]=True
    $ PreGameName = GameName
    $ persistent.ejaculation +=1;
    $ PreGameName = GameName
    $ temp_miyuki_sex1 = True;
    $ persistent.miyuki_sex1 = True;
    $ persistent.count_e2225b +=1;
    $ persistent.library_scene6 = True;
    if (persistent.count_e2225e > 0 and persistent.count_e2225b == 1):
        $ GameName = "e2225h.nss";
    elif (persistent.count_e2225b > 1):
        $ GameName = "e2225d.nss";
    else:
        $ GameName = "e2225c.nss";
    if (RECO_PLAY==1):
        $ GameCircle=False
    return
label e2225b:
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    show expression ("cg/ev/"+imagename["eve2225a美雪男の浪漫メイドd"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)

    xy "\"Миюки... я сейчас кончу в тебя!..\""
    voice "voice/e22/25b00010a01.opus"

    mx "\"Ха-а-а! Н-н-н... Хорошо... Ладно... А-а-ах! Кончай куда хочешь— А-А-АХ! А-АХ!\""
    voice "voice/e22/25b00020a01.opus"

    mx "\"Ого... я чувствую, как он разбухает во мне— Ха-а-а-а-а! А-ах! А-ах! А-А-А-А-А-АХ!!!\""
    voice "voice/e22/25b00030a01.opus"

    mx "\"Н-нха-а-А-А-АХ! А-ах! А-а-а-ах! Ох, блядь! Я люблю тебя! Я люблю тебя! Мне так приятно— А-А-АХ!\""
    voice "voice/e22/25b00040a01.opus"

    mx "\"Я скоро— Я скоро опять кончу—! Пожалуйста— кончай со мной—!\""
    voice "voice/e22/25b00050a01.opus"

    mx "\"Просто потеряй самоконтроль— и заполни мою киску своей спермой—! Н-нха-а-а-А-А-А-АХ—!\""
    voice "voice/e22/25b00060a01.opus"

    mx "\"Ха-а! А-ах! А-ах! А-ах! А-ах! А-а-а-ах! А-ах! А-ах, а-ах, а-ах! А-а-а-а-а-а-ах—\""
    voice "voice/e22/25b00070a01.opus"

    mx "\"Н-нха-а-а-а-а-а-а-а-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-А-АХ—!!!\""
    hide 絵色黒
    $ renpy.music.play("ttb15",channel = "bgm", if_changed = True)
    show expression ("cg/bg/"+imagename["bg110100_3_マンションリビング"]+".jpg")
    show expression ("cg/ev/"+imagename["eve2225a美雪男の浪漫メイドd"]+".jpg") as 絵専 zorder 1100 at truecenter
    with Dissolve(0.0/1000)
    show expression Solid("FFFFFF") as 絵演色白 zorder 5000
    with Dissolve((200.0+800.0)/1000)
    with Dissolve((250.0+1000.0)/1000)
    show expression ("cg/ev/"+imagename["eve2225a美雪男の浪漫メイドe"]+".jpg") as 絵専 zorder 1100 at truecenter
    pause (500/1000)
    hide 絵絶頂板
    hide 絵演色白
    with Dissolve(1500.0/1000)
    pause (1000/1000)
    voice "voice/e22/25b00080a01.opus"

    mx "\"А-а-а-ах... а-ах... н-нгх... н-н... н-н-н... н-н-н-нг!.. Н-н-н-нг-гх!!!..\""
    voice "voice/e22/25b00090a01.opus"

    mx "\"Я... чувствую это... н-н... н-н-н... Так много... течёт во мне... Ха-а!\""
    voice "voice/e22/25b00100a01.opus"

    mx "\"Н-нг-гх-х! Н-н-н... н-н-нг-г... н-н... Ха-а! Ха-а! Ха-а... н-н... н-н-н... н-н...\""

    "Я уже давно как перестал двигаться, но тело Миюки продолжало слегка вздрагивать."

    "Её киска сжалась так, будто выжимала всю сперму из моего члена до последней капли."

    "Обессиленный, я рухнул на неё..."
    stop bgm fadeout (3000.0/1000)
    show expression Solid("000000") as 絵色黒 zorder 1900
    with Dissolve((3000.0+500.0)/1000)

    "...и потерял своё сознание."
    show expression Solid("000000") as 絵色黒上 zorder 5000
    with Dissolve((2000.0+1000.0)/1000)
    pause (16/1000)
    if (RECO_PLAY==1):
        pass
    else:
        scene expression "cg/bg/black.jpg" as 絵色黒 zorder 2000 with ImageDissolve(im.MatrixColor("cg/data/zzex_eyelid_01_00_0.png",im.matrix.invert()),(30000/1000))
    return
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
